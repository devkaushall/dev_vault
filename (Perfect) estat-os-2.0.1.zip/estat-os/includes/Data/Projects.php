<?php
/**
 * Society / project repository.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Audit\AuditLog;
use EstatOS\Support\Sanitize;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Projects are first class records that can act as a parent for listings.
 */
final class Projects {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete' ) );
	}

	/**
	 * Create or update a project.
	 *
	 * @param array<string,mixed> $input   Raw input.
	 * @param int                 $post_id Existing ID or 0.
	 * @return int|WP_Error
	 */
	public static function save( array $input, int $post_id = 0 ) {
		$title = Sanitize::text( $input['title'] ?? '' );
		if ( 0 === $post_id && '' === $title ) {
			return new WP_Error( 'estat_invalid_title', __( 'Please enter the name of the society or project.', 'estat-os' ) );
		}

		$postarr = array(
			'post_type'   => PostTypes::PROJECT,
			'post_title'  => $title,
			'post_status' => Sanitize::choice( $input['status'] ?? 'publish', array( 'draft', 'publish' ), 'publish' ),
		);
		if ( isset( $input['description'] ) ) {
			$postarr['post_content'] = Sanitize::html( $input['description'] );
		}
		if ( $post_id > 0 ) {
			$postarr['ID'] = $post_id;
			$result        = wp_update_post( $postarr, true );
		} else {
			$result = wp_insert_post( $postarr, true );
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$project_id = (int) $result;

		foreach ( Meta::project_schema() as $key => $field ) {
			if ( ! empty( $field['computed'] ) ) {
				continue;
			}
			$short = substr( $key, strlen( '_estat_' ) );
			if ( array_key_exists( $key, $input ) ) {
				$raw = $input[ $key ];
			} elseif ( array_key_exists( $short, $input ) ) {
				$raw = $input[ $short ];
			} else {
				continue;
			}
			$value = Meta::sanitize_value( $raw, $field );
			if ( '' === $value || array() === $value ) {
				delete_post_meta( $project_id, $key );
			} else {
				update_post_meta( $project_id, $key, $value );
			}
		}

		if ( isset( $input['locality'] ) ) {
			$locality = is_array( $input['locality'] ) ? $input['locality'] : array( $input['locality'] );
			$ids      = array();
			foreach ( $locality as $item ) {
				if ( is_numeric( $item ) ) {
					$ids[] = (int) $item;
					continue;
				}
				$name = Sanitize::text( $item );
				if ( '' === $name ) {
					continue;
				}
				$term = term_exists( $name, Taxonomies::LOCALITY );
				if ( ! is_array( $term ) ) {
					$term = wp_insert_term( $name, Taxonomies::LOCALITY );
				}
				if ( ! is_wp_error( $term ) ) {
					$ids[] = (int) $term['term_id'];
				}
			}
			wp_set_object_terms( $project_id, $ids, Taxonomies::LOCALITY, false );
		}

		if ( isset( $input['cover_id'] ) ) {
			$cover = Sanitize::int( $input['cover_id'] );
			if ( $cover ) {
				set_post_thumbnail( $project_id, $cover );
			}
		}

		AuditLog::record( $post_id > 0 ? 'project.updated' : 'project.created', 'project', $project_id, array() );
		return $project_id;
	}

	/**
	 * Statistics for one project.
	 *
	 * @param int $project_id Project ID.
	 * @return array<string,mixed>
	 */
	public static function stats( int $project_id ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'estat_index';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total,
					SUM(CASE WHEN availability = 'available' THEN 1 ELSE 0 END) AS available,
					MIN(CASE WHEN price > 0 THEN price END) AS price_min,
					MAX(price) AS price_max
				 FROM {$table} WHERE project_id = %d AND post_status = 'publish'",
				$project_id
			),
			ARRAY_A
		);
		// phpcs:enable

		return array(
			'project_id' => $project_id,
			'listings'   => isset( $row['total'] ) ? (int) $row['total'] : 0,
			'available'  => isset( $row['available'] ) ? (int) $row['available'] : 0,
			'price_min'  => isset( $row['price_min'] ) ? (float) $row['price_min'] : 0.0,
			'price_max'  => isset( $row['price_max'] ) ? (float) $row['price_max'] : 0.0,
		);
	}

	/**
	 * Detach listings from a deleted project so relationships never break.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_delete( int $post_id ): void {
		if ( PostTypes::PROJECT !== get_post_type( $post_id ) ) {
			return;
		}
		$listings = get_posts(
			array(
				'post_type'   => PostTypes::LISTING,
				'post_status' => 'any',
				'numberposts' => 500,
				'fields'      => 'ids',
				'meta_key'    => '_estat_project_id',
				'meta_value'  => $post_id,
			)
		);
		foreach ( $listings as $listing_id ) {
			delete_post_meta( (int) $listing_id, '_estat_project_id' );
			Listings::refresh_derived( (int) $listing_id );
		}
		AuditLog::record( 'project.deleted', 'project', $post_id, array( 'detached' => count( $listings ) ) );
	}

	/**
	 * Find a project by reference number.
	 *
	 * @param string $external_id Reference.
	 * @return int
	 */
	public static function find_by_external_id( string $external_id ): int {
		$external_id = Sanitize::text( $external_id );
		if ( '' === $external_id ) {
			return 0;
		}
		$found = get_posts(
			array(
				'post_type'     => PostTypes::PROJECT,
				'post_status'   => 'any',
				'numberposts'   => 1,
				'fields'        => 'ids',
				'meta_key'      => '_estat_external_id',
				'meta_value'    => $external_id,
				'no_found_rows' => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}
}
