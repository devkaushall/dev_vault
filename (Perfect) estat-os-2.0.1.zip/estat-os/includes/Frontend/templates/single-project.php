<?php
/**
 * Fallback template for a single society or project.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Projects;
use EstatOS\Frontend\Components;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );

get_header();

while ( have_posts() ) :
	the_post();
	$project_id = (int) get_the_ID();
	$stats      = Projects::stats( $project_id );
	?>
	<main class="estat-single" id="main">
		<h1><?php the_title(); ?></h1>
		<ul class="estat-single-facts">
			<li><strong><?php esc_html_e( 'Stage', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'project_statuses', (string) get_post_meta( $project_id, '_estat_project_status', true ) ) ); ?></li>
			<?php if ( $stats['price_min'] > 0 ) : ?>
				<li><strong><?php esc_html_e( 'Prices from', 'estat-os' ); ?>:</strong> <?php echo esc_html( Format::money( (float) $stats['price_min'] ) ); ?></li>
			<?php endif; ?>
			<li><strong><?php esc_html_e( 'Properties listed', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) (int) $stats['listings'] ); ?></li>
		</ul>
		<div class="estat-single-description"><?php the_content(); ?></div>
		<h2><?php esc_html_e( 'Available here', 'estat-os' ); ?></h2>
		<?php echo Components::directory( array( 'project_id' => $project_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</main>
	<?php
endwhile;

get_footer();
