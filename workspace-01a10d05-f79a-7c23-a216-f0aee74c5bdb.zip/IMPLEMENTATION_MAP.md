# Internal implementation map

**Audit date:** 2026-10-05  
**Release status:** **NOT READY**. The source tree is an established React/TypeScript application; preserve it and its verified behavior. This map is a dependency-ordered view of existing work and remaining acceptance, not a new phase plan. Requirements remain defined by `Chess_Game_Master_Product_Technical_Spec_v1.0_HI.md`, `Chess_Game_Master_Research_HI.md`, and `Chess_Game_Master_Chess_Atlas_HI.md`.

## Existing architecture and ownership

- **Application shell and routes — `src/app/`**: React screens, navigation, local-store context, mode policy, persisted display/time-control preferences, Settings, and Practice resume/review routing. `src/components/ChessWorkspace.tsx` is the shared board workspace. Keep engine-mode decisions behind `src/app/modePolicy.ts` and the fail-closed engine gate.
- **Chess domain — `src/domain/chess/`**: `chess.js`-backed legal moves, canonical legal SAN/UCI history, repetition/draw state, FEN/PGN adapters, immutable game transitions, and conservative terminal classification. The domain owns rules; the UI must not create a second legality/adjudication implementation.
- **Clock domain — `src/domain/clock/`**: monotonic Fischer clock, revisions, increment and paused snapshots. Practice UI starts only after explicit user action; timed records recover paused. Any unresolved flag result stays locked rather than receiving an invented result.
- **Knowledge and review — `src/knowledge/`**: provenance-bearing local opening data, bounded strategy/pawn/tactic/attack/defence/endgame recognition, shared evidence aggregation, move classification, key moments, evidence-bound explanations and candidate learning insights. Recognition is not engine evaluation or human-intent inference.
- **Learning and local state — `src/learning/`, `src/storage/LocalChessStore.ts`**: lesson/puzzle/opening progress, IndexedDB schema-v2 validation/migration, analysis sidecars, row quarantine/recovery, backup export/restore and deletion.
- **Engine boundary — `src/engine/`**: generic UCI adapter and test-only transport fake; `engineGate.ts` refuses creation while approval/assets/runtime are unavailable. There is no Stockfish binary, NNUE, real Worker, substitute bot, LLM analysis or human multiplayer.
- **PWA, static assets and release metadata — `src/pwa/`, `public/`, `index.html`, `SBOM.cdx.json`**: local service-worker shell/cache and update prompt, bundled CC0 opening index, notices, manifest, CSP meta, `_headers`, and CycloneDX SBOM. `public/_headers` requires a compatible deploy host; Vite preview does not apply it as response headers.
- **Verification**: Vitest suites live beside source as `*.test.ts(x)`. Current final evidence is summarized in `IMPLEMENTATION_STATUS.md` and the product contract remains unchanged.

## Verified integrated workflows

- Settings persists board coordinates/orientation, reduced-motion choice, and the next Practice clock preset; those values affect a newly opened/timed board.
- A timed local Practice board starts, accepts and saves legal moves, pauses on browser lifecycle changes, can be stopped without assigning a chess result, and remains recoverable from local storage.
- A standard, untouched scratch board does not create a history row; its first legal move makes it durable. Timed/custom-FEN and previously saved records remain durable.
- Local backup downloads and validated restore cover games/clocks, progress, analysis, recovery copies and app preferences; import merges and does not overwrite matching IDs.
- After an online preload, production-preview offline reload resumes a saved Practice game and accepts another local move.
- Final suite: 37 test files / 297 tests; typecheck, production build and npm audits pass. Production Chromium and the responsive/accessibility checks are detailed in `IMPLEMENTATION_STATUS.md`.

## Dependency-ordered remaining work

These are acceptance dependencies, not new phases. Do not mark a dependent feature complete until its prerequisite and integrated tests pass.

- **Rules correctness before release:** complete exact FIDE dead-position detection and the Article 6.9 timeout “any possible legal sequence” mating-possibility decision; preserve checkmate precedence and draw/resignation/timeout/abort distinctions. The current conservative `adjudication-pending` path is safer than a false result but is not acceptance. Add exhaustive/curated boundary fixtures and verify the edition/source immediately before release. This prerequisite applies to every playable mode, including timed Practice.
- **External licensing gate before any engine work:** obtain written GPL-3.0-or-later distribution approval and owner-approved Stockfish 19 source/build, NNUE, notices and distribution plan. Until those exact artifacts/approvals exist, retain the disabled engine UI and policy. After approval, implement a real dedicated Worker and test startup/readiness, cancellation, stale responses, illegal PV/bestmove rejection, crashes/recovery, responsiveness and review/coached-mode boundaries before enabling Challenge or Coached Practice. A generic adapter plus test fake is not engine acceptance.
- **Complete remaining V1 product requirements:** Hindi-first shell still contains English UI; five starter lessons are rule-focused and lack user level selection/full progression; puzzles are a small mate-in-one set; opening recognition/training and curated knowledge remain selective; Review lacks engine-backed analysis, annotations and preservation of PGN comments/variations; saved-position naming and a full variation/retry workflow are absent. Extend only against the specification/Atlas with source provenance, legal-line validation and false-positive tests. Do not convert candidate recognition into evaluation or invent claims to fill missing content.
- **Close deployment and asset sign-offs:** obtain provenance/license confirmation for the bundled app icons; choose the actual static host and verify the required CSP and response security headers there. The preview result cannot prove provider enforcement. Keep the SBOM/notices synchronized and review every future dependency/data asset separately.
- **Manual/platform release acceptance:** run a human WCAG 2.2 AA and screen-reader audit; verify touch targets, zoom/reflow, forced colors, keyboard/promotion flows on named devices; test current Safari/Firefox/Edge plus iOS/Android; measure the specification's performance budgets on named baseline hardware. Existing Chromium/axe checks are useful evidence, not substitutes for these acceptance items.
- **Reliability depth:** exercise IndexedDB quota/write failure, multi-tab migration/update races, worker error paths once unblocked, longer offline/cache-eviction behavior, and structured fuzz/property tests for PGN/FEN/storage boundaries. These do not justify weakening strict validation or deleting recoverable rows.

## Scope protections

- Do not restart or replace the working React/TypeScript app, reimplement validated chess.js rules, or remove Phase 1–7 behavior to make the matrix look smaller.
- Phase 8 remains **BLOCKED** until the licensing gate is actually met. Do not use a different engine, fake evaluation, hidden fallback, LLM analysis, or live competitive-human assistance.
- Keep the app local-first; preserve original Review history, existing fair-play policy, uncertainty labels and recovery data.
- Do not treat FEN as repetition history, candidates as forced plans, engine scores as human intent, or automated scans as complete legal/accessibility sign-off.
- Historical numbered phase notes remain in the status document for traceability; this map adds no numbered phase structure and does not silently remove any original requirement.