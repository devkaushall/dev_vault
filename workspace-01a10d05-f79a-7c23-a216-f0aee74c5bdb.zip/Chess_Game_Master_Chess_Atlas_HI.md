# Chess Game Master — Opening, Strategy, Tactics & Endgame Atlas

**भाषा:** सरल हिन्दी; प्रचलित English chess terms साथ में  
**शोध स्थिति:** research, analysis और product-design सुझाव; कोई code नहीं  
**कटऑफ:** 5 अक्टूबर 2026

## इस atlas का दायरा

यह major openings, आम minor/offbeat systems, gambits, रणनीतिक योजनाओं, tactical motifs, attacking/defensive patterns और endgame plans का **व्यावहारिक पहचान-मानचित्र** है। इसे हर सम्भव opening move की पूर्ण theory-book न समझें। Opening tree बहुत जल्दी फैलता है; कई move-orders एक ही position तक पहुँचते हैं (transposition), और किसी नाम की सीमा/database label स्रोत के अनुसार बदल सकती है।

Opening नामों के लिए ECO A–E वर्गीकरण और Lichess के खुले opening dataset को उपयोगी index माना गया है। Dataset नाम, ECO, PGN move-sequence और position fields देता है; उसका अपना नियम है कि transposition सम्भालने के लिए एक ही position के कई entries हो सकते हैं। वह **नाम/पहचान का index है, strategy का प्रमाण या सभी theoretical continuations की पूरी सूची नहीं**। [1](https://github.com/lichess-org/chess-openings) [2](https://lichess.org/opening/tree)

इसलिए नीचे तीन स्तर हैं:
1. प्रमुख families और उनकी आम branches;
2. उपयोगी minor systems और gambits की पहचान;
3. बोर्ड पर योजना/मोटिफ पहचानने के संकेत।

किसी opening को पहचानने का सबसे अच्छा तरीका सिर्फ नाम याद करना नहीं, बल्कि **आरम्भिक move sequence + pawn structure + pieces की जगह + सम्भावित pawn breaks** देखना है। `3...Nf6` का अर्थ है तीसरी चाल पर Black का Nf6। `≈` का अर्थ है “आम तौर पर”, न कि हर position में पक्का नियम।

---

# 1. Opening map: पहले चालों से family पहचानें

## 1.1 पहली चाल का बड़ा नक्शा

- **1.e4 e5 — Open Games:** जल्दी central contact; Italian, Ruy Lopez, Scotch, Four Knights, Vienna, King’s Gambit आदि।
- **1.e4 और Black का कोई दूसरा जवाब — Semi-open games:** Sicilian `...c5`, French `...e6`, Caro-Kann `...c6`, Scandinavian `...d5`, Pirc/Modern, Alekhine आदि।
- **1.d4 d5 — Queen’s-pawn/closed families:** Queen’s Gambit, Slav/Semi-Slav, Tarrasch, तथा London/Colle जैसे systems।
- **1.d4 Nf6 और ...g6/...e6/...c5 — Indian/related defences:** King’s Indian, Grünfeld, Nimzo-Indian, Queen’s Indian, Benoni आदि।
- **Flank moves `1.c4`, `1.Nf3`, `1.f4`, `1.b3`, `1.b4` आदि:** English, Réti, Bird, Larsen/Nimzo-Larsen, Polish/Sokolsky आदि; ये अक्सर दूसरे families में transpose होते हैं।

**ECO का मोटा index:** A00–A99 में flank/irregular और कुछ Dutch/Benoni lines; B00–B99 में French को छोड़कर कई semi-open `1.e4` replies; C00–C99 में French और `1.e4 e5` open games; D00–D99 में Queen’s-pawn/QG/Slav और कुछ Grünfeld lines; E00–E99 में Indian defences और Catalan-जैसी families। ये broad volumes हैं—किसी transposed position का code उसकी exact line पर निर्भर हो सकता है। [1](https://github.com/lichess-org/chess-openings)

**सामान्य शुरुआती उद्देश्य:** center पर प्रभाव, pieces का विकास, king safety, और ऐसा pawn structure बनाना जिसमें आगे की योजना समझ आए। यह checklist है, कोई कठोर नियम नहीं—कई hypermodern openings जानबूझकर opponent को center में pawns लगाने देती हैं और बाद में उन्हें चुनौती देती हैं। Strategy को material, activity, space, pawn structure और king safety से जोड़कर देखना उपयोगी है। [9](https://www.chess.com/terms/chess-strategy)

## 1.2 1.e4 e5: Open Games

### Ruy Lopez / Spanish
- **पहचान:** `1.e4 e5 2.Nf3 Nc6 3.Bb5`। White का bishop c6-knight पर दबाव डालता है, जो e5 pawn का रक्षक है।
- **मकसद/आकार:** development के साथ e5-centre पर दीर्घकालीन दबाव; अक्सर manoeuvring और central break `d4` महत्वपूर्ण होते हैं।
- **आम branches:** Berlin `3...Nf6`; Morphy `3...a6`; Closed, Open, Exchange; Marshall Counterattack में Black बाद में `...d5` से gambit/initiative लेता है; Schliemann `3...f5` एक तेज़ counter.
- **खेल में cue:** bishop b5 पर है; Black को तय करना है कि ...a6 से उसे पूछे, ...Nf6 से e4/e5 पर खेले, या कोई तेज़ counter चुने।

### Italian Game
- **पहचान:** `1.e4 e5 2.Nf3 Nc6 3.Bc4`।
- **मकसद/आकार:** f7 पर शुरुआती नज़र और जल्दी development।
- **आम branches:** Giuoco Piano `3...Bc5`, जिसमें शांत `d3` (Giuoco Pianissimo) या `c3/d4` योजनाएँ; Evans Gambit `4.b4`; Two Knights Defence `3...Nf6`, जिससे Fried Liver/Traxler जैसे तेज़ sub-lines निकलते हैं।
- **खेल में cue:** bishop c4 से f7 diagonal; देखें कि Black ...Bc5 खेलता है या ...Nf6 से e4 पर जवाब देता है।

### Scotch Game
- **पहचान:** `1.e4 e5 2.Nf3 Nc6 3.d4`।
- **मकसद/आकार:** centre को जल्दी खोलकर pieces सक्रिय करना; positions अक्सर खुली और सीधी होती हैं।
- **आम branches:** Classical `4.Nxd4 Bc5`, Schmidt `...Nf6`, Mieses, Scotch Gambit `4.Bc4`, Göring Gambit `4.c3`।
- **खेल में cue:** तीसरी चाल पर d-pawn से central exchange—यह Scotch का सबसे साफ संकेत है।

### Four Knights Game
- **पहचान:** `1.e4 e5 2.Nf3 Nc6 3.Nc3 Nf6`।
- **मकसद/आकार:** दोनों तरफ सरल development; फिर `d4` या `Bb5` से centre पर निर्णय।
- **आम branches:** Scotch Variation `4.d4`, Spanish/Rubinstein-जैसे setups, तथा बहुत तीखी Halloween Gambit `4.Nxe5`।
- **खेल में cue:** दोनों knights f3/c3 और f6/c6 पर; चारों knights जल्दी विकसित।

### Vienna Game
- **पहचान:** `1.e4 e5 2.Nc3`।
- **मकसद/आकार:** e4 को सहारा देते हुए f-pawn push या quiet development की गुंजाइश।
- **आम branches:** Vienna Gambit `3.f4`, शांत Mieses setup `3.g3`, तथा Black का `2...Nf6` (Falkbeer नाम से भी मिलता है)।
- **खेल में cue:** White ने Nf3 से पहले Nc3 चुना है; आगे f4 आए तो आक्रमणकारी Vienna setup सम्भव।

### King’s Gambit
- **पहचान:** `1.e4 e5 2.f4`।
- **मकसद/आकार:** f-pawn देकर development, e-file/f-file पर खुली lines और centre पर दबाव पाना।
- **आम branches:** Accepted `2...exf4` (King’s Knight/Bishop Gambit, Kieseritzky, Muzio जैसे नाम); Declined setups; Falkbeer Countergambit `2...d5`।
- **खेल में cue:** White का f-pawn e4 के support के लिए आगे आया; king safety और material दोनों जल्दी महत्वपूर्ण हो सकते हैं।

### Petroff / Russian Defence
- **पहचान:** `1.e4 e5 2.Nf3 Nf6`।
- **मकसद/आकार:** Black e5 की रक्षा करने के बजाय e4 पर counterattack करता है; अक्सर symmetric और solid game।
- **आम branches:** `3.Nxe5` के बाद Classical lines; `3.d4`; `3.Nc3` से Four Knights में transposition सम्भव।
- **खेल में cue:** दोनों knights एक-दूसरे के centre pawn पर हमला करते हैं—इसे सिर्फ “दोनों तरफ pawn बचाना” न समझें।

### Philidor Defence
- **पहचान:** `1.e4 e5 2.Nf3 d6`।
- **मकसद/आकार:** e5 को pawn से सहारा; बाद में ...Nf6 और सुरक्षित development। Black का light-squared bishop कुछ समय बन्द रह सकता है।
- **आम branches:** Hanham setup, Exchange, तथा कम आम Philidor Countergambit `3.d4 f5`।
- **खेल में cue:** Black ने ...Nc6 की जगह ...d6 से e5 बचाया; White को अक्सर space और जल्दी d4 मिलता है।

### Ponziani Opening
- **पहचान:** `1.e4 e5 2.Nf3 Nc6 3.c3`।
- **मकसद/आकार:** `d4` को तैयार कर centre में दो pawns लगाना।
- **आम branches:** `3...Nf6` Jaenisch Counterattack, `3...d5` replies, तथा Ponziani Countergambit `3...f5`।
- **खेल में cue:** White का c-pawn आगे है और b1-knight का सामान्य c3 square बन्द हो गया है।

### Bishop’s Opening और Centre/Danish Gambit
- **Bishop’s Opening पहचान:** `1.e4 e5 2.Bc4`; f7 पर दबाव और flexible development; `2...Nf6` तथा Italian-जैसी transpositions आम।
- **Centre Game पहचान:** `1.e4 e5 2.d4 exd4`; White तुरंत centre खोलता है।
- **Danish Gambit पहचान:** Centre Game के बाद `3.c3`, और आगे `...dxc3` स्वीकार होने पर White तेज़ development/खुली diagonals के लिए एक या अधिक pawns दे सकता है।
- **खेल में cue:** अगर c-pawn भी देकर bishops/queen जल्दी सक्रिय हों, तो gambit की compensation development और king-attack में खोजें।

### अन्य 1.e4 e5 sidelines
- **Three Knights:** `1.e4 e5 2.Nf3 Nc6 3.Nc3` के बाद Black का ...Nf6 न आए तो भी तीन-knight setup नाम से पहचाना जाता है; आगे Four Knights में transpose हो सकता है।
- **Wayward Queen / Parham:** `1.e4 e5 2.Qh5` (कभी Qf3) — f7 पर जल्दी pressure, पर queen tempo से chase हो सकती है।
- **Damiano Defence:** `1.e4 e5 2.Nf3 f6` — Black e5-pawn को और सहारा देकर knight को चुनौती देने की कोशिश करता है, पर king-side कमजोर squares की कीमत देखनी चाहिए; यह uncommon sideline है।
- **Latvian और Elephant Gambits:** `2...f5` और `2...d5`; दोनों centre पर तुरन्त counterattack की कोशिश हैं, पर इनकी material/king-safety स्थिति हर line में जाँचें।

## 1.3 1.e4 के विरुद्ध semi-open defences

### Sicilian Defence
- **पहचान:** `1.e4 c5`।
- **मकसद/आकार:** Black d4-square को चुनौती देता है और asymmetric pawn structure स्वीकार कर counterplay बनाता है। Open Sicilian में `2.Nf3` और `3.d4 cxd4 4.Nxd4` के बाद दोनों sides के plans अलग हो सकते हैं।
- **Black की मुख्य families:** Najdorf `...a6`; Dragon `...g6`; Accelerated Dragon; Scheveningen `...e6` और `...d6`; Sveshnikov/Kalashnikov में ...e5; Classical `...Nc6/...d6`; Taimanov/Kan–Paulsen में ...e6; O’Kelly `2...a6`।
- **White की anti-Sicilians:** Alapin `2.c3`; Closed Sicilian `2.Nc3`; Grand Prix `2.Nc3` और f4; Rossolimo `2.Nf3 Nc6 3.Bb5`; Moscow `2.Nf3 d6 3.Bb5+`; Smith–Morra `2.d4 cxd4 3.c3`; Wing Gambit `2.b4`; Bowdler `2.Bc4`।
- **खेल में cue:** Black ने c-pawn से e4 का जवाब दिया। Open Sicilian में central d-pawn exchange; कई lines में White kingside activity और Black queenside counterplay देखता है। Sicilian के नाम और branches बहुत गहरे हैं—यह सूची केवल प्रमुख families है। [6](https://www.chess.com/openings/Sicilian-Defense)

### French Defence
- **पहचान:** `1.e4 e6`, प्रायः आगे `...d5`।
- **मकसद/आकार:** Black centre पर हमला करता है; e6-d5 pawn chain के बदले c8 bishop को बाहर निकालना कभी चुनौती बन सकता है।
- **आम branches:** Advance `3.e5`; Exchange `3.exd5`; Tarrasch `3.Nd2`; Winawer `3.Nc3 Bb4`; Classical/Steinitz `3.Nc3 Nf6`; Rubinstein और MacCutcheon जैसी कम/विशेष शाखाएँ।
- **खेल में cue:** White का e-pawn आगे बढ़कर जगह लेता है या exchange होता है; White का `c4` और Black के `...c5`/`...f6` जैसे pawn breaks अहम।

### Caro–Kann Defence
- **पहचान:** `1.e4 c6`, आम तौर पर `...d5`।
- **मकसद/आकार:** centre को support करते हुए Black का c8 bishop French की तुलना में बाहर आने की अधिक गुंजाइश रखता है।
- **आम branches:** Classical `3.Nc3/3.Nd2 d5`; Advance `3.e5`; Exchange `3.exd5`; Panov–Botvinnik `3.exd5 cxd5 4.c4`; Two Knights और Fantasy `3.f3`।
- **खेल में cue:** `...c6` के बाद `...d5`; अक्सर solid pawn structure बनाम White की space/activity।

### Scandinavian / Centre-Counter Defence
- **पहचान:** `1.e4 d5`।
- **मकसद/आकार:** Black तुरन्त e4 pawn को चुनौती देता है।
- **आम branches:** `2.exd5 Qxd5` के बाद अक्सर `...Qa5` या queen retreat; Modern `2...Nf6` से knight द्वारा pawn वापस लेने की तैयारी; कुछ sharp Icelandic/Portuguese gambit sidelines।
- **खेल में cue:** White के exchange के तुरन्त बाद Black की queen या knight d5 पर recapture की योजना बनाती है। Queen जल्दी बाहर हो तो उसे tempo से हमला करने की सम्भावना देखें।

### Alekhine Defence
- **पहचान:** `1.e4 Nf6 2.e5 Nd5`।
- **मकसद/आकार:** Black White के pawns को आगे बुलाकर बाद में उन पर हमला करना चाहता है।
- **आम branches:** Four Pawns Attack, Exchange, Modern, Two Pawns/Attack setups।
- **खेल में cue:** Black का knight बार-बार pawn से chased होता है; White के पास space, Black को centre पर timely counterstrike चाहिए।

### Pirc और Modern Defences
- **Pirc पहचान:** `1.e4 d6 2.d4 Nf6 3.Nc3 g6`।
- **Modern पहचान:** `1.e4 g6` और सामान्यतः ...Nf6 को कुछ देर टालना; ...Nf6 जल्दी आने पर Pirc में transposition हो सकता है।
- **मकसद/आकार:** Black पहले दूरी से centre पर नियंत्रण, फिर `...e5` या `...c5` से counterattack; bishop अक्सर g7 पर fianchetto।
- **आम branches:** Pirc में Austrian Attack `4.f4`, 150 Attack `4.Be3`, Sämisch `4.f3`, Classical/Byrne; Modern में Gurgenidze-जैसे systems और अलग move-orders।
- **खेल में cue:** White को बड़ा pawn centre बनाने दिया गया है; Black के bishop की लंबी diagonal और central pawn break पर नज़र रखें। यह “centre मुफ्त में दे देना” नहीं, counterplay का positional चुनाव है।

### कम आम 1.e4 defences
- **Nimzowitsch Defence:** `1.e4 Nc6`; Black जल्दी knight निकालकर बाद में `...d5` से centre पर खेल सकता है। कई lines Scandinavian-जैसी बनती हैं।
- **Owen Defence:** `1.e4 b6`; bishop b7 से लंबी diagonal पर दबाव, पर centre को सावधानी से संभालना पड़ता है।
- **St. George Defence:** `1.e4 a6`; flank-pawn चाल के बाद ...b5 या ...d5 की तैयारी वाला offbeat choice।
- **खेल में cue:** Black ने e-pawn को सीधे जवाब देने के बजाय flank piece/bishop setup चुना है; नाम से ज्यादा देखिए कि वह e4/d4 पर कब प्रहार करता है।

## 1.4 1.d4 d5 और Queen’s Gambit परिवार

### Queen’s Gambit
- **पहचान:** `1.d4 d5 2.c4`। White c-pawn देकर/आगे रखकर d5 पर दबाव और centre में प्रभाव चाहता है।
- **तीन बड़े जवाब:** Accepted `2...dxc4`; Declined `2...e6`; Slav `2...c6`। Semi-Slav तब जब Black ...e6 और ...c6 दोनों रखे।
- **आम branches:** QGD Orthodox, Lasker, Tartakower, Cambridge Springs, Exchange, Ragozin; Slav main/Exchange; Semi-Slav Meran, Botvinnik, Moscow/Anti-Moscow; Tarrasch `...c5`; Chigorin `...Nc6`; Albin Countergambit `...e5`; Baltic `...Bf5`।
- **खेल में cue:** White का c-pawn d5 को चुनौती दे रहा है। Black c-pawn ले भी ले, तो भी यह जरूरी नहीं कि pawn स्थायी रूप से जीता रहे—White उसे अक्सर वापस ले सकता है; “gambit” नाम को स्थायी material loss न मानें। [8](https://www.chess.com/openings/Queens-Gambit)

### Slav और Semi-Slav
- **Slav पहचान:** `1.d4 d5 2.c4 c6`। `...c6` d5 को support करता है और c8 bishop को pawn-chain के बाहर आने देता है।
- **Semi-Slav पहचान:** Queen’s Gambit के बाद ...e6 के साथ ...c6; मजबूत centre लेकिन c8 bishop अस्थायी रूप से बन्द।
- **आम branches:** Slav Accepted, Exchange, Main; Semi-Slav Meran/Botvinnik/Moscow/Anti-Moscow।
- **खेल में cue:** Black d5 को दो pawns से संभाल रहा है या c-pawn exchange करके bishop को सक्रिय कर रहा है।

### Tarrasch Defence
- **पहचान:** Queen’s Gambit में Black जल्दी `...c5` खेलता है, जैसे `1.d4 d5 2.c4 e6 3.Nc3 c5`।
- **मकसद/आकार:** White के centre को चुनौती और pieces की सक्रियता; बदले में Black को isolated queen’s pawn (IQP) मिल सकता है।
- **आम शाखाएँ:** Tarrasch और Semi-Tarrasch move-orders।
- **खेल में cue:** central pawn tension जल्दी खुलती है; isolated d-pawn कमजोरी भी हो सकता है और activity का स्रोत भी।

### Queen’s-pawn systems: London, Colle, Torre, Trompowsky, Veresov
- **London System पहचान:** `d4, Bf4, e3, Nf3, c3` जैसी रचना; bishop को pawn-chain के बाहर निकालकर एक repeatable setup। Jobava-London में प्रायः Nc3 भी जल्दी आता है।
- **Colle पहचान:** `d4, Nf3, e3, Bd3, Nbd2`; तैयार होने पर `e4` break। Colle–Zukertort में b3/Bb2 setup अधिक दिखता है।
- **Torre पहचान:** queen’s-pawn setup के साथ `Bg5`, अक्सर Nf6-knight पर pin/pressure।
- **Trompowsky पहचान:** `1.d4 Nf6 2.Bg5`; तुरन्त knight से सवाल और कुछ Indian main-lines से बचने का विकल्प।
- **Veresov/Richter–Veresov पहचान:** `1.d4 d5 2.Nc3 Nf6 3.Bg5`; e4 की तैयारी और pin।
- **Blackmar–Diemer Gambit पहचान:** `1.d4 d5 2.e4 dxe4 3.Nc3`; आगे f3 से pawn वापस देने/विकास के बदले खुली lines।
- **ध्यान:** “system opening” बताता है कि setup अक्सर समान है; इसका मतलब यह नहीं कि opponent के जवाब या pawn breaks को नज़रअंदाज़ किया जा सकता है।

## 1.5 Indian और अन्य 1.d4 defences

### King’s Indian Defence (KID)
- **पहचान:** Black `...Nf6, ...g6, ...Bg7, ...d6, ...O-O`; White अक्सर c4/Nc3/e4 खेलता है।
- **मकसद/आकार:** White को centre लेने देना, फिर `...e5`/`...c5` से उस पर हमला; कई structures में Black kingside attack और White queenside/centre play करता है।
- **आम branches:** Classical, Sämisch, Averbakh, Four Pawns Attack, Fianchetto, Makogonov।
- **खेल में cue:** fianchetto bishop g7 से centre देख रहा है; Black के `...e5` के बाद d5 बन्द हो तो दोनों wings पर दौड़ हो सकती है।

### Grünfeld Defence
- **पहचान:** `1.d4 Nf6 2.c4 g6 3.Nc3 d5`।
- **मकसद/आकार:** Black White के pawn centre को तुरन्त चुनौती देता है और long diagonal/central pressure से counterplay लेता है।
- **आम branches:** Exchange, Russian System, Classical, Fianchetto और 3.f3 जैसे sideline setups।
- **खेल में cue:** KID के विपरीत Black ...d5 बहुत जल्दी खेलता है; White के e4/d4 centre पर pieces का दबाव देखें।

### Nimzo-Indian Defence
- **पहचान:** `1.d4 Nf6 2.c4 e6 3.Nc3 Bb4`।
- **मकसद/आकार:** Black knight को pin करके e4 रोकने, c-pawns की कमजोरी बनवाने या centre में दबाव पाने की कोशिश करता है।
- **आम branches:** Rubinstein `4.e3`, Sämisch `4.a3`, Classical/Capablanca `4.Qc2`, Leningrad `4.Bg5`।
- **खेल में cue:** bishop b4 पर Nc3 को pin करता है; White 3.Nf3 खेलकर Nimzo को टाल भी सकता है।

### Queen’s Indian और Bogo-Indian
- **Queen’s Indian पहचान:** `1.d4 Nf6 2.c4 e6 3.Nf3 b6`; bishop b7 से centre पर दूर से नियंत्रण। आम setups `g3`, `a3`, `Nc3` के जवाब में बदलते हैं।
- **Bogo-Indian पहचान:** ...e6 के बाद Black जल्दी `...Bb4+`; check से development/structure पर सवाल।
- **खेल में cue:** Black की b7 diagonal और e4-square का नियंत्रण; सिर्फ space गिनने से position का मूल्य न आँकें।

### Catalan
- **पहचान:** `1.d4 Nf6 2.c4 e6 3.g3`, प्रायः ...d5; bishop g2 लंबी diagonal पर।
- **मकसद/आकार:** दीर्घकालीन c4/d5 पर दबाव और मजबूत development; Black c4 pawn ले सकता है पर उसे रोककर रखना कठिन हो सकता है।
- **आम branches:** Open Catalan (Black ...dxc4) और Closed Catalan (pawn tension कायम)।
- **खेल में cue:** g2 bishop और c4 pawn के बीच खुली diagonal देखें।

### Benoni और Benko/Volga Gambit
- **Modern Benoni पहचान:** `1.d4 Nf6 2.c4 c5 3.d5 e6`; White space लेता है, Black asymmetric queenside/central counterplay खोजता है।
- **आम branches:** Modern, Czech, Old Benoni; Modern में `...exd5` के बाद Black के ...b5/...f5 breaks और White के central/queenside plans।
- **Benko/Volga पहचान:** `1.d4 Nf6 2.c4 c5 3.d5 b5`; Black pawn देकर a/b-files और queenside pressure की दीर्घकालीन compensation चाहता है। Accepted/declined और fianchetto setups आम।
- **खेल में cue:** Benoni में White का d5-space बनाम Black की open lines; Benko में Black का ...b5 pawn offer और a/b-file pressure। Benko का उद्देश्य केवल जल्दी mate नहीं, अक्सर लम्बा positional दबाव है।

### Budapest, Fajarowicz, Blumenfeld और Old Indian
- **Budapest Gambit पहचान:** `1.d4 Nf6 2.c4 e5`; Black pawn offer से White के centre और development को बिगाड़ना चाहता है। Adler में ...Ng4; Fajarowicz में `3.dxe5 Ne4`।
- **Blumenfeld Countergambit पहचान:** d4/c4/e6 के बाद Black ...c5 और ...b5 से queenside pawn देकर centre के विरुद्ध खेलता है।
- **Old Indian पहचान:** प्रायः `...Nf6, ...d6, ...e5`; Black का setup KID से अलग, पर centre break का लक्ष्य मौजूद।
- **खेल में cue:** Budapest में ...e5 से सीधा pawn offer; Blumenfeld में ...b5; Old Indian में compact ...d6/...e5 structure।

### Dutch Defence
- **पहचान:** `1.d4 f5`।
- **मकसद/आकार:** Black e4 पर नियंत्रण और kingside space/attack चाहता है; f-pawn आगे होने से king-side कमजोरियाँ भी बन सकती हैं।
- **आम branches:** Leningrad (fianchetto ...g6/...Bg7), Stonewall (आम तौर पर ...f5/...e6/...d5/...c6), Classical/Ilyin-Zhenevsky। Staunton Gambit `2.e4` White का sharp जवाब।
- **खेल में cue:** e4-square, ...e6 ke baad dark-square holes, और ...c5/...e5 breaks का संतुलन देखें।

## 1.6 Flank openings और आम minor/offbeat systems

### English Opening
- **पहचान:** `1.c4`।
- **मकसद/आकार:** d5-square पर प्रभाव और flexible transposition; White centre को पहले pawn से कब्ज़ा करने के बजाय नियंत्रित कर सकता है।
- **आम branches:** Symmetrical `...c5`, Reversed Sicilian `...e5`, Four Knights, Botvinnik setup, Hedgehog structures।
- **खेल में cue:** c-pawn आगे, पर बाकी position तय करेगी कि यह English है या d4/Indian setup में transposed position।

### Réti और King’s Indian Attack (KIA)
- **Réti पहचान:** `1.Nf3`, अक्सर `2.c4`; centre को दूर से दबाव और move-order flexibility।
- **KIA पहचान:** `Nf3, g3, Bg2, O-O, d3, Nbd2` और बाद में e4; यह कई अलग openings के विरुद्ध इस्तेमाल होने वाला **system** है, एक ही forced opening नहीं।
- **मकसद/आकार:** bishop fianchetto और kingside/central buildup; opponent के pawn centre के अनुसार plans बदलें।
- **खेल में cue:** g2 bishop, d3/e4 pawn setup और Nbd2-f1/h2 जैसी manoeuvres।

### Larsen/Nimzo-Larsen, Bird, Polish/Sokolsky
- **Larsen/Nimzo-Larsen:** `1.b3`; Bb2 से लंबी diagonal और centre पर दूर का दबाव।
- **Bird:** `1.f4`; e5 नियंत्रण और kingside space; From’s Gambit का जवाब `1...e5`।
- **Polish/Sokolsky:** `1.b4`; queenside space और b-file/fianchetto ideas; Black centre को तुरन्त चुनौती दे सकता है।
- **खेल में cue:** किनारे का pawn शुरुआती चाल में आगे; देखिए कि centre पर कौन कब्ज़ा करता है और उस flank pawn से कौन-सी line खुलती है।

### अन्य नाम जिनसे club games में सामना हो सकता है
- **King’s Fianchetto / Benko Opening:** `1.g3` — Bg2 और central control की तैयारी।
- **Grob:** `1.g4` — बहुत offbeat, तेज़ g-pawn expansion; king safety और कमजोर squares की कीमत जाँचें।
- **Van Geet/Dunst:** `1.Nc3` — develop करके e4/d4 सम्भव, लेकिन knight के square पर बाद का pawn plan निर्भर।
- **Saragossa:** `1.c3` — d4 की तैयारी।
- **Mieses:** `1.d3` — शांत development; अक्सर बाद में e4 बनता है।
- **Anderssen:** `1.a3`; **Ware:** `1.a4`; **Clemenz:** `1.h3`; **Desprez/Kádas:** `1.h4`; **Amar:** `1.Nh3`; **Sodium:** `1.Na3`; **Barnes:** `1.f3`; **Van’t Kruijs:** `1.e3`।
- **पहचान/व्यावहारिक बात:** पहली चाल से नाम पहचान सकते हैं, पर minor opening के लिए अक्सर एक universally agreed “main plan” नहीं होता। पहले centre, king safety और opponent की चालों के अनुसार सामान्य chess priorities लागू करें। Dataset में ऐसे नामों का index मिल सकता है, पर नाम की मौजूदगी उसकी strength का प्रमाण नहीं। [1](https://github.com/lichess-org/chess-openings)

---

# 2. Gambits: pawn offer के पीछे कौन-सा बदला?

**Gambit** में एक पक्ष अक्सर pawn (कभी-कभी अधिक material) देकर बदले में tempo, खुले रास्ते, development, centre, initiative या long-term positional compensation चाहता है। “Accepted” का अर्थ offer लिया गया; “declined” का अर्थ नहीं लिया गया। हर gambit मजबूर/साउंड नहीं होता—विशेषकर surprise lines में opponent का सही जवाब तैयारी को बदल सकता है।

**काम के आधार पर मोटे प्रकार:** (1) development/open-lines gambit—Evans, Danish; (2) central-break gambit—Albin, Latvian, Elephant; (3) attack/initiative gambit—King’s, Smith–Morra, Blackmar–Diemer; (4) long-term positional compensation—Benko; (5) countergambit—Black White के gambit या centre को pawn offer से जवाब देता है। ये उपयोगी descriptions हैं, formal/एकमात्र वर्गीकरण नहीं।

## White के आम gambits

- **King’s Gambit:** `1.e4 e5 2.f4` — development, खुले f/e रास्ते और तेज़ हमला; Accepted/Declined/Falkbeer counter.
- **Evans Gambit:** Italian के बाद `4.b4` — bishop को tempo देना और centre में `c3/d4` जल्दी खेलना।
- **Danish Gambit:** `1.e4 e5 2.d4 exd4 3.c3` — तेज़ development और खुले bishops; Black एक या अधिक pawns ले सकता है।
- **Göring/Scotch Gambit:** Scotch में `4.c3`, या `4.Bc4` — material लेने से पहले development/attack को प्राथमिकता।
- **Smith–Morra:** `1.e4 c5 2.d4 cxd4 3.c3` — Sicilian के विरुद्ध development और open c/d-files।
- **Wing Gambit:** `1.e4 c5 2.b4` — c-pawn को flank से चुनौती, open b-file/tempo की उम्मीद।
- **Blackmar–Diemer:** `1.d4 d5 2.e4 dxe4 3.Nc3`, आगे f3 — rapid development, centre और king-side activity।
- **Staunton Gambit:** Dutch `1...f5` के बाद `2.e4` — centre खोलकर Black के kingside setup को चुनौती।
- **From’s Gambit:** Bird `1.f4` के जवाब में `1...e5` — Black initiative और e-file opening के लिए pawn offer कर सकता है।
- **Réti Gambit:** `1.Nf3 d5 2.c4`; Black `...dxc4` ले तो White अक्सर pawn वापस लेने की कोशिश करता है, इसलिए “gambit” नाम हमेशा स्थायी pawn-sacrifice नहीं बताता। `2...d4` से Black space भी ले सकता है। [25](https://www.chess.com/openings/Reti-Opening)
- **Tennison Gambit:** `1.Nf3 d5 2.e4` (या transposed move-order) — centre और development के बदले pawn।
- **Milner–Barry Gambit:** French Advance structure में White का pawn offer — development और kingside/central activity की उम्मीद।
- **Ponziani Countergambit:** `1.e4 e5 2.Nf3 Nc6 3.c3 f5` — White के centre पर तुरन्त counterattack।

## Black के आम gambits/countergambits

- **Marshall Attack (Ruy Lopez):** Closed Ruy setup के बाद ...d5 का pawn offer; विकास और king attack की initiative। यह gambit है, केवल trap नहीं—White को concrete defence चाहिए।
- **Latvian Gambit:** `1.e4 e5 2.Nf3 f5` — e4 पर attack और खुली lines; king safety की कीमत भी देखें।
- **Elephant Gambit:** `1.e4 e5 2.Nf3 d5` — centre पर तुरन्त counterstrike।
- **Albin Countergambit:** `1.d4 d5 2.c4 e5` — White के d-pawn/centre के विरुद्ध activity और passed-pawn ideas।
- **Budapest/Fajarowicz:** `1.d4 Nf6 2.c4 e5`; Fajarowicz में `3.dxe5 Ne4` — development और central disruption।
- **Benko/Volga:** `1.d4 Nf6 2.c4 c5 3.d5 b5` — pawn के बदले a/b-files पर दीर्घकालीन queenside दबाव।
- **Blumenfeld Countergambit:** ...c5 और ...b5 से White के centre को चुनौती; अक्सर material से अधिक central counterplay लक्ष्य।
- **Englund Gambit:** `1.d4 e5` — surprise/trap-oriented counter; White के सही विकास के विरुद्ध Black की स्थिति का मूल्य अलग से जाँचना जरूरी।
- **Schara–Hennig तथा अन्य Queen’s-pawn countergambits:** d4/c4 centre के सामने ...c5/...e5 pawn offers; exact नाम move-order पर निर्भर।

**दो सावधानियाँ:**
1. हर pawn offer को “मुफ्त pawn” न समझें—पहले देखें कि opponent उसे सुरक्षित रख सकता है या नहीं।
2. हर gambit को खराब/अच्छा कहने से पहले resulting position, development, king safety और concrete tactics देखें। Queen’s Gambit का नाम होने पर भी pawn अक्सर वापस लिया जा सकता है। [8](https://www.chess.com/openings/Queens-Gambit)

---

# 3. Strategy और positional concepts

**Strategy** लम्बे समय का plan है; **tactic** छोटा, forcing sequence है। एक अच्छे plan का आधार अक्सर pawn structure होता है; tactical opportunity भी उसी plan से पैदा हो सकती है। [9](https://www.chess.com/terms/chess-strategy)

## 3.1 हर position में देखने योग्य strategic levers

- **Centre:** e4/d4/e5/d5 pawns से कब्ज़ा या दूर से नियंत्रण। सवाल: क्या centre खुला है, बन्द है, या tension में है? किसका development उस बदलाव से लाभ पाएगा?
- **Development और tempo:** undeveloped pieces, repeated moves, queen पर tempo, और king के बीच में रहने का जोखिम गिनें।
- **King safety:** pawn shield, खुली files/diagonals, king के escape squares, और opposite-side castling।
- **Space:** आगे गए pawns opponent के pieces की squares घटाते हैं; बदले में वे target या कमजोर squares भी छोड़ सकते हैं।
- **Piece activity/mobility:** सबसे कम उपयोगी piece कौन-सा है? उसे बेहतर square या open file पर लाने की योजना अक्सर अच्छे move की शुरुआत है।
- **Open/semi-open files:** rooks को ऐसी files पर रखें जहाँ pawn target, entry square या seventh rank तक पहुँच हो।
- **Weak squares / outposts:** ऐसा square जिसे enemy pawn से हटाना कठिन हो, विशेषकर central knight के लिए। पहले pawn structure से तय करें कि square सचमुच टिकाऊ है या नहीं।
- **Good vs bad bishop:** अपने pawns जिस रंग पर हों, उसी रंग का bishop बन्द हो सकता है; पर खुले diagonals, pawn breaks और opponent के targets इसे बदल सकते हैं।
- **Bishop pair:** खुली position में दो bishops की लंबी range उपयोगी हो सकती है; बन्द structure में knight/outpost अधिक असरदार हो सकता है—यह कोई automatic rule नहीं।
- **Pawn break:** ऐसा pawn move जो structure बदलता, line खोलता या defender हटाता है; हर pawn push के बाद यह पूछें कि कौन-सी file/square खुली और कौन-सी कमजोर हुई। [13](https://www.chess.com/terms/pawn-break-chess)
- **Prophylaxis:** opponent की सम्भावित योजना पहले पहचानकर रोकना—पर ऐसा move तभी जब वह वास्तविक खतरे/plan को रोकता हो, सिर्फ डर से tempo न गँवाएँ। [12](https://www.chess.com/terms/prophylaxis-chess)
- **Exchange strategy:** exchange से किसकी अच्छी piece, defender या useful pawn structure हटेगा? “अधिक pieces trade = बेहतर” सार्वभौमिक नियम नहीं।
- **Initiative / counterplay:** लगातार threats देने से कभी material की कमी की भरपाई होती है; हमला रुकने पर compensation खत्म तो नहीं हो रही, जाँचें।
- **Blockade:** passed pawn या space advantage को आगे बढ़ने से रोकने के लिए piece को उसके आगे टिकाना; blockade square पर piece सुरक्षित है या नहीं, देखें।

## 3.2 पहचानने योग्य pawn structures और उनके plans

- **Isolated Queen’s Pawn (IQP):** d-pawn को बगल के c/e pawns सहारा नहीं देते। IQP वाला पक्ष activity, e5/c5 squares और pawn advance से खेलता है; opponent exchanges और blockading से target बना सकता है। IQP हमेशा कमजोरी नहीं—pieces सक्रिय हों तो ताकत भी है।
- **Hanging pawns:** पास-पास c/d pawns को अपने pawns का सहारा नहीं। इनके पक्ष को अक्सर activity और सही समय का advance चाहिए; विरोधी blockade और exchanges से दबाव बना सकता है। [17](https://www.chess.com/terms/hanging-pawns-chess)
- **Doubled pawns:** एक ही file में दो अपने pawns। कमजोरियाँ (कम pawn protection, targets) और फायदे (open file, centre control) दोनों सम्भव।
- **Backward pawn:** आगे बढ़ना कठिन, और पीछे का square कमजोर। उसे सामने से block करना/उस पर file pressure डालना आम plan।
- **Pawn chain:** pawns diagonal रूप से एक-दूसरे को सहारा देते हैं। अक्सर chain के base पर हमला या दूसरी तरफ counterbreak; chain की दिशा से संभावित attack-wing का संकेत मिल सकता है।
- **Passed pawn:** आगे की files पर opponent pawn उसे रोक/ले नहीं सकता। उसे king/rook support दें; opponent block करके king या rook से पीछे से हमला कर सकता है।
- **Carlsbad structure:** Queen’s Gambit Exchange आदि से बनने वाली संरचना। White की आम योजना minority attack (`b4-b5`) से c-pawn कमजोर बनाना; दूसरी योजना e4 central break। Black counterplay/king-side play खोजता है। [14](https://www.chess.com/terms/carlsbad-pawn-structure-chess) [15](https://www.chess.com/terms/minority-attack-chess)
- **Maróczy Bind:** अक्सर White pawns c4/e4; Black के ...d5 और ...b5 breaks को रोककर space/कसाव। Black को piece manoeuvre और सही break ढूँढना होता है; सिर्फ बंद रहने से structure अपने आप जीतता नहीं। [16](https://www.chess.com/terms/maroczy-bind)
- **Hedgehog:** Black compact pawns रखकर c/d-files पर जगह छोड़ता है और ...b5/...d5/...e5 जैसे breaks के लिए तैयार रहता है। White space में overextend हो तो Black counterstrike कर सकता है।
- **French pawn chain:** White e5-d4 chain; ...c5 से base d4 पर हमला और कभी ...f6 से head e5 पर प्रहार। White kingside space/attack या centre को स्थिर कर सकता है।
- **Benoni structure:** White d5 से space, Black queenside/c-file pressure और pawn breaks; किस side के pieces सक्रिय हैं, उससे plan तय करें।
- **Dutch Stonewall:** Black के ...f5/...e6/...d5/...c6 ढाँचे से e4 नियंत्रण; बदले में c8-bishop और कुछ dark squares कमजोर हो सकते हैं।
- **Majority/minority:** wing पर pawns की संख्या गिनें। Majority passed pawn बना सकती है; minority attack opponent chain में कमजोर pawn उत्पन्न करने का प्रयास। दोनों plans concrete structure पर निर्भर।

**Recognition habit:** pieces से पहले pawns को देखकर “कौन-सा pawn break position बदलेगा?” पूछें। Structure-आधारित plans, जैसे Carlsbad minority attack या Maroczy bind, opening name से अलग positions में भी आ सकते हैं। [14](https://www.chess.com/terms/carlsbad-pawn-structure-chess) [16](https://www.chess.com/terms/maroczy-bind)

---

# 4. Tactics और tactical motifs

हर motif को **संभावना** की तरह पहचानें, फिर opponent की best reply सहित calculate करें। Lichess के puzzle themes में fork, pin, skewer, discovered attack/check, overload, zwischenzug, x-ray, interference, clearance, attraction, deflection, underpromotion, desperado और defensive move जैसे groups अलग पहचाने जाते हैं। [10](https://lichess.org/training/themes) [11](https://lichess.org/practice)

## 4.1 मुख्य tactical motifs

- **Fork / double attack:** एक move से एक piece दो या अधिक targets पर हमला करे—king + queen/rook का knight fork आम संकेत। देखें कि check देकर tempo मिलता है या नहीं।
- **Pin:** line-piece (bishop/rook/queen) किसी piece पर हमला करे; उसके पीछे king या अधिक मूल्यवान target हो। Absolute pin में king उजागर होने से pinned piece हट नहीं सकता; relative pin में हट सकता है पर नुकसान हो सकता है।
- **Skewer:** बड़ी value वाले piece पर line attack; वह हटे तो पीछे का piece/target गिरता है—pin का उल्टा क्रम।
- **Discovered attack:** blocker हटे और पीछे का rook/bishop/queen हमला खोले। अगर नया हमला king पर है तो discovered check।
- **Double check:** move करने वाला piece और खुली line वाला piece दोनों check दें; आम तौर पर king को move करना पड़ता है।
- **X-ray:** किसी line-piece का प्रभाव बीच के piece के पार latent रूप में रहे; बीच का piece exchange/हटे तो पीछे का target मिलता है।
- **Battery:** दो line-pieces एक file/rank/diagonal पर align—जैसे queen+bishop; अगली exchange या pawn move से दबाव बढ़ सकता है।
- **Remove the defender / undermining:** किसी target का रक्षक capture या exchange करके हटाना। पहले गिनें कि defender और क्या-क्या बचा रहा है।
- **Deflection:** रक्षक को उसकी अहम duty/square से हटने पर मजबूर करना; फिर कमजोर target पर वार।
- **Decoy / attraction:** opponent piece को खराब square पर बुलाना/खींचना ताकि अगली tactic सम्भव हो। Deflection से मिलता-जुलता, पर जोर lure पर है।
- **Overload:** एक defender पर कई duties हों; उसे एक target बचाने को मजबूर कर दूसरा छोड़ना।
- **Interference / obstruction:** दो enemy pieces के बीच की line काटने के लिए बीच में piece डालना; एक piece दूसरे को support न कर पाए।
- **Clearance:** अपनी piece को हटाकर square/file/diagonal खाली करना, ताकि दूसरी piece हमला कर सके; कभी tempo के साथ।
- **Zwischenzug / intermezzo:** अपेक्षित recapture से पहले बीच की forcing move—check, attack या threat—जो material/tempo का हिसाब बदल दे।
- **Trapped piece:** opponent piece के escape squares कम; उससे पहले exits रोकें, फिर हमला करें। सिर्फ उस पर हमला करना पर्याप्त नहीं, escape route भी गिनें।
- **Loose/hanging piece:** undefended या पर्याप्त सुरक्षा से कम piece। हर move के बाद देखें कि कोई piece “en prise” तो नहीं, और defender pin/overload से बँधा तो नहीं।
- **Desperado:** पकड़े जाने वाली piece capture/check देकर अधिकतम नुकसान कराए या exchange order बदले।
- **Sacrifice:** material देकर mate, forced win, promotion, attack या positional gain लेना। Sacrifice तभी सफल है जब follow-up/compensation concrete हो।
- **Underpromotion:** pawn को queen के बजाय rook/bishop/knight बनाना—अक्सर knight check, stalemate से बचाव, या rook-pawn endgame के कारण।
- **Promotion race / breakthrough:** दोनों passed pawns दौड़ रहे हों; check, tempo, capture sequence और promotion square की सुरक्षा calculate करें।
- **Perpetual check:** लगातार checks से draw/repetition मजबूर करना; हारती position बचाने का resource हो सकता है।
- **Stalemate resource:** king check में नहीं पर कोई legal move न बचे तो draw; material पीछे हो तो opponent को stalemate देने की tactic खोजें।
- **Zugzwang:** उपलब्ध legal move ही position खराब करे; pawn/king endgames और manoeuvring positions में अक्सर।
- **Windmill:** discovered-check जैसी व्यवस्था में बार-बार check और साथ में pieces लेना; uncommon, पर king के सीमित escape squares और खुली lines इसका संकेत।

## 4.2 आम mating/attack patterns

- **Back-rank mate:** king अपने pawns के पीछे फँसा, escape-square नहीं; rook/queen आख़िरी rank पर आती है। संकेत: luft नहीं और defender हटा/व्यस्त है।
- **Smothered mate:** king अपने pieces/pawns से घिरा; knight checkmate देता है। पहले escape squares की गिनती करें।
- **Arabian mate:** किनारे/कोने के पास rook और knight मिलकर king के escape squares सीमित करते हैं।
- **Anastasia’s mate:** board-edge के पास rook/queen file या rank पर हमला करे, knight escape squares रोके।
- **Boden’s mate:** दो bishops की cross-diagonals और अपने pieces से फँसा king; diagonal alignment देखिए।
- **Scholar’s/Fool’s mate:** शुरुआती queen+bishop/f7-f2 या शुरुआती king-safety गलती पर आधारित basic patterns; इन्हें pattern सीखने के लिए जानें, हर game में force करने की योजना न बनाएँ।
- **Greek Gift (Bxh7+ / Bxh2+):** bishop sacrifice से king को बाहर खींचकर queen/knight attack लाने का pattern। यह “bishop दो और mate पक्का” नहीं—escape squares, attacking pieces, defenders और checks की पूरी line पहले calculate करें।

**हर tactic की validation:** forcing move चुनें → opponent के check/capture/escape/interposition को देखें → line के अंत में material, king safety और promotion स्थिति फिर गिनें। केवल motif दिखना जीत का प्रमाण नहीं।

---

# 5. Attacking patterns: attack कब और कहाँ बनता है?

1. **Uncastled king / centre में king:** central files खुलने से पहले development advantage हो तो checks और line-opening breaks खोजें। कभी pawn लेने से ज्यादा जल्दी pieces लाना उपयोगी होता है।
2. **f2/f7 focal point:** शुरुआत में king से बचा हुआ pawn; bishop/queen/knight का coordination और king की actual protection देखें। “कमज़ोर square” कहना अकेला tactic नहीं।
3. **Battery:** queen+bishop या rooks को king की दिशा में align करना; बीच के blocker को हटाने की योजना साथ रखें।
4. **Open-file attack:** rook/queen को open या semi-open file पर लाकर 7th rank, king या कमजोर pawn पर pressure। File खुलने से पहले उस पर अपना rook किस tempo से पहुँचेगा, देखें।
5. **Rook lift:** rook को तीसरी/चौथी rank पर लाकर sideways attack में शामिल करना—उदाहरणतः f-file से kingside। संकेत: rook के रास्ते में pawns/pieces हट चुके हैं और लक्ष्य के पास defenders कम।
6. **Opposite-side castling + pawn storm:** दोनों kings अलग wings पर हों तो flank pawns आगे बढ़ाकर lines खोलना आम plan है; पर अपने king की तरफ खुली file भी opponent के लिए खतरा। Pawn storm सिर्फ तब जब centre सुरक्षित/बंद हो या हमला पहले पहुँचे।
7. **Central break से king attack:** king centre में हो तो `d4/e4` या `...d5/...e5` से lines खुल सकती हैं। Break के बाद किसकी pieces तैयार हैं, यह असली सवाल है।
8. **Greek Gift / king exposure:** bishop sacrifice के बाद queen/knight/rook कितनी जल्दी जुड़ते हैं, escape squares कौन रोकता है—सारी forcing line गिनें।
9. **Kingside vs queenside attack:** pawn structure, king location और open files देखकर तय करें; opening के नाम से “हमेशा यहाँ हमला” तय न करें।
10. **Minority attack:** यह सामान्यतः positional pawn attack है, तुरन्त king attack नहीं; कम pawns से opponent pawn chain में weakness बनाना इसका उद्देश्य। Carlsbad structure में b-pawns की advance इसका जाना-पहचाना रूप है। [14](https://www.chess.com/terms/carlsbad-pawn-structure-chess) [15](https://www.chess.com/terms/minority-attack-chess)

---

# 6. Defensive techniques: हमला रोकने के practical साधन

रक्षा में सिर्फ pieces को target पर टिकाए रखना काफी नहीं। पहले opponent का **सबसे forcing threat** पहचानें, फिर ऐसा जवाब चुनें जो king safety और counterplay दोनों बचाए। Prophylaxis का अर्थ opponent की सम्भावित योजना समय से रोकना है। [12](https://www.chess.com/terms/prophylaxis-chess) [20](https://www.chess.com/terms/chess-defense)

- **Checks, captures, threats की जाँच:** opponent की पिछली चाल ने क्या नया हमला बनाया? अगली चाल पर mate/queen/piece का खतरा क्या है?
- **Attacker हटाएँ:** सबसे सक्रिय attacking piece को exchange/capture करें; खासकर queen/knight/bishop जो king के पास आ चुका हो। पर exchange से position खराब तो नहीं, जाँचें।
- **Target को मजबूत करें:** अतिरिक्त defender, king/rook support, या pawn cover जोड़ें; defenders की संख्या के साथ उनकी pin/overload भी देखें।
- **Line block/interpose:** bishop/rook/queen attack के बीच piece रखकर file/diagonal काटें; interposition के बाद वह piece खुद hanging तो नहीं?
- **King के escape squares बनाएं (luft):** उपयुक्त h3/h6 या अन्य pawn move back-rank mate रोक सकता है; लेकिन king shelter न खोलें और tempo की कीमत आँकें।
- **King reposition/castle:** king को सुरक्षित square पर ले जाएँ, castling rights/route legal और सुरक्षित हों तभी।
- **हमलावर की supply काटें:** central break रोकें, open file बन्द करें, attacking bishop/knight का outpost छीनें, या key square पर prophylaxis करें।
- **Material लौटाएँ:** extra pawn/piece रखने से mate का खतरा हो तो material वापस देकर attack घटाना कभी सबसे सही रक्षा हो सकती है।
- **Counterattack:** opponent की king/queen/loose piece पर तुरन्त threat बनाकर उसे defence में लगाएँ—पर अपने king का forced mate नज़रअंदाज़ न करें।
- **Queen trade / repetition / perpetual:** जब सुरक्षित हो, attacker की queen exchange, forced repetition या perpetual check से बराबरी/ड्रॉ बचाएँ।
- **Blockade / fortress:** passed pawn रोकें या ऐसा defensive setup रखें जहाँ opponent प्रगति न कर सके। Fortress का दावा तभी करें जब वह concrete sequence के विरुद्ध टिके।
- **Stalemate resource:** हारती position में legal moves कम करना कभी draw दे सकता है; अपने king को अनावश्यक check में न डालें और opponent की stalemate possibilities भी देखें।
- **Defensive sacrifice / counter-check:** check के जवाब में counter-check, attacker को exchange देना, या मजबूर sacrifice से attack की धार घटाना सम्भव। इसे line-by-line जाँचें।

**Recognition cue:** अगर हर defensive piece एक ही critical square/king को बचा रहा है, तो overload, deflection, interference या defender removal की tactic दोनों पक्षों के लिए तलाशें।

---

# 7. Endgame strategy और पहचानने योग्य patterns

Endgame में king स्वयं सक्रिय piece बन जाता है। लेकिन “king को centre में लाओ” से पहले checks, passed pawns और tactical threats देखें। Lichess अभ्यास सामग्री pawn endgames में key squares/opposition और rook endgames में Lucena/Philidor positions को अलग सिखाती है। [11](https://lichess.org/practice)

## 7.1 सामान्य endgame priorities

- **King activity:** king को centre/passed pawn की ओर लाएँ; checks/queen promotion की tactical safety जाँचें।
- **Passed pawn:** अपना passer बनाना, उसे आगे बढ़ाने का सही समय, king/rook से escort; opponent के passer को block/capture।
- **Rook activity:** rook को passive pawn-guard पर न बाँधें यदि वह पीछे से checking/entry कर सकता है; passed pawn के पीछे rook एक सामान्य सिद्धान्त है।
- **Trade की गणना:** material आगे हो तो pieces trade करना मदद कर सकता है, पर pawn endings के परिणाम अलग से calculate करें; हर exchange जीत को आसान नहीं करता।
- **Opposite-coloured bishops:** कुछ positions में drawing chances बढ़ सकते हैं, खासकर कम pawns/एक तरफ कमजोरियाँ हों; यह स्वतः draw नहीं।
- **Fortress/perpetual/stalemate:** practical draw resources की तलाश करें; material count अकेला परिणाम तय नहीं करता।

## 7.2 Pawn endings

- **Opposition:** kings आमने-सामने हों और बीच में तय दूरी; सही side opposition लेकर key squares में प्रवेश रोक/खोल सकती है। पहले move order और pawn race calculate करें।
- **Key squares:** pawn की promotion से जुड़ी squares; king उन तक पहुँचे तो pawn promote हो सकता है (opponent king/piece की स्थिति भी देखें)।
- **Square rule:** दूर भागते passed pawn को king पकड़ सकता है या नहीं, यह जल्दी आँकने का तरीका; checks, blockers, en passant और चाल किसकी है, उसे जोड़कर calculate करें।
- **Triangulation:** king तीन चालों में वही क्षेत्र वापस पहुँचता है पर opponent को move करने पर मजबूर कर tempo बदलता है।
- **Outflanking/shouldering:** opponent king को एक तरफ धकेलकर अपने king के लिए रास्ता बनाना।
- **Reserve tempo:** ऐसा pawn move बचाकर रखना जिससे बाद में opposition/zugzwang जीता जा सके।
- **Pawn breakthrough:** connected pawns की sacrifice/advance sequence से passer बनाना; पहले opponent के king/pawns की capture line गिनें।
- **Recognition cue:** kings, passed pawns, opposition, key squares और “जिसकी चाल” — ये पाँच चीजें पहले देखें।

## 7.3 Rook endings

- **Active rook:** passive pawn की रक्षा से ज्यादा सक्रिय checks/side attack उपयोगी हो सकते हैं।
- **Rook behind the passer:** अपना या opponent का passed pawn—rook को उसके पीछे रखने से support या रोकने की दूरी मिलती है।
- **King cut-off:** rook से opponent king को file/rank पर काटना; passer के आगे बढ़ने के लिए king को दूर रखें।
- **Side checks:** कमज़ोर king को पीछे से/किनारे से check देना और pawn को आगे न बढ़ने देना—drawing resource।
- **Lucena position:** rook+pawn vs rook की सामान्य winning setup; rook “bridge” बनाकर checks से बचते हुए pawn promote करता है।
- **Philidor position:** rook+pawn vs rook में सामान्य drawing setup; defender तीसरी rank पर रोककर सही समय पर पीछे से check करता है।
- **Vancura-type defence:** rook-pawn के विरुद्ध side checks और king/pawn coordination का draw idea; exact conditions देखना जरूरी।
- **Recognition cue:** king कहाँ है, rook किस file/rank पर है, pawn किस rank पर है, और rook side-check दे सकता है या नहीं—पहले यही गिनें।

## 7.4 Minor-piece, queen और basic mating endings

- **Bishop vs knight:** खुले position/दो wings पर bishop की range; बन्द structure/स्थिर outpost पर knight अधिक अच्छा हो सकता है। Pawn structure और targets फैसला करते हैं।
- **Opposite-coloured bishops:** attack में हर side अलग colour squares पर दबाव बना सकती है; कम material में draw chances बढ़ सकते हैं, पर attack/extra passed pawn हो तो जीत सम्भव।
- **Wrong-coloured bishop + rook pawn:** bishop promotion square के विपरीत रंग का हो और defending king सही corner पहुँचे, तो pawn queen न बन पाए; इसे practical draw check के रूप में पहचानें।
- **Knight endgame:** king activity, outpost और passed pawn अक्सर निर्णायक; knight दूर के दोनों wings पर bishop जितना तेज़ नहीं पहुँच सकता।
- **Queen ending:** king को checks से बचाएँ; perpetual checks, checks की दिशा, pawn shelter और passed pawns की गति calculate करें।
- **Basic mates:** K+Q vs K और K+R vs K में king को edge/corner की ओर धकेलना; K+B+N mate में bishop/knight coordination और सही corner की तकनीक अभ्यास करें। Lichess अभ्यास में basic piece mates और mating-pattern modules उपलब्ध हैं। [11](https://lichess.org/practice)

---

# 8. खेल के बीच पहचानने की checklist

## हर चाल से पहले 30-सेकंड scan

1. **Opponent की पिछली चाल ने क्या बदला?** कौन-सी line खुली/बन्द हुई; किस piece ने किस target पर नया हमला बनाया?
2. **मेरे forcing candidates:** Checks → Captures → Threats. इनमें से कौन-सी चाल opponent को सबसे सीमित जवाब देती है?
3. **Opponent के forcing replies:** मेरी candidate के बाद उसके checks, captures, forks या mate-threat क्या हैं?
4. **Loose pieces:** कौन-सी piece undefended/कम-defended है? क्या defender pinned, overloaded या हटाई जा सकती है?
5. **Alignment:** king-queen-rook/bishop एक file/diagonal पर तो नहीं? कोई knight fork square, pin, skewer या discovered attack सम्भव?
6. **King safety:** escape squares, back-rank, open files/diagonals, attackers बनाम defenders।
7. **Strategic plan:** pawn structure में अगला break क्या है? मेरी worst piece कहाँ सुधरेगी? opponent का plan किस move से रोका जा सकता है?
8. **Endgame check (यदि queens/pieces घट रहे हों):** king activity, passed pawns, opposition, rook activity, drawing fortress।
9. **Line verify:** चुनी हुई चाल के बाद कम-से-कम opponent का सबसे forcing practical reply calculate करें; motif नाम से move को सही न मानें।

## Opening को खेल के दौरान पहचानना

- पहले **defining move** पकड़ें (जैसे ...c5 = Sicilian family; 3.Bb5 = Ruy Lopez; 3.Bc4 = Italian), लेकिन बाद के transposition को अनुमति दें।
- फिर **pawn skeleton** देखें—e4/e5, d4/d5, c4/c5, chain/isolated pawn—और pieces कहाँ विकसित हैं।
- यदि opening label स्पष्ट न हो, तो नाम जबरन न दें; “Sicilian-जैसी structure”, “IQP position”, “opposite-side castling” जैसे position labels ज्यादा उपयोगी हो सकते हैं।
- Opening explorer/name lookup को move-order index की तरह लें, move की गुणवत्ता के निर्णायक के रूप में नहीं। Lichess dataset में भी transpositions के लिए कई entries का उल्लेख है। [1](https://github.com/lichess-org/chess-openings)

---

# 9. भविष्य के Chess Game Master specification के लिए सुझाव

1. **Opening labels को hierarchical रखें:** family → variation → subvariation; confidence और defining move sequence अलग दिखाएँ। Unknown/unclear label देना गलत नाम से बेहतर है।
2. **Opening recognition और chess advice अलग रखें:** नाम move-history से; plan/pattern वर्तमान board structure और side-to-move से।
3. **Tactic suggestion को “candidate motif” कहें, निष्कर्ष नहीं:** उदाहरण “यहाँ pin/fork सम्भव है—line देखें”; engine/analysis validation के बाद ही “जीतता है” जैसी भाषा।
4. **Plan tags में दोनों sides शामिल हों:** `White: minority attack`, `Black: ...c5 break`, `defensive: remove attacker`—एकतरफा coaching से बचें।
5. **Endgame material count के साथ theoretical pattern पहचानें:** opposition, Lucena/Philidor, rook behind passer, fortress, stalemate; पर exact position verification जरूरी।
6. **Minor openings को surprise/rare label दें, quality score नहीं:** opening-name index की मौजूदगी को “साउंड” या “श्रेष्ठ” का प्रमाण न मानें।
7. **Training sets को theme के अनुसार बाँटें:** fork/pin/discovery, defence, king attack, pawn endings, rook endings; Lichess puzzle/practice taxonomy उपयोगी public reference है। [10](https://lichess.org/training/themes) [11](https://lichess.org/practice)

---

# स्रोत और आगे पढ़ने के links

नीचे के references taxonomy और motifs की जाँच के लिए चुने गए हैं। Chess.com/Lichess के learning pages उपयोगी शिक्षण स्रोत हैं; opening names/move-order के लिए dataset/explorer अधिक उपयुक्त है। किसी भी एक source की branch naming को अकेला आधिकारिक chess-law न समझें।

1. Lichess, **Chess opening names dataset** — ECO, name, PGN/UCI/position fields, naming/transposition conventions और CC0 जानकारी: https://github.com/lichess-org/chess-openings
2. Lichess, **Opening tree / opening explorer**: https://lichess.org/opening/tree
3. Chess.com, **Openings index**: https://www.chess.com/openings
4. Chess.com, **Ruy Lopez**: https://www.chess.com/openings/Ruy-Lopez
5. Chess.com, **Italian Game**: https://www.chess.com/openings/Italian-Game
6. Chess.com, **Sicilian Defence**: https://www.chess.com/openings/Sicilian-Defense
7. Chess.com, **French Defence**: https://www.chess.com/openings/French-Defense
8. Chess.com, **Queen’s Gambit**: https://www.chess.com/openings/Queens-Gambit
9. Chess.com, **Strategy concepts**: https://www.chess.com/terms/chess-strategy
10. Lichess, **Puzzle themes** (fork, pin, discovered attack, king attack, defensive move, advanced motifs): https://lichess.org/training/themes
11. Lichess, **Practice** (checkmates, tactics, opposition, key squares, Lucena/Philidor): https://lichess.org/practice
12. Chess.com, **Prophylaxis**: https://www.chess.com/terms/prophylaxis-chess
13. Chess.com, **Pawn breaks**: https://www.chess.com/terms/pawn-break-chess
14. Chess.com, **Carlsbad structure**: https://www.chess.com/terms/carlsbad-pawn-structure-chess
15. Chess.com, **Minority attack**: https://www.chess.com/terms/minority-attack-chess
16. Chess.com, **Maróczy Bind**: https://www.chess.com/terms/maroczy-bind
17. Chess.com, **Hanging pawns**: https://www.chess.com/terms/hanging-pawns-chess
18. Chess.com, **Chess tactics glossary**: https://www.chess.com/terms/chess-tactics
19. Chess.com, **Checkmate patterns**: https://www.chess.com/terms/checkmate-chess
20. Chess.com, **Chess defence**: https://www.chess.com/terms/chess-defense
21. Chess.com, **Lucena position**: https://www.chess.com/terms/lucena-position-chess
22. Chess.com, **Philidor position**: https://www.chess.com/terms/philidor-position-chess
23. Chess.com, **Opposition**: https://www.chess.com/terms/opposition-chess
24. Chess.com, **Fortress**: https://www.chess.com/terms/chess-fortress
25. Chess.com, **Réti Opening / Réti Gambit**: https://www.chess.com/openings/Reti-Opening

---

## एक-पंक्ति सार

**Opening को move-order और pawn structure से पहचानें; strategy को plan/structure से; tactic को forcing calculation से; defence को opponent के सबसे खतरनाक idea से; और endgame को king activity तथा pawn promotion की दौड़ से।**