import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/testing/setup.ts'],
    restoreMocks: true,
    clearMocks: true,
    coverage: {
      reporter: ['text', 'html'],
      include: ['src/domain/**/*.ts', 'src/knowledge/**/*.ts', 'src/engine/**/*.ts'],
      exclude: ['src/testing/**'],
    },
  },
});
