import { describe, expect, it, vi } from 'vitest';
import serviceWorkerSource from '../../public/sw.js?raw';

type FakeResponse = { ok: boolean; body: string; text: () => Promise<string>; clone: () => FakeResponse };
type WorkerEvent = { data?: { type?: string }; request?: { method: string; url: string; mode?: string }; waitUntil?: (promise: Promise<unknown>) => void; respondWith?: (promise: Promise<unknown>) => void };
type WorkerHandler = (event: WorkerEvent) => void;

function makeResponse(body: string, ok = true): FakeResponse {
  return { ok, body, text: async () => body, clone() { return makeResponse(body, ok); } };
}

function makeHarness() {
  const handlers = new Map<string, WorkerHandler>();
  const entries = new Map<string, Map<string, FakeResponse>>();
  const cache = {
    addAll: vi.fn(async (urls: string[]) => {
      const store = entries.get('chess-game-master-v3-shell')!;
      for (const url of urls) store.set(url, makeResponse(url === '/' ? '<html><script src="/assets/main.js"></script><link href="/assets/main.css"></html>' : `precache:${url}`));
    }),
    add: vi.fn(async (url: string) => { entries.get('chess-game-master-v3-shell')!.set(url, makeResponse(`asset:${url}`)); }),
    match: vi.fn(async (request: string | { url: string }, _options?: { ignoreVary?: boolean }) => {
      const key = typeof request === 'string' ? request : new URL(request.url).pathname;
      return entries.get('chess-game-master-v3-shell')?.get(key);
    }),
    put: vi.fn(async (request: string | { url: string }, response: FakeResponse) => {
      const key = typeof request === 'string' ? request : new URL(request.url).pathname;
      entries.get('chess-game-master-v3-shell')!.set(key, response);
    }),
  };
  const caches = {
    open: vi.fn(async (name: string) => {
      if (!entries.has(name)) entries.set(name, new Map());
      return cache;
    }),
    keys: vi.fn(async () => [...entries.keys()]),
    delete: vi.fn(async (name: string) => entries.delete(name)),
    match: vi.fn(async (request: string) => {
      for (const current of entries.values()) if (current.has(request)) return current.get(request);
      return undefined;
    }),
  };
  const self = {
    location: { origin: 'https://chess.test' },
    addEventListener: (type: string, handler: WorkerHandler) => handlers.set(type, handler),
    skipWaiting: vi.fn(async () => undefined),
    clients: { claim: vi.fn(async () => undefined) },
  };
  const fetch = vi.fn(async () => makeResponse('network'));
  new Function('self', 'caches', 'fetch', 'URL', 'Response', 'console', serviceWorkerSource)(self, caches, fetch, URL, { error: () => ({ error: true }) }, console);
  return { handlers, entries, cache, caches, self, fetch };
}

describe('service-worker production policy', () => {
  it('precaches the shell but waits for explicit user approval before activation', async () => {
    const worker = makeHarness();
    let installPromise: Promise<unknown> | undefined;
    worker.handlers.get('install')!({ waitUntil: (promise) => { installPromise = promise; } });
    await installPromise;
    expect(worker.cache.addAll).toHaveBeenCalledWith(expect.arrayContaining(['/','/manifest.webmanifest','/data/openings/a.tsv']));
    expect(worker.cache.add).toHaveBeenCalledWith('/assets/main.js');
    expect(worker.self.skipWaiting).not.toHaveBeenCalled();

    let activationPromise: Promise<unknown> | undefined;
    worker.handlers.get('message')!({ data: { type: 'ACTIVATE_UPDATE' }, waitUntil: (promise) => { activationPromise = promise; } });
    await activationPromise;
    expect(worker.self.skipWaiting).toHaveBeenCalledTimes(1);
  });

  it('cleans old app caches only during activation and claims the installed shell', async () => {
    const worker = makeHarness();
    worker.entries.set('chess-game-master-v1-shell', new Map());
    worker.entries.set('unrelated-cache', new Map());
    let activationPromise: Promise<unknown> | undefined;
    worker.handlers.get('activate')!({ waitUntil: (promise) => { activationPromise = promise; } });
    await activationPromise;
    expect(worker.caches.delete).toHaveBeenCalledWith('chess-game-master-v1-shell');
    expect(worker.caches.delete).not.toHaveBeenCalledWith('unrelated-cache');
    expect(worker.self.clients.claim).toHaveBeenCalledOnce();
  });

  it('serves cached same-origin modules despite Vary: Origin differences', async () => {
    const worker = makeHarness();
    const cachedModule = makeResponse('cached module');
    worker.entries.set('chess-game-master-v3-shell', new Map([['/assets/main.js', cachedModule]]));
    let response: Promise<unknown> | undefined;
    const request = { method: 'GET', url: 'https://chess.test/assets/main.js', mode: 'cors' };
    worker.handlers.get('fetch')!({ request, respondWith: (promise) => { response = promise; } });
    expect(await response).toBe(cachedModule);
    expect(worker.cache.match).toHaveBeenCalledWith(request, { ignoreVary: true });
    expect(worker.fetch).not.toHaveBeenCalled();
  });

  it('serves a cached document when navigation is offline and ignores cross-origin requests', async () => {
    const worker = makeHarness();
    const cache = new Map<string, FakeResponse>();
    const shell = makeResponse('<html>cached offline shell</html>');
    cache.set('/', shell);
    worker.entries.set('chess-game-master-v3-shell', cache);
    worker.fetch.mockRejectedValue(new Error('offline'));
    let navigationResponse: Promise<unknown> | undefined;
    worker.handlers.get('fetch')!({
      request: { method: 'GET', url: 'https://chess.test/review', mode: 'navigate' },
      respondWith: (promise) => { navigationResponse = promise; },
    });
    expect(await navigationResponse).toBe(shell);

    let intercepted = false;
    worker.handlers.get('fetch')!({
      request: { method: 'GET', url: 'https://third-party.test/image.png', mode: 'no-cors' },
      respondWith: () => { intercepted = true; },
    });
    expect(intercepted).toBe(false);
  });
});
