import { Chess, type Square } from 'chess.js';
import { parseUci } from '../domain/chess/position';

export type LessonGoal =
  | { kind: 'specific-move'; uci: string }
  | { kind: 'resolve-check' }
  | { kind: 'promote'; from: Square; to: Square }
  | { kind: 'same-file-move'; from: Square; file: string };

export type Lesson = {
  id: string;
  version: 1;
  category: 'rules' | 'tactics' | 'strategy' | 'openings' | 'endgames';
  title: string;
  objective: string;
  fen: string;
  goal: LessonGoal;
  /** Four-stage ladder: concept, board cue, candidate, then one verified answer/line. */
  hints: [string, string, string, string];
  explanation: string;
  recognitionCue: string;
  source: 'Chess Game Master curated';
};

export const CURATED_LESSONS: Lesson[] = [
  {
    id: 'rules-castling-path-001',
    version: 1,
    category: 'rules',
    title: 'कैसलिंग का रास्ता सुरक्षित हो',
    objective: 'उस तरफ़ कैसलिंग करें जहाँ राजा का रास्ता attacked नहीं है।',
    fen: 'k7/8/8/8/8/8/5r2/R3K2R w KQ - 0 1',
    goal: { kind: 'specific-move', uci: 'e1c1' },
    hints: [
      'कैसलिंग में राजा दो चौखाने चलता है और चुना हुआ rook उसके पास आता है।',
      'राजा e1 से f1 या d1 होकर जाएगा—दोनों रास्तों के राजा-चौखाने जाँचें।',
      'f1 attacked है, जबकि d1 सुरक्षित है; इसलिए queen-side का रास्ता उपलब्ध है।',
      'e1-c1 और rook a1-d1 चलाएँ: `O-O-O` यहाँ जाँचा हुआ उत्तर है।',
    ],
    explanation: 'राजा शह से बाहर, शह के रास्ते से होकर या शह में कैसलिंग नहीं कर सकता। rook के रास्ते पर यही attack-नियम लागू नहीं होता।',
    recognitionCue: 'कैसलिंग से पहले राजा के शुरुआती, बीच के और अंतिम चौखाने जाँचें—rook के चौखाने नहीं।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'rules-en-passant-001',
    version: 1,
    category: 'rules',
    title: 'एन पासां का अवसर एक चाल तक',
    objective: 'अभी दो चौखाने चला प्यादा पकड़ें।',
    fen: '4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
    goal: { kind: 'specific-move', uci: 'e5d6' },
    hints: [
      'En passant का मौका केवल विरोधी के तुरंत पिछले दो-चौखाने pawn move के बाद मिलता है।',
      'काला pawn d7 से d5 आया है; इस position में target square d6 है।',
      'सफ़ेद pawn e5 से d6 पर जा सकता है और d5 वाला pawn हटेगा।',
      '`exd6` (`e5d6`) खेलें—यही इस lesson का जाँचा हुआ उत्तर है।',
    ],
    explanation: 'दो चौखाने चले प्यादे के तुरंत बाद ही en passant उपलब्ध होता है। मारने वाली गोटी बीच के चौखाने पर जाती है और d5 का प्यादा हटता है।',
    recognitionCue: 'पिछली चाल और en-passant target देखें; यह अधिकार केवल अगली चाल तक रहता है।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'rules-promotion-choice-001',
    version: 1,
    category: 'rules',
    title: 'प्यादे के लिए चार पदोन्नति विकल्प',
    objective: 'प्यादे को अंतिम पंक्ति तक पहुँचाकर कोई वैध गोटी चुनें।',
    fen: '4k3/P7/8/8/8/8/8/4K3 w - - 0 1',
    goal: { kind: 'promote', from: 'a7', to: 'a8' },
    hints: [
      'अंतिम rank पर पहुँचने वाली pawn चाल पर promotion अनिवार्य है।',
      'यह pawn a7 पर है; a8 पहुँचने पर चार अलग pieces चुन सकते हैं।',
      'Queen, rook, bishop और knight—चारों कानूनी विकल्प हैं; position के अनुसार चुनें।',
      'उदाहरण के लिए `a7-a8=N` चुनें; इस lesson में चारों promotion उत्तर स्वीकार होते हैं।',
    ],
    explanation: 'अंतिम पंक्ति तक पहुँचने वाली चाल पर पदोन्नति अनिवार्य है। वज़ीर, हाथी, ऊँट या घोड़ा चुन सकते हैं; नियम-तंत्र को चुपचाप वज़ीर नहीं चुनना चाहिए।',
    recognitionCue: 'प्यादा 8वीं या 1वीं पंक्ति पर पहुँचे तो रुककर पदोन्नति की गोटी चुनें।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'rules-answer-check-001',
    version: 1,
    category: 'rules',
    title: 'शह का जवाब देना ज़रूरी है',
    objective: 'ऐसी वैध चाल चलें जिससे आपके राजा से शह हटे।',
    fen: '4k3/8/8/8/8/8/4r3/4K2R w - - 0 1',
    goal: { kind: 'resolve-check' },
    hints: [
      'शह में ऐसी legal चाल जरूरी है जो अपने राजा को सुरक्षित करे।',
      'पहले शह देने वाली काली rook और राजा के आसपास के legal squares देखें।',
      'राजा को e-file से हटाएँ, या rook को तभी मारें/रास्ता रोकें जब चाल legal हो।',
      '`Kf1` (`e1f1`) इस स्थिति का एक rules-validated उत्तर है।',
    ],
    explanation: 'वैध बचाव चाल के बाद आपके राजा पर शह नहीं रहनी चाहिए। बोर्ड की legal-move सूची rules library से आती है।',
    recognitionCue: 'शह में केवल वैध राजा-चालें, शह देने वाली गोटी पर capture और संभव बीच-बचाव देखें।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'rules-pinned-piece-001',
    version: 1,
    category: 'rules',
    title: 'पिन की गोटी राजा को खुला न छोड़े',
    objective: 'पिन हुए rook को e-फ़ाइल पर रखते हुए चलें।',
    fen: '4r1k1/8/8/8/8/8/4R3/4K3 w - - 0 1',
    goal: { kind: 'same-file-move', from: 'e2', file: 'e' },
    hints: [
      'किसी pinned piece को हटाने से अपने राजा पर छिपी line खुल सकती है।',
      'सफ़ेद राजा e1 पर है और काली rook e8 से e-file पर दबाव डालती है।',
      'सफ़ेद rook e2 अभी बीच में है; उसे e-file पर रखते हुए चलें।',
      '`Re3` (`e2e3`) इस lesson का एक legal उत्तर है।',
    ],
    explanation: 'काले rook ने सफ़ेद राजा और e2 rook को एक ही फ़ाइल पर रखा है। rules library राजा को शह में छोड़ने वाली चालें रोकती है।',
    recognitionCue: 'यदि कोई गोटी अपने राजा की अकेली ढाल है, तो दिखने में चल सकने पर भी उसकी वैध चालें सीमित हो सकती हैं।',
    source: 'Chess Game Master curated',
  },
];

export type LessonAnswer = {
  status: 'correct' | 'incorrect' | 'illegal';
  san?: string;
  explanation: string;
};

export function validateLessonCatalog(lessons: Lesson[] = CURATED_LESSONS): void {
  const seen = new Set<string>();
  for (const lesson of lessons) {
    if (seen.has(lesson.id)) throw new Error(`Duplicate lesson id: ${lesson.id}`);
    seen.add(lesson.id);
    if (lesson.hints.length !== 4 || lesson.hints.some((hint) => !hint.trim())) throw new Error(`Lesson ${lesson.id} must provide four non-empty progressive hints.`);
    const chess = new Chess(lesson.fen);
    const goal = lesson.goal;
    if (chess.isCheckmate() || chess.isStalemate()) throw new Error(`Lesson ${lesson.id} starts in a terminal position.`);
    if (goal.kind === 'resolve-check' && !chess.isCheck()) throw new Error(`Lesson ${lesson.id} must start in check.`);
    if (goal.kind === 'specific-move' && !chess.moves({ verbose: true }).some((move) => `${move.from}${move.to}${move.promotion ?? ''}` === goal.uci)) {
      throw new Error(`Lesson ${lesson.id} answer is not legal.`);
    }
    if (goal.kind === 'promote' && !chess.moves({ verbose: true }).some((move) => move.from === goal.from && move.to === goal.to && move.promotion)) {
      throw new Error(`Lesson ${lesson.id} has no legal promotion answer.`);
    }
    if (goal.kind === 'same-file-move' && !chess.moves({ verbose: true }).some((move) => move.from === goal.from && move.to[0] === goal.file)) {
      throw new Error(`Lesson ${lesson.id} has no legal same-file answer.`);
    }
  }
}

export function validateLessonMove(lesson: Lesson, uci: string): LessonAnswer {
  const chess = new Chess(lesson.fen);
  let intent;
  try {
    intent = parseUci(uci);
  } catch {
    return { status: 'illegal', explanation: 'That is not a legal move in this position.' };
  }
  let move;
  try {
    move = chess.move({ from: intent.from, to: intent.to, ...(intent.promotion ? { promotion: intent.promotion } : {}) });
  } catch {
    return { status: 'illegal', explanation: 'That is not a legal move in this position.' };
  }
  const goal = lesson.goal;
  const correct = goal.kind === 'specific-move'
    ? `${move.from}${move.to}${move.promotion ?? ''}` === goal.uci
    : goal.kind === 'resolve-check'
      ? !chess.isCheck()
      : goal.kind === 'promote'
        ? move.from === goal.from && move.to === goal.to && Boolean(move.promotion)
        : move.from === goal.from && move.to[0] === goal.file;
  return correct
    ? { status: 'correct', san: move.san, explanation: lesson.explanation }
    : { status: 'incorrect', san: move.san, explanation: 'यह चाल वैध है, लेकिन पाठ का लक्ष्य पूरा नहीं करती। फिर कोशिश करें या संकेत माँगें।' };
}

export function lessonHint(lesson: Lesson, hintLevel: number): { hintLevel: number; text: string; exhausted: boolean } {
  const currentLevel = Number.isFinite(hintLevel) ? Math.max(0, Math.floor(hintLevel)) : 0;
  if (currentLevel >= lesson.hints.length) {
    return { hintLevel: lesson.hints.length, text: 'अब और संकेत उपलब्ध नहीं हैं।', exhausted: true };
  }
  const nextLevel = currentLevel + 1;
  return { hintLevel: nextLevel, text: lesson.hints[nextLevel - 1], exhausted: nextLevel >= lesson.hints.length };
}
