import { Chess, type Square } from 'chess.js';
import { fenSnapshot, uciForMove } from '../domain/chess/position';
import type { Color } from 'chess.js';

export type MateInOnePuzzle = {
  id: string;
  version: 1;
  theme: 'back-rank' | 'queen-mate';
  title: string;
  task: 'mate-in-one';
  fen: string;
  hints: string[];
  explanation: string;
  recognitionCue: string;
  source: 'Chess Game Master curated';
};

export const CURATED_PUZZLES: MateInOnePuzzle[] = [
  {
    id: 'mate-queen-king-001',
    version: 1,
    theme: 'queen-mate',
    title: 'वज़ीर और राजा का तालमेल',
    task: 'mate-in-one',
    fen: '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1',
    hints: [
      'काले राजा के बच निकलने वाले चौखाने देखें।',
      'वज़ीर चलें और राजा के भागने के चौखाने ढके रखें।',
    ],
    explanation: 'वज़ीर शह देता है और सफ़ेद राजा बाकी बचाव-चौखाने ढकता है। चाल तभी सही मानी जाती है जब rules library मात की पुष्टि करे।',
    recognitionCue: 'मात कहने से पहले राजा की हर चाल, capture, block और अन्य वैध बचाव जाँचें।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'mate-back-rank-001',
    version: 1,
    theme: 'back-rank',
    title: 'खुली फ़ाइल से back-rank mate',
    task: 'mate-in-one',
    fen: '6k1/5ppp/8/8/8/8/8/1R4K1 w - - 0 1',
    hints: [
      'काला राजा अपने ही प्यादों से घिरा है।',
      'खुली b-फ़ाइल से हाथी को back rank पर शह देने के लिए चलें।',
    ],
    explanation: 'हाथी आठवीं पंक्ति पर पहुँचकर घिरे राजा को शह देता है। अंतिम स्थिति में कोई वैध बचाव नहीं, इसलिए यह जाँची हुई एक-चाल की मात है।',
    recognitionCue: 'back-rank pattern तभी मात है जब भागने के चौखाने और सभी बचाव चालें बंद हों।',
    source: 'Chess Game Master curated',
  },
  {
    id: 'mate-rook-corner-001',
    version: 1,
    theme: 'back-rank',
    title: 'कोने में हाथी का जाल',
    task: 'mate-in-one',
    fen: '7k/6pp/8/8/8/8/8/5RK1 w - - 0 1',
    hints: [
      'राजा के अपने प्यादे उसके बचाव-चौखाने सीमित करते हैं।',
      'आठवीं पंक्ति पर हाथी की शह देखें।',
    ],
    explanation: 'हाथी की शह के साथ राजा के भागने के चौखाने भी सीमित हैं। rules engine पुष्टि करता है कि कोई वैध जवाब नहीं बचा।',
    recognitionCue: 'वैध जवाबों की संख्या शून्य होने से पहले हाथी की शह को मात न कहें।',
    source: 'Chess Game Master curated',
  },
];

export type PuzzleAttempt = {
  id: string;
  puzzleId: string;
  createdAt: string;
  outcome: 'correct' | 'incorrect' | 'illegal' | 'revealed' | 'skipped' | 'reset';
  moveUci?: string;
  moveSan?: string;
  hintLevel: number;
};

export type PuzzleSubmission = {
  attempt: PuzzleAttempt;
  message: string;
  afterFen?: string;
  checkmateVerified: boolean;
};

export function puzzleSideToMove(puzzle: MateInOnePuzzle): Color {
  return new Chess(puzzle.fen).turn();
}

export function getVerifiedMateInOneSolutions(puzzle: MateInOnePuzzle): Array<{ uci: string; san: string }> {
  const start = new Chess(puzzle.fen);
  const solutions: Array<{ uci: string; san: string }> = [];
  for (const legalMove of start.moves({ verbose: true })) {
    const trial = new Chess(puzzle.fen);
    const move = trial.move({ from: legalMove.from, to: legalMove.to, ...(legalMove.promotion ? { promotion: legalMove.promotion } : {}) });
    if (trial.isCheckmate()) solutions.push({ uci: uciForMove(move), san: move.san });
  }
  return solutions;
}

export function validatePuzzleCatalog(puzzles: MateInOnePuzzle[] = CURATED_PUZZLES): void {
  const seen = new Set<string>();
  for (const puzzle of puzzles) {
    if (seen.has(puzzle.id)) throw new Error(`Duplicate puzzle id: ${puzzle.id}`);
    seen.add(puzzle.id);
    const chess = new Chess(puzzle.fen);
    if (!getVerifiedMateInOneSolutions(puzzle).length) throw new Error(`Puzzle ${puzzle.id} has no verified mate-in-one solution.`);
    if (chess.isCheckmate() || chess.isStalemate()) throw new Error(`Puzzle ${puzzle.id} starts in a terminal position.`);
  }
}

export function submitPuzzleMove(
  puzzle: MateInOnePuzzle,
  moveUci: string,
  hintLevel = 0,
  at = new Date().toISOString(),
  id: string = crypto.randomUUID(),
): PuzzleSubmission {
  const start = new Chess(puzzle.fen);
  let move;
  try {
    const match = /^([a-h][1-8])([a-h][1-8])([qrbn])?$/.exec(moveUci.trim());
    if (!match) throw new Error('Invalid move notation.');
    move = start.move({ from: match[1] as Square, to: match[2] as Square, ...(match[3] ? { promotion: match[3] } : {}) });
  } catch {
    return {
      attempt: { id, puzzleId: puzzle.id, createdAt: at, outcome: 'illegal', moveUci, hintLevel },
      message: 'यह इस स्थिति में वैध चाल नहीं है।',
      checkmateVerified: false,
    };
  }
  const uci = uciForMove(move);
  const isMate = start.isCheckmate();
  return {
    attempt: {
      id,
      puzzleId: puzzle.id,
      createdAt: at,
      outcome: isMate ? 'correct' : 'incorrect',
      moveUci: uci,
      moveSan: move.san,
      hintLevel,
    },
    message: isMate ? 'सही — वैध चाल-निर्माण से मात की पुष्टि हुई।' : 'चाल वैध है, लेकिन लक्ष्य पूरा नहीं करती। नया दर्ज प्रयास शुरू करने के लिए रीसेट करें।',
    ...(isMate ? { afterFen: fenSnapshot(start, '-') } : {}),
    checkmateVerified: isMate,
  };
}

export function createPuzzleMetaAttempt(puzzleId: string, outcome: 'revealed' | 'skipped' | 'reset', hintLevel: number, at = new Date().toISOString(), id: string = crypto.randomUUID()): PuzzleAttempt {
  return { id, puzzleId, createdAt: at, outcome, hintLevel };
}

export function nextPuzzleHint(puzzle: MateInOnePuzzle, currentLevel: number): { level: number; text: string; exhausted: boolean } {
  const level = Math.min(puzzle.hints.length, Math.max(0, currentLevel) + 1);
  return {
    level,
    text: puzzle.hints[Math.max(0, level - 1)] ?? 'अब कोई और संकेत उपलब्ध नहीं है।',
    exhausted: level >= puzzle.hints.length,
  };
}
