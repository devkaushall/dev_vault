import { describe, expect, it } from 'vitest';
import { CURATED_LESSONS, lessonHint, validateLessonCatalog, validateLessonMove } from './lessons';

describe('versioned interactive rule lessons', () => {
  it('validates each curated answer against the legal move generator', () => {
    expect(() => validateLessonCatalog()).not.toThrow();
  });

  it('teaches castling safety and en-passant removal with exact legal moves', () => {
    expect(validateLessonMove(CURATED_LESSONS[0], 'e1c1').status).toBe('correct');
    expect(validateLessonMove(CURATED_LESSONS[1], 'e5d6')).toMatchObject({ status: 'correct', san: 'exd6' });
  });

  it('accepts all promotion choices but rejects an ordinary king move', () => {
    for (const promotion of ['q', 'r', 'b', 'n']) {
      expect(validateLessonMove(CURATED_LESSONS[2], `a7a8${promotion}`).status).toBe('correct');
    }
    expect(validateLessonMove(CURATED_LESSONS[2], 'e1d1').status).toBe('incorrect');
  });

  it('accepts any legal check response and records illegal intent separately', () => {
    const lesson = CURATED_LESSONS[3];
    expect(validateLessonMove(lesson, 'e1f1').status).toBe('correct');
    expect(validateLessonMove(lesson, 'a1a8').status).toBe('illegal');
  });

  it('provides a four-stage hint ladder and starts a clean ladder after exhaustion', () => {
    for (const lesson of CURATED_LESSONS) {
      expect(lesson.hints).toHaveLength(4);
      const stages = [0, 1, 2, 3].map((level) => lessonHint(lesson, level));
      expect(stages.map((stage) => stage.hintLevel)).toEqual([1, 2, 3, 4]);
      expect(stages.every((stage) => stage.text.trim().length > 0)).toBe(true);
      expect(stages[0].exhausted).toBe(false);
      expect(stages[3].exhausted).toBe(true);
      expect(lessonHint(lesson, 4)).toMatchObject({ hintLevel: 4, exhausted: true, text: 'अब और संकेत उपलब्ध नहीं हैं।' });
    }
  });

  it('keeps the final hint evidence-bound to a legal solution', () => {
    expect(lessonHint(CURATED_LESSONS[0], 3).text).toContain('O-O-O');
    expect(validateLessonMove(CURATED_LESSONS[0], 'e1c1').status).toBe('correct');
    expect(lessonHint(CURATED_LESSONS[4], 3).text).toContain('e2e3');
    expect(validateLessonMove(CURATED_LESSONS[4], 'e2e3').status).toBe('correct');
  });
});
