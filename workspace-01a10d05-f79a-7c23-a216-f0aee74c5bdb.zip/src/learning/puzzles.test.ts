import { describe, expect, it } from 'vitest';
import { CURATED_PUZZLES, getVerifiedMateInOneSolutions, nextPuzzleHint, submitPuzzleMove, validatePuzzleCatalog } from './puzzles';

describe('evidence-validated curated tactics', () => {
  it('validates every curated starting position and its solutions with legal chess rules', () => {
    expect(() => validatePuzzleCatalog()).not.toThrow();
    expect(getVerifiedMateInOneSolutions(CURATED_PUZZLES[0]).length).toBeGreaterThan(1);
    expect(getVerifiedMateInOneSolutions(CURATED_PUZZLES[1]).map((move) => move.san)).toContain('Rb8#');
    expect(getVerifiedMateInOneSolutions(CURATED_PUZZLES[2]).map((move) => move.san)).toContain('Rf8#');
  });

  it('records a legal non-solution as a failed attempt and does not reveal the line', () => {
    const puzzle = CURATED_PUZZLES[1];
    const wrong = submitPuzzleMove(puzzle, 'b1b2', 0, '2026-10-05T00:00:00Z', 'wrong-1');
    expect(wrong.attempt).toMatchObject({ outcome: 'incorrect', moveUci: 'b1b2' });
    expect(wrong.checkmateVerified).toBe(false);
    expect(wrong.afterFen).toBeUndefined();
  });

  it('records illegal input without changing the puzzle board', () => {
    const result = submitPuzzleMove(CURATED_PUZZLES[0], 'a1a8', 0, '2026-10-05T00:00:00Z', 'illegal-1');
    expect(result.attempt.outcome).toBe('illegal');
    expect(result.afterFen).toBeUndefined();
  });

  it('solves with a verified mating move and advances progressive hints', () => {
    const result = submitPuzzleMove(CURATED_PUZZLES[1], 'b1b8', 1, '2026-10-05T00:00:00Z', 'correct-1');
    expect(result.attempt).toMatchObject({ outcome: 'correct', moveSan: 'Rb8#', hintLevel: 1 });
    expect(result.checkmateVerified).toBe(true);
    expect(result.afterFen).toContain(' b ');
    expect(nextPuzzleHint(CURATED_PUZZLES[1], 0).level).toBe(1);
    expect(nextPuzzleHint(CURATED_PUZZLES[1], 1).level).toBe(2);
    expect(nextPuzzleHint(CURATED_PUZZLES[1], 2).exhausted).toBe(true);
  });
});
