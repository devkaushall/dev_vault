import { Chess, type Color, type Move } from 'chess.js';
import type { GameRecord } from '../domain/chess/types';
import { createChessEvidence, type ChessEvidence, type EvidenceReference } from './evidence';

type ReplayedMove = { ply: number; move: Move; after: Chess; afterFen: string };
type RepetitionReplay = { fens: string[]; moves: ReplayedMove[] };

function sideName(side: Color): 'white' | 'black' {
  return side === 'w' ? 'white' : 'black';
}

function moveReference(event: ReplayedMove): EvidenceReference {
  const uci = `${event.move.from}${event.move.to}${event.move.promotion ?? ''}`;
  return { kind: 'move', id: uci, ply: event.ply, uciMoves: [uci], sanMoves: [event.move.san], description: 'Legally replayed move in the repeated cycle.' };
}

function perpetualCheckEvidence(args: {
  fen: string;
  ply: number;
  positionKey: string;
  occurrences: number[];
  firstCycle: ReplayedMove[];
  secondCycle: ReplayedMove[];
  checkingSide: Color;
}): ChessEvidence {
  const cycle = args.firstCycle.map((event) => `${event.move.from}${event.move.to}${event.move.promotion ?? ''}`);
  const repeatedCycle = args.secondCycle.map((event) => `${event.move.from}${event.move.to}${event.move.promotion ?? ''}`);
  const references: EvidenceReference[] = args.occurrences.map((ply) => ({
    kind: 'position', id: args.positionKey, ply, description: 'The same FIDE repetition-identity position occurred at this ply.',
  }));
  references.push(...args.firstCycle.map(moveReference), ...args.secondCycle.map(moveReference));
  return createChessEvidence({
    type: 'transition',
    subtype: 'perpetual-check-pattern',
    status: 'candidate',
    confidence: 'medium',
    ply: args.ply,
    side: sideName(args.checkingSide),
    position: { fen: args.fen, moveNumber: Number(args.fen.split(/\s+/)[5]) || 1 },
    facts: [
      { key: 'pattern', value: 'same legal move cycle repeated twice; every recorded move by the named side gives check' },
      { key: 'cycleStartPly', value: args.occurrences[0] },
      { key: 'cycleLength', value: args.firstCycle.length },
      { key: 'checkingSide', value: sideName(args.checkingSide) },
      { key: 'firstCycleUci', value: cycle },
      { key: 'secondCycleUci', value: repeatedCycle },
      { key: 'separateDrawRule', value: false },
    ],
    references,
    lines: [{ moves: cycle, notation: 'uci', legal: true, termination: 'repetition' }],
    source: 'legal-game-replay repetition-cycle comparison',
    explanation: {
      whatHappened: `The same legal move cycle repeated twice, and every recorded move by ${sideName(args.checkingSide)} in that cycle gives check.`,
      whyItMatters: 'This is a candidate description of a perpetual-check pattern; threefold/fivefold repetition rules are represented separately, and perpetual check is not asserted as a separate draw rule.',
      concept: 'repeated checking cycle',
      learningTakeaway: 'Compare the full repeated position identity and legal move cycles; do not infer a draw claim or player intent from checks alone.',
    },
    createdBy: { analyser: 'repetition-detector', version: '1.0.0' },
  });
}

/** Exact repetition evidence from canonical replay keys; a repetition is not itself a claim. */
export function detectRepetitionEvidence(record: GameRecord, replay: RepetitionReplay): ChessEvidence[] {
  const evidence: ChessEvidence[] = [];
  const occurrences = new Map<string, number[]>();
  const initialKey = record.repetitionKeys[0];
  occurrences.set(initialKey, [0]);

  for (const event of replay.moves) {
    const key = record.repetitionKeys[event.ply];
    const previous = occurrences.get(key) ?? [];
    const plies = [...previous, event.ply];
    occurrences.set(key, plies);
    const occurrenceCount = plies.length;
    if (occurrenceCount !== 3 && occurrenceCount !== 5) continue;

    const automatic = occurrenceCount === 5;
    const precedingOccurrences = plies.slice(0, -1);
    const references: EvidenceReference[] = [...precedingOccurrences, event.ply].map((ply) => ({
      kind: 'position', id: key, ply, description: 'The same FIDE repetition-identity position occurred at this ply.',
    }));
    const lastMove = replay.moves[event.ply - 1];
    if (lastMove) references.push(moveReference(lastMove));
    evidence.push(createChessEvidence({
      type: 'transition',
      subtype: automatic ? 'fivefold-repetition' : 'threefold-repetition',
      status: 'confirmed',
      confidence: 'high',
      ply: event.ply,
      side: sideName(event.after.turn()),
      position: { fen: event.afterFen, moveNumber: Number(event.afterFen.split(/\s+/)[5]) || 1 },
      facts: [
        { key: 'repetitionCount', value: occurrenceCount },
        { key: 'occurrencePlies', value: plies.map(String) },
        { key: 'repeatedPositionKey', value: key },
        { key: 'automaticFivefold', value: automatic },
        { key: 'claimRequired', value: !automatic },
      ],
      references,
      source: 'canonical repetition keys from legal game replay',
      explanation: {
        whatHappened: `The same repetition-identity position occurred ${occurrenceCount} times in the recorded history.`,
        whyItMatters: automatic
          ? 'Fivefold repetition is an automatic draw condition under standard chess rules; the recorded position identity and occurrences are listed.'
          : 'Threefold repetition makes a draw claim available when the applicable rules and game state permit it; this evidence does not say a claim was made.',
        concept: automatic ? 'fivefold repetition' : 'threefold repetition',
        learningTakeaway: 'A repeated position and a completed draw claim are distinct facts; inspect the recorded history and result separately.',
      },
      createdBy: { analyser: 'repetition-detector', version: '1.0.0' },
    }));

    if (occurrenceCount === 3) {
      const [startPly, secondPly, thirdPly] = plies;
      const firstCycle = replay.moves.slice(startPly, secondPly);
      const secondCycle = replay.moves.slice(secondPly, thirdPly);
      const firstUci = firstCycle.map((move) => `${move.move.from}${move.move.to}${move.move.promotion ?? ''}`);
      const secondUci = secondCycle.map((move) => `${move.move.from}${move.move.to}${move.move.promotion ?? ''}`);
      if (firstCycle.length > 0 && firstCycle.length === secondCycle.length && firstUci.every((uci, index) => uci === secondUci[index])) {
        for (const side of ['w', 'b'] as const) {
          const sideMoves = [...firstCycle, ...secondCycle].filter((move) => move.move.color === side);
          if (!sideMoves.length || !sideMoves.every((move) => move.after.isCheck())) continue;
          evidence.push(perpetualCheckEvidence({
            fen: event.afterFen,
            ply: event.ply,
            positionKey: key,
            occurrences: plies,
            firstCycle,
            secondCycle,
            checkingSide: side,
          }));
        }
      }
    }
  }
  return evidence;
}
