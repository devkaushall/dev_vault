import { Chess, type Color, type Square } from 'chess.js';

/**
 * Phase 5/6 finding primitives and the Phase 7.1 evidence transport contract.
 * Numeric detector confidence/relevance are recognition metadata only; neither
 * is an engine evaluation or a guarantee that an implication is best play.
 */
export type KnowledgeEvidenceKind = 'board-state' | 'move-sequence' | 'dataset-label' | 'curated-claim';
export type KnowledgeEvidenceValue = string | number | boolean | readonly string[] | readonly number[];

/** Versioned, JSON-safe boundary for detector adapters and evidence aggregation. */
export type EvidenceStatus = 'confirmed' | 'candidate' | 'deferred';
export type EvidenceConfidence = 'high' | 'medium' | 'low';
export type BuiltinEvidenceType =
  | 'opening'
  | 'strategy'
  | 'pawn_structure'
  | 'tactic'
  | 'attack'
  | 'defence'
  | 'endgame'
  | 'king_safety'
  | 'material'
  | 'move_classification'
  | 'transition';
/** Namespaced extension points keep current records readable as new evidence is added. */
export type EvidenceType = BuiltinEvidenceType | `engine.${string}` | `custom.${string}`;

export type EvidenceFactValue = string | number | boolean | string[];
export type EvidenceFact = { key: string; value: EvidenceFactValue };
export type EvidenceReference = {
  kind: 'move' | 'position' | 'line' | 'opening' | 'detector';
  id: string;
  ply?: number;
  uciMoves?: string[];
  sanMoves?: string[];
  description?: string;
};
export type EvidenceMove = { uci: string; san: string };
export type EvidenceLineContinuation = {
  opponentReply: EvidenceMove;
  continuation?: EvidenceMove;
  opponentReplyCountAfterContinuation?: number;
  worstMaterialGain?: number;
  terminalOutcome?: 'checkmate' | 'stalemate';
};
export type EvidenceLineValidation = {
  candidateMoveLegal: boolean | null;
  forcingMove: EvidenceMove | null;
  forcingStatus: 'verified-check' | 'verified-double-check' | 'candidate-only' | 'not-applicable';
  opponentRepliesGenerated: number;
  opponentReplies: EvidenceMove[];
  repliesTruncated: boolean;
  continuationSearch: 'all-immediate-replies' | 'bounded' | 'not-performed' | 'not-applicable';
  continuations: EvidenceLineContinuation[];
  outcome: {
    kind: 'checkmate' | 'stalemate' | 'material-gain' | 'position-fact' | 'unproven';
    materialGain?: number;
    deterministic: boolean;
    description: string;
  };
};
export type EvidenceLine = {
  moves: string[];
  notation: 'san' | 'uci';
  /** Preserve the detector's paired notation when its validated line provides both. */
  sanMoves?: string[];
  uciMoves?: string[];
  /** Null preserves source uncertainty; true means legal generation/replay was validated. */
  legal: boolean | null;
  termination: 'mate' | 'material_change' | 'position_change' | 'promotion' | 'repetition' | 'stalemate' | 'unknown';
};
export type EvidenceExplanation = {
  whatHappened?: string;
  whyItMatters?: string;
  possibleIdea?: string;
  candidateResponse?: string;
  concept?: string;
  learningTakeaway?: string;
};

const BUILTIN_EVIDENCE_TYPES = new Set<BuiltinEvidenceType>([
  'opening', 'strategy', 'pawn_structure', 'tactic', 'attack', 'defence', 'endgame',
  'king_safety', 'material', 'move_classification', 'transition',
]);

function isEvidenceType(value: unknown): value is EvidenceType {
  return typeof value === 'string' && (
    BUILTIN_EVIDENCE_TYPES.has(value as BuiltinEvidenceType)
    || /^(engine|custom)\.[a-z0-9][a-z0-9._-]*$/.test(value)
  );
}
export type EngineEvidence = {
  name: string;
  version: string;
  depth?: number;
  score?: number;
  mate?: number;
  pv?: string[];
};
export type ChessEvidence = {
  schemaVersion: 1;
  evidenceId: string;
  type: EvidenceType;
  subtype: string;
  status: EvidenceStatus;
  confidence: EvidenceConfidence;
  ply: number;
  side: 'white' | 'black';
  position: { fen: string; moveNumber: number; san?: string; uci?: string };
  facts: EvidenceFact[];
  references: EvidenceReference[];
  source: string;
  lines?: EvidenceLine[];
  /** Detector proof/coverage fields copied verbatim where a Phase 6 legal-line search exists. */
  legalLineValidation?: EvidenceLineValidation;
  explanation?: EvidenceExplanation;
  createdBy: { analyser: string; version: string };
  /** Reserved for a future approved engine integration. Phase 7 never sets it. */
  engine?: EngineEvidence;
};

export type KnowledgeEvidence = {
  id: string;
  kind: KnowledgeEvidenceKind;
  description: string;
  squares?: readonly Square[];
  values?: Readonly<Record<string, KnowledgeEvidenceValue>>;
};

export type KnowledgeProvenance =
  | {
      kind: 'lichess-opening-dataset';
      repository: string;
      commit: string;
      license: string;
      field?: string;
    }
  | {
      kind: 'chess-atlas';
      document: 'Chess_Game_Master_Chess_Atlas_HI.md';
      section: string;
      basis: string;
    }
  | {
      kind: 'board-derivation';
      source: 'chess.js';
      method: string;
    };

export type KnowledgeImplication = {
  side?: Color;
  description: string;
  condition?: string;
};

export type KnowledgeFinding = {
  conceptId: string;
  label: string;
  evidence: KnowledgeEvidence[];
  confidence: number;
  relevance: number;
  possibleImplications: KnowledgeImplication[];
  provenance: KnowledgeProvenance[];
};

export function assertKnowledgeFinding(finding: KnowledgeFinding): KnowledgeFinding {
  if (!Number.isFinite(finding.confidence) || finding.confidence < 0 || finding.confidence > 1) {
    throw new RangeError(`Knowledge confidence for ${finding.conceptId} must be between 0 and 1.`);
  }
  if (!Number.isFinite(finding.relevance) || finding.relevance < 0 || finding.relevance > 1) {
    throw new RangeError(`Knowledge relevance for ${finding.conceptId} must be between 0 and 1.`);
  }
  if (!finding.evidence.length) throw new Error(`Knowledge finding ${finding.conceptId} must cite evidence.`);
  if (!finding.provenance.length) throw new Error(`Knowledge finding ${finding.conceptId} must cite provenance.`);
  return finding;
}

export function confidenceLevel(score: number): EvidenceConfidence {
  if (!Number.isFinite(score) || score < 0 || score > 1) throw new RangeError('Evidence confidence score must be between 0 and 1.');
  return score >= 0.9 ? 'high' : score >= 0.6 ? 'medium' : 'low';
}

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null';
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const object = value as Record<string, unknown>;
  return `{${Object.keys(object).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(object[key])}`).join(',')}}`;
}

/** Stable FNV-1a ID for the same ordered, typed evidence payload. */
export function stableEvidenceId(input: Pick<ChessEvidence, 'type' | 'subtype' | 'ply' | 'position' | 'facts' | 'source' | 'createdBy'>): string {
  const stable = stableStringify(input);
  let hash = 0x811c9dc5;
  for (let index = 0; index < stable.length; index += 1) {
    hash ^= stable.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return `ev_${input.type}_${input.ply}_${(hash >>> 0).toString(36).padStart(7, '0')}`;
}

export function createChessEvidence(draft: Omit<ChessEvidence, 'schemaVersion' | 'evidenceId'>): ChessEvidence {
  const idInput = {
    type: draft.type,
    subtype: draft.subtype,
    ply: draft.ply,
    position: draft.position,
    facts: draft.facts,
    source: draft.source,
    createdBy: draft.createdBy,
  };
  return assertChessEvidence({ schemaVersion: 1, ...draft, evidenceId: stableEvidenceId(idInput) });
}

function assertEvidenceMove(move: unknown): void {
  if (!move || typeof move !== 'object' || typeof (move as EvidenceMove).uci !== 'string' || typeof (move as EvidenceMove).san !== 'string') {
    throw new TypeError('Evidence legal-line moves must preserve SAN and UCI strings.');
  }
}

function assertLineValidation(validation: EvidenceLineValidation): void {
  if (validation.candidateMoveLegal !== true && validation.candidateMoveLegal !== false && validation.candidateMoveLegal !== null) throw new TypeError('Evidence line legality must preserve true, false, or null.');
  if (validation.forcingMove !== null) assertEvidenceMove(validation.forcingMove);
  if (!['verified-check', 'verified-double-check', 'candidate-only', 'not-applicable'].includes(validation.forcingStatus)) throw new TypeError('Evidence forcing status is invalid.');
  if (!Number.isInteger(validation.opponentRepliesGenerated) || validation.opponentRepliesGenerated < 0) throw new RangeError('Evidence reply count must be non-negative.');
  if (!Array.isArray(validation.opponentReplies) || validation.opponentReplies.some((move) => !move || typeof move.uci !== 'string' || typeof move.san !== 'string')) throw new TypeError('Evidence opponent replies must preserve SAN and UCI.');
  if (typeof validation.repliesTruncated !== 'boolean') throw new TypeError('Evidence reply truncation flag is invalid.');
  if (!['all-immediate-replies', 'bounded', 'not-performed', 'not-applicable'].includes(validation.continuationSearch)) throw new TypeError('Evidence continuation-search state is invalid.');
  if (!Array.isArray(validation.continuations)) throw new TypeError('Evidence continuations must be an array.');
  for (const branch of validation.continuations) {
    assertEvidenceMove(branch.opponentReply);
    if (branch.continuation) assertEvidenceMove(branch.continuation);
  }
  if (!validation.outcome || !['checkmate', 'stalemate', 'material-gain', 'position-fact', 'unproven'].includes(validation.outcome.kind)
    || typeof validation.outcome.deterministic !== 'boolean' || typeof validation.outcome.description !== 'string') {
    throw new TypeError('Evidence line outcome is invalid.');
  }
}

export function assertChessEvidence(evidence: ChessEvidence): ChessEvidence {
  if (!evidence || evidence.schemaVersion !== 1) throw new TypeError('Unsupported chess evidence schema version.');
  if (!isEvidenceType(evidence.type)) throw new TypeError('Chess evidence type is not a registered or namespaced extension type.');
  if (typeof evidence.evidenceId !== 'string' || !/^ev_[a-z][a-z0-9_.-]*_\d+_[a-z0-9]+$/.test(evidence.evidenceId)) throw new TypeError('Chess evidence ID is malformed.');
  if (!Number.isInteger(evidence.ply) || evidence.ply < 0) throw new RangeError('Evidence ply must be a non-negative integer.');
  if (!evidence.position || typeof evidence.position.fen !== 'string') throw new TypeError('Evidence position requires a FEN string.');
  if (!Number.isInteger(evidence.position.moveNumber) || evidence.position.moveNumber < 1) throw new RangeError('Evidence move number must be positive.');
  if (evidence.side !== 'white' && evidence.side !== 'black') throw new TypeError('Evidence side must be white or black.');
  if (typeof evidence.source !== 'string' || !evidence.source || typeof evidence.subtype !== 'string' || !evidence.subtype
    || typeof evidence.createdBy?.analyser !== 'string' || !evidence.createdBy.analyser
    || typeof evidence.createdBy.version !== 'string' || !evidence.createdBy.version) throw new TypeError('Evidence provenance is required.');
  if (!Array.isArray(evidence.facts) || !Array.isArray(evidence.references)) throw new TypeError('Evidence facts and references must be arrays.');
  for (const reference of evidence.references) {
    if (!reference || !['move', 'position', 'line', 'opening', 'detector'].includes(reference.kind) || typeof reference.id !== 'string' || !reference.id) throw new TypeError('Evidence references require a supported kind and stable ID.');
    if (reference.ply !== undefined && (!Number.isInteger(reference.ply) || reference.ply < 0)) throw new RangeError('Evidence reference ply must be a non-negative integer.');
    if (reference.uciMoves !== undefined && (!Array.isArray(reference.uciMoves) || reference.uciMoves.some((move) => typeof move !== 'string'))) throw new TypeError('Evidence UCI references must be string arrays.');
    if (reference.sanMoves !== undefined && (!Array.isArray(reference.sanMoves) || reference.sanMoves.some((move) => typeof move !== 'string'))) throw new TypeError('Evidence SAN references must be string arrays.');
  }
  if (evidence.lines !== undefined) {
    if (!Array.isArray(evidence.lines)) throw new TypeError('Evidence lines must be an array.');
    for (const line of evidence.lines) {
      if (!line || !Array.isArray(line.moves) || line.moves.some((move) => typeof move !== 'string')) throw new TypeError('Evidence line moves must be strings.');
      if (line.notation !== 'san' && line.notation !== 'uci') throw new TypeError('Evidence line notation is invalid.');
      if (line.sanMoves !== undefined && (!Array.isArray(line.sanMoves) || line.sanMoves.some((move) => typeof move !== 'string'))) throw new TypeError('Evidence SAN lines must be string arrays.');
      if (line.uciMoves !== undefined && (!Array.isArray(line.uciMoves) || line.uciMoves.some((move) => typeof move !== 'string'))) throw new TypeError('Evidence UCI lines must be string arrays.');
      if (line.legal !== true && line.legal !== false && line.legal !== null) throw new TypeError('Evidence line legality must preserve true, false, or null.');
      if (!['mate', 'material_change', 'position_change', 'promotion', 'repetition', 'stalemate', 'unknown'].includes(line.termination)) throw new TypeError('Evidence line termination is invalid.');
    }
  }
  if (evidence.legalLineValidation) assertLineValidation(evidence.legalLineValidation);
  if (!['confirmed', 'candidate', 'deferred'].includes(evidence.status)) throw new TypeError('Evidence status is invalid.');
  if (!['high', 'medium', 'low'].includes(evidence.confidence)) throw new TypeError('Evidence confidence is invalid.');
  try {
    new Chess(evidence.position.fen);
    const json = JSON.stringify(evidence);
    if (typeof json !== 'string') throw new Error('JSON serialization returned no data.');
  } catch (error) {
    throw new TypeError(`Chess evidence is not valid/serializable: ${error instanceof Error ? error.message : 'unknown error'}`);
  }
  for (const fact of evidence.facts) {
    if (!fact.key || !(typeof fact.value === 'string' || typeof fact.value === 'number' && Number.isFinite(fact.value) || typeof fact.value === 'boolean' || Array.isArray(fact.value))) {
      throw new TypeError('Chess evidence facts must use serializable scalar or string-array values.');
    }
    if (Array.isArray(fact.value) && fact.value.some((value) => typeof value !== 'string')) throw new TypeError('Evidence arrays must contain only strings.');
  }
  return evidence;
}
