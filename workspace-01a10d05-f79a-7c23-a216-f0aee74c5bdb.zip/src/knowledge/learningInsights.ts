import type { ChessEvidence, EvidenceConfidence } from './evidence';

export type LearningEvidenceSet = {
  /** Stable, local-only identity used to avoid counting duplicate review copies twice. */
  gameKey: string;
  totalPlies: number;
  /** Number of positions whose deep detectors ran; defaults to totalPlies for legacy callers. */
  analyzedPositionCount?: number;
  evidence: readonly ChessEvidence[];
};
export type LearningInsightThresholds = {
  minimumOccurrences: number;
  minimumDistinctGames: number;
  minimumFrequency: number;
};
export type LearningInsight = {
  id: string;
  patternId: string;
  label: string;
  scope: 'repeated-across-reviewed-games';
  status: 'candidate';
  confidence: EvidenceConfidence;
  occurrenceCount: number;
  distinctGameCount: number;
  frequency: number;
  frequencyBasis: 'replayed-moves' | 'analyzed-positions';
  summary: string;
  evidenceIds: string[];
};
export type LearningInsightsResult = {
  schemaVersion: 1;
  thresholds: LearningInsightThresholds;
  insights: LearningInsight[];
  limitations: string[];
};

type PatternCoverage = 'replayed-moves' | 'analyzed-positions';
type PatternDefinition = { id: string; label: string; coverage: PatternCoverage };
type PatternOccurrence = { gameKey: string; ply: number; evidence: ChessEvidence; coverage: PatternCoverage };

const DEFAULT_THRESHOLDS: LearningInsightThresholds = {
  minimumOccurrences: 3,
  minimumDistinctGames: 2,
  minimumFrequency: 0.08,
};

function patternFor(evidence: ChessEvidence): PatternDefinition | undefined {
  if (evidence.status === 'deferred') return undefined;
  if (evidence.type === 'move_classification') {
    const map: Record<string, PatternDefinition> = {
      'candidate-tactical-mistake': { id: 'candidate-tactical-vulnerability', label: 'Candidate tactical vulnerability cues', coverage: 'analyzed-positions' },
      'king-safety-change': { id: 'king-safety-change', label: 'King-safety changes', coverage: 'replayed-moves' },
      'pawn-break': { id: 'central-pawn-break', label: 'Central pawn-break cues', coverage: 'replayed-moves' },
      'defensive-move': { id: 'defensive-resource', label: 'Defensive resources', coverage: 'analyzed-positions' },
      'strategic-move': { id: 'strategic-cue', label: 'Strategic cues', coverage: 'analyzed-positions' },
      'piece-activity-change': { id: 'piece-activity-change', label: 'Piece-activity changes', coverage: 'replayed-moves' },
    };
    return map[evidence.subtype];
  }
  if (evidence.type === 'tactic') return { id: `tactic:${evidence.subtype}`, label: `Tactical ${evidence.subtype.replaceAll('-', ' ')} cues`, coverage: 'analyzed-positions' };
  if (evidence.type === 'pawn_structure') return { id: `pawn-structure:${evidence.subtype}`, label: `Pawn-structure ${evidence.subtype.replaceAll('-', ' ')} cues`, coverage: 'analyzed-positions' };
  if (evidence.type === 'strategy') return { id: `strategy:${evidence.subtype}`, label: `Strategic ${evidence.subtype.replaceAll('-', ' ')} cues`, coverage: 'analyzed-positions' };
  if (evidence.type === 'endgame' && evidence.subtype !== 'material-phase-profile') return { id: `endgame:${evidence.subtype}`, label: `Endgame ${evidence.subtype.replaceAll('-', ' ')} cues`, coverage: 'analyzed-positions' };
  return undefined;
}

function confidenceFor(count: number, games: number): EvidenceConfidence {
  return count >= 5 && games >= 3 ? 'medium' : 'low';
}

/**
 * Finds recurring, evidence-backed study themes. Patterns are counted once per
 * game/ply and require multiple reviewed games; the output is never a player
 * trait, rating, or universal accuracy score.
 */
export function deriveLearningInsights(
  evidenceSets: readonly LearningEvidenceSet[],
  thresholds: Partial<LearningInsightThresholds> = {},
): LearningInsightsResult {
  const effective: LearningInsightThresholds = { ...DEFAULT_THRESHOLDS, ...thresholds };
  if (!Number.isInteger(effective.minimumOccurrences) || effective.minimumOccurrences < 1) throw new RangeError('minimumOccurrences must be a positive integer.');
  if (!Number.isInteger(effective.minimumDistinctGames) || effective.minimumDistinctGames < 1) throw new RangeError('minimumDistinctGames must be a positive integer.');
  if (!Number.isFinite(effective.minimumFrequency) || effective.minimumFrequency < 0 || effective.minimumFrequency > 1) throw new RangeError('minimumFrequency must be between 0 and 1.');

  const uniqueGames = new Map<string, { totalPlies: number; analyzedPositionCount: number; evidence: ChessEvidence[] }>();
  for (const set of evidenceSets) {
    if (!set.gameKey || !Number.isInteger(set.totalPlies) || set.totalPlies < 0) continue;
    const analyzedPositionCount = Number.isInteger(set.analyzedPositionCount) && (set.analyzedPositionCount ?? -1) >= 0
      ? set.analyzedPositionCount!
      : set.totalPlies;
    const current = uniqueGames.get(set.gameKey);
    if (current) {
      current.totalPlies = Math.max(current.totalPlies, set.totalPlies);
      current.analyzedPositionCount = Math.max(current.analyzedPositionCount, analyzedPositionCount);
      current.evidence.push(...set.evidence);
    } else uniqueGames.set(set.gameKey, { totalPlies: set.totalPlies, analyzedPositionCount, evidence: [...set.evidence] });
  }

  const patterns = new Map<string, { coverage: PatternCoverage; occurrences: Map<string, PatternOccurrence> }>();
  for (const [gameKey, set] of uniqueGames) {
    for (const evidence of set.evidence) {
      const pattern = patternFor(evidence);
      if (!pattern || !Number.isInteger(evidence.ply) || evidence.ply < 0) continue;
      const existing = patterns.get(pattern.id);
      const bucket = existing ?? { coverage: pattern.coverage, occurrences: new Map<string, PatternOccurrence>() };
      const key = `${gameKey}:${evidence.ply}`;
      if (!bucket.occurrences.has(key)) bucket.occurrences.set(key, { gameKey, ply: evidence.ply, evidence, coverage: pattern.coverage });
      patterns.set(pattern.id, bucket);
    }
  }

  const insights: LearningInsight[] = [];
  for (const [patternId, pattern] of patterns) {
    const occurrences = [...pattern.occurrences.values()].sort((a, b) => a.gameKey.localeCompare(b.gameKey) || a.ply - b.ply);
    const distinctGameCount = new Set(occurrences.map((item) => item.gameKey)).size;
    const observedCount = [...uniqueGames.values()].reduce((sum, game) => sum + Math.max(1, pattern.coverage === 'analyzed-positions' ? game.analyzedPositionCount : game.totalPlies), 0);
    const frequency = observedCount ? Math.min(1, occurrences.length / observedCount) : 0;
    if (occurrences.length < effective.minimumOccurrences || distinctGameCount < effective.minimumDistinctGames || frequency < effective.minimumFrequency) continue;
    const label = patternFor(occurrences[0].evidence)?.label ?? patternId;
    const confidence = confidenceFor(occurrences.length, distinctGameCount);
    const frequencyBasis = pattern.coverage;
    const frequencyScope = frequencyBasis === 'analyzed-positions' ? 'selected analyzed positions' : 'replayed moves';
    insights.push({
      id: `insight_${patternId.replace(/[^a-z0-9]+/gi, '_').toLowerCase()}_${occurrences.length}_${distinctGameCount}`,
      patternId,
      label,
      scope: 'repeated-across-reviewed-games',
      status: 'candidate',
      confidence,
      occurrenceCount: occurrences.length,
      distinctGameCount,
      frequency,
      frequencyBasis,
      summary: `${label} appeared ${occurrences.length} times across ${distinctGameCount} distinct reviewed games (${Math.round(frequency * 100)}% of ${frequencyScope}). This is a candidate study theme, not a permanent player trait or a move-quality score.`,
      evidenceIds: [...new Set(occurrences.map((item) => item.evidence.evidenceId))].sort(),
    });
  }
  insights.sort((a, b) => b.occurrenceCount - a.occurrenceCount || a.patternId.localeCompare(b.patternId));
  return {
    schemaVersion: 1,
    thresholds: effective,
    insights,
    limitations: [
      'A pattern is emitted only after configurable occurrence, distinct-game, and frequency thresholds are met.',
      'Duplicate review copies sharing one gameKey are counted as one game; duplicate evidence at a game/ply is counted once per pattern.',
      'Every result is a candidate study theme, not a permanent weakness, player trait, rating, or universal accuracy score.',
      'Missing or deferred evidence is not counted as evidence that a pattern was absent.',
    ],
  };
}
