import { Chess, type Color, type Move, type PieceSymbol } from 'chess.js';
import type { GameRecord } from '../domain/chess/types';
import { fenAtPly, positionKey, uciForMove } from '../domain/chess/position';
import {
  analyzeAttacks,
  type AttackFinding,
} from './attack';
import {
  analyzeDefence,
  type DefenceResourceFinding,
} from './defence';
import {
  analyzeEndgames,
  type EndgameFinding,
} from './endgames';
import {
  analyzeStaticPosition,
  type PositionEvidence,
} from './positionFacts';
import {
  analyzeStrategyPosition,
  type StrategyFinding,
} from './strategy';
import { analyzePawnStructures } from './pawnStructures';
import {
  analyzeTactics,
  type TacticalFinding,
  type TacticalLegalLine,
} from './tactics';
import { detectRepetitionEvidence } from './repetitionEvidence';
import {
  lookupOpeningAtPosition,
  type OpeningCatalog,
  type OpeningMatch,
} from './openings';
import {
  assertChessEvidence,
  confidenceLevel,
  stableEvidenceId,
  type BuiltinEvidenceType,
  type ChessEvidence,
  type EvidenceConfidence,
  type EvidenceFact,
  type EvidenceLine,
  type EvidenceLineValidation,
  type EvidenceReference,
  type EvidenceStatus,
  type EvidenceType,
  type KnowledgeEvidence,
  type KnowledgeEvidenceValue,
  type KnowledgeFinding,
  type KnowledgeProvenance,
} from './evidence';

export const EVIDENCE_ANALYSER_VERSION = '1.0.0';
export const DEFAULT_MAX_ANALYZED_POSITIONS = 48;

export type AggregationOptions = {
  /** Bound costly detector passes. Moves outside selected positions remain explicitly deferred. */
  maxAnalyzedPositions?: number;
  /** Yield between positions when called from a browser review. Defaults to true. */
  yieldToEventLoop?: boolean;
};

export type PositionEvidenceIndex = {
  ply: number;
  fen: string;
  evidenceIds: string[];
};

export type ChessEvidenceAggregation = {
  schemaVersion: 1;
  gameId: string;
  totalPlies: number;
  analyzedPositionPlies: number[];
  positions: PositionEvidenceIndex[];
  evidence: ChessEvidence[];
  limitations: string[];
};

type ReplayedMove = {
  ply: number;
  beforeFen: string;
  afterFen: string;
  move: Move;
  before: Chess;
  after: Chess;
  positionKeyBefore: string;
  positionKeyAfter: string;
};

type PositionArgs = {
  fen: string;
  ply: number;
  sideToMove: Color;
  record?: GameRecord;
  catalog?: OpeningCatalog;
  includeDeferred?: boolean;
};

export type ChessEvidenceBatch = readonly ChessEvidence[];

function compareText(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null';
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  const object = value as Record<string, unknown>;
  const entries = Object.keys(object)
    .filter((key) => object[key] !== undefined)
    .sort(compareText)
    .map((key) => `${JSON.stringify(key)}:${canonicalJson(object[key])}`);
  return `{${entries.join(',')}}`;
}

function compareEvidence(a: ChessEvidence, b: ChessEvidence): number {
  return a.ply - b.ply
    || compareText(a.type, b.type)
    || compareText(a.subtype, b.subtype)
    || compareText(a.evidenceId, b.evidenceId)
    || compareText(a.position.fen, b.position.fen)
    || compareText(a.source, b.source);
}

function evidenceCoreJson(evidence: ChessEvidence): string {
  return canonicalJson(Object.fromEntries(Object.entries(evidence).filter(([key]) => key !== 'references')));
}

/**
 * Merges already-adapted batches from the domain detectors. It validates and
 * deduplicates by stable ID, rejects conflicting ID collisions, and sorts
 * deterministically without changing status, confidence, facts, provenance,
 * references, or legal-line validation. This boundary does not run detectors
 * or generate user-facing prose.
 */
export function aggregateEvidenceBatches(batches: readonly ChessEvidenceBatch[]): ChessEvidence[] {
  const byId = new Map<string, ChessEvidence>();
  for (const batch of batches) {
    for (const candidate of batch) {
      const item = assertChessEvidence(candidate);
      const existing = byId.get(item.evidenceId);
      if (!existing) {
        byId.set(item.evidenceId, item);
        continue;
      }
      if (evidenceCoreJson(existing) !== evidenceCoreJson(item)) {
        throw new Error(`Conflicting chess evidence uses stable ID ${item.evidenceId}.`);
      }
      const references = [...new Map([...existing.references, ...item.references].map((reference) => [canonicalJson(reference), { ...reference }])).values()]
        .sort((a, b) => compareText(canonicalJson(a), canonicalJson(b)));
      byId.set(item.evidenceId, { ...existing, references });
    }
  }
  return [...byId.values()].sort(compareEvidence);
}

const TYPE_TO_ANALYSER: Record<BuiltinEvidenceType, string> = {
  opening: 'opening-recognizer',
  strategy: 'strategy-detector',
  pawn_structure: 'pawn-structure-detector',
  tactic: 'tactics-detector',
  attack: 'attack-detector',
  defence: 'defence-detector',
  endgame: 'endgame-detector',
  king_safety: 'position-detector',
  material: 'position-detector',
  move_classification: 'move-classifier',
  transition: 'transition-detector',
};

function sideName(side: Color): 'white' | 'black' {
  return side === 'w' ? 'white' : 'black';
}

function moveNumberFromFen(fen: string): number {
  const number = Number(fen.trim().split(/\s+/)[5]);
  return Number.isInteger(number) && number > 0 ? number : 1;
}

function normalizeValue(value: KnowledgeEvidenceValue): string | number | boolean | string[] {
  if (Array.isArray(value)) return value.map(String);
  return value as string | number | boolean;
}

function stableFacts(facts: EvidenceFact[]): EvidenceFact[] {
  return facts.slice().sort((a, b) => compareText(a.key, b.key) || compareText(canonicalJson(a.value), canonicalJson(b.value)));
}

function toEvidence(args: {
  type: EvidenceType;
  subtype: string;
  status: EvidenceStatus;
  confidence: EvidenceConfidence;
  ply: number;
  side: Color;
  fen: string;
  facts: EvidenceFact[];
  references?: EvidenceReference[];
  source: string;
  analyser?: string;
  san?: string;
  uci?: string;
  lines?: EvidenceLine[];
  legalLineValidation?: EvidenceLineValidation;
}): ChessEvidence {
  const position = {
    fen: args.fen,
    moveNumber: moveNumberFromFen(args.fen),
    ...(args.san ? { san: args.san } : {}),
    ...(args.uci ? { uci: args.uci } : {}),
  };
  const facts = stableFacts(args.facts);
  const analyser = args.analyser ?? TYPE_TO_ANALYSER[args.type as BuiltinEvidenceType] ?? 'evidence-adapter';
  const idInput = {
    type: args.type,
    subtype: args.subtype,
    ply: args.ply,
    position,
    facts,
    source: args.source,
    createdBy: { analyser, version: EVIDENCE_ANALYSER_VERSION },
  };
  return assertChessEvidence({
    schemaVersion: 1,
    ...idInput,
    evidenceId: stableEvidenceId(idInput),
    status: args.status,
    confidence: args.confidence,
    side: sideName(args.side),
    references: args.references ?? [],
    source: args.source,
    ...(args.lines?.length ? { lines: args.lines } : {}),
    ...(args.legalLineValidation ? { legalLineValidation: args.legalLineValidation } : {}),
  });
}

function serializeProvenance(provenance: KnowledgeProvenance[]): string[] {
  return provenance.map((entry) => {
    if (entry.kind === 'board-derivation') return `${entry.source}: ${entry.method}`;
    if (entry.kind === 'chess-atlas') return `${entry.document} ${entry.section}: ${entry.basis}`;
    return `${entry.repository}@${entry.commit} (${entry.license})${entry.field ? ` field=${entry.field}` : ''}`;
  });
}

function findingFacts(finding: KnowledgeFinding, boardEvidence: KnowledgeEvidence[], extra: EvidenceFact[] = []): EvidenceFact[] {
  const facts: EvidenceFact[] = [
    { key: 'conceptId', value: finding.conceptId },
    { key: 'label', value: finding.label },
    { key: 'detectorConfidence', value: finding.confidence },
    { key: 'relevance', value: finding.relevance },
    ...serializeProvenance(finding.provenance).map((value, index) => ({ key: `provenance.${index}`, value })),
    ...extra,
  ];
  for (const evidence of boardEvidence) {
    facts.push({ key: `evidence.${evidence.id}.description`, value: evidence.description });
    for (const [key, value] of Object.entries(evidence.values ?? {})) {
      facts.push({ key: `evidence.${evidence.id}.${key}`, value: normalizeValue(value) });
    }
  }
  return facts;
}

function referencesFor(finding: KnowledgeFinding, fen: string, ply: number, move?: { san: string; uci: string }, lines?: EvidenceLine[]): EvidenceReference[] {
  const references: EvidenceReference[] = [
    { kind: 'detector', id: finding.conceptId },
    { kind: 'position', id: positionKey(new Chess(fen)), ply },
  ];
  for (const evidence of finding.evidence) references.push({
    kind: evidence.kind === 'dataset-label' ? 'opening' : 'detector',
    id: evidence.id,
    ply,
    description: evidence.description,
  });
  if (move) references.push({ kind: 'move', id: move.uci, ply: ply + 1, uciMoves: [move.uci], sanMoves: [move.san] });
  if (lines) lines.forEach((line, index) => {
    const uciMoves = line.uciMoves ?? (line.notation === 'uci' ? line.moves : undefined);
    const sanMoves = line.sanMoves ?? (line.notation === 'san' ? line.moves : undefined);
    references.push({
      kind: 'line',
      id: `${finding.conceptId}:${ply}:${index}`,
      ply,
      ...(uciMoves ? { uciMoves: [...uciMoves] } : {}),
      ...(sanMoves ? { sanMoves: [...sanMoves] } : {}),
    });
  });
  return references;
}

function copyLegalLineValidation(line: TacticalLegalLine): EvidenceLineValidation {
  return {
    candidateMoveLegal: line.candidateMoveLegal,
    forcingMove: line.forcingMove ? { ...line.forcingMove } : null,
    forcingStatus: line.forcingStatus,
    opponentRepliesGenerated: line.opponentRepliesGenerated,
    opponentReplies: line.opponentReplies.map((move) => ({ ...move })),
    repliesTruncated: line.repliesTruncated,
    continuationSearch: line.continuationSearch,
    continuations: line.continuations.map((branch) => ({
      opponentReply: { ...branch.opponentReply },
      ...(branch.continuation ? { continuation: { ...branch.continuation } } : {}),
      ...(branch.opponentReplyCountAfterContinuation === undefined ? {} : { opponentReplyCountAfterContinuation: branch.opponentReplyCountAfterContinuation }),
      ...(branch.worstMaterialGain === undefined ? {} : { worstMaterialGain: branch.worstMaterialGain }),
      ...(branch.terminalOutcome ? { terminalOutcome: branch.terminalOutcome } : {}),
    })),
    outcome: { ...line.outcome },
  };
}

function tacticalLines(finding: TacticalFinding | DefenceResourceFinding | EndgameFinding): EvidenceLine[] {
  const line = finding.legalLine;
  if (!line) return [];
  const termination: EvidenceLine['termination'] = line.outcome.kind === 'checkmate'
    ? 'mate'
    : line.outcome.kind === 'stalemate'
      ? 'stalemate'
      : line.outcome.kind === 'material-gain'
        ? 'material_change'
        : line.outcome.kind === 'position-fact'
          ? 'position_change'
          : 'unknown';
  const result: EvidenceLine[] = [];
  if (line.forcingMove) {
    if (line.continuations.length) {
      for (const branch of line.continuations) {
        const moves = [line.forcingMove, branch.opponentReply, branch.continuation].filter((move): move is { uci: string; san: string } => Boolean(move));
        const uciMoves = moves.map((move) => move.uci);
        result.push({ moves: uciMoves, notation: 'uci', uciMoves, sanMoves: moves.map((move) => move.san), legal: line.candidateMoveLegal, termination: branch.terminalOutcome === 'checkmate' ? 'mate' : branch.terminalOutcome === 'stalemate' ? 'stalemate' : termination });
      }
    } else {
      result.push({ moves: [line.forcingMove.uci], notation: 'uci', uciMoves: [line.forcingMove.uci], sanMoves: [line.forcingMove.san], legal: line.candidateMoveLegal, termination });
    }
  }
  return result;
}

function genericFinding(args: {
  type: EvidenceType;
  subtype: string;
  state: EvidenceStatus;
  finding: KnowledgeFinding;
  fen: string;
  ply: number;
  fallbackSide: Color;
  side?: Color;
  move?: { san: string; uci: string };
  lines?: EvidenceLine[];
  legalLineValidation?: EvidenceLineValidation;
  extraFacts?: EvidenceFact[];
  source?: string;
}): ChessEvidence {
  const relatedSide = args.side ?? args.finding.possibleImplications.find((item) => item.side)?.side ?? args.fallbackSide;
  const scopeFact = args.side || args.finding.possibleImplications.some((item) => item.side)
    ? []
    : [{ key: 'sideScope', value: 'position-wide; side field is the side to move for indexing only' }];
  const implications = args.finding.possibleImplications.map((item) => item.description).filter(Boolean);
  return toEvidence({
    type: args.type,
    subtype: args.subtype,
    status: args.state,
    confidence: confidenceLevel(args.finding.confidence),
    ply: args.ply,
    side: relatedSide,
    fen: args.fen,
    san: args.move?.san,
    uci: args.move?.uci,
    facts: findingFacts(args.finding, args.finding.evidence, [...scopeFact, ...(args.extraFacts ?? []), ...(implications.length ? [{ key: 'possibleImplications', value: implications }] : [])]),
    references: referencesFor(args.finding, args.fen, args.ply, args.move, args.lines),
    source: args.source ?? serializeProvenance(args.finding.provenance).join(' | '),
    analyser: TYPE_TO_ANALYSER[args.type as BuiltinEvidenceType],
    lines: args.lines,
    legalLineValidation: args.legalLineValidation,
  });
}

function tacticalFindingEvidence(finding: TacticalFinding, fen: string, ply: number): ChessEvidence {
  const lines = tacticalLines(finding);
  return genericFinding({
    type: 'tactic', subtype: finding.motif, state: finding.state, finding, fen, ply, fallbackSide: finding.side,
    side: finding.side, move: finding.triggeringMove, lines,
    legalLineValidation: copyLegalLineValidation(finding.legalLine),
    source: serializeProvenance(finding.provenance).join(' | '),
    extraFacts: [
      { key: 'candidateMoveLegal', value: finding.legalLine.candidateMoveLegal === null ? 'not-applicable' : finding.legalLine.candidateMoveLegal },
      { key: 'forcingStatus', value: finding.legalLine.forcingStatus },
      { key: 'opponentRepliesGenerated', value: finding.legalLine.opponentRepliesGenerated },
      { key: 'continuationSearch', value: finding.legalLine.continuationSearch },
      { key: 'outcome', value: finding.legalLine.outcome.kind },
      { key: 'outcomeDeterministic', value: finding.legalLine.outcome.deterministic },
      { key: 'possibleConsequence', value: finding.possibleConsequence },
    ],
  });
}

function typeForAttack(finding: AttackFinding): EvidenceType {
  return finding.motif === 'exposed-king' ? 'king_safety' : 'attack';
}

function typeForStrategy(finding: StrategyFinding): EvidenceType {
  return finding.concept === 'king-safety' ? 'king_safety' : 'strategy';
}

function addPositionFinding(args: {
  evidence: ChessEvidence[];
  finding: KnowledgeFinding;
  type: EvidenceType;
  subtype: string;
  fen: string;
  ply: number;
  sideToMove: Color;
  side?: Color;
  state: EvidenceStatus;
  boardEvidence?: KnowledgeEvidence[];
  move?: { san: string; uci: string };
  lines?: EvidenceLine[];
  legalLineValidation?: EvidenceLineValidation;
  extraFacts?: EvidenceFact[];
  source?: string;
}) {
  args.evidence.push(genericFinding({
    type: args.type,
    subtype: args.subtype,
    state: args.state,
    finding: args.finding,
    fen: args.fen,
    ply: args.ply,
    fallbackSide: args.sideToMove,
    side: args.side,
    move: args.move,
    lines: args.lines,
    legalLineValidation: args.legalLineValidation,
    extraFacts: args.extraFacts,
    source: args.source,
  }));
}

function addDeferred(args: {
  evidence: ChessEvidence[];
  type: EvidenceType;
  subtype: string;
  reason: string;
  fen: string;
  ply: number;
  side: Color;
  source: string;
}) {
  args.evidence.push(toEvidence({
    type: args.type,
    subtype: args.subtype,
    status: 'deferred',
    confidence: 'low',
    ply: args.ply,
    side: args.side,
    fen: args.fen,
    facts: [{ key: 'reason', value: args.reason }],
    references: [{ kind: 'detector', id: args.source }, { kind: 'position', id: positionKey(new Chess(args.fen)), ply: args.ply }],
    source: args.source,
  }));
}

function boardFactEvidence(fact: PositionEvidence, fen: string, ply: number, sideToMove: Color): ChessEvidence {
  const type: EvidenceType = fact.id === 'material-count'
    ? 'material'
    : fact.id === 'side-to-move-in-check'
      ? 'king_safety'
      : fact.id.startsWith('fork-candidate')
        ? 'tactic'
        : fact.id.startsWith('passed-pawns') || fact.id.startsWith('doubled-pawns') || fact.id.startsWith('isolated-pawns')
          ? 'pawn_structure'
          : 'strategy';
  const source = fact.source;
  return toEvidence({
    type,
    subtype: fact.id,
    status: fact.kind === 'verified-board-fact' ? 'confirmed' : 'candidate',
    confidence: fact.confidence === 'verified' ? 'high' : 'low',
    ply,
    side: sideToMove,
    fen,
    facts: [
      { key: 'title', value: fact.title },
      { key: 'description', value: fact.explanation },
      ...fact.evidence.map((item) => ({ key: item.field, value: Array.isArray(item.value) ? item.value.map(String) : item.value })),
      { key: 'squares', value: fact.squares },
    ],
    references: [
      { kind: 'position', id: positionKey(new Chess(fen)), ply },
      { kind: 'detector', id: fact.id },
    ],
    source,
    analyser: source === 'static-geometry-v1' ? 'position-facts-detector' : 'chess.js-position-facts',
  });
}

function addOpeningEvidence(args: {
  evidence: ChessEvidence[];
  match: OpeningMatch;
  fen: string;
  ply: number;
  side: Color;
}) {
  const openingNames = args.match.entries.map((entry) => entry.name);
  const ecoCodes = args.match.entries.map((entry) => entry.eco);
  const hierarchy = args.match.hierarchy.flatMap((entry) => entry.labelPath);
  const matchEvidence = toEvidence({
    type: 'opening',
    subtype: 'opening-match',
    status: 'confirmed',
    confidence: args.match.confidence,
    ply: args.ply,
    side: args.side,
    fen: args.fen,
    facts: [
      { key: 'matchKind', value: args.match.kind },
      { key: 'openingNames', value: openingNames },
      { key: 'ecoCodes', value: ecoCodes },
      { key: 'matchedPly', value: args.match.matchedPly },
      { key: 'hierarchy', value: [...new Set(hierarchy)] },
      { key: 'datasetCommit', value: args.match.dataset.commit },
      { key: 'license', value: args.match.dataset.license },
    ],
    references: [
      { kind: 'position', id: args.match.positionKey, ply: args.ply },
      ...args.match.entries.map((entry) => ({ kind: 'opening' as const, id: `${entry.eco}:${entry.name}`, ply: args.ply })),
      ...args.match.definingLines.slice(0, 8).map((line) => ({ kind: 'line' as const, id: `${line.eco}:${line.name}`, ply: args.ply, uciMoves: line.moves.map((move) => move.uci), sanMoves: line.moves.map((move) => move.san) })),
    ],
    source: `${args.match.dataset.repository}@${args.match.dataset.commit} (${args.match.dataset.license})`,
    analyser: 'opening-recognizer',
  });
  args.evidence.push(matchEvidence);
  const claims = [
    ...args.match.knowledge.typicalPlans,
    ...args.match.knowledge.pawnBreaks,
    ...args.match.knowledge.piecePlacements,
    ...args.match.knowledge.tacticalIdeas,
    ...args.match.knowledge.counterplans,
    ...args.match.knowledge.gambitStatus.map((item) => ({ ...item.finding, gambitState: item.state, gambitName: item.name })),
  ];
  for (const claim of claims) {
    const gambit = claim as KnowledgeFinding & { gambitState?: string; gambitName?: string };
    args.evidence.push(genericFinding({
      type: 'opening', subtype: claim.conceptId, state: 'candidate', finding: claim,
      fen: args.fen, ply: args.ply, fallbackSide: args.side,
      extraFacts: [
        { key: 'openingNames', value: openingNames },
        ...(gambit.gambitState ? [{ key: 'gambitState', value: gambit.gambitState }] : []),
        ...(gambit.gambitName ? [{ key: 'gambitName', value: gambit.gambitName }] : []),
      ],
      source: serializeProvenance(claim.provenance).join(' | '),
    }));
  }
}

function addTacticalDeferred(evidence: ChessEvidence[], reason: string, fen: string, ply: number, side: Color) {
  addDeferred({ evidence, type: 'tactic', subtype: 'unsupported-tactical-motif', reason, fen, ply, side, source: 'tactics-detector' });
}

export function aggregatePositionEvidence(args: PositionArgs): ChessEvidence[] {
  const position = new Chess(args.fen);
  const fen = position.fen({ forceEnpassantSquare: true });
  const side = position.turn();
  const evidence: ChessEvidence[] = [];
  const historyRecord = args.record && args.ply <= args.record.moveHistory.length
    ? {
        ...args.record,
        cursorPly: args.ply,
        currentFen: fenAtPly(args.record, args.ply),
        repetitionKeys: args.record.repetitionKeys.slice(0, args.ply + 1),
      }
    : undefined;

  if (args.catalog) {
    const uciMoves = historyRecord?.moveHistory.slice(0, args.ply).map((move) => move.uci) ?? [];
    const opening = lookupOpeningAtPosition(args.catalog, fen, uciMoves);
    if (opening) addOpeningEvidence({ evidence, match: opening, fen, ply: args.ply, side });
  }

  const tactical = analyzeTactics(position);
  for (const finding of tactical.findings) evidence.push(tacticalFindingEvidence(finding, fen, args.ply));
  if (args.includeDeferred) for (const deferred of tactical.deferredMotifs) addTacticalDeferred(evidence, deferred.reason, fen, args.ply, side);

  const attack = analyzeAttacks(position, historyRecord, tactical);
  for (const finding of attack.findings) {
    const related = finding.triggeringMove;
    addPositionFinding({
      evidence,
      finding,
      type: typeForAttack(finding),
      subtype: finding.motif,
      fen,
      ply: args.ply,
      sideToMove: side,
      side: finding.side,
      state: finding.state,
      boardEvidence: finding.boardEvidence,
      move: related,
      source: serializeProvenance(finding.provenance).join(' | '),
    });
  }
  if (args.includeDeferred) for (const limitation of attack.limitations) addDeferred({ evidence, type: 'attack', subtype: 'bounded-attack-coverage', reason: limitation, fen, ply: args.ply, side, source: 'attack-detector' });

  const defence = analyzeDefence(position, historyRecord, tactical);
  for (const threat of [...defence.threatAssessment.checks, ...defence.threatAssessment.captures, ...defence.threatAssessment.threats]) {
    const finding = threat as KnowledgeFinding;
    const state: EvidenceStatus = threat.state;
    addPositionFinding({
      evidence, finding, type: 'defence', subtype: `threat-${threat.category}`, fen, ply: args.ply, sideToMove: side,
      side: threat.side, state, boardEvidence: threat.evidence,
      move: threat.move,
      source: serializeProvenance(threat.provenance).join(' | '),
      extraFacts: [{ key: 'severityCue', value: threat.severity }, { key: 'targetSquares', value: threat.targetSquares }],
    });
  }
  for (const resource of defence.resources) {
    addPositionFinding({
      evidence, finding: resource, type: 'defence', subtype: resource.motif, fen, ply: args.ply, sideToMove: side,
      side: resource.side, state: resource.state, boardEvidence: resource.boardEvidence,
      move: resource.triggeringMove, lines: tacticalLines(resource),
      legalLineValidation: copyLegalLineValidation(resource.legalLine),
      source: serializeProvenance(resource.provenance).join(' | '),
      extraFacts: [{ key: 'possibleConsequence', value: resource.possibleConsequence }],
    });
  }
  if (args.includeDeferred) for (const deferred of defence.deferredResources) addDeferred({ evidence, type: 'defence', subtype: deferred.motif, reason: deferred.reason, fen, ply: args.ply, side, source: 'defence-detector' });

  const endgames = analyzeEndgames(position, historyRecord, tactical);
  // Preserve the detector's material-phase output even when no named endgame
  // motif is present, so adjacent-move classification can compare the shared
  // evidence record instead of duplicating phase rules.
  evidence.push(toEvidence({
    type: 'endgame',
    subtype: 'material-phase-profile',
    status: 'confirmed',
    confidence: 'high',
    ply: args.ply,
    side,
    fen,
    facts: [
      { key: 'endgamePhase', value: endgames.phase },
      { key: 'basis', value: 'endgame detector material inventory' },
      { key: 'isEngineEvaluation', value: false },
    ],
    references: [
      { kind: 'position', id: positionKey(position), ply: args.ply },
      { kind: 'detector', id: 'endgame.material-profile' },
    ],
    source: 'endgame-detector (material inventory)',
    analyser: 'endgame-detector',
  }));
  for (const finding of endgames.findings) {
    addPositionFinding({
      evidence, finding, type: 'endgame', subtype: finding.motif, fen, ply: args.ply, sideToMove: side,
      side: finding.side, state: finding.state, boardEvidence: finding.boardEvidence,
      move: finding.triggeringMove, lines: tacticalLines(finding),
      legalLineValidation: finding.legalLine ? copyLegalLineValidation(finding.legalLine) : undefined,
      source: serializeProvenance(finding.provenance).join(' | '),
      extraFacts: [{ key: 'possibleConsequence', value: finding.possibleConsequence }, { key: 'endgamePhase', value: endgames.phase }],
    });
  }
  if (args.includeDeferred) for (const deferred of endgames.deferredMotifs) addDeferred({ evidence, type: 'endgame', subtype: deferred.motif, reason: deferred.reason, fen, ply: args.ply, side, source: 'endgame-detector' });

  const strategies = analyzeStrategyPosition({
    fen,
    ...(args.record ? { history: { initialFen: args.record.initialPosition.fen, uciMoves: args.record.moveHistory.slice(0, args.ply).map((move) => move.uci) } } : {}),
  });
  for (const finding of strategies.findings) {
    addPositionFinding({
      evidence, finding, type: typeForStrategy(finding), subtype: finding.concept, fen, ply: args.ply,
      sideToMove: side, side: finding.side, state: finding.candidate ? 'candidate' : 'confirmed',
      source: serializeProvenance(finding.provenance).join(' | '),
      extraFacts: [{ key: 'possiblePlan', value: finding.possiblePlan }],
    });
  }
  if (args.includeDeferred) for (const deferred of strategies.deferred) addDeferred({ evidence, type: 'strategy', subtype: deferred.concept, reason: deferred.reason, fen, ply: args.ply, side, source: 'strategy-detector' });

  const structures = analyzePawnStructures(fen);
  for (const finding of structures.findings) {
    addPositionFinding({
      evidence, finding, type: 'pawn_structure', subtype: finding.structure, fen, ply: args.ply,
      sideToMove: side, side: finding.side, state: finding.candidate ? 'candidate' : 'confirmed',
      source: serializeProvenance(finding.provenance).join(' | '),
      extraFacts: [{ key: 'possiblePlan', value: finding.possiblePlan }],
    });
  }
  if (args.includeDeferred) for (const deferred of structures.deferred) addDeferred({ evidence, type: 'pawn_structure', subtype: deferred.structure, reason: deferred.reason, fen, ply: args.ply, side, source: 'pawn-structure-detector' });

  const positionFacts = analyzeStaticPosition(fen);
  for (const fact of [...positionFacts.facts, ...positionFacts.candidates]) evidence.push(boardFactEvidence(fact, fen, args.ply, side));

  return aggregateEvidenceBatches([evidence]);
}

function replayRecord(record: GameRecord): { fens: string[]; moves: ReplayedMove[] } {
  if (!record || !record.initialPosition?.fen || !Array.isArray(record.moveHistory) || !Array.isArray(record.repetitionKeys)) throw new TypeError('Evidence aggregation requires a complete canonical game record.');
  if (record.repetitionKeys.length !== record.moveHistory.length + 1) throw new Error('Evidence aggregation rejected inconsistent repetition history.');
  if (!Number.isInteger(record.cursorPly) || record.cursorPly < 0 || record.cursorPly > record.moveHistory.length) throw new RangeError('Evidence aggregation rejected an invalid game cursor.');
  const chess = new Chess(record.initialPosition.fen);
  const fens = [chess.fen({ forceEnpassantSquare: true })];
  const keys = [positionKey(chess)];
  const moves: ReplayedMove[] = [];
  for (const [index, entry] of record.moveHistory.entries()) {
    const before = new Chess(chess.fen({ forceEnpassantSquare: true }));
    const beforeFen = before.fen({ forceEnpassantSquare: true });
    if (entry.ply !== index + 1 || positionKey(before) !== entry.beforeKey || positionKey(new Chess(entry.beforeFen)) !== entry.beforeKey) throw new Error(`Evidence aggregation rejected inconsistent history at ply ${entry.ply}.`);
    const candidate = chess.moves({ verbose: true }).find((move) => uciForMove(move) === entry.uci);
    if (!candidate) throw new Error(`Evidence aggregation rejected illegal move ${entry.uci} at ply ${entry.ply}.`);
    const applied = chess.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) });
    if (applied.san !== entry.san || uciForMove(applied) !== entry.uci) throw new Error(`Evidence aggregation rejected mismatched SAN/UCI at ply ${entry.ply}.`);
    const after = new Chess(chess.fen({ forceEnpassantSquare: true }));
    const afterFen = after.fen({ forceEnpassantSquare: true });
    const keyBefore = positionKey(before);
    const keyAfter = positionKey(after);
    if (keyAfter !== entry.afterKey || positionKey(new Chess(entry.afterFen)) !== entry.afterKey) throw new Error(`Evidence aggregation rejected inconsistent result at ply ${entry.ply}.`);
    keys.push(keyAfter);
    fens.push(afterFen);
    moves.push({ ply: index + 1, beforeFen, afterFen, move: applied, before, after, positionKeyBefore: keyBefore, positionKeyAfter: keyAfter });
  }
  if (keys.some((key, index) => key !== record.repetitionKeys[index])) throw new Error('Evidence aggregation rejected inconsistent repetition keys.');
  if (positionKey(new Chess(record.currentFen)) !== keys[record.cursorPly]) throw new Error('Evidence aggregation rejected a cursor FEN that does not match replayed history.');
  return { fens, moves };
}

function eventPriority(event: ReplayedMove): number {
  const move = event.move;
  if (event.after.isCheckmate()) return 1000;
  if (move.promotion) return 900;
  if (event.after.isCheck()) return 850;
  if (move.isCapture() && move.captured === 'q') return 800;
  if (move.isCapture() && move.captured === 'r') return 700;
  if (move.isCapture()) return 500;
  if (move.piece === 'p' && ['d4', 'e4', 'd5', 'e5'].includes(move.to)) return 350;
  if (move.flags.includes('k') || move.flags.includes('q')) return 300;
  return 0;
}

function chooseAnalyzedPlies(moves: ReplayedMove[], maxPositions: number): number[] {
  const lastPly = moves.length;
  const cap = Math.max(1, Math.floor(maxPositions));
  if (lastPly + 1 <= cap) return Array.from({ length: lastPly + 1 }, (_, ply) => ply);
  if (cap === 1) return [lastPly];
  const selected = new Set<number>([0, lastPly]);
  const events = moves
    .map((event) => ({ event, priority: eventPriority(event) }))
    .filter((entry) => entry.priority > 0)
    .sort((a, b) => b.priority - a.priority || a.event.ply - b.event.ply);
  for (const { event } of events) {
    const neighbors = [event.ply - 1, event.ply];
    const additions = neighbors.filter((ply) => !selected.has(ply));
    if (selected.size + additions.length <= cap) additions.forEach((ply) => selected.add(ply));
  }
  if (selected.size < cap) {
    const step = lastPly / Math.max(1, cap - 1);
    for (let index = 0; index < cap && selected.size < cap; index += 1) selected.add(Math.round(index * step));
  }
  if (selected.size < cap) {
    for (let ply = 0; ply <= lastPly && selected.size < cap; ply += 1) selected.add(ply);
  }
  return [...selected].sort((a, b) => a - b);
}

function materialPoints(position: Chess, side: Color): number {
  const values: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  return position.board().flat().reduce((total, piece) => total + (piece?.color === side ? values[piece.type] : 0), 0);
}

function moveHistoryEvidence(record: GameRecord, event: ReplayedMove): ChessEvidence {
  const move = event.move;
  const side = move.color;
  const captured = move.captured as PieceSymbol | undefined;
  const whiteBefore = materialPoints(event.before, 'w');
  const whiteAfter = materialPoints(event.after, 'w');
  const blackBefore = materialPoints(event.before, 'b');
  const blackAfter = materialPoints(event.after, 'b');
  const whitePerspectiveDelta = (whiteAfter - whiteBefore) - (blackAfter - blackBefore);
  const facts: EvidenceFact[] = [
    { key: 'san', value: move.san },
    { key: 'uci', value: uciForMove(move) },
    { key: 'piece', value: move.piece },
    { key: 'capture', value: move.isCapture() },
    { key: 'capturedPiece', value: captured ?? 'none' },
    { key: 'check', value: event.after.isCheck() },
    { key: 'checkmate', value: event.after.isCheckmate() },
    { key: 'stalemate', value: event.after.isStalemate() },
    { key: 'promotion', value: move.promotion ?? 'none' },
    { key: 'materialPointsWhiteBefore', value: whiteBefore },
    { key: 'materialPointsWhiteAfter', value: whiteAfter },
    { key: 'materialPointsBlackBefore', value: blackBefore },
    { key: 'materialPointsBlackAfter', value: blackAfter },
    { key: 'whitePerspectiveMaterialDelta', value: whitePerspectiveDelta },
    { key: 'materialWeights', value: ['p=1', 'n=3', 'b=3', 'r=5', 'q=9'] },
    { key: 'materialCountOnly', value: true },
    { key: 'isEngineEvaluation', value: false },
    { key: 'source', value: record.moveHistory[event.ply - 1]?.source ?? 'unknown' },
  ];
  const references: EvidenceReference[] = [
    { kind: 'move', id: uciForMove(move), ply: event.ply, uciMoves: [uciForMove(move)], sanMoves: [move.san] },
    { kind: 'position', id: event.positionKeyBefore, ply: event.ply - 1 },
    { kind: 'position', id: event.positionKeyAfter, ply: event.ply },
  ];
  return toEvidence({
    type: 'move_classification', subtype: 'move-history', status: 'confirmed', confidence: 'high', ply: event.ply, side,
    fen: event.beforeFen, san: move.san, uci: uciForMove(move), facts, references,
    source: 'canonical-game-history (replayed with chess.js)', analyser: 'move-history-adapter',
  });
}

export async function aggregateGameEvidence(
  record: GameRecord,
  catalog?: OpeningCatalog,
  options: AggregationOptions = {},
): Promise<ChessEvidenceAggregation> {
  const replay = replayRecord(record);
  const maxPositions = options.maxAnalyzedPositions ?? DEFAULT_MAX_ANALYZED_POSITIONS;
  if (!Number.isInteger(maxPositions) || maxPositions < 1 || maxPositions > 512) throw new RangeError('maxAnalyzedPositions must be between 1 and 512.');
  const selectedPlies = chooseAnalyzedPlies(replay.moves, maxPositions);
  const evidenceBatches: ChessEvidenceBatch[] = [
    replay.moves.map((event) => moveHistoryEvidence(record, event)),
    detectRepetitionEvidence(record, replay),
  ];
  const positions: PositionEvidenceIndex[] = [];
  const finalPly = replay.moves.length;
  for (const ply of selectedPlies) {
    const fen = replay.fens[ply];
    const sideToMove = new Chess(fen).turn();
    const positionEvidence = aggregatePositionEvidence({
      fen,
      ply,
      sideToMove,
      record,
      catalog,
      includeDeferred: ply === finalPly,
    });
    evidenceBatches.push(positionEvidence);
    positions.push({ ply, fen, evidenceIds: positionEvidence.map((entry) => entry.evidenceId) });
    if (options.yieldToEventLoop !== false) await new Promise<void>((resolve) => setTimeout(resolve, 0));
  }
  const containsOpeningMatch = evidenceBatches.some((batch) => batch.some((entry) => entry.type === 'opening' && entry.subtype === 'opening-match'));
  if (!catalog || !containsOpeningMatch) {
    const fen = replay.fens[finalPly];
    const openingStatus: ChessEvidence[] = [];
    addDeferred({
      evidence: openingStatus,
      type: 'opening',
      subtype: catalog ? 'opening-not-recognized' : 'opening-catalog-unavailable',
      reason: catalog
        ? 'No indexed opening position was recognized in the analyzed history; this does not imply an opening error or knowledge gap.'
        : 'The bundled opening catalog was not available during this review; no opening label was inferred.',
      fen,
      ply: finalPly,
      side: new Chess(fen).turn(),
      source: 'opening-recognizer',
    });
    evidenceBatches.push(openingStatus);
  }
  const selected = new Set(selectedPlies);
  const omitted = Array.from({ length: finalPly + 1 }, (_, ply) => ply).filter((ply) => !selected.has(ply));
  if (omitted.length) {
    const fen = replay.fens[omitted[0]];
    const coverageEvidence: ChessEvidence[] = [];
    addDeferred({ evidence: coverageEvidence, type: 'transition', subtype: 'detector-budget', reason: `Deep detectors were applied to ${selectedPlies.length} of ${finalPly + 1} positions. Positions outside the deterministic selection are not claimed to be motif-free.`, fen, ply: omitted[0], side: new Chess(fen).turn(), source: 'evidence-aggregation' });
    evidenceBatches.push(coverageEvidence);
  }
  const deduplicated = aggregateEvidenceBatches(evidenceBatches);
  return {
    schemaVersion: 1,
    gameId: record.id,
    totalPlies: finalPly,
    analyzedPositionPlies: selectedPlies,
    positions,
    evidence: deduplicated,
    limitations: [
      `Expensive position detectors are bounded to ${selectedPlies.length} deterministic position(s); skipped positions have an explicit deferred record.`,
      'All imported or saved moves are legally replayed with chess.js before analysis; the source GameRecord is never mutated.',
      'Database/opening or static structural findings are recognition cues, not engine evaluations or claims about player intent.',
      'No engine, rating, accuracy, blunder, best-move, or human-intent evidence is created.',
    ],
  };
}

export function evidenceTypeForFinding(finding: { conceptId: string; motif?: string; structure?: string; concept?: string }): EvidenceType {
  if (finding.conceptId.startsWith('opening.')) return 'opening';
  if (finding.conceptId.startsWith('tactics.')) return 'tactic';
  if (finding.conceptId.startsWith('attack.')) return finding.conceptId.includes('exposed-king') ? 'king_safety' : 'attack';
  if (finding.conceptId.startsWith('defence.')) return 'defence';
  if (finding.conceptId.startsWith('endgame.')) return 'endgame';
  if (finding.conceptId.startsWith('pawn-structure.')) return 'pawn_structure';
  if (finding.conceptId.startsWith('strategy.')) return finding.conceptId.includes('king-safety') ? 'king_safety' : 'strategy';
  return 'transition';
}
