import type { GameRecord } from '../domain/chess/types';
import type { ChessEvidence } from './evidence';
import { aggregateEvidenceBatches, aggregateGameEvidence, DEFAULT_MAX_ANALYZED_POSITIONS } from './evidenceAggregation';
import type { OpeningCatalog } from './openings';
import { classifyMoves, type MoveClassificationResult } from './moveClassifier';
import { detectKeyMoments, type KeyMomentResult } from './keyMoments';
import { explainChessEvidence, type ExplanationResult } from './explanations';

export type ReviewAnalysisOptions = {
  catalog?: OpeningCatalog;
  maxAnalyzedPositions?: number;
};
export type ReviewAnalysisReport = {
  schemaVersion: 1;
  gameId: string;
  totalPlies: number;
  aggregationPlies: number[];
  evidence: ChessEvidence[];
  classification: MoveClassificationResult;
  keyMoments: KeyMomentResult;
  explanations: ExplanationResult;
  limitations: string[];
};

/** Local deterministic orchestration for Review. It derives sidecar analysis only. */
export async function analyzeReviewRecord(record: GameRecord, options: ReviewAnalysisOptions = {}): Promise<ReviewAnalysisReport> {
  const aggregation = await aggregateGameEvidence(record, options.catalog, {
    maxAnalyzedPositions: options.maxAnalyzedPositions ?? DEFAULT_MAX_ANALYZED_POSITIONS,
  });
  const classification = classifyMoves(record, aggregation);
  const momentInputs = aggregateEvidenceBatches([aggregation.evidence, classification.evidence]);
  const keyMoments = detectKeyMoments(momentInputs);
  const allEvidence = aggregateEvidenceBatches([momentInputs, keyMoments.evidence]);
  const explanations = explainChessEvidence(allEvidence);
  return {
    schemaVersion: 1,
    gameId: record.id,
    totalPlies: aggregation.totalPlies,
    aggregationPlies: aggregation.analyzedPositionPlies,
    evidence: allEvidence,
    classification,
    keyMoments,
    explanations,
    limitations: [
      ...aggregation.limitations,
      ...classification.limitations,
      ...explanations.limitations,
      'Review analysis is stored separately from the canonical game history; move records are never rewritten by analysis.',
    ],
  };
}
