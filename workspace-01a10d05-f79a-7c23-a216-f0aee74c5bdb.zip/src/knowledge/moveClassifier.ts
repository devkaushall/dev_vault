import { Chess, SQUARES, type Color, type Move, type PieceSymbol, type Square } from 'chess.js';
import type { GameRecord } from '../domain/chess/types';
import { positionKey, uciForMove } from '../domain/chess/position';
import {
  confidenceLevel,
  createChessEvidence,
  type ChessEvidence,
  type EvidenceConfidence,
  type EvidenceStatus,
} from './evidence';
import type { ChessEvidenceAggregation } from './evidenceAggregation';

export const MOVE_CLASSIFICATION_CATEGORIES = [
  'normal-developing-move',
  'capture',
  'check',
  'checkmate',
  'stalemate',
  'material-change',
  'tactical-move',
  'defensive-move',
  'pawn-break',
  'king-safety-change',
  'piece-activity-change',
  'exchange-trade',
  'promotion-endgame-transition',
  'opening-transition',
  'strategic-move',
  'candidate-tactical-mistake',
  'unknown',
  'deferred',
] as const;

export type MoveClassificationCategory = (typeof MOVE_CLASSIFICATION_CATEGORIES)[number];
export type MoveCategoryFinding = {
  category: MoveClassificationCategory;
  status: EvidenceStatus;
  confidence: EvidenceConfidence;
  evidenceId: string;
  explanation: string;
  relatedEvidenceIds: string[];
};
export type ClassifiedMove = {
  ply: number;
  san: string;
  uci: string;
  side: Color;
  status: EvidenceStatus;
  categories: MoveCategoryFinding[];
  evidenceIds: string[];
  detectorCoverage: 'analyzed' | 'deferred';
};
export type MoveClassificationResult = {
  schemaVersion: 1;
  gameId: string;
  moves: ClassifiedMove[];
  evidence: ChessEvidence[];
  limitations: string[];
};

type MoveContext = {
  ply: number;
  move: Move;
  uci: string;
  before: Chess;
  after: Chess;
  beforeKey: string;
  afterKey: string;
};

type CategoryDraft = {
  category: MoveClassificationCategory;
  status: EvidenceStatus;
  confidence: number;
  explanation: string;
  facts: Array<{ key: string; value: string | number | boolean | string[] }>;
  relatedEvidence: ChessEvidence[];
};
type OneMoveClassification = { move: ClassifiedMove; evidence: ChessEvidence[] };

const MATERIAL: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const CENTRAL_SQUARES = new Set<Square>(['d4', 'e4', 'd5', 'e5']);
const HOME_MINOR_SQUARES = new Set<Square>(['b1', 'g1', 'c1', 'f1', 'b8', 'g8', 'c8', 'f8']);

function pieceName(piece: PieceSymbol | undefined): string {
  return piece ? ({ p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king' } as const)[piece] : 'piece';
}

function safePositionKey(fen: string): string {
  return positionKey(new Chess(fen));
}

function moveContexts(record: GameRecord): MoveContext[] {
  const chess = new Chess(record.initialPosition.fen);
  const contexts: MoveContext[] = [];
  for (const entry of record.moveHistory) {
    const before = new Chess(chess.fen({ forceEnpassantSquare: true }));
    const legal = chess.moves({ verbose: true }).find((candidate) => uciForMove(candidate) === entry.uci);
    if (!legal) throw new Error(`Move classifier rejected illegal history at ply ${entry.ply}.`);
    const applied = chess.move({ from: legal.from, to: legal.to, ...(legal.promotion ? { promotion: legal.promotion } : {}) });
    if (applied.san !== entry.san || uciForMove(applied) !== entry.uci) throw new Error(`Move classifier rejected mismatched history at ply ${entry.ply}.`);
    const after = new Chess(chess.fen({ forceEnpassantSquare: true }));
    contexts.push({
      ply: entry.ply,
      move: applied,
      uci: entry.uci,
      before,
      after,
      beforeKey: positionKey(before),
      afterKey: positionKey(after),
    });
  }
  return contexts;
}

function evidenceAtPosition(evidence: ChessEvidence[], key: string): ChessEvidence[] {
  return evidence.filter((item) => {
    try { return safePositionKey(item.position.fen) === key; }
    catch { return false; }
  });
}

function fact(item: ChessEvidence, key: string): string | number | boolean | string[] | undefined {
  return item.facts.find((entry) => entry.key === key)?.value;
}

function mentionsMove(item: ChessEvidence, uci: string, positionKeyBefore: string): boolean {
  if (item.position.uci !== uci) return false;
  try {
    if (safePositionKey(item.position.fen) !== positionKeyBefore) return false;
  } catch {
    return false;
  }
  return item.references.some((reference) => reference.kind === 'move' && reference.uciMoves?.includes(uci));
}

function newCategory(args: CategoryDraft): CategoryDraft {
  return args;
}

function kingSafetySignature(evidence: ChessEvidence[]): string[] {
  const relevantFields = new Set([
    'title', 'description', 'kingSquare', 'shieldPawns', 'missingShieldSquares',
    'geometricAttackers', 'openFiles', 'check', 'sideToMove',
  ]);
  return evidence
    .filter((item) => item.type === 'king_safety')
    .map((item) => {
      const salientFacts = item.facts
        .filter((entry) => relevantFields.has(entry.key.split('.').at(-1) ?? entry.key))
        .map((entry) => [entry.key.split('.').at(-1) ?? entry.key, entry.value] as const)
        .sort((a, b) => JSON.stringify(a) < JSON.stringify(b) ? -1 : JSON.stringify(a) > JSON.stringify(b) ? 1 : 0);
      return `${item.subtype}:${item.side}:${item.status}:${JSON.stringify(salientFacts)}`;
    })
    .sort();
}

function endgamePhaseEvidence(evidence: ChessEvidence[]): string | undefined {
  const profile = evidence.find((item) => item.type === 'endgame' && item.subtype === 'material-phase-profile');
  const phase = profile?.facts.find((entry) => entry.key === 'endgamePhase')?.value;
  return typeof phase === 'string' ? phase : undefined;
}

function nonPawnActivity(position: Chess, side: Color): number {
  let count = 0;
  for (const target of SQUARES) {
    if (position.attackers(target, side).some((source) => {
      const piece = position.get(source);
      return piece?.type !== 'p' && piece?.type !== 'k';
    })) count += 1;
  }
  return count;
}

function buildCategoryEvidence(context: MoveContext, draft: CategoryDraft): ChessEvidence {
  const relatedIds = draft.relatedEvidence.map((item) => item.evidenceId);
  const references = [
    { kind: 'move' as const, id: context.uci, ply: context.ply, uciMoves: [context.uci], sanMoves: [context.move.san], description: 'Actual move replayed legally from the canonical history.' },
    { kind: 'position' as const, id: context.beforeKey, ply: context.ply - 1, description: 'Validated position immediately before the move.' },
    { kind: 'position' as const, id: context.afterKey, ply: context.ply, description: 'Validated position immediately after the move.' },
    ...draft.relatedEvidence.map((item) => ({ kind: 'detector' as const, id: item.evidenceId, ply: item.ply, description: `${item.type}/${item.subtype} evidence.` })),
    ...draft.relatedEvidence.flatMap((item) => item.references.filter((reference) => reference.kind === 'opening').map((reference) => ({ ...reference }))),
  ];
  const lines = draft.relatedEvidence
    .filter((item) => {
      try { return safePositionKey(item.position.fen) === context.beforeKey; }
      catch { return false; }
    })
    .flatMap((item) => item.lines ?? [])
    .filter((line, index, all) => all.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(line)) === index);
  return createChessEvidence({
    type: 'move_classification',
    subtype: draft.category,
    status: draft.status,
    confidence: confidenceLevel(draft.confidence),
    ply: context.ply,
    side: context.move.color === 'w' ? 'white' : 'black',
    position: { fen: context.before.fen({ forceEnpassantSquare: true }), moveNumber: Number(context.before.fen().split(' ')[5]), san: context.move.san, uci: context.uci },
    facts: [
      { key: 'category', value: draft.category },
      { key: 'san', value: context.move.san },
      { key: 'uci', value: context.uci },
      { key: 'explanation', value: draft.explanation },
      { key: 'relatedEvidenceIds', value: relatedIds },
      ...draft.facts,
    ],
    references,
    source: 'legal chess.js move replay + Phase 7 evidence aggregation',
    ...(lines.length ? { lines } : {}),
    explanation: {
      whatHappened: `${context.move.san}: ${draft.explanation}`,
      whyItMatters: draft.explanation,
      possibleIdea: draft.status === 'candidate' ? 'This is a candidate interpretation of the board evidence, not a claim about player intent.' : undefined,
      concept: draft.category,
      learningTakeaway: 'Use the recorded move, resulting position, and cited evidence; this classification is not an engine judgment.',
    },
    createdBy: { analyser: 'move-classifier', version: '1.0.0' },
  });
}

function classifyOne(context: MoveContext, aggregation: ChessEvidenceAggregation, contextsByPly: Map<number, MoveContext>): OneMoveClassification {
  const categories: CategoryDraft[] = [];
  const add = (draft: CategoryDraft) => {
    if (!categories.some((item) => item.category === draft.category && item.explanation === draft.explanation)) categories.push(draft);
  };
  const allEvidence = aggregation.evidence;
  const beforeEvidence = evidenceAtPosition(allEvidence, context.beforeKey);
  const afterEvidence = evidenceAtPosition(allEvidence, context.afterKey);
  const actualMoveEvidence = allEvidence.find((item) => item.type === 'move_classification' && item.subtype === 'move-history' && item.ply === context.ply && item.position.uci === context.uci);
  if (!actualMoveEvidence) throw new Error(`Move classifier found no replay evidence for ply ${context.ply}.`);

  if (context.move.isCapture()) add(newCategory({
    category: 'capture', status: 'confirmed', confidence: 1,
    explanation: `The legal move captures a ${pieceName(context.move.captured as PieceSymbol | undefined)}.`,
    facts: [{ key: 'capture', value: true }, { key: 'capturedPiece', value: context.move.captured ?? 'unknown' }, { key: 'capturedMaterialClass', value: MATERIAL[context.move.captured as PieceSymbol] ?? 0 }],
    relatedEvidence: [actualMoveEvidence],
  }));
  if (context.after.isCheckmate()) add(newCategory({
    category: 'checkmate', status: 'confirmed', confidence: 1,
    explanation: 'The legal move leaves the opponent in check with no legal reply according to chess.js.',
    facts: [{ key: 'checkmate', value: true }, { key: 'legalReplies', value: 0 }], relatedEvidence: [actualMoveEvidence],
  }));
  else if (context.after.isCheck()) add(newCategory({
    category: 'check', status: 'confirmed', confidence: 1,
    explanation: 'The legal move gives check according to chess.js.', facts: [{ key: 'check', value: true }], relatedEvidence: [actualMoveEvidence],
  }));
  else if (context.after.isStalemate()) add(newCategory({
    category: 'stalemate', status: 'confirmed', confidence: 1,
    explanation: 'The legal move leaves the side to move with no legal moves and not in check, according to chess.js.',
    facts: [{ key: 'stalemate', value: true }, { key: 'legalReplies', value: 0 }], relatedEvidence: [actualMoveEvidence],
  }));

  const materialDelta = fact(actualMoveEvidence, 'whitePerspectiveMaterialDelta');
  if (typeof materialDelta === 'number' && materialDelta !== 0) add(newCategory({
    category: 'material-change', status: 'confirmed', confidence: 1,
    explanation: `The legal move changes the recorded material balance by ${materialDelta > 0 ? '+' : ''}${materialDelta} point(s) from White's perspective using simple piece weights; this is not an engine evaluation.`,
    facts: [
      { key: 'whitePerspectiveMaterialDelta', value: materialDelta },
      ...(['materialPointsWhiteBefore', 'materialPointsWhiteAfter', 'materialPointsBlackBefore', 'materialPointsBlackAfter'] as const).flatMap((key) => {
        const value = fact(actualMoveEvidence, key);
        return typeof value === 'number' ? [{ key, value }] : [];
      }),
      { key: 'materialCountOnly', value: fact(actualMoveEvidence, 'materialCountOnly') === true },
      { key: 'isEngineEvaluation', value: false },
    ],
    relatedEvidence: [actualMoveEvidence],
  }));

  if (context.move.promotion) add(newCategory({
    category: 'promotion-endgame-transition', status: 'confirmed', confidence: 1,
    explanation: `The legal pawn move promotes to a ${pieceName(context.move.promotion)}.`, facts: [{ key: 'promotion', value: context.move.promotion }], relatedEvidence: [actualMoveEvidence],
  }));
  const phaseBefore = endgamePhaseEvidence(beforeEvidence);
  const phaseAfter = endgamePhaseEvidence(afterEvidence);
  if (phaseBefore && phaseAfter && phaseBefore !== phaseAfter && phaseAfter !== 'mixed-or-middlegame') add(newCategory({
    category: 'promotion-endgame-transition', status: 'confirmed', confidence: 0.98,
    explanation: `The endgame detector's material profile changes from ${phaseBefore} to ${phaseAfter}; this identifies a piece-inventory class, not a theoretical result.`,
    facts: [{ key: 'phaseBefore', value: phaseBefore }, { key: 'phaseAfter', value: phaseAfter }],
    relatedEvidence: [...beforeEvidence, ...afterEvidence].filter((item) => item.type === 'endgame'),
  }));

  if (context.move.piece === 'n' || context.move.piece === 'b') {
    if (HOME_MINOR_SQUARES.has(context.move.from) && !HOME_MINOR_SQUARES.has(context.move.to)) add(newCategory({
      category: 'normal-developing-move', status: 'candidate', confidence: 0.68,
      explanation: `The ${pieceName(context.move.piece)} legally leaves its starting square; development value is not evaluated.`,
      facts: [{ key: 'from', value: context.move.from }, { key: 'to', value: context.move.to }], relatedEvidence: [actualMoveEvidence],
    }));
  }

  const matchingCandidates = beforeEvidence.filter((item) => mentionsMove(item, context.uci, context.beforeKey));
  const tactical = matchingCandidates.filter((item) => item.type === 'tactic');
  if (tactical.length) add(newCategory({
    category: 'tactical-move',
    status: tactical.some((item) => item.status === 'confirmed') ? 'confirmed' : 'candidate',
    confidence: tactical.some((item) => item.status === 'confirmed') ? 0.96 : 0.62,
    explanation: tactical.some((item) => item.status === 'confirmed')
      ? `The played move matches a confirmed ${tactical[0].subtype.replaceAll('-', ' ')} finding.`
      : `The played move matches a candidate ${tactical[0].subtype.replaceAll('-', ' ')} cue; its material or positional outcome is not established.`,
    facts: [{ key: 'motifs', value: tactical.map((item) => item.subtype) }], relatedEvidence: tactical,
  }));
  const defensive = matchingCandidates.filter((item) => item.type === 'defence' && !item.subtype.startsWith('threat-'));
  if (defensive.length) add(newCategory({
    category: 'defensive-move',
    status: defensive.some((item) => item.status === 'confirmed') ? 'confirmed' : 'candidate',
    confidence: defensive.some((item) => item.status === 'confirmed') ? 0.94 : 0.62,
    explanation: defensive.some((item) => item.status === 'confirmed')
      ? `The move matches a legally verified ${defensive[0].subtype.replaceAll('-', ' ')} resource; no ranking against alternatives is made.`
      : `The move matches a candidate ${defensive[0].subtype.replaceAll('-', ' ')} resource; defensive quality is not evaluated.`,
    facts: [{ key: 'resourceMotifs', value: defensive.map((item) => item.subtype) }], relatedEvidence: defensive,
  }));

  const pawnBreak = matchingCandidates.filter((item) => item.type === 'attack' && item.subtype === 'central-break');
  if (pawnBreak.length || context.move.piece === 'p' && CENTRAL_SQUARES.has(context.move.to)) add(newCategory({
    category: 'pawn-break', status: pawnBreak.some((item) => item.status === 'confirmed') ? 'confirmed' : 'candidate', confidence: pawnBreak.length ? 0.68 : 0.56,
    explanation: pawnBreak.length ? 'The played legal pawn move matches a central-break detector cue.' : 'The legal pawn move enters or captures on a central square; strategic value is not evaluated.',
    facts: [{ key: 'centralSquare', value: context.move.to }, { key: 'capture', value: context.move.isCapture() }], relatedEvidence: pawnBreak.length ? pawnBreak : [actualMoveEvidence],
  }));

  const structureBefore = new Set(beforeEvidence.filter((item) => ['strategy', 'pawn_structure'].includes(item.type) && item.status !== 'deferred').map((item) => `${item.type}:${item.subtype}`));
  const newStructuralEvidence = afterEvidence.filter((item) => ['strategy', 'pawn_structure'].includes(item.type) && item.status !== 'deferred' && !structureBefore.has(`${item.type}:${item.subtype}`));
  if (newStructuralEvidence.length) add(newCategory({
    category: 'strategic-move', status: 'candidate', confidence: 0.58,
    explanation: 'The resulting position adds a strategy or pawn-structure cue that was not present in the analyzed pre-move position; no plan quality is judged.',
    facts: [{ key: 'newConcepts', value: newStructuralEvidence.map((item) => item.subtype) }], relatedEvidence: newStructuralEvidence,
  }));

  const beforeSafety = kingSafetySignature(beforeEvidence);
  const afterSafety = kingSafetySignature(afterEvidence);
  const safetyChanged = JSON.stringify(beforeSafety) !== JSON.stringify(afterSafety);
  if (safetyChanged) add(newCategory({
    category: 'king-safety-change', status: 'candidate', confidence: 0.55,
    explanation: 'The analyzed king-safety evidence changes across the before/after positions; these cues do not prove a forced attack.',
    facts: [
      { key: 'beforeEvidenceProfile', value: beforeSafety },
      { key: 'afterEvidenceProfile', value: afterSafety },
    ], relatedEvidence: [...beforeEvidence, ...afterEvidence].filter((item) => item.type === 'king_safety'),
  }));

  const activityBefore = nonPawnActivity(context.before, context.move.color);
  const activityAfter = nonPawnActivity(context.after, context.move.color);
  if (Math.abs(activityAfter - activityBefore) >= 3) add(newCategory({
    category: 'piece-activity-change', status: 'candidate', confidence: 0.49,
    explanation: 'The mover side changes the number of squares controlled geometrically by non-pawn, non-king pieces by at least three; this is an activity cue, not a positional evaluation.',
    facts: [{ key: 'controlledSquaresBefore', value: activityBefore }, { key: 'controlledSquaresAfter', value: activityAfter }, { key: 'delta', value: activityAfter - activityBefore }],
    relatedEvidence: [...beforeEvidence, ...afterEvidence].filter((item) => item.type === 'strategy'),
  }));

  if (context.move.isCapture()) {
    const next = contextsByPly.get(context.ply + 1);
    const capturedBack = next?.beforeKey === context.afterKey && next.move.isCapture() && next.move.to === context.move.to && next.move.captured === context.move.piece;
    if (capturedBack && next) add(newCategory({
      category: 'exchange-trade', status: 'confirmed', confidence: 0.97,
      explanation: `The captured piece is legally recaptured on ${context.move.to} on the next ply; an exchange occurred, but its value is not ranked.`,
      facts: [{ key: 'recaptureUci', value: next.uci }, { key: 'square', value: context.move.to }], relatedEvidence: [actualMoveEvidence],
    }));
  }

  const beforeOpening = beforeEvidence.filter((item) => item.type === 'opening' && item.subtype === 'opening-match');
  const afterOpening = afterEvidence.filter((item) => item.type === 'opening' && item.subtype === 'opening-match');
  const previousLabels = new Set(beforeOpening.flatMap((item) => Array.isArray(fact(item, 'openingNames')) ? fact(item, 'openingNames') as string[] : []));
  const newOpeningEvidence = afterOpening.filter((item) => (Array.isArray(fact(item, 'openingNames')) ? fact(item, 'openingNames') as string[] : []).some((name) => !previousLabels.has(name)));
  if (newOpeningEvidence.length) add(newCategory({
    category: 'opening-transition', status: 'confirmed', confidence: 0.92,
    explanation: 'The post-move position reaches a newly recognized opening-index entry; this is a database transition, not an evaluation of the move.',
    facts: [{ key: 'openingNames', value: newOpeningEvidence.flatMap((item) => Array.isArray(fact(item, 'openingNames')) ? fact(item, 'openingNames') as string[] : []) }], relatedEvidence: newOpeningEvidence,
  }));

  const newlyAvailableTactics = afterEvidence.filter((item) => item.type === 'tactic'
    && item.status === 'confirmed'
    && item.side !== (context.move.color === 'w' ? 'white' : 'black')
    && ['material-gain', 'checkmate'].includes(String(fact(item, 'outcome'))));
  if (newlyAvailableTactics.length) add(newCategory({
    category: 'candidate-tactical-mistake', status: 'candidate', confidence: 0.55,
    explanation: 'After this move, the opponent has a confirmed legal tactical resource in the analyzed position. This is a candidate vulnerability, not a verdict that the move was a blunder or that another move was better.',
    facts: [{ key: 'opponentResources', value: newlyAvailableTactics.map((item) => item.subtype) }], relatedEvidence: newlyAvailableTactics,
  }));

  const preAnalyzed = aggregation.analyzedPositionPlies.includes(context.ply - 1);
  const postAnalyzed = aggregation.analyzedPositionPlies.includes(context.ply);
  if (!categories.length) add(newCategory({
    category: preAnalyzed && postAnalyzed ? 'unknown' : 'deferred', status: 'deferred', confidence: 0.25,
    explanation: preAnalyzed && postAnalyzed
      ? 'No supported move class was established from the analyzed deterministic and heuristic evidence.'
      : 'Move classification is deferred because one or both adjacent positions were outside the bounded detector pass.',
    facts: [{ key: 'reason', value: preAnalyzed && postAnalyzed ? 'insufficient-supported-evidence' : 'position-not-analyzed' }], relatedEvidence: [actualMoveEvidence],
  }));
  const categoryEvidence = categories.map((draft) => buildCategoryEvidence(context, draft));
  const classified = categories.map((draft, index) => ({
    category: draft.category,
    status: draft.status,
    confidence: confidenceLevel(draft.confidence),
    evidenceId: categoryEvidence[index].evidenceId,
    explanation: draft.explanation,
    relatedEvidenceIds: draft.relatedEvidence.map((item) => item.evidenceId),
  } satisfies MoveCategoryFinding));
  const resultStatus: EvidenceStatus = classified.some((item) => item.status === 'candidate')
    ? 'candidate'
    : classified.some((item) => item.status === 'confirmed')
      ? 'confirmed'
      : 'deferred';
  return {
    move: {
      ply: context.ply,
      san: context.move.san,
      uci: context.uci,
      side: context.move.color,
      status: resultStatus,
      categories: classified,
      evidenceIds: classified.map((item) => item.evidenceId),
      detectorCoverage: preAnalyzed && postAnalyzed ? 'analyzed' : 'deferred',
    },
    evidence: categoryEvidence,
  };
}

/** Deterministic legal facts and explicitly tentative heuristic cues; never an engine review. */
export function classifyMoves(record: GameRecord, aggregation: ChessEvidenceAggregation): MoveClassificationResult {
  if (aggregation.schemaVersion !== 1 || aggregation.gameId !== record.id || aggregation.totalPlies !== record.moveHistory.length) {
    throw new Error('Move classification requires matching versioned evidence for this exact game history.');
  }
  const contexts = moveContexts(record);
  const contextMap = new Map(contexts.map((context) => [context.ply, context]));
  const classifications = contexts.map((context) => classifyOne(context, aggregation, contextMap));
  return {
    schemaVersion: 1,
    gameId: record.id,
    moves: classifications.map((item) => item.move),
    evidence: classifications.flatMap((item) => item.evidence),
    limitations: [
      'Check, checkmate, capture, promotion, and recapture facts are replay-validated with chess.js.',
      'Development, pawn-break, king-safety, activity, structural, and tactical-risk labels are evidence-bound candidates unless their deterministic trigger is explicit.',
      'A candidate tactical mistake means only that a verified opponent resource appears after the move; it does not compare alternatives or establish a blunder.',
      'No best move, blunder, inaccuracy, brilliant move, rating, or accuracy score is produced.',
    ],
  };
}
