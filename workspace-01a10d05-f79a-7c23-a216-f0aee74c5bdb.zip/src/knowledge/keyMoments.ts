import { confidenceLevel, createChessEvidence, type ChessEvidence, type EvidenceConfidence, type EvidenceStatus } from './evidence';

export const KEY_MOMENT_CATEGORIES = [
  'check',
  'checkmate',
  'capture',
  'tactic',
  'material-change',
  'king-safety-change',
  'piece-activity-change',
  'pawn-break',
  'exchange',
  'opening-transition',
  'endgame-transition',
  'defensive-resource',
  'opportunity',
  'repetition',
  'perpetual-check-pattern',
  'promotion',
  'stalemate',
  'strategic-cue',
] as const;

export type KeyMomentCategory = (typeof KEY_MOMENT_CATEGORIES)[number];
export type KeyMoment = {
  id: string;
  category: KeyMomentCategory;
  ply: number;
  side: 'white' | 'black';
  status: EvidenceStatus;
  confidence: EvidenceConfidence;
  uci?: string;
  san?: string;
  summary: string;
  detectionBasis: string[];
  positionFen: string;
  evidenceIds: string[];
  evidence: ChessEvidence;
};
export type KeyMomentResult = { schemaVersion: 1; moments: KeyMoment[]; evidence: ChessEvidence[] };

type MomentSeed = { category: KeyMomentCategory; eventPly: number; evidence: ChessEvidence; discriminator: string };

const CONFIDENCE_SCORE: Record<EvidenceConfidence, number> = { high: 0.95, medium: 0.7, low: 0.4 };

function compareText(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

function factValue(evidence: ChessEvidence, key: string): string | number | boolean | string[] | undefined {
  return evidence.facts.find((fact) => fact.key === key)?.value;
}

function playedMove(evidence: ChessEvidence): { uci: string; san?: string } | undefined {
  // Detector evidence may carry a legal candidate move. Only the canonical
  // replay adapter/classifier may label a move as played game history.
  if (evidence.type !== 'move_classification') return undefined;
  const reference = evidence.references.find((item) => item.kind === 'move' && item.ply === evidence.ply);
  const uci = evidence.position.uci ?? reference?.uciMoves?.[0];
  if (!uci || !reference?.uciMoves?.includes(uci)) return undefined;
  const san = evidence.position.san ?? reference.sanMoves?.[reference.uciMoves.indexOf(uci)];
  return { uci, ...(san ? { san } : {}) };
}

function uciOf(evidence: ChessEvidence): string | undefined {
  return playedMove(evidence)?.uci;
}

function sanOf(evidence: ChessEvidence): string | undefined {
  return playedMove(evidence)?.san;
}

function candidateMoveKey(evidence: ChessEvidence): string | undefined {
  return evidence.position.uci ?? evidence.references.find((reference) => reference.kind === 'move')?.uciMoves?.[0];
}

function seedFor(evidence: ChessEvidence, category: KeyMomentCategory, eventPly = evidence.ply, discriminator = evidence.subtype): MomentSeed {
  return { category, eventPly, evidence, discriminator };
}

function classifyEvidence(evidence: ChessEvidence): MomentSeed[] {
  const result: MomentSeed[] = [];
  // Deferred coverage is not a detected event and must not become a phantom moment.
  if (evidence.status === 'deferred') return result;
  if (evidence.type === 'move_classification' && evidence.subtype === 'move-history') {
    const isMate = factValue(evidence, 'checkmate') === true;
    if (isMate) result.push(seedFor(evidence, 'checkmate', evidence.ply));
    else if (factValue(evidence, 'check') === true) result.push(seedFor(evidence, 'check', evidence.ply));
    if (factValue(evidence, 'stalemate') === true) result.push(seedFor(evidence, 'stalemate', evidence.ply));
    if (factValue(evidence, 'promotion') !== undefined && factValue(evidence, 'promotion') !== 'none') result.push(seedFor(evidence, 'promotion', evidence.ply));
    if (factValue(evidence, 'capture') === true) result.push(seedFor(evidence, 'capture', evidence.ply));
    const materialDelta = factValue(evidence, 'whitePerspectiveMaterialDelta');
    if (typeof materialDelta === 'number' && materialDelta !== 0) result.push(seedFor(evidence, 'material-change', evidence.ply, String(materialDelta)));
  }
  if (evidence.type === 'transition') {
    if (evidence.subtype === 'threefold-repetition' || evidence.subtype === 'fivefold-repetition') result.push(seedFor(evidence, 'repetition'));
    if (evidence.subtype === 'perpetual-check-pattern') result.push(seedFor(evidence, 'perpetual-check-pattern'));
  }
  // Position-level detectors can attach a legal candidate move in position.uci;
  // that line is not necessarily the move played in the reviewed game.
  if (evidence.type === 'tactic') result.push(seedFor(evidence, 'tactic', evidence.ply));
  if (evidence.type === 'defence' && !evidence.subtype.startsWith('threat-')) result.push(seedFor(evidence, 'defensive-resource', evidence.ply));
  if (evidence.type === 'endgame' && evidence.position.uci) result.push(seedFor(evidence, 'opportunity', evidence.ply));

  if (evidence.type === 'move_classification' && evidence.subtype !== 'move-history') {
    const categoryMap: Partial<Record<string, KeyMomentCategory>> = {
      check: 'check',
      checkmate: 'checkmate',
      stalemate: 'stalemate',
      'material-change': 'material-change',
      capture: 'capture',
      'tactical-move': 'tactic',
      'defensive-move': 'defensive-resource',
      'pawn-break': 'pawn-break',
      'king-safety-change': 'king-safety-change',
      'piece-activity-change': 'piece-activity-change',
      'exchange-trade': 'exchange',
      'opening-transition': 'opening-transition',
      'strategic-move': 'strategic-cue',
      'candidate-tactical-mistake': 'opportunity',
      'promotion-endgame-transition': factValue(evidence, 'promotion') ? 'promotion' : 'endgame-transition',
    };
    const category = categoryMap[evidence.subtype];
    if (category) result.push(seedFor(evidence, category));
    if (evidence.subtype === 'promotion-endgame-transition' && factValue(evidence, 'phaseAfter')) result.push(seedFor(evidence, 'endgame-transition'));
  }
  return result;
}

function groupStatus(evidence: ChessEvidence[]): EvidenceStatus {
  // Uncertainty is conservative: a confirmed source must not erase a candidate
  // interpretation for the same grouped event.
  if (evidence.some((item) => item.status === 'candidate')) return 'candidate';
  if (evidence.some((item) => item.status === 'confirmed')) return 'confirmed';
  return 'deferred';
}

function buildMomentEvidence(category: KeyMomentCategory, eventPly: number, sources: ChessEvidence[]): ChessEvidence {
  const orderedSources = [...sources].sort((a, b) => compareText(a.evidenceId, b.evidenceId));
  const primary = orderedSources[0];
  const ids = orderedSources.map((item) => item.evidenceId);
  const status = groupStatus(orderedSources);
  const confidenceScore = Math.min(...orderedSources.map((item) => CONFIDENCE_SCORE[item.confidence]));
  const statusSources = orderedSources.filter((item) => item.status === status);
  const candidateSafe = (value: string | undefined) => value && (status !== 'candidate' || /\b(candidate|possible|possibly|may|might|could|cue|not established|not verified|conditional)\b/i.test(value))
    ? value
    : value && status === 'candidate' ? `Candidate event: ${value}` : value;
  const rawSummary = statusSources.find((item) => item.explanation?.whatHappened)?.explanation?.whatHappened
    ?? orderedSources.find((item) => item.explanation?.whatHappened)?.explanation?.whatHappened;
  const summary = candidateSafe(rawSummary) ?? `${category.replaceAll('-', ' ')} evidence is available for ply ${eventPly}.`;
  const rawWhy = statusSources.find((item) => item.explanation?.whyItMatters)?.explanation?.whyItMatters
    ?? orderedSources.find((item) => item.explanation?.whyItMatters)?.explanation?.whyItMatters;
  const whyItMatters = candidateSafe(rawWhy)
    ?? 'This moment is linked to replay-validated chess evidence; its broader meaning is not inferred.';
  const possibleIdea = candidateSafe(statusSources.find((item) => item.explanation?.possibleIdea)?.explanation?.possibleIdea
    ?? orderedSources.find((item) => item.explanation?.possibleIdea)?.explanation?.possibleIdea);
  const references = [
    { kind: 'detector' as const, id: 'key-moment-detector', ply: eventPly, description: 'Moment assembled from the referenced evidence records.' },
    ...orderedSources.map((item) => ({ kind: 'detector' as const, id: item.evidenceId, ply: item.ply, description: `${item.type}/${item.subtype} supporting evidence.` })),
    ...orderedSources.flatMap((item) => item.references),
  ].filter((reference, index, all) => all.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(reference)) === index);
  const lines = orderedSources.flatMap((item) => item.lines ?? []).filter((line, index, all) => all.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(line)) === index);
  const san = orderedSources.find((item) => sanOf(item)) ? sanOf(orderedSources.find((item) => sanOf(item))!) : undefined;
  const uci = orderedSources.find((item) => uciOf(item)) ? uciOf(orderedSources.find((item) => uciOf(item))!) : undefined;
  return createChessEvidence({
    type: 'transition',
    subtype: `key-moment-${category}`,
    status,
    confidence: confidenceLevel(confidenceScore),
    ply: eventPly,
    side: primary.side,
    position: {
      fen: primary.position.fen,
      moveNumber: primary.position.moveNumber,
      ...(san ? { san } : {}),
      ...(uci ? { uci } : {}),
    },
    facts: [
      { key: 'category', value: category },
      { key: 'summary', value: summary },
      { key: 'supportingEvidenceIds', value: ids },
      { key: 'detectionBasis', value: [...new Set(orderedSources.map((item) => `${item.type}/${item.subtype}`))] },
    ],
    references,
    ...(lines.length ? { lines } : {}),
    source: 'Phase 7 evidence aggregation + key-moment detector',
    explanation: {
      whatHappened: summary,
      whyItMatters,
      ...(possibleIdea ? { possibleIdea } : {}),
      concept: category,
      learningTakeaway: status === 'candidate'
        ? 'Keep this as a candidate interpretation until the cited evidence and legal context are reviewed.'
        : 'Use the cited move and position references; this moment is not an engine evaluation.',
    },
    createdBy: { analyser: 'key-moment-detector', version: '1.0.0' },
  });
}

/** Converts supported evidence into stable moments while retaining its uncertainty and provenance. */
export function detectKeyMoments(evidence: readonly ChessEvidence[]): KeyMomentResult {
  const grouped = new Map<string, MomentSeed[]>();
  for (const item of evidence) {
    for (const seed of classifyEvidence(item)) {
      if (!Number.isInteger(seed.eventPly) || seed.eventPly < 0) continue;
      const playedMoveId = uciOf(item);
      const moveKey = playedMoveId ? `played:${playedMoveId}` : candidateMoveKey(item) ? `candidate:${candidateMoveKey(item)}` : '';
      const key = [seed.category, seed.eventPly, moveKey, moveKey ? '' : seed.discriminator].join('|');
      const bucket = grouped.get(key);
      if (bucket) bucket.push(seed);
      else grouped.set(key, [seed]);
    }
  }
  const moments: KeyMoment[] = [...grouped.values()].map((seeds) => {
    const sourceEvidence = [...new Map(seeds.map((seed) => [seed.evidence.evidenceId, seed.evidence])).values()];
    const eventPly = seeds[0].eventPly;
    const category = seeds[0].category;
    const momentEvidence = buildMomentEvidence(category, eventPly, sourceEvidence);
    return {
      id: momentEvidence.evidenceId,
      category,
      ply: eventPly,
      side: momentEvidence.side,
      status: momentEvidence.status,
      confidence: momentEvidence.confidence,
      ...(momentEvidence.position.uci ? { uci: momentEvidence.position.uci } : {}),
      ...(momentEvidence.position.san ? { san: momentEvidence.position.san } : {}),
      summary: momentEvidence.explanation?.whatHappened ?? category,
      detectionBasis: [...new Set(sourceEvidence.map((item) => `${item.type} / ${item.subtype}`))],
      positionFen: momentEvidence.position.fen,
      evidenceIds: sourceEvidence.map((item) => item.evidenceId).sort(compareText),
      evidence: momentEvidence,
    };
  }).sort((a, b) => a.ply - b.ply || compareText(a.category, b.category) || compareText(a.id, b.id));
  return { schemaVersion: 1, moments, evidence: moments.map((moment) => moment.evidence) };
}
