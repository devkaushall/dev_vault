import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { analyzeStrategyPosition, type StrategyAnalysis, type StrategyConcept } from './strategy';

function concept(result: StrategyAnalysis, name: StrategyConcept, side?: 'w' | 'b') {
  return result.findings.find((finding) => finding.concept === name && (side ? finding.side === side : true));
}

function makeHistory(uciMoves: string[]) {
  const chess = new Chess();
  for (const uci of uciMoves) {
    const move = chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] as 'q' | 'r' | 'b' | 'n' } : {}) });
    if (!move) throw new Error(`Bad fixture move ${uci}`);
  }
  return { fen: chess.fen({ forceEnpassantSquare: true }), history: { uciMoves } };
}

describe('evidence-bound strategy recognition', () => {
  it('returns only evidence-backed findings and defers tempo on a static starting position', () => {
    const result = analyzeStrategyPosition({ fen: new Chess().fen() });
    expect(result.findings.some((finding) => finding.concept === 'centre-control')).toBe(false);
    expect(result.findings.some((finding) => finding.concept === 'king-safety')).toBe(false);
    expect(result.findings.some((finding) => finding.concept === 'open-semi-open-files')).toBe(false);
    expect(result.findings.some((finding) => finding.concept === 'outposts')).toBe(false);
    expect(concept(result, 'bishop-pair', 'w')).toBeDefined();
    expect(concept(result, 'bishop-pair', 'b')).toBeDefined();
    expect(result.findings.some((finding) => finding.concept === 'exchange-strategy')).toBe(false);
    expect(result.deferred).toContainEqual(expect.objectContaining({ concept: 'tempo', reason: expect.stringContaining('static FEN') }));
    for (const finding of result.findings) {
      expect(finding.conceptId).toMatch(/^strategy\./);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
      expect(finding.relevance).toBeGreaterThanOrEqual(0);
      expect(finding.relevance).toBeLessThanOrEqual(1);
      expect(finding.possiblePlan.length).toBeGreaterThan(0);
      expect(finding.possibleImplications.length).toBeGreaterThan(0);
    }
  });

  it('recognizes centre, development, space, shelter, files, and activity using measured board conditions', () => {
    const position = 'r3k2r/pp2pppp/8/3PP3/8/8/PPP2PPP/R3K2R w KQkq - 0 1';
    const result = analyzeStrategyPosition({ fen: position });
    expect(concept(result, 'centre-control', 'w')?.evidence[0].values?.occupiedCentralPawns).toEqual(expect.arrayContaining(['d5', 'e5']));
    expect(concept(result, 'space', 'w')?.evidence[0].values?.advancedPawns).toEqual(expect.arrayContaining(['d5', 'e5']));
    expect(concept(result, 'king-safety', 'w')?.label).toContain('1/3');
    expect(concept(result, 'open-semi-open-files', 'b')?.label).toContain('semi-open');

    const developed = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/8/4N3/4K3 w - - 0 1' });
    expect(concept(developed, 'development', 'w')?.evidence[0].values?.piecesOffHomeSquares).toEqual(['e2']);

    const active = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/2B5/8/4K1R1 w - - 0 1' });
    expect(concept(active, 'piece-activity', 'w')?.evidence[0].values?.opponentHalfSquares).toEqual(expect.arrayContaining(['e5', 'f6', 'g7']));
  });

  it('recognizes a pawn-supported knight outpost and withholds it when an enemy pawn can challenge', () => {
    const supported = analyzeStrategyPosition({ fen: '4k3/p6p/8/3N4/2P5/8/8/4K3 w - - 0 1' });
    expect(concept(supported, 'outposts', 'w')).toMatchObject({
      label: expect.stringContaining('knight on d5'),
      confidence: 0.9,
      evidence: [expect.objectContaining({ values: expect.objectContaining({ ownPawnSupport: true, immediateEnemyPawnChallenge: false }) })],
    });
    expect(concept(supported, 'weak-squares', 'w')?.evidence[0].values?.candidateSquares).toContain('d5');

    const challengeable = analyzeStrategyPosition({ fen: '4k3/p6p/2p5/3N4/2P5/8/8/4K3 w - - 0 1' });
    expect(concept(challengeable, 'outposts', 'w')).toBeUndefined();
    expect(concept(challengeable, 'weak-squares', 'w')).toBeUndefined();
    expect(challengeable.deferred).toContainEqual(expect.objectContaining({ concept: 'outposts' }));
  });

  it('reports legal pawn-break, counterplay, and conditional initiative candidates without asserting a tactic', () => {
    const result = analyzeStrategyPosition({ fen: '4k3/8/8/3p4/4P3/2B5/8/4K1R1 w - - 0 1' });
    const breakFinding = concept(result, 'pawn-breaks', 'w');
    expect(breakFinding?.label).toContain('exd5');
    expect(breakFinding?.evidence).toContainEqual(expect.objectContaining({ kind: 'move-sequence', values: expect.objectContaining({ uci: 'e4d5' }) }));
    expect(concept(result, 'counterplay', 'w')?.candidate).toBe(true);
    expect(concept(result, 'initiative', 'w')?.label).toContain('initiative candidate');
    expect(result.limitations.join(' ')).toContain('no tactics, attack, defence');

    const noBreak = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1' });
    expect(concept(noBreak, 'pawn-breaks')).toBeUndefined();
    expect(noBreak.deferred).toContainEqual(expect.objectContaining({ concept: 'pawn-breaks' }));
    expect(concept(noBreak, 'initiative')).toBeUndefined();
    expect(concept(noBreak, 'counterplay')).toBeUndefined();
  });

  it('raises prophylaxis only for a clear opponent pawn-push challenge', () => {
    const frenchAdvance = 'rnbqkbnr/ppp2ppp/4p3/3pP3/3P4/8/PPP2PPP/RNBQKBNR w KQkq - 0 4';
    const result = analyzeStrategyPosition({ fen: frenchAdvance });
    const prophylaxis = concept(result, 'prophylaxis', 'w');
    expect(prophylaxis?.label).toContain('pawn-break candidate');
    expect(prophylaxis?.evidence[0].values?.candidatePushes).toContain('c7-c5');
    expect(prophylaxis?.possiblePlan).toContain('without a real target');

    const quiet = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1' });
    expect(concept(quiet, 'prophylaxis')).toBeUndefined();
    expect(quiet.deferred).toContainEqual(expect.objectContaining({ concept: 'prophylaxis' }));
  });

  it('reports bishop pair/quality cues, concrete exchange context, and a directly verified blockade', () => {
    const bishops = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/8/8/2BBK3 w - - 0 1' });
    expect(concept(bishops, 'bishop-pair', 'w')?.evidence[0].values?.bishopSquares).toEqual(['c1', 'd1']);
    expect(concept(bishops, 'bishop-quality', 'w')?.label).toContain('no good/bad verdict');
    const singleBishop = analyzeStrategyPosition({ fen: '4k3/8/8/8/8/8/4B3/4K3 w - - 0 1' });
    expect(concept(singleBishop, 'bishop-pair')).toBeUndefined();

    const exchange = analyzeStrategyPosition({ fen: '4k3/8/2n3n1/8/8/8/8/2BBK3 w - - 0 1' });
    expect(concept(exchange, 'exchange-strategy', 'w')?.possiblePlan).toContain('does not identify a favorable exchange');

    const blocked = analyzeStrategyPosition({ fen: '7k/4b3/4P3/8/8/8/8/K7 w - - 0 1' });
    expect(concept(blocked, 'blockade', 'b')?.evidence[0].values).toMatchObject({ passedPawn: 'e6', blockerSquare: 'e7', blockerType: 'b' });
    const unblocked = analyzeStrategyPosition({ fen: '7k/3b4/4P3/8/8/8/8/K7 w - - 0 1' });
    expect(concept(unblocked, 'blockade')).toBeUndefined();
  });

  it('detects tempo only from matching legal history, with edge/mismatch cases rejected', () => {
    const history = makeHistory(['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3']);
    const result = analyzeStrategyPosition(history);
    expect(result.findings.filter((finding) => finding.concept === 'tempo').map((finding) => finding.side)).toContain('w');
    expect(concept(result, 'tempo', 'w')?.evidence[0].values?.ply).toEqual([1, 3]);

    expect(() => analyzeStrategyPosition({
      fen: history.fen,
      history: { uciMoves: ['g1f3'] },
    })).toThrow('does not replay');
    expect(() => analyzeStrategyPosition({
      fen: history.fen,
      history: { uciMoves: ['not-a-move'] },
    })).toThrow('Invalid strategy-history UCI');
  });
});
