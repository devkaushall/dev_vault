import { describe, expect, it } from 'vitest';
import { createChessEvidence } from './evidence';
import { deriveLearningInsights, type LearningEvidenceSet } from './learningInsights';

function finding(id: string, ply: number, status: 'confirmed' | 'candidate' | 'deferred' = 'candidate') {
  return createChessEvidence({
    type: 'move_classification',
    subtype: 'candidate-tactical-mistake',
    status,
    confidence: 'medium',
    ply,
    side: 'white',
    position: { fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: Math.floor(ply / 2) + 1, uci: 'e1e2' },
    facts: [{ key: 'fixture', value: id }],
    references: [{ kind: 'move', id: `move-${id}`, ply, uciMoves: ['e1e2'] }],
    source: 'learning-insight-test-fixture',
    explanation: { whatHappened: 'A candidate tactical vulnerability cue is present.', whyItMatters: 'A legal opponent resource is recorded.' },
    createdBy: { analyser: 'test-fixture', version: '1.0.0' },
  });
}

function gameSet(gameKey: string, totalPlies: number, plies: number[], status: 'confirmed' | 'candidate' | 'deferred' = 'candidate'): LearningEvidenceSet {
  return { gameKey, totalPlies, evidence: plies.map((ply, index) => finding(`${gameKey}-${index}`, ply, status)) };
}

describe('recurring learning insights', () => {
  it('does not infer a lasting trait from one incident or one reviewed game', () => {
    expect(deriveLearningInsights([gameSet('game-a', 12, [3])]).insights).toEqual([]);
    expect(deriveLearningInsights([gameSet('game-a', 12, [1, 4, 8])]).insights).toEqual([]);
  });

  it('emits a candidate study theme only after occurrence, distinct-game, and frequency thresholds pass', () => {
    const result = deriveLearningInsights([
      gameSet('game-a', 8, [1, 4]),
      gameSet('game-b', 8, [3]),
    ]);
    expect(result.insights).toHaveLength(1);
    expect(result.insights[0]).toMatchObject({
      status: 'candidate', occurrenceCount: 3, distinctGameCount: 2, confidence: 'low',
      scope: 'repeated-across-reviewed-games',
    });
    expect(result.insights[0].frequency).toBeCloseTo(3 / 16);
    expect(result.insights[0].summary).toMatch(/not a permanent player trait/i);
    expect(result.insights[0]).not.toHaveProperty('rating');
    expect(result.insights[0]).not.toHaveProperty('accuracy');
  });

  it('deduplicates duplicate review copies by game key and excludes deferred evidence', () => {
    const duplicateCopy = gameSet('same-history', 8, [1, 3]);
    const result = deriveLearningInsights([
      duplicateCopy,
      { ...duplicateCopy, evidence: [finding('copy-duplicate', 1)] },
      gameSet('unreviewed', 8, [2], 'deferred'),
    ]);
    expect(result.insights).toEqual([]);
  });

  it('supports stricter explicit thresholds without relaxing uncertainty', () => {
    const result = deriveLearningInsights([
      gameSet('a', 10, [1, 3, 5]),
      gameSet('b', 10, [2, 4, 6]),
    ], { minimumOccurrences: 6, minimumDistinctGames: 2, minimumFrequency: 0.3 });
    expect(result.insights).toHaveLength(1);
    expect(result.insights[0].status).toBe('candidate');
    expect(result.limitations.join(' ')).toMatch(/not a permanent weakness/i);
  });
});
