import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { analyzeTactics, TACTICAL_MOTIFS, validateTacticalCandidate, type TacticalFinding } from './tactics';

function findingsFor(fen: string, motif: TacticalFinding['motif']): TacticalFinding[] {
  return analyzeTactics(new Chess(fen)).findings.filter((finding) => finding.motif === motif);
}

function findingForMove(fen: string, motif: TacticalFinding['motif'], uci: string): TacticalFinding | undefined {
  return findingsFor(fen, motif).find((finding) => finding.triggeringMove?.uci === uci);
}

describe('tactical recognition service', () => {
  it('exposes every requested motif and explicitly defers unimplemented proof families', () => {
    const analysis = analyzeTactics(new Chess());
    const deferred = new Set(analysis.deferredMotifs.map((entry) => entry.motif));
    expect(analysis.findings.every((finding) => finding.state === 'confirmed' || finding.state === 'candidate')).toBe(true);
    expect(analysis.deferredMotifs.every((entry) => entry.state === 'deferred' && entry.reason.length > 0)).toBe(true);
    expect(TACTICAL_MOTIFS).toContain('windmill');
    expect(deferred).toEqual(new Set([
      'remove-defender', 'deflection', 'decoy', 'overload', 'interference', 'clearance',
      'zwischenzug', 'trapped-piece', 'desperado', 'sacrifice', 'perpetual-check', 'zugzwang', 'windmill',
    ]));
    expect(analysis.findings.some((finding) => deferred.has(finding.motif))).toBe(false);
  });

  it('attaches evidence, provenance, legal-line fields and bounded confidence to every result', () => {
    const analysis = analyzeTactics(new Chess('6k1/3q4/8/3N4/8/8/8/K7 w - - 0 1'));
    expect(analysis.findings.length).toBeGreaterThan(0);
    for (const finding of analysis.findings) {
      expect(finding.conceptId).toBe(`tactics.${finding.motif}`);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.provenance.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
      expect(finding.relevance).toBeGreaterThanOrEqual(0);
      expect(finding.relevance).toBeLessThanOrEqual(1);
      expect(finding.legalLine).toHaveProperty('candidateMoveLegal');
      expect(finding.legalLine).toHaveProperty('forcingMove');
      expect(finding.legalLine).toHaveProperty('opponentRepliesGenerated');
      expect(finding.legalLine).toHaveProperty('continuations');
      expect(finding.legalLine).toHaveProperty('outcome');
    }
  });

  describe('fork', () => {
    const forkFen = '6k1/3q4/8/3N4/8/8/8/K7 w - - 0 1';

    it('confirms a legal checking knight fork only after the reply tree preserves a material gain', () => {
      const fork = findingForMove(forkFen, 'fork', 'd5f6');
      expect(fork).toBeDefined();
      expect(fork?.state).toBe('confirmed');
      expect(fork?.legalLine.forcingStatus).toBe('verified-check');
      expect(fork?.legalLine.opponentRepliesGenerated).toBeGreaterThan(0);
      expect(fork!.legalLine.continuations).toHaveLength(fork!.legalLine.opponentRepliesGenerated);
      expect(fork?.legalLine.continuations.every((line) => line.continuation?.uci === 'f6d7')).toBe(true);
      expect(fork?.legalLine.outcome.kind).toBe('material-gain');
      expect(fork?.legalLine.outcome.materialGain).toBeGreaterThanOrEqual(3);
      expect(fork?.possibleConsequence).toMatch(/not an engine evaluation/i);
    });

    it('does not call a checking move a fork when the second target is not attacked', () => {
      const nearMiss = '6k1/2q5/8/3N4/8/8/8/K7 w - - 0 1';
      expect(findingForMove(nearMiss, 'fork', 'd5f6')).toBeUndefined();
    });

    it('does not create a fork for an illegal candidate move', () => {
      const result = validateTacticalCandidate(new Chess(forkFen), 'd5d6');
      expect(result).toMatchObject({ legal: false, reason: 'illegal-move' });
    });
  });

  describe('pin and skewer geometry candidates', () => {
    it('recognizes an absolute pin only as a candidate, not a proved win', () => {
      const pinFen = '4k3/4q3/8/8/8/8/8/4R1K1 w - - 0 1';
      const pin = findingsFor(pinFen, 'pin').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('e7')));
      expect(pin).toBeDefined();
      expect(pin?.state).toBe('candidate');
      expect(pin?.legalLine.candidateMoveLegal).toBeNull();
      expect(pin?.legalLine.outcome.kind).toBe('unproven');
    });

    it('rejects the near-miss where the king is not behind the front piece', () => {
      const nearMiss = '3k4/4q3/8/8/8/8/8/4R1K1 w - - 0 1';
      expect(findingsFor(nearMiss, 'pin')).toHaveLength(0);
    });

    it('detects a diagonal queen-to-rook skewer candidate', () => {
      const skewerFen = '4r2k/3q4/8/8/B7/8/8/7K w - - 0 1';
      const skewer = findingsFor(skewerFen, 'skewer').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('d7')));
      expect(skewer).toBeDefined();
      expect(skewer?.state).toBe('candidate');
      expect(skewer?.legalLine.outcome.deterministic).toBe(false);
    });

    it('does not call non-collinear pieces a skewer', () => {
      const nearMiss = '5r1k/3q4/8/8/B7/8/8/7K w - - 0 1';
      expect(findingsFor(nearMiss, 'skewer')).toHaveLength(0);
    });
  });

  describe('discovered attacks and double check', () => {
    it('verifies a discovered check after the blocker legally leaves the file', () => {
      const fen = '4k3/8/8/8/8/8/4N3/4R1K1 w - - 0 1';
      const discovered = findingForMove(fen, 'discovered-attack', 'e2f4');
      expect(discovered).toBeDefined();
      expect(discovered?.state).toBe('confirmed');
      expect(discovered?.legalLine.forcingStatus).toBe('verified-check');
      expect(discovered?.legalLine.opponentRepliesGenerated).toBeGreaterThan(0);
      expect(discovered?.boardEvidence[0].squares).toContain('e8');
    });

    it('does not report a discovered check for a king move that leaves the blocker in place', () => {
      const fen = '4k3/8/8/8/8/8/4N3/4R1K1 w - - 0 1';
      expect(findingForMove(fen, 'discovered-attack', 'g1f1')).toBeUndefined();
    });

    it('records a discovered attack on a queen as a candidate, not a forced win', () => {
      const fen = 'k7/4q3/8/8/8/8/4N3/4R2K w - - 0 1';
      const discovered = findingForMove(fen, 'discovered-attack', 'e2f4');
      expect(discovered).toBeDefined();
      expect(discovered?.state).toBe('candidate');
      expect(discovered?.legalLine.candidateMoveLegal).toBe(true);
      expect(discovered?.legalLine.outcome.kind).toBe('unproven');
      expect(discovered?.possibleConsequence).toMatch(/no forcing win is claimed/i);
    });

    it('rejects the discovered-attack near-miss when the target is off the slider line', () => {
      const fen = 'k2q4/8/8/8/8/8/4N3/4R2K w - - 0 1';
      expect(findingForMove(fen, 'discovered-attack', 'e2f4')).toBeUndefined();
    });

    it('confirms double check and validates that every legal reply is a king move', () => {
      const fen = '7k/8/8/8/8/8/7B/K6R w - - 0 1';
      const doubleCheck = findingForMove(fen, 'double-check', 'h2e5');
      expect(doubleCheck).toBeDefined();
      expect(doubleCheck?.state).toBe('confirmed');
      expect(doubleCheck?.legalLine.forcingStatus).toBe('verified-double-check');
      expect(doubleCheck?.legalLine.opponentRepliesGenerated).toBeGreaterThan(0);
      expect(doubleCheck?.legalLine.outcome.kind).toBe('position-fact');
      expect(doubleCheck?.evidence.some((evidence) => evidence.values?.allRepliesAreKingMoves === true)).toBe(true);
    });

    it('keeps a single discovered check from being mislabeled double check', () => {
      const fen = '7k/8/8/8/8/8/7B/K6R w - - 0 1';
      expect(findingForMove(fen, 'double-check', 'h2g3')).toBeUndefined();
    });
  });

  describe('x-ray and battery candidates', () => {
    it('recognizes an x-ray through one enemy blocker as a candidate only', () => {
      const xrayFen = 'k3q3/8/8/8/4p3/8/8/4R2K w - - 0 1';
      const xray = findingsFor(xrayFen, 'x-ray').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('e8')));
      expect(xray).toBeDefined();
      expect(xray?.state).toBe('candidate');
      expect(xray?.legalLine.forcingMove).toBeNull();
      expect(xray?.legalLine.outcome.kind).toBe('unproven');
    });

    it('rejects an x-ray near-miss with the rear target off the ray', () => {
      const nearMiss = 'k2q4/8/8/8/4p3/8/8/4R2K w - - 0 1';
      expect(findingsFor(nearMiss, 'x-ray')).toHaveLength(0);
    });

    it('recognizes two aligned compatible friendly sliders as a battery candidate', () => {
      const batteryFen = '4k3/4p3/8/8/8/4Q3/8/4R2K w - - 0 1';
      const battery = findingsFor(batteryFen, 'battery').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('e3')));
      expect(battery).toBeDefined();
      expect(battery?.state).toBe('candidate');
      expect(battery?.legalLine.outcome.kind).toBe('unproven');
    });

    it('does not invent a battery when only one friendly slider is aligned', () => {
      const nearMiss = '4k3/4p3/8/8/8/8/8/4R2K w - - 0 1';
      expect(findingsFor(nearMiss, 'battery')).toHaveLength(0);
    });
  });

  describe('loose pieces', () => {
    it('confirms a legally capturable, undefended queen when material survives every immediate reply', () => {
      const fen = 'k7/4q3/8/8/8/8/4R3/7K w - - 0 1';
      const loose = findingsFor(fen, 'loose-piece').find((finding) => finding.triggeringMove?.uci === 'e2e7');
      expect(loose).toBeDefined();
      expect(loose?.state).toBe('confirmed');
      expect(loose?.legalLine.outcome.kind).toBe('material-gain');
      expect(loose?.legalLine.outcome.materialGain).toBeGreaterThanOrEqual(1);
      expect(loose?.legalLine.opponentRepliesGenerated).toBeGreaterThan(0);
      expect(loose?.legalLine.continuations.every((line) => line.continuation !== undefined)).toBe(true);
      expect(loose?.legalLine.continuationSearch).toBe('all-immediate-replies');
    });

    it('rejects a geometrically attacked queen defended by a rook', () => {
      const defended = 'k3r3/4q3/8/8/8/8/4R3/7K w - - 0 1';
      expect(findingsFor(defended, 'loose-piece')).toHaveLength(0);
    });
  });

  describe('underpromotion and promotion races', () => {
    it('records a legal edge-file underpromotion as a candidate without claiming superiority', () => {
      const fen = '8/P7/8/8/8/8/8/4k2K w - - 0 1';
      const underpromotion = findingForMove(fen, 'underpromotion', 'a7a8n');
      expect(underpromotion).toBeDefined();
      expect(underpromotion?.state).toBe('candidate');
      expect(underpromotion?.legalLine.candidateMoveLegal).toBe(true);
      expect(underpromotion?.legalLine.outcome.kind).toBe('unproven');
      expect(underpromotion?.possibleConsequence).toMatch(/not evaluated/i);
    });

    it('does not invent underpromotion before a pawn reaches the promotion rank', () => {
      const fen = '8/8/P7/8/8/8/4k3/7K w - - 0 1';
      expect(findingsFor(fen, 'underpromotion')).toHaveLength(0);
    });

    it('recognizes a passed-pawn race only as a distance candidate', () => {
      const fen = '4k3/P7/8/8/8/7p/8/3K4 w - - 0 1';
      const race = findingsFor(fen, 'promotion-race')[0];
      expect(race).toBeDefined();
      expect(race?.state).toBe('candidate');
      expect(race?.legalLine.outcome.kind).toBe('unproven');
      expect(race?.possibleConsequence).toMatch(/No winner is predicted/i);
    });

    it('rejects a race when the opposing pawn is not passed', () => {
      const fen = '4k3/P7/8/8/8/7p/7P/3K4 w - - 0 1';
      expect(findingsFor(fen, 'promotion-race')).toHaveLength(0);
    });
  });

  describe('terminal positions and candidate validation', () => {
    it('confirms an immediate stalemate resource from legal move generation', () => {
      const fen = '8/8/8/8/8/8/Q7/K1k5 w - - 0 1';
      const stalemate = findingForMove(fen, 'stalemate-resource', 'a2e2');
      expect(stalemate).toBeDefined();
      expect(stalemate?.state).toBe('confirmed');
      expect(stalemate?.legalLine.outcome).toMatchObject({ kind: 'stalemate', deterministic: true });
    });

    it('does not call an ordinary legal move stalemate', () => {
      expect(findingsFor('8/8/8/8/8/8/Q7/K1k5 w - - 0 1', 'stalemate-resource').some((finding) => finding.triggeringMove?.uci === 'a2a3')).toBe(false);
    });

    it('confirms a mating pattern only when chess.js reports checkmate', () => {
      const fen = '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1';
      const mating = findingsFor(fen, 'mating-pattern');
      expect(mating.length).toBeGreaterThan(0);
      expect(mating.every((finding) => finding.state === 'confirmed' && finding.legalLine.outcome.kind === 'checkmate')).toBe(true);
    });

    it('has no mating-pattern finding in the initial position', () => {
      expect(findingsFor(new Chess().fen(), 'mating-pattern')).toHaveLength(0);
    });

    it('distinguishes malformed and illegal UCI candidates and does not mutate the board', () => {
      const position = new Chess();
      const before = position.fen();
      expect(validateTacticalCandidate(position, 'e2e9')).toMatchObject({ legal: false, reason: 'invalid-uci' });
      expect(validateTacticalCandidate(position, 'e2e5')).toMatchObject({ legal: false, reason: 'illegal-move' });
      expect(validateTacticalCandidate(position, 'e2e4')).toMatchObject({ legal: true, move: { uci: 'e2e4' } });
      expect(position.fen()).toBe(before);
    });
  });
});
