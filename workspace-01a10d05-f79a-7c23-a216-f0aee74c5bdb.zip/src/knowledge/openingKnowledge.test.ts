import { describe, expect, it } from 'vitest';
import { lookupOpeningAtPosition, parseOpeningTsv } from './openings';

const CURATED_FIXTURE = `eco\tname\tpgn
C50\tItalian Game: Giuoco Piano\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5
C50\tItalian Game: Giuoco Pianissimo\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. d3
C50\tItalian Game: Giuoco Pianissimo, Normal\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. d3 Bc5
C65\tRuy Lopez: Berlin Defense\t1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6
C55\tItalian Game: Two Knights Defense\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6
C02\tFrench Defense: Advance Variation\t1. e4 e6 2. d4 d5 3. e5
D06\tQueen's Gambit\t1. d4 d5 2. c4
D20\tQueen's Gambit Accepted\t1. d4 d5 2. c4 dxc4
D30\tQueen's Gambit Declined\t1. d4 d5 2. c4 e6
C51\tItalian Game: Evans Gambit\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4
C51\tItalian Game: Evans Gambit Accepted\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bxb4
C51\tItalian Game: Evans Gambit Declined\t1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bb6
A00\tUncatalogued Example\t1. b3 e5 2. Bb2
`;

const catalog = parseOpeningTsv(CURATED_FIXTURE);

function matchByName(name: string) {
  const entry = catalog.entries.find((candidate) => candidate.name === name);
  if (!entry) throw new Error(`Fixture is missing ${name}`);
  return lookupOpeningAtPosition(catalog, entry.finalFen, entry.uciMoves)!;
}

describe('curated opening knowledge', () => {
  it('keeps exact dataset hierarchy, family curation, and defining SAN/UCI moves distinct and sourced', () => {
    const match = matchByName('Italian Game: Giuoco Pianissimo, Normal');
    expect(match.hierarchy).toContainEqual(expect.objectContaining({
      family: expect.objectContaining({ id: 'open-games', label: 'Open Games' }),
      opening: 'Italian Game',
      variation: 'Giuoco Pianissimo',
      subvariation: 'Normal',
      labelPath: ['Italian Game', 'Giuoco Pianissimo', 'Normal'],
    }));
    expect(match.hierarchy[0].provenance).toContainEqual(expect.objectContaining({
      kind: 'lichess-opening-dataset', commit: '5a13018164f6bd88f48b3dc31a8e2a39f31a060a', field: 'name',
    }));
    expect(match.hierarchy[0].family?.provenance).toMatchObject({
      kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md', section: '§1.1 पहली चाल का बड़ा नक्शा',
    });
    expect(match.definingLines[0].moves.at(-1)).toMatchObject({ ply: 8, color: 'b', san: 'Bc5', uci: 'f8c5' });
    expect(match.definingLines[0].provenance).toContainEqual(expect.objectContaining({ kind: 'lichess-opening-dataset', field: 'pgn' }));
  });

  it('supplies sourced, conditional plan and piece-placement findings with bounded confidence and relevance', () => {
    const italian = matchByName('Italian Game: Giuoco Piano');
    expect(italian.knowledge.typicalPlans).toEqual(expect.arrayContaining([
      expect.objectContaining({ conceptId: 'opening.italian-game-giuoco-piano.central-c3-d4' }),
    ]));
    expect(italian.knowledge.piecePlacements[0]).toMatchObject({
      label: 'The bishop on c4 eyes the f7 diagonal',
      evidence: expect.arrayContaining([expect.objectContaining({ kind: 'board-state' })]),
      possibleImplications: expect.arrayContaining([expect.objectContaining({ side: 'w' })]),
    });
    for (const finding of [...italian.knowledge.typicalPlans, ...italian.knowledge.piecePlacements]) {
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
      expect(finding.relevance).toBeGreaterThanOrEqual(0);
      expect(finding.relevance).toBeLessThanOrEqual(1);
      expect(finding.provenance).toContainEqual(expect.objectContaining({
        kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md', section: '§1.2 Italian Game',
      }));
    }
    expect(matchByName('Italian Game: Giuoco Pianissimo').knowledge.typicalPlans[0].label).toContain('quieter');
    expect(matchByName('Ruy Lopez: Berlin Defense').knowledge.piecePlacements[0].provenance[0]).toMatchObject({
      kind: 'chess-atlas', section: '§1.2 Ruy Lopez / Spanish',
    });

    const italianTwoKnights = matchByName('Italian Game: Two Knights Defense');
    expect(italianTwoKnights.knowledge.tacticalIdeas[0]).toMatchObject({
      label: 'The Two Knights branch has sharper tactical sub-lines', confidence: 0.91,
      provenance: expect.arrayContaining([expect.objectContaining({ kind: 'chess-atlas', section: '§1.2 Italian Game' })]),
    });
    expect(italianTwoKnights.knowledge.tacticalIdeas[0].possibleImplications[0].description).toContain('not a tactic');

    const frenchAdvance = matchByName('French Defense: Advance Variation');
    expect(frenchAdvance.knowledge.pawnBreaks[0]).toMatchObject({
      label: 'Black can challenge the chain with ...c5 or ...f6',
      provenance: expect.arrayContaining([expect.objectContaining({ kind: 'chess-atlas', section: '§1.3 French Defence; §3.2 French pawn chain' })]),
    });
    expect(frenchAdvance.knowledge.counterplans[0]).toMatchObject({
      label: 'White may use kingside space or stabilize the centre',
      possibleImplications: expect.arrayContaining([expect.objectContaining({ side: 'w' })]),
    });
  });

  it('recognizes offered, accepted, and declined gambits from the defining legal moves', () => {
    expect(matchByName("Queen's Gambit").knowledge.gambitStatus[0]).toMatchObject({ name: "Queen's Gambit", state: 'offered' });
    expect(matchByName("Queen's Gambit Accepted").knowledge.gambitStatus[0]).toMatchObject({ name: "Queen's Gambit", state: 'accepted' });
    expect(matchByName("Queen's Gambit Declined").knowledge.gambitStatus[0]).toMatchObject({ name: "Queen's Gambit", state: 'declined' });
    expect(matchByName('Italian Game: Evans Gambit').knowledge.gambitStatus[0]).toMatchObject({ name: 'Evans Gambit', state: 'offered' });
    expect(matchByName('Italian Game: Evans Gambit Accepted').knowledge.gambitStatus[0]).toMatchObject({ name: 'Evans Gambit', state: 'accepted' });
    expect(matchByName('Italian Game: Evans Gambit Declined').knowledge.gambitStatus[0]).toMatchObject({ name: 'Evans Gambit', state: 'declined' });
    expect(matchByName("Queen's Gambit Accepted").knowledge.gambitStatus[0].finding.evidence[0].values?.uciMoves).toEqual(['d2d4', 'd7d5', 'c2c4', 'd5c4']);
  });

  it('does not fabricate family or strategy claims for unsupported names, and keeps transposition confidence distinct', () => {
    const unknown = matchByName('Uncatalogued Example');
    expect(unknown.hierarchy[0]).toMatchObject({ opening: 'Uncatalogued Example', labelPath: ['Uncatalogued Example'] });
    expect(unknown.hierarchy[0].family).toBeUndefined();
    expect(unknown.knowledge).toEqual({
      typicalPlans: [], pawnBreaks: [], piecePlacements: [], tacticalIdeas: [], counterplans: [], gambitStatus: [],
    });

    const pianoEntry = catalog.entries.find((entry) => entry.name === 'Italian Game: Giuoco Piano')!;
    const transposed = lookupOpeningAtPosition(catalog, pianoEntry.finalFen, [
      'e2e4', 'e7e5', 'f1c4', 'b8c6', 'g1f3', 'f8c5',
    ])!;
    expect(transposed).toMatchObject({ kind: 'transposition', confidence: 'medium' });
    expect(transposed.knowledge.typicalPlans).toHaveLength(1);
    expect(transposed.definingLines[0].moves.map((move) => move.uci)).toEqual(pianoEntry.uciMoves);
  });
});
