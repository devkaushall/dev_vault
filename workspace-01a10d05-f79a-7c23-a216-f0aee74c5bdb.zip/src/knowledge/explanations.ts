import { Chess, type Move } from 'chess.js';
import { uciForMove } from '../domain/chess/position';
import { aggregateEvidenceBatches } from './evidenceAggregation';
import type { ChessEvidence, EvidenceConfidence, EvidenceExplanation, EvidenceFactValue, EvidenceReference, EvidenceStatus } from './evidence';

export type StructuredExplanation = {
  id: string;
  ply: number;
  side: 'white' | 'black';
  status: EvidenceStatus;
  confidence: EvidenceConfidence;
  whatHappened: string;
  whyItMatters: string;
  possibleIdeaOrThreat: string;
  candidateResponse: string;
  concept: string;
  learningTakeaway: string;
  evidenceIds: string[];
  references: EvidenceReference[];
};
export type ExplanationResult = {
  schemaVersion: 1;
  explanations: StructuredExplanation[];
  limitations: string[];
};

const PIECE_NAMES: Record<string, string> = {
  p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king',
};
const MOMENT_LABELS: Record<string, string> = {
  check: 'check',
  checkmate: 'checkmate',
  capture: 'capture',
  tactic: 'tactical cue',
  'material-change': 'material change',
  'king-safety-change': 'king-safety change',
  'piece-activity-change': 'piece-activity change',
  'pawn-break': 'pawn-break cue',
  exchange: 'exchange',
  'opening-transition': 'opening transition',
  'endgame-transition': 'endgame transition',
  'defensive-resource': 'defensive resource',
  opportunity: 'possible opportunity',
  repetition: 'repetition',
  'perpetual-check-pattern': 'perpetual-check pattern',
  promotion: 'promotion',
  stalemate: 'stalemate',
  'strategic-cue': 'strategic cue',
};

function fact(evidence: ChessEvidence, key: string): EvidenceFactValue | undefined {
  return evidence.facts.find((entry) => entry.key === key)?.value;
}

function stringFact(evidence: ChessEvidence, key: string): string | undefined {
  const value = fact(evidence, key);
  return typeof value === 'string' ? value : undefined;
}

function stringArrayFact(evidence: ChessEvidence, key: string): string[] {
  const value = fact(evidence, key);
  return Array.isArray(value) ? value : [];
}

function humanize(value: string | undefined): string {
  return (value ?? 'board evidence').replaceAll(/[-_.]+/g, ' ').replaceAll(/\s+/g, ' ').trim();
}

function qualifyCandidate(text: string, status: EvidenceStatus): string {
  if (status !== 'candidate') return text;
  if (/\b(candidate|possible|possibly|may|might|could|cue|not established|not verified|conditional)\b/i.test(text)) return text;
  return `Candidate interpretation: ${text}`;
}

function describePiece(value: string | undefined): string {
  return value ? (PIECE_NAMES[value] ?? humanize(value)) : 'piece';
}

function descriptions(evidence: ChessEvidence): string[] {
  return evidence.facts
    .filter((entry) => entry.key === 'description' || entry.key.endsWith('.description'))
    .map((entry) => entry.value)
    .filter((value): value is string => typeof value === 'string' && value.trim().length > 0);
}

function validatedLine(evidence: ChessEvidence): string | undefined {
  for (const line of evidence.lines ?? []) {
    if (!line.legal || !line.moves.length) continue;
    try {
      const position = new Chess(evidence.position.fen);
      const sanMoves: string[] = [];
      for (const notation of line.moves) {
        const move: Move | undefined = line.notation === 'uci'
          ? position.moves({ verbose: true }).find((candidate) => uciForMove(candidate) === notation)
          : position.moves({ verbose: true }).find((candidate) => candidate.san === notation);
        if (!move) throw new Error('Line contains a move that is not legal from the cited position.');
        sanMoves.push(position.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }).san);
      }
      const ending = line.termination === 'mate'
        ? ' The cited line ends in checkmate.'
        : line.termination === 'stalemate'
          ? ' The cited line ends in stalemate.'
          : line.termination === 'repetition'
            ? ' The cited cycle returns to a repeated position.'
            : '';
      return `One legal continuation recorded in the evidence is ${sanMoves.join(' ')}.${ending} This line is not ranked as best play.`;
    } catch {
      // Invalid or stale imported lines are not shown as a candidate response.
    }
  }
  return undefined;
}

function sourceExplanation(evidence: ChessEvidence): EvidenceExplanation {
  return evidence.explanation ?? {};
}

function linkedSources(evidence: ChessEvidence, byId: Map<string, ChessEvidence>): ChessEvidence[] {
  const ids = [
    ...stringArrayFact(evidence, 'supportingEvidenceIds'),
    ...stringArrayFact(evidence, 'relatedEvidenceIds'),
  ];
  return [...new Set(ids)].flatMap((id) => {
    const linked = byId.get(id);
    return linked ? [linked] : [];
  });
}

function sourceText(sources: ChessEvidence[], select: (item: ChessEvidence) => string | undefined): string | undefined {
  return sources.map(select).find((value) => Boolean(value?.trim()));
}

function momentWhatHappened(evidence: ChessEvidence, sources: ChessEvidence[]): string | undefined {
  const supplied = sourceText(sources, (item) => item.explanation?.whatHappened);
  if (supplied) return supplied;
  const category = stringFact(evidence, 'category') ?? evidence.subtype.replace(/^key-moment-/, '');
  const label = MOMENT_LABELS[category] ?? humanize(category);
  const move = evidence.position.san ? ` at ${evidence.position.san}` : '';
  const source = sources.find((item) => item.subtype === 'move-history');
  if (source && category === 'capture') return `The legal move ${source.position.san ?? evidence.position.san ?? ''} captures a ${describePiece(stringFact(source, 'capturedPiece'))}.`.trim();
  if (source && category === 'checkmate') return `The legal move ${source.position.san ?? evidence.position.san ?? ''} results in checkmate.`.trim();
  if (source && category === 'check') return `The legal move ${source.position.san ?? evidence.position.san ?? ''} gives check.`.trim();
  if (source && category === 'promotion') return `The pawn move ${source.position.san ?? evidence.position.san ?? ''} promotes to a ${describePiece(stringFact(source, 'promotion'))}.`.trim();
  if (source && category === 'material-change') {
    const delta = fact(source, 'whitePerspectiveMaterialDelta');
    const signed = typeof delta === 'number' && delta > 0 ? `+${delta}` : String(delta ?? 'changed');
    return `The legal move ${source.position.san ?? evidence.position.san ?? ''} changes the counted material balance by ${signed} point(s) from White's perspective.`.trim();
  }
  if (category === 'repetition') {
    const repeated = sources.find((item) => item.type === 'transition' && /repetition/.test(item.subtype));
    const count = repeated ? fact(repeated, 'repetitionCount') : undefined;
    return typeof count === 'number'
      ? `The recorded position has a repetition count of ${count}.`
      : 'A repeated-position event is recorded in the supplied legal history.';
  }
  const evidenceLabel = sourceText(sources, (item) => stringFact(item, 'label') ?? stringFact(item, 'title'));
  if (evidenceLabel) return `${evidenceLabel} is linked to the recorded${move ? ` move${move}` : ' position'}.`;
  return `A ${label} is linked to the recorded${move ? ` move${move}` : ' position'}.`;
}

function whatHappened(evidence: ChessEvidence, sources: ChessEvidence[]): string {
  const explanation = sourceExplanation(evidence);
  let text = evidence.subtype.startsWith('key-moment-')
    ? momentWhatHappened(evidence, sources) ?? explanation.whatHappened
    : explanation.whatHappened;

  if (!text && evidence.type === 'opening' && evidence.subtype === 'opening-match') {
    const names = stringArrayFact(evidence, 'openingNames');
    const eco = stringArrayFact(evidence, 'ecoCodes');
    const matchKind = stringFact(evidence, 'matchKind');
    const matchLabel = matchKind === 'transposition' ? 'transposition match' : matchKind === 'exact-sequence' ? 'move-sequence match' : 'indexed match';
    text = names.length
      ? `This position matches ${names.join(' / ')} in the opening index${eco.length ? ` (${eco.join(', ')})` : ''}; the index reports an ${matchLabel}.`
      : 'The position matches an entry in the opening index.';
  }

  if (!text && evidence.type === 'endgame' && evidence.subtype === 'material-phase-profile') {
    const phase = stringFact(evidence, 'endgamePhase');
    text = `The material profile is classified as ${humanize(phase)}. This is a piece-inventory label, not an evaluation of the position.`;
  }

  if (!text && evidence.status === 'deferred') {
    const reason = stringFact(evidence, 'reason');
    text = reason ? `This ${humanize(evidence.subtype)} assessment is deferred: ${reason}` : `This ${humanize(evidence.subtype)} assessment is deferred; it was not established from the available evidence.`;
  }

  if (!text) {
    const label = stringFact(evidence, 'label') ?? stringFact(evidence, 'title');
    const directDescription = descriptions(evidence)[0];
    if (label && directDescription) text = `${label}: ${directDescription}`;
    else if (label) text = `${label} is recorded in the ${humanize(evidence.type)} evidence.`;
    else if (directDescription) text = directDescription;
    else if (evidence.type === 'move_classification') {
      const san = evidence.position.san;
      text = `${san ? `The recorded move ${san}` : 'The recorded move'} has a ${humanize(evidence.subtype)} classification.`;
    } else text = `${humanize(evidence.subtype)} evidence is recorded for this position.`;
  }

  if (evidence.status === 'deferred' && !/\b(deferred|not assessed|not established|unavailable|outside)\b/i.test(text)) text = `Deferred assessment: ${text}`;
  return qualifyCandidate(text, evidence.status);
}

function whyItMatters(evidence: ChessEvidence, sources: ChessEvidence[]): string {
  const isMoment = evidence.subtype.startsWith('key-moment-');
  const source = isMoment
    ? sourceText(sources, (item) => item.explanation?.whyItMatters)
    : sourceExplanation(evidence).whyItMatters;
  if (source) return qualifyCandidate(source, evidence.status);
  if (evidence.status === 'deferred') {
    const reason = stringFact(evidence, 'reason');
    return reason
      ? `Coverage is deferred because ${reason} Missing analysis is not evidence that the motif is absent.`
      : 'This finding was not assessed; absence of a finding does not mean the position is motif-free.';
  }
  const implications = [
    ...stringArrayFact(evidence, 'possibleImplications'),
    ...sources.flatMap((item) => stringArrayFact(item, 'possibleImplications')),
  ];
  if (implications.length) return qualifyCandidate(implications[0], evidence.status);
  const consequence = stringFact(evidence, 'possibleConsequence')
    ?? sources.map((item) => stringFact(item, 'possibleConsequence')).find(Boolean);
  if (consequence) return qualifyCandidate(consequence, evidence.status);
  const descriptionsFromSources = sources.flatMap(descriptions);
  if (descriptionsFromSources.length) return qualifyCandidate(descriptionsFromSources[0], evidence.status);
  if (evidence.type === 'opening' && evidence.subtype === 'opening-match') return 'Opening recognition identifies an indexed position; it does not judge the move or the resulting position.';
  if (evidence.type === 'endgame') return 'The material label helps describe the board, but no theoretical result or conversion is inferred.';
  if (evidence.type === 'material') return 'Material counts describe piece inventory only; they do not evaluate compensation, initiative, or the position as a whole.';
  return evidence.status === 'candidate'
    ? 'This is a candidate cue, not a verified outcome or a judgment of move quality.'
    : 'The evidence records the stated board fact; no broader consequence is assumed.';
}

function possibleIdeaOrThreat(evidence: ChessEvidence, sources: ChessEvidence[]): string {
  const source = sourceExplanation(evidence).possibleIdea;
  if (source) return qualifyCandidate(source, evidence.status);
  const plan = stringFact(evidence, 'possiblePlan')
    ?? sources.map((item) => stringFact(item, 'possiblePlan')).find(Boolean);
  if (plan) return qualifyCandidate(plan, evidence.status);
  const implications = stringArrayFact(evidence, 'possibleImplications');
  const consequence = stringFact(evidence, 'possibleConsequence')
    ?? sources.map((item) => stringFact(item, 'possibleConsequence')).find(Boolean);
  if (implications.length) return qualifyCandidate(`One possible idea or consequence is: ${implications[0]}`, evidence.status);
  if (consequence) return qualifyCandidate(`One possible idea or consequence is: ${consequence}`, evidence.status);

  const category = stringFact(evidence, 'category') ?? evidence.subtype.replace(/^key-moment-/, '');
  if (category === 'check') return 'The checked side must answer the check with a legal move; this evidence does not rank the replies.';
  if (category === 'checkmate') return 'The recorded checkmate leaves no legal reply; no further response is available in that position.';
  if (category === 'capture') return 'Review what remains attacked and whether a recapture is legal; no exchange value is inferred.';
  if (evidence.type === 'opening' && evidence.subtype === 'opening-match') return 'No strategic plan is included with this opening-index match.';
  if (evidence.status === 'deferred') return 'No idea or threat is confirmed while this assessment remains deferred.';
  return 'No separate idea or threat is supported by this evidence; no player intent is assumed.';
}

function candidateResponse(evidence: ChessEvidence, sources: ChessEvidence[]): string {
  const explicit = sourceExplanation(evidence).candidateResponse
    ?? sources.map((item) => item.explanation?.candidateResponse).find(Boolean);
  if (explicit) return qualifyCandidate(explicit, evidence.status);
  const line = validatedLine(evidence) ?? sources.map(validatedLine).find(Boolean);
  if (line) return qualifyCandidate(line, evidence.status);
  const category = stringFact(evidence, 'category') ?? evidence.subtype.replace(/^key-moment-/, '');
  if (category === 'checkmate') return 'No legal reply exists after the move, according to the recorded checkmate fact.';
  if (category === 'check') return 'No response line is attached; inspect the legal replies from the checked position.';
  return 'No candidate response is supplied by this evidence; alternatives are not ranked.';
}

function concept(evidence: ChessEvidence): string {
  const source = sourceExplanation(evidence).concept;
  if (source) return source;
  const category = stringFact(evidence, 'category');
  if (category) return MOMENT_LABELS[category] ?? humanize(category);
  if (evidence.type === 'opening' && evidence.subtype === 'opening-match') return 'Opening recognition';
  if (evidence.type === 'endgame' && evidence.subtype === 'material-phase-profile') return 'Material-defined phase';
  return humanize(stringFact(evidence, 'conceptId') ?? stringFact(evidence, 'label') ?? evidence.subtype);
}

function learningTakeaway(evidence: ChessEvidence): string {
  const source = sourceExplanation(evidence).learningTakeaway;
  if (source) return qualifyCandidate(source, evidence.status);
  if (evidence.status === 'deferred') return 'Coverage is incomplete; do not treat an unreported pattern as absent.';
  if (evidence.type === 'opening') return 'Use the cited label and move sequence to compare ideas; an opening match does not rate the moves.';
  if (evidence.type === 'tactic') return 'Replay the legal replies and check what the line actually establishes; a legal line is not automatically best play.';
  if (evidence.type === 'defence') return 'Check the current threat and verify that any candidate resource is legal; resources are not ranked.';
  if (evidence.type === 'attack' || evidence.type === 'king_safety') return 'Treat geometric king-safety or attack cues as prompts for review, not proof of a forced attack.';
  if (evidence.type === 'strategy' || evidence.type === 'pawn_structure') return 'Verify the pattern on the cited board; this evidence does not rank plans or moves.';
  if (evidence.type === 'endgame') return 'Material profiles can guide review, but theoretical outcome and conversion are not assessed.';
  if (evidence.type === 'material') return 'Compare the exact piece counts; material totals alone are not a position evaluation.';
  if (evidence.status === 'candidate') return 'Keep this as a candidate interpretation and review the cited move and position before drawing a conclusion.';
  return 'Check the cited position, move, confidence, and status before drawing a conclusion.';
}

function evidenceLinks(evidence: ChessEvidence, sources: ChessEvidence[]): string[] {
  return [...new Set([evidence.evidenceId, ...sources.map((item) => item.evidenceId)])];
}

/**
 * Builds user-facing, evidence-bound explanations. The only input is the shared
 * ChessEvidence[] contract; detectors, game records, engines, and intent labels
 * are intentionally outside this service boundary.
 */
export function explainChessEvidence(evidence: readonly ChessEvidence[]): ExplanationResult {
  const unique = aggregateEvidenceBatches([evidence])
    .filter((item) => !(item.type === 'move_classification' && item.subtype === 'move-history'));
  const byId = new Map(unique.map((item) => [item.evidenceId, item]));
  const explanations = unique.map((item): StructuredExplanation => {
    const sources = linkedSources(item, byId);
    return {
      id: `ex_${item.evidenceId}`,
      ply: item.ply,
      side: item.side,
      status: item.status,
      confidence: item.confidence,
      whatHappened: whatHappened(item, sources),
      whyItMatters: whyItMatters(item, sources),
      possibleIdeaOrThreat: possibleIdeaOrThreat(item, sources),
      candidateResponse: candidateResponse(item, sources),
      concept: concept(item),
      learningTakeaway: learningTakeaway(item),
      evidenceIds: evidenceLinks(item, sources),
      references: item.references.map((reference) => ({ ...reference })),
    };
  });
  return {
    schemaVersion: 1,
    explanations,
    limitations: [
      'Explanations are built only from the shared ChessEvidence contract and validated legal lines; detector modules, game records, and engine scores are not consulted.',
      'Opening names, material phases, candidate ideas, and possible responses describe supplied evidence and are not move-quality judgments.',
      'A displayed legal line is replay-validated from its cited position and is not ranked as best play.',
      'Evidence confidence is recognition confidence, not move quality, game outcome probability, or player rating.',
      'No engine evaluation, human intent, universal accuracy score, or definitive blunder/best/brilliant label is produced.',
    ],
  };
}
