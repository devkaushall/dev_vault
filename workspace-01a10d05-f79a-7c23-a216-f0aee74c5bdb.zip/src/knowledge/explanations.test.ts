import { describe, expect, it } from 'vitest';
import { createChessEvidence } from './evidence';
import { explainChessEvidence } from './explanations';

function candidateEvidence(lineMoves: string[] = ['e1e2']) {
  return createChessEvidence({
    type: 'tactic',
    subtype: 'fork-candidate',
    status: 'candidate',
    confidence: 'medium',
    ply: 4,
    side: 'white',
    position: { fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: 3 },
    facts: [{ key: 'motif', value: 'fork-candidate' }],
    references: [{ kind: 'position', id: 'fixture-position', ply: 4 }],
    lines: [{ moves: lineMoves, notation: 'uci', legal: true, termination: 'position_change' }],
    source: 'explanation-test-fixture',
    explanation: {
      whatHappened: 'A candidate fork cue is recorded in the legal position.',
      whyItMatters: 'The line shows one possible tactical continuation, but its outcome is not established.',
      possibleIdea: 'A piece may attack more than one target if the fork cue holds.',
      concept: 'fork',
      learningTakeaway: 'Check every legal reply before treating a motif as a result.',
    },
    createdBy: { analyser: 'test-fixture', version: '1.0.0' },
  });
}

describe('evidence-only explanation service', () => {
  it('returns structured conditional explanations and revalidates candidate lines', () => {
    const source = candidateEvidence();
    const result = explainChessEvidence([source]);
    expect(result.explanations).toHaveLength(1);
    expect(result.explanations[0]).toMatchObject({
      status: 'candidate', confidence: 'medium', concept: 'fork', evidenceIds: [source.evidenceId],
    });
    expect(result.explanations[0].whatHappened).toMatch(/candidate/i);
    expect(result.explanations[0].possibleIdeaOrThreat).toMatch(/may attack/i);
    expect(result.explanations[0].candidateResponse).toMatch(/Ke2/);
    expect(result.explanations[0].candidateResponse).toMatch(/not ranked/i);
    expect(result.explanations[0].references).toEqual(source.references);
    expect(JSON.stringify(result.explanations)).not.toMatch(/best move|blunder|brilliant|inaccurate|player intended/i);
  });

  it('omits a candidate response when a purported line does not replay legally from the cited position', () => {
    const result = explainChessEvidence([candidateEvidence(['a1a8'])]);
    expect(result.explanations[0].candidateResponse).toMatch(/No candidate response is supplied/i);
    expect(result.explanations[0].candidateResponse).not.toMatch(/a1a8|Ra8/);
    expect(result.explanations[0].status).toBe('candidate');
  });

  it('renders an indexed opening label and preserves the position reference without exposing analyser names', () => {
    const opening = createChessEvidence({
      type: 'opening', subtype: 'opening-match', status: 'confirmed', confidence: 'high', ply: 2, side: 'black',
      position: { fen: 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2', moveNumber: 2 },
      facts: [
        { key: 'matchKind', value: 'transposition' },
        { key: 'openingNames', value: ['King\'s Pawn Game'] },
        { key: 'ecoCodes', value: ['C20'] },
      ],
      references: [{ kind: 'position', id: 'opening-position-2', ply: 2 }, { kind: 'opening', id: 'C20:King\'s Pawn Game' }],
      source: 'fixture-opening-index', createdBy: { analyser: 'test-fixture', version: '1.0.0' },
    });
    const result = explainChessEvidence([opening]);
    expect(result.explanations[0].whatHappened).toMatch(/King's Pawn Game.*C20.*transposition/i);
    expect(result.explanations[0]).toMatchObject({ status: 'confirmed', confidence: 'high', concept: 'Opening recognition' });
    expect(result.explanations[0].references).toEqual(opening.references);
    expect(JSON.stringify(result.explanations)).not.toMatch(/fixture-opening-index|test-fixture|opening-recognizer/);
  });

  it('keeps candidate and deferred evidence distinct and links explanations back to supporting evidence', () => {
    const support = createChessEvidence({
      type: 'strategy', subtype: 'piece-activity', status: 'candidate', confidence: 'low', ply: 5, side: 'white',
      position: { fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: 3 },
      facts: [{ key: 'label', value: 'White non-pawns geometrically influence 8 available squares' }, { key: 'possiblePlan', value: 'Look for a useful square for the least active piece.' }],
      references: [{ kind: 'position', id: 'strategy-position', ply: 5 }], source: 'private-detector-name',
      createdBy: { analyser: 'test-fixture', version: '1.0.0' },
    });
    const moment = createChessEvidence({
      type: 'transition', subtype: 'key-moment-strategic-cue', status: 'candidate', confidence: 'low', ply: 5, side: 'white',
      position: { fen: support.position.fen, moveNumber: 3, uci: 'e2e4', san: 'e4' },
      facts: [{ key: 'category', value: 'strategic-cue' }, { key: 'supportingEvidenceIds', value: [support.evidenceId] }],
      references: [{ kind: 'position', id: 'strategy-position', ply: 5 }], source: 'private-moment-name',
      createdBy: { analyser: 'test-fixture', version: '1.0.0' },
    });
    const deferred = createChessEvidence({
      type: 'tactic', subtype: 'unsupported-tactical-motif', status: 'deferred', confidence: 'low', ply: 6, side: 'black',
      position: { fen: support.position.fen, moveNumber: 4 }, facts: [{ key: 'reason', value: 'The position was outside the bounded detector pass.' }],
      references: [{ kind: 'position', id: 'deferred-position', ply: 6 }], source: 'private-tactics-name',
      createdBy: { analyser: 'test-fixture', version: '1.0.0' },
    });
    const result = explainChessEvidence([moment, deferred, support]);
    const linked = result.explanations.find((entry) => entry.id === `ex_${moment.evidenceId}`)!;
    const deferredExplanation = result.explanations.find((entry) => entry.id === `ex_${deferred.evidenceId}`)!;
    expect(linked.status).toBe('candidate');
    expect(linked.evidenceIds).toContain(support.evidenceId);
    expect(linked.possibleIdeaOrThreat).toMatch(/useful square/i);
    expect(deferredExplanation.status).toBe('deferred');
    expect(deferredExplanation.whatHappened).toMatch(/deferred/i);
    expect(deferredExplanation.whyItMatters).toMatch(/not evidence that the motif is absent/i);
    expect(JSON.stringify(result.explanations)).not.toMatch(/private-detector-name|private-moment-name|private-tactics-name/);
  });

  it('ignores raw history records and does not attach engine data', () => {
    const history = createChessEvidence({
      type: 'move_classification', subtype: 'move-history', status: 'confirmed', confidence: 'high', ply: 1, side: 'white',
      position: { fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: 1, uci: 'e1e2', san: 'Ke2' },
      facts: [{ key: 'san', value: 'Ke2' }], references: [{ kind: 'move', id: 'e1e2', uciMoves: ['e1e2'] }], source: 'fixture',
      createdBy: { analyser: 'test-fixture', version: '1.0.0' },
    });
    const result = explainChessEvidence([history]);
    expect(result.explanations).toEqual([]);
    expect(result).not.toHaveProperty('engine');
  });
});
