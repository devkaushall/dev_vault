import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { parseOpeningTsv, type OpeningCatalog } from './openings';
import { aggregateGameEvidence } from './evidenceAggregation';
import { classifyMoves } from './moveClassifier';
import type { GameRecord } from '../domain/chess/types';

function gameFrom(fen: string, uciMoves: string[], id = 'classifier-fixture'): GameRecord {
  let record = createGame({ id, initialFen: fen, now: '2026-10-05T00:00:00.000Z' });
  uciMoves.forEach((uci, index) => {
    record = applyMove(record, uci, { committedAt: `2026-10-05T00:00:${String(index + 1).padStart(2, '0')}.000Z` }).record;
  });
  return record;
}

async function classify(record: GameRecord, catalog: OpeningCatalog | null = parseOpeningTsv('eco\tname\tpgn\nC20\tKing\'s Pawn Game\t1. e4 e5')) {
  const aggregation = await aggregateGameEvidence(record, catalog ?? undefined, { maxAnalyzedPositions: 32, yieldToEventLoop: false });
  return classifyMoves(record, aggregation);
}

function categoriesFor(result: Awaited<ReturnType<typeof classify>>, ply: number): Set<string> {
  return new Set(result.moves.find((move) => move.ply === ply)?.categories.map((item) => item.category));
}

describe('evidence-based move classification', () => {
  it('identifies a legal developing move and a candidate central pawn break without rating its quality', async () => {
    const record = gameFrom(new Chess().fen(), ['e2e4', 'e7e5', 'g1f3']);
    const result = await classify(record);
    expect(categoriesFor(result, 1)).toContain('pawn-break');
    expect(categoriesFor(result, 3)).toContain('normal-developing-move');
    expect(result.moves.find((move) => move.ply === 3)?.categories.find((item) => item.category === 'normal-developing-move')?.status).toBe('candidate');
    const centralBreak = await classify(gameFrom(new Chess().fen(), ['d2d4']), null);
    expect(categoriesFor(centralBreak, 1)).toContain('piece-activity-change');
    expect(result.evidence.every((item) => item.type === 'move_classification' && !/\b(best|blunder|brilliant|inaccurate)\b/i.test(JSON.stringify(item.explanation ?? {})))).toBe(true);
  });

  it('classifies a legal capture with a move and source-evidence link, then marks checkmate as confirmed', async () => {
    const capture = await classify(gameFrom('4q2k/8/8/8/8/8/8/4R2K w - - 0 1', ['e1e8']));
    const captureFinding = capture.moves[0].categories.find((item) => item.category === 'capture');
    expect(captureFinding).toMatchObject({ status: 'confirmed', confidence: 'high' });
    expect(categoriesFor(capture, 1)).toContain('material-change');
    const materialFinding = capture.moves[0].categories.find((item) => item.category === 'material-change');
    const materialEvidence = capture.evidence.find((item) => item.evidenceId === materialFinding?.evidenceId);
    expect(materialEvidence?.facts).toContainEqual({ key: 'whitePerspectiveMaterialDelta', value: 9 });
    expect(materialEvidence?.facts).toContainEqual({ key: 'isEngineEvaluation', value: false });
    const captureEvidence = capture.evidence.find((item) => item.evidenceId === captureFinding?.evidenceId);
    expect(captureEvidence?.position).toMatchObject({ san: 'Rxe8+', uci: 'e1e8' });
    expect(captureEvidence?.references.some((reference) => reference.kind === 'move' && reference.id === 'e1e8')).toBe(true);
    expect(captureEvidence?.facts.some((fact) => fact.key === 'capture' && fact.value === true)).toBe(true);

    const matePosition = new Chess('7k/5Q2/6K1/8/8/8/8/8 w - - 0 1');
    const matingMove = matePosition.moves({ verbose: true }).find((move) => {
      const after = new Chess(matePosition.fen());
      after.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
      return after.isCheckmate();
    });
    expect(matingMove).toBeDefined();
    const record = gameFrom(matePosition.fen(), [`${matingMove!.from}${matingMove!.to}`]);
    const result = await classify(record);
    const move = result.moves[0];
    expect(move.categories.map((item) => item.category)).toContain('checkmate');
    expect(move.categories.find((item) => item.category === 'checkmate')).toMatchObject({ status: 'confirmed', confidence: 'high' });
    expect(result.evidence.find((item) => item.subtype === 'checkmate')?.facts.some((item) => item.key === 'legalReplies' && item.value === 0)).toBe(true);
  });

  it('classifies a verified stalemate as a confirmed move event', async () => {
    const result = await classify(gameFrom('k7/8/2K5/1Q6/8/8/8/8 w - - 0 1', ['b5b6']));
    const stalemate = result.moves[0].categories.find((item) => item.category === 'stalemate');
    expect(stalemate).toMatchObject({ status: 'confirmed', confidence: 'high' });
    const evidence = result.evidence.find((item) => item.evidenceId === stalemate?.evidenceId);
    expect(evidence?.facts).toContainEqual({ key: 'stalemate', value: true });
    expect(evidence?.facts).toContainEqual({ key: 'legalReplies', value: 0 });
  });

  it('labels a newly available forced material tactic as a candidate vulnerability, never a definitive blunder', async () => {
    const fen = 'k3r3/8/8/8/8/8/4R3/4Q2K w - - 0 1';
    const result = await classify(gameFrom(fen, ['e2f2']));
    const candidate = result.moves[0].categories.find((item) => item.category === 'candidate-tactical-mistake');
    expect(candidate).toBeDefined();
    expect(candidate?.status).toBe('candidate');
    const evidence = result.evidence.find((item) => item.evidenceId === candidate?.evidenceId);
    expect(evidence?.explanation?.whyItMatters).toMatch(/candidate vulnerability/i);
    expect(evidence?.facts.some((item) => item.key === 'opponentResources')).toBe(true);
    expect(evidence?.engine).toBeUndefined();
  });

  it('classifies an actual legal defensive resource and a king-safety change as candidates or verified resources', async () => {
    const inCheckFen = 'k3r3/8/8/8/8/8/3R4/4K3 w - - 0 1';
    const defence = await classify(gameFrom(inCheckFen, ['d2e2']));
    expect(categoriesFor(defence, 1)).toContain('defensive-move');
    expect(defence.moves[0].categories.find((item) => item.category === 'defensive-move')?.status).toBe('confirmed');

    const shelterFen = '4k3/8/8/8/8/8/6P1/6K1 w - - 0 1';
    const shelterRecord = gameFrom(shelterFen, ['g2g3']);
    const shelterAggregation = await aggregateGameEvidence(shelterRecord, undefined, { maxAnalyzedPositions: 8, yieldToEventLoop: false });
    const safety = classifyMoves(shelterRecord, shelterAggregation);
    expect(categoriesFor(safety, 1)).toContain('king-safety-change');
    const safetyFinding = safety.moves[0].categories.find((item) => item.category === 'king-safety-change');
    expect(safetyFinding?.status).toBe('candidate');
    const safetyEvidence = safety.evidence.find((item) => item.evidenceId === safetyFinding?.evidenceId);
    const safetySourceIds = safetyEvidence?.facts.find((fact) => fact.key === 'relatedEvidenceIds')?.value;
    expect(Array.isArray(safetySourceIds) && shelterAggregation.evidence.some((source) => safetySourceIds.includes(source.evidenceId) && source.type === 'king_safety')).toBe(true);
  });

  it('detects a legal exchange and a database opening transition with source references', async () => {
    const trade = await classify(gameFrom('3r3k/8/8/3q4/8/8/3Q4/7K w - - 0 1', ['d2d5', 'd8d5']));
    expect(categoriesFor(trade, 1)).toContain('exchange-trade');
    expect(trade.moves[0].categories.find((item) => item.category === 'exchange-trade')?.status).toBe('confirmed');
    const opening = await classify(gameFrom(new Chess().fen(), ['e2e4', 'e7e5']));
    expect(categoriesFor(opening, 2)).toContain('opening-transition');
    expect(opening.evidence.find((item) => item.subtype === 'opening-transition')?.references.some((item) => item.kind === 'opening')).toBe(true);
  });

  it('detects promotion, a material-defined endgame transition, and a candidate strategic cue', async () => {
    const promotion = await classify(gameFrom('7k/P7/8/8/8/8/8/7K w - - 0 1', ['a7a8q']));
    expect(categoriesFor(promotion, 1)).toContain('promotion-endgame-transition');
    expect(categoriesFor(promotion, 1)).toContain('check');

    const endgameRecord = gameFrom('7k/8/8/8/8/8/6q1/6RK w - - 0 1', ['g1g2']);
    const endgameAggregation = await aggregateGameEvidence(endgameRecord, undefined, { maxAnalyzedPositions: 8, yieldToEventLoop: false });
    const endgame = classifyMoves(endgameRecord, endgameAggregation);
    expect(categoriesFor(endgame, 1)).toContain('promotion-endgame-transition');
    const transition = endgame.moves[0].categories.find((item) => item.category === 'promotion-endgame-transition');
    expect(transition?.status).toBe('confirmed');
    const transitionEvidence = endgame.evidence.find((item) => item.evidenceId === transition?.evidenceId);
    expect(transitionEvidence?.facts.some((fact) => fact.key === 'phaseAfter' && fact.value === 'basic-mating-material')).toBe(true);
    const linkedIds = transitionEvidence?.facts.find((fact) => fact.key === 'relatedEvidenceIds')?.value;
    const profiles = endgameAggregation.evidence.filter((source) => source.type === 'endgame' && source.subtype === 'material-phase-profile');
    expect(Array.isArray(linkedIds) && profiles.some((profile) => linkedIds.includes(profile.evidenceId))).toBe(true);

    const strategic = await classify(gameFrom(new Chess().fen(), ['a2a3']), null);
    expect(categoriesFor(strategic, 1)).toContain('strategic-move');
    expect(strategic.moves[0].categories.find((item) => item.category === 'strategic-move')?.status).toBe('candidate');
  });

  it('returns unknown/deferred when evidence is insufficient and preserves exact category evidence IDs', async () => {
    const record = gameFrom(new Chess().fen(), ['a2a3']);
    const aggregation = await aggregateGameEvidence(record, undefined, { maxAnalyzedPositions: 32, yieldToEventLoop: false });
    const sparseAggregation = { ...aggregation, evidence: aggregation.evidence.filter((item) => item.type === 'move_classification' && item.subtype === 'move-history') };
    const result = classifyMoves(record, sparseAggregation);
    const move = result.moves[0];
    expect(move.categories.some((item) => item.category === 'unknown' && item.status === 'deferred')).toBe(true);
    expect(move.evidenceIds).toEqual(move.categories.map((item) => item.evidenceId));
    expect(move.evidenceIds.every((id) => result.evidence.some((item) => item.evidenceId === id))).toBe(true);

    const boundedRecord = gameFrom(new Chess().fen(), ['a2a3', 'a7a6'], 'bounded-classifier');
    const boundedAggregation = await aggregateGameEvidence(boundedRecord, undefined, { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    const bounded = classifyMoves(boundedRecord, boundedAggregation);
    expect(bounded.moves[0].categories.some((item) => item.category === 'deferred' && item.status === 'deferred')).toBe(true);
  });
});
