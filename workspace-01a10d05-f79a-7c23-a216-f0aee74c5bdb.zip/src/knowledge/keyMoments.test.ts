import { describe, expect, it } from 'vitest';
import { createChessEvidence, type ChessEvidence } from './evidence';
import { detectKeyMoments } from './keyMoments';

function item(args: {
  type?: ChessEvidence['type'];
  subtype: string;
  status?: ChessEvidence['status'];
  confidence?: ChessEvidence['confidence'];
  ply: number;
  uci?: string;
  san?: string;
  facts?: ChessEvidence['facts'];
  explanation?: ChessEvidence['explanation'];
  fen?: string;
}): ChessEvidence {
  const position = { fen: args.fen ?? '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: Math.floor(args.ply / 2) + 1, ...(args.uci ? { uci: args.uci } : {}), ...(args.san ? { san: args.san } : {}) };
  return createChessEvidence({
    type: args.type ?? 'move_classification',
    subtype: args.subtype,
    status: args.status ?? 'confirmed',
    confidence: args.confidence ?? 'high',
    ply: args.ply,
    side: 'white',
    position,
    facts: args.facts ?? [],
    references: [
      { kind: 'position', id: `position-${args.ply}`, ply: args.ply },
      ...(args.uci ? [{ kind: 'move' as const, id: args.uci, ply: args.ply, uciMoves: [args.uci], ...(args.san ? { sanMoves: [args.san] } : {}) }] : []),
    ],
    source: 'key-moment-test-fixture',
    explanation: args.explanation,
    createdBy: { analyser: 'test-fixture', version: '1.0.0' },
  });
}

describe('evidence-supported key moments', () => {
  it('surfaces checkmate, material change, promotion, stalemate, and repetition from exact facts', () => {
    const evidence = [
      item({ subtype: 'move-history', ply: 1, uci: 'e1e2', san: 'Ke2', facts: [{ key: 'checkmate', value: true }, { key: 'check', value: true }] }),
      item({ subtype: 'move-history', ply: 2, uci: 'e8e7', san: 'Ke7', facts: [{ key: 'whitePerspectiveMaterialDelta', value: -3 }] }),
      item({ subtype: 'move-history', ply: 3, uci: 'e7e8', san: 'Ke8', facts: [{ key: 'promotion', value: 'q' }] }),
      item({ subtype: 'move-history', ply: 4, uci: 'e1e2', san: 'Ke2', facts: [{ key: 'stalemate', value: true }] }),
      item({ subtype: 'move-history', ply: 5, uci: 'e1e8', san: 'Rxe8', fen: '4q2k/8/8/8/8/8/8/4R2K w - - 0 1', facts: [{ key: 'capture', value: true }, { key: 'capturedPiece', value: 'q' }] }),
      item({ type: 'transition', subtype: 'threefold-repetition', ply: 5, facts: [{ key: 'repetitionCount', value: 3 }] }),
      item({ type: 'transition', subtype: 'perpetual-check-pattern', ply: 6, facts: [{ key: 'separateDrawRule', value: false }] }),
    ];
    const result = detectKeyMoments(evidence);
    const categories = result.moments.map((moment) => moment.category);
    expect(categories).toEqual(expect.arrayContaining(['checkmate', 'capture', 'material-change', 'promotion', 'stalemate', 'repetition', 'perpetual-check-pattern']));
    expect(result.moments.find((moment) => moment.category === 'checkmate')?.status).toBe('confirmed');
    expect(result.moments.find((moment) => moment.category === 'repetition')?.evidence.references.some((reference) => reference.kind === 'position')).toBe(true);
  });

  it('keeps tactical opportunities and defensive resources candidate when the source evidence is uncertain', () => {
    const candidate = item({
      subtype: 'candidate-tactical-mistake', ply: 8, uci: 'e2f2', san: 'Rf2', status: 'candidate', confidence: 'medium',
      explanation: { whatHappened: 'A verified opponent resource appears after the move.', whyItMatters: 'A legal tactical resource is available in the analyzed position.' },
    });
    const defence = item({ type: 'defence', subtype: 'block-interpose', ply: 8, uci: 'd2e2', san: 'Re2', status: 'candidate', confidence: 'low' });
    const result = detectKeyMoments([candidate, defence]);
    expect(result.moments.find((moment) => moment.category === 'opportunity')).toMatchObject({ status: 'candidate', confidence: 'medium', uci: 'e2f2' });
    const defensiveMoment = result.moments.find((moment) => moment.category === 'defensive-resource');
    expect(defensiveMoment).toMatchObject({ status: 'candidate', ply: 8 });
    expect(defensiveMoment?.uci).toBeUndefined();
    expect(defensiveMoment?.san).toBeUndefined();
    expect(result.evidence.every((item) => item.engine === undefined)).toBe(true);
    expect(JSON.stringify(result)).not.toMatch(/best move|player intended/i);
  });

  it('does not promote mixed candidate evidence to confirmed or turn deferred coverage into a moment', () => {
    const candidate = item({ type: 'tactic', subtype: 'fork-candidate', ply: 7, uci: 'e2e4', status: 'candidate', confidence: 'low' });
    const confirmed = item({ type: 'tactic', subtype: 'verified-check', ply: 7, uci: 'e2e4', status: 'confirmed', confidence: 'high' });
    const deferred = item({ type: 'tactic', subtype: 'unsupported-motif', ply: 20, status: 'deferred', confidence: 'low' });
    const result = detectKeyMoments([confirmed, deferred, candidate]);
    expect(result.moments).toHaveLength(1);
    expect(result.moments[0]).toMatchObject({ category: 'tactic', status: 'candidate', confidence: 'low' });
    expect(result.moments[0].evidenceIds).toEqual(expect.arrayContaining([candidate.evidenceId, confirmed.evidenceId]));
    expect(result.moments.every((moment) => moment.ply !== deferred.ply)).toBe(true);
  });

  it('deduplicates evidence for one event and creates stable linked moment evidence', () => {
    const history = item({ subtype: 'move-history', ply: 1, uci: 'e1e2', san: 'Ke2', facts: [{ key: 'check', value: true }] });
    const classification = item({ subtype: 'check', ply: 1, uci: 'e1e2', san: 'Ke2', facts: [{ key: 'check', value: true }] });
    const first = detectKeyMoments([history, classification]);
    const second = detectKeyMoments([classification, history]);
    const checks = first.moments.filter((moment) => moment.category === 'check');
    expect(checks).toHaveLength(1);
    expect(checks[0].evidenceIds).toHaveLength(2);
    expect(checks[0].id).toBe(second.moments.find((moment) => moment.category === 'check')?.id);
  });
});
