import { Chess, SQUARES, type Color, type PieceSymbol, type Square } from 'chess.js';

const VALUES: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const PIECE_NAMES: Record<PieceSymbol, string> = { p: 'प्यादा', n: 'घोड़ा', b: 'ऊँट', r: 'हाथी', q: 'वज़ीर', k: 'राजा' };

export type EvidenceItem = { field: string; value: string | number | string[] };
export type PositionEvidence = {
  id: string;
  kind: 'verified-board-fact' | 'static-candidate';
  confidence: 'verified' | 'candidate';
  title: string;
  explanation: string;
  squares: Square[];
  evidence: EvidenceItem[];
  source: 'chess.js-legal-position' | 'static-geometry-v1';
};

export type PositionFacts = {
  fen: string;
  turn: Color;
  inCheck: boolean;
  checkmate: boolean;
  stalemate: boolean;
  legalMoveCount: number;
  whiteMaterialPoints: number;
  blackMaterialPoints: number;
  facts: PositionEvidence[];
  candidates: PositionEvidence[];
  limitations: string[];
};

function fileNumber(square: Square): number {
  return square.charCodeAt(0) - 97;
}

function rankNumber(square: Square): number {
  return Number(square[1]);
}

function piecesOf(chess: Chess, color: Color, type?: PieceSymbol): Square[] {
  return SQUARES.filter((square) => {
    const piece = chess.get(square);
    return piece?.color === color && (!type || piece.type === type);
  });
}

function countMaterial(chess: Chess, color: Color): number {
  return SQUARES.reduce((total, square) => {
    const piece = chess.get(square);
    return piece?.color === color ? total + VALUES[piece.type] : total;
  }, 0);
}

function passedPawns(chess: Chess, color: Color): Square[] {
  return piecesOf(chess, color, 'p').filter((square) => {
    const ownFile = fileNumber(square);
    const ownRank = rankNumber(square);
    return piecesOf(chess, color === 'w' ? 'b' : 'w', 'p').every((enemySquare) => {
      const enemyFile = fileNumber(enemySquare);
      const enemyRank = rankNumber(enemySquare);
      const isAhead = color === 'w' ? enemyRank > ownRank : enemyRank < ownRank;
      return !isAhead || Math.abs(enemyFile - ownFile) > 1;
    });
  });
}

function doubledPawnGroups(chess: Chess, color: Color): Square[][] {
  const byFile = new Map<number, Square[]>();
  for (const square of piecesOf(chess, color, 'p')) {
    const file = fileNumber(square);
    byFile.set(file, [...(byFile.get(file) ?? []), square]);
  }
  return [...byFile.values()].filter((squares) => squares.length > 1);
}

function isolatedPawns(chess: Chess, color: Color): Square[] {
  const allPawns = piecesOf(chess, color, 'p');
  return allPawns.filter((square) => !allPawns.some((other) => Math.abs(fileNumber(square) - fileNumber(other)) === 1));
}

function fileFacts(chess: Chess): PositionEvidence[] {
  const facts: PositionEvidence[] = [];
  for (let file = 0; file < 8; file++) {
    const squares = SQUARES.filter((square) => fileNumber(square) === file);
    const whitePawns = squares.filter((square) => chess.get(square)?.color === 'w' && chess.get(square)?.type === 'p');
    const blackPawns = squares.filter((square) => chess.get(square)?.color === 'b' && chess.get(square)?.type === 'p');
    const fileName = String.fromCharCode(97 + file);
    if (!whitePawns.length && !blackPawns.length) {
      facts.push({
        id: `open-file-${fileName}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `खुली फ़ाइल ${fileName}`,
        explanation: `${fileName}-फ़ाइल पर कोई प्यादा नहीं है। यह बोर्ड का तथ्य है; अपने-आप फ़ाइल पर कब्ज़ा करने की सलाह नहीं।`,
        squares,
        evidence: [{ field: 'whitePawns', value: 0 }, { field: 'blackPawns', value: 0 }],
        source: 'chess.js-legal-position',
      });
    } else if (!whitePawns.length || !blackPawns.length) {
      const sideId = whitePawns.length ? 'black' : 'white';
      const side = whitePawns.length ? 'काले' : 'सफ़ेद';
      facts.push({
        id: `semi-open-file-${sideId}-${fileName}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `${side} के पास ${fileName}-फ़ाइल अर्ध-खुली है`,
        explanation: `${fileName}-फ़ाइल पर ${side} का कोई प्यादा नहीं, जबकि विरोधी का कम-से-कम एक प्यादा है। फ़ाइल पर दबाव पूरी स्थिति पर निर्भर करता है।`,
        squares,
        evidence: [{ field: 'whitePawns', value: whitePawns.length }, { field: 'blackPawns', value: blackPawns.length }],
        source: 'chess.js-legal-position',
      });
    }
  }
  return facts;
}

function forkCandidates(chess: Chess): PositionEvidence[] {
  const ownSide = chess.turn();
  const enemySide = ownSide === 'w' ? 'b' : 'w';
  const candidates: PositionEvidence[] = [];
  for (const move of chess.moves({ verbose: true })) {
    const trial = new Chess(chess.fen({ forceEnpassantSquare: true }));
    trial.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const targets: Array<{ square: Square; type: PieceSymbol }> = [];
    for (const square of SQUARES) {
      const piece = trial.get(square);
      if (piece?.color === enemySide && (piece.type === 'k' || VALUES[piece.type] >= 3) && trial.attackers(square, ownSide).includes(move.to)) {
        targets.push({ square, type: piece.type });
      }
    }
    const distinct = [...new Map(targets.map((target) => [target.square, target])).values()];
    if (distinct.length >= 2) {
      candidates.push({
        id: `fork-candidate-${move.from}-${move.to}-${move.promotion ?? ''}`,
        kind: 'static-candidate',
        confidence: 'candidate',
        title: `${move.san} के बाद संभावित fork`,
        explanation: `चली गई गोटी ज्यामितीय रूप से ${distinct.map((target) => `${target.square} पर ${PIECE_NAMES[target.type]}`).join(' और ')} पर हमला करती है। बचाव, pins, exchanges या सामग्री जीतने की गणना नहीं की गई है।`,
        squares: [move.from, move.to, ...distinct.map((target) => target.square)],
        evidence: [
          { field: 'legalFirstMove', value: `${move.from}${move.to}${move.promotion ?? ''}` },
          { field: 'attackedTargets', value: distinct.map((target) => `${target.type}@${target.square}`) },
        ],
        source: 'static-geometry-v1',
      });
    }
  }
  return candidates;
}

export function analyzeStaticPosition(fen: string): PositionFacts {
  const chess = new Chess(fen);
  const whiteMaterialPoints = countMaterial(chess, 'w');
  const blackMaterialPoints = countMaterial(chess, 'b');
  const materialDetail = `सफ़ेद ${whiteMaterialPoints} अंक; काले ${blackMaterialPoints} अंक (केवल प्रचलित गोटी-मूल्य; यह engine evaluation नहीं है)।`;
  const facts: PositionEvidence[] = [
    {
      id: 'material-count',
      kind: 'verified-board-fact',
      confidence: 'verified',
      title: 'गोटियों का अंक-मूल्य',
      explanation: materialDetail,
      squares: [],
      evidence: [{ field: 'whitePoints', value: whiteMaterialPoints }, { field: 'blackPoints', value: blackMaterialPoints }],
      source: 'chess.js-legal-position',
    },
  ];

  for (const color of ['w', 'b'] as const) {
    const bishops = piecesOf(chess, color, 'b');
    if (bishops.length >= 2) {
      facts.push({
        id: `bishop-pair-${color}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `${color === 'w' ? 'सफ़ेद' : 'काले'} के पास ऊँटों की जोड़ी है`,
        explanation: `एक पक्ष के दो ऊँट मौजूद हैं। यह गिनती का तथ्य है; इससे लाभ होता है या नहीं, यह स्थिति पर निर्भर करता है।`,
        squares: bishops,
        evidence: [{ field: 'bishops', value: bishops }],
        source: 'chess.js-legal-position',
      });
    }
    const passers = passedPawns(chess, color);
    if (passers.length) {
      facts.push({
        id: `passed-pawns-${color}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `${color === 'w' ? 'सफ़ेद' : 'काले'} के passed pawn: ${passers.join(', ')}`,
        explanation: 'इन प्यादों के आगे समान या पास की फ़ाइल पर विरोधी प्यादा नहीं है। यह स्थिर जाँच promotion race या गोटी से रोके जाने का मूल्यांकन नहीं करती।',
        squares: passers,
        evidence: [{ field: 'squares', value: passers }],
        source: 'chess.js-legal-position',
      });
    }
    for (const group of doubledPawnGroups(chess, color)) {
      facts.push({
        id: `doubled-pawns-${color}-${group[0][0]}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `${color === 'w' ? 'सफ़ेद' : 'काले'} के ${group[0][0]}-फ़ाइल पर doubled pawns हैं`,
        explanation: 'एक ही रंग के दो या अधिक प्यादे एक फ़ाइल पर हैं। इस संरचना के लाभ और नुकसान दोनों हो सकते हैं; कोई रणनीतिक निर्णय नहीं निकाला गया।',
        squares: group,
        evidence: [{ field: 'squares', value: group }],
        source: 'chess.js-legal-position',
      });
    }
    const isolated = isolatedPawns(chess, color);
    if (isolated.length) {
      facts.push({
        id: `isolated-pawns-${color}`,
        kind: 'verified-board-fact',
        confidence: 'verified',
        title: `${color === 'w' ? 'सफ़ेद' : 'काले'} के isolated pawn: ${isolated.join(', ')}`,
        explanation: 'पास की फ़ाइल पर उसी पक्ष का प्यादा नहीं है। केवल यह संरचनात्मक तथ्य प्यादे की कमजोरी तय नहीं करता।',
        squares: isolated,
        evidence: [{ field: 'squares', value: isolated }],
        source: 'chess.js-legal-position',
      });
    }
  }
  facts.push(...fileFacts(chess));
  if (chess.isCheck()) {
    const checkedKing = piecesOf(chess, chess.turn(), 'k')[0];
    facts.unshift({
      id: 'side-to-move-in-check',
      kind: 'verified-board-fact',
      confidence: 'verified',
      title: `${chess.turn() === 'w' ? 'सफ़ेद' : 'काले'} राजा को शह है`,
      explanation: 'चाल चलने वाले पक्ष को ऐसी वैध चाल चलनी होगी जो शह हटाए।',
      squares: checkedKing ? [checkedKing] : [],
      evidence: [{ field: 'sideToMove', value: chess.turn() }, { field: 'legalMoveCount', value: chess.moves().length }],
      source: 'chess.js-legal-position',
    });
  }
  const candidates = forkCandidates(chess).slice(0, 8);
  return {
    fen: chess.fen({ forceEnpassantSquare: true }),
    turn: chess.turn(),
    inCheck: chess.isCheck(),
    checkmate: chess.isCheckmate(),
    stalemate: chess.isStalemate(),
    legalMoveCount: chess.moves().length,
    whiteMaterialPoints,
    blackMaterialPoints,
    facts,
    candidates,
    limitations: [
      'केवल स्थिर ज्यामिति: संभावित motif पूरी गणना, engine verdict या मानवीय मंशा का दावा नहीं है।',
      'Passed-pawn, isolated-pawn और फ़ाइल से जुड़े तथ्य पूरी रणनीतिक जाँच नहीं हैं।',
    ],
  };
}
