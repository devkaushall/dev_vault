import { describe, expect, it } from 'vitest';
import { analyzeStaticPosition } from './positionFacts';

describe('evidence-bound static recognition', () => {
  it('reports checked status and conventional material counts as verified board facts', () => {
    const result = analyzeStaticPosition('4k3/8/8/8/8/8/4r3/4K2R w - - 0 1');
    expect(result.inCheck).toBe(true);
    expect(result.facts[0]).toMatchObject({ id: 'side-to-move-in-check', confidence: 'verified' });
    expect(result.facts.some((fact) => fact.id === 'material-count' && fact.confidence === 'verified')).toBe(true);
  });

  it('detects pawn-count structure facts without inferring strategic quality', () => {
    const result = analyzeStaticPosition('4k3/2P5/8/8/8/8/2P5/4K3 w - - 0 1');
    expect(result.facts.some((fact) => fact.id.startsWith('doubled-pawns-w-'))).toBe(true);
    expect(result.facts.some((fact) => fact.id === 'isolated-pawns-w')).toBe(true);
    expect(result.facts.some((fact) => fact.id === 'passed-pawns-w' && fact.title.includes('c7'))).toBe(true);
    expect(result.facts.find((fact) => fact.id === 'material-count')?.explanation).toContain('engine evaluation नहीं');
  });

  it('labels a geometrically verified fork only as a candidate, not a won tactic', () => {
    const result = analyzeStaticPosition('4k1r1/3q4/8/3N4/8/8/8/4K3 w - - 0 1');
    const fork = result.candidates.find((candidate) => candidate.id.includes('d5-f6'));
    expect(fork).toMatchObject({ kind: 'static-candidate', confidence: 'candidate' });
    expect(fork?.explanation).toContain('गणना नहीं की गई है');
    expect(fork?.evidence).toContainEqual(expect.objectContaining({ field: 'attackedTargets', value: expect.arrayContaining(['q@d7', 'r@g8']) }));
  });
});
