import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { createChessEvidence, type ChessEvidence, type EvidenceType } from './evidence';
import { aggregateEvidenceBatches, aggregateGameEvidence, aggregatePositionEvidence } from './evidenceAggregation';
import { parseOpeningTsv } from './openings';
import { analyzeTactics } from './tactics';

function shortGame() {
  let record = createGame({ id: 'phase7-aggregate', now: '2026-10-05T00:00:00.000Z' });
  for (const [index, uci] of ['e2e4', 'e7e5'].entries()) {
    record = applyMove(record, uci, { committedAt: `2026-10-05T00:00:0${index + 1}.000Z` }).record;
  }
  return record;
}

const openingCatalog = () => parseOpeningTsv('eco\tname\tpgn\nC20\tKing\'s Pawn Game\t1. e4 e5');
const testFen = '4k3/8/8/8/8/8/8/4K3 w - - 0 1';

function evidenceOf(
  type: EvidenceType,
  subtype: string,
  source: string,
  status: ChessEvidence['status'],
  confidence: ChessEvidence['confidence'],
  ply = 0,
  references: ChessEvidence['references'] = [],
  extra: Partial<Pick<ChessEvidence, 'lines' | 'legalLineValidation'>> = {},
): ChessEvidence {
  return createChessEvidence({
    type,
    subtype,
    status,
    confidence,
    ply,
    side: 'white',
    position: { fen: testFen, moveNumber: 1 },
    facts: [{ key: 'sourceFact', value: `${type}:${subtype}` }],
    references,
    source,
    createdBy: { analyser: source, version: '1.0.0' },
    ...extra,
  });
}

describe('Phase 7 evidence aggregation', () => {
  it('collects Phase 5/6 detector outputs through a versioned, serializable contract', async () => {
    const report = await aggregateGameEvidence(shortGame(), openingCatalog(), { maxAnalyzedPositions: 4, yieldToEventLoop: false });
    const types = new Set(report.evidence.map((item) => item.type));
    expect(report.schemaVersion).toBe(1);
    const expectedTypes: EvidenceType[] = ['opening', 'strategy', 'pawn_structure', 'tactic', 'attack', 'defence', 'endgame', 'material', 'move_classification'];
    for (const type of expectedTypes) expect(types.has(type), `missing ${type} evidence`).toBe(true);
    expect(report.evidence.every((item) => item.evidenceId.startsWith('ev_') && item.createdBy.analyser && item.createdBy.version && item.source)).toBe(true);
    expect(report.evidence.every((item) => ['confirmed', 'candidate', 'deferred'].includes(item.status))).toBe(true);
    expect(report.evidence.some((item) => item.type === 'opening' && item.subtype === 'opening-match' && item.status === 'confirmed' && item.createdBy.analyser === 'opening-recognizer')).toBe(true);
    const phase = report.evidence.find((item) => item.type === 'endgame' && item.subtype === 'material-phase-profile');
    expect(phase).toMatchObject({ status: 'confirmed', confidence: 'high', createdBy: { analyser: 'endgame-detector' } });
    expect(phase?.facts.find((entry) => entry.key === 'endgamePhase')?.value).toBe('mixed-or-middlegame');
    expect(phase?.facts.find((entry) => entry.key === 'isEngineEvaluation')?.value).toBe(false);
    const moveHistory = report.evidence.find((item) => item.subtype === 'move-history');
    expect(moveHistory?.references.some((reference) => reference.kind === 'move' && reference.uciMoves?.length === 1)).toBe(true);
    expect(moveHistory?.references.filter((reference) => reference.kind === 'position')).toHaveLength(2);
    const serialized = JSON.stringify(report);
    expect(JSON.parse(serialized)).toEqual(report);
    expect(report.evidence.every((item) => item.engine === undefined)).toBe(true);
  });

  it('merges multiple detector batches without changing status, confidence, provenance, or references', () => {
    const tacticReference = { kind: 'move' as const, id: 'e2e4', ply: 2, uciMoves: ['e2e4'], sanMoves: ['e4'] };
    const extraPositionReference = { kind: 'position' as const, id: 'position-after' as const, ply: 3 };
    const tactic = evidenceOf('tactic', 'fork', 'tactics-detector', 'candidate', 'medium', 2, [tacticReference]);
    const sameTactic = { ...tactic, references: [extraPositionReference] };
    const opening = evidenceOf('opening', 'opening-match', 'opening-recognizer', 'confirmed', 'high', 0, [{ kind: 'opening', id: 'C20:King Pawn' }]);
    const strategy = evidenceOf('strategy', 'weak-square', 'strategy-detector', 'deferred', 'low', 1);

    const aggregated = aggregateEvidenceBatches([[tactic, strategy], [opening, sameTactic]]);
    expect(aggregated.map((item) => item.evidenceId)).toEqual([opening.evidenceId, strategy.evidenceId, tactic.evidenceId]);
    expect(aggregated).toHaveLength(3);
    expect(aggregated[0]).toMatchObject({ status: 'confirmed', confidence: 'high', source: 'opening-recognizer', createdBy: { analyser: 'opening-recognizer', version: '1.0.0' } });
    expect(aggregated[1]).toMatchObject({ status: 'deferred', confidence: 'low', source: 'strategy-detector' });
    expect(aggregated[2]).toMatchObject({ status: 'candidate', confidence: 'medium', source: 'tactics-detector' });
    expect(aggregated[2].references).toEqual([extraPositionReference, tacticReference].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))));
    expect(aggregateEvidenceBatches([[opening, sameTactic], [strategy, tactic]])).toEqual(aggregated);
  });

  it('rejects conflicting payloads that reuse one stable evidence ID', () => {
    const original = evidenceOf('attack', 'open-file', 'attack-detector', 'candidate', 'low');
    const conflict = { ...original, status: 'confirmed' as const };
    expect(() => aggregateEvidenceBatches([[original], [conflict]])).toThrow(/conflicting chess evidence/i);
  });

  it('preserves the validated detector proof and legal line without generating prose', () => {
    const mateFen = '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1';
    const detectorFinding = analyzeTactics(new Chess(mateFen)).findings.find((finding) => finding.motif === 'mating-pattern' && finding.state === 'confirmed');
    expect(detectorFinding).toBeDefined();
    const items = aggregatePositionEvidence({ fen: mateFen, ply: 0, sideToMove: 'w' });
    const mate = items.find((item) => item.type === 'tactic' && item.subtype === 'mating-pattern' && item.status === 'confirmed' && item.position.uci === detectorFinding?.triggeringMove?.uci);
    expect(mate?.legalLineValidation).toEqual(detectorFinding?.legalLine);
    expect(mate?.lines?.some((line) => line.legal === true && line.termination === 'mate' && line.moves.length === 1 && line.sanMoves?.length === 1)).toBe(true);
    expect(mate?.references.some((reference) => reference.kind === 'move' && reference.uciMoves?.length === 1)).toBe(true);
    expect(mate?.references.some((reference) => reference.kind === 'line' && reference.uciMoves?.length === reference.sanMoves?.length)).toBe(true);
    expect(mate?.facts).toContainEqual({ key: 'detectorConfidence', value: detectorFinding?.confidence });
    expect(mate && Object.hasOwn(mate, 'explanation')).toBe(false);
  });

  it('keeps tactical legal-line evidence traceable to the exact move and line', () => {
    const mateFen = '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1';
    const items = aggregatePositionEvidence({ fen: mateFen, ply: 0, sideToMove: 'w' });
    const mate = items.find((item) => item.type === 'tactic' && item.subtype === 'mating-pattern' && item.status === 'confirmed');
    expect(mate).toBeDefined();
    expect(mate?.lines?.some((line) => line.legal && line.termination === 'mate' && line.moves.length === 1)).toBe(true);
    expect(mate?.references.some((reference) => reference.kind === 'move' && reference.uciMoves?.length === 1)).toBe(true);
  });

  it('marks skipped deep positions as deferred without treating them as motif-free', async () => {
    const report = await aggregateGameEvidence(shortGame(), openingCatalog(), { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    expect(report.analyzedPositionPlies).toEqual([2]);
    const deferred = report.evidence.find((item) => item.subtype === 'detector-budget');
    expect(deferred).toMatchObject({ status: 'deferred', type: 'transition' });
    expect(deferred?.facts.some((fact) => String(fact.value).includes('not claimed to be motif-free'))).toBe(true);
  });

  it('rejects invalid or mismatched game history before aggregation', async () => {
    const record = shortGame();
    record.moveHistory[0] = { ...record.moveHistory[0], san: 'd4' };
    await expect(aggregateGameEvidence(record, openingCatalog(), { yieldToEventLoop: false })).rejects.toThrow(/mismatched SAN\/UCI/i);
  });

  it('records descriptive material counts and exact move facts without an engine score', async () => {
    const game = applyMove(createGame({ id: 'material-count-test', initialFen: 'k7/8/8/3p4/4P3/8/8/7K w - - 0 1' }), 'e4d5').record;
    const report = await aggregateGameEvidence(game, undefined, { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    const move = report.evidence.find((item) => item.subtype === 'move-history' && item.ply === 1);
    expect(move?.facts).toContainEqual({ key: 'whitePerspectiveMaterialDelta', value: 1 });
    expect(move?.facts).toContainEqual({ key: 'materialCountOnly', value: true });
    expect(move?.facts).toContainEqual({ key: 'isEngineEvaluation', value: false });
    expect(move?.facts).toContainEqual({ key: 'materialWeights', value: ['p=1', 'n=3', 'b=3', 'r=5', 'q=9'] });
    expect(move?.engine).toBeUndefined();
  });

  it('keeps the source record immutable during game aggregation', async () => {
    const record = shortGame();
    const before = JSON.stringify(record);
    await aggregateGameEvidence(record, openingCatalog(), { maxAnalyzedPositions: 2, yieldToEventLoop: false });
    expect(JSON.stringify(record)).toBe(before);
  });
});
