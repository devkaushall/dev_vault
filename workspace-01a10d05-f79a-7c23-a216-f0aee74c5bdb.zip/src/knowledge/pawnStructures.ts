import { Chess, SQUARES, type Color, type Square } from 'chess.js';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeEvidenceValue, type KnowledgeFinding } from './evidence';

export type PawnStructureType =
  | 'isolated-pawn'
  | 'doubled-pawn'
  | 'backward-pawn-candidate'
  | 'passed-pawn'
  | 'pawn-chain'
  | 'isolated-queens-pawn'
  | 'hanging-pawns-candidate'
  | 'carlsbad-like'
  | 'maroczy-bind-like'
  | 'hedgehog-like'
  | 'french-chain'
  | 'benoni-like'
  | 'dutch-stonewall-like'
  | 'majority-minority';

export const PAWN_STRUCTURE_TYPES: readonly PawnStructureType[] = [
  'isolated-pawn', 'doubled-pawn', 'backward-pawn-candidate', 'passed-pawn', 'pawn-chain',
  'isolated-queens-pawn', 'hanging-pawns-candidate', 'carlsbad-like', 'maroczy-bind-like',
  'hedgehog-like', 'french-chain', 'benoni-like', 'dutch-stonewall-like', 'majority-minority',
];

export type PawnStructureFinding = KnowledgeFinding & {
  structure: PawnStructureType;
  possiblePlan: string;
  candidate: boolean;
  side?: Color;
};

export type PawnStructureAnalysis = {
  fen: string;
  pawnCounts: { w: number; b: number };
  findings: PawnStructureFinding[];
  deferred: Array<{ structure: PawnStructureType; reason: string }>;
  limitations: string[];
};

type StructureSource = { section: string; basis: string };

const FILES = 'abcdefgh';
const CENTRAL_FILES = new Set([2, 3, 4, 5]);
const STRUCTURE_SOURCES: Readonly<Record<PawnStructureType, StructureSource>> = {
  'isolated-pawn': { section: '§3.2 Isolated Queen’s Pawn (IQP)', basis: 'The Atlas defines an isolated pawn by the absence of friendly pawns on neighboring files and warns that activity can compensate for it.' },
  'doubled-pawn': { section: '§3.2 Doubled pawns', basis: 'The Atlas defines doubled pawns as same-side pawns on one file and notes both structural costs and possible benefits.' },
  'backward-pawn-candidate': { section: '§3.2 Backward pawn', basis: 'The Atlas describes a backward pawn as difficult to advance with a weak square behind it; the detector requires a pawn-attacked advance square and a less-advanced neighbor structure.' },
  'passed-pawn': { section: '§3.2 Passed pawn', basis: 'The Atlas defines a passed pawn by the absence of opposing pawns that can stop or capture it on the same or adjacent files.' },
  'pawn-chain': { section: '§3.2 Pawn chain', basis: 'The Atlas describes pawn chains as diagonal pawn support and suggests examining the base or an opposing break.' },
  'isolated-queens-pawn': { section: '§3.2 Isolated Queen’s Pawn (IQP)', basis: 'The Atlas identifies the IQP as an unsupported d-pawn and notes both active-square/pawn-advance opportunities and blockading/exchange plans.' },
  'hanging-pawns-candidate': { section: '§3.2 Hanging pawns', basis: 'The Atlas describes adjacent c/d pawns without pawn support and notes activity/advance versus blockade/exchange plans.' },
  'carlsbad-like': { section: '§3.2 Carlsbad structure', basis: 'The Atlas associates the Carlsbad pawn structure with a queenside minority attack and central-break alternatives.' },
  'maroczy-bind-like': { section: '§3.2 Maróczy Bind', basis: 'The Atlas describes c4/e4 pawns constraining ...d5 and ...b5 breaks; it warns that the bind is not automatically winning.' },
  'hedgehog-like': { section: '§3.2 Hedgehog', basis: 'The Atlas describes compact pawns, surrendered space, and possible ...b5/...d5/...e5 counterbreaks.' },
  'french-chain': { section: '§3.2 French pawn chain', basis: 'The Atlas identifies White’s e5-d4 chain, ...c5 against d4, ...f6 against e5, and White’s space/central-stability choices.' },
  'benoni-like': { section: '§3.2 Benoni structure', basis: 'The Atlas describes White’s d5 space against Black’s queenside/c-file pressure and pawn breaks.' },
  'dutch-stonewall-like': { section: '§1.5 Dutch Defence; §3.2 Dutch Stonewall', basis: 'The Atlas identifies ...f5/...e6/...d5/...c6 as the Stonewall skeleton and notes e4 control, a potentially restricted c8-bishop and dark-square holes.' },
  'majority-minority': { section: '§3.2 Majority/minority', basis: 'The Atlas says wing pawn majorities may create a passed pawn while a minority may try to create a target; both depend on the concrete structure.' },
};

function opposite(color: Color): Color {
  return color === 'w' ? 'b' : 'w';
}

function sideLabel(color: Color): string {
  return color === 'w' ? 'White' : 'Black';
}

function fileIndex(square: Square): number {
  return square.charCodeAt(0) - 97;
}

function rankIndex(square: Square): number {
  return Number(square[1]);
}

function relativeRank(color: Color, square: Square): number {
  return color === 'w' ? rankIndex(square) : 9 - rankIndex(square);
}

function makeSquare(file: number, rank: number): Square | undefined {
  if (file < 0 || file > 7 || rank < 1 || rank > 8) return undefined;
  return `${FILES[file]}${rank}` as Square;
}

function pawnsOf(chess: Chess, color: Color): Square[] {
  return SQUARES.filter((square) => {
    const piece = chess.get(square);
    return piece?.color === color && piece.type === 'p';
  });
}

function pawnAttacks(chess: Chess, color: Color): Set<Square> {
  const direction = color === 'w' ? 1 : -1;
  const result = new Set<Square>();
  for (const pawn of pawnsOf(chess, color)) {
    for (const fileStep of [-1, 1]) {
      const target = makeSquare(fileIndex(pawn) + fileStep, rankIndex(pawn) + direction);
      if (target) result.add(target);
    }
  }
  return result;
}

function pawnGroupsByFile(pawns: readonly Square[]): Map<number, Square[]> {
  const groups = new Map<number, Square[]>();
  for (const pawn of pawns) {
    const file = fileIndex(pawn);
    groups.set(file, [...(groups.get(file) ?? []), pawn]);
  }
  return groups;
}

function pawnsOnFile(groups: Map<number, Square[]>, file: number): Square[] {
  return groups.get(file) ?? [];
}

function pawnEvidence(
  id: string,
  description: string,
  values: Readonly<Record<string, KnowledgeEvidenceValue>>,
  squares?: readonly Square[],
): KnowledgeEvidence {
  return { id, kind: 'board-state', description, values, ...(squares ? { squares } : {}) };
}

function createFinding(input: {
  structure: PawnStructureType;
  id: string;
  label: string;
  side?: Color;
  evidence: KnowledgeEvidence[];
  confidence: number;
  relevance: number;
  possiblePlan: string;
  candidate?: boolean;
}): PawnStructureFinding {
  const source = STRUCTURE_SOURCES[input.structure];
  const finding = assertKnowledgeFinding({
    conceptId: `pawn-structure.${input.structure}.${input.id}`,
    label: input.label,
    evidence: input.evidence,
    confidence: input.confidence,
    relevance: input.relevance,
    possibleImplications: [{ ...(input.side ? { side: input.side } : {}), description: input.possiblePlan }],
    provenance: [
      { kind: 'board-derivation', source: 'chess.js', method: 'static legal FEN parse and explicit pawn-square geometry; no opening-name inference' },
      { kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md', section: source.section, basis: source.basis },
    ],
  });
  return {
    ...finding,
    structure: input.structure,
    possiblePlan: input.possiblePlan,
    candidate: input.candidate ?? false,
    ...(input.side ? { side: input.side } : {}),
  };
}

function isPassedPawn(chess: Chess, color: Color, pawn: Square): boolean {
  const pawnFile = fileIndex(pawn);
  const pawnRank = rankIndex(pawn);
  return pawnsOf(chess, opposite(color)).every((enemyPawn) => {
    const enemyRank = rankIndex(enemyPawn);
    const ahead = color === 'w' ? enemyRank > pawnRank : enemyRank < pawnRank;
    return !ahead || Math.abs(fileIndex(enemyPawn) - pawnFile) > 1;
  });
}

function pawnChainComponents(chess: Chess, color: Color): Square[][] {
  const pawns = pawnsOf(chess, color);
  const pawnSet = new Set(pawns);
  const adjacency = new Map<Square, Set<Square>>(pawns.map((pawn) => [pawn, new Set<Square>()]));
  const direction = color === 'w' ? 1 : -1;
  for (const pawn of pawns) {
    for (const fileStep of [-1, 1]) {
      const target = makeSquare(fileIndex(pawn) + fileStep, rankIndex(pawn) + direction);
      if (!target || !pawnSet.has(target)) continue;
      adjacency.get(pawn)?.add(target);
      adjacency.get(target)?.add(pawn);
    }
  }
  const visited = new Set<Square>();
  const components: Square[][] = [];
  for (const pawn of pawns) {
    if (visited.has(pawn) || !adjacency.get(pawn)?.size) continue;
    const component: Square[] = [];
    const pending = [pawn];
    while (pending.length) {
      const current = pending.pop()!;
      if (visited.has(current)) continue;
      visited.add(current);
      component.push(current);
      pending.push(...(adjacency.get(current) ?? []));
    }
    if (component.length >= 2) components.push(component.sort((a, b) => relativeRank(color, a) - relativeRank(color, b)));
  }
  return components;
}

function backwardPawnCandidates(chess: Chess, color: Color): Square[] {
  const ownPawns = pawnsOf(chess, color);
  const ownPawnAttacks = pawnAttacks(chess, color);
  const enemyPawnAttacks = pawnAttacks(chess, opposite(color));
  const direction = color === 'w' ? 1 : -1;
  return ownPawns.filter((pawn) => {
    const front = makeSquare(fileIndex(pawn), rankIndex(pawn) + direction);
    if (!front || chess.get(front) || !enemyPawnAttacks.has(front) || ownPawnAttacks.has(front)) return false;
    const adjacent = ownPawns.filter((other) => Math.abs(fileIndex(other) - fileIndex(pawn)) === 1);
    return adjacent.length > 0 && adjacent.some((other) => relativeRank(color, other) > relativeRank(color, pawn));
  });
}

function hangingPawnGroups(chess: Chess, color: Color): Square[][] {
  const ownPawns = pawnsOf(chess, color);
  const supportedSquares = pawnAttacks(chess, color);
  const unprotected = ownPawns.filter((pawn) => CENTRAL_FILES.has(fileIndex(pawn)) && !supportedSquares.has(pawn));
  const adjacency = new Map<Square, Set<Square>>(unprotected.map((pawn) => [pawn, new Set<Square>()]));
  for (let first = 0; first < unprotected.length; first++) {
    for (let second = first + 1; second < unprotected.length; second++) {
      const a = unprotected[first];
      const b = unprotected[second];
      if (Math.abs(fileIndex(a) - fileIndex(b)) !== 1 || Math.abs(rankIndex(a) - rankIndex(b)) > 1) continue;
      adjacency.get(a)?.add(b);
      adjacency.get(b)?.add(a);
    }
  }
  const visited = new Set<Square>();
  const groups: Square[][] = [];
  for (const pawn of unprotected) {
    if (visited.has(pawn) || !adjacency.get(pawn)?.size) continue;
    const group: Square[] = [];
    const pending = [pawn];
    while (pending.length) {
      const current = pending.pop()!;
      if (visited.has(current)) continue;
      visited.add(current);
      group.push(current);
      pending.push(...(adjacency.get(current) ?? []));
    }
    if (group.length >= 2) groups.push(group.sort());
  }
  return groups;
}

function findCarlsbadLike(chess: Chess): Array<{ minority: Color; majority: Color; white: Square[]; black: Square[] }> {
  const pawns = { w: pawnsOf(chess, 'w'), b: pawnsOf(chess, 'b') };
  const files = { w: pawnGroupsByFile(pawns.w), b: pawnGroupsByFile(pawns.b) };
  const queenSide = { w: pawns.w.filter((sq) => fileIndex(sq) <= 2), b: pawns.b.filter((sq) => fileIndex(sq) <= 2) };
  const results: Array<{ minority: Color; majority: Color; white: Square[]; black: Square[] }> = [];
  for (const majority of ['w', 'b'] as const) {
    const minority = opposite(majority);
    if (queenSide[majority].length !== 3 || queenSide[minority].length !== 2) continue;
    if (!pawnsOnFile(files[majority], 0).length || !pawnsOnFile(files[majority], 1).length
      || !pawnsOnFile(files[minority], 0).length || !pawnsOnFile(files[minority], 1).length) continue;
    if (!pawnsOnFile(files[majority], 2).length || pawnsOnFile(files[minority], 2).length) continue;
    const centralFiles = [3, 4];
    const centralSupport = (['w', 'b'] as const).every((color) => centralFiles.every((file) =>
      pawnsOnFile(files[color], file).some((square) => relativeRank(color, square) >= 3 && relativeRank(color, square) <= 6),
    ));
    if (!centralSupport) continue;
    results.push({ minority, majority, white: queenSide.w, black: queenSide.b });
  }
  return results;
}

function maroczySides(chess: Chess): Color[] {
  const found: Color[] = [];
  for (const color of ['w', 'b'] as const) {
    const cRank = color === 'w' ? 4 : 5;
    const enemy = opposite(color);
    const ownPawns = pawnsOf(chess, color);
    const enemyPawns = pawnsOf(chess, enemy);
    const cPawn = ownPawns.find((square) => square === `c${cRank}`);
    const ePawn = ownPawns.find((square) => square === `e${cRank}`);
    const opponentHasNoCPawn = !enemyPawns.some((square) => fileIndex(square) === 2);
    const enemyHasDPawn = enemyPawns.some((square) => fileIndex(square) === 3);
    if (!cPawn || !ePawn || !opponentHasNoCPawn || !enemyHasDPawn) continue;
    const target = (color === 'w' ? 'd5' : 'd4') as Square;
    const attacks = pawnAttacks(chess, color);
    if (attacks.has(target)) found.push(color);
  }
  return found;
}

function hedgehogSides(chess: Chess): Color[] {
  const found: Color[] = [];
  for (const color of ['w', 'b'] as const) {
    const own = pawnsOf(chess, color);
    const ownFiles = pawnGroupsByFile(own);
    const requiredFiles = [0, 1, 3, 4];
    const requiredHomeRanks = requiredFiles.every((file) =>
      pawnsOnFile(ownFiles, file).some((square) => relativeRank(color, square) === 3),
    );
    const cPawnAbsent = pawnsOnFile(ownFiles, 2).length === 0;
    const compactPawns = own.filter((square) => relativeRank(color, square) <= 3).length;
    const opponentAdvancedCenter = pawnsOf(chess, opposite(color)).filter((square) =>
      CENTRAL_FILES.has(fileIndex(square)) && relativeRank(opposite(color), square) >= 4,
    ).length;
    if (requiredHomeRanks && cPawnAbsent && compactPawns >= 6 && opponentAdvancedCenter >= 2) found.push(color);
  }
  return found;
}

function frenchChains(chess: Chess): Array<{ side: Color; ownBase: Square; ownHead: Square; enemyBase: Square; enemyHead: Square }> {
  const found: Array<{ side: Color; ownBase: Square; ownHead: Square; enemyBase: Square; enemyHead: Square }> = [];
  for (const side of ['w', 'b'] as const) {
    const ownBase = (side === 'w' ? 'd4' : 'd5') as Square;
    const ownHead = (side === 'w' ? 'e5' : 'e4') as Square;
    const enemyBase = (side === 'w' ? 'd5' : 'd4') as Square;
    const enemyHead = (side === 'w' ? 'e6' : 'e3') as Square;
    if (chess.get(ownBase)?.color !== side || chess.get(ownBase)?.type !== 'p'
      || chess.get(ownHead)?.color !== side || chess.get(ownHead)?.type !== 'p'
      || chess.get(enemyBase)?.color !== opposite(side) || chess.get(enemyBase)?.type !== 'p'
      || chess.get(enemyHead)?.color !== opposite(side) || chess.get(enemyHead)?.type !== 'p') continue;
    const attacks = pawnAttacks(chess, side);
    if (attacks.has(ownHead)) found.push({ side, ownBase, ownHead, enemyBase, enemyHead });
  }
  return found;
}

function benoniLike(chess: Chess): boolean {
  return chess.get('c4')?.color === 'w' && chess.get('c4')?.type === 'p'
    && chess.get('d5')?.color === 'w' && chess.get('d5')?.type === 'p'
    && chess.get('c5')?.color === 'b' && chess.get('c5')?.type === 'p'
    && chess.get('e6')?.color === 'b' && chess.get('e6')?.type === 'p';
}

function dutchStonewall(chess: Chess): boolean {
  return (['c6', 'd5', 'e6', 'f5'] as Square[]).every((square) => chess.get(square)?.color === 'b' && chess.get(square)?.type === 'p');
}

function wingPawns(pawns: readonly Square[], wing: 'queenside' | 'kingside'): Square[] {
  return pawns.filter((square) => wing === 'queenside' ? fileIndex(square) <= 2 : fileIndex(square) >= 5);
}

export function analyzePawnStructures(fen: string): PawnStructureAnalysis {
  const chess = new Chess(fen);
  const normalizedFen = chess.fen({ forceEnpassantSquare: true });
  const findings: PawnStructureFinding[] = [];
  const pawns = { w: pawnsOf(chess, 'w'), b: pawnsOf(chess, 'b') };
  const byFile = { w: pawnGroupsByFile(pawns.w), b: pawnGroupsByFile(pawns.b) };

  for (const color of ['w', 'b'] as const) {
    for (const pawn of pawns[color]) {
      const file = fileIndex(pawn);
      const hasAdjacentSupportFile = pawns[color].some((other) => Math.abs(fileIndex(other) - file) === 1);
      if (!hasAdjacentSupportFile) {
        findings.push(createFinding({
          structure: 'isolated-pawn', id: `${color}-${pawn}`, side: color,
          label: `${sideLabel(color)} isolated pawn on ${pawn}`,
          evidence: [pawnEvidence(`isolated-${color}-${pawn}`, 'No friendly pawn occupies either neighboring file.', { pawn, adjacentFriendlyPawns: [] }, [pawn])],
          confidence: 1, relevance: 0.78,
          possiblePlan: 'Assess whether activity or a pawn advance compensates for the lack of adjacent-pawn support; do not assume the pawn is weak.',
        }));
      }
      if (file === 3 && pawnsOnFile(byFile[color], 3).length === 1
        && !pawnsOnFile(byFile[color], 2).length && !pawnsOnFile(byFile[color], 4).length) {
        findings.push(createFinding({
          structure: 'isolated-queens-pawn', id: `${color}-${pawn}`, side: color,
          label: `${sideLabel(color)} isolated queen’s pawn (IQP) on ${pawn}`,
          evidence: [pawnEvidence(
            `iqp-${color}-${pawn}`, 'Exactly one friendly pawn is on the d-file and there are no friendly pawns on c- or e-files.',
            { pawn, cFileFriendlyPawns: 0, dFileFriendlyPawns: 1, eFileFriendlyPawns: 0 }, [pawn],
          )],
          confidence: 1, relevance: 0.86,
          possiblePlan: 'For the IQP side, consider activity, e5/c5 squares and a supported advance; the opponent may seek exchanges or a blockade.',
        }));
      }
    }
    for (const [file, group] of byFile[color]) {
      if (group.length < 2) continue;
      const name = FILES[file];
      findings.push(createFinding({
        structure: 'doubled-pawn', id: `${color}-${name}`, side: color,
        label: `${sideLabel(color)} doubled pawns on the ${name}-file`,
        evidence: [pawnEvidence(`doubled-${color}-${name}`, 'At least two friendly pawns occupy the same file.', { file: name, pawns: group }, group)],
        confidence: 1, relevance: 0.72,
        possiblePlan: 'Review whether the doubled pawns create targets or useful open-file/central control; the count alone does not rate them.',
      }));
    }

    for (const pawn of backwardPawnCandidates(chess, color)) {
      const front = makeSquare(fileIndex(pawn), rankIndex(pawn) + (color === 'w' ? 1 : -1))!;
      findings.push(createFinding({
        structure: 'backward-pawn-candidate', id: `${color}-${pawn}`, side: color,
        label: `${sideLabel(color)} backward-pawn candidate on ${pawn}`,
        evidence: [pawnEvidence(
          `backward-${color}-${pawn}`, 'The pawn is behind at least one adjacent-file friendly pawn, its advance square is empty and pawn-attacked by the opponent, and no friendly pawn attacks that square.',
          { pawn, advanceSquare: front, enemyPawnAttacksAdvance: true, friendlyPawnSupportsAdvance: false }, [pawn, front],
        )],
        confidence: 0.84, relevance: 0.72, candidate: true,
        possiblePlan: 'Consider supporting or advancing the pawn only if safe; the opponent may blockade it or apply file pressure.',
      }));
    }

    for (const pawn of pawns[color].filter((square) => isPassedPawn(chess, color, square))) {
      findings.push(createFinding({
        structure: 'passed-pawn', id: `${color}-${pawn}`, side: color,
        label: `${sideLabel(color)} passed pawn on ${pawn}`,
        evidence: [pawnEvidence(
          `passed-${color}-${pawn}`, 'No opposing pawn is ahead on the same or an adjacent file.',
          { pawn, enemyPawnsOnSameOrAdjacentFilesAhead: 0 }, [pawn],
        )],
        confidence: 1, relevance: 0.8,
        possiblePlan: 'Assess support and blockade squares; this structural test does not evaluate promotion races or piece control.',
      }));
    }

    for (const component of pawnChainComponents(chess, color)) {
      const baseRank = Math.min(...component.map((square) => relativeRank(color, square)));
      const headRank = Math.max(...component.map((square) => relativeRank(color, square)));
      const bases = component.filter((square) => relativeRank(color, square) === baseRank);
      const heads = component.filter((square) => relativeRank(color, square) === headRank);
      findings.push(createFinding({
        structure: 'pawn-chain', id: `${color}-${component.join('-')}`, side: color,
        label: `${sideLabel(color)} pawn chain of ${component.length} pawn(s)`,
        evidence: [pawnEvidence(
          `chain-${color}-${component.join('-')}`, 'Every connected pawn in this component is diagonally defended by another friendly pawn.',
          { chainSquares: component, basePawns: bases, headPawns: heads }, component,
        )],
        confidence: 1, relevance: 0.76,
        possiblePlan: 'Compare pressure on the chain base with a counterbreak on the other wing; chain direction alone does not determine an attack.',
      }));
    }

    for (const group of hangingPawnGroups(chess, color)) {
      findings.push(createFinding({
        structure: 'hanging-pawns-candidate', id: `${color}-${group.join('-')}`, side: color,
        label: `${sideLabel(color)} unsupported adjacent central-pawn group: ${group.join(', ')}`,
        evidence: [pawnEvidence(
          `hanging-${color}-${group.join('-')}`, 'At least two adjacent-file central pawns are close together and neither is currently defended by a friendly pawn.',
          { pawns: group, pawnSupported: false }, group,
        )],
        confidence: 0.84, relevance: 0.73, candidate: true,
        possiblePlan: 'The side may seek activity and a timely advance; the opponent may seek exchanges or a blockade. Piece support is not evaluated here.',
      }));
    }
  }

  for (const { minority, majority, white, black } of findCarlsbadLike(chess)) {
    findings.push(createFinding({
      structure: 'carlsbad-like', id: `${minority}-minority`, side: minority,
      label: `Carlsbad-like queenside pawn structure: ${sideLabel(minority)} minority vs ${sideLabel(majority)} majority`,
      evidence: [pawnEvidence(
        'carlsbad-like-structure', 'Both sides retain a/b pawns and central d/e pawns; only the majority side retains a c-pawn, creating a 2-v-3 queenside count.',
        { minoritySide: minority, majoritySide: majority, whiteQueensidePawns: white, blackQueensidePawns: black }, [...white, ...black],
      )],
      confidence: 0.9, relevance: 0.88, candidate: true,
      possiblePlan: 'The minority side can consider a minority attack; the majority side can seek a passed pawn or central play. Verify piece placement before choosing either plan.',
    }));
  }

  for (const color of maroczySides(chess)) {
    const cSquare = (color === 'w' ? 'c4' : 'c5') as Square;
    const eSquare = (color === 'w' ? 'e4' : 'e5') as Square;
    const target = (color === 'w' ? 'd5' : 'd4') as Square;
    findings.push(createFinding({
      structure: 'maroczy-bind-like', id: color, side: color,
      label: `${sideLabel(color)} Maroczy Bind-like c/e pawn structure`,
      evidence: [pawnEvidence(
        `maroczy-${color}`, 'Friendly c/e pawns occupy the central fourth/fifth rank and both geometrically control the d5/d4 square; the opponent has no c-pawn and retains a d-pawn.',
        { cPawn: cSquare, ePawn: eSquare, controlledCentralSquare: target, opponentCPawns: 0 }, [cSquare, eSquare, target],
      )],
      confidence: 0.9, relevance: 0.85, candidate: true,
      possiblePlan: 'Maintain central control and watch for ...d5/...b5 (or the mirrored breaks); the bind is not automatically winning.',
    }));
  }

  for (const color of hedgehogSides(chess)) {
    const ownPawns = pawns[color];
    findings.push(createFinding({
      structure: 'hedgehog-like', id: color, side: color,
      label: `${sideLabel(color)} compact Hedgehog-like pawn structure`,
      evidence: [pawnEvidence(
        `hedgehog-${color}`, 'a/b/d/e pawns are compact on the home-side third rank, the c-pawn is absent, at least six friendly pawns remain compact, and the opponent has central advanced pawns.',
        { compactPawns: ownPawns.filter((square) => relativeRank(color, square) <= 3), missingCPawn: true,
          opponentAdvancedCentralPawns: pawns[opposite(color)].filter((square) => CENTRAL_FILES.has(fileIndex(square)) && relativeRank(opposite(color), square) >= 4) }, ownPawns,
      )],
      confidence: 0.88, relevance: 0.79, candidate: true,
      possiblePlan: 'Keep the compact formation until a supported ...b5, ...d5, or ...e5 counterbreak is ready; avoid treating the label as an automatic evaluation.',
    }));
  }

  for (const chain of frenchChains(chess)) {
    findings.push(createFinding({
      structure: 'french-chain', id: chain.side, side: chain.side,
      label: `${sideLabel(chain.side)} French-chain structure ${chain.ownHead}-${chain.ownBase}`,
      evidence: [pawnEvidence(
        `french-chain-${chain.side}`, 'The side has a diagonally linked e/d pawn chain, and the opponent has the matching e/d central pawns.',
        { ownBase: chain.ownBase, ownHead: chain.ownHead, enemyBase: chain.enemyBase, enemyHead: chain.enemyHead },
        [chain.ownBase, chain.ownHead, chain.enemyBase, chain.enemyHead],
      )],
      confidence: 0.96, relevance: 0.88, candidate: false,
      possiblePlan: chain.side === 'w'
        ? 'Black may target d4 with ...c5 or e5 with ...f6; White can preserve kingside space or stabilize the centre.'
        : 'White can examine breaks against the chain base/head and choose between pressure and central stabilization.',
    }));
  }

  if (benoniLike(chess)) {
    findings.push(createFinding({
      structure: 'benoni-like', id: 'black-modern-skeleton', side: 'b',
      label: 'Benoni-like pawn structure: White d5/c4 space versus Black c5/e6 counterplay',
      evidence: [pawnEvidence(
        'benoni-skeleton', 'White pawns occupy c4/d5 while Black pawns occupy c5/e6; the label is derived only from this board pattern.',
        { whiteSpacePawns: ['c4', 'd5'], blackCounterplayPawns: ['c5', 'e6'] }, ['c4', 'd5', 'c5', 'e6'],
      )],
      confidence: 0.9, relevance: 0.86, candidate: true,
      possiblePlan: 'White may use d5 space; Black may seek c-file/queenside pressure and pawn breaks. Compare piece activity before committing.',
    }));
  }

  if (dutchStonewall(chess)) {
    findings.push(createFinding({
      structure: 'dutch-stonewall-like', id: 'black', side: 'b',
      label: 'Black Dutch Stonewall-like f5/e6/d5/c6 pawn skeleton',
      evidence: [pawnEvidence(
        'dutch-stonewall-skeleton', 'Black pawns are actually present on f5, e6, d5, and c6; no opening label is consulted.',
        { blackPawnSquares: ['f5', 'e6', 'd5', 'c6'] }, ['f5', 'e6', 'd5', 'c6'],
      )],
      confidence: 1, relevance: 0.88, candidate: false,
      possiblePlan: 'The structure contests e4; review the c8-bishop and dark-square holes before seeking ...c5 or ...e5.',
    }));
  }

  for (const wing of ['queenside', 'kingside'] as const) {
    const counts = { w: wingPawns(pawns.w, wing), b: wingPawns(pawns.b, wing) };
    const difference = Math.abs(counts.w.length - counts.b.length);
    if (difference < 1 || Math.min(counts.w.length, counts.b.length) < 2) continue;
    const majority: Color = counts.w.length > counts.b.length ? 'w' : 'b';
    const minority = opposite(majority);
    findings.push(createFinding({
      structure: 'majority-minority', id: `${wing}-${majority}`, side: majority,
      label: `${sideLabel(majority)} ${wing} pawn majority (${counts[majority].length} vs ${counts[minority].length})`,
      evidence: [pawnEvidence(
        `majority-${wing}-${majority}`, 'Pawn counts on the a-c or f-h files; central d/e pawns are excluded.',
        { wing, majoritySide: majority, majorityPawns: counts[majority], minoritySide: minority, minorityPawns: counts[minority] },
        [...counts.w, ...counts.b],
      )],
      confidence: 1, relevance: Math.min(1, difference / 3), candidate: true,
      possiblePlan: 'A wing majority may help create a passed pawn; the minority may try to create a target. This count is not itself a winning plan.',
    }));
  }

  const detected = new Set(findings.map((finding) => finding.structure));
  const deferred = PAWN_STRUCTURE_TYPES.filter((structure) => !detected.has(structure)).map((structure) => ({
    structure,
    reason: structure === 'carlsbad-like'
      ? 'The specific 2-v-3 queenside minority skeleton with central d/e pawns is absent.'
      : structure === 'maroczy-bind-like'
        ? 'The c/e central bind conditions and opponent c/d-pawn relation are absent.'
        : structure === 'hedgehog-like'
          ? 'The compact c-pawn-absent shell plus opposing central space conditions are absent.'
          : structure === 'french-chain'
            ? 'The linked d/e chain and matching opposing central pawns are absent.'
            : structure === 'benoni-like'
              ? 'The c4/d5 versus c5/e6 board skeleton is absent.'
              : structure === 'dutch-stonewall-like'
                ? 'Black does not have pawns on all four defining Stonewall squares f5/e6/d5/c6.'
                : 'No pawn-square group met this detector’s explicit board-condition threshold.',
  }));

  return {
    fen: normalizedFen,
    pawnCounts: { w: pawns.w.length, b: pawns.b.length },
    findings,
    deferred,
    limitations: [
      'All labels come from current pawn squares; no ECO, opening name, move order, engine, or human-intent inference is used.',
      'Backward, hanging, Carlsbad, Maroczy, Hedgehog, Benoni, and named-structure results are conservative candidates/skeletons; alternate definitions and move orders may not match these thresholds.',
      'Plans are conditional educational implications, not evaluation or best-move advice; pawn geometry does not measure piece support, king safety, tactics, or endgame races.',
    ],
  };
}
