import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { aggregateGameEvidence } from './evidenceAggregation';
import { detectKeyMoments } from './keyMoments';

function repeatKnights(cycles: number) {
  let record = createGame({ id: `repetition-${cycles}`, now: '2026-10-05T00:00:00.000Z' });
  const line = ['g1f3', 'g8f6', 'f3g1', 'f6g8'];
  for (const [index, uci] of Array.from({ length: cycles }, () => line).flat().entries()) {
    record = applyMove(record, uci, { committedAt: `2026-10-05T00:${String(Math.floor(index / 60)).padStart(2, '0')}:${String((index % 60) + 1).padStart(2, '0')}.000Z` }).record;
  }
  return record;
}

describe('repetition evidence from canonical move history', () => {
  it('detects a repeated legal checking cycle as a candidate perpetual-check pattern', async () => {
    let record = createGame({ id: 'perpetual-check-pattern', initialFen: '7k/R7/8/8/8/8/8/2K5 w - - 0 1' });
    const cycle = ['a7a8', 'h8h7', 'a8a7', 'h7h8'];
    for (const [index, uci] of [...cycle, ...cycle].entries()) record = applyMove(record, uci, { committedAt: `2026-10-05T00:00:${String(index + 1).padStart(2, '0')}.000Z` }).record;
    const report = await aggregateGameEvidence(record, undefined, { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    const perpetual = report.evidence.find((item) => item.subtype === 'perpetual-check-pattern');
    expect(perpetual).toMatchObject({ status: 'candidate', confidence: 'medium', ply: 8, side: 'white' });
    expect(perpetual?.lines?.[0]).toMatchObject({ legal: true, termination: 'repetition', moves: cycle });
    expect(perpetual?.facts).toContainEqual({ key: 'separateDrawRule', value: false });
    const moments = detectKeyMoments(report.evidence).moments;
    expect(moments.some((moment) => moment.category === 'perpetual-check-pattern' && moment.status === 'candidate')).toBe(true);
    expect(moments.some((moment) => moment.category === 'repetition' && moment.status === 'confirmed')).toBe(true);
  });

  it('distinguishes a threefold claim opportunity from automatic fivefold repetition', async () => {
    const threefold = await aggregateGameEvidence(repeatKnights(2), undefined, { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    const three = threefold.evidence.find((item) => item.subtype === 'threefold-repetition');
    expect(three).toMatchObject({ type: 'transition', status: 'confirmed', confidence: 'high', ply: 8 });
    expect(three?.facts).toContainEqual({ key: 'claimRequired', value: true });

    const fivefold = await aggregateGameEvidence(repeatKnights(4), undefined, { maxAnalyzedPositions: 1, yieldToEventLoop: false });
    const five = fivefold.evidence.find((item) => item.subtype === 'fivefold-repetition');
    expect(five).toMatchObject({ type: 'transition', status: 'confirmed', confidence: 'high', ply: 16 });
    expect(five?.facts).toContainEqual({ key: 'automaticFivefold', value: true });
    expect(five?.references.filter((reference) => reference.kind === 'position').map((reference) => reference.ply)).toEqual([0, 4, 8, 12, 16]);
  });
});
