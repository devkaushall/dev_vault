import { Chess, SQUARES, type Color, type Move, type Piece, type PieceSymbol, type Square } from 'chess.js';
import { deriveDrawState } from '../domain/chess/position';
import { positionKey, uciForMove } from '../domain/chess/position';
import type { GameRecord } from '../domain/chess/types';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeFinding } from './evidence';
import { analyzeTactics, type TacticalAnalysis, type TacticalLegalLine, type TacticalMove } from './tactics';

export const DEFENCE_RESOURCES = [
  'remove-attacker',
  'reinforce-target',
  'block-interpose',
  'luft',
  'king-reposition',
  'castling',
  'cut-attacker-supply',
  'return-material',
  'counterattack',
  'counter-check',
  'queen-trade',
  'repetition',
  'blockade',
  'fortress',
  'stalemate-resource',
  'defensive-sacrifice',
] as const;

export type DefenceResourceMotif = (typeof DEFENCE_RESOURCES)[number];
export type DefenceResourceState = 'confirmed' | 'candidate';
export type DefenceThreatCategory = 'checks' | 'captures' | 'threats';
export type DefenceThreatState = 'confirmed' | 'candidate';

export type DefenceThreat = KnowledgeFinding & {
  category: DefenceThreatCategory;
  state: DefenceThreatState;
  side: Color;
  move?: TacticalMove;
  targetSquares: Square[];
  severity: number;
};

export type DefenceThreatAssessment = {
  order: readonly ['checks', 'captures', 'threats'];
  checks: DefenceThreat[];
  captures: DefenceThreat[];
  threats: DefenceThreat[];
  priorityCategory: DefenceThreatCategory | 'none';
  mostDangerousVerifiedThreat: DefenceThreat | null;
  mostDangerousCandidateThreat: DefenceThreat | null;
  priorityExplanation: string;
};

export type DefenceResourceFinding = KnowledgeFinding & {
  state: DefenceResourceState;
  motif: DefenceResourceMotif;
  side: Color;
  triggeringMove?: TacticalMove;
  boardEvidence: KnowledgeEvidence[];
  legalLine: TacticalLegalLine;
  possibleConsequence: string;
};

export type DeferredDefenceResource = {
  motif: DefenceResourceMotif;
  state: 'deferred';
  reason: string;
};

export type DefenceAnalysis = {
  version: 1;
  positionFen: string;
  defendingSide: Color;
  threatAssessment: DefenceThreatAssessment;
  resources: DefenceResourceFinding[];
  deferredResources: DeferredDefenceResource[];
  limitations: string[];
};

const MATERIAL_VALUE: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const REPLY_DISPLAY_LIMIT = 48;
const THREAT_DISPLAY_LIMIT = 48;
const DEFERRED_RESOURCES: DeferredDefenceResource[] = [
  { motif: 'fortress', state: 'deferred', reason: 'No fortress proof is implemented; static material/activity patterns cannot establish that the opponent has no breakthrough.' },
];
const BOARD_PROVENANCE = [
  { kind: 'board-derivation' as const, source: 'chess.js' as const, method: 'legal move/reply generation and board-derived threat/resource checks; no engine ranking' },
];

function opposite(side: Color): Color {
  return side === 'w' ? 'b' : 'w';
}

function squareAt(file: number, rank: number): Square | null {
  if (file < 0 || file > 7 || rank < 1 || rank > 8) return null;
  return `${String.fromCharCode(97 + file)}${rank}` as Square;
}

function squareCoords(square: Square): [number, number] {
  return [square.charCodeAt(0) - 97, Number(square[1])];
}

function pieceValue(piece: Piece | null | undefined): number {
  return piece ? MATERIAL_VALUE[piece.type] : 0;
}

function kingSquare(position: Chess, side: Color): Square {
  const square = SQUARES.find((candidate) => {
    const piece = position.get(candidate);
    return piece?.type === 'k' && piece.color === side;
  });
  if (!square) throw new Error(`The ${side === 'w' ? 'white' : 'black'} king is missing from the defence-analysis position.`);
  return square;
}

function clonePosition(position: Chess): Chess {
  return new Chess(position.fen());
}

function applyLegalMove(position: Chess, move: Move): { position: Chess; move: Move } {
  const after = clonePosition(position);
  const applied = after.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  return { position: after, move: applied };
}

function moveFact(move: Move): TacticalMove {
  return { uci: uciForMove(move), san: move.san };
}

function makeEvidence(
  id: string,
  description: string,
  squares: Square[],
  values: Record<string, string | number | boolean | readonly string[] | readonly number[]>,
  kind: KnowledgeEvidence['kind'] = 'board-state',
): KnowledgeEvidence {
  return { id, kind, description, squares, values };
}

function lineForMove(
  move: Move,
  after: Chess,
  outcome?: TacticalLegalLine['outcome'],
): TacticalLegalLine {
  const replies = after.moves({ verbose: true });
  const fact = moveFact(move);
  return {
    candidateMoveLegal: true,
    forcingMove: fact,
    forcingStatus: after.isCheck() ? 'verified-check' : 'candidate-only',
    opponentRepliesGenerated: replies.length,
    opponentReplies: replies.slice(0, REPLY_DISPLAY_LIMIT).map(moveFact),
    repliesTruncated: replies.length > REPLY_DISPLAY_LIMIT,
    continuationSearch: after.isCheckmate() || after.isStalemate() ? 'all-immediate-replies' : 'not-performed',
    continuations: [],
    outcome: outcome ?? (after.isCheckmate()
      ? { kind: 'checkmate', deterministic: true, description: 'The legal move gives checkmate according to chess.js.' }
      : after.isStalemate()
        ? { kind: 'stalemate', deterministic: true, description: 'The legal move draws by stalemate according to chess.js.' }
        : after.isCheck()
          ? { kind: 'position-fact', deterministic: true, description: 'The legal move gives check; defensive quality is not evaluated.' }
          : { kind: 'unproven', deterministic: false, description: 'The legal resource is identified, but no engine-level or long-horizon outcome is claimed.' }),
  };
}

function createResource(args: {
  motif: DefenceResourceMotif;
  side: Color;
  label: string;
  state: DefenceResourceState;
  confidence: number;
  relevance: number;
  boardEvidence: KnowledgeEvidence[];
  possibleConsequence: string;
  move?: Move;
  after?: Chess;
  outcome?: TacticalLegalLine['outcome'];
}): DefenceResourceFinding {
  const conceptId = `defence.${args.motif}`;
  const evidence = [...args.boardEvidence];
  const fact = args.move ? moveFact(args.move) : undefined;
  if (fact) evidence.push(makeEvidence(
    `${conceptId}.move.${fact.uci}`,
    `Legally generated defensive candidate ${fact.san} (${fact.uci}).`,
    [args.move!.from, args.move!.to],
    { uci: fact.uci, san: fact.san, legal: true },
    'move-sequence',
  ));
  const line = args.move && args.after
    ? lineForMove(args.move, args.after, args.outcome)
    : {
        candidateMoveLegal: null,
        forcingMove: null,
        forcingStatus: 'not-applicable' as const,
        opponentRepliesGenerated: 0,
        opponentReplies: [],
        repliesTruncated: false,
        continuationSearch: 'not-applicable' as const,
        continuations: [],
        outcome: args.outcome ?? { kind: 'unproven' as const, deterministic: false, description: 'No candidate move line was required for this board/history resource.' },
      };
  return {
    ...assertKnowledgeFinding({
      conceptId,
      label: args.label,
      evidence,
      confidence: args.confidence,
      relevance: args.relevance,
      possibleImplications: [{ side: args.side, description: args.possibleConsequence }],
      provenance: BOARD_PROVENANCE,
    }),
    state: args.state,
    motif: args.motif,
    side: args.side,
    ...(fact ? { triggeringMove: fact } : {}),
    boardEvidence: args.boardEvidence,
    legalLine: line,
    possibleConsequence: args.possibleConsequence,
  };
}

function createThreat(args: {
  category: DefenceThreatCategory;
  state: DefenceThreatState;
  side: Color;
  description: string;
  evidence: KnowledgeEvidence[];
  targetSquares: Square[];
  severity: number;
  move?: Move;
}): DefenceThreat {
  const categoryId = args.category.slice(0, -1);
  const findingEvidence = [...args.evidence];
  const fact = args.move ? moveFact(args.move) : undefined;
  if (fact) findingEvidence.push(makeEvidence(
    `defence.threat.${args.category}.${fact.uci}`,
    `Threat move ${fact.san} (${fact.uci}) is generated on a position with that side to move.`,
    [args.move!.from, args.move!.to],
    { uci: fact.uci, san: fact.san, hypotheticalTurn: args.state === 'candidate' },
    'move-sequence',
  ));
  return {
    ...assertKnowledgeFinding({
      conceptId: `defence.threat.${categoryId}`,
      label: `${categoryId[0].toUpperCase()}${categoryId.slice(1)} threat`,
      evidence: findingEvidence,
      confidence: args.state === 'confirmed' ? 1 : 0.55,
      relevance: Math.min(1, Math.max(0.3, args.severity / 100)),
      possibleImplications: [{ side: args.side, description: args.description }],
      provenance: BOARD_PROVENANCE,
    }),
    category: args.category,
    state: args.state,
    side: args.side,
    ...(fact ? { move: fact } : {}),
    targetSquares: args.targetSquares,
    severity: args.severity,
  };
}

function legalMovesForSide(position: Chess, side: Color): { position: Chess; moves: Move[] } {
  if (position.turn() === side) return { position: clonePosition(position), moves: position.moves({ verbose: true }) };
  const fields = position.fen().split(' ');
  fields[1] = side;
  // Castling and en-passant are deliberately removed: this is only a
  // hypothetical candidate scan for static checks/captures, not a real turn.
  fields[2] = '-';
  fields[3] = '-';
  const hypothetical = new Chess(fields.join(' '));
  return { position: hypothetical, moves: hypothetical.moves({ verbose: true }) };
}

function analyzeThreats(position: Chess, defendingSide: Color): DefenceThreatAssessment {
  const enemy = opposite(defendingSide);
  const checks: DefenceThreat[] = [];
  const captures: DefenceThreat[] = [];
  const threats: DefenceThreat[] = [];
  const defenderKing = kingSquare(position, defendingSide);
  if (position.isCheck()) {
    const checkers = position.attackers(defenderKing, enemy);
    const legalEvasions = position.moves({ verbose: true }).length;
    checks.push(createThreat({
      category: 'checks', state: 'confirmed', side: enemy,
      description: `The defending king on ${defenderKing} is currently in check from ${checkers.join(', ') || 'an attacking piece'}; all legal evasions must be considered before other resources.`,
      evidence: [makeEvidence('defence.threat.current-check', 'chess.js confirms the side to move is in check.', [defenderKing, ...checkers], { checkers, legalEvasions, checkmate: position.isCheckmate() })],
      targetSquares: [defenderKing], severity: position.isCheckmate() ? 1000 : 100,
    }));
  } else {
    const hypothetical = legalMovesForSide(position, enemy);
    for (const move of hypothetical.moves) {
      const after = applyLegalMove(hypothetical.position, move).position;
      const victim = position.get(move.to);
      if (move.isCapture() && victim?.color === defendingSide) {
        captures.push(createThreat({
          category: 'captures', state: 'candidate', side: enemy,
          description: `If the opponent had the move, ${move.san} is a legal capture of the ${victim.type} on ${move.to}; it is not an immediate move while the defender is to move.`,
          evidence: [makeEvidence(
            `defence.threat.hypothetical-capture.${moveFact(move).uci}`,
            `A turn-switched chess.js legality check generated the capture of a friendly ${victim.type}.`,
            [move.from, move.to],
            { victim: victim.type, materialClass: MATERIAL_VALUE[victim.type], legalInHypotheticalTurn: true },
            'move-sequence',
          )],
          targetSquares: [move.to], severity: MATERIAL_VALUE[victim.type] * 10 + (after.isCheck() ? 5 : 0), move,
        }));
      }
      if (after.isCheck()) {
        const king = kingSquare(after, defendingSide);
        checks.push(createThreat({
          category: 'checks', state: 'candidate', side: enemy,
          description: `The hypothetical legal move ${move.san} would check the defending king if the opponent were to move now; it is not a current forcing threat.`,
          evidence: [makeEvidence(
            `defence.threat.hypothetical-check.${moveFact(move).uci}`,
            'A turn-switched legal move leaves the defender in check; this is a candidate scan, not the current move order.',
            [move.from, move.to, king],
            { check: true, checkmate: after.isCheckmate(), hypotheticalTurn: true },
            'move-sequence',
          )],
          targetSquares: [king], severity: after.isCheckmate() ? 200 : 80, move,
        }));
      }
      const newlyAttacked: Square[] = [];
      for (const target of SQUARES) {
        const piece = after.get(target);
        if (!piece || piece.color !== defendingSide || piece.type === 'p' || piece.type === 'k') continue;
        const beforeCount = position.attackers(target, enemy).length;
        const afterCount = after.attackers(target, enemy).length;
        if (afterCount > beforeCount && after.attackers(target, enemy).includes(move.to)) newlyAttacked.push(target);
      }
      if (newlyAttacked.length && !move.isCapture()) {
        threats.push(createThreat({
          category: 'threats', state: 'candidate', side: enemy,
          description: `The hypothetical legal move ${move.san} newly attacks the listed friendly high-value target(s); no forced material result is claimed.`,
          evidence: [makeEvidence(
            `defence.threat.hypothetical-pressure.${moveFact(move).uci}`,
            'A turn-switched legal move increases direct geometric pressure on one or more friendly pieces.',
            [move.from, move.to, ...newlyAttacked],
            { newlyAttackedTargets: newlyAttacked, hypotheticalTurn: true },
            'move-sequence',
          )],
          targetSquares: newlyAttacked, severity: Math.max(...newlyAttacked.map((square) => pieceValue(position.get(square)))) * 10, move,
        }));
      }
    }
  }
  const priorityCategory: DefenceThreatAssessment['priorityCategory'] = checks.length ? 'checks' : captures.length ? 'captures' : threats.length ? 'threats' : 'none';
  const priorityTier = priorityCategory === 'checks' ? checks : priorityCategory === 'captures' ? captures : priorityCategory === 'threats' ? threats : [];
  const sortedTier = priorityTier.slice().sort((a, b) => b.severity - a.severity);
  const mostDangerousVerifiedThreat = checks.find((threat) => threat.state === 'confirmed') ?? null;
  const mostDangerousCandidateThreat = sortedTier[0] ?? null;
  const priorityExplanation = mostDangerousVerifiedThreat
    ? 'Current check is verified and takes priority over captures and other threats.'
    : mostDangerousCandidateThreat
      ? `The ${priorityCategory} tier is surfaced first; its highest-severity item is only a candidate because it is hypothetical or geometric.`
      : 'No current verified check or supported capture/threat candidate was found.';
  return {
    order: ['checks', 'captures', 'threats'],
    checks: checks.slice().sort((a, b) => b.severity - a.severity).slice(0, THREAT_DISPLAY_LIMIT),
    captures: captures.slice().sort((a, b) => b.severity - a.severity).slice(0, THREAT_DISPLAY_LIMIT),
    threats: threats.slice().sort((a, b) => b.severity - a.severity).slice(0, THREAT_DISPLAY_LIMIT),
    priorityCategory,
    mostDangerousVerifiedThreat,
    mostDangerousCandidateThreat,
    priorityExplanation,
  };
}

function lineBetween(source: Square, target: Square): Square[] {
  const [sourceFile, sourceRank] = squareCoords(source);
  const [targetFile, targetRank] = squareCoords(target);
  const fileDiff = targetFile - sourceFile;
  const rankDiff = targetRank - sourceRank;
  const aligned = fileDiff === 0 || rankDiff === 0 || Math.abs(fileDiff) === Math.abs(rankDiff);
  if (!aligned) return [];
  const fileStep = Math.sign(fileDiff);
  const rankStep = Math.sign(rankDiff);
  if (fileStep === 0 && rankStep === 0) return [];
  const between: Square[] = [];
  let file = sourceFile + fileStep;
  let rank = sourceRank + rankStep;
  while (file !== targetFile || rank !== targetRank) {
    const square = squareAt(file, rank);
    if (!square) return [];
    between.push(square);
    file += fileStep;
    rank += rankStep;
  }
  return between;
}

function isSlider(piece: Piece | null | undefined): boolean {
  return piece?.type === 'b' || piece?.type === 'r' || piece?.type === 'q';
}

function isPassedPawn(position: Chess, square: Square, side: Color): boolean {
  const [file, rank] = squareCoords(square);
  for (let fileDelta = -1; fileDelta <= 1; fileDelta += 1) {
    const adjacentFile = file + fileDelta;
    if (adjacentFile < 0 || adjacentFile > 7) continue;
    for (let rankIndex = 1; rankIndex <= 8; rankIndex += 1) {
      const otherSquare = squareAt(adjacentFile, rankIndex);
      if (!otherSquare) continue;
      const piece = position.get(otherSquare);
      if (!piece || piece.color === side || piece.type !== 'p') continue;
      if (side === 'w' ? rankIndex > rank : rankIndex < rank) return false;
    }
  }
  return true;
}

function validateHistory(position: Chess, record: GameRecord): void {
  if (!Number.isInteger(record.cursorPly) || record.cursorPly < 0 || record.cursorPly > record.moveHistory.length) {
    throw new RangeError('Defence analysis received a GameRecord with an invalid cursor ply.');
  }
  const replay = new Chess(record.initialPosition.fen);
  const expectedKeys = [positionKey(replay)];
  for (const entry of record.moveHistory.slice(0, record.cursorPly)) {
    const move = replay.move({ from: entry.from, to: entry.to, ...(entry.promotion ? { promotion: entry.promotion } : {}) });
    if (move.san !== entry.san || uciForMove(move) !== entry.uci) throw new Error(`Defence analysis rejected mismatched history at ply ${entry.ply}.`);
    expectedKeys.push(positionKey(replay));
  }
  const recordedKeys = record.repetitionKeys.slice(0, record.cursorPly + 1);
  if (recordedKeys.length !== expectedKeys.length || recordedKeys.some((key, index) => key !== expectedKeys[index])) {
    throw new Error('Defence analysis rejected inconsistent repetition history.');
  }
  const recorded = new Chess(record.currentFen);
  if (positionKey(replay) !== positionKey(recorded) || positionKey(replay) !== positionKey(position)) {
    throw new Error('Defence analysis rejected history that does not replay to the analyzed position.');
  }
}

function threatenedTargets(position: Chess, side: Color): Map<Square, Square[]> {
  const enemy = opposite(side);
  const result = new Map<Square, Square[]>();
  for (const square of SQUARES) {
    const piece = position.get(square);
    if (!piece || piece.color !== side || pieceValue(piece) < 3) continue;
    const attackers = position.attackers(square, enemy);
    if (attackers.length) result.set(square, attackers);
  }
  return result;
}

function resourceEvidence(motif: DefenceResourceMotif, move: Move, description: string, squares: Square[], values: Record<string, string | number | boolean | readonly string[] | readonly number[]>): KnowledgeEvidence[] {
  return [makeEvidence(`defence.${motif}.${moveFact(move).uci}`, description, squares, values, 'move-sequence')];
}

function classifyResources(position: Chess, side: Color, moves: Move[]): DefenceResourceFinding[] {
  const enemy = opposite(side);
  const findings: DefenceResourceFinding[] = [];
  const threatened = threatenedTargets(position, side);
  const king = kingSquare(position, side);
  const checkers = position.isCheck() ? position.attackers(king, enemy) : [];
  const evadingCheck = position.isCheck();
  const checkInterpositionSquares = checkers.flatMap((checker) => isSlider(position.get(checker)) ? lineBetween(checker, king) : []);
  const ownShelter = new Set<Square>();
  const [kingFile, kingRank] = squareCoords(king);
  const forward = side === 'w' ? 1 : -1;
  for (let fileDelta = -1; fileDelta <= 1; fileDelta += 1) {
    const square = squareAt(kingFile + fileDelta, kingRank + forward);
    if (square) ownShelter.add(square);
  }

  const addMoveResource = (args: {
    motif: DefenceResourceMotif;
    move: Move;
    after: Chess;
    state: DefenceResourceState;
    label: string;
    confidence: number;
    relevance: number;
    description: string;
    consequence: string;
    squares: Square[];
    values: Record<string, string | number | boolean | readonly string[] | readonly number[]>;
    outcome?: TacticalLegalLine['outcome'];
  }) => {
    findings.push(createResource({
      motif: args.motif,
      side,
      label: args.label,
      state: args.state,
      confidence: args.confidence,
      relevance: args.relevance,
      boardEvidence: resourceEvidence(args.motif, args.move, args.description, args.squares, args.values),
      possibleConsequence: args.consequence,
      move: args.move,
      after: args.after,
      ...(args.outcome ? { outcome: args.outcome } : {}),
    }));
  };

  for (const move of moves) {
    const { position: after, move: applied } = applyLegalMove(position, move);
    const fact = moveFact(applied);
    const resolvesCheck = evadingCheck && !after.isCheck();
    const stillAttackedTargets: Square[] = [];
    for (const [target, attackers] of threatened) {
      const originalTarget = position.get(target);
      const afterTarget = after.get(target);
      if (!originalTarget || originalTarget.color !== side || !afterTarget || afterTarget.color !== side || afterTarget.type !== originalTarget.type) continue;
      const beforeAttackers = position.attackers(target, enemy);
      const afterAttackers = after.attackers(target, enemy);
      if (afterAttackers.length < beforeAttackers.length) {
        stillAttackedTargets.push(target);
        addMoveResource({
          motif: 'cut-attacker-supply', move: applied, after, state: 'candidate', label: 'Cut-attacker-supply candidate', confidence: 0.61, relevance: 0.65,
          description: `Legal move ${fact.san} reduces geometric enemy attackers on threatened target ${target} from ${beforeAttackers.length} to ${afterAttackers.length}.`,
          consequence: 'The move reduces the visible supply of attackers to a threatened piece; the position is not evaluated as safe or best.',
          squares: [target, ...attackers, ...afterAttackers, applied.from, applied.to],
          values: { target, beforeAttackers, afterAttackers, legal: true },
        });
      }
      const beforeDefenders = position.attackers(target, side).length;
      const afterDefenders = after.attackers(target, side).length;
      if (afterDefenders > beforeDefenders) {
        addMoveResource({
          motif: 'reinforce-target', move: applied, after, state: 'candidate', label: 'Reinforce-target candidate', confidence: 0.58, relevance: 0.61,
          description: `Legal move ${fact.san} increases friendly geometric defenders of threatened target ${target} from ${beforeDefenders} to ${afterDefenders}.`,
          consequence: 'The target receives additional geometric support; pinned defenders and tactical exchanges are not fully evaluated.',
          squares: [target, applied.from, applied.to],
          values: { target, beforeDefenders, afterDefenders, legal: true },
        });
      }
      if (applied.isCapture() && attackers.includes(applied.to)) {
        addMoveResource({
          motif: 'remove-attacker', move: applied, after, state: resolvesCheck ? 'confirmed' : 'candidate', label: 'Remove-attacker resource', confidence: resolvesCheck ? 0.97 : 0.64, relevance: 0.68,
          description: `Legal capture ${fact.san} removes an enemy attacker of the threatened ${position.get(target)?.type ?? 'piece'} on ${target}.`,
          consequence: resolvesCheck ? 'The legal capture removes a checking attacker and resolves the current check.' : 'The legal capture removes one geometric attacker from a threatened target; further safety is not proved.',
          squares: [target, applied.from, applied.to],
          values: { target, removedAttacker: applied.to, resolvesCheck, legal: true },
          ...(resolvesCheck ? { outcome: { kind: 'position-fact', deterministic: true, description: 'The legal move removes the checker and leaves the king no longer in check.' } } : {}),
        });
      }
    }

    if (evadingCheck && resolvesCheck) {
      if (applied.piece === 'k') {
        addMoveResource({
          motif: 'king-reposition', move: applied, after, state: 'confirmed', label: 'Legal king-evasion resource', confidence: 0.98, relevance: 0.78,
          description: `Legal king move ${fact.san} leaves the king out of check.`,
          consequence: 'This is a legal king evasion; no ranking against other defenses is made.',
          squares: [king, applied.to, ...checkers], values: { evadesCheck: true, legal: true },
          outcome: { kind: 'position-fact', deterministic: true, description: 'The king is no longer in check after the legal move.' },
        });
      }
      if (checkInterpositionSquares.includes(applied.to)) {
        addMoveResource({
          motif: 'block-interpose', move: applied, after, state: 'confirmed', label: 'Legal block/interposition resource', confidence: 0.98, relevance: 0.79,
          description: `Legal move ${fact.san} occupies a square between a sliding checker and the king, resolving check.`,
          consequence: 'A legal interposition answers the current sliding check; follow-up safety is not ranked.',
          squares: [king, applied.to, ...checkers], values: { resolvesCheck: true, slidingCheckers: checkers },
          outcome: { kind: 'position-fact', deterministic: true, description: 'The legal move interposes and leaves the king out of check.' },
        });
      }
      if (applied.isCapture() && !findings.some((finding) => finding.motif === 'remove-attacker' && finding.triggeringMove?.uci === fact.uci)) {
        addMoveResource({
          motif: 'remove-attacker', move: applied, after, state: 'confirmed', label: 'Legal capture-evasion resource', confidence: 0.96, relevance: 0.76,
          description: `Legal capture ${fact.san} resolves the current check.`,
          consequence: 'The legal capture removes the checker and resolves the current check; it is not ranked against other defenses.',
          squares: [king, applied.from, applied.to, ...checkers], values: { resolvesCheck: true, legal: true },
          outcome: { kind: 'position-fact', deterministic: true, description: 'The legal capture leaves the king out of check.' },
        });
      }
    }

    if (applied.piece === 'k' && !applied.flags.includes('k') && !applied.flags.includes('q')) {
      addMoveResource({
        motif: 'king-reposition', move: applied, after, state: 'candidate', label: 'King-reposition candidate', confidence: 0.53, relevance: 0.5,
        description: `Legal king move ${fact.san} changes the king square.`,
        consequence: 'The king can legally reposition; safety of the resulting plan is not evaluated.',
        squares: [applied.from, applied.to], values: { legal: true },
      });
    }
    if (applied.flags.includes('k') || applied.flags.includes('q')) {
      addMoveResource({
        motif: 'castling', move: applied, after, state: 'confirmed', label: 'Legal castling resource', confidence: 1, relevance: 0.71,
        description: `chess.js generated and applied legal ${applied.flags.includes('k') ? 'kingside' : 'queenside'} castling.`,
        consequence: 'Castling is legal in this position; whether it improves safety is not evaluated.',
        squares: [applied.from, applied.to], values: { wing: applied.flags.includes('k') ? 'kingside' : 'queenside', legal: true },
        outcome: { kind: 'position-fact', deterministic: true, description: 'The castling move is legal under chess.js rules.' },
      });
    }
    if (applied.piece === 'p' && !applied.isCapture() && ownShelter.has(applied.from)) {
      addMoveResource({
        motif: 'luft', move: applied, after, state: 'candidate', label: 'Luft-creation candidate', confidence: 0.48, relevance: 0.45,
        description: `Legal pawn move ${fact.san} vacates a king-adjacent shield square ${applied.from}.`,
        consequence: 'The move may create a flight square for the king; that square is not asserted to be safe.',
        squares: [king, applied.from, applied.to], values: { vacatedKingShieldSquare: applied.from, legal: true },
      });
    }

    if (resolvesCheck && !applied.isCapture() && applied.piece !== 'k') {
      const blocking = checkInterpositionSquares.includes(applied.to);
      if (!blocking) {
        addMoveResource({
          motif: 'block-interpose', move: applied, after, state: 'confirmed', label: 'Legal check-evasion resource', confidence: 0.96, relevance: 0.74,
          description: `Legal move ${fact.san} resolves the current check without moving the king or capturing a checker.`,
          consequence: 'The move is a legal check evasion; its long-term defensive value is not ranked.',
          squares: [king, applied.from, applied.to, ...checkers], values: { resolvesCheck: true, legal: true },
          outcome: { kind: 'position-fact', deterministic: true, description: 'The legal move leaves the king out of check.' },
        });
      }
    }

    if (after.isCheck()) {
      addMoveResource({
        motif: 'counter-check', move: applied, after, state: 'confirmed', label: 'Verified counter-check resource', confidence: 0.98, relevance: 0.79,
        description: `Legal move ${fact.san} leaves the opposing king in check.`,
        consequence: 'The move gives a verified check and requires a legal response; no win or best defense is inferred.',
        squares: [applied.from, applied.to, kingSquare(after, enemy)], values: { check: true, legal: true },
        outcome: { kind: after.isCheckmate() ? 'checkmate' : 'position-fact', deterministic: true, description: after.isCheckmate() ? 'The counter-check is checkmate.' : 'The legal move checks the opposing king.' },
      });
    }

    const attackedEnemyMajors = SQUARES.filter((target) => {
      const piece = after.get(target);
      if (!piece || piece.color !== enemy || (piece.type !== 'q' && piece.type !== 'r')) return false;
      return after.attackers(target, side).includes(applied.to) && !position.attackers(target, side).length;
    });
    if (attackedEnemyMajors.length && !after.isCheck()) {
      addMoveResource({
        motif: 'counterattack', move: applied, after, state: 'candidate', label: 'Counterattack candidate', confidence: 0.52, relevance: 0.6,
        description: `Legal move ${fact.san} creates geometric pressure on an enemy queen/rook at ${attackedEnemyMajors.join(', ')}.`,
        consequence: 'The move creates a candidate counterattack against high-value pieces; no tactical gain or opponent response is assumed.',
        squares: [applied.from, applied.to, ...attackedEnemyMajors], values: { newlyAttackedTargets: attackedEnemyMajors },
      });
    }

    const queenRecaptures = applied.piece === 'q' && applied.isCapture() && applied.captured === 'q'
      ? after.moves({ verbose: true }).filter((reply) => reply.isCapture() && reply.to === applied.to && after.get(applied.to)?.type === 'q')
      : [];
    if (queenRecaptures.length && (evadingCheck || threatened.size > 0)) {
      addMoveResource({
        motif: 'queen-trade', move: applied, after, state: 'candidate', label: 'Queen-trade candidate', confidence: 0.62, relevance: 0.65,
        description: `Legal move ${fact.san} captures the opposing queen, and the opponent has at least one legal recapture of the capturing queen.`,
        consequence: 'A queen exchange is legally available if the opponent chooses the recapture; whether offering it helps the defense is not evaluated.',
        squares: [applied.from, applied.to], values: { capturedQueen: true, legal: true, legalRecaptures: queenRecaptures.map((reply) => moveFact(reply).uci), bothQueensLeaveOnRecapture: true },
      });
    }

    if (applied.isCapture() && (evadingCheck || threatened.size > 0)) {
      const afterEnemyReplies = after.moves({ verbose: true });
      const recapture = afterEnemyReplies.find((reply) => reply.isCapture() && reply.to === applied.to && after.get(applied.to)?.color === side);
      if (recapture) {
        const afterRecapture = applyLegalMove(after, recapture).position;
        const ourRecaptures = afterRecapture.moves({ verbose: true }).filter((reply) => reply.isCapture() && reply.to === recapture.to);
        if (ourRecaptures.length) {
          const returnLine = [applied.from, applied.to, recapture.to];
          addMoveResource({
            motif: 'return-material', move: applied, after, state: 'candidate', label: 'Return-material exchange candidate', confidence: 0.44, relevance: 0.43,
            description: `A legal capture ${fact.san} has a legal recapture ${moveFact(recapture).san}, followed by at least one legal further recapture.`,
            consequence: 'A concrete exchange chain may return material or simplify; no line is preferred and the complete exchange is not evaluated.',
            squares: returnLine, values: { opponentRecapture: moveFact(recapture).uci, defenderRecaptures: ourRecaptures.length },
          });
        }
      }
    }

    for (const [target, attackers] of threatened) {
      const piece = position.get(target);
      const remainingTarget = after.get(target);
      if (!piece || piece.color !== side || !remainingTarget || remainingTarget.color !== side || remainingTarget.type !== piece.type) continue;
      const beforePressure = position.attackers(target, enemy).length;
      const afterPressure = after.attackers(target, enemy).length;
      if (afterPressure >= beforePressure) continue;
      // A defensive sacrifice is only surfaced when a legal move reduces
      // pressure on a threatened piece while leaving the moved unit capturable.
      if (applied.piece === 'k' || pieceValue(after.get(applied.to)) < 3) continue;
      const enemyCanCaptureMovedPiece = after.moves({ verbose: true }).some((reply) => reply.isCapture() && reply.to === applied.to);
      const createsCounterPressure = after.isCheck() || attackedEnemyMajors.length > 0;
      if (!enemyCanCaptureMovedPiece || !createsCounterPressure) continue;
      addMoveResource({
        motif: 'defensive-sacrifice', move: applied, after, state: 'candidate', label: 'Defensive-sacrifice candidate', confidence: 0.42, relevance: 0.48,
        description: `Legal move ${fact.san} leaves a valuable piece capturable while reducing pressure on a threatened target and creating counter-pressure.`,
        consequence: 'This may be a defensive investment, but the capture sequence and compensation are not proved.',
        squares: [target, applied.from, applied.to, ...attackers], values: { threatenedTarget: target, pressureBefore: beforePressure, pressureAfter: afterPressure, capturable: true, counterCheck: after.isCheck() },
      });
    }

    for (const passedPawn of SQUARES) {
      const pawn = position.get(passedPawn);
      if (!pawn || pawn.type !== 'p' || pawn.color !== enemy || !isPassedPawn(position, passedPawn, enemy)) continue;
      const rank = Number(passedPawn[1]) + (enemy === 'w' ? 1 : -1);
      const blockSquare = squareAt(passedPawn.charCodeAt(0) - 97, rank);
      if (blockSquare !== applied.to) continue;
      addMoveResource({
        motif: 'blockade', move: applied, after, state: 'candidate', label: 'Passed-pawn blockade candidate', confidence: 0.55, relevance: 0.58,
        description: `Legal move ${fact.san} occupies the square directly in front of the opposing passed pawn on ${passedPawn}.`,
        consequence: 'The pawn advance is geometrically blocked for now; the blockading piece may be attacked or bypassed.',
        squares: [passedPawn, blockSquare], values: { passedPawn, blockedSquare: blockSquare, legal: true },
      });
    }
  }
  return findings;
}

function analyzeRepetitionResource(position: Chess, record?: GameRecord): DefenceResourceFinding[] {
  if (!record) return [];
  validateHistory(position, record);
  const state = deriveDrawState(position, record, record.cursorPly);
  if (state.canClaimThreefoldNow) {
    return [createResource({
      motif: 'repetition', side: position.turn(), label: 'Verified current threefold-claim resource', state: 'confirmed', confidence: 1, relevance: 0.9,
      boardEvidence: [makeEvidence(
        'defence.repetition.current-threefold',
        'The replay-validated history contains at least three occurrences of the current repetition identity.',
        [],
        { repetitionCount: state.repetitionCount, claimAvailable: true },
        'move-sequence',
      )],
      possibleConsequence: 'A threefold-repetition draw claim is available under the existing domain draw rules; the service does not submit the claim automatically.',
      outcome: { kind: 'position-fact', deterministic: true, description: 'The domain draw-state derivation confirms a current threefold claim is available.' },
    })];
  }
  const intended = state.intendedClaims.find((claim) => claim.reason === 'threefold-repetition');
  if (!intended?.intendedUci) return [];
  const move = position.moves({ verbose: true }).find((candidate) => uciForMove(candidate) === intended.intendedUci);
  if (!move) return [];
  const after = applyLegalMove(position, move).position;
  return [createResource({
    motif: 'repetition', side: position.turn(), label: 'Verified intended threefold-claim resource', state: 'confirmed', confidence: 0.98, relevance: 0.88,
    boardEvidence: [makeEvidence(
      `defence.repetition.intended.${intended.intendedUci}`,
      `Legal move ${intended.intendedSan ?? move.san} would create a third occurrence according to the replay-validated domain history.`,
      [move.from, move.to],
      { repetitionCountBeforeMove: state.repetitionCount, intendedUci: intended.intendedUci, claimAvailableAfterIntendedMove: true },
      'move-sequence',
    )],
    possibleConsequence: 'The move can be declared for a threefold-repetition draw under domain rules; no claim is made that a draw is desirable.',
    move,
    after,
    outcome: { kind: 'position-fact', deterministic: true, description: 'The domain draw-state derivation validates an intended-move threefold claim.' },
  })];
}

function analyzeStalemateResources(position: Chess, tactical: TacticalAnalysis): DefenceResourceFinding[] {
  return tactical.findings
    .filter((finding) => finding.motif === 'stalemate-resource')
    .map((finding) => {
      const move = position.moves({ verbose: true }).find((candidate) => uciForMove(candidate) === finding.triggeringMove?.uci);
      if (!move) return null;
      const after = applyLegalMove(position, move).position;
      return createResource({
        motif: 'stalemate-resource', side: position.turn(), label: 'Verified stalemate defensive resource', state: 'confirmed', confidence: 1, relevance: 1,
        boardEvidence: finding.boardEvidence,
        possibleConsequence: 'The legal move immediately draws by stalemate; this may save a lost position, but the service does not decide whether a draw is preferable.',
        move, after,
        outcome: { kind: 'stalemate', deterministic: true, description: 'chess.js confirms the legal move leaves the opponent stalemated.' },
      });
    })
    .filter((finding): finding is DefenceResourceFinding => finding !== null);
}

function deduplicateResources(resources: DefenceResourceFinding[]): DefenceResourceFinding[] {
  const seen = new Set<string>();
  return resources.filter((finding) => {
    const key = `${finding.motif}|${finding.triggeringMove?.uci ?? finding.boardEvidence.map((evidence) => evidence.id).join(',')}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Analyze defensive resources in Checks → Captures → Threats order without ranking moves as best. */
export function analyzeDefence(position: Chess, record?: GameRecord, tacticalAnalysis?: TacticalAnalysis): DefenceAnalysis {
  const source = clonePosition(position);
  const tactical = tacticalAnalysis ?? analyzeTactics(source);
  if (positionKey(new Chess(tactical.positionFen)) !== positionKey(source)) throw new Error('Defence analysis received tactical evidence for a different position.');
  const side = source.turn();
  if (record) validateHistory(source, record);
  const threats = analyzeThreats(source, side);
  const legalMoves = source.moves({ verbose: true });
  const resources = [
    ...classifyResources(source, side, legalMoves),
    ...analyzeRepetitionResource(source, record),
    ...analyzeStalemateResources(source, tactical),
  ];
  return {
    version: 1,
    positionFen: source.fen(),
    defendingSide: side,
    threatAssessment: threats,
    resources: deduplicateResources(resources),
    deferredResources: DEFERRED_RESOURCES.map((entry) => ({ ...entry })),
    limitations: [
      'Threat categories are generated in Checks → Captures → Threats order; current check is verified, while turn-switched capture/check/pressure scans are candidates only.',
      'Legal resources are identified, not ranked. No resource is labeled best and no engine evaluation is used.',
      'Repetition is verified only when a supplied GameRecord replays legally to the analyzed position; fortress proof is deferred.',
      'Return-material, blockade and defensive-sacrifice findings are candidate exchange/geometry patterns with shallow legal validation, not full forcing-line proofs.',
      'Static attacks use chess.js attack geometry; pinned-piece consequences and long tactical sequences may require deeper validation.',
    ],
  };
}
