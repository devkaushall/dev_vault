import { describe, expect, it } from 'vitest';
import { analyzePawnStructures, type PawnStructureAnalysis, type PawnStructureType } from './pawnStructures';

function structure(result: PawnStructureAnalysis, type: PawnStructureType, side?: 'w' | 'b') {
  return result.findings.find((finding) => finding.structure === type && (side ? finding.side === side : true));
}

describe('board-derived pawn-structure recognition', () => {
  it('detects isolated, doubled, IQP and passed pawns from pawn squares, with edge negatives', () => {
    const isolated = analyzePawnStructures('4k3/8/8/8/3P4/8/8/4K3 w - - 0 1');
    expect(structure(isolated, 'isolated-pawn', 'w')?.evidence[0].squares).toContain('d4');
    expect(structure(isolated, 'isolated-queens-pawn', 'w')?.label).toContain('IQP');
    expect(structure(isolated, 'passed-pawn', 'w')?.evidence[0].squares).toContain('d4');

    const doubled = analyzePawnStructures('4k3/8/8/8/3P4/3P4/8/4K3 w - - 0 1');
    expect(structure(doubled, 'doubled-pawn', 'w')?.evidence[0].values?.pawns).toEqual(expect.arrayContaining(['d4', 'd3']));
    expect(structure(doubled, 'isolated-queens-pawn', 'w')).toBeUndefined();

    const defended = analyzePawnStructures('4k3/8/8/8/2PPP3/8/8/4K3 w - - 0 1');
    expect(structure(defended, 'isolated-pawn', 'w')).toBeUndefined();
    expect(structure(defended, 'isolated-queens-pawn', 'w')).toBeUndefined();
    expect(structure(defended, 'doubled-pawn', 'w')).toBeUndefined();

    const blockedByEnemyPawn = analyzePawnStructures('4k3/8/2p5/3P4/8/8/8/4K3 w - - 0 1');
    expect(structure(blockedByEnemyPawn, 'passed-pawn', 'w')).toBeUndefined();
  });

  it('requires both relative pawn placement and pawn-control evidence for backward and hanging candidates', () => {
    const backward = analyzePawnStructures('4k3/8/8/2p1p3/2P1P3/3P4/8/4K3 w - - 0 1');
    expect(structure(backward, 'backward-pawn-candidate', 'w')).toMatchObject({
      label: expect.stringContaining('on d3'),
      confidence: 0.84,
      evidence: [expect.objectContaining({ values: expect.objectContaining({ advanceSquare: 'd4', enemyPawnAttacksAdvance: true, friendlyPawnSupportsAdvance: false }) })],
    });
    const noEnemyPawnControl = analyzePawnStructures('4k3/8/8/8/2P1P3/3P4/8/4K3 w - - 0 1');
    expect(structure(noEnemyPawnControl, 'backward-pawn-candidate')).toBeUndefined();

    const hanging = analyzePawnStructures('4k3/8/8/8/2PP4/8/8/4K3 w - - 0 1');
    expect(structure(hanging, 'hanging-pawns-candidate', 'w')?.evidence[0].values?.pawns).toEqual(['c4', 'd4']);
    const supported = analyzePawnStructures('4k3/8/8/8/2PP4/4P3/8/4K3 w - - 0 1');
    expect(structure(supported, 'hanging-pawns-candidate', 'w')).toBeUndefined();
  });

  it('finds diagonal pawn chains and only labels the French chain with the opposing d/e pawns', () => {
    const french = analyzePawnStructures('4k3/8/4p3/3pP3/3P4/8/8/4K3 w - - 0 1');
    expect(structure(french, 'pawn-chain', 'w')?.evidence[0].values?.chainSquares).toEqual(expect.arrayContaining(['d4', 'e5']));
    expect(structure(french, 'french-chain', 'w')?.evidence[0].values).toMatchObject({ ownBase: 'd4', ownHead: 'e5', enemyBase: 'd5', enemyHead: 'e6' });

    const incomplete = analyzePawnStructures('4k3/8/8/4P3/8/8/8/4K3 w - - 0 1');
    expect(structure(incomplete, 'pawn-chain')).toBeUndefined();
    expect(structure(incomplete, 'french-chain')).toBeUndefined();
  });

  it('recognizes the Carlsbad-like minority skeleton from a/b/c and central d/e pawns, not opening names', () => {
    const carlsbad = analyzePawnStructures('4k3/pp3ppp/2p1p3/3p4/3P4/4P3/PP3PPP/4K3 w - - 0 1');
    expect(structure(carlsbad, 'carlsbad-like', 'w')).toMatchObject({
      label: expect.stringContaining('White minority vs Black majority'),
      evidence: [expect.objectContaining({ values: expect.objectContaining({ whiteQueensidePawns: ['a2', 'b2'], blackQueensidePawns: ['a7', 'b7', 'c6'] }) })],
    });
    expect(structure(carlsbad, 'majority-minority', 'b')?.label).toContain('queenside pawn majority');

    const balanced = analyzePawnStructures('4k3/pp3ppp/8/8/8/8/PP3PPP/4K3 w - - 0 1');
    expect(structure(balanced, 'carlsbad-like')).toBeUndefined();
    expect(structure(balanced, 'majority-minority')).toBeUndefined();
  });

  it('detects Maroczy and Hedgehog-like shells only when their pawn conditions are present', () => {
    const maroczy = analyzePawnStructures('4k3/pp3ppp/3p4/8/2P1P3/8/PP3PPP/4K3 w - - 0 1');
    expect(structure(maroczy, 'maroczy-bind-like', 'w')?.evidence[0].values).toMatchObject({ cPawn: 'c4', ePawn: 'e4', controlledCentralSquare: 'd5', opponentCPawns: 0 });
    const brokenBind = analyzePawnStructures('4k3/pp3ppp/2pp4/8/2P1P3/8/PP3PPP/4K3 w - - 0 1');
    expect(structure(brokenBind, 'maroczy-bind-like')).toBeUndefined();

    const hedgehog = analyzePawnStructures('4k3/5ppp/pp1pp3/8/2PPP3/8/PP3PPP/4K3 w - - 0 1');
    expect(structure(hedgehog, 'hedgehog-like', 'b')?.label).toContain('compact Hedgehog-like');
    const cPawnPresent = analyzePawnStructures('4k3/5ppp/ppp1p3/8/2PPP3/8/PP3PPP/4K3 w - - 0 1');
    expect(structure(cPawnPresent, 'hedgehog-like')).toBeUndefined();
  });

  it('detects Benoni and Dutch Stonewall structures from exact pawn squares, with negative fixtures', () => {
    const benoni = analyzePawnStructures('rnbqkb1r/pp1p1ppp/4pn2/2pP4/2P5/8/PP2PPPP/RNBQKBNR w KQkq - 0 4');
    expect(structure(benoni, 'benoni-like', 'b')?.evidence[0].squares).toEqual(['c4', 'd5', 'c5', 'e6']);
    const noBenoni = analyzePawnStructures('rnbqkb1r/pp1p1ppp/5n2/2pP4/2P5/8/PP2PPPP/RNBQKBNR w KQkq - 0 4');
    expect(structure(noBenoni, 'benoni-like')).toBeUndefined();

    const stonewall = analyzePawnStructures('4k3/8/2p1p3/3p1p2/8/8/8/K7 w - - 0 1');
    expect(structure(stonewall, 'dutch-stonewall-like', 'b')?.evidence[0].squares).toEqual(['f5', 'e6', 'd5', 'c6']);
    const incompleteStonewall = analyzePawnStructures('4k3/8/4p3/3p1p2/8/8/8/K7 w - - 0 1');
    expect(structure(incompleteStonewall, 'dutch-stonewall-like')).toBeUndefined();
  });

  it('counts wing majorities only when both sides have a meaningful pawn group', () => {
    const majority = analyzePawnStructures('4k3/5pp1/8/8/8/8/5PPP/4K3 w - - 0 1');
    expect(structure(majority, 'majority-minority', 'w')?.label).toContain('kingside pawn majority (3 vs 2)');
    const onePawn = analyzePawnStructures('4k3/6p1/8/8/8/8/5PPP/4K3 w - - 0 1');
    expect(structure(onePawn, 'majority-minority')).toBeUndefined();
  });

  it('attaches provenance, evidence, confidence, relevance, and a conditional plan to every result', () => {
    const result = analyzePawnStructures('4k3/8/8/3P4/8/8/8/4K3 w - - 0 1');
    expect(result.findings.length).toBeGreaterThan(0);
    for (const finding of result.findings) {
      expect(finding.conceptId).toMatch(/^pawn-structure\./);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
      expect(finding.relevance).toBeGreaterThanOrEqual(0);
      expect(finding.relevance).toBeLessThanOrEqual(1);
      expect(finding.possiblePlan.length).toBeGreaterThan(0);
      expect(finding.provenance).toContainEqual(expect.objectContaining({ kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md' }));
    }
    expect(result.deferred.some((item) => item.structure === 'maroczy-bind-like')).toBe(true);
    expect(result.limitations.join(' ')).toContain('no ECO, opening name');
  });
});
