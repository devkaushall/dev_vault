import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { parseOpeningTsv } from './openings';
import { analyzeReviewRecord } from './reviewAnalysis';
import type { GameRecord } from '../domain/chess/types';

function gameFrom(fen: string, moves: string[], id: string): GameRecord {
  let record = createGame({ id, initialFen: fen, now: '2026-10-05T00:00:00.000Z' });
  moves.forEach((uci, index) => {
    record = applyMove(record, uci, { committedAt: `2026-10-05T00:00:${String(index + 1).padStart(2, '0')}.000Z` }).record;
  });
  return record;
}

describe('Review intelligence orchestration', () => {
  it('integrates opening, pawn-break, development, moment, and explanation evidence without changing canonical history', async () => {
    const record = gameFrom(new Chess().fen(), ['e2e4', 'e7e5', 'g1f3'], 'review-integration');
    const before = structuredClone(record);
    const catalog = parseOpeningTsv('eco\tname\tpgn\nC20\tKing\'s Pawn Game\t1. e4 e5');
    const report = await analyzeReviewRecord(record, { catalog, maxAnalyzedPositions: 8 });
    expect(report.classification.moves.find((move) => move.ply === 1)?.categories.map((item) => item.category)).toContain('pawn-break');
    expect(report.classification.moves.find((move) => move.ply === 3)?.categories.map((item) => item.category)).toContain('normal-developing-move');
    expect(report.keyMoments.moments.some((moment) => moment.category === 'opening-transition')).toBe(true);
    expect(report.explanations.explanations.every((item) => item.evidenceIds.every((id) => report.evidence.some((source) => source.evidenceId === id)))).toBe(true);
    expect(record).toEqual(before);
  });

  it('carries a replay-verified capture through classification, key moments, and its explanation with full provenance', async () => {
    const record = gameFrom('4q2k/8/8/8/8/8/8/4R2K w - - 0 1', ['e1e8'], 'review-capture-integration');
    const report = await analyzeReviewRecord(record, { maxAnalyzedPositions: 4 });
    const capture = report.classification.moves[0].categories.find((item) => item.category === 'capture');
    expect(capture).toMatchObject({ status: 'confirmed', confidence: 'high' });
    const source = report.evidence.find((item) => item.evidenceId === capture?.evidenceId);
    expect(source?.position).toMatchObject({ uci: 'e1e8', san: 'Rxe8+' });
    expect(source?.references.some((reference) => reference.kind === 'move' && reference.uciMoves?.[0] === 'e1e8')).toBe(true);
    const moment = report.keyMoments.moments.find((item) => item.category === 'capture');
    expect(moment).toMatchObject({ status: 'confirmed', ply: 1, uci: 'e1e8', san: 'Rxe8+' });
    expect(moment?.evidenceIds).toContain(capture?.evidenceId);
    const explanation = report.explanations.explanations.find((item) => item.id === `ex_${moment?.id}`);
    expect(explanation).toMatchObject({ status: 'confirmed', concept: 'capture' });
    expect(explanation?.whatHappened).toMatch(/captures a queen/i);
    expect(explanation?.evidenceIds).toContain(capture?.evidenceId);
    expect(report.evidence.map((item) => item.evidenceId)).toEqual([...new Set(report.evidence.map((item) => item.evidenceId))]);
  });

  it('integrates a candidate strategic cue with its explanation and linked key moment', async () => {
    const record = gameFrom(new Chess().fen(), ['a2a3'], 'review-strategy-integration');
    const report = await analyzeReviewRecord(record, { maxAnalyzedPositions: 4 });
    const category = report.classification.moves[0].categories.find((item) => item.category === 'strategic-move');
    expect(category?.status).toBe('candidate');
    const moment = report.keyMoments.moments.find((item) => item.category === 'strategic-cue');
    expect(moment?.status).toBe('candidate');
    expect(moment?.evidenceIds).toContain(category?.evidenceId);
    expect(report.explanations.explanations.some((item) => item.evidenceIds.includes(moment!.id) && item.status === 'candidate')).toBe(true);
  });

  it('surfaces only a candidate tactical vulnerability when a replayed move allows a verified legal resource', async () => {
    const record = gameFrom('k3r3/8/8/8/8/8/4R3/4Q2K w - - 0 1', ['e2f2'], 'review-tactical-candidate');
    const report = await analyzeReviewRecord(record, { maxAnalyzedPositions: 4 });
    const category = report.classification.moves[0].categories.find((item) => item.category === 'candidate-tactical-mistake');
    expect(category?.status).toBe('candidate');
    expect(report.keyMoments.moments.find((moment) => moment.category === 'opportunity')?.status).toBe('candidate');
    expect(report.evidence.every((item) => item.engine === undefined)).toBe(true);
    expect(report.classification.moves.flatMap((move) => move.categories).every((item) => !['best-move', 'blunder', 'brilliant', 'inaccurate'].includes(item.category))).toBe(true);
    expect(report.limitations.join(' ')).toMatch(/no best move, blunder/i);
  });
});
