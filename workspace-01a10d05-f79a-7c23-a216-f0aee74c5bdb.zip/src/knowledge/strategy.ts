import { Chess, SQUARES, type Color, type PieceSymbol, type Square } from 'chess.js';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeEvidenceValue, type KnowledgeFinding, type KnowledgeProvenance } from './evidence';
import { uciForMove } from '../domain/chess/position';

export type StrategyConcept =
  | 'centre-control'
  | 'development'
  | 'tempo'
  | 'king-safety'
  | 'space'
  | 'piece-activity'
  | 'open-semi-open-files'
  | 'weak-squares'
  | 'outposts'
  | 'bishop-quality'
  | 'bishop-pair'
  | 'pawn-breaks'
  | 'prophylaxis'
  | 'exchange-strategy'
  | 'initiative'
  | 'counterplay'
  | 'blockade';

export const STRATEGY_CONCEPTS: readonly StrategyConcept[] = [
  'centre-control', 'development', 'tempo', 'king-safety', 'space', 'piece-activity',
  'open-semi-open-files', 'weak-squares', 'outposts', 'bishop-quality', 'bishop-pair',
  'pawn-breaks', 'prophylaxis', 'exchange-strategy', 'initiative', 'counterplay', 'blockade',
];

export type StrategyFinding = KnowledgeFinding & {
  concept: StrategyConcept;
  possiblePlan: string;
  candidate: boolean;
  side?: Color;
};

export type DeferredStrategyConcept = { concept: StrategyConcept; reason: string };
export type StrategyHistory = { initialFen?: string; uciMoves: readonly string[] };
export type StrategyAnalysisInput = { fen: string; history?: StrategyHistory };
export type StrategyAnalysis = {
  fen: string;
  findings: StrategyFinding[];
  deferred: DeferredStrategyConcept[];
  limitations: string[];
};

type PawnBreakCandidate = {
  side: Color;
  san: string;
  uci: string;
  from: Square;
  to: Square;
  capturedPawn: boolean;
  newlyChallengedPawns: Square[];
};

type PieceTrace = {
  id: string;
  color: Color;
  type: PieceSymbol;
  moves: Array<{ ply: number; san: string; uci: string }>;
};

const FILES = 'abcdefgh';
const CENTER_SQUARES: readonly Square[] = ['d4', 'e4', 'd5', 'e5'];
const CENTRAL_FILES = new Set([2, 3, 4, 5]);
const MINOR_HOME: Record<Color, Readonly<Record<string, PieceSymbol>>> = {
  w: { b1: 'n', g1: 'n', c1: 'b', f1: 'b' },
  b: { b8: 'n', g8: 'n', c8: 'b', f8: 'b' },
};
const PIECE_VALUE_LABEL: Record<PieceSymbol, string> = { p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king' };

function opposite(color: Color): Color {
  return color === 'w' ? 'b' : 'w';
}

function sideLabel(color: Color): string {
  return color === 'w' ? 'White' : 'Black';
}

function fileIndex(square: Square): number {
  return square.charCodeAt(0) - 97;
}

function rankIndex(square: Square): number {
  return Number(square[1]);
}

function makeSquare(file: number, rank: number): Square | undefined {
  if (file < 0 || file > 7 || rank < 1 || rank > 8) return undefined;
  return `${FILES[file]}${rank}` as Square;
}

function squaresOf(chess: Chess, color: Color, type?: PieceSymbol): Square[] {
  return SQUARES.filter((square) => {
    const piece = chess.get(square);
    return piece?.color === color && (!type || piece.type === type);
  });
}

function pawnAttackSquares(chess: Chess, color: Color): Set<Square> {
  const direction = color === 'w' ? 1 : -1;
  const attacked = new Set<Square>();
  for (const pawn of squaresOf(chess, color, 'p')) {
    for (const deltaFile of [-1, 1]) {
      const target = makeSquare(fileIndex(pawn) + deltaFile, rankIndex(pawn) + direction);
      if (target) attacked.add(target);
    }
  }
  return attacked;
}

function nonPawnInfluence(chess: Chess, color: Color): { squares: Square[]; opponentHalfSquares: Square[]; activePieces: number } {
  const controlled: Square[] = [];
  const pieces = squaresOf(chess, color).filter((square) => {
    const type = chess.get(square)?.type;
    return type === 'n' || type === 'b' || type === 'r' || type === 'q';
  });
  let activePieces = 0;
  for (const square of SQUARES) {
    const occupant = chess.get(square);
    if (occupant?.color === color) continue;
    const attackers = chess.attackers(square, color).filter((from) => {
      const type = chess.get(from)?.type;
      return type === 'n' || type === 'b' || type === 'r' || type === 'q';
    });
    if (attackers.length) controlled.push(square);
  }
  for (const pieceSquare of pieces) {
    const geometricTargets = controlled.filter((target) => chess.attackers(target, color).some((from) => from === pieceSquare));
    if (geometricTargets.length >= 2) activePieces++;
  }
  const opponentHalfSquares = controlled.filter((square) => color === 'w' ? rankIndex(square) >= 5 : rankIndex(square) <= 4);
  return { squares: controlled, opponentHalfSquares, activePieces };
}

function atlasSource(section: string, basis: string): KnowledgeProvenance {
  return { kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md', section, basis };
}

function finding(input: {
  concept: StrategyConcept;
  id: string;
  label: string;
  evidence: KnowledgeEvidence[];
  confidence: number;
  relevance: number;
  possiblePlan: string;
  section: string;
  basis: string;
  side?: Color;
  candidate?: boolean;
}): StrategyFinding {
  const base = assertKnowledgeFinding({
    conceptId: `strategy.${input.concept}.${input.id}`,
    label: input.label,
    evidence: input.evidence,
    confidence: input.confidence,
    relevance: input.relevance,
    possibleImplications: [{ ...(input.side ? { side: input.side } : {}), description: input.possiblePlan }],
    provenance: [
      { kind: 'board-derivation', source: 'chess.js', method: 'legal FEN parsing plus explicitly described static geometry; no search/evaluation' },
      atlasSource(input.section, input.basis),
    ],
  });
  return {
    ...base,
    concept: input.concept,
    possiblePlan: input.possiblePlan,
    candidate: input.candidate ?? false,
    ...(input.side ? { side: input.side } : {}),
  };
}

function boardEvidence(
  id: string,
  description: string,
  values: Readonly<Record<string, KnowledgeEvidenceValue>>,
  squares?: readonly Square[],
): KnowledgeEvidence {
  return { id, kind: 'board-state', description, values, ...(squares ? { squares } : {}) };
}

function squareColor(square: Square): number {
  return (fileIndex(square) + rankIndex(square)) % 2;
}

function diagonalReach(chess: Chess, bishop: Square): Square[] {
  const reached: Square[] = [];
  for (const [deltaFile, deltaRank] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    let file = fileIndex(bishop) + deltaFile;
    let rank = rankIndex(bishop) + deltaRank;
    while (file >= 0 && file <= 7 && rank >= 1 && rank <= 8) {
      const square = makeSquare(file, rank)!;
      reached.push(square);
      if (chess.get(square)) break;
      file += deltaFile;
      rank += deltaRank;
    }
  }
  return reached;
}

function passedPawns(chess: Chess, color: Color): Square[] {
  const enemyPawns = squaresOf(chess, opposite(color), 'p');
  return squaresOf(chess, color, 'p').filter((pawn) => {
    const rank = rankIndex(pawn);
    const file = fileIndex(pawn);
    return enemyPawns.every((enemyPawn) => {
      const enemyRank = rankIndex(enemyPawn);
      const enemyFile = fileIndex(enemyPawn);
      const ahead = color === 'w' ? enemyRank > rank : enemyRank < rank;
      return !ahead || Math.abs(enemyFile - file) > 1;
    });
  });
}

function legalPawnBreaks(chess: Chess): PawnBreakCandidate[] {
  const side = chess.turn();
  const enemy = opposite(side);
  const beforeAttacks = pawnAttackSquares(chess, side);
  const enemyPawnSquares = squaresOf(chess, enemy, 'p');
  const candidates: PawnBreakCandidate[] = [];
  for (const move of chess.moves({ verbose: true })) {
    if (move.piece !== 'p') continue;
    const trial = new Chess(chess.fen({ forceEnpassantSquare: true }));
    trial.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const afterAttacks = pawnAttackSquares(trial, side);
    const newlyChallengedPawns = enemyPawnSquares.filter((square) => afterAttacks.has(square) && !beforeAttacks.has(square));
    const capturedPawn = move.isCapture() && move.captured === 'p';
    if (!capturedPawn && newlyChallengedPawns.length === 0) continue;
    candidates.push({
      side,
      san: move.san,
      uci: uciForMove(move),
      from: move.from,
      to: move.to,
      capturedPawn,
      newlyChallengedPawns,
    });
  }
  return candidates;
}

function potentialPawnBreaks(chess: Chess, color: Color, targetColor: Color): Array<{ from: Square; to: Square; targets: Square[] }> {
  const direction = color === 'w' ? 1 : -1;
  const targetPawns = squaresOf(chess, targetColor, 'p');
  const results: Array<{ from: Square; to: Square; targets: Square[] }> = [];
  for (const pawn of squaresOf(chess, color, 'p')) {
    const startRank = rankIndex(pawn);
    const file = fileIndex(pawn);
    const eligiblePushes = [1, ...(startRank === (color === 'w' ? 2 : 7) ? [2] : [])];
    for (const steps of eligiblePushes) {
      const toRank = startRank + direction * steps;
      let pathClear = true;
      for (let step = 1; step <= steps; step++) {
        const pathSquare = makeSquare(file, startRank + direction * step);
        if (!pathSquare || chess.get(pathSquare)) pathClear = false;
      }
      const destination = makeSquare(file, toRank);
      if (!pathClear || !destination) continue;
      const attackRank = toRank + direction;
      const targets = targetPawns.filter((target) =>
        rankIndex(target) === attackRank && Math.abs(fileIndex(target) - file) === 1,
      );
      if (targets.length) results.push({ from: pawn, to: destination, targets });
    }
  }
  return results;
}

function canEnemyPawnChallenge(chess: Chess, color: Color, target: Square): boolean {
  for (const pawn of squaresOf(chess, opposite(color), 'p')) {
    const enemyColor = opposite(color);
    const enemyDirection = enemyColor === 'w' ? 1 : -1;
    const startRank = rankIndex(pawn);
    const file = fileIndex(pawn);
    const options = [1, ...(startRank === (enemyColor === 'w' ? 2 : 7) ? [2] : [])];
    for (const steps of options) {
      let clear = true;
      for (let step = 1; step <= steps; step++) {
        const path = makeSquare(file, startRank + enemyDirection * step);
        if (!path || chess.get(path)) clear = false;
      }
      if (!clear) continue;
      const movedRank = startRank + enemyDirection * steps;
      const targetRank = movedRank + enemyDirection;
      if (targetRank === rankIndex(target) && Math.abs(file - fileIndex(target)) === 1) return true;
    }
  }
  return false;
}

function traceHistory(chess: Chess, history: StrategyHistory): PieceTrace[] {
  const replay = new Chess(history.initialFen ?? new Chess().fen());
  const unitsAtSquare = new Map<Square, PieceTrace>();
  const allTraces: PieceTrace[] = [];
  let serial = 0;
  for (const square of SQUARES) {
    const piece = replay.get(square);
    if (!piece) continue;
    const trace = { id: `piece-${serial++}-${piece.color}-${square}`, color: piece.color, type: piece.type, moves: [] };
    unitsAtSquare.set(square, trace);
    allTraces.push(trace);
  }
  for (const [index, uci] of history.uciMoves.entries()) {
    const match = /^([a-h][1-8])([a-h][1-8])([qrbn])?$/.exec(uci);
    if (!match) throw new Error(`Invalid strategy-history UCI at ply ${index + 1}.`);
    const from = match[1] as Square;
    const to = match[2] as Square;
    const move = replay.move({ from, to, ...(match[3] ? { promotion: match[3] as Exclude<PieceSymbol, 'p' | 'k'> } : {}) });
    if (!move) throw new Error(`Illegal strategy-history move at ply ${index + 1}.`);
    const actor = unitsAtSquare.get(from) ?? { id: `piece-${serial++}-${move.color}-${from}`, color: move.color, type: move.piece, moves: [] };
    if (!allTraces.includes(actor)) allTraces.push(actor);
    const uciValue = uciForMove(move);
    actor.moves.push({ ply: index + 1, san: move.san, uci: uciValue });
    const capturedSquare = move.isEnPassant()
      ? `${to[0]}${rankIndex(to) - (move.color === 'w' ? 1 : -1)}` as Square
      : move.isCapture() ? to : undefined;
    if (capturedSquare) unitsAtSquare.delete(capturedSquare);
    unitsAtSquare.delete(from);
    unitsAtSquare.set(to, actor);
    if (move.promotion) actor.type = move.promotion;
    if (move.flags.includes('k') || move.flags.includes('q')) {
      const backRank = move.color === 'w' ? '1' : '8';
      const rookFrom = `${move.flags.includes('k') ? 'h' : 'a'}${backRank}` as Square;
      const rookTo = `${move.flags.includes('k') ? 'f' : 'd'}${backRank}` as Square;
      const rook = unitsAtSquare.get(rookFrom);
      if (rook) {
        unitsAtSquare.delete(rookFrom);
        unitsAtSquare.set(rookTo, rook);
      }
    }
  }
  if (replay.fen({ forceEnpassantSquare: true }) !== chess.fen({ forceEnpassantSquare: true })) {
    throw new Error('Strategy history does not replay to the supplied position.');
  }
  // Retain captured units too: their prior repeated moves remain historical evidence.
  return allTraces;
}

function addFinding(
  output: StrategyFinding[],
  input: Parameters<typeof finding>[0],
) {
  output.push(finding(input));
}

export function analyzeStrategyPosition(input: StrategyAnalysisInput): StrategyAnalysis {
  const chess = new Chess(input.fen);
  const fen = chess.fen({ forceEnpassantSquare: true });
  const findings: StrategyFinding[] = [];
  const omittedReasons = new Map<StrategyConcept, string>();
  const deferReason = (concept: StrategyConcept, reason: string) => omittedReasons.set(concept, reason);

  // Centre: report geometric influence and pawn occupancy, never a positional verdict.
  for (const color of ['w', 'b'] as const) {
    const controlled = CENTER_SQUARES.filter((square) => chess.attackers(square, color).length > 0);
    const occupiedPawns = CENTER_SQUARES.filter((square) => {
      const piece = chess.get(square);
      return piece?.color === color && piece.type === 'p';
    });
    if (controlled.length || occupiedPawns.length) {
      addFinding(findings, {
        concept: 'centre-control', id: color, side: color,
        label: `${sideLabel(color)} has central pawn/influence evidence`,
        evidence: [boardEvidence(
          `centre-${color}`, 'Central squares occupied by friendly pawns or geometrically attacked by friendly pieces.',
          { controlledSquares: controlled, occupiedCentralPawns: occupiedPawns },
          [...controlled, ...occupiedPawns],
        )],
        confidence: 0.88, relevance: Math.min(1, (controlled.length + occupiedPawns.length) / 6), candidate: true,
        possiblePlan: 'Use the centre evidence to assess central breaks and piece coordination; influence is not the same as secure control.',
        section: '§3.1 Centre', basis: 'The Atlas asks whether the centre is open, closed, or tense, and who benefits from changing it.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'centre-control')) deferReason('centre-control', 'No central pawn occupancy or geometric influence met the reporting threshold.');

  // Development: current minor-piece placement is visible; move history is not assumed.
  for (const color of ['w', 'b'] as const) {
    const homeSquares = Object.entries(MINOR_HOME[color]) as Array<[Square, PieceSymbol]>;
    const homePieces = homeSquares.filter(([square, type]) => {
      const piece = chess.get(square);
      return piece?.color === color && piece.type === type;
    }).map(([square]) => square);
    const awayMinors = squaresOf(chess, color).filter((square) => {
      const type = chess.get(square)?.type;
      return (type === 'n' || type === 'b') && !Object.hasOwn(MINOR_HOME[color], square);
    });
    if (awayMinors.length) {
      addFinding(findings, {
        concept: 'development', id: color, side: color,
        label: `${sideLabel(color)} has ${awayMinors.length} minor piece(s) off the standard home squares`,
        evidence: [boardEvidence(
          `development-${color}`, 'Current knight/bishop locations compared with standard initial minor-piece squares.',
          { piecesOffHomeSquares: awayMinors, matchingMinorsStillOnHomeSquares: homePieces }, [...awayMinors, ...homePieces],
        )],
        confidence: 0.82, relevance: Math.min(1, awayMinors.length / 3), candidate: true,
        possiblePlan: 'Review whether the remaining pieces are developed and coordinated; a static board cannot distinguish a moved piece from a replacement or capture.',
        section: '§3.1 Development and tempo', basis: 'The Atlas recommends checking undeveloped pieces and development before committing to a plan.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'development')) deferReason('development', 'No minor piece is currently off a standard home square; FEN alone does not prove past development moves.');

  // Tempo is only surfaced from a validated, replayed ordered move history.
  if (input.history) {
    const traces = traceHistory(chess, input.history);
    const repeated = traces.filter((trace) => trace.moves.length >= 2 && trace.moves[1].ply <= 12 && ['n', 'b', 'q'].includes(trace.type));
    for (const trace of repeated) {
      const first = trace.moves[0];
      const second = trace.moves[1];
      addFinding(findings, {
        concept: 'tempo', id: trace.id, side: trace.color,
        label: `${sideLabel(trace.color)} moved the same ${PIECE_VALUE_LABEL[trace.type]} at least twice in the first 12 plies`,
        evidence: [{
          id: `tempo-${trace.id}`, kind: 'move-sequence', description: 'Piece identity was tracked by replaying the supplied legal UCI history.',
          values: { firstMove: `${first.san} (${first.uci})`, repeatedMove: `${second.san} (${second.uci})`, ply: [first.ply, second.ply] },
        }],
        confidence: 0.96, relevance: 0.55, candidate: true,
        possiblePlan: 'Ask what the repeated move gained and whether development/king safety is being delayed; repeated moves are not automatically a tempo loss.',
        section: '§3.1 Development and tempo', basis: 'The Atlas lists repeated moves and queen tempo as development/tempo considerations, not as automatic mistakes.',
      });
    }
    if (!repeated.length) deferReason('tempo', 'The validated history contains no same-piece repeated move in the first 12 plies.');
  } else {
    deferReason('tempo', 'A static FEN has no ordered history, so tempo expenditure is not inferred.');
  }

  // King safety: pawn shield/open-file cues only; no attack or mating assessment.
  for (const color of ['w', 'b'] as const) {
    const kingSquare = squaresOf(chess, color, 'k')[0];
    if (!kingSquare) continue;
    const direction = color === 'w' ? 1 : -1;
    const shieldRank = rankIndex(kingSquare) + direction;
    const shieldSquares = [-1, 0, 1].map((offset) => makeSquare(fileIndex(kingSquare) + offset, shieldRank)).filter((square): square is Square => Boolean(square));
    const shieldPawns = shieldSquares.filter((square) => {
      const piece = chess.get(square);
      return piece?.color === color && piece.type === 'p';
    });
    const adjacentFiles = [-1, 0, 1].map((offset) => fileIndex(kingSquare) + offset).filter((file) => file >= 0 && file < 8);
    const nearbyOpenFiles = adjacentFiles.filter((file) =>
      SQUARES.filter((square) => fileIndex(square) === file).every((square) => chess.get(square)?.type !== 'p'),
    ).map((file) => FILES[file]);
    if (shieldPawns.length < 2 || nearbyOpenFiles.length) {
      addFinding(findings, {
        concept: 'king-safety', id: color, side: color,
        label: `${sideLabel(color)} king shelter has ${shieldPawns.length}/3 adjacent shield pawns${nearbyOpenFiles.length ? `; nearby open file(s): ${nearbyOpenFiles.join(', ')}` : ''}`,
        evidence: [boardEvidence(
          `king-shelter-${color}`, 'King square, same-side pawn shield directly in front, and open files on adjacent files.',
          { kingSquare, shieldPawns, nearbyOpenFiles }, [kingSquare, ...shieldSquares, ...shieldPawns],
        )],
        confidence: 0.9, relevance: Math.min(1, (3 - shieldPawns.length + nearbyOpenFiles.length) / 3), candidate: true,
        possiblePlan: 'Review king shelter and open lines before choosing a plan; these pawn cues do not establish that an attack exists.',
        section: '§3.1 King safety', basis: 'The Atlas lists pawn shield, open files/diagonals, escape squares and castling as king-safety factors.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'king-safety')) deferReason('king-safety', 'Both kings have at least two adjacent shelter pawns and no adjacent open file under this conservative static check.');

  // Space: count central/advanced pawn presence, not a global advantage score.
  for (const color of ['w', 'b'] as const) {
    const advanced = squaresOf(chess, color, 'p').filter((square) => color === 'w' ? rankIndex(square) >= 5 : rankIndex(square) <= 4);
    if (advanced.length >= 2) {
      addFinding(findings, {
        concept: 'space', id: color, side: color,
        label: `${sideLabel(color)} has ${advanced.length} pawns in the opponent’s half`,
        evidence: [boardEvidence(`space-${color}`, 'Friendly pawns occupy the opposing half of the board.', { advancedPawns: advanced }, advanced)],
        confidence: 0.86, relevance: Math.min(1, advanced.length / 4), candidate: true,
        possiblePlan: 'Use the advanced pawns to consider restricting squares, while checking whether they become targets or leave weak squares.',
        section: '§3.1 Space', basis: 'The Atlas describes advanced pawns as space that can restrict pieces but may also become targets or leave weak squares.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'space')) deferReason('space', 'No side has two or more pawns in the opponent half; a single advanced pawn is not labelled a space advantage.');

  // Piece activity: geometric non-pawn reach, explicitly not legal mobility/evaluation.
  const activity = new Map<Color, ReturnType<typeof nonPawnInfluence>>();
  for (const color of ['w', 'b'] as const) {
    const measure = nonPawnInfluence(chess, color);
    activity.set(color, measure);
    if (measure.activePieces >= 2 || measure.opponentHalfSquares.length >= 3) {
      addFinding(findings, {
        concept: 'piece-activity', id: color, side: color,
        label: `${sideLabel(color)} non-pawns geometrically influence ${measure.squares.length} available squares`,
        evidence: [boardEvidence(
          `piece-activity-${color}`, 'Distinct empty/enemy-occupied squares reached by knights, bishops, rooks, or queens; pins and legal mobility are not resolved.',
          { influenceSquares: measure.squares, opponentHalfSquares: measure.opponentHalfSquares, activePieces: measure.activePieces },
          measure.squares,
        )],
        confidence: 0.76, relevance: Math.min(1, Math.max(measure.activePieces / 4, measure.opponentHalfSquares.length / 8)), candidate: true,
        possiblePlan: 'Look for the least active piece and a useful square or file; geometric reach alone is not a piece-quality verdict.',
        section: '§3.1 Piece activity/mobility', basis: 'The Atlas recommends identifying the least useful piece and seeking a better square or open file.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'piece-activity')) deferReason('piece-activity', 'No side met the conservative non-pawn geometric-reach threshold.');

  // Open and semi-open files are exact pawn-count facts.
  for (let file = 0; file < 8; file++) {
    const fileSquares = SQUARES.filter((square) => fileIndex(square) === file);
    const whitePawns = fileSquares.filter((square) => chess.get(square)?.color === 'w' && chess.get(square)?.type === 'p');
    const blackPawns = fileSquares.filter((square) => chess.get(square)?.color === 'b' && chess.get(square)?.type === 'p');
    const name = FILES[file];
    if (!whitePawns.length && !blackPawns.length) {
      addFinding(findings, {
        concept: 'open-semi-open-files', id: `open-${name}`,
        label: `Open ${name}-file`,
        evidence: [boardEvidence(`open-file-${name}`, 'Neither side has a pawn on this file.', { file: name, whitePawns: 0, blackPawns: 0 }, fileSquares)],
        confidence: 1, relevance: 0.7, candidate: false,
        possiblePlan: 'Consider whether a rook can use this file or an entry square; openness alone does not imply control.',
        section: '§3.1 Open/semi-open files', basis: 'The Atlas defines open/semi-open files through pawn targets and possible rook entry, not by openness alone.',
      });
    } else if (!whitePawns.length || !blackPawns.length) {
      const side = whitePawns.length ? 'b' : 'w';
      addFinding(findings, {
        concept: 'open-semi-open-files', id: `semi-${side}-${name}`, side,
        label: `${sideLabel(side)} has a semi-open ${name}-file`,
        evidence: [boardEvidence(
          `semi-open-file-${side}-${name}`, 'The named side has no pawn on the file while the opponent has at least one.',
          { file: name, whitePawns: whitePawns.length, blackPawns: blackPawns.length }, fileSquares,
        )],
        confidence: 1, relevance: 0.65, candidate: false,
        possiblePlan: 'Consider rook pressure on targets or entry squares on the semi-open file; assess piece access and defense.',
        section: '§3.1 Open/semi-open files', basis: 'The Atlas recommends using rooks on files with pawn targets, entry squares, or seventh-rank access.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'open-semi-open-files')) deferReason('open-semi-open-files', 'Every file still contains at least one pawn from each side.');

  // Weak-square cues require an advanced friendly non-pawn occupant and no opposing pawn attack.
  for (const color of ['w', 'b'] as const) {
    const enemyPawnAttacks = pawnAttackSquares(chess, opposite(color));
    const candidates = SQUARES.filter((square) => {
      const piece = chess.get(square);
      const relativeRank = color === 'w' ? rankIndex(square) : 9 - rankIndex(square);
      return CENTRAL_FILES.has(fileIndex(square)) && relativeRank >= 5 && relativeRank <= 6
        && piece?.color === color && piece.type !== 'p' && piece.type !== 'k' && !enemyPawnAttacks.has(square);
    });
    if (candidates.length) {
      addFinding(findings, {
        concept: 'weak-squares', id: color, side: color,
        label: `${sideLabel(color)} occupies central advanced squares not currently attacked by enemy pawns`,
        evidence: [boardEvidence(
          `pawn-holes-${color}`, 'Squares occupied by friendly pieces in the opponent half, outside the current opposing pawn attack map.',
          { candidateSquares: candidates, enemyPawnAttackSquares: [...enemyPawnAttacks] }, candidates,
        )],
        confidence: 0.82, relevance: Math.min(1, candidates.length / 2), candidate: true,
        possiblePlan: 'Assess whether the occupant can remain or be reinforced; piece exchanges and future pawn moves may change the square’s status.',
        section: '§3.1 Weak squares/outposts', basis: 'The Atlas defines a weak square by whether an enemy pawn can dislodge a piece, and says pawn structure must confirm the square is durable.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'weak-squares')) deferReason('weak-squares', 'No friendly non-pawn occupies a central advanced square outside the current enemy-pawn attack map.');

  // Outpost candidates additionally require friendly pawn support and no immediate pawn push challenge.
  for (const color of ['w', 'b'] as const) {
    const ownPawnAttacks = pawnAttackSquares(chess, color);
    const enemyPawnAttacks = pawnAttackSquares(chess, opposite(color));
    const knights = squaresOf(chess, color, 'n').filter((square) => {
      const relativeRank = color === 'w' ? rankIndex(square) : 9 - rankIndex(square);
      return CENTRAL_FILES.has(fileIndex(square)) && relativeRank >= 5 && relativeRank <= 6
        && ownPawnAttacks.has(square) && !enemyPawnAttacks.has(square)
        && !canEnemyPawnChallenge(chess, color, square);
    });
    for (const knight of knights) {
      addFinding(findings, {
        concept: 'outposts', id: `${color}-${knight}`, side: color,
        label: `${sideLabel(color)} knight on ${knight} is pawn-supported and not immediately challengeable by an enemy pawn`,
        evidence: [boardEvidence(
          `outpost-${color}-${knight}`, 'Advanced central knight is defended by a friendly pawn; current/one-push enemy pawn attacks were checked.',
          { square: knight, ownPawnSupport: true, currentEnemyPawnAttack: false, immediateEnemyPawnChallenge: false }, [knight],
        )],
        confidence: 0.9, relevance: 0.82, candidate: true,
        possiblePlan: 'Preserve or reinforce the knight’s square if useful; exchanges by pieces and longer-term pawn routes are not assessed.',
        section: '§3.1 Weak squares/outposts', basis: 'The Atlas describes a durable square, especially for a central knight, as an outpost only after checking pawn challengeability.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'outposts')) deferReason('outposts', 'No central advanced knight met the pawn-support and pawn-challengeability conditions.');

  // Bishop pair is a count; bishop quality is supplied only as measurable cues, not a good/bad verdict.
  for (const color of ['w', 'b'] as const) {
    const bishops = squaresOf(chess, color, 'b');
    if (bishops.length >= 2) {
      addFinding(findings, {
        concept: 'bishop-pair', id: color, side: color,
        label: `${sideLabel(color)} has two bishops (bishop-pair count)`,
        evidence: [boardEvidence(`bishop-pair-${color}`, 'Two same-side bishops are present on the board.', { bishopSquares: bishops }, bishops)],
        confidence: 1, relevance: 0.66, candidate: false,
        possiblePlan: 'Check whether the position is open enough for both bishops; the pair is a material configuration, not an automatic advantage.',
        section: '§3.1 Bishop pair', basis: 'The Atlas notes that two bishops can be useful on open lines, while closed structures may favor knights/outposts; this is not automatic.',
      });
    }
    if (bishops.length) {
      const ownPawns = squaresOf(chess, color, 'p');
      const profiles = bishops.map((square) => ({
        square,
        sameColorFriendlyPawns: ownPawns.filter((pawn) => squareColor(pawn) === squareColor(square)),
        geometricDiagonalSquares: diagonalReach(chess, square),
      }));
      addFinding(findings, {
        concept: 'bishop-quality', id: color, side: color,
        label: `${sideLabel(color)} bishop-quality cues (pawn color-complex and diagonal reach; no good/bad verdict)`,
        evidence: profiles.map((profile, index) => boardEvidence(
          `bishop-profile-${color}-${index}`, 'Same-color friendly pawn count and diagonal squares before the first blocker.',
          { bishop: profile.square, sameColorFriendlyPawns: profile.sameColorFriendlyPawns, diagonalReach: profile.geometricDiagonalSquares },
          [profile.square, ...profile.sameColorFriendlyPawns, ...profile.geometricDiagonalSquares],
        )),
        confidence: 0.78, relevance: 0.52, candidate: true,
        possiblePlan: 'Compare the bishop’s open diagonals with friendly same-color pawns and future breaks; these cues can change and do not alone rate the bishop.',
        section: '§3.1 Good vs bad bishop; bishop pair', basis: 'The Atlas says same-color pawns may restrict a bishop but open diagonals, pawn breaks and targets can change its quality.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'bishop-pair')) deferReason('bishop-pair', 'Neither side currently has two bishops.');
  if (!findings.some((item) => item.concept === 'bishop-quality')) deferReason('bishop-quality', 'No bishop is present to profile.');

  // Legal pawn moves only; report structural break candidates, not their tactical soundness.
  const breakCandidates = legalPawnBreaks(chess);
  for (const candidate of breakCandidates.slice(0, 8)) {
    addFinding(findings, {
      concept: 'pawn-breaks', id: candidate.uci, side: candidate.side,
      label: `${sideLabel(candidate.side)} legal pawn-break candidate ${candidate.san}`,
      evidence: [
        { id: `pawn-break-move-${candidate.uci}`, kind: 'move-sequence', description: 'A legal pawn move from chess.js that captures an enemy pawn or newly attacks one geometrically.', values: { san: candidate.san, uci: candidate.uci } },
        boardEvidence(`pawn-break-target-${candidate.uci}`, 'Pawn structure before/after the candidate move.', {
          from: candidate.from, to: candidate.to, capturedPawn: candidate.capturedPawn,
          newlyChallengedEnemyPawns: candidate.newlyChallengedPawns,
        }, [candidate.from, candidate.to, ...candidate.newlyChallengedPawns]),
      ],
      confidence: 0.82, relevance: 0.62, candidate: true,
      possiblePlan: 'Assess whether this legal pawn move changes the structure in your favor; calculate exchanges and the opponent’s reply before selecting it.',
      section: '§3.1 Pawn break', basis: 'The Atlas defines a pawn break as a pawn move that changes structure, opens a line, or removes a defender, and advises checking what becomes weak.',
    });
  }
  if (!breakCandidates.length) deferReason('pawn-breaks', 'No legal pawn move captures or newly challenges an enemy pawn in this position.');

  if (breakCandidates.length) {
    const side = chess.turn();
    const activityForSide = activity.get(side)!;
    const targetSquares = [...new Set(breakCandidates.flatMap((candidate) => candidate.newlyChallengedPawns))];
    addFinding(findings, {
      concept: 'counterplay', id: side, side,
      label: `${sideLabel(side)} has a legal pawn-break route that may create structural counterplay`,
      evidence: [
        boardEvidence('counterplay-pawn-breaks', 'Legal pawn-break candidates and their immediate structural targets.', {
          candidateMoves: breakCandidates.map((candidate) => `${candidate.san} (${candidate.uci})`),
          challengedPawns: targetSquares,
          capturedPawnCandidates: breakCandidates.filter((candidate) => candidate.capturedPawn).map((candidate) => candidate.uci),
        }, breakCandidates.flatMap((candidate) => [candidate.from, candidate.to, ...candidate.newlyChallengedPawns])),
      ],
      confidence: 0.77, relevance: 0.66, candidate: true,
      possiblePlan: 'Use a break to contest the opponent’s pawn structure or space if your pieces can support it; this is a route, not proof of adequate compensation.',
      section: '§3.1 Initiative / counterplay', basis: 'The Atlas says counterplay can compensate for material/space only while activity and threats remain; the finding reports only the structural route.',
    });

    if (activityForSide.opponentHalfSquares.length >= 2) {
      addFinding(findings, {
        concept: 'initiative', id: side, side,
        label: `${sideLabel(side)} has an initiative candidate: legal pawn break plus non-pawn reach in the opponent half`,
        evidence: [
          boardEvidence('initiative-break', 'A legal pawn-break candidate exists for the side to move.', { candidateMoves: breakCandidates.map((candidate) => `${candidate.san} (${candidate.uci})`) }, breakCandidates.flatMap((candidate) => [candidate.from, candidate.to])),
          boardEvidence('initiative-reach', 'Non-pawn geometric reach in the opponent half; no forcing line or attack is assessed.', { squares: activityForSide.opponentHalfSquares }, activityForSide.opponentHalfSquares),
        ],
        confidence: 0.61, relevance: 0.53, candidate: true,
        possiblePlan: 'Consider whether the break can be used with tempo to sustain activity; initiative is not confirmed without calculating the opponent’s replies.',
        section: '§3.1 Initiative / counterplay', basis: 'The Atlas relates initiative to sustained threats and warns to check whether compensation survives when activity stops; this is only a positional candidate cue.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'counterplay')) deferReason('counterplay', 'No legal structural pawn-break route for the side to move met the detector conditions.');
  if (!findings.some((item) => item.concept === 'initiative')) deferReason('initiative', 'No combination of a legal pawn break and at least two non-pawn influence squares in the opponent half; forcing initiative is not inferred from a static position.');

  // Prophylaxis: only raise a review cue when the opponent has a clear pseudo-legal pawn-break geometry.
  const sideToMove = chess.turn();
  const enemyBreaks = potentialPawnBreaks(chess, opposite(sideToMove), sideToMove);
  if (enemyBreaks.length) {
    addFinding(findings, {
      concept: 'prophylaxis', id: sideToMove, side: sideToMove,
      label: `${sideLabel(opposite(sideToMove))} has ${enemyBreaks.length} pawn-break candidate(s) to review`,
      evidence: [boardEvidence(
        'prophylaxis-enemy-breaks', 'Opponent pawn pushes have clear paths and would geometrically challenge friendly pawns.',
        { candidatePushes: enemyBreaks.map((item) => `${item.from}-${item.to}`), targetPawns: [...new Set(enemyBreaks.flatMap((item) => item.targets))], method: 'pseudo-legal pawn geometry; king safety and pins not checked' },
        enemyBreaks.flatMap((item) => [item.from, item.to, ...item.targets]),
      )],
      confidence: 0.67, relevance: 0.58, candidate: true,
      possiblePlan: 'Before committing elsewhere, decide whether a concrete pawn-break plan must be prevented or answered; do not spend a tempo prophylactically without a real target.',
      section: '§3.1 Prophylaxis', basis: 'The Atlas defines prophylaxis as identifying and preventing a real opponent plan, and cautions against losing tempo from fear alone.',
    });
  } else {
    deferReason('prophylaxis', 'No clear pseudo-legal opponent pawn push currently challenges a friendly pawn; no prophylactic threat is invented.');
  }

  // Exchange strategy is exposed only when piece inventories create a concrete comparison.
  const bishopCounts = { w: squaresOf(chess, 'w', 'b').length, b: squaresOf(chess, 'b', 'b').length };
  const knightCounts = { w: squaresOf(chess, 'w', 'n').length, b: squaresOf(chess, 'b', 'n').length };
  const pairVsKnights: Array<{ pair: Color; knights: Color }> = [];
  if (bishopCounts.w >= 2 && bishopCounts.b === 0 && knightCounts.b >= 2) pairVsKnights.push({ pair: 'w', knights: 'b' });
  if (bishopCounts.b >= 2 && bishopCounts.w === 0 && knightCounts.w >= 2) pairVsKnights.push({ pair: 'b', knights: 'w' });
  for (const comparison of pairVsKnights) {
    addFinding(findings, {
      concept: 'exchange-strategy', id: `${comparison.pair}-pair-vs-${comparison.knights}-knights`, side: comparison.pair,
      label: `${sideLabel(comparison.pair)} bishop pair versus ${sideLabel(comparison.knights)} two-or-more knights: exchange context`,
      evidence: [boardEvidence(
        'exchange-piece-inventory', 'The board has a bishop-pair versus knight-heavy material configuration.',
        { whiteBishops: bishopCounts.w, blackBishops: bishopCounts.b, whiteKnights: knightCounts.w, blackKnights: knightCounts.b },
        [...squaresOf(chess, 'w', 'b'), ...squaresOf(chess, 'b', 'b'), ...squaresOf(chess, 'w', 'n'), ...squaresOf(chess, 'b', 'n')],
      )],
      confidence: 0.96, relevance: 0.55, candidate: true,
      possiblePlan: 'If a trade is available, compare the resulting pawn structure and open/closed lines; the piece count alone does not identify a favorable exchange.',
      section: '§3.1 Exchange strategy; bishop pair', basis: 'The Atlas says an exchange should be judged by the quality piece/defender/structure removed, and that bishop-pair value depends on openness.',
    });
  }
  if (!findings.some((item) => item.concept === 'exchange-strategy')) deferReason('exchange-strategy', 'No bishop-pair-versus-knight-heavy inventory cue is present; no particular exchange is inferred from superficial attacks.');

  // Blockade: exact passed-pawn geometry plus an enemy non-pawn immediately in front.
  for (const color of ['w', 'b'] as const) {
    const direction = color === 'w' ? 1 : -1;
    for (const pawn of passedPawns(chess, color)) {
      const front = makeSquare(fileIndex(pawn), rankIndex(pawn) + direction);
      const blocker = front ? chess.get(front) : undefined;
      if (!front || !blocker || blocker.color === color || blocker.type === 'p') continue;
      addFinding(findings, {
        concept: 'blockade', id: `${color}-${pawn}-${front}`, side: opposite(color),
        label: `${sideLabel(opposite(color))} piece on ${front} blocks the passed pawn on ${pawn}`,
        evidence: [boardEvidence(
          `blockade-${pawn}-${front}`, 'Pawn-race geometry: the pawn has no enemy pawn ahead on the same/adjacent files, and an enemy non-pawn occupies its immediate advance square.',
          { passedPawn: pawn, blockerSquare: front, blockerType: blocker.type, blockerColor: blocker.color }, [pawn, front],
        )],
        confidence: 0.96, relevance: 0.82, candidate: false,
        possiblePlan: 'Assess whether the blocker can remain supported and whether the passed pawn can be attacked from behind; no endgame evaluation is made.',
        section: '§3.1 Blockade', basis: 'The Atlas describes blockading a passed pawn with a piece on the square in front and checking whether that piece is safe.',
      });
    }
  }
  if (!findings.some((item) => item.concept === 'blockade')) deferReason('blockade', 'No enemy non-pawn immediately blocks a geometrically passed pawn.');

  const represented = new Set(findings.map((item) => item.concept));
  const deferred = STRATEGY_CONCEPTS.filter((concept) => !represented.has(concept)).map((concept) => ({
    concept,
    reason: omittedReasons.get(concept) ?? 'No evidence met the conservative reporting threshold for this position.',
  }));
  return {
    fen,
    findings,
    deferred,
    limitations: [
      'Plans are evidence-bound candidates, not engine evaluations, best-move advice, or claims about human intent.',
      'Geometric influence/pawn maps do not resolve pins, exchanges, forced replies, or king-safety tactics.',
      'Tempo requires validated ordered move history; a static FEN cannot establish move-order or repeated-piece tempo.',
      'Initiative and counterplay are emitted only as conditional cues; no tactics, attack, defence, or endgame recognition is performed.',
    ],
  };
}
