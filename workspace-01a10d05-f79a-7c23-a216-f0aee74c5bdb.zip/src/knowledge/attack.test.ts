import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { analyzeAttacks, type AttackFinding } from './attack';

function findingsFor(fen: string, motif: AttackFinding['motif']): AttackFinding[] {
  return analyzeAttacks(new Chess(fen)).findings.filter((finding) => finding.motif === motif);
}

function findingForMove(fen: string, motif: AttackFinding['motif'], uci: string): AttackFinding | undefined {
  return findingsFor(fen, motif).find((finding) => finding.triggeringMove?.uci === uci);
}

describe('attack-pattern recognition service', () => {
  it('keeps every attack idea evidence-bound, confidence-bounded and probabilistic unless the board/history fact is verified', () => {
    const analysis = analyzeAttacks(new Chess());
    expect(analysis.historyValidation).toBe('not-provided');
    for (const finding of analysis.findings) {
      expect(finding.conceptId).toBe(`attack.${finding.motif}`);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.provenance.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
      expect(finding.state).toBe('candidate');
      expect(finding.possibleConsequence).toMatch(/possible|candidate|may|could/i);
      expect(finding.possibleConsequence).not.toMatch(/opponent intends|the opponent plans/i);
    }
  });

  describe('exposed king and f2/f7 target', () => {
    it('marks an unshielded king as a possible attack condition', () => {
      const fen = '4k3/8/8/8/8/8/8/4K3 w - - 0 1';
      const findings = findingsFor(fen, 'exposed-king');
      expect(findings.length).toBeGreaterThan(0);
      expect(findings.every((finding) => finding.state === 'candidate')).toBe(true);
      expect(findings.some((finding) => finding.boardEvidence.some((evidence) => evidence.values?.shieldPawns === 0))).toBe(true);
    });

    it('does not flag the normal starting king shelters as exposed', () => {
      expect(findingsFor(new Chess().fen(), 'exposed-king')).toHaveLength(0);
    });

    it('finds an attacked f7 pawn but does not claim a forced capture', () => {
      const fen = '6k1/5p2/8/8/2B5/8/8/4K3 w - - 0 1';
      const target = findingsFor(fen, 'f2-f7-target').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('f7')));
      expect(target).toBeDefined();
      expect(target?.state).toBe('candidate');
      expect(target?.possibleConsequence).toMatch(/no forced capture/i);
    });

    it('detects the mirrored f2 target at the board edge as an attack candidate', () => {
      const fen = '5r1k/8/8/8/8/8/5P2/K7 w - - 0 1';
      const target = findingsFor(fen, 'f2-f7-target').find((finding) => finding.boardEvidence.some((evidence) => evidence.squares?.includes('f2')));
      expect(target).toBeDefined();
      expect(target?.side).toBe('b');
      expect(target?.state).toBe('candidate');
    });

    it('rejects the f2/f7 near-miss when the target pawn is absent or unattacked', () => {
      const fen = '6k1/4p3/8/8/2B5/8/8/4K3 w - - 0 1';
      expect(findingsFor(fen, 'f2-f7-target')).toHaveLength(0);
      expect(findingsFor(new Chess().fen(), 'f2-f7-target')).toHaveLength(0);
    });
  });

  describe('battery and open files', () => {
    it('reuses the tactical battery candidate and keeps attack outcome unproven', () => {
      const fen = '4k3/4p3/8/8/8/4Q3/8/4R2K w - - 0 1';
      const battery = findingsFor(fen, 'battery')[0];
      expect(battery).toBeDefined();
      expect(battery?.state).toBe('candidate');
      expect(battery?.possibleConsequence).toMatch(/no attack result/i);
    });

    it('does not infer a battery from a single aligned slider', () => {
      const fen = '4k3/4p3/8/8/8/8/8/4R2K w - - 0 1';
      expect(findingsFor(fen, 'battery')).toHaveLength(0);
    });

    it('recognizes clear-file pressure on an enemy queen as a candidate', () => {
      const fen = '6k1/4q3/8/8/8/8/8/4R2K w - - 0 1';
      const attack = findingsFor(fen, 'open-file-attack')[0];
      expect(attack).toBeDefined();
      expect(attack?.state).toBe('candidate');
      expect(attack?.boardEvidence[0].values?.fileState).toBe('open');
      expect(attack?.possibleConsequence).toMatch(/no tactical win/i);
    });

    it('rejects an open-file near-miss when the attacking side still has a file pawn', () => {
      const fen = '6k1/4q3/8/8/4P3/8/8/4R2K w - - 0 1';
      expect(findingsFor(fen, 'open-file-attack')).toHaveLength(0);
    });
  });

  describe('rook lifts and castling history', () => {
    it('offers a legal rook lift only as a candidate idea', () => {
      const fen = '7k/8/8/8/8/8/8/R6K w - - 0 1';
      const lift = findingForMove(fen, 'rook-lift', 'a1a3');
      expect(lift).toBeDefined();
      expect(lift?.state).toBe('candidate');
      expect(lift?.evidence.some((evidence) => evidence.values?.legal === true)).toBe(true);
      expect(lift?.possibleConsequence).toMatch(/not a recommended move/i);
    });

    it('rejects a rook-lift candidate blocked by its own pawn', () => {
      const fen = '7k/8/8/8/8/8/P7/R6K w - - 0 1';
      expect(findingsFor(fen, 'rook-lift')).toHaveLength(0);
    });

    it('recognizes opposite-side castling only from replay-validated legal history', () => {
      let record = createGame({
        id: 'attack-opposite-castling',
        initialFen: 'r3k3/8/8/8/8/8/8/4K2R w Kq - 0 1',
        now: '2026-10-05T00:00:00.000Z',
      });
      record = applyMove(record, 'e1g1', { committedAt: '2026-10-05T00:00:01.000Z' }).record;
      record = applyMove(record, 'e8c8', { committedAt: '2026-10-05T00:00:02.000Z' }).record;
      const analysis = analyzeAttacks(new Chess(record.currentFen), record);
      const castling = analysis.findings.find((finding) => finding.motif === 'opposite-side-castling');
      expect(analysis.historyValidation).toBe('validated');
      expect(castling).toBeDefined();
      expect(castling?.state).toBe('candidate');
      expect(castling?.possibleConsequence).toMatch(/no attack plan/i);
    });

    it('does not infer opposite castling from king placement in a FEN without history', () => {
      const fen = '2k5/8/8/8/8/8/8/6K1 w - - 0 1';
      expect(findingsFor(fen, 'opposite-side-castling')).toHaveLength(0);
    });

    it('rejects a mismatched supplied history instead of trusting its attack label', () => {
      let record = createGame({
        id: 'attack-invalid-history',
        initialFen: 'r3k3/8/8/8/8/8/8/4K2R w Kq - 0 1',
        now: '2026-10-05T00:00:00.000Z',
      });
      record = applyMove(record, 'e1g1', { committedAt: '2026-10-05T00:00:01.000Z' }).record;
      record.currentFen = new Chess().fen();
      expect(() => analyzeAttacks(new Chess(record.currentFen), record)).toThrow(/history/i);
    });
  });

  describe('pawn storms, central breaks and Greek Gift candidates', () => {
    it('detects advanced wing pawns near the enemy king as a possible storm', () => {
      const fen = '6k1/8/8/8/5PPP/8/8/K7 w - - 0 1';
      const storm = findingsFor(fen, 'pawn-storm')[0];
      expect(storm).toBeDefined();
      expect(storm?.state).toBe('candidate');
      expect(storm?.possibleConsequence).toMatch(/could support an attack/i);
    });

    it('does not call central-only pawns a pawn storm', () => {
      const fen = '6k1/8/8/8/3PP3/8/8/K7 w - - 0 1';
      expect(findingsFor(fen, 'pawn-storm')).toHaveLength(0);
    });

    it('records a legal central pawn break as a candidate', () => {
      const fen = 'k7/8/8/3p4/4P3/8/8/7K w - - 0 1';
      const breakMove = findingForMove(fen, 'central-break', 'e4d5');
      expect(breakMove).toBeDefined();
      expect(breakMove?.state).toBe('candidate');
      expect(breakMove?.possibleConsequence).toMatch(/not evaluated/i);
    });

    it('rejects a non-central pawn move as a central-break candidate', () => {
      const fen = 'k7/8/8/3p4/8/2P5/8/7K w - - 0 1';
      expect(findingsFor(fen, 'central-break')).toHaveLength(0);
    });

    it('recognizes a legal Bxh7 check only as a Greek Gift candidate', () => {
      const fen = '6k1/7p/8/8/8/3B4/8/4K3 w - - 0 1';
      const gift = findingForMove(fen, 'greek-gift-candidate', 'd3h7');
      expect(gift).toBeDefined();
      expect(gift?.state).toBe('candidate');
      expect(gift?.possibleConsequence).toMatch(/no sacrifice soundness/i);
    });

    it('rejects a bishop capture that does not check as a Greek Gift', () => {
      const fen = 'k7/7p/8/8/8/3B4/8/4K3 w - - 0 1';
      expect(findingForMove(fen, 'greek-gift-candidate', 'd3h7')).toBeUndefined();
    });
  });

  describe('wing and minority attacks', () => {
    it('marks a substantial wing piece concentration as a candidate', () => {
      const fen = '6k1/8/8/8/5PPP/8/6B1/K7 w - - 0 1';
      const wing = findingsFor(fen, 'wing-attack')[0];
      expect(wing).toBeDefined();
      expect(wing?.state).toBe('candidate');
      expect(wing?.possibleConsequence).toMatch(/no move, plan/i);
    });

    it('does not infer a wing attack from three pawns without another attacking piece', () => {
      const fen = '6k1/8/8/8/5PPP/8/8/K7 w - - 0 1';
      expect(findingsFor(fen, 'wing-attack')).toHaveLength(0);
    });

    it('detects a 2-versus-3 queenside pawn minority only as a candidate', () => {
      const fen = '4k3/ppp5/8/8/PP6/8/8/4K3 w - - 0 1';
      const minority = findingsFor(fen, 'minority-attack')[0];
      expect(minority).toBeDefined();
      expect(minority?.state).toBe('candidate');
      expect(minority?.possibleConsequence).toMatch(/may offer a minority-attack plan/i);
    });

    it('rejects the 2-versus-2 near-miss', () => {
      const fen = '4k3/pp6/8/8/PP6/8/8/4K3 w - - 0 1';
      expect(findingsFor(fen, 'minority-attack')).toHaveLength(0);
    });
  });
});
