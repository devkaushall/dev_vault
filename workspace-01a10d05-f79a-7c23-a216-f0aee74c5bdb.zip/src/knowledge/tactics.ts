import { Chess, SQUARES, type Color, type Move, type Piece, type PieceSymbol, type Square } from 'chess.js';
import { uciForMove } from '../domain/chess/position';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeFinding } from './evidence';

/**
 * Tactical recognition deliberately separates board candidates from proved
 * results. chess.js supplies legal moves and terminal-state facts; this module
 * does not estimate positional value or claim engine-strength play.
 */
export const TACTICAL_MOTIFS = [
  'fork',
  'pin',
  'skewer',
  'discovered-attack',
  'double-check',
  'x-ray',
  'battery',
  'remove-defender',
  'deflection',
  'decoy',
  'overload',
  'interference',
  'clearance',
  'zwischenzug',
  'trapped-piece',
  'loose-piece',
  'desperado',
  'sacrifice',
  'underpromotion',
  'promotion-race',
  'perpetual-check',
  'stalemate-resource',
  'zugzwang',
  'windmill',
  'mating-pattern',
] as const;

export type TacticalMotif = (typeof TACTICAL_MOTIFS)[number];
export type TacticalState = 'confirmed' | 'candidate';
export type TacticalMove = { uci: string; san: string };

export type TacticalOutcome = {
  kind: 'checkmate' | 'stalemate' | 'material-gain' | 'position-fact' | 'unproven';
  materialGain?: number;
  deterministic: boolean;
  description: string;
};

export type TacticalContinuation = {
  opponentReply: TacticalMove;
  continuation?: TacticalMove;
  opponentReplyCountAfterContinuation?: number;
  worstMaterialGain?: number;
  terminalOutcome?: 'checkmate' | 'stalemate';
};

export type TacticalLegalLine = {
  candidateMoveLegal: boolean | null;
  forcingMove: TacticalMove | null;
  forcingStatus: 'verified-check' | 'verified-double-check' | 'candidate-only' | 'not-applicable';
  opponentRepliesGenerated: number;
  opponentReplies: TacticalMove[];
  repliesTruncated: boolean;
  continuationSearch: 'all-immediate-replies' | 'bounded' | 'not-performed' | 'not-applicable';
  continuations: TacticalContinuation[];
  outcome: TacticalOutcome;
};

export type TacticalFinding = KnowledgeFinding & {
  state: TacticalState;
  motif: TacticalMotif;
  side: Color;
  triggeringMove?: TacticalMove;
  boardEvidence: KnowledgeEvidence[];
  legalLine: TacticalLegalLine;
  possibleConsequence: string;
};

export type DeferredTacticalMotif = {
  motif: TacticalMotif;
  state: 'deferred';
  reason: string;
};

export type TacticalAnalysis = {
  version: 1;
  positionFen: string;
  sideToMove: Color;
  findings: TacticalFinding[];
  deferredMotifs: DeferredTacticalMotif[];
  limitations: string[];
};

export type TacticalCandidateValidation =
  | { legal: true; move: TacticalMove; afterFen: string }
  | { legal: false; reason: 'invalid-uci' | 'illegal-move'; message: string };

const MATERIAL_VALUE: Record<PieceSymbol, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
};

const LINE_DIRECTIONS: ReadonlyArray<readonly [number, number]> = [
  [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1],
];
const DISPLAY_REPLY_LIMIT = 48;
const MATERIAL_PROOF_FORK_LIMIT = 8;
const MATERIAL_PROOF_REPLY_LIMIT = 64;
const MATERIAL_PROOF_BRANCH_LIMIT = 96;

const DEFERRED_MOTIFS: DeferredTacticalMotif[] = [
  { motif: 'remove-defender', state: 'deferred', reason: 'No validated defender-removal sequence search is implemented yet.' },
  { motif: 'deflection', state: 'deferred', reason: 'No forcing-deflection proof search is implemented yet.' },
  { motif: 'decoy', state: 'deferred', reason: 'No legal-line decoy verification is implemented yet.' },
  { motif: 'overload', state: 'deferred', reason: 'No multi-duty piece/resource analysis is implemented yet.' },
  { motif: 'interference', state: 'deferred', reason: 'No verified line-interference motif search is implemented yet.' },
  { motif: 'clearance', state: 'deferred', reason: 'No clearance-square/line forcing search is implemented yet.' },
  { motif: 'zwischenzug', state: 'deferred', reason: 'No candidate move-order comparison is implemented yet.' },
  { motif: 'trapped-piece', state: 'deferred', reason: 'No complete legal-escape and opponent-response proof is implemented yet.' },
  { motif: 'desperado', state: 'deferred', reason: 'No forced-exchange sequence proof is implemented yet.' },
  { motif: 'sacrifice', state: 'deferred', reason: 'Material investment requires broader forcing-line proof; no engine evaluation is substituted.' },
  { motif: 'perpetual-check', state: 'deferred', reason: 'Repetition/perpetual-check cycles are not searched by this bounded tactical service.' },
  { motif: 'zugzwang', state: 'deferred', reason: 'No all-legal-moves deterioration proof is implemented.' },
  { motif: 'windmill', state: 'deferred', reason: 'No verified repeated discovered-check sequence search is implemented.' },
];

const CONFIRMED_PROVENANCE = [
  { kind: 'board-derivation' as const, source: 'chess.js' as const, method: 'legal move generation and deterministic terminal-state validation' },
];
const CANDIDATE_PROVENANCE = [
  { kind: 'board-derivation' as const, source: 'chess.js' as const, method: 'board geometry and bounded legal-move validation; not an engine evaluation' },
];

function squareAt(file: number, rank: number): Square | null {
  if (file < 0 || file > 7 || rank < 1 || rank > 8) return null;
  return `${String.fromCharCode(97 + file)}${rank}` as Square;
}

function squareCoords(square: Square): [number, number] {
  return [square.charCodeAt(0) - 97, Number(square[1])];
}

function clonePosition(position: Chess): Chess {
  return new Chess(position.fen());
}

function kingSquare(position: Chess, side: Color): Square {
  const square = SQUARES.find((candidate) => {
    const piece = position.get(candidate);
    return piece?.type === 'k' && piece.color === side;
  });
  if (!square) throw new Error(`The ${side === 'w' ? 'white' : 'black'} king is missing from the chess.js position.`);
  return square;
}

function applyLegalMove(position: Chess, move: Move): { position: Chess; move: Move } {
  const after = clonePosition(position);
  const applied = after.move({
    from: move.from,
    to: move.to,
    ...(move.promotion ? { promotion: move.promotion } : {}),
  });
  return { position: after, move: applied };
}

function moveEvidence(move: Move): TacticalMove {
  return { uci: uciForMove(move), san: move.san };
}

function allLegalMoves(position: Chess): Move[] {
  return position.moves({ verbose: true });
}

function pieceValue(piece: Piece | null | undefined): number {
  return piece ? MATERIAL_VALUE[piece.type] : 0;
}

function materialAdvantage(position: Chess, side: Color): number {
  let sideMaterial = 0;
  let otherMaterial = 0;
  for (const square of SQUARES) {
    const piece = position.get(square);
    if (!piece || piece.type === 'k') continue;
    if (piece.color === side) sideMaterial += pieceValue(piece);
    else otherMaterial += pieceValue(piece);
  }
  return sideMaterial - otherMaterial;
}

function makeEvidence(
  id: string,
  description: string,
  squares: Square[],
  values: Record<string, string | number | boolean | readonly string[] | readonly number[]>,
  kind: KnowledgeEvidence['kind'] = 'board-state',
): KnowledgeEvidence {
  return { id, kind, description, squares, values };
}

function createLine(
  overrides: Partial<TacticalLegalLine> = {},
): TacticalLegalLine {
  return {
    candidateMoveLegal: null,
    forcingMove: null,
    forcingStatus: 'not-applicable',
    opponentRepliesGenerated: 0,
    opponentReplies: [],
    repliesTruncated: false,
    continuationSearch: 'not-performed',
    continuations: [],
    outcome: { kind: 'unproven', deterministic: false, description: 'No deterministic material or terminal outcome was established.' },
    ...overrides,
  };
}

function createFinding(args: {
  motif: TacticalMotif;
  state: TacticalState;
  side: Color;
  label: string;
  confidence: number;
  relevance: number;
  boardEvidence: KnowledgeEvidence[];
  legalLine: TacticalLegalLine;
  possibleConsequence: string;
  triggeringMove?: TacticalMove;
}): TacticalFinding {
  const conceptId = `tactics.${args.motif}`;
  const evidence = [...args.boardEvidence];
  if (args.triggeringMove) {
    evidence.push(makeEvidence(
      `${conceptId}.triggering-move.${args.triggeringMove.uci}`,
      `Legally generated move ${args.triggeringMove.san} (${args.triggeringMove.uci}).`,
      [],
      { san: args.triggeringMove.san, uci: args.triggeringMove.uci },
      'move-sequence',
    ));
  }
  if (args.legalLine.opponentRepliesGenerated > 0 || args.legalLine.candidateMoveLegal !== null) {
    evidence.push(makeEvidence(
      `${conceptId}.legal-line.${args.triggeringMove?.uci ?? 'static'}`,
      `Candidate status: ${args.state}; legal replies generated: ${args.legalLine.opponentRepliesGenerated}; outcome: ${args.legalLine.outcome.kind}.`,
      [],
      {
        candidateMoveLegal: args.legalLine.candidateMoveLegal ?? 'not-applicable',
        forcingStatus: args.legalLine.forcingStatus,
        opponentRepliesGenerated: args.legalLine.opponentRepliesGenerated,
        outcome: args.legalLine.outcome.kind,
        deterministic: args.legalLine.outcome.deterministic,
      },
      'move-sequence',
    ));
  }
  const consequence = args.possibleConsequence;
  const finding: TacticalFinding = {
    ...assertKnowledgeFinding({
      conceptId,
      label: args.label,
      evidence,
      confidence: args.confidence,
      relevance: args.relevance,
      possibleImplications: [{ side: args.side, description: consequence }],
      provenance: args.state === 'confirmed' ? CONFIRMED_PROVENANCE : CANDIDATE_PROVENANCE,
    }),
    state: args.state,
    motif: args.motif,
    side: args.side,
    ...(args.triggeringMove ? { triggeringMove: args.triggeringMove } : {}),
    boardEvidence: args.boardEvidence,
    legalLine: args.legalLine,
    possibleConsequence: consequence,
  };
  return finding;
}

function forcingStatus(positionAfterMove: Chess, mover: Color): TacticalLegalLine['forcingStatus'] {
  const defender = positionAfterMove.turn();
  if (!positionAfterMove.isCheck()) return 'candidate-only';
  const attackers = positionAfterMove.attackers(kingSquare(positionAfterMove, defender), mover);
  return attackers.length >= 2 ? 'verified-double-check' : 'verified-check';
}

function repliesFor(position: Chess): { moves: Move[]; display: TacticalMove[]; truncated: boolean } {
  const replies = allLegalMoves(position);
  return {
    moves: replies,
    display: replies.slice(0, DISPLAY_REPLY_LIMIT).map(moveEvidence),
    truncated: replies.length > DISPLAY_REPLY_LIMIT,
  };
}

function analyzeMateAndStalemate(position: Chess, side: Color): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  for (const move of allLegalMoves(position)) {
    const { position: after, move: applied } = applyLegalMove(position, move);
    const lineMove = moveEvidence(applied);
    if (after.isCheckmate()) {
      const evidence = [makeEvidence(
        `tactics.mating-pattern.checkmate.${lineMove.uci}`,
        'The legal move leaves the opposing king in check with no legal reply according to chess.js.',
        [applied.to],
        { legalReplies: 0, checkmate: true },
        'move-sequence',
      )];
      findings.push(createFinding({
        motif: 'mating-pattern',
        state: 'confirmed',
        side,
        label: 'Verified mate in one',
        confidence: 1,
        relevance: 1,
        boardEvidence: evidence,
        triggeringMove: lineMove,
        legalLine: createLine({
          candidateMoveLegal: true,
          forcingMove: lineMove,
          forcingStatus: 'verified-check',
          continuationSearch: 'all-immediate-replies',
          outcome: { kind: 'checkmate', deterministic: true, description: 'Checkmate is confirmed by chess.js; the opponent has no legal reply.' },
        }),
        possibleConsequence: 'The move ends the game by checkmate under chess.js rules.',
      }));
    } else if (after.isStalemate()) {
      const evidence = [makeEvidence(
        `tactics.stalemate-resource.${lineMove.uci}`,
        'The legal move leaves the opponent with no legal move while not in check.',
        [applied.to],
        { legalReplies: 0, stalemate: true },
        'move-sequence',
      )];
      findings.push(createFinding({
        motif: 'stalemate-resource',
        state: 'confirmed',
        side,
        label: 'Verified stalemate resource',
        confidence: 1,
        relevance: 1,
        boardEvidence: evidence,
        triggeringMove: lineMove,
        legalLine: createLine({
          candidateMoveLegal: true,
          forcingMove: lineMove,
          forcingStatus: 'candidate-only',
          continuationSearch: 'all-immediate-replies',
          outcome: { kind: 'stalemate', deterministic: true, description: 'The move immediately draws by stalemate according to chess.js.' },
        }),
        possibleConsequence: 'The move immediately draws by stalemate; whether that is desirable depends on the game result and position.',
      }));
    }
  }
  return findings;
}

function analyzeDiscoveredChecks(position: Chess, side: Color): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  const enemy = opposite(side);
  for (const move of allLegalMoves(position)) {
    const { position: after, move: applied } = applyLegalMove(position, move);
    const moveFact = moveEvidence(applied);
    const discoveredTargets: Array<{ square: Square; source: Square; isKing: boolean }> = [];
    for (const target of SQUARES) {
      const targetPiece = after.get(target);
      if (!targetPiece || targetPiece.color !== enemy || (targetPiece.type !== 'k' && pieceValue(targetPiece) < 3)) continue;
      for (const source of SQUARES) {
        if (source === applied.from || source === applied.to) continue;
        const slider = after.get(source);
        if (!slider || slider.color !== side || !isSliderForTarget(slider.type, source, target)) continue;
        if (position.attackers(target, side).includes(source) || !after.attackers(target, side).includes(source)) continue;
        discoveredTargets.push({ square: target, source, isKing: targetPiece.type === 'k' });
      }
    }
    if (!discoveredTargets.length) continue;
    const replyInfo = repliesFor(after);
    for (const target of discoveredTargets) {
      const isVerifiedCheck = target.isKing && after.isCheck();
      const terminalMate = isVerifiedCheck && after.isCheckmate();
      const boardEvidence = [makeEvidence(
        `tactics.discovered-attack.${moveFact.uci}.${target.square}.${target.source}`,
        target.isKing
          ? 'A previously blocked, unmoved friendly slider now checks the opposing king after the legal move.'
          : 'A previously blocked, unmoved friendly slider now attacks an enemy high-value piece after the legal move; tactical gain remains unproved.',
        [applied.from, applied.to, target.square, target.source],
        {
          newlyAttackingSlider: target.source,
          target: target.square,
          targetType: target.isKing ? 'king' : after.get(target.square)?.type ?? 'unknown',
          legalReplies: replyInfo.moves.length,
          check: isVerifiedCheck,
        },
        'move-sequence',
      )];
      findings.push(createFinding({
        motif: 'discovered-attack',
        state: isVerifiedCheck ? 'confirmed' : 'candidate',
        side,
        label: isVerifiedCheck ? 'Discovered check' : 'Discovered-attack candidate',
        confidence: isVerifiedCheck ? 0.98 : 0.56,
        relevance: isVerifiedCheck ? 0.88 : 0.6,
        boardEvidence,
        triggeringMove: moveFact,
        legalLine: createLine({
          candidateMoveLegal: true,
          forcingMove: moveFact,
          forcingStatus: isVerifiedCheck ? forcingStatus(after, side) : 'candidate-only',
          opponentRepliesGenerated: replyInfo.moves.length,
          opponentReplies: replyInfo.display,
          repliesTruncated: replyInfo.truncated,
          continuationSearch: 'not-performed',
          outcome: terminalMate
            ? { kind: 'checkmate', deterministic: true, description: 'The discovered check is checkmate.' }
            : isVerifiedCheck
              ? { kind: 'position-fact', deterministic: true, description: `A newly uncovered legal check is verified; ${replyInfo.moves.length} legal replies exist.` }
              : { kind: 'unproven', deterministic: false, description: 'A newly uncovered slider attacks a high-value piece, but a forcing continuation or material outcome is not proved.' },
        }),
        possibleConsequence: terminalMate
          ? 'The discovered check ends the game.'
          : isVerifiedCheck
            ? 'The opponent must answer check; no further material outcome is inferred.'
            : 'A high-value piece is newly attacked, but no forcing win is claimed.',
      }));
    }
  }
  return findings;
}

function isSliderForTarget(type: PieceSymbol, source: Square, target: Square): boolean {
  const [sourceFile, sourceRank] = squareCoords(source);
  const [targetFile, targetRank] = squareCoords(target);
  const fileDelta = targetFile - sourceFile;
  const rankDelta = targetRank - sourceRank;
  const diagonal = Math.abs(fileDelta) === Math.abs(rankDelta) && fileDelta !== 0;
  const orthogonal = (fileDelta === 0) !== (rankDelta === 0);
  if (type === 'q') return diagonal || orthogonal;
  if (type === 'b') return diagonal;
  if (type === 'r') return orthogonal;
  return false;
}

function opposite(side: Color): Color {
  return side === 'w' ? 'b' : 'w';
}

function findForkTargets(positionAfterMove: Chess, move: Move, side: Color): Square[] {
  const enemy = opposite(side);
  const targets: Square[] = [];
  for (const square of SQUARES) {
    const piece = positionAfterMove.get(square);
    if (!piece || piece.color !== enemy) continue;
    if (piece.type !== 'k' && pieceValue(piece) < 3) continue;
    if (!positionAfterMove.attackers(square, side).includes(move.to)) continue;
    targets.push(square);
  }
  return targets;
}

function findLegalCapturesTo(position: Chess, targets: Square[]): Map<Square, Move[]> {
  const moves = allLegalMoves(position);
  const result = new Map<Square, Move[]>();
  for (const target of targets) {
    result.set(target, moves.filter((move) => move.to === target && move.isCapture()));
  }
  return result;
}

type MaterialProof = {
  confirmed: boolean;
  complete: boolean;
  minGain?: number;
  replyInfo: ReturnType<typeof repliesFor>;
  continuations: TacticalContinuation[];
  outcome: TacticalOutcome;
};

function proveForkMaterial(
  position: Chess,
  positionAfterMove: Chess,
  move: Move,
  targets: Square[],
): MaterialProof {
  const mover = move.color;
  const replyInfo = repliesFor(positionAfterMove);
  const baseMaterial = materialAdvantage(position, mover);
  if (replyInfo.moves.length > MATERIAL_PROOF_REPLY_LIMIT) {
    return {
      confirmed: false,
      complete: false,
      replyInfo,
      continuations: [],
      outcome: { kind: 'unproven', deterministic: false, description: `Material proof stopped: ${replyInfo.moves.length} legal replies exceeds the ${MATERIAL_PROOF_REPLY_LIMIT}-reply bound.` },
    };
  }
  if (!replyInfo.moves.length) {
    const isMate = positionAfterMove.isCheckmate();
    return {
      confirmed: false,
      complete: true,
      replyInfo,
      continuations: [],
      outcome: isMate
        ? { kind: 'checkmate', deterministic: true, description: 'The move is checkmate; the tactical consequence is represented by the verified mating-pattern finding.' }
        : { kind: 'stalemate', deterministic: true, description: 'The move is stalemate; no fork material claim is added.' },
    };
  }

  let nodes = 0;
  let minGain = Number.POSITIVE_INFINITY;
  let everyReplyWinsMaterial = true;
  let complete = true;
  const continuations: TacticalContinuation[] = [];

  for (const reply of replyInfo.moves) {
    const afterReply = applyLegalMove(positionAfterMove, reply).position;
    const replyLine: TacticalContinuation = { opponentReply: moveEvidence(reply) };
    if (afterReply.isCheckmate()) {
      everyReplyWinsMaterial = false;
      minGain = Number.NEGATIVE_INFINITY;
      continuations.push(replyLine);
      continue;
    }
    const legalCaptures = findLegalCapturesTo(afterReply, targets);
    let bestGain = Number.NEGATIVE_INFINITY;
    let bestContinuation: Move | undefined;
    let bestReplyCount = 0;
    let bestTerminal: TacticalContinuation['terminalOutcome'];

    for (const captureMoves of legalCaptures.values()) {
      for (const continuation of captureMoves) {
        nodes += 1;
        if (nodes > MATERIAL_PROOF_BRANCH_LIMIT) {
          complete = false;
          break;
        }
        const afterContinuation = applyLegalMove(afterReply, continuation).position;
        if (afterContinuation.isCheckmate()) {
          // Checkmate is handled as its own terminal motif; it is not converted
          // into an invented numerical material value for the fork proof.
          continue;
        }
        if (afterContinuation.isStalemate()) {
          const drawMaterialGain = materialAdvantage(afterContinuation, mover) - baseMaterial;
          if (drawMaterialGain > bestGain) {
            bestGain = drawMaterialGain;
            bestContinuation = continuation;
            bestReplyCount = 0;
            bestTerminal = 'stalemate';
          }
          continue;
        }
        const opponentResponses = allLegalMoves(afterContinuation);
        if (opponentResponses.length > MATERIAL_PROOF_REPLY_LIMIT) {
          complete = false;
          continue;
        }
        let worstGain = Number.POSITIVE_INFINITY;
        for (const opponentResponse of opponentResponses) {
          const afterResponse = applyLegalMove(afterContinuation, opponentResponse).position;
          const gain = afterResponse.isCheckmate()
            ? Number.NEGATIVE_INFINITY
            : materialAdvantage(afterResponse, mover) - baseMaterial;
          worstGain = Math.min(worstGain, gain);
        }
        if (opponentResponses.length === 0) {
          // A non-check terminal with no legal moves is stalemate, not a win.
          worstGain = materialAdvantage(afterContinuation, mover) - baseMaterial;
          bestTerminal = 'stalemate';
        }
        if (worstGain > bestGain) {
          bestGain = worstGain;
          bestContinuation = continuation;
          bestReplyCount = opponentResponses.length;
          if (opponentResponses.length > 0) bestTerminal = undefined;
        }
      }
      if (nodes > MATERIAL_PROOF_BRANCH_LIMIT) break;
    }

    if (bestGain === Number.NEGATIVE_INFINITY || !Number.isFinite(bestGain) && bestGain !== Number.POSITIVE_INFINITY) {
      everyReplyWinsMaterial = false;
      minGain = Number.NEGATIVE_INFINITY;
      continuations.push(replyLine);
      continue;
    }
    if (bestGain < 3 || bestTerminal === 'stalemate') everyReplyWinsMaterial = false;
    minGain = Math.min(minGain, bestGain);
    continuations.push({
      ...replyLine,
      ...(bestContinuation ? { continuation: moveEvidence(bestContinuation) } : {}),
      ...(bestContinuation ? { opponentReplyCountAfterContinuation: bestReplyCount } : {}),
      worstMaterialGain: Number.isFinite(bestGain) ? bestGain : undefined,
      ...(bestTerminal ? { terminalOutcome: bestTerminal } : {}),
    });
    if (!complete) break;
  }

  const confirmed = complete && everyReplyWinsMaterial && continuations.length === replyInfo.moves.length;
  if (!complete) {
    return {
      confirmed: false,
      complete: false,
      minGain: Number.isFinite(minGain) ? minGain : undefined,
      replyInfo,
      continuations,
      outcome: { kind: 'unproven', deterministic: false, description: 'The bounded reply/continuation proof was incomplete; no forced material claim is made.' },
    };
  }
  return {
    confirmed,
    complete: true,
    minGain: Number.isFinite(minGain) ? minGain : undefined,
    replyInfo,
    continuations,
    outcome: confirmed
      ? { kind: 'material-gain', materialGain: minGain, deterministic: true, description: `A material gain of at least ${minGain} point(s) survives every legal immediate reply and the tested recapture response.` }
      : { kind: 'unproven', deterministic: false, description: 'No material gain of at least a minor piece was proved across every legal reply.' },
  };
}

function analyzeForks(position: Chess, side: Color): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  let proofCount = 0;
  for (const move of allLegalMoves(position)) {
    const { position: after, move: applied } = applyLegalMove(position, move);
    const targets = findForkTargets(after, applied, side);
    if (targets.length < 2) continue;
    const moveFact = moveEvidence(applied);
    const replies = repliesFor(after);
    let proof: MaterialProof;
    if (proofCount < MATERIAL_PROOF_FORK_LIMIT) {
      proof = proveForkMaterial(position, after, applied, targets);
      proofCount += 1;
    } else {
      proof = {
        confirmed: false,
        complete: false,
        replyInfo: replies,
        continuations: [],
        outcome: { kind: 'unproven', deterministic: false, description: `Material proof bound reached (${MATERIAL_PROOF_FORK_LIMIT} fork candidates per position).` },
      };
    }
    const checkStatus = forcingStatus(after, side);
    const candidateState: TacticalState = proof.confirmed ? 'confirmed' : 'candidate';
    const evidence = [makeEvidence(
      `tactics.fork.targets.${moveFact.uci}`,
      `The moved piece geometrically attacks ${targets.length} enemy high-value target(s); the response tree is separately checked for legal captures and durable material gain.`,
      [applied.from, applied.to, ...targets],
      {
        targetSquares: targets,
        targetCount: targets.length,
        legalReplies: proof.replyInfo.moves.length,
        proofComplete: proof.complete,
        deterministicMaterialOutcome: proof.confirmed,
      },
      'move-sequence',
    )];
    findings.push(createFinding({
      motif: 'fork',
      state: candidateState,
      side,
      label: proof.confirmed ? 'Verified material fork' : 'Fork candidate',
      confidence: proof.confirmed ? 0.96 : 0.55,
      relevance: proof.confirmed ? 0.95 : 0.58,
      boardEvidence: evidence,
      triggeringMove: moveFact,
      legalLine: createLine({
        candidateMoveLegal: true,
        forcingMove: moveFact,
        forcingStatus: checkStatus,
        opponentRepliesGenerated: proof.replyInfo.moves.length,
        opponentReplies: proof.replyInfo.display,
        repliesTruncated: proof.replyInfo.truncated,
        continuationSearch: proof.complete ? 'all-immediate-replies' : 'bounded',
        continuations: proof.continuations,
        outcome: proof.outcome,
      }),
      possibleConsequence: proof.confirmed
        ? `At least ${proof.minGain} point(s) of material are proved to survive the searched immediate replies; this is not an engine evaluation.`
        : 'The move attacks multiple targets, but the bounded legal-line search did not prove a durable material gain.',
    }));
  }
  return findings;
}

function analyzeLoosePieces(position: Chess, side: Color): TacticalFinding[] {
  const enemy = opposite(side);
  const findings: TacticalFinding[] = [];
  const legal = allLegalMoves(position);
  const enemySquares = SQUARES.filter((square) => {
    const piece = position.get(square);
    return Boolean(piece && piece.color === enemy && piece.type !== 'k' && pieceValue(piece) >= 3);
  });
  for (const square of enemySquares) {
    const target = position.get(square);
    if (!target) continue;
    const attackers = position.attackers(square, side);
    const defenders = position.attackers(square, enemy);
    if (!attackers.length || defenders.length) continue;
    const captures = legal.filter((move) => move.to === square && move.isCapture());
    if (!captures.length) continue;
    let best: {
      move: Move;
      gain: number;
      replies: ReturnType<typeof repliesFor>;
      continuation: TacticalContinuation[];
      complete: boolean;
      allBranchesMate: boolean;
    } | undefined;
    const baselineMaterial = materialAdvantage(position, side);

    for (const capture of captures) {
      const afterCapture = applyLegalMove(position, capture).position;
      const replyInfo = repliesFor(afterCapture);
      if (replyInfo.moves.length > MATERIAL_PROOF_REPLY_LIMIT) continue;
      let visitedBranches = 0;
      let minimumGain = Number.POSITIVE_INFINITY;
      let everyBranchProven = true;
      let allBranchesMate = replyInfo.moves.length === 0 ? afterCapture.isCheckmate() : true;
      let complete = true;
      const branches: TacticalContinuation[] = [];

      if (afterCapture.isStalemate()) {
        everyBranchProven = false;
        minimumGain = Number.NEGATIVE_INFINITY;
      } else if (afterCapture.isCheckmate()) {
        minimumGain = Number.POSITIVE_INFINITY;
      } else {
        for (const reply of replyInfo.moves) {
          const afterReply = applyLegalMove(afterCapture, reply).position;
          const branch: TacticalContinuation = { opponentReply: moveEvidence(reply) };
          if (afterReply.isCheckmate() || afterReply.isStalemate()) {
            everyBranchProven = false;
            minimumGain = Number.NEGATIVE_INFINITY;
            branches.push({ ...branch, terminalOutcome: afterReply.isCheckmate() ? 'checkmate' : 'stalemate' });
            continue;
          }
          const continuations = allLegalMoves(afterReply);
          if (continuations.length > MATERIAL_PROOF_REPLY_LIMIT) {
            complete = false;
            everyBranchProven = false;
            branches.push(branch);
            break;
          }
          let bestBranchGain = Number.NEGATIVE_INFINITY;
          let bestContinuation: Move | undefined;
          let bestResponseCount = 0;
          let bestTerminal: TacticalContinuation['terminalOutcome'];
          let branchSawMate = false;
          for (const continuation of continuations) {
            visitedBranches += 1;
            if (visitedBranches > MATERIAL_PROOF_BRANCH_LIMIT * 5) {
              complete = false;
              everyBranchProven = false;
              break;
            }
            const afterContinuation = applyLegalMove(afterReply, continuation).position;
            if (afterContinuation.isCheckmate()) {
              branchSawMate = true;
              if (Number.POSITIVE_INFINITY > bestBranchGain) {
                bestBranchGain = Number.POSITIVE_INFINITY;
                bestContinuation = continuation;
                bestResponseCount = 0;
                bestTerminal = 'checkmate';
              }
              continue;
            }
            if (afterContinuation.isStalemate()) continue;
            const responses = allLegalMoves(afterContinuation);
            if (responses.length > MATERIAL_PROOF_REPLY_LIMIT) {
              complete = false;
              continue;
            }
            let worstGain = Number.POSITIVE_INFINITY;
            for (const response of responses) {
              const afterResponse = applyLegalMove(afterContinuation, response).position;
              const gain = afterResponse.isCheckmate()
                ? Number.NEGATIVE_INFINITY
                : materialAdvantage(afterResponse, side) - baselineMaterial;
              worstGain = Math.min(worstGain, gain);
            }
            if (!responses.length) worstGain = Number.NEGATIVE_INFINITY;
            if (worstGain > bestBranchGain) {
              bestBranchGain = worstGain;
              bestContinuation = continuation;
              bestResponseCount = responses.length;
              bestTerminal = undefined;
            }
          }
          if (!complete && visitedBranches > MATERIAL_PROOF_BRANCH_LIMIT * 5) break;
          if (!bestContinuation || (bestBranchGain < 1 && bestBranchGain !== Number.POSITIVE_INFINITY)) {
            everyBranchProven = false;
            minimumGain = Number.NEGATIVE_INFINITY;
            branches.push(branch);
            continue;
          }
          if (bestTerminal !== 'checkmate') allBranchesMate = false;
          if (Number.isFinite(bestBranchGain)) minimumGain = Math.min(minimumGain, bestBranchGain);
          branches.push({
            ...branch,
            continuation: moveEvidence(bestContinuation),
            opponentReplyCountAfterContinuation: bestResponseCount,
            ...(Number.isFinite(bestBranchGain) ? { worstMaterialGain: bestBranchGain } : {}),
            ...(bestTerminal ? { terminalOutcome: bestTerminal } : {}),
          });
          if (branchSawMate && bestTerminal !== 'checkmate') allBranchesMate = false;
        }
      }

      const confirmed = complete && everyBranchProven && (minimumGain >= 1 || minimumGain === Number.POSITIVE_INFINITY);
      const gain = allBranchesMate && confirmed ? Number.POSITIVE_INFINITY : minimumGain;
      if (!best || (confirmed && !best.complete) || gain > best.gain) {
        best = { move: capture, gain, replies: replyInfo, continuation: branches, complete, allBranchesMate };
      }
    }
    if (!best) continue;
    const confirmed = best.complete && (best.gain >= 1 || best.allBranchesMate) && best.continuation.length === best.replies.moves.length;
    const moveFact = moveEvidence(best.move);
    const evidence = [makeEvidence(
      `tactics.loose-piece.${square}`,
      `An enemy ${target.type} on ${square} is attacked, has no geometric friendly defender, and at least one legal capture exists. The proof tests every immediate reply, a legal continuation, and the resulting opponent replies within bounds.`,
      [square, ...attackers],
      { piece: target.type, attackers, defenders, legalCaptures: captures.length, proofComplete: best.complete, minimumTestedGain: Number.isFinite(best.gain) ? best.gain : best.allBranchesMate ? 'checkmate' : 'unproven' },
      'move-sequence',
    )];
    findings.push(createFinding({
      motif: 'loose-piece',
      state: confirmed ? 'confirmed' : 'candidate',
      side,
      label: confirmed ? 'Verified hanging-piece capture' : 'Loose-piece candidate',
      confidence: confirmed ? 0.94 : 0.58,
      relevance: confirmed ? 0.88 : 0.61,
      boardEvidence: evidence,
      triggeringMove: moveFact,
      legalLine: createLine({
        candidateMoveLegal: true,
        forcingMove: moveFact,
        forcingStatus: forcingStatus(applyLegalMove(position, best.move).position, side),
        opponentRepliesGenerated: best.replies.moves.length,
        opponentReplies: best.replies.display,
        repliesTruncated: best.replies.truncated,
        continuationSearch: best.complete ? 'all-immediate-replies' : 'bounded',
        continuations: best.continuation,
        outcome: confirmed
          ? best.allBranchesMate
            ? { kind: 'checkmate', deterministic: true, description: 'Every tested opponent reply has a legal continuation to checkmate.' }
            : { kind: 'material-gain', ...(Number.isFinite(best.gain) ? { materialGain: best.gain } : {}), deterministic: true, description: `A legal capture, continuation, and tested opponent responses retain a material gain of at least ${best.gain} point(s).` }
          : { kind: 'unproven', deterministic: false, description: 'The attacked piece has a legal capture, but the bounded continuation tree does not prove a durable gain.' },
      }),
      possibleConsequence: confirmed
        ? best.allBranchesMate
          ? 'Every tested immediate reply permits a legal continuation to checkmate; the terminal result is proved.'
          : `A legal capture and continuation preserve at least ${best.gain} point(s) through the tested replies; this is not an engine evaluation.`
        : 'The piece appears loose, but no durable gain is established; it may be tactically defended or the bounded line is incomplete.',
    }));
  }
  return findings;
}

function analyzeDiscoveredAndDoubleChecks(position: Chess, side: Color): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  const enemy = opposite(side);
  for (const move of allLegalMoves(position)) {
    const { position: after, move: applied } = applyLegalMove(position, move);
    if (!after.isCheck()) continue;
    const king = kingSquare(after, enemy);
    const checkSources = after.attackers(king, side);
    if (checkSources.length < 2) continue;
    const replyInfo = repliesFor(after);
    const allRepliesAreKingMoves = replyInfo.moves.every((reply) => reply.piece === 'k');
    const doubleCheckVerified = checkSources.length >= 2 && allRepliesAreKingMoves && (replyInfo.moves.length > 0 || after.isCheckmate());
    const moveFact = moveEvidence(applied);
    const evidence = [makeEvidence(
      `tactics.double-check.${moveFact.uci}`,
      `Two or more distinct friendly pieces legally check the opposing king; ${replyInfo.moves.length} legal reply/replies are generated, all by the king: ${allRepliesAreKingMoves}.`,
      [applied.from, applied.to, king, ...checkSources],
      { checkingSources: checkSources, legalReplies: replyInfo.moves.length, allRepliesAreKingMoves, checkmate: after.isCheckmate() },
      'move-sequence',
    )];
    findings.push(createFinding({
      motif: 'double-check',
      state: doubleCheckVerified ? 'confirmed' : 'candidate',
      side,
      label: doubleCheckVerified ? 'Verified double check' : 'Double-check candidate',
      confidence: doubleCheckVerified ? 0.98 : 0.64,
      relevance: 0.94,
      boardEvidence: evidence,
      triggeringMove: moveFact,
      legalLine: createLine({
        candidateMoveLegal: true,
        forcingMove: moveFact,
        forcingStatus: 'verified-double-check',
        opponentRepliesGenerated: replyInfo.moves.length,
        opponentReplies: replyInfo.display,
        repliesTruncated: replyInfo.truncated,
        continuationSearch: 'not-performed',
        outcome: after.isCheckmate()
          ? { kind: 'checkmate', deterministic: true, description: 'The double check is checkmate.' }
          : { kind: 'position-fact', deterministic: true, description: `Double check is verified. All ${replyInfo.moves.length} legal replies move the king; no material result is inferred.` },
      }),
      possibleConsequence: after.isCheckmate() ? 'The double check ends the game.' : 'Only legal king replies are available to the checked side; no material gain is inferred.',
    }));
  }
  return findings;
}

function analyzeLineCandidates(position: Chess): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  for (const side of ['w', 'b'] as const) {
    for (const source of SQUARES) {
      const slider = position.get(source);
      if (!slider || slider.color !== side || !['b', 'r', 'q'].includes(slider.type)) continue;
      const [sourceFile, sourceRank] = squareCoords(source);
      for (const [fileStep, rankStep] of LINE_DIRECTIONS) {
        if (!isSliderForDirection(slider.type, fileStep, rankStep)) continue;
        const ray: Square[] = [];
        let file = sourceFile + fileStep;
        let rank = sourceRank + rankStep;
        while (true) {
          const square = squareAt(file, rank);
          if (!square) break;
          ray.push(square);
          file += fileStep;
          rank += rankStep;
        }
        const occupied = ray.filter((square) => position.get(square));
        if (!occupied.length) continue;
        const firstSquare = occupied[0];
        const first = position.get(firstSquare)!;
        const secondSquare = occupied[1];
        const second = secondSquare ? position.get(secondSquare) : undefined;

        // Two allied compatible sliders on the same unobstructed ray are a battery candidate.
        if (first.color === side && isSliderForDirection(first.type, fileStep, rankStep)) {
          const key = [source, firstSquare].sort().join(':');
          const already = findings.some((finding) => finding.motif === 'battery' && finding.evidence.some((item) => item.id === `tactics.battery.${key}`));
          if (!already) {
            const boardEvidence = [makeEvidence(
              `tactics.battery.${key}`,
              'Two friendly compatible line pieces share an unobstructed ray; no forcing battery outcome is inferred.',
              [source, firstSquare],
              { pieceTypes: [slider.type, first.type], rayDirection: [fileStep, rankStep] },
            )];
            findings.push(createFinding({
              motif: 'battery', state: 'candidate', side, label: 'Battery candidate', confidence: 0.49, relevance: 0.42,
              boardEvidence, legalLine: createLine(),
              possibleConsequence: 'The aligned line pieces may coordinate, but no forcing move or material outcome is proved.',
            }));
          }
          continue;
        }
        if (!second || !secondSquare || first.color !== opposite(side) || second.color !== opposite(side) || first.type === 'k') continue;
        const values = { frontPiece: first.type, rearPiece: second.type, frontSquare: firstSquare, rearSquare: secondSquare };
        if (second.type === 'k' || pieceValue(second) > pieceValue(first)) {
          const boardEvidence = [makeEvidence(
            `tactics.pin.${source}.${firstSquare}.${secondSquare}`,
            'A friendly slider attacks the first enemy blocker, with a more valuable enemy piece or king behind it on the same ray.',
            [source, firstSquare, secondSquare],
            values,
          )];
          findings.push(createFinding({
            motif: 'pin', state: 'candidate', side, label: 'Pin candidate', confidence: 0.57, relevance: 0.55,
            boardEvidence, legalLine: createLine(),
            possibleConsequence: 'The front piece is geometrically constrained by a more valuable unit behind it; tactical consequences are unproven.',
          }));
        } else if (pieceValue(first) > pieceValue(second)) {
          const boardEvidence = [makeEvidence(
            `tactics.skewer.${source}.${firstSquare}.${secondSquare}`,
            'A friendly slider attacks a higher-value enemy blocker with a lower-value enemy piece behind it on the same ray.',
            [source, firstSquare, secondSquare],
            values,
          )];
          findings.push(createFinding({
            motif: 'skewer', state: 'candidate', side, label: 'Skewer candidate', confidence: 0.54, relevance: 0.53,
            boardEvidence, legalLine: createLine(),
            possibleConsequence: 'If the front piece moves, the rear piece may become exposed; no forced move or gain is proved.',
          }));
        }

        if ((pieceValue(second) >= 3 || second.type === 'k') && !findings.some((finding) => finding.motif === 'x-ray' && finding.evidence.some((item) => item.id === `tactics.x-ray.${source}.${firstSquare}.${secondSquare}`))) {
          const boardEvidence = [makeEvidence(
            `tactics.x-ray.${source}.${firstSquare}.${secondSquare}`,
            'A friendly slider has a compatible geometric ray through one enemy blocker toward another enemy target.',
            [source, firstSquare, secondSquare],
            values,
          )];
          findings.push(createFinding({
            motif: 'x-ray', state: 'candidate', side, label: 'X-ray candidate', confidence: 0.46, relevance: 0.4,
            boardEvidence, legalLine: createLine(),
            possibleConsequence: 'An x-ray relation is geometrically present, but no forced target gain is proved.',
          }));
        }
      }
    }
  }
  return findings;
}

function isSliderForDirection(type: PieceSymbol, fileStep: number, rankStep: number): boolean {
  const diagonal = fileStep !== 0 && rankStep !== 0;
  return type === 'q' || (type === 'b' && diagonal) || (type === 'r' && !diagonal);
}

function analyzeUnderpromotions(position: Chess, side: Color): TacticalFinding[] {
  const findings: TacticalFinding[] = [];
  for (const move of allLegalMoves(position)) {
    if (!move.promotion || move.promotion === 'q') continue;
    const after = applyLegalMove(position, move).position;
    const moveFact = moveEvidence(move);
    const replies = repliesFor(after);
    const mate = after.isCheckmate();
    const evidence = [makeEvidence(
      `tactics.underpromotion.${moveFact.uci}`,
      mate
        ? `The legal ${move.promotion}-promotion produces checkmate.`
        : `The legal pawn promotion chooses ${move.promotion} rather than a queen; no superiority over other promotions is established.`,
      [move.from, move.to],
      { promotion: move.promotion, checkmate: mate, legalReplies: replies.moves.length },
      'move-sequence',
    )];
    findings.push(createFinding({
      motif: 'underpromotion',
      state: mate ? 'confirmed' : 'candidate',
      side,
      label: mate ? 'Verified mating underpromotion' : 'Underpromotion candidate',
      confidence: mate ? 1 : 0.6,
      relevance: mate ? 1 : 0.52,
      boardEvidence: evidence,
      triggeringMove: moveFact,
      legalLine: createLine({
        candidateMoveLegal: true,
        forcingMove: moveFact,
        forcingStatus: after.isCheck() ? forcingStatus(after, side) : 'candidate-only',
        opponentRepliesGenerated: replies.moves.length,
        opponentReplies: replies.display,
        repliesTruncated: replies.truncated,
        continuationSearch: 'not-performed',
        outcome: mate
          ? { kind: 'checkmate', deterministic: true, description: 'The legal underpromotion is checkmate.' }
          : { kind: 'unproven', deterministic: false, description: 'Underpromotion is legal; no material/positional superiority to queen promotion is inferred.' },
      }),
      possibleConsequence: mate ? 'The underpromotion delivers verified checkmate.' : 'The underpromotion is legal, but whether it is better than queen promotion is not evaluated.',
    }));
  }
  return findings;
}

function isPassedPawn(position: Chess, square: Square, side: Color): boolean {
  const [file, rank] = squareCoords(square);
  for (let fileDelta = -1; fileDelta <= 1; fileDelta += 1) {
    const adjacentFile = file + fileDelta;
    if (adjacentFile < 0 || adjacentFile > 7) continue;
    for (let rankIndex = 1; rankIndex <= 8; rankIndex += 1) {
      const otherSquare = squareAt(adjacentFile, rankIndex);
      if (!otherSquare) continue;
      const piece = position.get(otherSquare);
      if (!piece || piece.color === side || piece.type !== 'p') continue;
      if (side === 'w' ? rankIndex > rank : rankIndex < rank) return false;
    }
  }
  return true;
}

function analyzePromotionRaces(position: Chess): TacticalFinding[] {
  const whitePawns: Square[] = [];
  const blackPawns: Square[] = [];
  for (const square of SQUARES) {
    const piece = position.get(square);
    if (piece?.type !== 'p' || !isPassedPawn(position, square, piece.color)) continue;
    (piece.color === 'w' ? whitePawns : blackPawns).push(square);
  }
  if (!whitePawns.length || !blackPawns.length) return [];
  const fastest = (squares: Square[], side: Color): { square: Square; plies: number } => {
    const steps = (square: Square) => side === 'w' ? 8 - Number(square[1]) : Number(square[1]) - 1;
    const square = squares.slice().sort((a, b) => steps(a) - steps(b))[0];
    return { square, plies: steps(square) };
  };
  const white = fastest(whitePawns, 'w');
  const black = fastest(blackPawns, 'b');
  const boardEvidence = [makeEvidence(
    'tactics.promotion-race.passed-pawns',
    'Both sides have at least one passed pawn; promotion distance is a geometry-based candidate only and does not account for every king/piece interaction.',
    [white.square, black.square],
    { whitePromotionPlies: white.plies, blackPromotionPlies: black.plies },
  )];
  return [createFinding({
    motif: 'promotion-race', state: 'candidate', side: position.turn(), label: 'Promotion-race candidate', confidence: 0.45, relevance: 0.42,
    boardEvidence, legalLine: createLine(),
    possibleConsequence: `Passed pawns on ${white.square} and ${black.square} create a possible race (${white.plies} and ${black.plies} forward steps before promotion, ignoring checks and blockers). No winner is predicted.`,
  })];
}

/** Analyze the current position without mutating the supplied chess.js board. */
export function analyzeTactics(position: Chess): TacticalAnalysis {
  const source = clonePosition(position);
  const side = source.turn();
  const findings = [
    ...analyzeMateAndStalemate(source, side),
    ...analyzeDiscoveredChecks(source, side),
    ...analyzeDiscoveredAndDoubleChecks(source, side),
    ...analyzeForks(source, side),
    ...analyzeLoosePieces(source, side),
    ...analyzeLineCandidates(source),
    ...analyzeUnderpromotions(source, side),
    ...analyzePromotionRaces(source),
  ];
  return {
    version: 1,
    positionFen: source.fen(),
    sideToMove: side,
    findings: deduplicateFindings(findings),
    deferredMotifs: DEFERRED_MOTIFS.map((entry) => ({ ...entry })),
    limitations: [
      'Confirmed material gains are limited to a bounded reply tree: fork continuations capture an attacked target and test immediate recaptures; loose-piece captures test one legal continuation and the opponent response. This is not a search to game-theoretic outcome.',
      'Pin, skewer, battery, and x-ray are geometry-based candidates only; their legal tactical consequences are not proven.',
      'Promotion-race distance ignores checks, capture choices, and king/piece interference; it is only a candidate.',
      'A legal non-mating underpromotion is a candidate, not a claim that it is superior to queen promotion.',
      'No engine evaluation, opponent-intent inference, or positional-value estimate is used.',
    ],
  };
}

function deduplicateFindings(findings: TacticalFinding[]): TacticalFinding[] {
  const seen = new Set<string>();
  return findings.filter((finding) => {
    const key = `${finding.motif}|${finding.side}|${finding.triggeringMove?.uci ?? finding.boardEvidence.map((item) => item.id).join(',')}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Validate a caller-supplied UCI candidate with chess.js and leave the source position unchanged. */
export function validateTacticalCandidate(position: Chess, uci: string): TacticalCandidateValidation {
  const match = /^([a-h][1-8])([a-h][1-8])([qrbn])?$/i.exec(uci.trim());
  if (!match) return { legal: false, reason: 'invalid-uci', message: 'Candidate is not valid UCI coordinate notation.' };
  const from = match[1].toLowerCase() as Square;
  const to = match[2].toLowerCase() as Square;
  const promotion = match[3]?.toLowerCase() as PieceSymbol | undefined;
  const trial = clonePosition(position);
  try {
    const move = trial.move({ from, to, ...(promotion ? { promotion } : {}) });
    return { legal: true, move: moveEvidence(move), afterFen: trial.fen() };
  } catch {
    return { legal: false, reason: 'illegal-move', message: 'Candidate is not legal in this position according to chess.js.' };
  }
}
