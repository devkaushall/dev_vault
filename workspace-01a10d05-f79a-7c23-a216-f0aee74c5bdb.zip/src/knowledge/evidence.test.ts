import { describe, expect, it } from 'vitest';
import { assertChessEvidence, confidenceLevel, createChessEvidence, stableEvidenceId, type BuiltinEvidenceType, type ChessEvidence } from './evidence';

const evidenceInput = {
  type: 'tactic' as const,
  subtype: 'fork',
  ply: 7,
  position: { fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', moveNumber: 4 },
  facts: [{ key: 'motif', value: 'fork' }],
  source: 'tactics-detector',
  createdBy: { analyser: 'tactics-detector', version: '1.0.0' },
};

function makeEvidence(): ChessEvidence {
  const base = {
    schemaVersion: 1 as const,
    ...evidenceInput,
    evidenceId: stableEvidenceId(evidenceInput),
    status: 'candidate' as const,
    confidence: 'medium' as const,
    side: 'white' as const,
    references: [{ kind: 'detector' as const, id: 'tactics.fork' }],
    explanation: { whatHappened: 'A legal move may attack multiple targets.', concept: 'fork' },
  };
  return assertChessEvidence(base);
}

describe('versioned chess evidence contract', () => {
  it('creates a deterministic, source-bound ID for an equivalent ordered evidence payload', () => {
    expect(stableEvidenceId(evidenceInput)).toBe(stableEvidenceId(structuredClone(evidenceInput)));
    expect(stableEvidenceId(evidenceInput)).toMatch(/^ev_tactic_7_[a-z0-9]+$/);
    expect(stableEvidenceId({ ...evidenceInput, facts: [{ key: 'motif', value: 'pin' }] })).not.toBe(stableEvidenceId(evidenceInput));
  });

  it('uses the shared factory to generate an exact stable ID and JSON-safe contract record', () => {
    const created = createChessEvidence({
      ...evidenceInput,
      status: 'candidate',
      confidence: 'medium',
      side: 'white',
      references: [{ kind: 'detector', id: 'tactics.fork' }],
      explanation: { whatHappened: 'A candidate fork cue is recorded.' },
    });
    expect(created.evidenceId).toBe(stableEvidenceId(evidenceInput));
    expect(assertChessEvidence(JSON.parse(JSON.stringify(created)) as ChessEvidence)).toEqual(created);
  });

  it('validates a provenance-aware, serializable evidence record without inserting engine data', () => {
    const value = makeEvidence();
    expect(value).toMatchObject({ schemaVersion: 1, status: 'candidate', confidence: 'medium', source: 'tactics-detector' });
    const restored = JSON.parse(JSON.stringify(value)) as ChessEvidence;
    expect(assertChessEvidence(restored)).toEqual(value);
    expect(Object.hasOwn(restored, 'engine')).toBe(false);
  });

  it('supports all requested built-in detector evidence types', () => {
    const types: BuiltinEvidenceType[] = [
      'opening', 'strategy', 'pawn_structure', 'tactic', 'attack', 'defence', 'endgame',
      'king_safety', 'material', 'move_classification', 'transition',
    ];
    const records = types.map((type) => createChessEvidence({
      ...evidenceInput,
      type,
      subtype: `${type}-fixture`,
      status: 'candidate',
      confidence: 'low',
      side: 'white',
      references: [],
      createdBy: { analyser: `${type}-detector`, version: '1.0.0' },
    }));
    expect(records.map((record) => record.type)).toEqual(types);
    expect(records.every((record) => record.schemaVersion === 1)).toBe(true);
  });

  it('accepts namespaced future evidence types without requiring engine data', () => {
    const future = createChessEvidence({
      ...evidenceInput,
      type: 'engine.stockfish',
      subtype: 'principal-variation',
      status: 'deferred',
      confidence: 'low',
      side: 'white',
      references: [],
      createdBy: { analyser: 'engine-adapter', version: 'future' },
    });
    expect(future.type).toBe('engine.stockfish');
    expect(future.schemaVersion).toBe(1);
    expect(future.engine).toBeUndefined();
    expect(assertChessEvidence(JSON.parse(JSON.stringify(future)) as ChessEvidence)).toEqual(future);
  });

  it('rejects malformed position, missing provenance, unsupported version and non-serializable facts', () => {
    expect(() => assertChessEvidence({ ...makeEvidence(), schemaVersion: 2 } as unknown as ChessEvidence)).toThrow(/schema/i);
    expect(() => assertChessEvidence({ ...makeEvidence(), type: 'unknown' as unknown as ChessEvidence['type'] })).toThrow(/type/i);
    expect(() => assertChessEvidence({ ...makeEvidence(), position: { fen: 'not a FEN', moveNumber: 1 } })).toThrow(/serializable/i);
    expect(() => assertChessEvidence({ ...makeEvidence(), createdBy: { analyser: '', version: '' } })).toThrow(/provenance/i);
    expect(() => assertChessEvidence({ ...makeEvidence(), facts: [{ key: 'unsafe', value: [1, 2] as unknown as string[] }] })).toThrow(/strings/i);
  });

  it('maps numeric detector confidence to evidence-detection confidence, not chess strength', () => {
    expect(confidenceLevel(1)).toBe('high');
    expect(confidenceLevel(0.9)).toBe('high');
    expect(confidenceLevel(0.75)).toBe('medium');
    expect(confidenceLevel(0.6)).toBe('medium');
    expect(confidenceLevel(0.59)).toBe('low');
    expect(confidenceLevel(0.4)).toBe('low');
    expect(() => confidenceLevel(1.1)).toThrow(RangeError);
  });
});
