import { Chess, SQUARES, type Color, type Move, type PieceSymbol, type Square } from 'chess.js';
import { positionKey, uciForMove } from '../domain/chess/position';
import type { GameRecord } from '../domain/chess/types';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeEvidenceValue, type KnowledgeFinding } from './evidence';
import { analyzeTactics, type TacticalAnalysis, type TacticalLegalLine, type TacticalMove } from './tactics';

export const ENDGAME_MOTIFS = [
  'pawn-ending',
  'opposition',
  'key-squares',
  'square-rule',
  'triangulation',
  'outflanking',
  'reserve-tempo',
  'breakthrough',
  'rook-ending',
  'lucena',
  'philidor',
  'vancura',
  'minor-piece-ending',
  'opposite-coloured-bishops',
  'queen-ending',
  'basic-mating-ending',
  'fortress',
  'perpetual',
  'stalemate-resource',
] as const;

export type EndgameMotif = (typeof ENDGAME_MOTIFS)[number];
export type EndgameState = 'confirmed' | 'candidate';

export type EndgameFinding = KnowledgeFinding & {
  state: EndgameState;
  motif: EndgameMotif;
  side?: Color;
  boardEvidence: KnowledgeEvidence[];
  triggeringMove?: TacticalMove;
  legalLine?: TacticalLegalLine;
  possibleConsequence: string;
};

export type DeferredEndgameMotif = {
  motif: EndgameMotif;
  state: 'deferred';
  reason: string;
};

export type EndgamePhase =
  | 'pawn-ending'
  | 'rook-ending'
  | 'minor-piece-ending'
  | 'queen-ending'
  | 'basic-mating-material'
  | 'bare-kings'
  | 'mixed-or-middlegame';

export type EndgameAnalysis = {
  version: 1;
  positionFen: string;
  sideToMove: Color;
  phase: EndgamePhase;
  historyValidation: 'not-provided' | 'validated';
  findings: EndgameFinding[];
  deferredMotifs: DeferredEndgameMotif[];
  limitations: string[];
};

type Counts = Record<Color, Record<PieceSymbol, number>>;
type ReplayMove = { side: Color; uci: string; san: string; givesCheck: boolean; ply: number };
type ReplayHistory = { keys: string[]; moves: ReplayMove[] };

const MATERIAL_PIECES: PieceSymbol[] = ['p', 'n', 'b', 'r', 'q'];
const BOARD_PROVENANCE = [
  { kind: 'board-derivation' as const, source: 'chess.js' as const, method: 'material inventory, legal move replay, and explicit board-square conditions; no engine evaluation' },
];
const HISTORY_PROVENANCE = [
  { kind: 'board-derivation' as const, source: 'chess.js' as const, method: 'legal replay of supplied GameRecord plus repeated position/check sequence validation' },
];
const STATIC_DEFERRED: DeferredEndgameMotif[] = [
  { motif: 'triangulation', state: 'deferred', reason: 'No legal tempo-changing king-cycle proof is implemented.' },
  { motif: 'outflanking', state: 'deferred', reason: 'No complete king-route/opposition comparison is implemented.' },
  { motif: 'reserve-tempo', state: 'deferred', reason: 'No move-order proof establishes that a pawn/king tempo decides the position.' },
  { motif: 'vancura', state: 'deferred', reason: 'No sufficiently specific rook-pawn/side-check structure recognizer is implemented; the name is withheld.' },
  { motif: 'fortress', state: 'deferred', reason: 'No fortress proof is implemented; static material and square patterns cannot prove the opponent has no breakthrough.' },
];

function opposite(side: Color): Color {
  return side === 'w' ? 'b' : 'w';
}

function squareAt(file: number, rank: number): Square | null {
  if (file < 0 || file > 7 || rank < 1 || rank > 8) return null;
  return `${String.fromCharCode(97 + file)}${rank}` as Square;
}

function squareCoords(square: Square): [number, number] {
  return [square.charCodeAt(0) - 97, Number(square[1])];
}

function kingSquare(position: Chess, side: Color): Square {
  const square = SQUARES.find((candidate) => {
    const piece = position.get(candidate);
    return piece?.type === 'k' && piece.color === side;
  });
  if (!square) throw new Error(`The ${side === 'w' ? 'white' : 'black'} king is missing from the endgame-analysis position.`);
  return square;
}

function countPieces(position: Chess): Counts {
  const counts: Counts = {
    w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
    b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
  };
  for (const square of SQUARES) {
    const piece = position.get(square);
    if (piece) counts[piece.color][piece.type] += 1;
  }
  return counts;
}

function nonKingCount(counts: Counts, side: Color): number {
  return MATERIAL_PIECES.reduce((sum, piece) => sum + counts[side][piece], 0);
}

function materialEvidence(position: Chess, counts: Counts, description: string): KnowledgeEvidence[] {
  return [makeEvidence(
    'endgame.material-inventory',
    description,
    SQUARES.filter((square) => Boolean(position.get(square))),
    {
      whiteMaterial: MATERIAL_PIECES.map((piece) => `${piece}:${counts.w[piece]}`),
      blackMaterial: MATERIAL_PIECES.map((piece) => `${piece}:${counts.b[piece]}`),
      whiteNonKings: nonKingCount(counts, 'w'),
      blackNonKings: nonKingCount(counts, 'b'),
    },
  )];
}

function makeEvidence(
  id: string,
  description: string,
  squares: Square[],
  values: Record<string, KnowledgeEvidenceValue>,
  kind: KnowledgeEvidence['kind'] = 'board-state',
): KnowledgeEvidence {
  return { id, kind, description, squares, values };
}

function createFinding(args: {
  motif: EndgameMotif;
  state: EndgameState;
  side?: Color;
  label: string;
  confidence: number;
  relevance: number;
  boardEvidence: KnowledgeEvidence[];
  possibleConsequence: string;
  triggeringMove?: TacticalMove;
  legalLine?: TacticalLegalLine;
  historyDerived?: boolean;
}): EndgameFinding {
  const conceptId = `endgame.${args.motif}`;
  const evidence = [...args.boardEvidence];
  if (args.triggeringMove) evidence.push(makeEvidence(
    `${conceptId}.move.${args.triggeringMove.uci}`,
    `Legally generated move ${args.triggeringMove.san} (${args.triggeringMove.uci}).`,
    [],
    { san: args.triggeringMove.san, uci: args.triggeringMove.uci },
    'move-sequence',
  ));
  if (args.legalLine) evidence.push(makeEvidence(
    `${conceptId}.legal-line.${args.triggeringMove?.uci ?? 'static'}`,
    `Legal line status: ${args.state}; opponent replies generated: ${args.legalLine.opponentRepliesGenerated}; outcome: ${args.legalLine.outcome.kind}.`,
    [],
    { candidateMoveLegal: args.legalLine.candidateMoveLegal ?? 'not-applicable', replies: args.legalLine.opponentRepliesGenerated, outcome: args.legalLine.outcome.kind },
    'move-sequence',
  ));
  return {
    ...assertKnowledgeFinding({
      conceptId,
      label: args.label,
      evidence,
      confidence: args.confidence,
      relevance: args.relevance,
      possibleImplications: [{ ...(args.side ? { side: args.side } : {}), description: args.possibleConsequence }],
      provenance: args.historyDerived ? HISTORY_PROVENANCE : BOARD_PROVENANCE,
    }),
    state: args.state,
    motif: args.motif,
    ...(args.side ? { side: args.side } : {}),
    boardEvidence: args.boardEvidence,
    ...(args.triggeringMove ? { triggeringMove: args.triggeringMove } : {}),
    ...(args.legalLine ? { legalLine: args.legalLine } : {}),
    possibleConsequence: args.possibleConsequence,
  };
}

function legalLineForMove(position: Chess, move: Move, after: Chess): TacticalLegalLine {
  const replies = after.moves({ verbose: true });
  const moveFact = { uci: uciForMove(move), san: move.san };
  return {
    candidateMoveLegal: true,
    forcingMove: moveFact,
    forcingStatus: after.isCheck() ? 'verified-check' : 'candidate-only',
    opponentRepliesGenerated: replies.length,
    opponentReplies: replies.slice(0, 48).map((reply) => ({ uci: uciForMove(reply), san: reply.san })),
    repliesTruncated: replies.length > 48,
    continuationSearch: after.isCheckmate() || after.isStalemate() ? 'all-immediate-replies' : 'not-performed',
    continuations: [],
    outcome: after.isCheckmate()
      ? { kind: 'checkmate', deterministic: true, description: 'The legal move gives checkmate according to chess.js.' }
      : after.isStalemate()
        ? { kind: 'stalemate', deterministic: true, description: 'The legal move leaves the opponent stalemated according to chess.js.' }
        : { kind: 'position-fact', deterministic: true, description: `Legal move applied from ${position.fen()} and resulting board recorded; no engine outcome is inferred.` },
  };
}

function isPassedPawn(position: Chess, square: Square, side: Color): boolean {
  const [file, rank] = squareCoords(square);
  for (let fileDelta = -1; fileDelta <= 1; fileDelta += 1) {
    const adjacentFile = file + fileDelta;
    if (adjacentFile < 0 || adjacentFile > 7) continue;
    for (let rankIndex = 1; rankIndex <= 8; rankIndex += 1) {
      const otherSquare = squareAt(adjacentFile, rankIndex);
      if (!otherSquare) continue;
      const piece = position.get(otherSquare);
      if (!piece || piece.color === side || piece.type !== 'p') continue;
      if (side === 'w' ? rankIndex > rank : rankIndex < rank) return false;
    }
  }
  return true;
}

function passedPawns(position: Chess, side: Color): Square[] {
  return SQUARES.filter((square) => {
    const piece = position.get(square);
    return piece?.type === 'p' && piece.color === side && isPassedPawn(position, square, side);
  });
}

function pawnPathClear(position: Chess, square: Square, side: Color): boolean {
  const [file, rank] = squareCoords(square);
  const step = side === 'w' ? 1 : -1;
  for (let nextRank = rank + step; nextRank >= 1 && nextRank <= 8; nextRank += step) {
    const nextSquare = squareAt(file, nextRank);
    if (nextSquare && position.get(nextSquare)) return false;
  }
  return true;
}

function analyzeMaterialPhase(position: Chess, counts: Counts): { phase: EndgamePhase; findings: EndgameFinding[]; flags: { pawn: boolean; rook: boolean; minor: boolean; queen: boolean } } {
  const allNonKings = MATERIAL_PIECES.filter((piece) => counts.w[piece] + counts.b[piece] > 0);
  const pawn = counts.w.p + counts.b.p > 0 && allNonKings.every((piece) => piece === 'p');
  const rook = counts.w.r > 0 && counts.b.r > 0 && counts.w.q + counts.b.q + counts.w.b + counts.b.b + counts.w.n + counts.b.n === 0;
  const minor = (counts.w.b + counts.w.n + counts.b.b + counts.b.n > 0) && counts.w.q + counts.b.q + counts.w.r + counts.b.r === 0;
  const queen = counts.w.q > 0 && counts.b.q > 0 && counts.w.r + counts.b.r + counts.w.b + counts.b.b + counts.w.n + counts.b.n === 0;
  const basicMate = detectBasicMatingMaterial(counts).length > 0;
  const findings: EndgameFinding[] = [];
  if (pawn) findings.push(createFinding({
    motif: 'pawn-ending', state: 'confirmed', label: 'Pawn-ending material profile', confidence: 1, relevance: 0.83,
    boardEvidence: materialEvidence(position, counts, 'All non-king material consists of pawns; no queen, rook, bishop, or knight remains.'),
    possibleConsequence: 'This is a pawn ending by material inventory; no result or winning plan is inferred.',
  }));
  if (rook) findings.push(createFinding({
    motif: 'rook-ending', state: 'confirmed', label: 'Rook-ending material profile', confidence: 1, relevance: 0.82,
    boardEvidence: materialEvidence(position, counts, 'Both sides retain at least one rook and no queens or minor pieces remain.'),
    possibleConsequence: 'This is a rook ending by material inventory; named theoretical positions require additional conditions.',
  }));
  if (minor) findings.push(createFinding({
    motif: 'minor-piece-ending', state: 'confirmed', label: 'Minor-piece-ending material profile', confidence: 0.99, relevance: 0.79,
    boardEvidence: materialEvidence(position, counts, 'No queens or rooks remain and at least one bishop/knight remains on the board.'),
    possibleConsequence: 'This is a minor-piece ending by material inventory; no result or conversion claim is inferred.',
  }));
  if (queen) findings.push(createFinding({
    motif: 'queen-ending', state: 'confirmed', label: 'Queen-ending material profile', confidence: 0.99, relevance: 0.79,
    boardEvidence: materialEvidence(position, counts, 'Both sides retain a queen and no rooks or minor pieces remain.'),
    possibleConsequence: 'This is a queen ending by material inventory; checking sequences and draw chances are not evaluated.',
  }));
  for (const side of detectBasicMatingMaterial(counts)) {
    findings.push(createFinding({
      motif: 'basic-mating-ending', state: 'candidate', side, label: 'Basic mating-material candidate', confidence: 0.77, relevance: 0.8,
      boardEvidence: materialEvidence(position, counts, `${side === 'w' ? 'White' : 'Black'} has a standard basic mating material set against a bare king, with no pawns on the board.`),
      possibleConsequence: 'The material configuration is associated with a basic mating ending; actual mate delivery and conversion are not verified.',
    }));
  }
  const phase: EndgamePhase = pawn
    ? 'pawn-ending'
    : rook
      ? 'rook-ending'
      : minor
        ? 'minor-piece-ending'
        : queen
          ? 'queen-ending'
          : basicMate
            ? 'basic-mating-material'
            : allNonKings.length === 0
              ? 'bare-kings'
              : 'mixed-or-middlegame';
  return { phase, findings, flags: { pawn, rook, minor, queen } };
}

function detectBasicMatingMaterial(counts: Counts): Color[] {
  if (counts.w.p + counts.b.p > 0) return [];
  const result: Color[] = [];
  for (const side of ['w', 'b'] as const) {
    const enemy = opposite(side);
    if (nonKingCount(counts, enemy) !== 0) continue;
    const ownSet: PieceSymbol[] = [];
    for (const piece of MATERIAL_PIECES) for (let count = 0; count < counts[side][piece]; count += 1) ownSet.push(piece);
    const isBasic = ownSet.length === 1 && (ownSet[0] === 'q' || ownSet[0] === 'r')
      || ownSet.length === 2 && ownSet.filter((piece) => piece === 'b').length === 2
      || ownSet.length === 2 && ownSet.includes('b') && ownSet.includes('n');
    if (isBasic) result.push(side);
  }
  return result;
}

function analyzeOpposition(position: Chess, pawnEnding: boolean): EndgameFinding[] {
  if (!pawnEnding) return [];
  const whiteKing = kingSquare(position, 'w');
  const blackKing = kingSquare(position, 'b');
  const [whiteFile, whiteRank] = squareCoords(whiteKing);
  const [blackFile, blackRank] = squareCoords(blackKing);
  const fileDistance = Math.abs(whiteFile - blackFile);
  const rankDistance = Math.abs(whiteRank - blackRank);
  const aligned = fileDistance === 0 || rankDistance === 0;
  const separation = Math.max(fileDistance, rankDistance);
  if (!aligned || separation < 2 || separation % 2 !== 0) return [];
  const sideWithOpposition = opposite(position.turn());
  const evidence = [makeEvidence(
    'endgame.opposition.kings',
    `The kings are aligned ${separation} square(s) apart on the same file/rank; the side not to move has the geometric opposition cue.`,
    [whiteKing, blackKing],
    { whiteKing, blackKing, fileDistance, rankDistance, sideToMove: position.turn(), sideNotToMove: sideWithOpposition },
  )];
  return [createFinding({
    motif: 'opposition', state: 'candidate', side: sideWithOpposition, label: 'Opposition candidate', confidence: 0.63, relevance: 0.68,
    boardEvidence: evidence,
    possibleConsequence: 'The side not to move has an aligned-king opposition cue; pawn structure, legal routes, and the result are not solved.',
  })];
}

function analyzeKeySquares(position: Chess, counts: Counts, pawnEnding: boolean): EndgameFinding[] {
  if (!pawnEnding) return [];
  const findings: EndgameFinding[] = [];
  for (const side of ['w', 'b'] as const) {
    if (counts[side].p !== 1 || counts[opposite(side)].p !== 0) continue;
    const pawn = SQUARES.find((square) => position.get(square)?.type === 'p' && position.get(square)?.color === side);
    if (!pawn || !isPassedPawn(position, pawn, side)) continue;
    const [file] = squareCoords(pawn);
    const rank = Number(pawn[1]);
    const relativeRank = side === 'w' ? rank : 9 - rank;
    if (relativeRank < 2 || relativeRank > 6) continue;
    const relativeKeyRank = relativeRank === 2 ? 4 : relativeRank === 3 ? 5 : relativeRank === 4 ? 6 : 7;
    const keySquares = [-1, 0, 1]
      .map((delta) => squareAt(file + delta, side === 'w' ? relativeKeyRank : 9 - relativeKeyRank))
      .filter((square): square is Square => square !== null);
    const king = kingSquare(position, side);
    const controlsKeySquare = keySquares.some((square) => square === king || position.attackers(square, side).includes(king));
    if (!controlsKeySquare) continue;
    const evidence = [makeEvidence(
      `endgame.key-squares.${side}.${pawn}`,
      `For the single passed pawn on ${pawn}, the friendly king occupies or geometrically controls at least one standard key square.`,
      [pawn, king, ...keySquares],
      { pawn, king, keySquares, controlsKeySquare: true, relativePawnRank: relativeRank },
    )];
    findings.push(createFinding({
      motif: 'key-squares', state: 'candidate', side, label: 'Key-square access candidate', confidence: 0.58, relevance: 0.62,
      boardEvidence: evidence,
      possibleConsequence: 'The king reaches a key square for this lone passed pawn under the simplified pawn-ending rule; the opposing king and move order may still prevent promotion.',
    }));
  }
  return findings;
}

function analyzeSquareRule(position: Chess, pawnEnding: boolean): EndgameFinding[] {
  if (!pawnEnding) return [];
  const findings: EndgameFinding[] = [];
  for (const side of ['w', 'b'] as const) {
    const enemy = opposite(side);
    const enemyKing = kingSquare(position, enemy);
    const [kingFile, kingRank] = squareCoords(enemyKing);
    for (const pawn of passedPawns(position, side)) {
      if (!pawnPathClear(position, pawn, side)) continue;
      const [pawnFile, pawnRank] = squareCoords(pawn);
      const steps = side === 'w' ? 8 - pawnRank : pawnRank - 1;
      const inside = Math.abs(kingFile - pawnFile) <= steps
        && (side === 'w' ? kingRank >= pawnRank : kingRank <= pawnRank);
      const evidence = [makeEvidence(
        `endgame.square-rule.${side}.${pawn}`,
        `A clear-path passed pawn on ${pawn} has ${steps} forward step(s); the opposing king is ${inside ? 'inside' : 'outside'} the unadjusted square by board geometry.`,
        [pawn, enemyKing],
        { pawn, opposingKing: enemyKing, stepsToPromotion: steps, insideSquare: inside, sideToMove: position.turn() },
      )];
      findings.push(createFinding({
        motif: 'square-rule', state: 'candidate', side: inside ? enemy : side, label: inside ? 'King-inside-square candidate' : 'King-outside-square candidate',
        confidence: 0.58, relevance: 0.62, boardEvidence: evidence,
        possibleConsequence: inside
          ? 'The opposing king lies inside the unadjusted pawn square and may catch or stop the pawn; tempo, checks, and legal king routes are not fully calculated.'
          : 'The opposing king lies outside the unadjusted pawn square; this is a promotion-race cue, not a guaranteed promotion.',
      }));
    }
  }
  return findings;
}

function analyzeBreakthrough(position: Chess, pawnEnding: boolean): EndgameFinding[] {
  if (!pawnEnding) return [];
  const findings: EndgameFinding[] = [];
  for (const move of position.moves({ verbose: true })) {
    if (move.piece !== 'p' || move.promotion) continue;
    const after = new Chess(position.fen());
    const applied = after.move({ from: move.from, to: move.to });
    const movedPawn = after.get(applied.to);
    if (!movedPawn || movedPawn.type !== 'p' || !isPassedPawn(after, applied.to, applied.color) || isPassedPawn(position, applied.from, applied.color)) continue;
    const fact = { uci: uciForMove(applied), san: applied.san };
    const evidence = [makeEvidence(
      `endgame.breakthrough.${fact.uci}`,
      `Legal pawn move ${fact.san} creates a passed pawn from a pawn that was not passed before the move.`,
      [applied.from, applied.to],
      { uci: fact.uci, san: fact.san, becomesPassed: true, opponentReplies: after.moves({ verbose: true }).length },
      'move-sequence',
    )];
    findings.push(createFinding({
      motif: 'breakthrough', state: 'candidate', side: applied.color, label: 'Pawn-breakthrough candidate', confidence: 0.68, relevance: 0.74,
      boardEvidence: evidence, triggeringMove: fact,
      legalLine: legalLineForMove(position, applied, after),
      possibleConsequence: 'The legal pawn move creates a passed pawn; whether it promotes or wins is not evaluated.',
    }));
  }
  return findings;
}

function analyzeOppositeColoredBishops(position: Chess, counts: Counts): EndgameFinding[] {
  if (counts.w.b !== 1 || counts.b.b !== 1) return [];
  if (counts.w.q + counts.b.q + counts.w.r + counts.b.r + counts.w.n + counts.b.n !== 0) return [];
  const whiteBishop = SQUARES.find((square) => position.get(square)?.type === 'b' && position.get(square)?.color === 'w');
  const blackBishop = SQUARES.find((square) => position.get(square)?.type === 'b' && position.get(square)?.color === 'b');
  if (!whiteBishop || !blackBishop) return [];
  const colorOf = (square: Square) => {
    const [file, rank] = squareCoords(square);
    return (file + rank) % 2 === 0 ? 'light' : 'dark';
  };
  const whiteColor = colorOf(whiteBishop);
  const blackColor = colorOf(blackBishop);
  if (whiteColor === blackColor) return [];
  return [createFinding({
    motif: 'opposite-coloured-bishops', state: 'confirmed', label: 'Opposite-coloured bishops material profile', confidence: 0.99, relevance: 0.7,
    boardEvidence: [makeEvidence(
      'endgame.opposite-coloured-bishops',
      `Each side has exactly one bishop on opposite square colours (${whiteColor} vs ${blackColor}); no rooks, queens or knights remain.`,
      [whiteBishop, blackBishop],
      { whiteBishop, blackBishop, whiteSquareColor: whiteColor, blackSquareColor: blackColor, pawns: counts.w.p + counts.b.p },
    )],
    possibleConsequence: 'This is an opposite-coloured-bishop ending by material and square colour; drawing tendencies depend on the pawn structure and are not evaluated.',
  })];
}

function analyzeLucena(position: Chess, counts: Counts, rookEnding: boolean): EndgameFinding[] {
  if (!rookEnding || counts.w.r !== 1 || counts.b.r !== 1) return [];
  const findings: EndgameFinding[] = [];
  for (const side of ['w', 'b'] as const) {
    const enemy = opposite(side);
    const backRank = side === 'w' ? 8 : 1;
    const passed = passedPawns(position, side).filter((square) => Number(square[1]) === (side === 'w' ? 7 : 2));
    for (const pawn of passed) {
      const [file, rank] = squareCoords(pawn);
      const ownKing = kingSquare(position, side);
      const enemyKing = kingSquare(position, enemy);
      const [ownFile, ownRank] = squareCoords(ownKing);
      const [enemyFile, enemyRank] = squareCoords(enemyKing);
      const kingSupportsPawn = ownFile === file && ownRank === rank - (side === 'w' ? 1 : -1);
      const defenderOnBackRank = enemyRank === backRank;
      const defenderCutOff = Math.abs(enemyFile - file) >= 2;
      const promotionSquare = squareAt(file, side === 'w' ? 8 : 1);
      if (!kingSupportsPawn || !defenderOnBackRank || !defenderCutOff || !promotionSquare || position.get(promotionSquare)) continue;
      const evidence = [makeEvidence(
        `endgame.lucena.${side}.${pawn}`,
        'Rook-ending preconditions match a Lucena-pattern candidate: passed seventh-rank pawn, supporting king directly behind it, defending king cut off on the back rank, and one rook each.',
        [pawn, ownKing, enemyKing, promotionSquare],
        { pawn, ownKing, enemyKing, promotionSquare, ownRooks: counts[side].r, defendingRooks: counts[enemy].r, defenderCutOffFiles: Math.abs(enemyFile - file) },
      )];
      findings.push(createFinding({
        motif: 'lucena', state: 'candidate', side, label: 'Lucena-pattern candidate', confidence: 0.65, relevance: 0.72,
        boardEvidence: evidence,
        possibleConsequence: 'The pawn/king/cut-off conditions resemble a Lucena rook ending; rook placement, checking resources, and the winning technique are not proved.',
      }));
    }
  }
  return findings;
}

function analyzePhilidor(position: Chess, counts: Counts, rookEnding: boolean): EndgameFinding[] {
  if (!rookEnding || counts.w.r !== 1 || counts.b.r !== 1) return [];
  const findings: EndgameFinding[] = [];
  for (const defender of ['w', 'b'] as const) {
    const attacker = opposite(defender);
    const defenderRookRank = defender === 'w' ? 6 : 3;
    const rookSquare = SQUARES.find((square) => {
      const piece = position.get(square);
      return piece?.type === 'r' && piece.color === defender && Number(square[1]) === defenderRookRank;
    });
    if (!rookSquare) continue;
    const defenderKing = kingSquare(position, defender);
    const [defenderFile, defenderRank] = squareCoords(defenderKing);
    for (const pawn of passedPawns(position, attacker)) {
      const pawnRank = Number(pawn[1]);
      const relativeRank = attacker === 'w' ? pawnRank : 9 - pawnRank;
      const [pawnFile] = squareCoords(pawn);
      if (relativeRank < 4 || relativeRank > 5) continue;
      const kingAhead = defender === 'w' ? defenderRank < pawnRank : defenderRank > pawnRank;
      if (!kingAhead || Math.abs(defenderFile - pawnFile) > 1) continue;
      const evidence = [makeEvidence(
        `endgame.philidor.${defender}.${pawn}`,
        `Rook-ending preconditions match a Philidor defensive-pattern candidate: passed pawn below the seventh, defending king in front, defender rook on its sixth-rank line, and one rook each.`,
        [pawn, defenderKing, rookSquare, kingSquare(position, attacker)],
        { defender, attacker, passedPawn: pawn, defenderKing, defenderRook: rookSquare, relativePawnRank: relativeRank },
      )];
      findings.push(createFinding({
        motif: 'philidor', state: 'candidate', side: defender, label: 'Philidor-pattern candidate', confidence: 0.61, relevance: 0.7,
        boardEvidence: evidence,
        possibleConsequence: 'The defending king/rook and pawn-rank conditions resemble a Philidor setup; exact defensive technique and draw are not proved.',
      }));
    }
  }
  return findings;
}

function validateHistory(position: Chess, record: GameRecord): ReplayHistory {
  if (!Number.isInteger(record.cursorPly) || record.cursorPly < 0 || record.cursorPly > record.moveHistory.length) {
    throw new RangeError('Endgame analysis received a GameRecord with an invalid cursor ply.');
  }
  const replay = new Chess(record.initialPosition.fen);
  const keys = [positionKey(replay)];
  const moves: ReplayMove[] = [];
  for (const entry of record.moveHistory.slice(0, record.cursorPly)) {
    const applied = replay.move({ from: entry.from, to: entry.to, ...(entry.promotion ? { promotion: entry.promotion } : {}) });
    if (applied.san !== entry.san || uciForMove(applied) !== entry.uci) {
      throw new Error(`Endgame analysis rejected mismatched history at ply ${entry.ply}.`);
    }
    moves.push({ side: applied.color, uci: uciForMove(applied), san: applied.san, givesCheck: replay.isCheck(), ply: entry.ply });
    keys.push(positionKey(replay));
  }
  const expected = record.repetitionKeys.slice(0, record.cursorPly + 1);
  if (expected.length !== keys.length || expected.some((key, index) => key !== keys[index])) {
    throw new Error('Endgame analysis rejected inconsistent repetition history.');
  }
  const recorded = new Chess(record.currentFen);
  if (positionKey(replay) !== positionKey(recorded) || positionKey(replay) !== positionKey(position)) {
    throw new Error('Endgame analysis rejected history that does not replay to the analyzed position.');
  }
  return { keys, moves };
}

function analyzePerpetual(position: Chess, history?: ReplayHistory): EndgameFinding[] {
  if (!history) return [];
  const key = positionKey(position);
  const occurrences = history.keys.flatMap((candidate, index) => candidate === key ? [index] : []);
  if (occurrences.length < 3) return [];
  const [first, second, third] = occurrences.slice(-3);
  const cycleOne = history.moves.slice(first, second);
  const cycleTwo = history.moves.slice(second, third);
  for (const side of ['w', 'b'] as const) {
    const checksOne = cycleOne.filter((move) => move.side === side);
    const checksTwo = cycleTwo.filter((move) => move.side === side);
    if (!checksOne.length || !checksTwo.length || !checksOne.every((move) => move.givesCheck) || !checksTwo.every((move) => move.givesCheck)) continue;
    const checkingMoves = [...checksOne, ...checksTwo];
    return [createFinding({
      motif: 'perpetual', state: 'confirmed', side, label: 'Verified repeated-check cycle', confidence: 0.99, relevance: 0.9,
      boardEvidence: [makeEvidence(
        `endgame.perpetual.${side}.${first}-${third}`,
        `Replay-validated history repeats the current position three times, and every move by ${side === 'w' ? 'White' : 'Black'} in both cycles gives check.`,
        [],
        { occurrences, cycleOnePlies: cycleOne.map((move) => move.ply), cycleTwoPlies: cycleTwo.map((move) => move.ply), checkingMoves: checkingMoves.map((move) => move.uci) },
        'move-sequence',
      )],
      possibleConsequence: 'A repeated-check cycle by this side is verified; repetition-claim rules may apply, but perpetual check is not a separate automatic FIDE result.',
      historyDerived: true,
    })];
  }
  return [];
}

function deduplicate(findings: EndgameFinding[]): EndgameFinding[] {
  const seen = new Set<string>();
  return findings.filter((finding) => {
    const key = `${finding.motif}|${finding.side ?? ''}|${finding.triggeringMove?.uci ?? finding.boardEvidence.map((evidence) => evidence.id).join(',')}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Condition-based endgame recognition; theoretical names are emitted only when their board prerequisites are present. */
export function analyzeEndgames(position: Chess, record?: GameRecord, tacticalAnalysis?: TacticalAnalysis): EndgameAnalysis {
  const source = new Chess(position.fen());
  const tactical = tacticalAnalysis ?? analyzeTactics(source);
  if (positionKey(new Chess(tactical.positionFen)) !== positionKey(source)) throw new Error('Endgame analysis received tactical evidence for a different position.');
  const history = record ? validateHistory(source, record) : undefined;
  const counts = countPieces(source);
  const classification = analyzeMaterialPhase(source, counts);
  const findings = [
    ...classification.findings,
    ...analyzeOpposition(source, classification.flags.pawn),
    ...analyzeKeySquares(source, counts, classification.flags.pawn),
    ...analyzeSquareRule(source, classification.flags.pawn),
    ...analyzeBreakthrough(source, classification.flags.pawn),
    ...analyzeOppositeColoredBishops(source, counts),
    ...analyzeLucena(source, counts, classification.flags.rook),
    ...analyzePhilidor(source, counts, classification.flags.rook),
    ...analyzePerpetual(source, history),
    ...tactical.findings
      .filter((finding) => finding.motif === 'stalemate-resource')
      .map((finding) => {
        const move = source.moves({ verbose: true }).find((candidate) => uciForMove(candidate) === finding.triggeringMove?.uci);
        if (!move) return null;
        const after = new Chess(source.fen());
        const applied = after.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
        return createFinding({
          motif: 'stalemate-resource', state: 'confirmed', side: source.turn(), label: 'Verified stalemate resource', confidence: 1, relevance: 1,
          boardEvidence: finding.boardEvidence,
          possibleConsequence: 'The legal move immediately draws by stalemate; this may be a drawing resource, but whether a draw is preferable is not evaluated.',
          triggeringMove: { uci: uciForMove(applied), san: applied.san },
          legalLine: legalLineForMove(source, applied, after),
        });
      })
      .filter((finding): finding is EndgameFinding => finding !== null),
  ];
  const deferred = STATIC_DEFERRED.map((entry) => ({ ...entry }));
  if (!history) deferred.push({ motif: 'perpetual', state: 'deferred', reason: 'Perpetual-check recognition requires replay-validated move history; a FEN alone cannot establish a cycle.' });
  return {
    version: 1,
    positionFen: source.fen(),
    sideToMove: source.turn(),
    phase: classification.phase,
    historyValidation: record ? 'validated' : 'not-provided',
    findings: deduplicate(findings),
    deferredMotifs: deferred,
    limitations: [
      'Pawn key-square and square-rule findings use simplified single-pawn geometry and are candidates; king routes, tempo, checks, and promotion captures are not fully searched.',
      'Lucena and Philidor labels require the listed board preconditions but remain candidates; rook-checking technique and forced outcomes are not proved.',
      'Vancura, triangulation, outflanking, reserve-tempo, and fortress are explicitly deferred rather than inferred from resemblance.',
      'Basic mating-ending findings describe material sets only; no tablebase or engine proof is used.',
      'Perpetual-check recognition needs replay-validated history and identifies a repeated-check cycle; repetition/draw claims remain governed by the existing domain rules.',
    ],
  };
}
