import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { analyzeDefence, DEFENCE_RESOURCES, type DefenceResourceFinding } from './defence';

function resourcesFor(fen: string, motif: DefenceResourceFinding['motif']): DefenceResourceFinding[] {
  return analyzeDefence(new Chess(fen)).resources.filter((finding) => finding.motif === motif);
}

function resourceForMove(fen: string, motif: DefenceResourceFinding['motif'], uci: string): DefenceResourceFinding | undefined {
  return resourcesFor(fen, motif).find((finding) => finding.triggeringMove?.uci === uci);
}

describe('defensive threat and resource analysis', () => {
  it('exposes every requested resource, with fortress explicitly deferred', () => {
    const analysis = analyzeDefence(new Chess());
    expect(DEFENCE_RESOURCES).toEqual(expect.arrayContaining([
      'remove-attacker', 'reinforce-target', 'block-interpose', 'luft', 'king-reposition', 'castling',
      'cut-attacker-supply', 'return-material', 'counterattack', 'counter-check', 'queen-trade', 'repetition',
      'blockade', 'fortress', 'stalemate-resource', 'defensive-sacrifice',
    ]));
    expect(analysis.deferredResources).toContainEqual(expect.objectContaining({ motif: 'fortress', state: 'deferred' }));
    expect(analysis.resources.every((finding) => finding.state === 'confirmed' || finding.state === 'candidate')).toBe(true);
  });

  it('orders Checks → Captures → Threats and prioritizes a verified current check', () => {
    const fen = 'k3r3/8/8/8/8/8/3R4/4K3 w - - 0 1';
    const analysis = analyzeDefence(new Chess(fen));
    expect(analysis.threatAssessment.order).toEqual(['checks', 'captures', 'threats']);
    expect(analysis.threatAssessment.priorityCategory).toBe('checks');
    expect(analysis.threatAssessment.mostDangerousVerifiedThreat?.category).toBe('checks');
    expect(analysis.threatAssessment.mostDangerousVerifiedThreat?.state).toBe('confirmed');
    expect(analysis.threatAssessment.priorityExplanation).toMatch(/current check is verified/i);
  });

  it('prioritizes a hypothetical check ahead of a capture and keeps both conditional', () => {
    const fen = 'r6k/8/8/8/8/8/7K/R7 w - - 0 1';
    const assessment = analyzeDefence(new Chess(fen)).threatAssessment;
    expect(assessment.priorityCategory).toBe('checks');
    expect(assessment.checks.some((threat) => threat.state === 'candidate')).toBe(true);
    expect(assessment.captures.some((threat) => threat.targetSquares.includes('a1') && threat.state === 'candidate')).toBe(true);
    expect(assessment.mostDangerousVerifiedThreat).toBeNull();
    expect(assessment.mostDangerousCandidateThreat?.category).toBe('checks');
    expect(assessment.mostDangerousCandidateThreat?.possibleImplications[0]?.description).toMatch(/not a current forcing threat/i);
  });

  it('attaches evidence, provenance and bounded confidence to threats and resources', () => {
    const analysis = analyzeDefence(new Chess('4r2k/8/8/8/8/8/3R4/4K3 w - - 0 1'));
    const findings = [
      ...analysis.resources,
      ...analysis.threatAssessment.checks,
      ...analysis.threatAssessment.captures,
      ...analysis.threatAssessment.threats,
    ];
    expect(findings.length).toBeGreaterThan(0);
    for (const finding of findings) {
      expect(finding.conceptId.length).toBeGreaterThan(0);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.provenance.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
    }
  });

  describe('check evasions and king safety resources', () => {
    it('recognizes a legal block/interposition that resolves a rook check', () => {
      const fen = 'k3r3/8/8/8/8/8/3R4/4K3 w - - 0 1';
      const interpose = resourceForMove(fen, 'block-interpose', 'd2e2');
      expect(interpose).toBeDefined();
      expect(interpose?.state).toBe('confirmed');
      expect(interpose?.legalLine.outcome).toMatchObject({ kind: 'position-fact', deterministic: true });
    });

    it('does not offer an illegal block as a resource', () => {
      const fen = 'k3r3/8/8/8/8/8/3R4/4K3 w - - 0 1';
      expect(resourceForMove(fen, 'block-interpose', 'd2d3')).toBeUndefined();
    });

    it('recognizes capturing the checking piece as a legal remove-attacker resource', () => {
      const fen = '7k/8/8/8/8/2b5/4N3/4K3 w - - 0 1';
      const remove = resourceForMove(fen, 'remove-attacker', 'e2c3');
      expect(remove).toBeDefined();
      expect(remove?.state).toBe('confirmed');
      expect(remove?.possibleConsequence).toMatch(/resolves the current check/i);
    });

    it('recognizes a legal castling resource without calling it best', () => {
      const fen = '4k3/8/8/8/8/8/8/4K2R w K - 0 1';
      const castling = resourceForMove(fen, 'castling', 'e1g1');
      expect(castling).toBeDefined();
      expect(castling?.state).toBe('confirmed');
      expect(castling?.possibleConsequence).toMatch(/not evaluated/i);
      expect(castling?.possibleConsequence).not.toMatch(/best/i);
    });

    it('recognizes a legal luft candidate but does not assert that the escape square is safe', () => {
      const fen = '4k3/8/8/8/8/8/6P1/6K1 w - - 0 1';
      const luft = resourceForMove(fen, 'luft', 'g2g3');
      expect(luft).toBeDefined();
      expect(luft?.state).toBe('candidate');
      expect(luft?.possibleConsequence).toMatch(/not asserted to be safe/i);
    });

    it('recognizes legal king repositioning as a resource candidate', () => {
      const fen = '4k3/8/8/8/8/8/8/4K3 w - - 0 1';
      const kingMove = resourceForMove(fen, 'king-reposition', 'e1d1');
      expect(kingMove).toBeDefined();
      expect(kingMove?.state).toBe('candidate');
    });
  });

  describe('target support, counterplay and exchanges', () => {
    it('detects a legal move that reinforces an attacked rook', () => {
      const fen = 'r6k/8/8/8/8/8/8/R1N4K w - - 0 1';
      const reinforce = resourceForMove(fen, 'reinforce-target', 'c1b3');
      expect(reinforce).toBeDefined();
      expect(reinforce?.state).toBe('candidate');
      expect(reinforce?.possibleConsequence).toMatch(/additional geometric support/i);
    });

    it('rejects a reinforce-target near-miss that does not add a defender', () => {
      const fen = 'r6k/8/8/8/8/8/8/R6K w - - 0 1';
      expect(resourcesFor(fen, 'reinforce-target')).toHaveLength(0);
    });

    it('recognizes cutting the attacker supply with a legal interposition', () => {
      const fen = 'r5k1/8/8/8/8/8/1B6/R6K w - - 0 1';
      const cut = resourceForMove(fen, 'cut-attacker-supply', 'b2a3');
      expect(cut).toBeDefined();
      expect(cut?.state).toBe('candidate');
      expect(cut?.boardEvidence[0].values?.afterAttackers).toEqual([]);
    });

    it('recognizes a legal counter-check without claiming a win', () => {
      const fen = '4r3/8/8/7k/2B5/8/8/4K3 w - - 0 1';
      const counterCheck = resourceForMove(fen, 'counter-check', 'c4e2');
      expect(counterCheck).toBeDefined();
      expect(counterCheck?.state).toBe('confirmed');
      expect(counterCheck?.legalLine.forcingStatus).toBe('verified-check');
      expect(counterCheck?.possibleConsequence).toMatch(/no win/i);
    });

    it('recognizes a legal counterattack against an enemy rook as a candidate', () => {
      const fen = 'k7/8/7q/8/8/8/4Q3/6K1 w - - 0 1';
      const counter = resourceForMove(fen, 'counterattack', 'e2h5');
      expect(counter).toBeDefined();
      expect(counter?.state).toBe('candidate');
    });

    it('does not call a queen capture a trade when the capturing queen cannot be recaptured', () => {
      const fen = '7k/8/8/3q4/8/8/3Q4/7K w - - 0 1';
      expect(resourceForMove(fen, 'queen-trade', 'd2d5')).toBeUndefined();
    });

    it('recognizes a queen exchange only when the opponent has a legal recapture', () => {
      const fen = '3r3k/8/8/3q4/8/8/3Q4/7K w - - 0 1';
      const trade = resourceForMove(fen, 'queen-trade', 'd2d5');
      expect(trade).toBeDefined();
      expect(trade?.state).toBe('candidate');
      expect(trade?.boardEvidence[0].values?.bothQueensLeaveOnRecapture).toBe(true);
      expect(trade?.boardEvidence[0].values?.legalRecaptures).toContain('d8d5');
      expect(trade?.possibleConsequence).toMatch(/opponent chooses the recapture/i);
    });

    it('finds a concrete legal exchange chain as a return-material candidate', () => {
      const fen = 'q6k/8/1nB5/8/8/8/8/R6K w - - 0 1';
      const exchange = resourceForMove(fen, 'return-material', 'a1a8');
      expect(exchange).toBeDefined();
      expect(exchange?.state).toBe('candidate');
      expect(exchange?.boardEvidence[0].values?.defenderRecaptures).toBeGreaterThan(0);
    });

    it('recognizes a passed-pawn blockade square as a candidate', () => {
      const fen = '7k/8/8/p7/8/8/8/R6K w - - 0 1';
      const blockade = resourceForMove(fen, 'blockade', 'a1a4');
      expect(blockade).toBeDefined();
      expect(blockade?.state).toBe('candidate');
    });

    it('does not invent blockade when the pawn is not passed', () => {
      const fen = '7k/8/8/p7/8/8/P7/R6K w - - 0 1';
      expect(resourcesFor(fen, 'blockade')).toHaveLength(0);
    });

    it('surfaces defensive sacrifice only when the legal move reduces pressure and creates counter-pressure', () => {
      const fen = '4r3/3p4/8/8/2B5/7k/4Q3/4K3 w - - 0 1';
      const sacrifice = resourceForMove(fen, 'defensive-sacrifice', 'c4e6');
      expect(sacrifice).toBeDefined();
      expect(sacrifice?.state).toBe('candidate');
      expect(sacrifice?.possibleConsequence).toMatch(/not proved/i);
    });
  });

  describe('draw resources and history validation', () => {
    it('reuses legal stalemate detection as a confirmed defensive resource', () => {
      const fen = '8/8/8/8/8/8/Q7/K1k5 w - - 0 1';
      const stalemate = resourceForMove(fen, 'stalemate-resource', 'a2e2');
      expect(stalemate).toBeDefined();
      expect(stalemate?.state).toBe('confirmed');
      expect(stalemate?.legalLine.outcome).toMatchObject({ kind: 'stalemate', deterministic: true });
    });

    it('recognizes a current threefold-claim resource only with replay-validated history', () => {
      let record = createGame({ id: 'defence-repetition', now: '2026-10-05T00:00:00.000Z' });
      const moves = ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1', 'f6g8'];
      moves.forEach((move, index) => {
        record = applyMove(record, move, { committedAt: `2026-10-05T00:00:${String(index + 1).padStart(2, '0')}.000Z` }).record;
      });
      const repetition = analyzeDefence(new Chess(record.currentFen), record).resources.find((finding) => finding.motif === 'repetition');
      expect(repetition).toBeDefined();
      expect(repetition?.state).toBe('confirmed');
      expect(repetition?.possibleConsequence).toMatch(/threefold-repetition draw claim is available/i);
    });

    it('rejects a repetition history that does not match the supplied board', () => {
      const record = createGame({ id: 'defence-bad-history', now: '2026-10-05T00:00:00.000Z' });
      expect(() => analyzeDefence(new Chess('4k3/8/8/8/8/8/8/4K3 w - - 0 1'), record)).toThrow(/history/i);
    });

    it('keeps fortress as an explicit deferred resource rather than a geometric claim', () => {
      const analysis = analyzeDefence(new Chess('4k3/8/8/8/8/8/8/4K3 w - - 0 1'));
      expect(analysis.resources.some((finding) => finding.motif === 'fortress')).toBe(false);
      expect(analysis.deferredResources.find((resource) => resource.motif === 'fortress')?.reason).toMatch(/no fortress proof/i);
    });
  });
});
