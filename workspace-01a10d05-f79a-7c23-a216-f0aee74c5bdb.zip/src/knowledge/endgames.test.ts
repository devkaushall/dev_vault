import { Chess } from 'chess.js';
import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { analyzeEndgames, ENDGAME_MOTIFS, type EndgameFinding } from './endgames';

function findingsFor(fen: string, motif: EndgameFinding['motif']): EndgameFinding[] {
  return analyzeEndgames(new Chess(fen)).findings.filter((finding) => finding.motif === motif);
}

function findingForMove(fen: string, motif: EndgameFinding['motif'], uci: string): EndgameFinding | undefined {
  return findingsFor(fen, motif).find((finding) => finding.triggeringMove?.uci === uci);
}

describe('condition-based endgame recognition', () => {
  it('exposes the requested motif catalogue and explicitly defers unproven techniques', () => {
    const analysis = analyzeEndgames(new Chess());
    expect(ENDGAME_MOTIFS).toContain('vancura');
    expect(analysis.deferredMotifs.every((motif) => motif.state === 'deferred' && motif.reason.length > 0)).toBe(true);
    expect(new Set(analysis.deferredMotifs.map((entry) => entry.motif))).toEqual(new Set([
      'triangulation', 'outflanking', 'reserve-tempo', 'vancura', 'fortress', 'perpetual',
    ]));
    expect(analysis.findings.every((finding) => finding.state === 'confirmed' || finding.state === 'candidate')).toBe(true);
  });

  it('attaches evidence, provenance and bounded confidence to every endgame finding', () => {
    const fen = 'k7/8/3K4/8/4P3/8/8/8 w - - 0 1';
    const analysis = analyzeEndgames(new Chess(fen));
    expect(analysis.findings.length).toBeGreaterThan(0);
    for (const finding of analysis.findings) {
      expect(finding.conceptId).toBe(`endgame.${finding.motif}`);
      expect(finding.evidence.length).toBeGreaterThan(0);
      expect(finding.provenance.length).toBeGreaterThan(0);
      expect(finding.confidence).toBeGreaterThanOrEqual(0);
      expect(finding.confidence).toBeLessThanOrEqual(1);
    }
  });

  describe('pawn endings', () => {
    it('classifies a kings-and-pawns-only ending from material inventory', () => {
      const fen = '8/7p/4k3/8/4K3/8/P7/8 w - - 0 1';
      const analysis = analyzeEndgames(new Chess(fen));
      expect(analysis.phase).toBe('pawn-ending');
      expect(findingsFor(fen, 'pawn-ending')[0]?.state).toBe('confirmed');
    });

    it('recognizes aligned-king opposition only for the even-separation condition', () => {
      const oppositionFen = '8/7p/4k3/8/4K3/8/P7/8 w - - 0 1';
      const opposition = findingsFor(oppositionFen, 'opposition')[0];
      expect(opposition).toBeDefined();
      expect(opposition?.state).toBe('candidate');
      expect(opposition?.side).toBe('b');
      expect(opposition?.possibleConsequence).toMatch(/not solved/i);
    });

    it('rejects an odd-distance opposition near-miss', () => {
      const nearMiss = '8/4k2p/8/8/4K3/8/P7/8 w - - 0 1';
      expect(findingsFor(nearMiss, 'opposition')).toHaveLength(0);
    });

    it('recognizes friendly king access to a passed pawn key square as a candidate', () => {
      const fen = 'k7/8/3K4/8/4P3/8/8/8 w - - 0 1';
      const keySquare = findingsFor(fen, 'key-squares')[0];
      expect(keySquare).toBeDefined();
      expect(keySquare?.state).toBe('candidate');
      expect(keySquare?.boardEvidence[0].values?.keySquares).toContain('d6');
      expect(keySquare?.possibleConsequence).toMatch(/may still prevent promotion/i);
    });

    it('rejects the key-square near-miss when the king is one rank short', () => {
      const nearMiss = 'k7/8/8/8/4P3/3K4/8/8 w - - 0 1';
      expect(findingsFor(nearMiss, 'key-squares')).toHaveLength(0);
    });

    it('reports square-rule geometry when the opposing king lies inside the unadjusted pawn square', () => {
      const fen = '8/8/8/4k3/8/8/P7/7K w - - 0 1';
      const squareRule = findingsFor(fen, 'square-rule')[0];
      expect(squareRule).toBeDefined();
      expect(squareRule?.boardEvidence[0].values?.insideSquare).toBe(true);
      expect(squareRule?.state).toBe('candidate');
      expect(squareRule?.possibleConsequence).toMatch(/not fully calculated/i);
    });

    it('reports an outside-square near-miss without claiming guaranteed promotion', () => {
      const fen = '8/8/8/7k/8/8/P7/7K w - - 0 1';
      const squareRule = findingsFor(fen, 'square-rule')[0];
      expect(squareRule).toBeDefined();
      expect(squareRule?.boardEvidence[0].values?.insideSquare).toBe(false);
      expect(squareRule?.possibleConsequence).toMatch(/not a guaranteed promotion/i);
    });

    it('recognizes a legal pawn capture that creates a passed pawn as a breakthrough candidate', () => {
      const fen = '7k/8/3p4/2P5/8/8/8/7K w - - 0 1';
      const breakthrough = findingForMove(fen, 'breakthrough', 'c5d6');
      expect(breakthrough).toBeDefined();
      expect(breakthrough?.state).toBe('candidate');
      expect(breakthrough?.legalLine?.candidateMoveLegal).toBe(true);
      expect(breakthrough?.legalLine?.outcome.kind).toBe('position-fact');
      expect(breakthrough?.possibleConsequence).toMatch(/whether it promotes or wins is not evaluated/i);
    });

    it('rejects an illegal/blocked pawn candidate that does not create a passed pawn', () => {
      const fen = '7k/3p4/8/2P5/8/8/8/7K w - - 0 1';
      expect(findingForMove(fen, 'breakthrough', 'c5c6')).toBeUndefined();
    });
  });

  describe('rook endings', () => {
    it('recognizes a rook-ending material profile without evaluating the result', () => {
      const fen = 'k7/8/8/8/8/8/8/r3R2K w - - 0 1';
      const analysis = analyzeEndgames(new Chess(fen));
      expect(analysis.phase).toBe('rook-ending');
      expect(findingsFor(fen, 'rook-ending')[0]?.state).toBe('confirmed');
    });

    it('recognizes strict Lucena-pattern preconditions as a candidate only', () => {
      const fen = 'k7/2P5/2K5/8/8/8/8/r3R3 w - - 0 1';
      const lucena = findingsFor(fen, 'lucena')[0];
      expect(lucena).toBeDefined();
      expect(lucena?.state).toBe('candidate');
      expect(lucena?.possibleConsequence).toMatch(/winning technique are not proved/i);
    });

    it('rejects a Lucena near-miss when the defender king is not cut off', () => {
      const nearMiss = '2k5/2P5/2K5/8/8/8/8/r3R3 w - - 0 1';
      expect(findingsFor(nearMiss, 'lucena')).toHaveLength(0);
    });

    it('recognizes conservative Philidor defensive preconditions as a candidate', () => {
      const fen = 'r6k/8/3R4/8/3p4/8/3K4/8 w - - 0 1';
      const philidor = findingsFor(fen, 'philidor')[0];
      expect(philidor).toBeDefined();
      expect(philidor?.state).toBe('candidate');
      expect(philidor?.side).toBe('w');
      expect(philidor?.possibleConsequence).toMatch(/draw are not proved/i);
    });

    it('rejects the Philidor near-miss without a defender rook on its sixth-rank line', () => {
      const nearMiss = 'r6k/8/8/3R4/3p4/8/3K4/8 w - - 0 1';
      expect(findingsFor(nearMiss, 'philidor')).toHaveLength(0);
    });

    it('withholds the Vancura name unless its unimplemented conditions can be proven', () => {
      const fen = 'r6k/8/8/8/8/8/8/R6K w - - 0 1';
      expect(findingsFor(fen, 'vancura')).toHaveLength(0);
      expect(analyzeEndgames(new Chess(fen)).deferredMotifs.find((entry) => entry.motif === 'vancura')?.state).toBe('deferred');
    });
  });

  describe('minor-piece, bishop and queen endings', () => {
    it('recognizes a minor-piece ending by material inventory', () => {
      const fen = '7k/8/8/8/8/8/2b5/K1B5 w - - 0 1';
      expect(analyzeEndgames(new Chess(fen)).phase).toBe('minor-piece-ending');
      expect(findingsFor(fen, 'minor-piece-ending')[0]?.state).toBe('confirmed');
    });

    it('recognizes opposite-coloured bishops only when the bishops occupy different square colours', () => {
      const opposite = '7k/8/8/8/8/8/2b5/K1B5 w - - 0 1';
      expect(findingsFor(opposite, 'opposite-coloured-bishops')).toHaveLength(1);
      const sameColor = '7k/8/8/8/8/8/1b6/K1B5 w - - 0 1';
      expect(findingsFor(sameColor, 'opposite-coloured-bishops')).toHaveLength(0);
    });

    it('recognizes a queen ending only when both queens remain and other pieces are absent', () => {
      const fen = '7k/8/q7/8/8/8/2Q5/7K w - - 0 1';
      const analysis = analyzeEndgames(new Chess(fen));
      expect(analysis.phase).toBe('queen-ending');
      expect(findingsFor(fen, 'queen-ending')[0]?.state).toBe('confirmed');
    });

    it('does not label a single-queen-versus-bare-king position a queen ending', () => {
      const fen = '7k/8/8/8/8/8/4Q3/K7 w - - 0 1';
      expect(findingsFor(fen, 'queen-ending')).toHaveLength(0);
    });

    it('recognizes standard basic mating material but does not claim mate is delivered', () => {
      const fen = '7k/8/8/8/8/8/4Q3/K7 w - - 0 1';
      const basicMate = findingsFor(fen, 'basic-mating-ending')[0];
      expect(basicMate).toBeDefined();
      expect(basicMate?.state).toBe('candidate');
      expect(basicMate?.possibleConsequence).toMatch(/actual mate delivery/i);
    });

    it('does not label KNN versus bare king as a basic mating ending', () => {
      const fen = '7k/8/8/8/8/8/2NN4/K7 w - - 0 1';
      expect(findingsFor(fen, 'basic-mating-ending')).toHaveLength(0);
    });
  });

  describe('repetition, perpetual check and stalemate resources', () => {
    it('verifies a repeated-check cycle only from replay-validated history', () => {
      let record = createGame({
        id: 'endgame-perpetual',
        initialFen: '7k/5Q2/8/8/8/8/8/K7 w - - 0 1',
        now: '2026-10-05T00:00:00.000Z',
      });
      const moves = ['f7e8', 'h8h7', 'e8f7', 'h7h8', 'f7e8', 'h8h7', 'e8f7', 'h7h8'];
      moves.forEach((move, index) => {
        record = applyMove(record, move, { committedAt: `2026-10-05T00:00:${String(index + 1).padStart(2, '0')}.000Z` }).record;
      });
      const analysis = analyzeEndgames(new Chess(record.currentFen), record);
      const perpetual = analysis.findings.find((finding) => finding.motif === 'perpetual');
      expect(analysis.historyValidation).toBe('validated');
      expect(perpetual).toBeDefined();
      expect(perpetual?.state).toBe('confirmed');
      expect(perpetual?.side).toBe('w');
      expect(perpetual?.possibleConsequence).toMatch(/not a separate automatic FIDE result/i);
    });

    it('does not infer perpetual check from a repeated non-checking cycle', () => {
      let record = createGame({ id: 'endgame-no-perpetual', now: '2026-10-05T00:00:00.000Z' });
      const moves = ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1', 'f6g8'];
      moves.forEach((move, index) => {
        record = applyMove(record, move, { committedAt: `2026-10-05T00:01:${String(index + 1).padStart(2, '0')}.000Z` }).record;
      });
      expect(analyzeEndgames(new Chess(record.currentFen), record).findings.some((finding) => finding.motif === 'perpetual')).toBe(false);
    });

    it('requires history before making any perpetual-check claim', () => {
      const fen = '7k/5Q2/8/8/8/8/8/K7 w - - 0 1';
      const analysis = analyzeEndgames(new Chess(fen));
      expect(analysis.findings.some((finding) => finding.motif === 'perpetual')).toBe(false);
      expect(analysis.deferredMotifs.find((entry) => entry.motif === 'perpetual')?.state).toBe('deferred');
    });

    it('reuses legal move generation to confirm an immediate stalemate resource', () => {
      const fen = '8/8/8/8/8/8/Q7/K1k5 w - - 0 1';
      const stalemate = findingForMove(fen, 'stalemate-resource', 'a2e2');
      expect(stalemate).toBeDefined();
      expect(stalemate?.state).toBe('confirmed');
      expect(stalemate?.legalLine?.outcome).toMatchObject({ kind: 'stalemate', deterministic: true });
    });

    it('rejects a supplied history that does not replay to the analyzed board', () => {
      const record = createGame({ id: 'endgame-invalid-history', now: '2026-10-05T00:00:00.000Z' });
      expect(() => analyzeEndgames(new Chess('4k3/8/8/8/8/8/8/4K3 w - - 0 1'), record)).toThrow(/history/i);
    });
  });
});
