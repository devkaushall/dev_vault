import { describe, expect, it } from 'vitest';
import { createGame, applyMove } from '../domain/chess/session';
import { createOpeningQuizQuestion, lookupOpeningAtPosition, parseOpeningTsv, recognizeGameOpening, submitOpeningAnswer } from './openings';

const TSV = `eco\tname\tpgn\nA04\tKnight's Opening\t1. Nf3 d5 2. d4\nD00\tQueen Pawn Game\t1. d4 d5 2. Nf3\nB00\tKing's Pawn Opening\t1. e4 e5 2. Nf3\nC44\tFour Knights Game\t1. e4 e5 2. Nf3 Nc6\n`;

describe('offline opening recognition', () => {
  it('parses legal PGN records and collapses transposed move orders by position', () => {
    const catalog = parseOpeningTsv(TSV);
    expect(catalog.entries).toHaveLength(4);
    expect(catalog.skippedRows).toBe(0);
    const transposedMoves = [...catalog.entries[0].uciMoves, 'g8f6', 'f3g1', 'f6g8', 'g1f3'];
    const transposed = lookupOpeningAtPosition(catalog, catalog.entries[0].finalFen, transposedMoves);
    expect(transposed?.kind).toBe('transposition');
    expect(transposed?.confidence).toBe('medium');
    expect(transposed?.entries.map((entry) => entry.name)).toEqual(["Knight's Opening", 'Queen Pawn Game']);
  });

  it('reports an exact sequence distinctly from a transposition', () => {
    const catalog = parseOpeningTsv(TSV);
    const entry = catalog.entries[0];
    expect(lookupOpeningAtPosition(catalog, entry.finalFen, entry.uciMoves)?.kind).toBe('exact-sequence');
  });

  it('finds the deepest known opening position in a longer game history', () => {
    const catalog = parseOpeningTsv(TSV);
    let game = createGame({ id: 'opening-game' });
    for (const uci of ['g1f3', 'd7d5', 'd2d4', 'g8f6']) game = applyMove(game, uci).record;
    const match = recognizeGameOpening(game, catalog);
    expect(match?.entries.map((entry) => entry.name)).toContain("Knight's Opening");
    expect(match?.matchedPly).toBe(3);
  });

  it('does not produce a quiz answer until submission and accepts transposition aliases', () => {
    const catalog = parseOpeningTsv(TSV);
    const question = createOpeningQuizQuestion(catalog, () => 0.01)!;
    expect(question.options).toHaveLength(4);
    expect(question.options).toContain(question.acceptedNames[0]);
    expect(submitOpeningAnswer(question, 'not an opening')).toMatchObject({ correct: false });
    expect(submitOpeningAnswer(question, question.acceptedNames.at(-1)!)).toMatchObject({ correct: true });
  });

  it('skips malformed rows without treating a bad row as authority', () => {
    const catalog = parseOpeningTsv(`${TSV}not-a-valid-row\nZ99\tFake\t1. e4`);
    expect(catalog.entries).toHaveLength(4);
    expect(catalog.skippedRows).toBe(2);
  });
});
