import { Chess } from 'chess.js';
import type { OpeningEntry } from './openings';
import { assertKnowledgeFinding, type KnowledgeEvidence, type KnowledgeFinding, type KnowledgeProvenance } from './evidence';
import { positionKey } from '../domain/chess/position';

export type OpeningDatasetProvenance = Extract<KnowledgeProvenance, { kind: 'lichess-opening-dataset' }>;
type DatasetProvenance = OpeningDatasetProvenance;

type OpeningFamilyCuration = {
  id: string;
  label: string;
  section: string;
  basis: string;
};

export type OpeningHierarchy = {
  family?: { id: string; label: string; provenance: KnowledgeProvenance };
  opening: string;
  variation?: string;
  subvariation?: string;
  labelPath: string[];
  provenance: KnowledgeProvenance[];
};

export type OpeningClaimCategory = 'typical-plan' | 'pawn-break' | 'piece-placement' | 'tactical-idea' | 'counterplan';
export type OpeningGambitState = 'offered' | 'accepted' | 'declined';

export type OpeningGambitStatus = {
  name: string;
  state: OpeningGambitState;
  finding: KnowledgeFinding;
};

export type OpeningKnowledgeBundle = {
  typicalPlans: KnowledgeFinding[];
  pawnBreaks: KnowledgeFinding[];
  piecePlacements: KnowledgeFinding[];
  tacticalIdeas: KnowledgeFinding[];
  counterplans: KnowledgeFinding[];
  gambitStatus: OpeningGambitStatus[];
};

type CuratedClaim = {
  category: OpeningClaimCategory;
  id: string;
  label: string;
  evidenceDescription: string;
  sourceSection: string;
  sourceBasis: string;
  confidence: number;
  relevance: number;
  implication?: { side: 'w' | 'b'; description: string; condition?: string };
};

type CuratedGambit = {
  name: string;
  state: OpeningGambitState;
  evidenceDescription: string;
  sourceSection: string;
  sourceBasis: string;
  confidence: number;
  relevance: number;
};

type CuratedRecord = {
  id: string;
  eco: string;
  name: string;
  pgn: string;
  claims?: readonly CuratedClaim[];
  gambit?: CuratedGambit;
};

type PreparedRecord = CuratedRecord & {
  uciMoves: string[];
  finalFen: string;
  positionKey: string;
};

const FAMILY_BY_OPENING: Readonly<Record<string, OpeningFamilyCuration>> = {
  'Italian Game': {
    id: 'open-games', label: 'Open Games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas maps 1.e4 e5 to Open Games and lists the Italian among those openings.',
  },
  'Ruy Lopez': {
    id: 'open-games', label: 'Open Games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas maps 1.e4 e5 to Open Games and lists the Ruy Lopez among those openings.',
  },
  'Scotch Game': {
    id: 'open-games', label: 'Open Games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas maps 1.e4 e5 to Open Games and lists the Scotch among those openings.',
  },
  'Four Knights Game': {
    id: 'open-games', label: 'Open Games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas maps 1.e4 e5 to Open Games and lists Four Knights among those openings.',
  },
  'French Defense': {
    id: 'semi-open-games', label: 'Semi-open games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas classifies 1.e4 replies other than ...e5 as semi-open and names the French.',
  },
  'French Defence': {
    id: 'semi-open-games', label: 'Semi-open games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas classifies 1.e4 replies other than ...e5 as semi-open and names the French.',
  },
  'Sicilian Defense': {
    id: 'semi-open-games', label: 'Semi-open games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas classifies 1.e4 replies other than ...e5 as semi-open and names the Sicilian.',
  },
  'Sicilian Defence': {
    id: 'semi-open-games', label: 'Semi-open games', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas classifies 1.e4 replies other than ...e5 as semi-open and names the Sicilian.',
  },
  "Queen's Gambit": {
    id: 'queens-pawn-closed', label: "Queen's-pawn/closed families", section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas places 1.d4 d5 openings, including the Queen’s Gambit, in the Queen’s-pawn/closed family.',
  },
  "Queen's Gambit Accepted": {
    id: 'queens-pawn-closed', label: "Queen's-pawn/closed families", section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas places 1.d4 d5 openings, including the Queen’s Gambit, in the Queen’s-pawn/closed family.',
  },
  "Queen's Gambit Declined": {
    id: 'queens-pawn-closed', label: "Queen's-pawn/closed families", section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas places 1.d4 d5 openings, including the Queen’s Gambit, in the Queen’s-pawn/closed family.',
  },
  'Slav Defense': {
    id: 'queens-pawn-closed', label: "Queen's-pawn/closed families", section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas includes the Slav among the 1.d4 d5 Queen’s-pawn/closed families.',
  },
  'English Opening': {
    id: 'flank-openings', label: 'Flank openings', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas identifies 1.c4 and the English as a flank opening.',
  },
  "King's Indian Defense": {
    id: 'indian-related-defenses', label: 'Indian/related defences', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas groups the King’s Indian among Indian and related defences.',
  },
  'King’s Indian Defense': {
    id: 'indian-related-defenses', label: 'Indian/related defences', section: '§1.1 पहली चाल का बड़ा नक्शा',
    basis: 'Atlas groups the King’s Indian among Indian and related defences.',
  },
};

/** Curated claims are intentionally independent of the CC0 name/ECO/move index. */
const CURATED_RECORDS: readonly CuratedRecord[] = [
  {
    id: 'italian-two-knights-branch',
    eco: 'C55',
    name: 'Italian Game: Two Knights Defense',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6',
    claims: [
      {
        category: 'tactical-idea', id: 'sharp-two-knights-lines', label: 'The Two Knights branch has sharper tactical sub-lines',
        evidenceDescription: 'The exact sequence includes 3...Nf6; the Atlas names Fried Liver and Traxler as deeper sharp sub-lines of this branch.',
        sourceSection: '§1.2 Italian Game',
        sourceBasis: 'The Atlas identifies 3...Nf6 as the Two Knights Defence and cites Fried Liver/Traxler among its sharp sub-lines.',
        confidence: 0.91, relevance: 0.7,
        implication: { side: 'w', description: 'Treat later tactical claims as line-specific and calculate legal replies; this opening cue itself is not a tactic or proof of an advantage.' },
      },
    ],
  },
  {
    id: 'french-advance-pawn-chain',
    eco: 'C02',
    name: 'French Defense: Advance Variation',
    pgn: '1. e4 e6 2. d4 d5 3. e5',
    claims: [
      {
        category: 'pawn-break', id: 'french-chain-breaks', label: 'Black can challenge the chain with ...c5 or ...f6',
        evidenceDescription: 'The recognized sequence forms White’s e5-d4 chain against Black’s e6-d5 pawns.',
        sourceSection: '§1.3 French Defence; §3.2 French pawn chain',
        sourceBasis: 'The Atlas identifies ...c5 as pressure on the chain base d4 and sometimes ...f6 against its head e5.',
        confidence: 0.9, relevance: 0.84,
        implication: { side: 'b', description: 'Consider a timely ...c5 against d4 or ...f6 against e5, subject to development and concrete tactics.', condition: 'These are candidate breaks, not mandatory moves.' },
      },
      {
        category: 'counterplan', id: 'french-white-chain-plan', label: 'White may use kingside space or stabilize the centre',
        evidenceDescription: 'The exact advance sequence establishes the e5-d4 pawn chain; the Atlas describes these as White’s common strategic choices.',
        sourceSection: '§3.2 French pawn chain',
        sourceBasis: 'The Atlas says White may use the French chain for kingside space/attack or stabilize the centre.',
        confidence: 0.85, relevance: 0.73,
        implication: { side: 'w', description: 'Choose between preserving the chain’s space and stabilizing it according to the opponent’s breaks.', condition: 'The correct plan depends on piece placement and the current pawn tension.' },
      },
    ],
  },
  {
    id: 'italian-game-giuoco-piano',
    eco: 'C50',
    name: 'Italian Game: Giuoco Piano',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5',
    claims: [
      {
        category: 'typical-plan', id: 'central-c3-d4', label: 'Prepare central expansion with c3 and d4',
        evidenceDescription: 'The recognized Italian Giuoco Piano line ends after 3...Bc5; the Atlas associates this branch with c3/d4 plans.',
        sourceSection: '§1.2 Italian Game',
        sourceBasis: '“Giuoco Piano ... c3/d4 योजनाएँ” (the Atlas describes c3/d4 as plans, not forced moves).',
        confidence: 0.88, relevance: 0.76,
        implication: { side: 'w', description: 'Consider c3 and a later d4 only when development and the current position support the central expansion.', condition: 'A conditional plan, not a move recommendation or engine evaluation.' },
      },
      {
        category: 'piece-placement', id: 'bishop-c4-f7-diagonal', label: 'The bishop on c4 eyes the f7 diagonal',
        evidenceDescription: 'The defining sequence includes Bc4 and the recognized position keeps the bishop on c4, facing the f7 diagonal.',
        sourceSection: '§1.2 Italian Game',
        sourceBasis: 'The Atlas identifies the c4 bishop’s early attention to f7 as an Italian Game cue.',
        confidence: 0.95, relevance: 0.65,
        implication: { side: 'w', description: 'Keep f7 and the diagonal in view; do not infer a tactical win without calculating replies.' },
      },
    ],
  },
  {
    id: 'italian-game-giuoco-pianissimo',
    eco: 'C50',
    name: 'Italian Game: Giuoco Pianissimo',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. d3',
    claims: [
      {
        category: 'typical-plan', id: 'quiet-d3-setup', label: 'A quieter Italian setup with d3',
        evidenceDescription: 'The exact line includes White’s d3 move; the Atlas calls the d3 branch Giuoco Pianissimo and contrasts it with c3/d4 plans.',
        sourceSection: '§1.2 Italian Game',
        sourceBasis: 'The Atlas describes quiet d3 as Giuoco Pianissimo and lists c3/d4 plans in the Italian family.',
        confidence: 0.94, relevance: 0.82,
        implication: { side: 'w', description: 'Continue development and reassess whether a later central expansion is feasible.', condition: 'The label describes a common setup; it does not prescribe a fixed continuation.' },
      },
    ],
  },
  {
    id: 'ruy-lopez-berlin-defense',
    eco: 'C65',
    name: 'Ruy Lopez: Berlin Defense',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6',
    claims: [
      {
        category: 'piece-placement', id: 'bishop-b5-pressure', label: 'The b5 bishop pressures the c6 knight that guards e5',
        evidenceDescription: 'The defining sequence places White’s bishop on b5 and Black’s knight on c6; the Atlas identifies the knight as a defender of e5.',
        sourceSection: '§1.2 Ruy Lopez / Spanish',
        sourceBasis: 'The Atlas says the b5 bishop pressures c6-knight, which defends e5.',
        confidence: 0.95, relevance: 0.8,
        implication: { side: 'w', description: 'The e5-centre can be a long-term pressure target; check whether exchanges or ...a6 alter the position.' },
      },
      {
        category: 'typical-plan', id: 'ruy-lopez-d4', label: 'Central d4 play can be a long-term plan',
        evidenceDescription: 'The recognized line is the Berlin branch beginning 3...Nf6; the Atlas lists central d4 as an important Ruy Lopez plan.',
        sourceSection: '§1.2 Ruy Lopez / Spanish',
        sourceBasis: 'The Atlas describes long-term pressure on e5 and says central d4 is often important.',
        confidence: 0.85, relevance: 0.71,
        implication: { side: 'w', description: 'Evaluate d4 as a candidate central break when it is supported and tactically sound.', condition: 'The break is position-dependent.' },
      },
    ],
  },
  {
    id: 'queens-gambit-offer',
    eco: 'D06',
    name: "Queen's Gambit",
    pgn: '1. d4 d5 2. c4',
    claims: [
      {
        category: 'typical-plan', id: 'challenge-d5', label: 'The c-pawn challenges d5 and seeks central influence',
        evidenceDescription: 'The exact sequence ends with White’s c-pawn on c4 challenging Black’s d5-pawn.',
        sourceSection: '§1.4 Queen’s Gambit',
        sourceBasis: 'The Atlas identifies 2.c4 as a challenge to d5 and a bid for central influence.',
        confidence: 0.96, relevance: 0.88,
        implication: { side: 'w', description: 'Use the c4-pawn and development to contest the centre; check the resulting position rather than assume the pawn is permanently lost.' },
      },
    ],
    gambit: {
      name: "Queen's Gambit", state: 'offered',
      evidenceDescription: 'White has played 2.c4; the Atlas distinguishes acceptance by ...dxc4 and decline by ...e6, ...c6, or other replies.',
      sourceSection: '§1.4 Queen’s Gambit',
      sourceBasis: 'The Atlas calls 2.c4 the Queen’s Gambit, lists ...dxc4/...e6/...c6 as replies, and warns that the c-pawn may be recovered.',
      confidence: 0.94, relevance: 0.9,
    },
  },
  {
    id: 'queens-gambit-accepted',
    eco: 'D20',
    name: "Queen's Gambit Accepted",
    pgn: '1. d4 d5 2. c4 dxc4',
    gambit: {
      name: "Queen's Gambit", state: 'accepted',
      evidenceDescription: 'Black’s d5-pawn has captured the offered c4-pawn with 2...dxc4.',
      sourceSection: '§1.4 Queen’s Gambit',
      sourceBasis: 'The Atlas explicitly labels 2...dxc4 as Accepted and notes that White may later regain the pawn.',
      confidence: 0.99, relevance: 0.95,
    },
  },
  {
    id: 'queens-gambit-declined',
    eco: 'D30',
    name: "Queen's Gambit Declined",
    pgn: '1. d4 d5 2. c4 e6',
    gambit: {
      name: "Queen's Gambit", state: 'declined',
      evidenceDescription: 'Black answered 2.c4 with 2...e6 rather than capturing on c4.',
      sourceSection: '§1.4 Queen’s Gambit',
      sourceBasis: 'The Atlas explicitly labels 2...e6 as Declined.',
      confidence: 0.99, relevance: 0.95,
    },
  },
  {
    id: 'evans-gambit-offered',
    eco: 'C51',
    name: 'Italian Game: Evans Gambit',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4',
    claims: [
      {
        category: 'typical-plan', id: 'evans-development', label: 'Use b4 to gain time on the bishop and prepare c3/d4',
        evidenceDescription: 'White has played the defining b4 pawn offer while Black’s bishop is on c5.',
        sourceSection: '§2 White के आम gambits',
        sourceBasis: 'The Atlas says the Evans Gambit’s 4.b4 aims to gain a tempo on the bishop and play c3/d4 quickly.',
        confidence: 0.96, relevance: 0.87,
        implication: { side: 'w', description: 'Seek development and central play for the pawn; verify the bishop’s actual reply and the concrete position.' },
      },
    ],
    gambit: {
      name: 'Evans Gambit', state: 'offered',
      evidenceDescription: 'The defining move 4.b4 offers the b-pawn to the bishop on c5.',
      sourceSection: '§2 White के आम gambits',
      sourceBasis: 'The Atlas identifies the Evans Gambit as the Italian line beginning 4.b4.',
      confidence: 0.99, relevance: 0.96,
    },
  },
  {
    id: 'evans-gambit-accepted',
    eco: 'C51',
    name: 'Italian Game: Evans Gambit Accepted',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bxb4',
    gambit: {
      name: 'Evans Gambit', state: 'accepted',
      evidenceDescription: 'The sequence continues with ...Bxb4, capturing the offered pawn.',
      sourceSection: '§2 White के आम gambits',
      sourceBasis: 'The Atlas defines the Evans Gambit by 4.b4; the dataset label and legal continuation show that Black accepted with ...Bxb4.',
      confidence: 0.98, relevance: 0.96,
    },
  },
  {
    id: 'evans-gambit-declined',
    eco: 'C51',
    name: 'Italian Game: Evans Gambit Declined',
    pgn: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bb6',
    gambit: {
      name: 'Evans Gambit', state: 'declined',
      evidenceDescription: 'Black declines the offered pawn with ...Bb6 instead of capturing on b4.',
      sourceSection: '§2 White के आम gambits',
      sourceBasis: 'The Atlas says an Evans Gambit offer begins with 4.b4; the legal line and dataset label identify ...Bb6 as the declined branch.',
      confidence: 0.96, relevance: 0.93,
    },
  },
];

function prepareRecord(record: CuratedRecord): PreparedRecord {
  const chess = new Chess();
  chess.loadPgn(record.pgn, { strict: true });
  const moves = chess.history({ verbose: true });
  if (!moves.length) throw new Error(`Curated opening record ${record.id} contains no moves.`);
  return {
    ...record,
    uciMoves: moves.map((move) => `${move.from}${move.to}${move.promotion ?? ''}`),
    finalFen: chess.fen({ forceEnpassantSquare: true }),
    positionKey: positionKey(chess),
  };
}

const PREPARED_RECORDS = CURATED_RECORDS.map(prepareRecord);

function atlasSource(section: string, basis: string): KnowledgeProvenance {
  return { kind: 'chess-atlas', document: 'Chess_Game_Master_Chess_Atlas_HI.md', section, basis };
}

function datasetSourceWithField(source: DatasetProvenance, field: string): DatasetProvenance {
  return { ...source, field };
}

function hierarchyForEntry(entry: OpeningEntry, datasetSource: DatasetProvenance): OpeningHierarchy {
  const colon = entry.name.indexOf(':');
  const opening = (colon < 0 ? entry.name : entry.name.slice(0, colon)).trim();
  const remainder = colon < 0 ? '' : entry.name.slice(colon + 1);
  const path = remainder.split(',').map((part) => part.trim()).filter(Boolean);
  const familyCuration = FAMILY_BY_OPENING[opening];
  const familySource = familyCuration ? atlasSource(familyCuration.section, familyCuration.basis) : undefined;
  const datasetLabelSource = datasetSourceWithField(datasetSource, 'name');
  return {
    ...(familyCuration && familySource ? {
      family: { id: familyCuration.id, label: familyCuration.label, provenance: familySource },
    } : {}),
    opening,
    ...(path[0] ? { variation: path[0] } : {}),
    ...(path[1] ? { subvariation: path[1] } : {}),
    labelPath: [opening, ...path],
    provenance: familySource ? [datasetLabelSource, familySource] : [datasetLabelSource],
  };
}

export function openingHierarchyForEntries(
  entries: readonly OpeningEntry[],
  datasetSource: DatasetProvenance,
): OpeningHierarchy[] {
  const unique = new Map<string, OpeningHierarchy>();
  for (const entry of entries) {
    const hierarchy = hierarchyForEntry(entry, datasetSource);
    const key = JSON.stringify([hierarchy.family?.id, hierarchy.labelPath]);
    if (!unique.has(key)) unique.set(key, hierarchy);
  }
  return [...unique.values()];
}

function makeFinding(
  record: PreparedRecord,
  entry: OpeningEntry,
  datasetSource: DatasetProvenance,
  id: string,
  label: string,
  evidenceDescription: string,
  sourceSection: string,
  sourceBasis: string,
  confidence: number,
  relevance: number,
  implication?: { side: 'w' | 'b'; description: string; condition?: string },
): KnowledgeFinding {
  const source = atlasSource(sourceSection, sourceBasis);
  const evidence: KnowledgeEvidence[] = [
    {
      id: `${id}:recognized-line`,
      kind: 'move-sequence' as const,
      description: evidenceDescription,
      values: { eco: entry.eco, name: entry.name, uciMoves: record.uciMoves, pgn: record.pgn },
    },
    {
      id: `${id}:position`,
      kind: 'board-state' as const,
      description: 'The position key is computed from the legal chess.js replay of the curated sequence.',
      values: { positionKey: record.positionKey, fen: record.finalFen },
    },
  ];
  return assertKnowledgeFinding({
    conceptId: `opening.${record.id}.${id}`,
    label,
    evidence,
    confidence,
    relevance,
    possibleImplications: implication ? [{ side: implication.side, description: implication.description, ...(implication.condition ? { condition: implication.condition } : {}) }] : [],
    provenance: [source, datasetSourceWithField(datasetSource, 'pgn')],
  });
}

export function emptyOpeningKnowledge(): OpeningKnowledgeBundle {
  return { typicalPlans: [], pawnBreaks: [], piecePlacements: [], tacticalIdeas: [], counterplans: [], gambitStatus: [] };
}

export function openingKnowledgeForEntries(
  entries: readonly OpeningEntry[],
  datasetSource: DatasetProvenance,
): OpeningKnowledgeBundle {
  const bundle = emptyOpeningKnowledge();
  for (const record of PREPARED_RECORDS) {
    const entry = entries.find((candidate) =>
      candidate.eco === record.eco && candidate.name === record.name && candidate.positionKey === record.positionKey,
    );
    if (!entry) continue;
    for (const claim of record.claims ?? []) {
      const finding = makeFinding(
        record, entry, datasetSource, claim.id, claim.label, claim.evidenceDescription,
        claim.sourceSection, claim.sourceBasis, claim.confidence, claim.relevance, claim.implication,
      );
      switch (claim.category) {
        case 'typical-plan': bundle.typicalPlans.push(finding); break;
        case 'pawn-break': bundle.pawnBreaks.push(finding); break;
        case 'piece-placement': bundle.piecePlacements.push(finding); break;
        case 'tactical-idea': bundle.tacticalIdeas.push(finding); break;
        case 'counterplan': bundle.counterplans.push(finding); break;
      }
    }
    if (record.gambit) {
      bundle.gambitStatus.push({
        name: record.gambit.name,
        state: record.gambit.state,
        finding: makeFinding(
          record, entry, datasetSource, 'gambit-status', `${record.gambit.name}: ${record.gambit.state}`,
          record.gambit.evidenceDescription, record.gambit.sourceSection, record.gambit.sourceBasis,
          record.gambit.confidence, record.gambit.relevance,
        ),
      });
    }
  }
  return bundle;
}
