import { Chess } from 'chess.js';
import type { GameRecord } from '../domain/chess/types';
import { fenAtPly, positionKey } from '../domain/chess/position';
import type { KnowledgeProvenance } from './evidence';
import {
  openingHierarchyForEntries,
  openingKnowledgeForEntries,
  type OpeningDatasetProvenance,
  type OpeningHierarchy,
  type OpeningKnowledgeBundle,
} from './openingKnowledge';

export const OPENING_DATASET = {
  repository: 'lichess-org/chess-openings',
  commit: '5a13018164f6bd88f48b3dc31a8e2a39f31a060a',
  license: 'CC0-1.0',
  files: ['a.tsv', 'b.tsv', 'c.tsv', 'd.tsv', 'e.tsv'],
} as const;

const OPENING_DATASET_SOURCE: OpeningDatasetProvenance = {
  kind: 'lichess-opening-dataset',
  repository: OPENING_DATASET.repository,
  commit: OPENING_DATASET.commit,
  license: OPENING_DATASET.license,
};

export type OpeningEntry = {
  eco: string;
  name: string;
  pgn: string;
  sanMoves: string[];
  uciMoves: string[];
  positionKey: string;
  finalFen: string;
};

export type OpeningDefiningMove = { ply: number; color: 'w' | 'b'; san: string; uci: string };
export type OpeningDefiningLine = {
  eco: string;
  name: string;
  pgn: string;
  moves: OpeningDefiningMove[];
  positionKey: string;
  provenance: KnowledgeProvenance[];
};

export type OpeningMatch = {
  kind: 'exact-sequence' | 'transposition';
  confidence: 'high' | 'medium';
  matchedPly: number;
  positionKey: string;
  entries: OpeningEntry[];
  hierarchy: OpeningHierarchy[];
  definingLines: OpeningDefiningLine[];
  knowledge: OpeningKnowledgeBundle;
  dataset: typeof OPENING_DATASET;
};

export type OpeningCatalog = {
  entries: OpeningEntry[];
  byPosition: Map<string, OpeningEntry[]>;
  bySequence: Map<string, OpeningEntry[]>;
  skippedRows: number;
};

function push(map: Map<string, OpeningEntry[]>, key: string, entry: OpeningEntry) {
  const values = map.get(key);
  if (values) values.push(entry);
  else map.set(key, [entry]);
}

function createEntry(eco: string, name: string, pgn: string): OpeningEntry {
  const chess = new Chess();
  chess.loadPgn(pgn, { strict: true });
  const moves = chess.history({ verbose: true });
  if (!moves.length) throw new Error('Opening row contains no moves.');
  return {
    eco,
    name,
    pgn,
    sanMoves: moves.map((move) => move.san),
    uciMoves: moves.map((move) => `${move.from}${move.to}${move.promotion ?? ''}`),
    positionKey: positionKey(chess),
    finalFen: chess.fen({ forceEnpassantSquare: true }),
  };
}

export function parseOpeningTsv(contents: string): OpeningCatalog {
  const lines = contents.replace(/^\uFEFF/, '').split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (!lines.length || lines[0].trim().toLowerCase() !== 'eco\tname\tpgn') throw new Error('Opening dataset header is invalid.');
  const entries: OpeningEntry[] = [];
  let skippedRows = 0;
  for (const line of lines.slice(1)) {
    const firstTab = line.indexOf('\t');
    const secondTab = line.indexOf('\t', firstTab + 1);
    if (firstTab < 1 || secondTab < firstTab + 2) {
      skippedRows++;
      continue;
    }
    const eco = line.slice(0, firstTab).trim();
    const name = line.slice(firstTab + 1, secondTab).trim();
    const pgn = line.slice(secondTab + 1).trim();
    if (!/^[A-E]\d\d$/i.test(eco) || !name || !pgn) {
      skippedRows++;
      continue;
    }
    try {
      entries.push(createEntry(eco.toUpperCase(), name, pgn));
    } catch {
      skippedRows++;
    }
  }
  const byPosition = new Map<string, OpeningEntry[]>();
  const bySequence = new Map<string, OpeningEntry[]>();
  for (const entry of entries) {
    push(byPosition, entry.positionKey, entry);
    push(bySequence, entry.uciMoves.join(' '), entry);
  }
  for (const [key, values] of byPosition) {
    byPosition.set(key, values.sort((a, b) => a.eco.localeCompare(b.eco) || a.name.localeCompare(b.name)));
  }
  return { entries, byPosition, bySequence, skippedRows };
}

export async function loadBundledOpeningCatalog(fetcher: typeof fetch = fetch): Promise<OpeningCatalog> {
  const responses = await Promise.all(OPENING_DATASET.files.map(async (file) => {
    const response = await fetcher(`/data/openings/${file}`);
    if (!response.ok) throw new Error(`Opening data is unavailable (${file}, HTTP ${response.status}).`);
    return response.text();
  }));
  const catalogs = responses.map(parseOpeningTsv);
  const entries = catalogs.flatMap((catalog) => catalog.entries);
  const byPosition = new Map<string, OpeningEntry[]>();
  const bySequence = new Map<string, OpeningEntry[]>();
  for (const entry of entries) {
    push(byPosition, entry.positionKey, entry);
    push(bySequence, entry.uciMoves.join(' '), entry);
  }
  for (const values of byPosition.values()) values.sort((a, b) => a.eco.localeCompare(b.eco) || a.name.localeCompare(b.name));
  return { entries, byPosition, bySequence, skippedRows: catalogs.reduce((sum, catalog) => sum + catalog.skippedRows, 0) };
}

function definingLinesFor(entries: readonly OpeningEntry[]): OpeningDefiningLine[] {
  return entries.map((entry) => ({
    eco: entry.eco,
    name: entry.name,
    pgn: entry.pgn,
    moves: entry.uciMoves.map((uci, index) => ({
      ply: index + 1,
      color: index % 2 === 0 ? 'w' : 'b',
      san: entry.sanMoves[index] ?? '',
      uci,
    })),
    positionKey: entry.positionKey,
    provenance: [{ ...OPENING_DATASET_SOURCE, field: 'pgn' }],
  }));
}

export function lookupOpeningAtPosition(catalog: OpeningCatalog, fen: string, uciMoves: string[] = []): OpeningMatch | undefined {
  const key = positionKey(new Chess(fen));
  const entries = catalog.byPosition.get(key);
  if (!entries?.length) return undefined;
  const exactSequence = entries.some((entry) => entry.uciMoves.length === uciMoves.length && entry.uciMoves.every((uci, index) => uci === uciMoves[index]));
  return {
    kind: exactSequence ? 'exact-sequence' : 'transposition',
    confidence: exactSequence ? 'high' : 'medium',
    matchedPly: uciMoves.length,
    positionKey: key,
    entries: [...entries],
    hierarchy: openingHierarchyForEntries(entries, { ...OPENING_DATASET_SOURCE, field: 'name' }),
    definingLines: definingLinesFor(entries),
    knowledge: openingKnowledgeForEntries(entries, OPENING_DATASET_SOURCE),
    dataset: OPENING_DATASET,
  };
}

/** Search backwards for the deepest exact database position already seen in this game. */
export function recognizeGameOpening(record: GameRecord, catalog: OpeningCatalog): OpeningMatch | undefined {
  for (let ply = record.cursorPly; ply >= 0; ply--) {
    const fen = fenAtPly(record, ply);
    const moves = record.moveHistory.slice(0, ply).map((move) => move.uci);
    const match = lookupOpeningAtPosition(catalog, fen, moves);
    if (match) return { ...match, matchedPly: ply };
  }
  return undefined;
}

export type OpeningQuizQuestion = {
  id: string;
  fen: string;
  uciMoves: string[];
  options: string[];
  acceptedNames: string[];
  eco: string;
  datasetCommit: string;
};

export function createOpeningQuizQuestion(catalog: OpeningCatalog, random: () => number = Math.random): OpeningQuizQuestion | undefined {
  const candidates = catalog.entries.filter((entry) => {
    const aliases = catalog.byPosition.get(entry.positionKey) ?? [];
    const names = [...new Set(aliases.map((item) => item.name))];
    return entry.uciMoves.length >= 4 && names.length <= 2;
  });
  if (!candidates.length) return undefined;
  const selected = candidates[Math.min(candidates.length - 1, Math.floor(Math.max(0, random()) * candidates.length))];
  const aliases = catalog.byPosition.get(selected.positionKey) ?? [selected];
  const acceptedNames = [...new Set(aliases.map((entry) => entry.name))];
  const distractors = [...new Set(catalog.entries.filter((entry) => !acceptedNames.includes(entry.name)).map((entry) => entry.name))];
  const randomIndex = (limit: number) => Math.min(limit - 1, Math.floor(Math.max(0, random()) * limit));
  const options = [...acceptedNames, ...distractors.slice(0, Math.max(0, 4 - acceptedNames.length))];
  // Deterministic shuffling via the supplied RNG also keeps quiz tests repeatable.
  for (let index = options.length - 1; index > 0; index--) {
    const swapIndex = randomIndex(index + 1);
    [options[index], options[swapIndex]] = [options[swapIndex], options[index]];
  }
  return {
    id: `opening:${selected.eco}:${selected.positionKey}`,
    fen: selected.finalFen,
    uciMoves: [...selected.uciMoves],
    options,
    acceptedNames,
    eco: selected.eco,
    datasetCommit: OPENING_DATASET.commit,
  };
}

export function submitOpeningAnswer(question: OpeningQuizQuestion, answer: string): { correct: boolean; acceptedNames: string[] } {
  return { correct: question.acceptedNames.includes(answer), acceptedNames: [...question.acceptedNames] };
}
