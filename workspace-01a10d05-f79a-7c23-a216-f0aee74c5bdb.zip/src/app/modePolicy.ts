import type { GameMode } from '../domain/chess/types';
import { isStockfishRuntimeAvailable } from '../engine/engineGate';

const stockfishAvailable = isStockfishRuntimeAvailable();

export type ModePolicy = {
  mode: GameMode;
  /** Engine modes cannot be entered unless the approved engine is genuinely bundled and enabled. */
  available: boolean;
  acceptsBoardMoves: boolean;
  engineOpponent: boolean;
  userInitiatedAnalysis: boolean;
  requestHints: boolean;
  takebacks: 'unlimited' | 'logged' | 'none';
  originalHistoryImmutable: boolean;
  revealSolutionsBeforeAnswer: boolean;
  competitiveHumanPlay: false;
};

export const MODE_POLICY: Record<GameMode, ModePolicy> = {
  Learn: {
    mode: 'Learn', available: true, acceptsBoardMoves: true, engineOpponent: false, userInitiatedAnalysis: false,
    requestHints: true, takebacks: 'logged', originalHistoryImmutable: false, revealSolutionsBeforeAnswer: false, competitiveHumanPlay: false,
  },
  Practice: {
    mode: 'Practice', available: true, acceptsBoardMoves: true, engineOpponent: false, userInitiatedAnalysis: true,
    requestHints: true, takebacks: 'unlimited', originalHistoryImmutable: false, revealSolutionsBeforeAnswer: true, competitiveHumanPlay: false,
  },
  Challenge: {
    mode: 'Challenge', available: stockfishAvailable, acceptsBoardMoves: stockfishAvailable, engineOpponent: stockfishAvailable, userInitiatedAnalysis: false,
    requestHints: false, takebacks: 'none', originalHistoryImmutable: false, revealSolutionsBeforeAnswer: false, competitiveHumanPlay: false,
  },
  CoachedPractice: {
    mode: 'CoachedPractice', available: stockfishAvailable, acceptsBoardMoves: stockfishAvailable, engineOpponent: stockfishAvailable,
    userInitiatedAnalysis: stockfishAvailable, requestHints: stockfishAvailable, takebacks: 'logged',
    originalHistoryImmutable: false, revealSolutionsBeforeAnswer: false, competitiveHumanPlay: false,
  },
  Review: {
    mode: 'Review', available: true, acceptsBoardMoves: false, engineOpponent: false, userInitiatedAnalysis: true,
    requestHints: true, takebacks: 'none', originalHistoryImmutable: true, revealSolutionsBeforeAnswer: true, competitiveHumanPlay: false,
  },
  Puzzle: {
    mode: 'Puzzle', available: true, acceptsBoardMoves: true, engineOpponent: false, userInitiatedAnalysis: false,
    requestHints: true, takebacks: 'none', originalHistoryImmutable: false, revealSolutionsBeforeAnswer: false, competitiveHumanPlay: false,
  },
  OpeningTraining: {
    mode: 'OpeningTraining', available: true, acceptsBoardMoves: true, engineOpponent: false, userInitiatedAnalysis: false,
    requestHints: true, takebacks: 'none', originalHistoryImmutable: false, revealSolutionsBeforeAnswer: false, competitiveHumanPlay: false,
  },
};

export function modePolicy(mode: GameMode): ModePolicy {
  return MODE_POLICY[mode];
}
