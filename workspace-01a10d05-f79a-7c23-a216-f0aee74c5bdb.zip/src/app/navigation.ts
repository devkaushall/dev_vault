export type ScreenId = 'home' | 'learn' | 'practice' | 'engine' | 'review' | 'puzzles' | 'openings' | 'history' | 'settings';

export const NAV_ITEMS: Array<{ id: ScreenId; label: string; icon: string; group: 'play' | 'library' }> = [
  { id: 'home', label: 'मुखपृष्ठ', icon: '⌂', group: 'play' },
  { id: 'learn', label: 'सीखें', icon: '✧', group: 'play' },
  { id: 'practice', label: 'अभ्यास बोर्ड', icon: '▦', group: 'play' },
  { id: 'engine', label: 'इंजन से खेलें', icon: '♟', group: 'play' },
  { id: 'review', label: 'खेल की समीक्षा', icon: '↺', group: 'play' },
  { id: 'puzzles', label: 'पहेलियाँ', icon: '✦', group: 'library' },
  { id: 'openings', label: 'ओपनिंग', icon: '⌘', group: 'library' },
  { id: 'history', label: 'सहेजे खेल', icon: '▤', group: 'library' },
  { id: 'settings', label: 'सेटिंग', icon: '⚙', group: 'library' },
];
