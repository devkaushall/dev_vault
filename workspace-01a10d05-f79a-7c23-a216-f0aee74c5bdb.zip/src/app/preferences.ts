export const TIME_CONTROL_PRESETS = [
  { id: 'untimed', label: 'बिना घड़ी', baseSeconds: 0, incrementSeconds: 0 },
  { id: '180+0', label: '3 + 0', baseSeconds: 180, incrementSeconds: 0 },
  { id: '180+2', label: '3 + 2', baseSeconds: 180, incrementSeconds: 2 },
  { id: '300+0', label: '5 + 0', baseSeconds: 300, incrementSeconds: 0 },
  { id: '600+5', label: '10 + 5', baseSeconds: 600, incrementSeconds: 5 },
] as const;

export type TimeControlPresetId = (typeof TIME_CONTROL_PRESETS)[number]['id'];
export type BoardOrientation = 'w' | 'b';
export type ReducedMotionChoice = 'system' | 'reduce' | 'full';
export type AppPreferences = {
  coordinates: boolean;
  boardOrientation: BoardOrientation;
  reducedMotion: ReducedMotionChoice;
  timeControlPresetId: TimeControlPresetId;
};

const STORAGE_KEY = 'chess-game-master.preferences.v1';
const DEFAULT_PREFERENCES: AppPreferences = {
  coordinates: true,
  boardOrientation: 'w',
  reducedMotion: 'system',
  timeControlPresetId: 'untimed',
};

function isTimeControlPreset(value: unknown): value is TimeControlPresetId {
  return TIME_CONTROL_PRESETS.some((preset) => preset.id === value);
}

export function isAppPreferences(value: unknown): value is AppPreferences {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const raw = value as Record<string, unknown>;
  return typeof raw.coordinates === 'boolean'
    && (raw.boardOrientation === 'b' || raw.boardOrientation === 'w')
    && (raw.reducedMotion === 'system' || raw.reducedMotion === 'reduce' || raw.reducedMotion === 'full')
    && isTimeControlPreset(raw.timeControlPresetId);
}

function preferencesFrom(value: unknown): AppPreferences {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return { ...DEFAULT_PREFERENCES };
  const raw = value as Record<string, unknown>;
  return {
    coordinates: typeof raw.coordinates === 'boolean' ? raw.coordinates : DEFAULT_PREFERENCES.coordinates,
    boardOrientation: raw.boardOrientation === 'b' || raw.boardOrientation === 'w' ? raw.boardOrientation : DEFAULT_PREFERENCES.boardOrientation,
    reducedMotion: raw.reducedMotion === 'system' || raw.reducedMotion === 'reduce' || raw.reducedMotion === 'full'
      ? raw.reducedMotion
      : DEFAULT_PREFERENCES.reducedMotion,
    timeControlPresetId: isTimeControlPreset(raw.timeControlPresetId) ? raw.timeControlPresetId : DEFAULT_PREFERENCES.timeControlPresetId,
  };
}

export function readAppPreferences(): AppPreferences {
  try {
    const serialized = globalThis.localStorage?.getItem(STORAGE_KEY);
    return serialized ? preferencesFrom(JSON.parse(serialized)) : { ...DEFAULT_PREFERENCES };
  } catch {
    return { ...DEFAULT_PREFERENCES };
  }
}

export function updateAppPreferences(patch: Partial<AppPreferences>): { preferences: AppPreferences; persisted: boolean } {
  const preferences = preferencesFrom({ ...readAppPreferences(), ...patch });
  let persisted = false;
  try {
    globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify(preferences));
    persisted = Boolean(globalThis.localStorage);
  } catch {
    // Keep the preference active for the current view even if browser storage is disabled.
  }
  return { preferences, persisted };
}

export function replaceAppPreferences(value: unknown): boolean {
  if (!isAppPreferences(value)) return false;
  try {
    if (!globalThis.localStorage) return false;
    globalThis.localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    applyReducedMotionPreference(value.reducedMotion);
    return true;
  } catch {
    return false;
  }
}

export function applyReducedMotionPreference(choice: ReducedMotionChoice): void {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.motion = choice;
}

export function timeControlForPreset(id: TimeControlPresetId): { baseSeconds: number; incrementSeconds: number } | undefined {
  const preset = TIME_CONTROL_PRESETS.find((entry) => entry.id === id);
  return !preset || preset.id === 'untimed' ? undefined : { baseSeconds: preset.baseSeconds, incrementSeconds: preset.incrementSeconds };
}

export function presetForClock(clock?: { baseMs: number; incrementMs: number }): TimeControlPresetId | undefined {
  if (!clock) return undefined;
  return TIME_CONTROL_PRESETS.find((preset) => preset.baseSeconds * 1000 === clock.baseMs && preset.incrementSeconds * 1000 === clock.incrementMs)?.id;
}
