import { afterEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { App } from './App';
import { LocalChessStore } from '../storage/LocalChessStore';

afterEach(() => vi.unstubAllGlobals());

describe('application shell', () => {
  it('keeps the skip link as the first keyboard stop on load and focuses main after route changes', async () => {
    const user = userEvent.setup();
    render(<App />);
    const skipLink = screen.getByRole('link', { name: 'मुख्य सामग्री पर जाएँ' });
    const main = screen.getByRole('main');

    await user.tab();
    expect(skipLink).toHaveFocus();
    expect(skipLink).toHaveAttribute('href', '#main-content');

    await user.click(screen.getByRole('button', { name: 'सीखें' }));
    await waitFor(() => expect(main).toHaveFocus());
  });

  it('navigates between local modes and visibly blocks the unlicensed engine', async () => {
    const user = userEvent.setup();
    render(<App />);
    expect(screen.getByRole('heading', { name: /स्थिति समझें/ })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'इंजन से खेलें' }));
    expect(screen.getByRole('heading', { name: 'इंजन प्रतिद्वंद्वी अभी उपलब्ध नहीं' })).toBeInTheDocument();
    expect(screen.getByText(/कोई chess engine शामिल या चुपचाप बदला नहीं गया/)).toBeInTheDocument();
    expect(screen.getByText(/लिखित GPLv3 स्वीकृति आवश्यक/)).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'सीखें' }));
    expect(screen.getByRole('heading', { name: 'चाल चलकर सीखें' })).toBeInTheDocument();
  });

  it('saves, returns home, and resumes an active Practice game at the saved position', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    await user.click(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));
    await waitFor(() => expect(screen.getByText('इस डिवाइस पर सहेजा')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /^मुखपृष्ठ$/ }));
    await user.click(await screen.findByRole('button', { name: /अभ्यास जारी रखें: White बनाम Black/ }));
    expect(screen.getByRole('gridcell', { name: 'e4 पर सफ़ेद प्यादा' })).toBeInTheDocument();
    expect(screen.getByRole('gridcell', { name: 'e7 पर काले प्यादा' })).toBeInTheDocument();
  });

  it('starts timed Practice only on demand, persists a paused clock across Home resume, and keeps Review clock-free', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    await user.selectOptions(screen.getByRole('combobox', { name: 'नई बाज़ी के लिए समय नियंत्रण' }), '180+0');
    await user.click(screen.getByRole('button', { name: 'नया बोर्ड' }));
    expect(screen.getAllByText('03:00')).toHaveLength(2);
    const startClock = screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' });
    expect(startClock).toHaveAttribute('aria-pressed', 'false');
    expect(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' })).toHaveAttribute('aria-disabled', 'true');

    await user.click(startClock);
    await user.click(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));
    expect(screen.getByRole('gridcell', { name: 'e4 पर सफ़ेद प्यादा' })).toBeInTheDocument();
    expect(screen.getByRole('gridcell', { name: 'e7 पर काले प्यादा' })).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'घड़ी रोकें' }));
    expect(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' })).toHaveAttribute('aria-pressed', 'false');
    expect(screen.getByRole('gridcell', { name: 'e7 पर काले प्यादा' })).toHaveAttribute('aria-disabled', 'true');
    await waitFor(() => expect(screen.getByText('इस डिवाइस पर सहेजा')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /^मुखपृष्ठ$/ }));
    const resumes = await screen.findAllByRole('button', { name: /अभ्यास जारी रखें: White बनाम Black/ });
    const resume = resumes.find((button) => button.textContent?.includes('घड़ी रुकी'));
    if (!resume) throw new Error('Timed Practice was not offered as a paused Home resume.');
    expect(resume).toHaveTextContent('घड़ी रुकी');
    await user.click(resume);
    expect(screen.getByRole('gridcell', { name: 'e4 पर सफ़ेद प्यादा' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' })).toHaveAttribute('aria-pressed', 'false');

    await user.click(screen.getByRole('button', { name: /^मुखपृष्ठ$/ }));
    const reviewActions = await screen.findAllByRole('button', { name: 'खेल की समीक्षा करें: White बनाम Black' });
    await user.click(reviewActions[0]);
    await user.click(await screen.findByRole('button', { name: 'Start self-review' }));
    expect(screen.getByRole('heading', { name: 'Replay & reflect' })).toBeInTheDocument();
    expect(screen.queryByRole('region', { name: 'अभ्यास की समय घड़ी' })).not.toBeInTheDocument();
  });

  it('applies saved Settings defaults to the next Practice board', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'सेटिंग खोलें' }));
    await user.click(screen.getByRole('checkbox', { name: 'Show board coordinates' }));
    await user.selectOptions(screen.getByRole('combobox', { name: 'Default board orientation' }), 'b');
    await user.selectOptions(screen.getByRole('combobox', { name: 'Default Practice time control' }), '180+0');

    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    expect(screen.getByRole('combobox', { name: 'नई बाज़ी के लिए समय नियंत्रण' })).toHaveValue('180+0');
    expect(document.querySelector('.file-labels')).not.toBeInTheDocument();
    const squares = within(screen.getByRole('grid', { name: /शतरंज बोर्ड/ })).getAllByRole('gridcell');
    expect(squares[0]).toHaveAccessibleName('h1 पर सफ़ेद हाथी');
    expect(squares[63]).toHaveAccessibleName('a8 पर काले हाथी');

    await user.click(screen.getByRole('button', { name: 'नया बोर्ड' }));
    expect(screen.getAllByText('03:00')).toHaveLength(2);
  });

  it('does not save an untouched scratch board, then persists it with its first legal move', async () => {
    const user = userEvent.setup();
    localStorage.removeItem('chess-game-master.preferences.v1');
    const store = new LocalChessStore();
    const beforeIds = new Set((await store.listGames()).map((game) => game.id));
    render(<App />);
    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    expect(await screen.findByText('पहली चाल पर सहेजा जाएगा')).toBeInTheDocument();
    expect((await store.listGames()).map((game) => game.id)).toEqual([...beforeIds]);

    await user.click(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));
    await waitFor(() => expect(screen.getByText('इस डिवाइस पर सहेजा')).toBeInTheDocument());
    const newGames = (await store.listGames()).filter((game) => !beforeIds.has(game.id));
    expect(newGames).toHaveLength(1);
    expect(newGames[0].moveHistory.map((move) => move.uci)).toEqual(['e2e4']);
    await store.close();
  });

  it('automatically pauses on a hidden tab and never resumes without a user action', async () => {
    const user = userEvent.setup();
    const visibilityDescriptor = Object.getOwnPropertyDescriptor(document, 'visibilityState');
    render(<App />);

    try {
      await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
      await user.selectOptions(screen.getByRole('combobox', { name: 'नई बाज़ी के लिए समय नियंत्रण' }), '180+0');
      await user.click(screen.getByRole('button', { name: 'नया बोर्ड' }));
      await user.click(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' }));

      Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'hidden' });
      fireEvent(document, new Event('visibilitychange'));
      expect(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' })).toHaveAttribute('aria-pressed', 'false');
      expect(screen.getByText(/ऐप छिपने या अभ्यास छोड़ने पर घड़ी रुक गई/)).toBeInTheDocument();
      Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'visible' });
      fireEvent(document, new Event('visibilitychange'));
      expect(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' })).toBeInTheDocument();
      await user.click(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' }));
      expect(screen.getByRole('button', { name: 'घड़ी रोकें' })).toHaveAttribute('aria-pressed', 'true');
    } finally {
      if (visibilityDescriptor) Object.defineProperty(document, 'visibilityState', visibilityDescriptor);
      else Reflect.deleteProperty(document, 'visibilityState');
    }
  });

  it('records an actual timer flag and locks the game when a complete timeout result is not proven', async () => {
    const user = userEvent.setup();
    let nowMs = 0;
    vi.spyOn(performance, 'now').mockImplementation(() => nowMs);
    render(<App />);

    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    await user.selectOptions(screen.getByRole('combobox', { name: 'नई बाज़ी के लिए समय नियंत्रण' }), '180+0');
    await user.click(screen.getByRole('button', { name: 'नया बोर्ड' }));
    await user.click(screen.getByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' }));
    nowMs = 181_000;

    await waitFor(() => expect(screen.getAllByText('समय समाप्त · परिणाम का निर्णय लंबित')).toHaveLength(2));
    expect(screen.getAllByText('00:00')).toHaveLength(1);
    expect(screen.queryByRole('button', { name: 'घड़ी शुरू / फिर चलाएँ' })).not.toBeInTheDocument();
    expect(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' })).toHaveAttribute('aria-disabled', 'true');
  });

  it('records Practice abort as stopped with no fabricated win, loss, or draw', async () => {
    const user = userEvent.setup();
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(true);
    render(<App />);
    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    await user.click(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));
    await waitFor(() => expect(screen.getByText('इस डिवाइस पर सहेजा')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: 'बिना परिणाम अभ्यास रोकें' }));
    expect(confirm).toHaveBeenCalledWith(expect.stringMatching(/कोई जीत, हार या ड्रॉ परिणाम/));
    expect(await screen.findByText('खेल रोका गया · कोई शतरंज परिणाम दर्ज नहीं')).toBeInTheDocument();
    expect(screen.getByRole('gridcell', { name: 'e4 पर सफ़ेद प्यादा' })).toHaveAttribute('aria-disabled', 'true');
    confirm.mockRestore();
  });

  it('records a confirmed local draw agreement as a game-ending result', async () => {
    const user = userEvent.setup();
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(true);
    render(<App />);
    await user.click(screen.getByRole('button', { name: /^अभ्यास बोर्ड$/ }));
    await user.click(screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));
    const agree = await screen.findByRole('button', { name: 'दोनों पक्ष ड्रॉ पर सहमत' });
    await user.click(agree);
    expect(confirm).toHaveBeenCalledWith(expect.stringMatching(/दोनों पक्ष/));
    expect(await screen.findByText(/1\/2-1\/2 · ड्रॉ पर सहमति/)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'दोनों पक्ष ड्रॉ पर सहमत' })).not.toBeInTheDocument();
    confirm.mockRestore();
  });

  it('offers a waiting service-worker update only for explicit user activation', async () => {
    const user = userEvent.setup();
    const waitingWorker = { postMessage: vi.fn() } as unknown as ServiceWorker;
    const registration = {
      waiting: waitingWorker,
      installing: null,
      update: vi.fn(async () => undefined),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    } as unknown as ServiceWorkerRegistration;
    const serviceWorkerContainer = {
      ready: Promise.resolve(registration),
      controller: {} as ServiceWorker,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    } as unknown as ServiceWorkerContainer;
    vi.stubGlobal('navigator', new Proxy(window.navigator, {
      has(target, property) {
        return property === 'serviceWorker' || Reflect.has(target, property);
      },
      get(target, property) {
        if (property === 'serviceWorker') return serviceWorkerContainer;
        return Reflect.get(target, property, target);
      },
    }));

    render(<App />);
    const activate = await screen.findByRole('button', { name: 'अपडेट और पुनः लोड करें' });
    expect(screen.getByText(/आपकी पुष्टि की प्रतीक्षा कर रहा है/)).toBeInTheDocument();
    expect(waitingWorker.postMessage).not.toHaveBeenCalled();
    await user.click(activate);
    expect(waitingWorker.postMessage).toHaveBeenCalledWith({ type: 'ACTIVATE_UPDATE' });
  });

  it('hides the closed mobile navigation from keyboard users and restores focus after Escape', async () => {
    const user = userEvent.setup();
    vi.stubGlobal('matchMedia', vi.fn().mockImplementation((media: string) => ({
      media,
      matches: true,
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })));
    render(<App />);
    const sidebar = document.getElementById('app-sidebar')!;
    const mainShell = document.querySelector('.app-main-shell')!;
    const toggle = screen.getByRole('button', { name: 'नेविगेशन खोलें' });
    expect(sidebar).toHaveAttribute('aria-hidden', 'true');
    expect(sidebar).toHaveAttribute('inert');
    expect(mainShell).not.toHaveAttribute('inert');

    await user.click(toggle);
    expect(sidebar).toHaveAttribute('aria-hidden', 'false');
    expect(mainShell).toHaveAttribute('inert');
    expect(screen.getByRole('button', { name: /^मुखपृष्ठ$/ })).toHaveFocus();
    await user.keyboard('{Escape}');
    await waitFor(() => expect(toggle).toHaveFocus());
    expect(sidebar).toHaveAttribute('inert');
  });
});
