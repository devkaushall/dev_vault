import { describe, expect, it } from 'vitest';
import { MODE_POLICY, modePolicy } from './modePolicy';
import { isStockfishRuntimeAvailable, STOCKFISH_LICENSING_GATE } from '../engine/engineGate';

describe('mode separation', () => {
  it('blocks Challenge and Coached Practice until approved Stockfish is actually bundled and enabled', () => {
    expect(STOCKFISH_LICENSING_GATE).toMatchObject({
      approvalStatus: 'pending-written-approval',
      bundled: false,
      workerImplemented: false,
      runtimeReady: false,
      featureEnabled: false,
    });
    expect(isStockfishRuntimeAvailable()).toBe(false);
    expect(modePolicy('Challenge')).toMatchObject({
      available: false,
      acceptsBoardMoves: false,
      engineOpponent: false,
      requestHints: false,
      userInitiatedAnalysis: false,
      takebacks: 'none',
    });
    expect(modePolicy('CoachedPractice')).toMatchObject({
      available: false,
      acceptsBoardMoves: false,
      engineOpponent: false,
      requestHints: false,
      userInitiatedAnalysis: false,
    });
    expect(Object.values(MODE_POLICY).every((policy) => policy.competitiveHumanPlay === false)).toBe(true);
  });

  it('preserves Practice and Review policies without advertising an unapproved engine', () => {
    expect(modePolicy('Practice')).toMatchObject({ available: true, engineOpponent: false, userInitiatedAnalysis: true });
    expect(modePolicy('Review')).toMatchObject({ available: true, originalHistoryImmutable: true });
  });

  it('keeps puzzle and opening answers hidden until user submission', () => {
    expect(modePolicy('Puzzle').revealSolutionsBeforeAnswer).toBe(false);
    expect(modePolicy('OpeningTraining').revealSolutionsBeforeAnswer).toBe(false);
  });
});
