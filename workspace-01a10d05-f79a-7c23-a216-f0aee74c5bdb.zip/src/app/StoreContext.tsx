import { createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import { LocalChessStore } from '../storage/LocalChessStore';

const StoreContext = createContext<LocalChessStore | null>(null);

export function StoreProvider({ store, children }: { store: LocalChessStore; children: ReactNode }) {
  return <StoreContext.Provider value={store}>{children}</StoreContext.Provider>;
}

export function useLocalStore(): LocalChessStore {
  const store = useContext(StoreContext);
  if (!store) throw new Error('LocalChessStore provider is missing.');
  return store;
}
