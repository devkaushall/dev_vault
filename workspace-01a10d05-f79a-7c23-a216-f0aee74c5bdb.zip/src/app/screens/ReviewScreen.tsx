import { useEffect, useState } from 'react';
import { ChessWorkspace } from '../../components/ChessWorkspace';
import { exportFen, importPgn } from '../../domain/chess/pgn';
import { createGame } from '../../domain/chess/session';
import type { GameRecord } from '../../domain/chess/types';
import { useLocalStore } from '../StoreContext';

export type ReviewScreenProps = {
  initialRecord?: GameRecord;
};

function createReviewCopy(source: GameRecord): GameRecord {
  const now = new Date().toISOString();
  return {
    ...source,
    id: `review-${crypto.randomUUID()}`,
    createdAt: now,
    updatedAt: now,
    mode: 'Review',
    status: 'reviewing',
    clock: undefined,
    pgnHeaders: source.pgnHeaders ? { ...source.pgnHeaders } : undefined,
    players: { white: { ...source.players.white }, black: { ...source.players.black } },
    moveHistory: source.moveHistory.map((move) => ({ ...move })),
    repetitionKeys: [...source.repetitionKeys],
    events: [...source.events],
    variations: source.variations.map((variation) => ({ ...variation, uciMoves: [...variation.uciMoves] })),
    notes: `Review copy of ${source.id}. The source game is unchanged.`,
  };
}

export function ReviewScreen({ initialRecord }: ReviewScreenProps) {
  const store = useLocalStore();
  const [savedGames, setSavedGames] = useState<GameRecord[]>([]);
  const [candidate, setCandidate] = useState<GameRecord>();
  const [retryRecord, setRetryRecord] = useState<GameRecord>();
  const [warnings, setWarnings] = useState<string[]>([]);
  const [pgn, setPgn] = useState('');
  const [error, setError] = useState('');
  const [reviewing, setReviewing] = useState(false);
  const [selfReviewNote, setSelfReviewNote] = useState('');
  const [storageError, setStorageError] = useState('');
  const [fileLabel, setFileLabel] = useState('');

  useEffect(() => {
    let active = true;
    void store.listGames().then((games) => {
      if (active) setSavedGames(games.filter((game) => game.moveHistory.length > 0));
    }).catch((reason: unknown) => setStorageError(reason instanceof Error ? reason.message : 'Saved games could not be loaded.'));
    return () => { active = false; };
  }, [store]);

  useEffect(() => {
    if (!initialRecord) return;
    const prepared = createReviewCopy(initialRecord);
    setCandidate(prepared);
    // Saved-game entry points must see the same self-review prompt as PGN imports.
    // Replay starts only after the user explicitly continues from this setup screen.
    setReviewing(false);
  }, [initialRecord]);

  const parsePgn = () => {
    setError('');
    try {
      const result = importPgn(pgn);
      setCandidate(result.record);
      setRetryRecord(undefined);
      setWarnings(result.warnings);
      setReviewing(false);
      setSelfReviewNote('');
    } catch (reason) {
      setCandidate(undefined);
      setWarnings([]);
      setError(reason instanceof Error ? reason.message : 'PGN could not be parsed.');
    }
  };

  const readFile = async (file?: File) => {
    if (!file) return;
    setFileLabel(file.name);
    setError('');
    if (file.size > 500_000) {
      setError('PGN file is too large (maximum 500 KB).');
      return;
    }
    try {
      setPgn(await file.text());
      setCandidate(undefined);
      setWarnings([]);
      setReviewing(false);
    } catch {
      setError('Could not read the selected file.');
    }
  };

  const selectSaved = (game: GameRecord) => {
    const candidateRecord = createReviewCopy(game);
    setCandidate(candidateRecord);
    setRetryRecord(undefined);
    setWarnings([]);
    setError('');
    setReviewing(false);
    setSelfReviewNote('');
  };

  const startReview = async () => {
    if (!candidate) return;
    try {
      const prepared = { ...candidate, notes: selfReviewNote.trim() ? `Self-review prompt: ${selfReviewNote.trim().slice(0, 1000)}` : candidate.notes };
      await store.saveGame(prepared);
      setCandidate(prepared);
      setRetryRecord(undefined);
      setReviewing(true);
      setStorageError('');
    } catch (reason) {
      setStorageError(reason instanceof Error ? reason.message : 'Review record could not be saved.');
    }
  };

  const stopReview = () => {
    setReviewing(false);
    setCandidate(undefined);
    setRetryRecord(undefined);
  };

  const startRetry = (source: GameRecord) => {
    const retry = createGame({ mode: 'Practice', initialFen: exportFen(source, source.cursorPly) });
    setCandidate(source);
    setRetryRecord({
      ...retry,
      notes: `Retry branch of review ${source.id} from ply ${source.cursorPly}. The original review history is unchanged.`,
    });
  };

  if (reviewing && candidate && retryRecord) {
    return (
      <div>
        <div className="review-return-bar"><button className="button-quiet" type="button" onClick={() => setRetryRecord(undefined)}>← मूल समीक्षा पर लौटें</button><span>अलग अभ्यास-शाखा · मूल खेल अपरिवर्तित</span></div>
        <ChessWorkspace key={retryRecord.id} mode="Practice" initialRecord={retryRecord} title="इस स्थिति पर अभ्यास" description={`मूल समीक्षा ${candidate.id} की ply ${candidate.cursorPly} से नई स्थानीय शाखा। मूल चाल-इतिहास नहीं बदलेगा।`} />
      </div>
    );
  }

  if (reviewing && candidate) {
    return (
      <div>
        <div className="review-return-bar"><button className="button-quiet" type="button" onClick={stopReview}>← Back to games</button><span>Review copy · source game unchanged</span></div>
        <ChessWorkspace key={candidate.id} mode="Review" initialRecord={candidate} onRetry={startRetry} title="Replay & reflect" description={candidate.notes?.startsWith('Self-review prompt:') ? `${candidate.notes} · Source game is unchanged.` : 'Review copy is read-only. Use move navigation to revisit moments; engine analysis is unavailable while licensing approval is pending.'} />
      </div>
    );
  }

  return (
    <section className="screen-content review-screen">
      <header className="screen-heading">
        <div><p className="eyebrow">REVIEW · ORIGINAL HISTORY PROTECTED</p><h1>Review a game</h1><p className="screen-description">Import a completed PGN or choose a saved game. Your self-review comes first; engine analysis remains unavailable until licensing is approved.</p></div>
        <span className="mode-pill mode-review">REVIEW · ENGINE GATED</span>
      </header>
      {storageError && <div className="save-warning" role="alert">Local storage: {storageError}</div>}
      <div className="review-import-grid">
        <section className="review-import-card">
          <div className="query-card-heading"><div><p className="eyebrow">IMPORT</p><h2>Paste a PGN game</h2></div><span className="icon-chip">⌁</span></div>
          <label className="field-label" htmlFor="pgn-input">PGN text</label>
          <textarea id="pgn-input" className="pgn-textarea" value={pgn} onChange={(event) => setPgn(event.target.value)} rows={8} spellCheck={false} placeholder={'[Event "Casual game"]\n[Result "*"]\n\n1. e4 e5 2. Nf3 Nc6 *'} />
          <div className="review-import-actions"><button className="button-primary" type="button" onClick={parsePgn}>Validate PGN</button><label className="button-secondary file-upload-label">Choose .pgn file<input type="file" accept=".pgn,text/plain" onChange={(event) => void readFile(event.target.files?.[0])} /></label></div>
          {fileLabel && <p className="small-note">Selected file: {fileLabel}</p>}
          {error && <p className="form-error" role="alert">{error}</p>}
          <p className="small-note">Standard chess only · 500 KB max · malformed notation is rejected. Imported names/comments are treated as untrusted text.</p>
        </section>
        <section className="saved-game-picker">
          <div className="query-card-heading"><div><p className="eyebrow">ON THIS DEVICE</p><h2>Saved games</h2></div><span className="saved-count">{savedGames.length}</span></div>
          {savedGames.length ? (
            <ul className="saved-game-list">
              {savedGames.slice(0, 8).map((game) => (
                <li key={game.id}>
                  <button type="button" className={`saved-game-item${candidate?.id === game.id ? ' saved-game-selected' : ''}`} onClick={() => selectSaved(game)}>
                    <span className="saved-game-icon" aria-hidden="true">♞</span>
                    <span><strong>{game.players.white.displayName || 'White'} vs {game.players.black.displayName || 'Black'}</strong><small>{new Date(game.updatedAt).toLocaleDateString()} · {game.moveHistory.length} ply · {game.mode}</small></span>
                    <span aria-hidden="true">›</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : <div className="saved-empty"><span aria-hidden="true">▤</span><p>No saved games yet. Play in Practice or import a PGN.</p></div>}
        </section>
      </div>

      {candidate && (
        <section className="review-preview-card">
          <div><p className="eyebrow">REVIEW SETUP</p><h2>{candidate.pgnHeaders?.Event || 'Game ready to review'}</h2><p>{candidate.players.white.displayName} vs {candidate.players.black.displayName} · {candidate.moveHistory.length} half-moves · {candidate.result?.score ?? 'unfinished'}</p></div>
          {warnings.length > 0 && <ul className="warning-list">{warnings.map((warning, index) => <li key={index}>{warning}</li>)}</ul>}
          <label className="field-label" htmlFor="self-review-note">Before replay: what do you want to understand?</label>
          <textarea id="self-review-note" value={selfReviewNote} onChange={(event) => setSelfReviewNote(event.target.value)} rows={2} placeholder="For example: where did the king become exposed? (optional)" maxLength={1000} />
          <div className="review-preview-actions"><span className="small-note">The original line will remain read-only.</span><button className="button-primary" type="button" onClick={() => void startReview()}>Start self-review</button></div>
          {storageError && <p className="form-error" role="alert">Game not saved: {storageError}</p>}
        </section>
      )}
    </section>
  );
}
