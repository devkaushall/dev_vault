import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { StoreProvider } from '../StoreContext';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { OpeningsScreen } from './OpeningsScreen';

let counter = 0;
const line = 'eco\tname\tpgn\nB00\tKing\'s Knight Opening\t1. e4 e5 2. Nf3 Nc6\n';
const empty = 'eco\tname\tpgn\n';

function makeStore() {
  return new LocalChessStore(indexedDB, `opening-screen-test-${++counter}`);
}

describe('opening recognition screen', () => {
  it('persists opening hints, answer, and a local progress summary without overwriting a session', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => ({
      ok: true,
      status: 200,
      text: async () => String(input).endsWith('/a.tsv') ? line : empty,
    })));
    const { unmount } = render(<StoreProvider store={store}><OpeningsScreen /></StoreProvider>);

    await waitFor(() => expect(screen.getByText('1 नाम सूचीबद्ध')).toBeInTheDocument());
    await user.click(screen.getByRole('tab', { name: 'पहचान अभ्यास' }));
    expect(await screen.findByRole('heading', { name: 'इस स्थिति से मेल खाता opening label चुनें' })).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'संकेत देखें' }));
    await user.click(screen.getByRole('button', { name: "King's Knight Opening" }));

    await waitFor(async () => {
      const progress = await store.listProgress('opening');
      expect(progress).toHaveLength(1);
      expect(progress[0].payload).toMatchObject({ status: 'answered', correct: true, hintLevel: 1, datasetCommit: expect.any(String) });
    });
    expect(screen.getByText(/स्थानीय प्रगति: 1 सत्र · 1\/1 सही · 1 संकेत/)).toBeInTheDocument();
    expect(await screen.findByText(/सही — यह label स्थानीय opening index/)).toBeInTheDocument();

    unmount();
    await store.close();
    vi.unstubAllGlobals();
  });

  it('supports tab-arrow navigation and exposes a labelled tab panel', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => ({
      ok: true,
      status: 200,
      text: async () => String(input).endsWith('/a.tsv') ? line : empty,
    })));
    const { unmount } = render(<StoreProvider store={store}><OpeningsScreen /></StoreProvider>);

    await waitFor(() => expect(screen.getByRole('tab', { name: 'पहचान अभ्यास' })).toBeEnabled());
    const lookup = screen.getByRole('tab', { name: 'चाल-क्रम खोजें' });
    lookup.focus();
    await user.keyboard('{ArrowRight}');
    const training = screen.getByRole('tab', { name: 'पहचान अभ्यास' });
    expect(training).toHaveFocus();
    expect(training).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByRole('tabpanel', { name: 'पहचान अभ्यास' })).toBeInTheDocument();

    unmount();
    await store.close();
    vi.unstubAllGlobals();
  });

  it('shows only an exact indexed position and identifies its evidence type', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => ({
      ok: true,
      status: 200,
      text: async () => String(input).endsWith('/a.tsv') ? line : empty,
    })));
    const { unmount } = render(<StoreProvider store={store}><OpeningsScreen /></StoreProvider>);

    await waitFor(() => expect(screen.getByText('1 नाम सूचीबद्ध')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: 'इस स्थिति की पहचान करें' }));
    expect(await screen.findByText('चाल-क्रम का सटीक मिलान · ply 4 तक।')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: "King's Knight Opening" })).toBeInTheDocument();
    expect(screen.getByText('उच्च भरोसा')).toBeInTheDocument();
    expect(screen.getByText('चाल-क्रम स्थानीय dataset की दर्ज पंक्ति से मेल खाता है।')).toBeInTheDocument();

    unmount();
    await store.close();
    vi.unstubAllGlobals();
  });
});
