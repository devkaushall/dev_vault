import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { applyMove, createGame } from '../../domain/chess/session';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { StoreProvider } from '../StoreContext';
import { HomeScreen } from './HomeScreen';

let counter = 0;
function makeStore(name = `home-screen-test-${++counter}`) {
  return new LocalChessStore(indexedDB, name);
}

async function corruptGameRow(name: string, record: unknown): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.open(name, 2);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const database = request.result;
      const transaction = database.transaction('games', 'readwrite');
      transaction.objectStore('games').put(record);
      transaction.oncomplete = () => { database.close(); resolve(); };
      transaction.onerror = () => { database.close(); reject(transaction.error); };
      transaction.onabort = () => { database.close(); reject(transaction.error); };
    };
  });
}

describe('home dashboard', () => {
  it('shows an unavailable-storage message rather than crashing without IndexedDB', async () => {
    const store = new LocalChessStore(null, 'unavailable-storage');
    const { unmount } = render(
      <StoreProvider store={store}>
        <HomeScreen onNavigate={vi.fn()} onReview={vi.fn()} onResume={vi.fn()} />
      </StoreProvider>,
    );
    expect(await screen.findByRole('alert')).toHaveTextContent(/डिवाइस पर सहेजे खेल नहीं पढ़ सके/);
    unmount();
  });

  it('shows a recovery notice after isolating corrupt local data', async () => {
    const dbName = `home-recovery-test-${++counter}`;
    const seed = makeStore(dbName);
    const bad = createGame({ id: 'broken-home-game' });
    await seed.saveGame(bad);
    await seed.close();
    await corruptGameRow(dbName, { ...bad, currentFen: 'corrupted' });

    const store = makeStore(dbName);
    const onNavigate = vi.fn();
    const { unmount } = render(
      <StoreProvider store={store}>
        <HomeScreen onNavigate={onNavigate} onReview={vi.fn()} onResume={vi.fn()} />
      </StoreProvider>,
    );
    expect(await screen.findByRole('status')).toHaveTextContent(/1 खराब रिकॉर्ड सुरक्षित recovery/);
    await userEvent.setup().click(screen.getByRole('button', { name: 'सहेजे खेल खोलें' }));
    expect(onNavigate).toHaveBeenCalledWith('history');

    unmount();
    await store.close();
  });

  it('shows saved-game count and opens a recent game directly in review', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    let game = createGame({ id: 'home-recent-game', now: '2026-10-05T00:00:00.000Z' });
    game = applyMove(game, 'e2e4').record;
    await store.saveGame(game);
    const onReview = vi.fn();
    const onResume = vi.fn();
    const onNavigate = vi.fn();
    const { unmount } = render(
      <StoreProvider store={store}>
        <HomeScreen onNavigate={onNavigate} onReview={onReview} onResume={onResume} />
      </StoreProvider>,
    );

    expect(await screen.findByText('इस डिवाइस पर · 1 सहेजे खेल')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /अभ्यास जारी रखें: White बनाम Black/ }));
    expect(onResume).toHaveBeenCalledWith(expect.objectContaining({ id: 'home-recent-game' }));
    await user.click(screen.getByRole('button', { name: /खेल की समीक्षा करें: White बनाम Black/ }));
    expect(onReview).toHaveBeenCalledWith(expect.objectContaining({ id: 'home-recent-game' }));
    await waitFor(() => expect(onNavigate).not.toHaveBeenCalled());

    unmount();
    await store.close();
  });
});
