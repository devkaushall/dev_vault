import { describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { StoreProvider } from '../StoreContext';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { getVerifiedMateInOneSolutions, CURATED_PUZZLES } from '../../learning/puzzles';
import { PuzzleScreen } from './PuzzleScreen';

let counter = 0;
function makeStore() {
  return new LocalChessStore(indexedDB, `puzzle-screen-test-${++counter}`);
}

describe('curated puzzle screen', () => {
  it('records reset as a new attempt and clears the visible hint ladder without deleting history', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><PuzzleScreen /></StoreProvider>);

    await user.click(screen.getByRole('button', { name: 'संकेत दें' }));
    expect(screen.getByText(/काले राजा के बच निकलने वाले चौखाने देखें/)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'फिर शुरू करें' }));
    expect(screen.queryByText(/काले राजा के बच निकलने वाले चौखाने देखें/)).not.toBeInTheDocument();
    expect(screen.getByText('इस सत्र के संकेत').parentElement).toHaveTextContent('0');
    await waitFor(async () => {
      const payload = (await store.listProgress('puzzle'))[0]?.payload;
      expect(payload).toMatchObject({ hintLevel: 0, attempts: [expect.objectContaining({ outcome: 'reset', hintLevel: 1 })] });
    });

    unmount();
    await store.close();
  });

  it('keeps the solution hidden, shows a progressive hint, and verifies mate legally', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><PuzzleScreen /></StoreProvider>);
    expect(screen.getByRole('heading', { name: 'वज़ीर और राजा का तालमेल' })).toBeInTheDocument();
    expect(screen.queryByText(/LEGAL SOLUTIONS/)).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'संकेत दें' }));
    expect(screen.getByText(/काले राजा के बच निकलने वाले चौखाने देखें/)).toBeInTheDocument();

    const solution = getVerifiedMateInOneSolutions(CURATED_PUZZLES[0])[0];
    const fromSquare = screen.getAllByRole('gridcell').find((cell) => cell.getAttribute('aria-label')?.startsWith(`${solution.uci.slice(0, 2)} पर`));
    if (!fromSquare) throw new Error('The verified mate source square is not available.');
    await user.click(fromSquare);
    const targetName = await waitFor(() => {
      const match = screen.getAllByRole('gridcell').find((cell) => cell.getAttribute('aria-label')?.includes(`${solution.uci.slice(2, 4)}, वैध गंतव्य`));
      if (!match) throw new Error('The verified mate destination is not available.');
      return match.getAttribute('aria-label')!;
    });
    await user.click(screen.getByRole('gridcell', { name: targetName }));

    expect(await screen.findByRole('heading', { name: 'मात मिली' })).toBeInTheDocument();
    await waitFor(async () => expect((await store.listProgress('puzzle'))[0]?.payload).toMatchObject({ solved: true, hintLevel: 1 }));

    unmount();
    await store.close();
  });
});
