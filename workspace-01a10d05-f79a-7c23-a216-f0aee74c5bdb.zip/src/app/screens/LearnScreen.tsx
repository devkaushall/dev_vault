import { useEffect, useMemo, useState } from 'react';
import { ChessBoard } from '../../components/ChessBoard';
import { applyMove, createGame } from '../../domain/chess/session';
import { derivePosition } from '../../domain/chess/position';
import type { GameRecord, UciMove } from '../../domain/chess/types';
import { CURATED_LESSONS, lessonHint, validateLessonMove } from '../../learning/lessons';
import { useLocalStore } from '../StoreContext';

const CATEGORY_LABELS: Record<(typeof CURATED_LESSONS)[number]['category'], string> = {
  rules: 'नियम', tactics: 'रणनीति', strategy: 'योजना', openings: 'ओपनिंग', endgames: 'एंडगेम',
};

export type LessonAttempt = {
  id: string;
  lessonId: string;
  createdAt: string;
  outcome: 'correct' | 'incorrect' | 'illegal';
  moveUci?: string;
  moveSan?: string;
  hintLevel: number;
};

export function LearnScreen() {
  const store = useLocalStore();
  const [selectedId, setSelectedId] = useState(CURATED_LESSONS[0].id);
  const lesson = CURATED_LESSONS.find((entry) => entry.id === selectedId) ?? CURATED_LESSONS[0];
  const [game, setGame] = useState<GameRecord>(() => createGame({ mode: 'Learn', initialFen: lesson.fen }));
  const [hintLevel, setHintLevel] = useState(0);
  const [hintText, setHintText] = useState('');
  const [attempts, setAttempts] = useState<LessonAttempt[]>([]);
  const [completed, setCompleted] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [storageError, setStorageError] = useState('');
  const [saveLabel, setSaveLabel] = useState('');
  const position = useMemo(() => derivePosition(game), [game]);

  useEffect(() => {
    let active = true;
    void store.listProgress('lesson').then((records) => {
      const saved = records.find((record) => record.id === `lesson:${lesson.id}`);
      if (!active || !saved) return;
      const payload = saved.payload as { attempts?: LessonAttempt[]; hintLevel?: number; completed?: boolean; successfulMove?: string };
      setAttempts(payload.attempts ?? []);
      setHintLevel(payload.hintLevel ?? 0);
      setCompleted(payload.completed ?? false);
      if (payload.completed && payload.successfulMove) {
        try {
          setGame(applyMove(createGame({ mode: 'Learn', initialFen: lesson.fen }), payload.successfulMove, { source: 'lesson' }).record);
        } catch { /* stale or edited progress never overrides the curated lesson */ }
      }
    }).catch((error: unknown) => setStorageError(error instanceof Error ? error.message : 'Could not load lesson progress.'));
    return () => { active = false; };
  }, [lesson.id, lesson.fen, store]);

  useEffect(() => {
    setGame(createGame({ mode: 'Learn', initialFen: lesson.fen }));
    setHintLevel(0);
    setHintText('');
    setAttempts([]);
    setCompleted(false);
    setFeedback('');
  }, [lesson.id, lesson.fen]);

  const persist = async (nextAttempts: LessonAttempt[], nextHint: number, done: boolean, successfulMove?: string) => {
    setSaveLabel('प्रगति सहेज रहे हैं…');
    try {
      await store.saveProgress({
        id: `lesson:${lesson.id}`,
        type: 'lesson',
        updatedAt: new Date().toISOString(),
        payload: { attempts: nextAttempts, hintLevel: nextHint, completed: done, successfulMove, lessonVersion: lesson.version },
      });
      setStorageError('');
      setSaveLabel('प्रगति इस डिवाइस पर सहेजी गई');
    } catch (error) {
      setStorageError(error instanceof Error ? error.message : 'Could not save lesson progress.');
      setSaveLabel('प्रगति सहेजी नहीं गई');
    }
  };

  const handleMove = (move: UciMove) => {
    const uci = `${move.from}${move.to}${move.promotion ?? ''}`;
    const checked = validateLessonMove(lesson, uci);
    const attempt: LessonAttempt = {
      id: crypto.randomUUID(),
      lessonId: lesson.id,
      createdAt: new Date().toISOString(),
      outcome: checked.status,
      moveUci: uci,
      moveSan: checked.san,
      hintLevel,
    };
    const nextAttempts = [...attempts, attempt];
    setAttempts(nextAttempts);
    setFeedback(checked.status === 'correct' ? `${checked.san} — लक्ष्य पूरा हुआ।` : checked.explanation);
    const nextDone = checked.status === 'correct';
    setCompleted(nextDone);
    void persist(nextAttempts, hintLevel, nextDone, nextDone ? uci : undefined);
    if (nextDone) {
      try { setGame(applyMove(game, move, { source: 'lesson', committedAt: attempt.createdAt }).record); }
      catch (error) { setFeedback(error instanceof Error ? error.message : 'The answer could not be displayed.'); }
    }
  };

  const giveHint = () => {
    const next = lessonHint(lesson, hintLevel);
    setHintLevel(next.hintLevel);
    setHintText(next.text);
    void persist(attempts, next.hintLevel, completed);
  };

  const reset = () => {
    setGame(createGame({ mode: 'Learn', initialFen: lesson.fen }));
    setCompleted(false);
    setHintLevel(0);
    setHintText('');
    setFeedback('नया प्रयास शुरू हुआ। पुराने प्रयास स्थानीय प्रगति में सुरक्षित हैं।');
    // Reset is a fresh attempt, not a deletion of attempt history or a reuse of old hints.
    void persist(attempts, 0, false);
  };

  return (
    <section className="screen-content training-screen">
      <header className="screen-heading">
        <div><p className="eyebrow">सीखें · बोर्ड पर नियम</p><h1>चाल चलकर सीखें</h1><p className="screen-description">छोटे, interactive पाठ। हर चाल rules library से जाँची जाती है; संकेत क्रमशः खुलते हैं और प्रयास स्थानीय रूप से सहेजे जाते हैं।</p></div>
        <span className="mode-pill mode-learn">सीखना · इंजन बंद</span>
      </header>
      {storageError && <div className="save-warning" role="alert"><strong>प्रगति सहेजने में समस्या।</strong> {storageError}</div>}
      <div className="lesson-layout">
        <aside className="lesson-list-card" aria-label="Lesson list">
          <p className="eyebrow">शुरुआती पाठ-क्रम</p>
          <h2>नियम और बोर्ड कौशल</h2>
          <ol>
            {CURATED_LESSONS.map((item, index) => (
              <li key={item.id}>
                <button className={`lesson-list-item${item.id === lesson.id ? ' lesson-current' : ''}`} type="button" onClick={() => setSelectedId(item.id)} aria-current={item.id === lesson.id ? 'step' : undefined}>
                  <span className="lesson-step-number">{String(index + 1).padStart(2, '0')}</span>
                  <span><strong>{item.title}</strong><small>{CATEGORY_LABELS[item.category]} · एक चाल</small></span>
                  <span className="lesson-chevron" aria-hidden="true">›</span>
                </button>
              </li>
            ))}
          </ol>
          <div className="curated-note"><span aria-hidden="true">✦</span><p>संपादित शुरुआती सामग्री<br /><strong>5 पाठ · कोई रेटिंग नहीं</strong></p></div>
        </aside>
        <article className="lesson-main-card">
          <div className="lesson-objective-row"><div><p className="eyebrow">पाठ {String(CURATED_LESSONS.findIndex((item) => item.id === lesson.id) + 1).padStart(2, '0')} · {CATEGORY_LABELS[lesson.category]}</p><h2>{lesson.title}</h2></div><span className="step-count">संकेत {hintLevel} / {lesson.hints.length}</span></div>
          <p className="lesson-objective"><strong>लक्ष्य</strong>{lesson.objective}</p>
          <div className="lesson-board-wrap">
            <ChessBoard position={position} disabled={completed} onMove={handleMove} />
            <div className="lesson-guide">
              <div className="guide-number">01</div>
              <div><p className="eyebrow">अभ्यास करें</p><h3>अपनी चाल चलें</h3><p>गोटी चुनें, फिर गंतव्य चुनें। बोर्ड पर focus करके तीर कुंजियों और Enter या Space से भी खेल सकते हैं।</p></div>
            </div>
          </div>
          {feedback && <p className={`training-feedback${completed ? ' success-feedback' : ''}`} role="status" aria-live="polite">{feedback}</p>}
          {hintText && <div className="hint-card"><span className="eyebrow">संकेत {hintLevel}</span><p>{hintText}</p></div>}
          {completed && <div className="lesson-answer-card"><p className="eyebrow">यह क्यों ज़रूरी है</p><p>{lesson.explanation}</p><p className="recognition-cue"><strong>अगली बार पहचानें:</strong> {lesson.recognitionCue}</p></div>}
          <div className="lesson-actions">
            <button className="button-primary" type="button" onClick={giveHint} disabled={completed || hintLevel >= lesson.hints.length}>संकेत देखें ({hintLevel}/{lesson.hints.length})</button>
            <button className="button-secondary" type="button" onClick={reset}>फिर कोशिश करें</button>
            {saveLabel && <span className="small-note" role="status">{saveLabel}</span>}
          </div>
          <div className="lesson-attempt-foot"><span>{attempts.length} दर्ज प्रयास</span><span>{completed ? 'पूरा हुआ' : 'जारी है'}</span></div>
        </article>
      </div>
    </section>
  );
}
