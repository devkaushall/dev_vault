import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SettingsScreen } from './SettingsScreen';
import { StoreProvider } from '../StoreContext';
import { readAppPreferences } from '../preferences';
import { createGame } from '../../domain/chess/session';
import { LocalChessStore } from '../../storage/LocalChessStore';

let storeNumber = 0;
function makeStore() {
  return new LocalChessStore(indexedDB, `settings-screen-${++storeNumber}`);
}
function renderSettings(store: LocalChessStore) {
  return render(<StoreProvider store={store}><SettingsScreen /></StoreProvider>);
}

beforeEach(() => localStorage.clear());
afterEach(() => vi.unstubAllGlobals());

describe('Settings screen', () => {
  it('persists board, orientation, reduced-motion, and next-game time-control preferences', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    renderSettings(store);

    await user.click(screen.getByRole('checkbox', { name: 'Show board coordinates' }));
    await user.selectOptions(screen.getByRole('combobox', { name: 'Default board orientation' }), 'b');
    await user.selectOptions(screen.getByRole('combobox', { name: 'Reduced motion preference' }), 'reduce');
    await user.selectOptions(screen.getByRole('combobox', { name: 'Default Practice time control' }), '180+2');

    expect(readAppPreferences()).toEqual({ coordinates: false, boardOrientation: 'b', reducedMotion: 'reduce', timeControlPresetId: '180+2' });
    expect(document.documentElement.dataset.motion).toBe('reduce');
    expect(screen.getByRole('status')).toHaveTextContent('Preference saved in this browser.');
    await store.close();
  });

  it('downloads one complete local backup including preferences', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const game = createGame({ id: 'settings-export-game', now: '2026-10-05T00:00:00.000Z' });
    await store.saveGame(game);
    const preferences = { coordinates: false, boardOrientation: 'b' as const, reducedMotion: 'reduce' as const, timeControlPresetId: '180+2' as const };
    localStorage.setItem('chess-game-master.preferences.v1', JSON.stringify(preferences));
    let downloaded: Blob | undefined;
    const createObjectURL = vi.fn((blob: Blob) => { downloaded = blob; return 'blob:local-backup'; });
    const revokeObjectURL = vi.fn();
    vi.stubGlobal('URL', { createObjectURL, revokeObjectURL });
    vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined);
    renderSettings(store);

    await user.click(screen.getByRole('button', { name: 'Download all local data' }));
    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent(/Local backup downloaded/));
    expect(createObjectURL).toHaveBeenCalledOnce();
    expect(downloaded).toBeInstanceOf(Blob);
    const packageData = JSON.parse(await downloaded!.text()) as { games: Array<{ id: string }>; appPreferences: unknown };
    expect(packageData.games).toMatchObject([{ id: game.id }]);
    expect(packageData.appPreferences).toEqual(preferences);
    await new Promise<void>((resolve) => window.setTimeout(resolve, 1_050));
    expect(revokeObjectURL).toHaveBeenCalledWith('blob:local-backup');
    await store.close();
  });

  it('restores a validated JSON backup from Settings and applies its preferences', async () => {
    const store = makeStore();
    const game = createGame({ id: 'settings-restore-game', now: '2026-10-05T00:00:00.000Z' });
    const backup = {
      format: 'chess-game-master-local-backup',
      schemaVersion: 1,
      exportedAt: '2026-10-05T00:00:00.000Z',
      games: [game],
      progress: [],
      analysis: [],
      recovery: [],
      appPreferences: { coordinates: false, boardOrientation: 'b', reducedMotion: 'reduce', timeControlPresetId: '300+0' },
    };
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    renderSettings(store);
    const input = screen.getByLabelText('Choose local data backup to restore') as HTMLInputElement;
    const file = new File([JSON.stringify(backup)], 'device-backup.json', { type: 'application/json' });
    fireEvent.change(input, { target: { files: [file] } });

    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent('Restore complete: 1 added, 0 existing IDs skipped.'));
    expect(await store.getGame(game.id)).toEqual(game);
    expect(readAppPreferences()).toEqual(backup.appPreferences);
    expect(document.documentElement.dataset.motion).toBe('reduce');
    await store.close();
  });
});
