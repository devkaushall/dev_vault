import { useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { Chess } from 'chess.js';
import { ChessBoard } from '../../components/ChessBoard';
import { createGame } from '../../domain/chess/session';
import { derivePosition } from '../../domain/chess/position';
import { importPgn } from '../../domain/chess/pgn';
import type { GameRecord } from '../../domain/chess/types';
import { createOpeningQuizQuestion, loadBundledOpeningCatalog, lookupOpeningAtPosition, OPENING_DATASET, recognizeGameOpening, submitOpeningAnswer, type OpeningCatalog, type OpeningMatch, type OpeningQuizQuestion } from '../../knowledge/openings';
import { useLocalStore } from '../StoreContext';

type View = 'lookup' | 'training';

function formatUciLine(moves: string[]): string {
  const chess = new Chess();
  const output: string[] = [];
  for (const [index, uci] of moves.entries()) {
    const from = uci.slice(0, 2);
    const to = uci.slice(2, 4);
    const promotion = uci[4];
    try {
      const move = chess.move({ from, to, ...(promotion ? { promotion } : {}) });
      output.push(`${index % 2 === 0 ? `${Math.floor(index / 2) + 1}.` : ''}${move.san}`);
    } catch {
      return 'Move sequence could not be replayed.';
    }
  }
  return output.join(' ');
}

function matchLabel(match: OpeningMatch) {
  if (match.kind === 'exact-sequence') return 'चाल-क्रम का सटीक मिलान';
  return 'स्थिति का सटीक मिलान · transposition';
}

type OpeningProgressStats = { sessions: number; answered: number; correct: number; hints: number; skipped: number };

function summarizeOpeningProgress(records: Array<{ payload: Record<string, unknown> }>): OpeningProgressStats {
  const sessions = records.filter((record) => typeof record.payload.status === 'string');
  return {
    sessions: sessions.length,
    answered: sessions.filter((record) => record.payload.status === 'answered').length,
    correct: sessions.filter((record) => record.payload.correct === true).length,
    hints: sessions.reduce((total, record) => total + (typeof record.payload.hintLevel === 'number' && Number.isFinite(record.payload.hintLevel) ? Math.max(0, record.payload.hintLevel) : 0), 0),
    skipped: sessions.filter((record) => record.payload.status === 'skipped').length,
  };
}

export function OpeningsScreen() {
  const store = useLocalStore();
  const [catalog, setCatalog] = useState<OpeningCatalog>();
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [view, setView] = useState<View>('lookup');
  const [moveText, setMoveText] = useState('1. e4 e5 2. Nf3 Nc6');
  const [lookupRecord, setLookupRecord] = useState<GameRecord>(() => createGame({ mode: 'Practice' }));
  const [lookupMatch, setLookupMatch] = useState<OpeningMatch>();
  const [lookupMessage, setLookupMessage] = useState('');
  const [query, setQuery] = useState('');
  const [question, setQuestion] = useState<OpeningQuizQuestion>();
  const [sessionId, setSessionId] = useState(() => crypto.randomUUID());
  const [progressStats, setProgressStats] = useState<OpeningProgressStats>({ sessions: 0, answered: 0, correct: 0, hints: 0, skipped: 0 });
  const [answer, setAnswer] = useState<string>();
  const [hintLevel, setHintLevel] = useState(0);
  const [trainingMessage, setTrainingMessage] = useState('');
  const [saveLabel, setSaveLabel] = useState('');
  const [storageError, setStorageError] = useState('');
  const sessionSaveQueue = useRef<Promise<void>>(Promise.resolve());
  const saveGeneration = useRef(0);
  const tabRefs = useRef(new Map<View, HTMLButtonElement>());
  const lookupPosition = useMemo(() => derivePosition(lookupRecord), [lookupRecord]);
  const trainingRecord = useMemo(() => question ? createGame({ mode: 'OpeningTraining', initialFen: question.fen }) : undefined, [question]);
  const trainingPosition = useMemo(() => trainingRecord ? derivePosition(trainingRecord) : undefined, [trainingRecord]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    void loadBundledOpeningCatalog().then((loaded) => {
      if (!active) return;
      setCatalog(loaded);
      setLoading(false);
      if (loaded.skippedRows) setLoadError(`${loaded.skippedRows} malformed data row(s) were skipped safely.`);
    }).catch((error: unknown) => {
      if (!active) return;
      setLoading(false);
      setLoadError(error instanceof Error ? error.message : 'Local opening data could not be loaded.');
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!catalog || question) return;
    const next = createOpeningQuizQuestion(catalog);
    if (next) setQuestion(next);
  }, [catalog, question]);

  useEffect(() => {
    let active = true;
    void store.listProgress('opening').then((records) => {
      if (active) setProgressStats(summarizeOpeningProgress(records));
    }).catch((error: unknown) => {
      if (active) setStorageError(error instanceof Error ? error.message : 'ओपनिंग प्रगति लोड नहीं हो सकी।');
    });
    return () => { active = false; };
  }, [store]);

  const runLookup = () => {
    if (!catalog) return;
    if (moveText.length > 50_000) {
      setLookupMessage('चाल-पाठ बहुत लंबा है (अधिकतम 50,000 अक्षर)।');
      return;
    }
    try {
      const imported = importPgn(moveText);
      const variant = imported.record.pgnHeaders?.Variant?.toLowerCase();
      if (variant && variant !== 'standard' && variant !== 'chess') throw new Error(`Unsupported variant: ${imported.record.pgnHeaders?.Variant}`);
      setLookupRecord(imported.record);
      const match = recognizeGameOpening(imported.record, catalog);
      setLookupMatch(match);
      setLookupMessage(match ? `${matchLabel(match)} · ply ${match.matchedPly} तक।` : 'स्थानीय ओपनिंग सूची में इस स्थिति का सटीक नाम नहीं मिला। समानता के आधार पर कोई अनुमान नहीं लगाया गया।');
    } catch (error) {
      setLookupMessage(`चालें parse नहीं हुईं: ${error instanceof Error ? error.message : 'अमान्य notation'}`);
    }
  };

  const searchByName = () => {
    if (!catalog) return;
    const term = query.trim().toLocaleLowerCase();
    if (!term) return;
    const result = catalog.entries.filter((entry) => `${entry.name} ${entry.eco}`.toLocaleLowerCase().includes(term)).slice(0, 20);
    if (!result.length) {
      setLookupMessage('स्थानीय सूची में इस खोज से कोई ओपनिंग नाम नहीं मिला।');
      return;
    }
    const selected = result[0];
    const match = lookupOpeningAtPosition(catalog, selected.finalFen, selected.uciMoves);
    const line = importPgn(`[Result "*"]\n\n${selected.pgn} *`).record;
    setLookupRecord(line);
    setLookupMatch(match);
    setLookupMessage(`${result.length} नाम मिले; पहला सटीक स्थिति-मिलान दिखाया गया है।`);
  };

  const persistTrainingSession = (session: {
    status: 'in-progress' | 'answered' | 'skipped';
    hintLevel: number;
    moveText: string;
    answer?: string;
    correct?: boolean;
  }) => {
    if (!question) return;
    const activeQuestion = question;
    const activeSessionId = sessionId;
    const generation = ++saveGeneration.current;
    const write = sessionSaveQueue.current.catch(() => undefined).then(() => store.saveProgress({
      id: `opening-session:${activeSessionId}`,
      type: 'opening',
      updatedAt: new Date().toISOString(),
      payload: {
        questionId: activeQuestion.id,
        datasetCommit: activeQuestion.datasetCommit,
        status: session.status,
        hintLevel: session.hintLevel,
        moveText: session.moveText,
        ...(session.answer === undefined ? {} : { answer: session.answer }),
        ...(session.correct === undefined ? {} : { correct: session.correct }),
      },
    }));
    sessionSaveQueue.current = write;
    setSaveLabel('प्रगति सहेजी जा रही है…');
    void write.then(async () => {
      setStorageError('');
      if (saveGeneration.current === generation) setSaveLabel('प्रगति इस डिवाइस पर सहेजी गई');
      try {
        setProgressStats(summarizeOpeningProgress(await store.listProgress('opening')));
      } catch { /* a committed session remains saved even if the summary refresh fails */ }
    }).catch((error: unknown) => {
      if (saveGeneration.current === generation) setSaveLabel('प्रगति सहेजी नहीं गई');
      setStorageError(error instanceof Error ? error.message : 'ओपनिंग प्रगति सहेजी नहीं जा सकी।');
    });
  };

  const submitAnswer = (selectedAnswer: string) => {
    if (!question || answer) return;
    const result = submitOpeningAnswer(question, selectedAnswer);
    setAnswer(selectedAnswer);
    setTrainingMessage(result.correct
      ? 'सही — यह label स्थानीय opening index में इस exact position से मेल खाता है।'
      : 'यह उस indexed position से मेल नहीं खाता। उत्तर के बाद move order और aliases देखें।');
    persistTrainingSession({
      status: 'answered', answer: selectedAnswer, correct: result.correct, hintLevel,
      moveText: formatUciLine(question.uciMoves),
    });
  };

  const giveTrainingHint = () => {
    if (!question) return;
    const nextLevel = Math.min(2, hintLevel + 1);
    if (nextLevel === hintLevel) return;
    setHintLevel(nextLevel);
    setTrainingMessage(nextLevel === 1
      ? 'पहले pawn structure और दोनों पक्षों के विकसित pieces देखें। नाम चाल-क्रम और स्थिति पर आधारित है, engine मूल्यांकन पर नहीं।'
      : `यह ECO ${question.eco[0]} परिवार में दर्ज है। पूरा ECO/name उत्तर देने के बाद दिखेगा।`);
    persistTrainingSession({ status: 'in-progress', hintLevel: nextLevel, moveText: formatUciLine(question.uciMoves) });
  };

  const nextQuestion = () => {
    if (!catalog) return;
    const next = createOpeningQuizQuestion(catalog);
    setQuestion(next);
    setSessionId(crypto.randomUUID());
    setAnswer(undefined);
    setHintLevel(0);
    setTrainingMessage('');
    setSaveLabel('');
  };

  const skipQuestion = () => {
    if (!question || answer) return;
    persistTrainingSession({ status: 'skipped', hintLevel, moveText: formatUciLine(question.uciMoves) });
    nextQuestion();
  };

  const onModeTabKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    let next: View | undefined;
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') next = 'training';
    else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') next = 'lookup';
    else if (event.key === 'Home') next = 'lookup';
    else if (event.key === 'End') next = 'training';
    if (!next || (next === 'training' && !catalog)) return;
    event.preventDefault();
    setView(next);
    tabRefs.current.get(next)?.focus();
  };

  const lookupNames = lookupMatch?.entries.slice(0, 6) ?? [];
  const exactSequence = lookupMatch?.entries.find((entry) => entry.uciMoves.length === lookupMatch.matchedPly);

  return (
    <section className="screen-content openings-screen">
      <header className="screen-heading">
        <div><p className="eyebrow">स्थानीय ओपनिंग सूची · इंजन बंद</p><h1>ओपनिंग पहचान</h1><p className="screen-description">जाने-पहचाने चाल-क्रम और स्थितियाँ खोजें। ओपनिंग नाम चाल की सलाह या engine evaluation नहीं है।</p></div>
        <div className="dataset-badge"><span className="dataset-dot" />{catalog ? `${catalog.entries.length.toLocaleString()} नाम सूचीबद्ध` : 'स्थानीय सूची'}</div>
      </header>
      {loading && <div className="loading-card" role="status"><span className="spinner" />ऑफ़लाइन ओपनिंग सूची लोड हो रही है…</div>}
      {loadError && <div className="save-warning" role="alert">{loadError}</div>}
      {storageError && <div className="save-warning" role="alert">Opening progress is not saved: {storageError}</div>}

      <div className="mode-switch" role="tablist" aria-label="ओपनिंग मोड">
        <button ref={(element) => { if (element) tabRefs.current.set('lookup', element); }} id="opening-lookup-tab" role="tab" aria-controls="opening-lookup-panel" aria-selected={view === 'lookup'} tabIndex={view === 'lookup' ? 0 : -1} className={view === 'lookup' ? 'mode-tab active-mode-tab' : 'mode-tab'} onClick={() => setView('lookup')} onKeyDown={onModeTabKeyDown}>चाल-क्रम खोजें</button>
        <button ref={(element) => { if (element) tabRefs.current.set('training', element); }} id="opening-training-tab" role="tab" aria-controls="opening-training-panel" aria-selected={view === 'training'} tabIndex={view === 'training' ? 0 : -1} className={view === 'training' ? 'mode-tab active-mode-tab' : 'mode-tab'} onClick={() => setView('training')} onKeyDown={onModeTabKeyDown} disabled={!catalog}>पहचान अभ्यास</button>
      </div>

      {view === 'lookup' && (
        <div className="opening-explorer-layout" id="opening-lookup-panel" role="tabpanel" aria-labelledby="opening-lookup-tab" tabIndex={0}>
          <section className="opening-query-card">
            <div className="query-card-heading"><div><p className="eyebrow">खोज</p><h2>चाल-क्रम पहचानें</h2></div><span className="icon-chip">⌕</span></div>
            <label className="field-label" htmlFor="opening-moves">PGN / SAN चालें</label>
            <textarea id="opening-moves" value={moveText} onChange={(event) => setMoveText(event.target.value)} rows={4} spellCheck={false} placeholder="1. e4 e5 2. Nf3 Nc6" />
            <button className="button-primary full-width" type="button" onClick={runLookup} disabled={!catalog}>इस स्थिति की पहचान करें</button>
            <div className="field-divider"><span>या</span></div>
            <label className="field-label" htmlFor="opening-name-search">नाम या ECO खोजें</label>
            <div className="inline-search"><input id="opening-name-search" value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') searchByName(); }} placeholder="जैसे Sicilian Defense या B20" /><button className="button-secondary" type="button" onClick={searchByName} disabled={!catalog}>खोजें</button></div>
            <p className="small-note">इनपुट standard chess notation के रूप में parse होता है; unsupported variants अस्वीकृत हैं। बाहरी API का उपयोग नहीं होता।</p>
            {lookupMessage && <p className="lookup-feedback" role="status" aria-live="polite">{lookupMessage}</p>}
          </section>
          <section className="opening-result-card">
            <div className="opening-board-wrap"><ChessBoard position={lookupPosition} disabled onMove={() => undefined} /></div>
            <div className="opening-result-content">
              <p className="eyebrow">स्थिति का मिलान</p>
              {lookupMatch ? (
                <>
                  <div className="confidence-row"><span className={`confidence-pill ${lookupMatch.confidence}`}>{lookupMatch.confidence === 'high' ? 'उच्च भरोसा' : 'मध्यम भरोसा'}</span><span className="match-kind">{matchLabel(lookupMatch)}</span></div>
                  <h2>{lookupNames.length === 1 ? lookupNames[0].name : 'Multiple indexed names'}</h2>
                  <p className="opening-match-note">{lookupMatch.kind === 'exact-sequence' ? 'चाल-क्रम स्थानीय dataset की दर्ज पंक्ति से मेल खाता है।' : 'बोर्ड की स्थिति मेल खाती है; यहाँ अलग चाल-क्रम से transposition हुआ हो सकता है।'}</p>
                  <ul className="opening-alias-list">
                    {lookupNames.map((entry) => <li key={`${entry.eco}-${entry.name}`}><span>{entry.eco}</span><strong>{entry.name}</strong></li>)}
                  </ul>
                  {lookupNames.length > 1 && <p className="small-note">स्रोत में इस स्थिति के कई नाम हैं। ये वैकल्पिक labels हैं, एकमात्र निर्णायक नाम नहीं।</p>}
                  {exactSequence && <div className="defining-line"><p className="eyebrow">सूची में दर्ज चाल-क्रम</p><p>{exactSequence.pgn}</p></div>}
                </>
              ) : (
                <div className="opening-empty-state"><span className="empty-icon">↗</span><h2>अभी सटीक नाम नहीं मिला</h2><p>सटीक स्थिति-मिलान के लिए जानी हुई चालें खेलें या पेस्ट करें। अज्ञात स्थिति को अज्ञात ही रखा जाता है; नाम का अनुमान नहीं लगाया जाता।</p></div>
              )}
              <div className="data-source-note"><span className="verified-chip">DATA MATCH</span><span>Lichess openings · {OPENING_DATASET.commit.slice(0, 8)} · CC0</span></div>
            </div>
          </section>
        </div>
      )}

      {view === 'training' && catalog && question && trainingPosition && (
        <div className="opening-training-layout" id="opening-training-panel" role="tabpanel" aria-labelledby="opening-training-tab" tabIndex={0}>
          <section className="opening-quiz-card">
            <div className="quiz-topline"><span className="mode-pill mode-opening">ओपनिंग अभ्यास</span><span className="small-note">इंजन बंद · लोकप्रियता स्कोर नहीं</span></div>
            <h2>इस स्थिति से मेल खाता opening label चुनें</h2>
            <p className="screen-description">स्थानीय dataset का नाम चुनें। उत्तर और transposition की जानकारी जमा करने तक छिपी रहेगी।</p>
            <p className="small-note" aria-label="ओपनिंग अभ्यास की स्थानीय प्रगति">स्थानीय प्रगति: {progressStats.sessions} सत्र · {progressStats.correct}/{progressStats.answered} सही · {progressStats.hints} संकेत · {progressStats.skipped} छोड़े</p>
            <div className="quiz-board-wrap"><ChessBoard position={trainingPosition} disabled onMove={() => undefined} /></div>
            <fieldset className="opening-options" disabled={Boolean(answer)}>
              <legend className="sr-only">Opening name choices</legend>
              {question.options.map((option) => (
                <button key={option} type="button" className={`opening-option${answer === option ? ' selected-opening-option' : ''}${answer && question.acceptedNames.includes(option) ? ' correct-opening-option' : ''}`} onClick={() => submitAnswer(option)}>
                  <span className="option-radio" aria-hidden="true">{answer === option ? '●' : '○'}</span>{option}
                </button>
              ))}
            </fieldset>
            <div className="quiz-actions">
              <button className="button-secondary" type="button" onClick={giveTrainingHint} disabled={Boolean(answer) || hintLevel >= 2}>संकेत {hintLevel ? `(${hintLevel}/2)` : 'देखें'}</button>
              <button className="button-quiet" type="button" onClick={skipQuestion} disabled={Boolean(answer)}>छोड़ें</button>
              {answer && <button className="button-primary" type="button" onClick={nextQuestion}>अगली स्थिति <span aria-hidden="true">→</span></button>}
            </div>
            {trainingMessage && <p className="training-feedback" role="status" aria-live="polite">{trainingMessage}</p>}
            {answer && (
              <div className="opening-answer-card">
                <p className="eyebrow">ANSWER · ECO {question.eco}</p>
                <h3>{question.acceptedNames.join(' / ')}</h3>
                <p className="defining-line-text">{formatUciLine(question.uciMoves)}</p>
                <p>These labels come from the local dataset. Similar names can map to the same transposed position.</p>
              </div>
            )}
            {saveLabel && <p className="small-note" role="status">{saveLabel}</p>}
          </section>
          <aside className="opening-training-sidebar">
            <div className="info-card opening-principle-card"><span className="principle-number">01</span><div><p className="eyebrow">RECOGNITION, NOT ADVICE</p><h3>Labels are not plans</h3><p>An opening name and ECO code describe a recorded line. They do not tell you the best move or evaluate the position.</p></div></div>
            <div className="info-card"><span className="principle-number">02</span><div><p className="eyebrow">TRANSPOSITIONS</p><h3>Same board, different route</h3><p>The index can attach multiple names to the same position. After answering, aliases are shown together.</p></div></div>
            <p className="data-attribution">Data source: {OPENING_DATASET.repository}<br />Commit {OPENING_DATASET.commit.slice(0, 12)} · {OPENING_DATASET.license}</p>
          </aside>
        </div>
      )}
    </section>
  );
}
