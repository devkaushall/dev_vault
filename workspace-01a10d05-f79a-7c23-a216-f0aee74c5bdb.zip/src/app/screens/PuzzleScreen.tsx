import { useEffect, useMemo, useRef, useState } from 'react';
import { ChessBoard } from '../../components/ChessBoard';
import { derivePosition } from '../../domain/chess/position';
import { applyMove, createGame } from '../../domain/chess/session';
import type { GameRecord, UciMove } from '../../domain/chess/types';
import { CURATED_PUZZLES, createPuzzleMetaAttempt, getVerifiedMateInOneSolutions, nextPuzzleHint, submitPuzzleMove, type PuzzleAttempt } from '../../learning/puzzles';
import { useLocalStore } from '../StoreContext';

const THEME_LABELS: Record<(typeof CURATED_PUZZLES)[number]['theme'], string> = {
  'back-rank': 'पिछली पंक्ति',
  'queen-mate': 'वज़ीर से मात',
};

export function PuzzleScreen() {
  const store = useLocalStore();
  const [index, setIndex] = useState(0);
  const puzzle = CURATED_PUZZLES[index];
  const [game, setGame] = useState<GameRecord>(() => createGame({ mode: 'Puzzle', initialFen: puzzle.fen }));
  const [progress, setProgress] = useState<Record<string, { attempts: PuzzleAttempt[]; hintLevel: number; solved: boolean }>>({});
  const [hintLevel, setHintLevel] = useState(0);
  const [hintText, setHintText] = useState('');
  const [feedback, setFeedback] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [storageError, setStorageError] = useState('');
  const [saveLabel, setSaveLabel] = useState('');
  const progressSaveQueue = useRef<Promise<void>>(Promise.resolve());
  const saveGeneration = useRef(0);
  const currentProgress = progress[puzzle.id] ?? { attempts: [], hintLevel: 0, solved: false };
  const position = useMemo(() => derivePosition(game), [game]);
  const solutions = useMemo(() => revealed || currentProgress.solved ? getVerifiedMateInOneSolutions(puzzle) : [], [currentProgress.solved, puzzle, revealed]);

  useEffect(() => {
    let active = true;
    void store.listProgress('puzzle').then((records) => {
      if (!active) return;
      const next: typeof progress = {};
      for (const record of records) {
        if (!record.id.startsWith('puzzle:')) continue;
        const puzzleId = record.id.slice('puzzle:'.length);
        const payload = record.payload as { attempts?: PuzzleAttempt[]; hintLevel?: number; solved?: boolean };
        next[puzzleId] = { attempts: payload.attempts ?? [], hintLevel: payload.hintLevel ?? 0, solved: payload.solved ?? false };
      }
      setProgress(next);
    }).catch((error: unknown) => setStorageError(error instanceof Error ? error.message : 'पहेली की प्रगति लोड नहीं हो सकी।'));
    return () => { active = false; };
  }, [store]);

  useEffect(() => {
    setGame(createGame({ mode: 'Puzzle', initialFen: puzzle.fen }));
    setHintLevel(0);
    setHintText('');
    setFeedback('');
    setRevealed(false);
  }, [index, puzzle.fen, puzzle.id]);

  useEffect(() => {
    const saved = progress[puzzle.id];
    if (!saved) return;
    setHintLevel(saved.hintLevel);
    if (saved.solved && game.moveHistory.length === 0) {
      const solvedAttempt = [...saved.attempts].reverse().find((attempt) => attempt.outcome === 'correct' && attempt.moveUci);
      if (solvedAttempt?.moveUci) {
        try { setGame(applyMove(createGame({ mode: 'Puzzle', initialFen: puzzle.fen }), solvedAttempt.moveUci, { source: 'puzzle', committedAt: solvedAttempt.createdAt }).record); } catch { /* a schema-edited progress row is ignored */ }
      }
    }
  }, [game.moveHistory.length, progress, puzzle.fen, puzzle.id]);

  const persist = (puzzleId: string, attempts: PuzzleAttempt[], nextHintLevel: number, solved: boolean) => {
    const generation = ++saveGeneration.current;
    const write = progressSaveQueue.current.catch(() => undefined).then(() => store.saveProgress({
      id: `puzzle:${puzzleId}`,
      type: 'puzzle',
      updatedAt: new Date().toISOString(),
      payload: { attempts, hintLevel: nextHintLevel, solved, version: 1 },
    }));
    progressSaveQueue.current = write;
    setSaveLabel('प्रगति सहेजी जा रही है…');
    void write.then(() => {
      setStorageError('');
      if (saveGeneration.current === generation) setSaveLabel('प्रगति इस डिवाइस पर सहेजी गई');
    }).catch((error: unknown) => {
      if (saveGeneration.current === generation) setSaveLabel('प्रगति सहेजी नहीं गई');
      setStorageError(error instanceof Error ? error.message : 'पहेली की प्रगति सहेजी नहीं जा सकी।');
    });
  };

  const handleMove = (move: UciMove) => {
    const result = submitPuzzleMove(puzzle, `${move.from}${move.to}${move.promotion ?? ''}`, hintLevel);
    const attempts = [...currentProgress.attempts, result.attempt];
    const solved = result.attempt.outcome === 'correct';
    setProgress((current) => ({ ...current, [puzzle.id]: { attempts, hintLevel, solved: current[puzzle.id]?.solved || solved } }));
    setFeedback(result.message);
    void persist(puzzle.id, attempts, hintLevel, currentProgress.solved || solved);
    if (solved) {
      try {
        setGame(applyMove(game, move, { source: 'puzzle', committedAt: result.attempt.createdAt }).record);
      } catch (error) {
        setFeedback(error instanceof Error ? error.message : 'The solved move could not be displayed.');
      }
    }
  };

  const giveHint = () => {
    const next = nextPuzzleHint(puzzle, hintLevel);
    setHintLevel(next.level);
    setHintText(next.text);
    void persist(puzzle.id, currentProgress.attempts, next.level, currentProgress.solved);
  };

  const resetAttempt = () => {
    const resetEvent = createPuzzleMetaAttempt(puzzle.id, 'reset', hintLevel);
    const attempts = [...currentProgress.attempts, resetEvent];
    setProgress((current) => ({ ...current, [puzzle.id]: { attempts, hintLevel: 0, solved: current[puzzle.id]?.solved ?? false } }));
    setGame(createGame({ mode: 'Puzzle', initialFen: puzzle.fen }));
    setHintLevel(0);
    setHintText('');
    setRevealed(false);
    setFeedback('नया प्रयास शुरू हुआ। पुराने प्रयास और संकेतों का स्तर स्थानीय प्रगति में सुरक्षित हैं।');
    void persist(puzzle.id, attempts, 0, currentProgress.solved);
  };

  const reveal = () => {
    const attempt = createPuzzleMetaAttempt(puzzle.id, 'revealed', hintLevel);
    const attempts = [...currentProgress.attempts, attempt];
    setProgress((current) => ({ ...current, [puzzle.id]: { attempts, hintLevel, solved: current[puzzle.id]?.solved ?? false } }));
    setRevealed(true);
    setFeedback('नीचे दिए गए हल वैध चालों से बनाए और जाँचे गए हैं।');
    void persist(puzzle.id, attempts, hintLevel, currentProgress.solved);
  };

  const skip = () => {
    const attempt = createPuzzleMetaAttempt(puzzle.id, 'skipped', hintLevel);
    const attempts = [...currentProgress.attempts, attempt];
    setProgress((current) => ({ ...current, [puzzle.id]: { attempts, hintLevel, solved: current[puzzle.id]?.solved ?? false } }));
    void persist(puzzle.id, attempts, hintLevel, currentProgress.solved);
    setIndex((current) => (current + 1) % CURATED_PUZZLES.length);
  };

  return (
    <section className="screen-content training-screen">
      <header className="screen-heading">
        <div><p className="eyebrow">रणनीति · बिना घड़ी</p><h1>पहेली अभ्यास</h1><p className="screen-description">पहले स्वयं चाल चलें। मात की पुष्टि कानूनी स्थिति से होती है; engine या puzzle rating का उपयोग नहीं।</p></div>
        <span className="mode-pill mode-puzzle">पहेली · उत्तर छिपा है</span>
      </header>
      {storageError && <div className="save-warning" role="alert"><strong>प्रगति सहेजने में समस्या।</strong> {storageError}</div>}
      <div className="training-layout">
        <div className="training-board-card">
          <div className="puzzle-board-meta"><div><p className="eyebrow">थीम · {THEME_LABELS[puzzle.theme]}</p><h2>{puzzle.title}</h2></div><span className="puzzle-index">{String(index + 1).padStart(2, '0')} / {String(CURATED_PUZZLES.length).padStart(2, '0')}</span></div>
          <p className="puzzle-task"><span className="task-icon" aria-hidden="true">♜</span>एक चाल में मात खोजें।</p>
          <ChessBoard position={position} disabled={currentProgress.solved} onMove={handleMove} />
          {feedback && <p className={`training-feedback${currentProgress.solved ? ' success-feedback' : ''}`} role="status" aria-live="polite">{feedback}</p>}
          <div className="puzzle-actions">
            <button className="button-primary" type="button" onClick={giveHint} disabled={currentProgress.solved}>संकेत दें</button>
            <button className="button-secondary" type="button" onClick={resetAttempt} disabled={currentProgress.solved}>फिर शुरू करें</button>
            <button className="button-secondary" type="button" onClick={reveal} disabled={revealed || currentProgress.solved}>उत्तर दिखाएँ</button>
            <button className="button-quiet" type="button" onClick={skip}>अगली पहेली</button>
          </div>
          {hintText && <div className="hint-card"><span className="eyebrow">संकेत {hintLevel}</span><p>{hintText}</p></div>}
          {currentProgress.solved && (
            <div className="lesson-answer-card"><p className="eyebrow">जाँचा हुआ परिणाम</p><h3>मात मिली</h3><p>{puzzle.explanation}</p><p className="recognition-cue"><strong>अगली बार पहचानें:</strong> {puzzle.recognitionCue}</p></div>
          )}
          {solutions.length > 0 && (
            <div className="solution-card"><p className="eyebrow">सभी वैध हल</p><p>{solutions.map((solution) => solution.san).join('  ·  ')}</p></div>
          )}
          {revealed && !currentProgress.solved && <p className="small-note">उत्तर दिखाया गया; यह प्रयास स्थानीय रिकॉर्ड में “उत्तर खोला” के रूप में दर्ज है।</p>}
        </div>
        <aside className="training-side-panel">
          <div className="training-stat"><span>प्रयास</span><strong>{currentProgress.attempts.length}</strong></div>
          <div className="training-stat"><span>इस सत्र के संकेत</span><strong>{hintLevel}</strong></div>
          <div className="training-stat"><span>प्रगति</span><strong>{currentProgress.solved ? 'हल हुई' : 'अभी हल नहीं'}</strong></div>
          <div className="info-card muted-card"><span className="info-icon" aria-hidden="true">i</span><p><strong>evaluation क्यों नहीं?</strong><br />इस सेट में मात को वैध चालों से सीधे जाँचा जाता है। संभावित योजनाओं या tactical नामों को प्रमाण नहीं माना जाता।</p></div>
          <p className="data-attribution">चयनित शुरुआती सेट · Chess Game Master · v1</p>
          {saveLabel && <p className="small-note" role="status">{saveLabel}</p>}
        </aside>
      </div>
    </section>
  );
}
