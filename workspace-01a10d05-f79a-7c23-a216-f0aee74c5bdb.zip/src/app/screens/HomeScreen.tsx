import { useEffect, useState } from 'react';
import type { GameRecord } from '../../domain/chess/types';
import { useLocalStore } from '../StoreContext';
import type { ScreenId } from '../navigation';

export type HomeScreenProps = { onNavigate: (screen: ScreenId) => void; onReview: (record: GameRecord) => void; onResume: (record: GameRecord) => void };

const HOME_CARDS: Array<{ id: ScreenId; eyebrow: string; title: string; description: string; icon: string; tone: string; action: string }> = [
  { id: 'learn', eyebrow: 'मार्गदर्शित · 5 शुरुआती पाठ', title: 'बोर्ड के साथ सीखें', description: 'नियमों के छोटे पाठ, क्रमिक संकेत और दर्ज किए गए दोबारा प्रयास।', icon: '✧', tone: 'card-sage', action: 'सीखना जारी रखें' },
  { id: 'practice', eyebrow: 'स्थानीय अभ्यास · इंजन बंद', title: 'स्थिति को समझें', description: 'वैध चालें चलें, FEN खोलें, चालें देखें और PGN निर्यात करें।', icon: '▦', tone: 'card-amber', action: 'अभ्यास बोर्ड खोलें' },
  { id: 'review', eyebrow: 'स्वयं समीक्षा · PGN आयात', title: 'अपना खेल समझें', description: 'इंजन विश्लेषण से पहले सहेजे या आयात किए खेल को दोबारा देखें।', icon: '↺', tone: 'card-rose', action: 'खेल की समीक्षा करें' },
  { id: 'puzzles', eyebrow: 'रणनीति · बिना घड़ी', title: 'पहेली हल करें', description: 'एक चाल में मात खोजें; उत्तर को वैध चालों से जाँचा जाता है।', icon: '✦', tone: 'card-blue', action: 'पहेली शुरू करें' },
  { id: 'openings', eyebrow: 'स्थानीय डेटा · CC0', title: 'ओपनिंग पहचानें', description: 'सटीक चाल-क्रम देखें और ओपनिंग नामों का अभ्यास करें।', icon: '⌘', tone: 'card-lilac', action: 'ओपनिंग सूची खोलें' },
  { id: 'engine', eyebrow: 'लाइसेंस स्वीकृति लंबित', title: 'इंजन के साथ खेलें', description: 'लिखित GPLv3 स्वीकृति तक Stockfish शामिल नहीं है। कोई दूसरा बॉट नहीं जोड़ा गया है।', icon: '♟', tone: 'card-muted', action: 'इंजन अभी उपलब्ध नहीं' },
];

export function HomeScreen({ onNavigate, onReview, onResume }: HomeScreenProps) {
  const store = useLocalStore();
  const [games, setGames] = useState<GameRecord[]>([]);
  const [storageMessage, setStorageMessage] = useState('');
  const [recoveryCount, setRecoveryCount] = useState(0);
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    let active = true;
    void (async () => {
      const items = await store.listGames();
      const recovered = await store.listRecoveryRecords();
      if (active) {
        setGames(items);
        setRecoveryCount(recovered.length);
      }
    })().catch((error: unknown) => {
      if (active) setStorageMessage(error instanceof Error ? error.message : 'Local games are unavailable.');
    });
    return () => { active = false; };
  }, [store]);

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
  }, []);

  return (
    <section className="screen-content home-screen">
      <div className="welcome-banner">
        <div className="welcome-copy"><p className="eyebrow">वापसी पर स्वागत है</p><h1>स्थिति समझें।<br /><em>फिर चाल चुनें।</em></h1><p>सीखने, अभ्यास और ईमानदार खेल-समीक्षा के लिए स्थानीय शतरंज कार्यक्षेत्र।</p><div className="welcome-actions"><button className="button-primary" type="button" onClick={() => onNavigate('learn')}>सीखना शुरू करें <span aria-hidden="true">→</span></button><button className="button-text-light" type="button" onClick={() => onNavigate('practice')}>अभ्यास बोर्ड खोलें</button></div></div>
        <div className="welcome-art" aria-hidden="true"><div className="hero-circle" /><div className="hero-board-grid">{Array.from({ length: 16 }, (_, index) => <span key={index} className={(Math.floor(index / 4) + index % 4) % 2 ? 'hero-square-dark' : 'hero-square-light'} />)}<b>♞</b></div><span className="hero-spark spark-one">✦</span><span className="hero-spark spark-two">✧</span></div>
        <div className={`offline-ribbon ${online ? '' : 'offline-ribbon-offline'}`}><i />{online ? 'स्थानीय · तैयार' : 'ऑफ़लाइन · स्थानीय मोड तैयार'}</div>
      </div>

      {storageMessage && <div className="save-warning" role="alert">डिवाइस पर सहेजे खेल नहीं पढ़ सके: {storageMessage}</div>}
      {recoveryCount > 0 && <div className="save-warning" role="status">{recoveryCount} खराब रिकॉर्ड सुरक्षित recovery में रखे गए हैं; इतिहास में उन्हें देख या निर्यात कर सकते हैं। <button className="button-small" type="button" onClick={() => onNavigate('history')}>सहेजे खेल खोलें</button></div>}
      <div className="section-title-row"><div><p className="eyebrow">आपका शतरंज कार्यक्षेत्र</p><h2>अपना रास्ता चुनें</h2></div><button className="button-link" type="button" onClick={() => onNavigate('history')}>सहेजे खेल <span aria-hidden="true">→</span></button></div>
      <div className="home-card-grid">
        {HOME_CARDS.map((card) => (
          <article className={`home-action-card ${card.tone}`} key={card.id}>
            <div className="home-card-icon" aria-hidden="true">{card.icon}</div>
            <p className="eyebrow">{card.eyebrow}</p>
            <h3>{card.title}</h3>
            <p className="home-card-description">{card.description}</p>
            <button className={card.id === 'engine' ? 'home-card-link disabled-home-link' : 'home-card-link'} type="button" onClick={() => { if (card.id !== 'engine') onNavigate(card.id); }} disabled={card.id === 'engine'} aria-disabled={card.id === 'engine'}>{card.action}<span aria-hidden="true">→</span></button>
          </article>
        ))}
      </div>
      <div className="home-bottom-row">
        <section className="recent-games-card"><div className="section-title-row compact-title"><div><p className="eyebrow">इस डिवाइस पर · {games.length} सहेजे खेल</p><h2>हाल के खेल</h2></div><button className="button-link" type="button" onClick={() => onNavigate('history')}>सभी देखें →</button></div>
          {games.length ? <ul className="recent-game-list">{games.slice(0, 3).map((game) => <li key={game.id}><span className="recent-piece" aria-hidden="true">♞</span><div><strong>{game.players.white.displayName || 'White'} vs {game.players.black.displayName || 'Black'}</strong><small>{new Date(game.updatedAt).toLocaleDateString()} · {game.moveHistory.length} ply · {game.mode}</small></div><span className="recent-result">{game.result?.score ?? (game.status === 'adjudication-pending' ? 'निर्णय लंबित' : '—')}</span>{game.mode === 'Practice' && game.status === 'active' && <button className="button-secondary" type="button" aria-label={`अभ्यास जारी रखें: ${game.players.white.displayName || 'White'} बनाम ${game.players.black.displayName || 'Black'}`} onClick={() => onResume(game)}>जारी रखें{game.clock ? ' · घड़ी रुकी' : ''}</button>}<button className="button-link" type="button" aria-label={`खेल की समीक्षा करें: ${game.players.white.displayName || 'White'} बनाम ${game.players.black.displayName || 'Black'}`} onClick={() => onReview(game)}>समीक्षा</button></li>)}</ul> : <div className="recent-empty"><span aria-hidden="true">♙</span><p>अभी कोई खेल सहेजा नहीं है।<br /><button className="button-link" type="button" onClick={() => onNavigate('practice')}>अभ्यास बोर्ड शुरू करें</button></p></div>}
        </section>
        <aside className="home-principle-card"><span className="principle-number" aria-hidden="true">01</span><p className="eyebrow">हमारा वादा</p><h3>व्याख्या से पहले प्रमाण।</h3><p>बोर्ड के तथ्य स्पष्ट हैं। रणनीतिक संकेत तब तक संभावित हैं जब तक चालों की वैधता जाँची न जाए।</p><button className="button-text-light" type="button" onClick={() => onNavigate('settings')}>लाइसेंस और गोपनीयता →</button></aside>
      </div>
    </section>
  );
}
