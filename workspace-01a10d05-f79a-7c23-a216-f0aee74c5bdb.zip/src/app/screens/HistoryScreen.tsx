import { useEffect, useMemo, useState } from 'react';
import { exportPgn } from '../../domain/chess/pgn';
import type { GameRecord } from '../../domain/chess/types';
import { useLocalStore } from '../StoreContext';
import type { RecoveryRecord } from '../../storage/LocalChessStore';

export type HistoryScreenProps = { onReview: (record: GameRecord) => void; onResume: (record: GameRecord) => void };

function downloadPgn(record: GameRecord) {
  const blob = new Blob([exportPgn(record)], { type: 'application/x-chess-pgn;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  const filename = record.id.replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 80) || 'game';
  anchor.download = `${filename}.pgn`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

export function HistoryScreen({ onReview, onResume }: HistoryScreenProps) {
  const store = useLocalStore();
  const [games, setGames] = useState<GameRecord[]>([]);
  const [recoveryRecords, setRecoveryRecords] = useState<RecoveryRecord[]>([]);
  const [query, setQuery] = useState('');
  const [modeFilter, setModeFilter] = useState('all');
  const [loadError, setLoadError] = useState('');
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    try {
      const savedGames = await store.listGames();
      const recovered = await store.listRecoveryRecords();
      setGames(savedGames);
      setRecoveryRecords(recovered);
      setLoadError('');
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Saved games could not be loaded.');
    }
  };

  useEffect(() => { void refresh(); }, [store]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return games.filter((game) => {
      if (modeFilter !== 'all' && game.mode !== modeFilter) return false;
      if (!needle) return true;
      const moves = game.moveHistory.map((move) => move.san).join(' ');
      return `${game.id} ${game.players.white.displayName} ${game.players.black.displayName} ${game.result?.score ?? ''} ${moves}`.toLocaleLowerCase().includes(needle);
    });
  }, [games, modeFilter, query]);

  const remove = async (game: GameRecord) => {
    if (!window.confirm('Delete this game and its saved analysis from this device?')) return;
    setBusy(true);
    try {
      await store.deleteGame(game.id);
      await refresh();
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Game deletion failed.');
    } finally {
      setBusy(false);
    }
  };

  const removeAll = async () => {
    if (!window.confirm('Delete all saved games and associated analysis from this device? This cannot be undone.')) return;
    setBusy(true);
    try {
      await store.clearGames();
      await refresh();
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Could not clear saved games.');
    } finally {
      setBusy(false);
    }
  };

  const exportRecovery = () => {
    try {
      const seen = new WeakSet<object>();
      const json = JSON.stringify({ exportedAt: new Date().toISOString(), records: recoveryRecords }, (_key, value: unknown) => {
        if (typeof value === 'bigint') return value.toString();
        if (value && typeof value === 'object') {
          if (seen.has(value)) return '[Circular reference omitted]';
          seen.add(value);
        }
        return value;
      }, 2);
      const url = URL.createObjectURL(new Blob([json], { type: 'application/json;charset=utf-8' }));
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'chess-game-recovery.json';
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
    } catch (error) {
      setLoadError(error instanceof Error ? `Recovery export failed: ${error.message}` : 'Recovery export failed.');
    }
  };

  const deleteRecoveryCopy = async (record: RecoveryRecord) => {
    if (!window.confirm(`Delete the preserved recovery copy for ${record.originalKey}? This cannot be undone.`)) return;
    try {
      await store.deleteRecoveryRecord(record.id);
      await refresh();
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Recovery copy could not be deleted.');
    }
  };

  return (
    <section className="screen-content history-screen">
      <header className="screen-heading">
        <div><p className="eyebrow">LOCAL LIBRARY · PRIVATE TO THIS DEVICE</p><h1>Saved games</h1><p className="screen-description">Search, review, export, or delete your local records. No account or cloud sync is used.</p></div>
        <span className="history-total">{games.length} game{games.length === 1 ? '' : 's'}</span>
      </header>
      {loadError && <div className="save-warning" role="alert">{loadError}</div>}
      {recoveryRecords.length > 0 && <section className="recovery-notice" aria-labelledby="recovery-title">
        <div><p className="eyebrow">LOCAL DATA RECOVERY</p><h2 id="recovery-title">{recoveryRecords.length} invalid record(s) preserved</h2><p>These rows were isolated so valid games and progress remain available. Export a diagnostic copy before deleting them.</p></div>
        <button className="button-secondary" type="button" onClick={exportRecovery}>Export recovery JSON</button>
        <details><summary>Show recovered records</summary><ul>{recoveryRecords.map((record) => <li key={record.id}><span><strong>{record.source} · {record.originalKey}</strong><small>{record.reason}</small></span><button className="button-link danger-text" type="button" onClick={() => void deleteRecoveryCopy(record)}>Delete copy</button></li>)}</ul></details>
      </section>}
      <div className="history-toolbar">
        <label className="history-search"><span className="sr-only">Search games</span><span aria-hidden="true">⌕</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search players, SAN, result…" /></label>
        <label className="filter-select"><span className="sr-only">Filter by mode</span><select value={modeFilter} onChange={(event) => setModeFilter(event.target.value)}><option value="all">All modes</option><option value="Practice">Practice</option><option value="Review">Review</option><option value="Puzzle">Puzzle</option><option value="Learn">Learn</option><option value="Challenge">Challenge</option><option value="CoachedPractice">Coached Practice</option></select></label>
        <button className="button-quiet danger-action" type="button" onClick={() => void removeAll()} disabled={!games.length || busy}>Delete all</button>
      </div>
      {filtered.length ? (
        <div className="history-table-wrap">
          <table className="history-table">
            <thead><tr><th>Game</th><th>Mode</th><th>Result</th><th>Moves</th><th>Updated</th><th><span className="sr-only">Actions</span></th></tr></thead>
            <tbody>
              {filtered.map((game) => (
                <tr key={game.id}>
                  <td><strong>{game.players.white.displayName || 'White'} <span>vs</span> {game.players.black.displayName || 'Black'}</strong><small>{game.id.slice(0, 12)}</small></td>
                  <td><span className="table-mode-badge">{game.mode}</span></td>
                  <td><span className="table-result">{game.result?.score ?? (game.status === 'adjudication-pending' ? 'Adjudication pending' : game.status === 'aborted' ? 'Stopped · no result' : 'In progress')}</span><small>{game.result?.reason ?? (game.status === 'adjudication-pending' ? 'Timeout result requires adjudication; moves are locked.' : game.status === 'aborted' ? 'Stopped without assigning a chess result.' : '')}</small></td>
                  <td>{Math.ceil(game.moveHistory.length / 2)} moves</td>
                  <td>{new Date(game.updatedAt).toLocaleString()}</td>
                  <td><div className="table-actions">{game.mode === 'Practice' && game.status === 'active' && <button className="button-link" type="button" onClick={() => onResume(game)} aria-label={`Resume practice game ${game.id.slice(0, 12)}`}>Continue{game.clock ? ' · clock paused' : ''}</button>}<button className="button-link" type="button" onClick={() => onReview(game)}>Review</button><button className="button-link" type="button" onClick={() => downloadPgn(game)}>PGN</button><button className="button-link danger-text" type="button" onClick={() => void remove(game)} disabled={busy}>Delete</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="history-empty"><span className="empty-icon">♜</span><h2>{games.length ? 'No matching games' : 'Your local game history is empty'}</h2><p>{games.length ? 'Try a different search or mode filter.' : 'Start a Practice board or import a completed game to keep a local record.'}</p></div>
      )}
      <footer className="history-privacy-note"><span aria-hidden="true">◉</span><span>Stored in this browser’s IndexedDB. The browser may clear local site data; export games you want to keep.</span></footer>
    </section>
  );
}
