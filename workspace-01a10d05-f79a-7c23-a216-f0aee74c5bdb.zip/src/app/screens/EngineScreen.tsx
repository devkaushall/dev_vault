import { STOCKFISH_LICENSING_GATE } from '../../engine/engineGate';
import type { ScreenId } from '../navigation';

export function EngineScreen({ onNavigate }: { onNavigate: (screen: ScreenId) => void }) {
  return (
    <section className="screen-content engine-gate-screen">
      <header className="screen-heading"><div><p className="eyebrow">इंजन के साथ खेलें</p><h1>इंजन प्रतिद्वंद्वी अभी उपलब्ध नहीं</h1><p className="screen-description">Engine adapter का आधार तैयार है, लेकिन कोई chess engine शामिल या चुपचाप बदला नहीं गया है।</p></div><span className="mode-pill mode-gated">रिलीज़ अवरोध</span></header>
      <div className="engine-gate-card">
        <div className="gate-symbol" aria-hidden="true">♞</div>
        <div><p className="eyebrow">{STOCKFISH_LICENSING_GATE.engine}</p><h2>लिखित GPLv3 स्वीकृति आवश्यक</h2><p>Stockfish का लाइसेंस GPL-3.0-or-later है। स्वीकृति और वितरण की शर्तें स्पष्ट होने तक Challenge और Coached Practice शुरू नहीं हो सकते।</p>
          <ul className="gate-check-list"><li><span>✓</span> UCI adapter और केवल-परीक्षण mock तैयार हैं</li><li><span>✓</span> Engine की principal variations को rules library से दोबारा जाँचा जाता है</li><li><span>—</span> Engine binary / Worker शामिल नहीं है</li><li><span>—</span> कोई random या replacement bot नहीं है</li></ul>
          <div className="gate-actions"><button className="button-primary" type="button" onClick={() => onNavigate('practice')}>स्थानीय अभ्यास बोर्ड खोलें</button><button className="button-secondary" type="button" onClick={() => onNavigate('settings')}>लाइसेंस स्थिति देखें</button></div>
        </div>
      </div>
      <p className="small-note gate-footnote">लाइसेंस स्वीकृति लंबित रहने तक यह पृष्ठ जानबूझकर खेलने योग्य नहीं है। कोई रेटिंग या बॉट-स्तर का दावा नहीं किया गया है।</p>
    </section>
  );
}
