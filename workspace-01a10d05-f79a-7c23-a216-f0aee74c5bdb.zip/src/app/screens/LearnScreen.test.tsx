import { describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { StoreProvider } from '../StoreContext';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { LearnScreen } from './LearnScreen';

let counter = 0;
function makeStore() {
  return new LocalChessStore(indexedDB, `learn-screen-test-${++counter}`);
}

describe('interactive rule lessons', () => {
  it('shows all four progressive hints and resets the next attempt without deleting history', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><LearnScreen /></StoreProvider>);

    for (let level = 0; level < 4; level++) {
      await user.click(screen.getByRole('button', { name: `संकेत देखें (${level}/4)` }));
    }
    expect(screen.getByText(/e1-c1 और rook a1-d1/)).toBeInTheDocument();
    expect(screen.getByText('संकेत 4')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'संकेत देखें (4/4)' })).toBeDisabled();

    await user.click(screen.getByRole('button', { name: 'फिर कोशिश करें' }));
    expect(screen.getByRole('button', { name: 'संकेत देखें (0/4)' })).toBeEnabled();
    expect(screen.queryByText(/e1-c1 और rook a1-d1/)).not.toBeInTheDocument();
    await waitFor(async () => expect((await store.listProgress('lesson'))[0]?.payload).toMatchObject({ hintLevel: 0, completed: false }));

    unmount();
    await store.close();
  });

  it('checks a castling lesson answer and persists the attempt locally', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><LearnScreen /></StoreProvider>);
    expect(screen.getByRole('heading', { name: 'कैसलिंग का रास्ता सुरक्षित हो' })).toBeInTheDocument();
    await user.click(screen.getByRole('gridcell', { name: 'e1 पर सफ़ेद राजा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना c1, वैध गंतव्य' }));
    expect(await screen.findByText('O-O-O — लक्ष्य पूरा हुआ।')).toBeInTheDocument();
    expect(screen.getByText('कैसलिंग से पहले राजा के शुरुआती, बीच के और अंतिम चौखाने जाँचें—rook के चौखाने नहीं।')).toBeInTheDocument();
    await waitFor(async () => expect(await store.listProgress('lesson')).toHaveLength(1));

    unmount();
    await store.close();
  });
});
