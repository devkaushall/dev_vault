import { useEffect, useState, type ChangeEvent } from 'react';
import { applyReducedMotionPreference, isAppPreferences, readAppPreferences, replaceAppPreferences, TIME_CONTROL_PRESETS, updateAppPreferences, type AppPreferences } from '../preferences';
import { STOCKFISH_LICENSING_GATE } from '../../engine/engineGate';
import { useLocalStore } from '../StoreContext';

export function SettingsScreen() {
  const store = useLocalStore();
  const [online, setOnline] = useState(navigator.onLine);
  const [serviceWorker, setServiceWorker] = useState('Checking offline shell…');
  const [message, setMessage] = useState('');
  const [preferenceMessage, setPreferenceMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [preferences, setPreferences] = useState<AppPreferences>(() => readAppPreferences());

  const savePreference = (patch: Partial<AppPreferences>) => {
    const result = updateAppPreferences(patch);
    setPreferences(result.preferences);
    if (patch.reducedMotion) applyReducedMotionPreference(patch.reducedMotion);
    setPreferenceMessage(result.persisted ? 'Preference saved in this browser.' : 'Preference changed for this view, but browser storage is unavailable.');
  };

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
  }, []);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) {
      setServiceWorker('This browser does not support service workers.');
      return;
    }
    void navigator.serviceWorker.getRegistration('/').then((registration) => {
      setServiceWorker(registration ? 'Offline shell registered' : 'Open the app once online to prepare the offline shell.');
    }).catch(() => setServiceWorker('Offline shell status could not be checked.'));
  }, []);

  const exportAllData = async () => {
    setBusy(true);
    try {
      const backup = JSON.parse(await store.exportBackup()) as Record<string, unknown>;
      backup.appPreferences = readAppPreferences();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      if (blob.size > 25_000_000) throw new Error('Local backup exceeds the 25 MB download limit.');
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `chess-game-master-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      setMessage('Local backup downloaded. It is not encrypted; keep the file somewhere private.');
    } catch (error) {
      setMessage(`Backup was not created: ${error instanceof Error ? error.message : 'storage error'}`);
    } finally {
      setBusy(false);
    }
  };

  const importAllData = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (file.size > 25_000_000) {
      setMessage('Backup file exceeds the 25 MB safety limit.');
      return;
    }
    if (!window.confirm('Merge the contents of this backup into this browser? Existing records with matching IDs will not be overwritten. The imported preferences will replace current preferences.')) return;
    setBusy(true);
    try {
      const json = await file.text();
      let decoded: unknown;
      try { decoded = JSON.parse(json); }
      catch { throw new Error('Backup file is not valid JSON.'); }
      if (!decoded || typeof decoded !== 'object' || Array.isArray(decoded) || !isAppPreferences((decoded as Record<string, unknown>).appPreferences)) {
        throw new Error('Backup does not contain valid app preferences. No local records were changed.');
      }
      const importedPreferences = (decoded as Record<string, unknown>).appPreferences as AppPreferences;
      const summary = await store.restoreBackup(json);
      const preferenceSaved = replaceAppPreferences(importedPreferences);
      setPreferences(importedPreferences);
      if (!preferenceSaved) applyReducedMotionPreference(importedPreferences.reducedMotion);
      const count = (values: typeof summary.added) => Object.values(values).reduce((total, value) => total + value, 0);
      const added = count(summary.added);
      const skipped = count(summary.skipped);
      setMessage(`Restore complete: ${added} added, ${skipped} existing IDs skipped.${preferenceSaved ? '' : ' Imported preferences could not be saved in browser storage.'}`);
    } catch (error) {
      setMessage(`Backup was not restored: ${error instanceof Error ? error.message : 'storage error'}`);
    } finally {
      setBusy(false);
    }
  };

  const eraseAll = async () => {
    if (!window.confirm('Permanently delete all games, review data, lesson attempts, puzzle progress, and opening training from this browser?')) return;
    setBusy(true);
    try {
      await store.clearAllData();
      setMessage('All local game and learning data was deleted.');
    } catch (error) {
      setMessage(`Data was not deleted: ${error instanceof Error ? error.message : 'storage error'}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="screen-content settings-screen">
      <header className="screen-heading"><div><p className="eyebrow">PREFERENCES · LOCAL STORAGE</p><h1>Settings & privacy</h1><p className="screen-description">Your games and progress stay in this browser. This is local storage, not an encrypted vault or cloud backup.</p></div><span className={`online-pill ${online ? 'online' : 'offline'}`}><i />{online ? 'Online' : 'Offline'}</span></header>
      <div className="settings-grid">
        <section className="settings-card"><p className="eyebrow">LANGUAGE & DISPLAY</p><h2>Interface preferences</h2>
          <div className="setting-row"><div><strong>Interface language</strong><small>Hindi-first; some existing screens still contain English. A language switch is not offered until full translations are available.</small></div><span className="setting-value">हिन्दी · default</span></div>
          <label className="setting-row setting-control-row"><span><strong>Board coordinates</strong><small>Show or hide the rank and file labels on the board.</small></span><input type="checkbox" aria-label="Show board coordinates" checked={preferences.coordinates} onChange={(event) => savePreference({ coordinates: event.target.checked })} /></label>
          <label className="setting-row setting-control-row"><span><strong>Board orientation</strong><small>Default view used when a board opens; the board can still be flipped in Practice.</small></span><select aria-label="Default board orientation" value={preferences.boardOrientation} onChange={(event) => savePreference({ boardOrientation: event.target.value as AppPreferences['boardOrientation'] })}><option value="w">White at bottom</option><option value="b">Black at bottom</option></select></label>
          <label className="setting-row setting-control-row"><span><strong>Reduced motion</strong><small>Choose the system setting or explicitly reduce/allow interface motion.</small></span><select aria-label="Reduced motion preference" value={preferences.reducedMotion} onChange={(event) => savePreference({ reducedMotion: event.target.value as AppPreferences['reducedMotion'] })}><option value="system">Follow system</option><option value="reduce">Reduce motion</option><option value="full">Allow motion</option></select></label>
          <label className="setting-row setting-control-row"><span><strong>Next Practice time control</strong><small>New boards and loaded FEN positions use this preset. Current games are unchanged.</small></span><select aria-label="Default Practice time control" value={preferences.timeControlPresetId} onChange={(event) => savePreference({ timeControlPresetId: event.target.value as AppPreferences['timeControlPresetId'] })}>{TIME_CONTROL_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label}</option>)}</select></label>
          <div className="setting-row"><div><strong>Notation & sound</strong><small>Standard SAN/PGN remains in use. Audio cues and additional piece sets are not bundled in this build.</small></div><span className="setting-value">SAN · no audio</span></div>
          {preferenceMessage && <p className="settings-message" role="status" aria-live="polite">{preferenceMessage}</p>}
        </section>
        <section className="settings-card"><p className="eyebrow">OFFLINE</p><h2>Local availability</h2>
          <div className="setting-row"><div><strong>App shell</strong><small>{serviceWorker}</small></div><span className={`status-dot ${serviceWorker.includes('registered') ? 'status-good' : 'status-warn'}`} /></div>
          <div className="setting-row"><div><strong>Opening index</strong><small>Bundled with this build; cached after first successful load</small></div><span className="setting-value">Local dataset</span></div>
          <div className="setting-row"><div><strong>Games & progress</strong><small>Stored with IndexedDB on this device only</small></div><span className="setting-value">No account</span></div>
        </section>
        <section className="settings-card license-card"><p className="eyebrow">LICENSES & ENGINE</p><h2>Dependency notices</h2>
          <ul className="license-list">
            <li><span className="license-mark">✓</span><div><strong>chess.js 1.4.0</strong><small>BSD-2-Clause · legal move generation and notation</small></div></li>
            <li><span className="license-mark">✓</span><div><strong>Lichess opening labels</strong><small>CC0-1.0 · commit { '5a13018164f6' }</small></div></li>
            <li className="license-pending"><span className="license-mark">!</span><div><strong>{STOCKFISH_LICENSING_GATE.engine}</strong><small>GPL-3.0-or-later approval pending · not bundled · engine features disabled</small></div></li>
          </ul>
          <p className="small-note">No substitute engine or hidden engine worker is loaded.</p>
          <p className="small-note"><a className="button-link" href="/THIRD_PARTY_NOTICES.txt">Third-party notices</a> · <a className="button-link" href="/sbom.cdx.json">CycloneDX SBOM</a></p>
        </section>
        <section className="settings-card privacy-card"><p className="eyebrow">DATA CONTROL</p><h2>Backup, restore or delete</h2>
          <p>Download a local JSON backup of game history, clocks, learning progress, analysis records, recoverable rows, and app preferences. Backups are not encrypted; the browser may also clear site data, and there is no remote recovery.</p>
          <div className="backup-actions"><button className="button-secondary" type="button" onClick={() => void exportAllData()} disabled={busy}>{busy ? 'Working…' : 'Download all local data'}</button><label className="backup-file-control"><span className="button-secondary">Choose backup to restore…</span><input type="file" accept="application/json,.json" aria-label="Choose local data backup to restore" onChange={(event) => void importAllData(event)} disabled={busy} /></label></div>
          <p className="small-note">Restore validates the full file before importing, merges in one database transaction, skips existing IDs without overwriting, and replaces saved preferences. Maximum file size: 25 MB.</p>
          <button className="button-danger" type="button" onClick={() => void eraseAll()} disabled={busy}>{busy ? 'Working…' : 'Delete all local games & progress'}</button>
          {message && <p className="settings-message" role="status" aria-live="polite">{message}</p>}
        </section>
      </div>
      <p className="settings-footnote">Chess Game Master V1 · Standard chess only · no ratings, public ranking, or live human competition</p>
    </section>
  );
}
