import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createGame } from '../../domain/chess/session';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { StoreProvider } from '../StoreContext';
import { HistoryScreen } from './HistoryScreen';

let counter = 0;
function name() { return `history-recovery-test-${++counter}`; }

async function corruptGameRow(databaseName: string, record: unknown): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.open(databaseName, 2);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const database = request.result;
      const transaction = database.transaction('games', 'readwrite');
      transaction.objectStore('games').put(record);
      transaction.oncomplete = () => { database.close(); resolve(); };
      transaction.onerror = () => { database.close(); reject(transaction.error); };
      transaction.onabort = () => { database.close(); reject(transaction.error); };
    };
  });
}

describe('saved-game recovery notice', () => {
  it('offers a paused-clock timed Practice game from History', async () => {
    const user = userEvent.setup();
    const dbName = name();
    const store = new LocalChessStore(indexedDB, dbName);
    const timed = createGame({ id: 'timed-history-game', timeControl: { baseSeconds: 180, incrementSeconds: 2 } });
    await store.saveGame(timed);
    const onResume = vi.fn();
    const onReview = vi.fn();
    const { unmount } = render(<StoreProvider store={store}><HistoryScreen onReview={onReview} onResume={onResume} /></StoreProvider>);

    const continueButton = await screen.findByRole('button', { name: 'Resume practice game timed-histor' });
    expect(continueButton).toHaveTextContent('clock paused');
    await user.click(continueButton);
    expect(onResume).toHaveBeenCalledWith(expect.objectContaining({ id: timed.id, clock: expect.objectContaining({ paused: true }) }));

    unmount();
    await store.close();
  });

  it('keeps valid games available, exposes the quarantined copy and supports deletion', async () => {
    const user = userEvent.setup();
    const dbName = name();
    const seed = new LocalChessStore(indexedDB, dbName);
    await seed.saveGame(createGame({ id: 'good-history-game' }));
    await seed.close();
    const bad = createGame({ id: 'broken-history-game' });
    await corruptGameRow(dbName, { ...bad, currentFen: 'corrupted' });

    const store = new LocalChessStore(indexedDB, dbName);
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(true);
    const onReview = vi.fn();
    const onResume = vi.fn();
    const { unmount } = render(<StoreProvider store={store}><HistoryScreen onReview={onReview} onResume={onResume} /></StoreProvider>);

    expect(await screen.findByText(/1 invalid record\(s\) preserved/i)).toBeInTheDocument();
    expect(screen.getByText(/good-history/)).toBeInTheDocument();
    await user.click(screen.getByText('Show recovered records'));
    expect(screen.getByText(/broken-history-game/)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Delete copy' }));
    await waitFor(() => expect(screen.queryByText(/invalid record\(s\) preserved/i)).not.toBeInTheDocument());
    expect(confirm).toHaveBeenCalledOnce();
    expect(await store.listGames()).toMatchObject([{ id: 'good-history-game' }]);

    unmount();
    confirm.mockRestore();
    await store.close();
  });
});
