import { useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { applyReducedMotionPreference, readAppPreferences } from './preferences';
import { StoreProvider } from './StoreContext';
import { LocalChessStore } from '../storage/LocalChessStore';
import { NAV_ITEMS, type ScreenId } from './navigation';
import { HomeScreen } from './screens/HomeScreen';
import { LearnScreen } from './screens/LearnScreen';
import { PuzzleScreen } from './screens/PuzzleScreen';
import { OpeningsScreen } from './screens/OpeningsScreen';
import { ReviewScreen } from './screens/ReviewScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { EngineScreen } from './screens/EngineScreen';
import { ChessWorkspace } from '../components/ChessWorkspace';
import type { GameRecord } from '../domain/chess/types';

const TITLES: Record<ScreenId, string> = {
  home: 'मुखपृष्ठ', learn: 'सीखें', practice: 'अभ्यास बोर्ड', engine: 'इंजन से खेलें', review: 'खेल की समीक्षा', puzzles: 'पहेलियाँ', openings: 'ओपनिंग', history: 'सहेजे खेल', settings: 'सेटिंग',
};

function useMobileNavigationBreakpoint(): boolean {
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && Boolean(window.matchMedia?.('(max-width: 700px)').matches));
  useEffect(() => {
    if (!window.matchMedia) return;
    const media = window.matchMedia('(max-width: 700px)');
    const update = () => setIsMobile(media.matches);
    update();
    media.addEventListener?.('change', update);
    return () => media.removeEventListener?.('change', update);
  }, []);
  return isMobile;
}

function ScreenContent({ screen, reviewRecord, practiceRecord, onNavigate, onReview, onResume }: {
  screen: ScreenId;
  reviewRecord?: GameRecord;
  practiceRecord?: GameRecord;
  onNavigate: (screen: ScreenId) => void;
  onReview: (record: GameRecord) => void;
  onResume: (record: GameRecord) => void;
}) {
  switch (screen) {
    case 'home': return <HomeScreen onNavigate={onNavigate} onReview={onReview} onResume={onResume} />;
    case 'learn': return <LearnScreen />;
    case 'practice': return <ChessWorkspace mode="Practice" initialRecord={practiceRecord} />;
    case 'engine': return <EngineScreen onNavigate={onNavigate} />;
    case 'review': return <ReviewScreen initialRecord={reviewRecord} />;
    case 'puzzles': return <PuzzleScreen />;
    case 'openings': return <OpeningsScreen />;
    case 'history': return <HistoryScreen onReview={onReview} onResume={onResume} />;
    case 'settings': return <SettingsScreen />;
  }
}

export function App() {
  const store = useMemo(() => new LocalChessStore(), []);
  const [screen, setScreen] = useState<ScreenId>('home');
  const [mobileNavigationOpen, setMobileNavigationOpen] = useState(false);
  const [reviewRecord, setReviewRecord] = useState<GameRecord>();
  const [practiceRecord, setPracticeRecord] = useState<GameRecord>();
  const [waitingWorker, setWaitingWorker] = useState<ServiceWorker | null>(null);
  const [updateNoticeDismissed, setUpdateNoticeDismissed] = useState(false);
  const isMobileNavigation = useMobileNavigationBreakpoint();
  const sidebarRef = useRef<HTMLDivElement>(null);
  const menuToggleRef = useRef<HTMLButtonElement>(null);
  const mainRef = useRef<HTMLElement>(null);
  const previousScreen = useRef(screen);
  const updateReloadRequested = useRef(false);

  const navigate = (next: ScreenId) => {
    setScreen(next);
    setMobileNavigationOpen(false);
    if (next !== 'review') setReviewRecord(undefined);
    setPracticeRecord(undefined);
  };

  // A selection is passed through local app state, never written into a URL.
  const openReview = (record: GameRecord) => {
    setReviewRecord(record);
    setPracticeRecord(undefined);
    setScreen('review');
    setMobileNavigationOpen(false);
  };

  const resumePractice = (record: GameRecord) => {
    if (record.mode !== 'Practice' || record.status !== 'active') return;
    setReviewRecord(undefined);
    setPracticeRecord(record);
    setScreen('practice');
    setMobileNavigationOpen(false);
  };

  useEffect(() => {
    applyReducedMotionPreference(readAppPreferences().reducedMotion);
  }, []);

  useEffect(() => {
    if (previousScreen.current === screen) return;
    previousScreen.current = screen;
    mainRef.current?.focus();
  }, [screen]);

  useEffect(() => {
    if (isMobileNavigation && mobileNavigationOpen) {
      sidebarRef.current?.querySelector<HTMLButtonElement>('.nav-item:not(:disabled)')?.focus();
    }
  }, [isMobileNavigation, mobileNavigationOpen]);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const serviceWorkers = navigator.serviceWorker;
    let active = true;
    let registration: ServiceWorkerRegistration | undefined;
    const detectWaitingWorker = () => {
      if (active && registration?.waiting && serviceWorkers.controller) {
        setWaitingWorker(registration.waiting);
        setUpdateNoticeDismissed(false);
      }
    };
    const onControllerChange = () => {
      if (updateReloadRequested.current) window.location.reload();
    };
    const onUpdateFound = () => {
      const installing = registration?.installing;
      if (!installing) return;
      const onStateChange = () => {
        if (installing.state === 'installed') detectWaitingWorker();
      };
      installing.addEventListener('statechange', onStateChange);
    };
    serviceWorkers.addEventListener('controllerchange', onControllerChange);
    void serviceWorkers.ready.then((readyRegistration) => {
      if (!active) return;
      registration = readyRegistration;
      detectWaitingWorker();
      registration.addEventListener('updatefound', onUpdateFound);
      void registration.update().catch(() => undefined);
    }).catch(() => undefined);
    return () => {
      active = false;
      serviceWorkers.removeEventListener('controllerchange', onControllerChange);
      registration?.removeEventListener('updatefound', onUpdateFound);
    };
  }, []);

  const closeMobileNavigation = (restoreFocus = true) => {
    setMobileNavigationOpen(false);
    if (restoreFocus) {
      const focusToggle = () => menuToggleRef.current?.focus();
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(focusToggle);
      else window.setTimeout(focusToggle, 0);
    }
  };

  const handleSidebarKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    if (!isMobileNavigation || !mobileNavigationOpen) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closeMobileNavigation();
      return;
    }
    if (event.key !== 'Tab') return;
    const controls = [...(sidebarRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], [tabindex="0"]') ?? [])];
    const first = controls[0];
    const last = controls.at(-1);
    if (!first || !last) return;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const applyUpdate = () => {
    if (!waitingWorker) return;
    updateReloadRequested.current = true;
    waitingWorker.postMessage({ type: 'ACTIVATE_UPDATE' });
  };

  const sidebarClass = `app-sidebar${mobileNavigationOpen ? ' sidebar-open' : ''}`;
  const sidebarHidden = isMobileNavigation && !mobileNavigationOpen;

  return (
    <StoreProvider store={store}>
      <a className="skip-link" href="#main-content">मुख्य सामग्री पर जाएँ</a>
      <div className="app-shell">
        <div
          ref={sidebarRef}
          id="app-sidebar"
          className={sidebarClass}
          aria-hidden={sidebarHidden}
          inert={sidebarHidden}
          role={isMobileNavigation && mobileNavigationOpen ? 'dialog' : 'complementary'}
          aria-modal={isMobileNavigation && mobileNavigationOpen ? true : undefined}
          aria-label={isMobileNavigation && mobileNavigationOpen ? 'मुख्य नेविगेशन' : 'सहायक नेविगेशन'}
          onKeyDown={handleSidebarKeyDown}
        >
          <div className="brand-lockup"><div className="brand-mark" aria-hidden="true">♞</div><div><strong>Chess Game</strong><span>MASTER</span></div></div>
          <p className="sidebar-caption">आपका शतरंज अभ्यास</p>
          <nav className="primary-navigation" aria-label="मुख्य नेविगेशन">
            <p className="nav-group-label">खेलें और सीखें</p>
            {NAV_ITEMS.filter((item) => item.group === 'play').map((item) => (
              <button key={item.id} className={`nav-item${screen === item.id ? ' nav-item-active' : ''}${item.id === 'engine' ? ' nav-item-gated' : ''}`} type="button" onClick={() => navigate(item.id)} aria-current={screen === item.id ? 'page' : undefined}>
                <span className="nav-icon" aria-hidden="true">{item.icon}</span><span>{item.label}</span>{item.id === 'engine' && <span className="nav-gate-dot" title="लाइसेंस स्वीकृति लंबित" />}
              </button>
            ))}
            <p className="nav-group-label nav-group-secondary">संग्रह</p>
            {NAV_ITEMS.filter((item) => item.group === 'library').map((item) => (
              <button key={item.id} className={`nav-item${screen === item.id ? ' nav-item-active' : ''}`} type="button" onClick={() => navigate(item.id)} aria-current={screen === item.id ? 'page' : undefined}>
                <span className="nav-icon" aria-hidden="true">{item.icon}</span><span>{item.label}</span>
              </button>
            ))}
          </nav>
          <div className="sidebar-bottom-card"><div className="sidebar-light" /><p className="eyebrow">पहले प्रमाण</p><p>बोर्ड के तथ्य, वैध चालें और स्पष्ट भरोसा-स्तर।</p><span>V1 · डिवाइस पर</span></div>
          <div className="sidebar-footer"><span className="connection-dot" /><span>बिना खाते के काम करता है</span></div>
        </div>

        <div className="app-main-shell" inert={isMobileNavigation && mobileNavigationOpen ? true : undefined}>
          {waitingWorker && !updateNoticeDismissed && <div className="update-banner" role="status"><span>सुरक्षित ऐप अपडेट तैयार है। वर्तमान खेल बदलने से बचाने के लिए यह आपकी पुष्टि की प्रतीक्षा कर रहा है।</span><button className="button-small" type="button" onClick={applyUpdate}>अपडेट और पुनः लोड करें</button><button className="button-link" type="button" onClick={() => setUpdateNoticeDismissed(true)}>अभी नहीं</button></div>}
          <header className="app-topbar">
            <button ref={menuToggleRef} className="mobile-menu-button" type="button" onClick={() => setMobileNavigationOpen((open) => !open)} aria-label={mobileNavigationOpen ? 'नेविगेशन बंद करें' : 'नेविगेशन खोलें'} aria-expanded={mobileNavigationOpen} aria-controls="app-sidebar">☰</button>
            <div className="breadcrumbs"><span>Chess Game Master</span><span aria-hidden="true">/</span><strong>{TITLES[screen]}</strong></div>
            <div className="topbar-status"><span className="local-status-dot" /><span>स्थानीय मोड</span><button className="topbar-settings" type="button" onClick={() => navigate('settings')} aria-label="सेटिंग खोलें">⚙</button></div>
          </header>
          <main ref={mainRef} id="main-content" className="main-content" tabIndex={-1}>
            <ScreenContent screen={screen} reviewRecord={reviewRecord} practiceRecord={practiceRecord} onNavigate={navigate} onReview={openReview} onResume={resumePractice} />
          </main>
          <footer className="app-footer"><span>Chess Game Master · V1</span><span>मानक शतरंज · रेटिंग नहीं · स्थानीय</span></footer>
        </div>
        {mobileNavigationOpen && <button className="mobile-nav-backdrop" type="button" tabIndex={-1} aria-hidden="true" onClick={() => closeMobileNavigation(true)} />}
      </div>
    </StoreProvider>
  );
}
