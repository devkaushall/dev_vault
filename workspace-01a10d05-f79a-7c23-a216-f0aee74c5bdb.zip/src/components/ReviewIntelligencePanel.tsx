import type { ReviewAnalysisReport } from '../knowledge/reviewAnalysis';
import type { LearningInsightsResult } from '../knowledge/learningInsights';

export type ReviewIntelligencePanelProps = {
  report?: ReviewAnalysisReport;
  insights?: LearningInsightsResult;
  activePositionKey: string;
  activePly: number;
  status: 'idle' | 'loading' | 'ready' | 'error';
  persistence?: 'saving' | 'saved' | 'error';
  error?: string;
  onNavigate: (ply: number) => void;
};

function statusLabel(status: 'confirmed' | 'candidate' | 'deferred') {
  return status === 'confirmed' ? 'Confirmed' : status === 'candidate' ? 'Candidate' : 'Deferred';
}

const MOMENT_LABELS: Record<string, string> = {
  check: 'Check', checkmate: 'Checkmate', capture: 'Capture', tactic: 'Tactical cue',
  'material-change': 'Material change', 'king-safety-change': 'King-safety change',
  'piece-activity-change': 'Piece-activity change', 'pawn-break': 'Pawn-break cue',
  exchange: 'Exchange', 'opening-transition': 'Opening transition',
  'endgame-transition': 'Endgame transition', 'defensive-resource': 'Defensive resource',
  opportunity: 'Possible opportunity', repetition: 'Repetition',
  'perpetual-check-pattern': 'Perpetual-check pattern', promotion: 'Promotion',
  stalemate: 'Stalemate', 'strategic-cue': 'Strategic cue',
};

function momentLabel(category: string): string {
  return MOMENT_LABELS[category] ?? category.replaceAll('-', ' ');
}

function currentPositionExplanation(report: ReviewAnalysisReport, positionKey: string, ply: number) {
  const evidenceById = new Map(report.evidence.map((item) => [item.evidenceId, item]));
  const statusPriority = { confirmed: 0, candidate: 1, deferred: 2 } as const;
  const priority = (type: string, subtype: string) => {
    if (type === 'opening' && subtype === 'opening-match') return 0;
    if (type === 'move_classification' && subtype !== 'move-history') return 1;
    if (type === 'defence') return 2;
    if (type === 'tactic') return 3;
    if (type === 'endgame' && subtype !== 'material-phase-profile') return 4;
    if (type === 'king_safety' || type === 'attack') return 5;
    if (type === 'strategy' || type === 'pawn_structure') return 6;
    if (type === 'endgame') return 7;
    return 8;
  };
  return report.explanations.explanations
    .filter((explanation) => explanation.ply === ply
      && explanation.references.some((reference) => reference.kind === 'position' && reference.id === positionKey))
    .sort((a, b) => {
      const left = evidenceById.get(a.id.replace(/^ex_/, ''));
      const right = evidenceById.get(b.id.replace(/^ex_/, ''));
      return priority(left?.type ?? '', left?.subtype ?? '') - priority(right?.type ?? '', right?.subtype ?? '')
        || statusPriority[a.status] - statusPriority[b.status]
        || a.id.localeCompare(b.id);
    });
}

export function ReviewIntelligencePanel({ report, insights, activePositionKey, activePly, status, persistence, error, onNavigate }: ReviewIntelligencePanelProps) {
  const findings = report?.evidence.filter((item) => !(item.type === 'move_classification' && item.subtype === 'move-history')) ?? [];
  const confirmed = findings.filter((item) => item.status === 'confirmed').length;
  const candidate = findings.filter((item) => item.status === 'candidate').length;
  const deferred = findings.filter((item) => item.status === 'deferred').length;
  const moments = report?.keyMoments.moments ?? [];
  const explanations = report ? currentPositionExplanation(report, activePositionKey, activePly).slice(0, 8) : [];

  return (
    <section className="review-intelligence" aria-labelledby="review-intelligence-title">
      <header className="review-intelligence-header">
        <div>
          <p className="eyebrow">LOCAL · EVIDENCE-BOUND · NO ENGINE</p>
          <h2 id="review-intelligence-title">Evidence-based review</h2>
          <p>Deterministic findings and conditional explanations from the replayed game. The original move history stays read-only.</p>
        </div>
        <div className="review-intelligence-state" role="status">
          {status === 'loading' && <><span className="spinner" />Building local evidence…</>}
          {status === 'ready' && <><span className="review-state-dot" />Analysis ready{persistence === 'saved' ? ' · saved on this device' : persistence === 'saving' ? ' · saving locally…' : persistence === 'error' ? ' · local save unavailable' : ''}</>}
          {status === 'error' && <span className="review-state-error">Analysis unavailable</span>}
          {status === 'idle' && <span>Waiting for a completed game record</span>}
        </div>
      </header>

      {status === 'error' && <p className="review-intelligence-error" role="alert">{error ?? 'Evidence-based review could not be prepared.'}</p>}
      {status === 'ready' && report && (
        <>
          <div className="review-intelligence-counts" aria-label="Evidence status totals">
            <span className="review-status-chip review-status-confirmed">Confirmed <strong>{confirmed}</strong></span>
            <span className="review-status-chip review-status-candidate">Candidate <strong>{candidate}</strong></span>
            <span className="review-status-chip review-status-deferred">Deferred <strong>{deferred}</strong></span>
            <span className="review-coverage-note">Analyzed {report.aggregationPlies.length} of {report.totalPlies + 1} positions · skipped coverage remains deferred.</span>
          </div>

          <div className="review-intelligence-grid">
            <section className="review-intelligence-card" aria-labelledby="key-moments-title">
              <div className="review-panel-title"><div><p className="eyebrow">MOVE- AND POSITION-LINKED</p><h3 id="key-moments-title">Key moments</h3></div><span className="review-panel-count">{moments.length}</span></div>
              {moments.length ? (
                <ol className="review-moment-list">
                  {moments.slice(0, 12).map((moment) => {
                    const explanation = report.explanations.explanations.find((item) => item.evidenceIds.includes(moment.id));
                    return (
                      <li key={moment.id}>
                        <div className="review-moment-main">
                          <div className="review-moment-title-row">
                            <span className={`review-status-chip review-status-${moment.status}`}>{statusLabel(moment.status)}</span>
                            <strong>{momentLabel(moment.category)}</strong>
                            <span className="review-confidence">{moment.confidence} confidence</span>
                          </div>
                          <p>{explanation?.whatHappened ?? 'A linked evidence-based moment is available.'}</p>
                          {explanation?.whyItMatters && <small>{explanation.whyItMatters}</small>}
                          {explanation?.possibleIdeaOrThreat && <small>Possible idea: {explanation.possibleIdeaOrThreat}</small>}
                          {explanation?.candidateResponse && <small>Possible response: {explanation.candidateResponse}</small>}
                          {explanation?.learningTakeaway && <small>Learning takeaway: {explanation.learningTakeaway}</small>}
                          <small>Linked evidence records: {moment.evidenceIds.length} · Related {moment.san ? `move ${moment.ply}: ${moment.san}${moment.uci ? ` (${moment.uci})` : ''}` : `position at ply ${moment.ply}`} · {moment.side}</small>
                        </div>
                        <button type="button" className="button-small" onClick={() => onNavigate(moment.ply)} aria-label={`Show ${momentLabel(moment.category)} at ply ${moment.ply}`}>
                          View
                        </button>
                      </li>
                    );
                  })}
                </ol>
              ) : <p className="review-empty-note">No key moment crossed a supported detector threshold. This does not mean every position was motif-free.</p>}
              {moments.length > 12 && <p className="review-more-note">Showing the first 12 moments in ply order.</p>}
            </section>

            <section className="review-intelligence-card" aria-labelledby="position-explanations-title">
              <div className="review-panel-title"><div><p className="eyebrow">CURRENT BOARD POSITION</p><h3 id="position-explanations-title">What the evidence says</h3></div><span className="review-panel-count">{explanations.length}</span></div>
              {explanations.length ? (
                <ul className="review-explanation-list">
                  {explanations.map((explanation) => (
                    <li key={explanation.id}>
                      <div className="review-explanation-meta">
                        <span className={`review-status-chip review-status-${explanation.status}`}>{statusLabel(explanation.status)}</span>
                        <span>{explanation.confidence} confidence</span>
                        <span>· {explanation.concept}</span>
                      </div>
                      <p><strong>What happened:</strong> {explanation.whatHappened}</p>
                      <p><strong>Why it matters:</strong> {explanation.whyItMatters}</p>
                      {explanation.possibleIdeaOrThreat && <p><strong>Possible idea or threat:</strong> {explanation.possibleIdeaOrThreat}</p>}
                      {explanation.candidateResponse && <p><strong>Candidate response / line:</strong> {explanation.candidateResponse}</p>}
                      <p><strong>Learning takeaway:</strong> {explanation.learningTakeaway}</p>
                      <small>Linked evidence records: {explanation.evidenceIds.length} · {explanation.references.filter((reference) => reference.kind === 'position').map((reference) => `position ply ${reference.ply ?? '?'}`).join(', ') || 'position reference recorded'}</small>
                    </li>
                  ))}
                </ul>
              ) : <p className="review-empty-note">No explanation is attached to this exact board position. Unsupported analysis stays deferred; absence of a card is not a chess-quality judgment.</p>}
            </section>
          </div>

          <section className="review-insight-card" aria-labelledby="recurring-insights-title">
            <div className="review-panel-title"><div><p className="eyebrow">REPEATED EVIDENCE ONLY</p><h3 id="recurring-insights-title">Recurring study themes</h3></div><span className="review-panel-count">{insights?.insights.length ?? 0}</span></div>
            {insights?.insights.length ? (
              <ul className="review-insight-list">{insights.insights.map((insight) => <li key={insight.id}><span className="review-status-chip review-status-candidate">Candidate</span><div><strong>{insight.label}</strong><p>{insight.summary}</p><small>{insight.occurrenceCount} occurrences · {insight.distinctGameCount} games · {Math.round(insight.frequency * 100)}% of {insight.frequencyBasis === 'analyzed-positions' ? 'selected analyzed positions' : 'replayed moves'}</small></div></li>)}</ul>
            ) : (
              <p className="review-empty-note">No recurring cross-game theme met the current threshold ({insights?.thresholds.minimumOccurrences ?? 3} occurrences across {insights?.thresholds.minimumDistinctGames ?? 2} reviewed games). One incident is not a permanent player trait.</p>
            )}
          </section>
          <p className="review-intelligence-footer">No engine score, best-move ranking, rating, universal accuracy score, or claim about human intent is generated. Candidate and deferred labels retain their uncertainty.</p>
        </>
      )}
    </section>
  );
}
