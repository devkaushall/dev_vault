import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { applyMove, createGame } from '../domain/chess/session';
import { parseOpeningTsv } from '../knowledge/openings';
import { analyzeReviewRecord } from '../knowledge/reviewAnalysis';
import { ReviewIntelligencePanel } from './ReviewIntelligencePanel';

function reviewedGame() {
  let record = createGame({ id: 'review-panel-fixture', now: '2026-10-05T00:00:00.000Z' });
  record = applyMove(record, 'e2e4', { committedAt: '2026-10-05T00:00:01.000Z' }).record;
  record = applyMove(record, 'e7e5', { committedAt: '2026-10-05T00:00:02.000Z' }).record;
  return record;
}

describe('ReviewIntelligencePanel', () => {
  it('renders readable opening and moment explanations without exposing detector internals', async () => {
    const report = await analyzeReviewRecord(reviewedGame(), {
      catalog: parseOpeningTsv('eco\tname\tpgn\nC20\tKing\'s Pawn Game\t1. e4 e5'),
      maxAnalyzedPositions: 8,
    });
    const opening = report.evidence.find((item) => item.type === 'opening' && item.subtype === 'opening-match');
    const position = opening?.references.find((reference) => reference.kind === 'position');
    expect(position?.id).toBeTruthy();

    const { container } = render(<ReviewIntelligencePanel
      report={report}
      insights={{ schemaVersion: 1, thresholds: { minimumOccurrences: 3, minimumDistinctGames: 2, minimumFrequency: 0.08 }, insights: [], limitations: [] }}
      activePositionKey={position!.id}
      activePly={2}
      status="ready"
      persistence="saved"
      onNavigate={vi.fn()}
    />);

    expect(screen.getByText(/King's Pawn Game/)).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Key moments' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'What the evidence says' })).toBeInTheDocument();
    expect(container.textContent).toContain('Linked evidence records:');
    expect(container.textContent).not.toMatch(/Detection basis|tactics-detector|attack-detector|ev_tactic_/i);
    expect(container.textContent).not.toMatch(/Related move \d+: d4/);
    expect(container.textContent).not.toMatch(/best move|blunder|player intended/i);
  });

  it('shows only move explanations belonging to the selected ply, not an upcoming move from a shared before-position reference', async () => {
    const report = await analyzeReviewRecord(reviewedGame(), { maxAnalyzedPositions: 8 });
    const beforePosition = report.classification.evidence.find((item) => item.subtype === 'pawn-break')?.references
      .find((reference) => reference.kind === 'position' && reference.ply === 0);
    expect(beforePosition).toBeDefined();
    const { container } = render(<ReviewIntelligencePanel
      report={report}
      activePositionKey={beforePosition!.id}
      activePly={0}
      status="ready"
      onNavigate={vi.fn()}
    />);
    expect(container.textContent).not.toMatch(/The recorded move e4 has a pawn-break classification/);
  });
});
