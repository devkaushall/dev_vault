import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createGame } from '../domain/chess/session';
import { derivePosition } from '../domain/chess/position';
import { ChessBoard } from './ChessBoard';

describe('accessible chessboard', () => {
  it('offers validated legal destinations and emits UCI coordinates', async () => {
    const user = userEvent.setup();
    const onMove = vi.fn();
    const position = derivePosition(createGame({ mode: 'Practice' }));
    render(<ChessBoard position={position} onMove={onMove} />);

    const e2 = screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' });
    await user.click(e2);
    expect(e2).toHaveAttribute('aria-selected', 'true');
    expect(e2).not.toHaveAttribute('aria-pressed');
    expect(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' })).toBeInTheDocument();
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e4, वैध गंतव्य' }));

    expect(onMove).toHaveBeenCalledWith({ from: 'e2', to: 'e4' });
    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent('चाल e4.'));
  });

  it('supports arrow-key focus movement between squares', async () => {
    const user = userEvent.setup();
    const position = derivePosition(createGame({ mode: 'Practice' }));
    render(<ChessBoard position={position} onMove={() => undefined} />);
    const e2 = screen.getByRole('gridcell', { name: 'e2 पर सफ़ेद प्यादा' });
    e2.focus();
    await user.keyboard('{ArrowUp}');
    expect(screen.getByRole('gridcell', { name: 'खाली चौखाना e3' })).toHaveFocus();
  });

  it('traps promotion focus and returns it to the board when cancelled', async () => {
    const user = userEvent.setup();
    const onMove = vi.fn();
    const position = derivePosition(createGame({ mode: 'Practice', initialFen: '7k/P7/8/8/8/8/8/7K w - - 0 1' }));
    render(<ChessBoard position={position} onMove={onMove} />);

    await user.click(screen.getByRole('gridcell', { name: 'a7 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना a8, वैध गंतव्य' }));
    await user.keyboard('{Escape}');

    expect(screen.queryByRole('dialog', { name: 'गोटी चुनें' })).not.toBeInTheDocument();
    expect(screen.getByRole('gridcell', { name: 'खाली चौखाना a8' })).toHaveFocus();
    expect(onMove).not.toHaveBeenCalled();
  });

  it('requires an explicit promotion piece instead of auto-queening', async () => {
    const user = userEvent.setup();
    const onMove = vi.fn();
    const position = derivePosition(createGame({ mode: 'Practice', initialFen: '7k/P7/8/8/8/8/8/7K w - - 0 1' }));
    render(<ChessBoard position={position} onMove={onMove} />);

    await user.click(screen.getByRole('gridcell', { name: 'a7 पर सफ़ेद प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना a8, वैध गंतव्य' }));
    expect(screen.getByRole('dialog', { name: 'गोटी चुनें' })).toBeInTheDocument();
    const queen = screen.getByRole('button', { name: 'वज़ीर बनाएँ' });
    const cancel = screen.getByRole('button', { name: 'रद्द करें' });
    expect(queen).toHaveFocus();
    await user.keyboard('{Shift>}{Tab}{/Shift}');
    expect(cancel).toHaveFocus();
    await user.keyboard('{Tab}');
    expect(queen).toHaveFocus();
    await user.click(screen.getByRole('button', { name: 'घोड़ा बनाएँ' }));
    expect(onMove).toHaveBeenCalledWith({ from: 'a7', to: 'a8', promotion: 'n' });
  });
});
