import { useEffect, useMemo, useRef, useState } from 'react';
import { Chess } from 'chess.js';
import type { Color } from 'chess.js';
import { ChessBoard } from './ChessBoard';
import { pauseClock, persistClockSnapshot, restoreClock, snapshotClock, startClock, type ClockState } from '../domain/clock/ChessClock';
import { analyzeStaticPosition } from '../knowledge/positionFacts';
import { abortPractice, agreeDraw, applyMove, branchFromCursor, claimDraw, createGame, navigateToPly, recordTimeout, redoTakeback, resign, takeback } from '../domain/chess/session';
import { derivePosition } from '../domain/chess/position';
import { exportFen, exportPgn } from '../domain/chess/pgn';
import type { GameRecord, UciMove } from '../domain/chess/types';
import { modePolicy } from '../app/modePolicy';
import { presetForClock, readAppPreferences, TIME_CONTROL_PRESETS, timeControlForPreset, updateAppPreferences, type TimeControlPresetId } from '../app/preferences';
import { useLocalStore } from '../app/StoreContext';
import { ReviewIntelligencePanel } from './ReviewIntelligencePanel';
import { assertChessEvidence, type ChessEvidence } from '../knowledge/evidence';
import { loadBundledOpeningCatalog } from '../knowledge/openings';
import { analyzeReviewRecord, type ReviewAnalysisReport } from '../knowledge/reviewAnalysis';
import { deriveLearningInsights, type LearningEvidenceSet, type LearningInsightsResult } from '../knowledge/learningInsights';

export type ChessWorkspaceProps = {
  mode?: 'Practice' | 'Review';
  initialRecord?: GameRecord;
  title?: string;
  description?: string;
  initialFen?: string;
  onRetry?: (record: GameRecord) => void;
};

function resultLabel(record: GameRecord): string {
  if (record.status === 'adjudication-pending') return 'समय समाप्त · परिणाम का निर्णय लंबित';
  if (record.status === 'aborted') return 'खेल रोका गया · कोई शतरंज परिणाम दर्ज नहीं';
  if (!record.result) return 'खेल जारी है';
  const score = record.result.score;
  const reason: Record<string, string> = {
    checkmate: 'मात',
    stalemate: 'स्टेलमेट',
    'dead-position': 'अपर्याप्त सामग्री से ड्रॉ',
    'fivefold-repetition': 'स्थिति पाँच बार दोहराई गई',
    'seventy-five-move-rule': '75 चाल का स्वचालित ड्रॉ',
    'threefold-claim': 'तीन बार दोहराव का दावा',
    'fifty-move-claim': '50 चाल का दावा',
    resignation: 'समर्पण',
    'draw-agreement': 'ड्रॉ पर सहमति',
    timeout: 'समय समाप्त',
    'timeout-pending-adjudication': 'समय समाप्त · परिणाम की जाँच लंबित',
    'imported-result': 'आयातित PGN परिणाम · कारण अज्ञात',
    aborted: 'खेल रोका गया',
  };
  return `${score} · ${reason[record.result.reason] ?? record.result.reason}`;
}

function MoveHistory({ record, onNavigate }: { record: GameRecord; onNavigate: (ply: number) => void }) {
  if (!record.moveHistory.length) return <p className="empty-inline">चालें चलते ही यहाँ दिखाई देंगी।</p>;
  return (
    <ol className="move-history" aria-label="चालों का इतिहास">
      {record.moveHistory.map((move, index) => (
        <li key={`${move.ply}-${move.uci}`}>
          <span className="move-number">{Math.floor(index / 2) + 1}{index % 2 === 0 ? '.' : '…'}</span>
          <button
            type="button"
            className={`move-history-button${record.cursorPly === index + 1 ? ' current-move' : ''}`}
            aria-label={`चाल ${index + 1} पर जाएँ, ${move.san}`}
            aria-current={record.cursorPly === index + 1 ? 'step' : undefined}
            disabled={Boolean(record.clock)}
            onClick={() => onNavigate(index + 1)}
          >{move.san}</button>
        </li>
      ))}
    </ol>
  );
}

function saveTextFile(filename: string, text: string, mimeType: string) {
  const blob = new Blob([text], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  // Let the browser start the user-initiated download before releasing the URL.
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function historyFingerprint(record: GameRecord): string {
  const canonical = `${record.initialPosition.fen}|${record.moveHistory.map((move) => move.uci).join(' ')}`;
  let hash = 0x811c9dc5;
  for (let index = 0; index < canonical.length; index += 1) {
    hash ^= canonical.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return `history_${(hash >>> 0).toString(36).padStart(7, '0')}`;
}

function storedLearningSet(payload: Record<string, unknown>): LearningEvidenceSet | undefined {
  if (payload.analysisKind !== 'phase7-review' || payload.schemaVersion !== 1 || typeof payload.historyFingerprint !== 'string' || !Array.isArray(payload.evidence)) return undefined;
  const evidence: ChessEvidence[] = [];
  for (const entry of payload.evidence) {
    try { evidence.push(assertChessEvidence(entry as ChessEvidence)); }
    catch { return undefined; }
  }
  const totalPlies = Number(payload.totalPlies);
  const analyzedPositionCount = Number(payload.analyzedPositionCount);
  if (!Number.isInteger(totalPlies) || totalPlies < 0 || !Number.isInteger(analyzedPositionCount) || analyzedPositionCount < 0) return undefined;
  return { gameKey: payload.historyFingerprint, totalPlies, analyzedPositionCount, evidence };
}

async function savedReviewEvidenceSets(store: ReturnType<typeof useLocalStore>, currentHistory: string): Promise<LearningEvidenceSet[]> {
  const games = (await store.listGames()).filter((game) => game.moveHistory.length > 0).slice(0, 30);
  const loaded = await Promise.all(games.map(async (game) => {
    if (historyFingerprint(game) === currentHistory) return undefined;
    try {
      const analyses = await store.listAnalysis(game.id);
      const analysis = analyses.find((entry) => entry.payload.analysisKind === 'phase7-review');
      return analysis ? storedLearningSet(analysis.payload) : undefined;
    } catch {
      return undefined;
    }
  }));
  return loaded.filter((set): set is LearningEvidenceSet => Boolean(set));
}

function formatClock(milliseconds: number): string {
  const totalSeconds = Math.ceil(Math.max(0, milliseconds) / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export function ChessWorkspace({ mode = 'Practice', initialRecord, title, description, initialFen, onRetry }: ChessWorkspaceProps) {
  const store = useLocalStore();
  const [record, setRecord] = useState<GameRecord>(() => initialRecord ?? createGame({ mode, initialFen }));
  const initialClock = initialRecord?.clock ? restoreClock(initialRecord.clock) : undefined;
  const [liveClock, setLiveClock] = useState<ClockState | undefined>(initialClock);
  const [selectedTimeControl, setSelectedTimeControl] = useState<TimeControlPresetId>(() => presetForClock(initialRecord?.clock) ?? readAppPreferences().timeControlPresetId);
  const [clockNow, setClockNow] = useState(() => performance.now());
  const [clockMessage, setClockMessage] = useState('');
  const [orientation, setOrientation] = useState<Color>(() => readAppPreferences().boardOrientation);
  const [showCoordinates] = useState(() => readAppPreferences().coordinates);
  const [message, setMessage] = useState('');
  const [fenInput, setFenInput] = useState('');
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const saveQueue = useRef<Promise<void>>(Promise.resolve());
  const recordRef = useRef(record);
  const clockRef = useRef(liveClock);
  recordRef.current = record;
  clockRef.current = liveClock;
  const replaceRecord = (next: GameRecord) => { recordRef.current = next; setRecord(next); };
  const replaceClock = (next?: ClockState) => { clockRef.current = next; setLiveClock(next); setClockNow(performance.now()); };
  const enqueueGameSave = (snapshot: GameRecord) => {
    const write = saveQueue.current.catch(() => undefined).then(() => store.saveGame(structuredClone(snapshot)));
    saveQueue.current = write;
    return write;
  };
  const policy = modePolicy(mode);
  const position = useMemo(() => derivePosition(record), [record]);
  const facts = useMemo(() => analyzeStaticPosition(position.fen), [position.fen]);
  const lastMove = record.cursorPly > 0 ? record.moveHistory[record.cursorPly - 1] : undefined;
  const [reviewAnalysisStatus, setReviewAnalysisStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [reviewAnalysis, setReviewAnalysis] = useState<ReviewAnalysisReport>();
  const [learningInsights, setLearningInsights] = useState<LearningInsightsResult>();
  const [analysisPersistence, setAnalysisPersistence] = useState<'saving' | 'saved' | 'error'>();
  const [reviewAnalysisError, setReviewAnalysisError] = useState('');

  useEffect(() => {
    const hasDurableContent = mode === 'Review' || Boolean(initialRecord) || Boolean(record.clock)
      || record.moveHistory.length > 0 || record.events.length > 0 || record.variations.length > 0
      || record.initialPosition.kind !== 'standard' || record.status !== 'active';
    if (!hasDurableContent) {
      setSaveState('idle');
      return;
    }
    let active = true;
    setSaveState('saving');
    void enqueueGameSave(record).then(() => { if (active) setSaveState('saved'); }).catch((error: unknown) => {
      if (active) {
        setSaveState('error');
        setMessage(`यह खेल सहेजा नहीं गया: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण विफल'}`);
      }
    });
    return () => { active = false; };
  }, [record, store, initialRecord, mode]);

  const finishTimedGame = (game: GameRecord, clock: ClockState, nowMs: number) => {
    const side = clock.activeSide;
    if (!side) return;
    try {
      const next = recordTimeout(game, side, new Date().toISOString(), { clock, monotonicNowMs: nowMs });
      replaceRecord(next);
      replaceClock(next.clock ? restoreClock(next.clock) : undefined);
      setClockMessage(next.status === 'adjudication-pending' ? 'समय समाप्त। फ़्लैग का परिणाम सुरक्षित रूप से तय नहीं हो सका; खेल लॉक है।' : `समय समाप्त। ${resultLabel(next)}`);
      return next;
    } catch (error) {
      setSaveState('error');
      setMessage(error instanceof Error ? `घड़ी का परिणाम दर्ज नहीं हुआ: ${error.message}` : 'घड़ी का परिणाम दर्ज नहीं हुआ।');
      return undefined;
    }
  };

  const pauseForLifecycle = (announce: boolean, updateUi: boolean) => {
    if (mode !== 'Practice') return;
    const game = recordRef.current;
    const clock = clockRef.current;
    if (!game.clock || !clock || clock.paused || game.status !== 'active') return;
    const nowMs = performance.now();
    const display = snapshotClock(clock, nowMs);
    if (display.flaggedSide) {
      const next = recordTimeout(game, display.flaggedSide, new Date().toISOString(), { clock, monotonicNowMs: nowMs });
      if (updateUi) {
        replaceRecord(next);
        replaceClock(next.clock ? restoreClock(next.clock) : undefined);
        setClockMessage(next.status === 'adjudication-pending' ? 'समय समाप्त। परिणाम सुरक्षित रूप से तय नहीं हो सका; खेल लॉक है।' : `समय समाप्त। ${resultLabel(next)}`);
      } else {
        recordRef.current = next;
        clockRef.current = next.clock ? restoreClock(next.clock) : undefined;
      }
      void enqueueGameSave(next).catch(() => { if (updateUi) setSaveState('error'); });
      return;
    }
    const paused = pauseClock(clock, nowMs);
    const next = { ...game, clock: persistClockSnapshot(paused, nowMs), updatedAt: new Date().toISOString() };
    if (updateUi) {
      replaceClock(paused);
      replaceRecord(next);
      if (announce) setClockMessage('ऐप छिपने या अभ्यास छोड़ने पर घड़ी रुक गई। वापस आने पर इसे हाथ से फिर शुरू करें।');
    } else {
      clockRef.current = paused;
      recordRef.current = next;
    }
    void enqueueGameSave(next).then(() => { if (updateUi) setSaveState('saved'); }).catch((error: unknown) => {
      if (updateUi) {
        setSaveState('error');
        setMessage(`रुकी हुई घड़ी सहेजी नहीं गई: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण विफल'}`);
      }
    });
  };

  useEffect(() => {
    if (mode !== 'Practice' || !record.clock || !liveClock || liveClock.paused || record.status !== 'active') return;
    let active = true;
    let lastSnapshotMs = performance.now();
    let lastDisplayLabel = '';
    const tick = () => {
      const game = recordRef.current;
      const clock = clockRef.current;
      if (!game.clock || !clock || clock.paused || game.status !== 'active') return;
      const nowMs = performance.now();
      const display = snapshotClock(clock, nowMs);
      const displayLabel = `${formatClock(display.whiteRemainingMs)}|${formatClock(display.blackRemainingMs)}`;
      if (displayLabel !== lastDisplayLabel) {
        lastDisplayLabel = displayLabel;
        setClockNow(nowMs);
      }
      if (display.flaggedSide) {
        finishTimedGame(game, clock, nowMs);
        return;
      }
      if (nowMs - lastSnapshotMs >= 1_000) {
        lastSnapshotMs = nowMs;
        const snapshot = { ...game, clock: persistClockSnapshot(clock, nowMs), updatedAt: new Date().toISOString() };
        void enqueueGameSave(snapshot).then(() => { if (active) setSaveState('saved'); }).catch((error: unknown) => {
          if (!active) return;
          setSaveState('error');
          setMessage(`घड़ी का सुरक्षित snapshot नहीं सहेजा गया: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण विफल'}`);
        });
      }
    };
    const interval = window.setInterval(tick, 100);
    return () => { active = false; window.clearInterval(interval); };
  }, [mode, record.id, record.status, record.cursorPly, record.updatedAt, liveClock?.paused, liveClock?.activeSide, liveClock?.revision]);

  useEffect(() => {
    if (mode !== 'Practice') return;
    const onVisibilityChange = () => { if (document.visibilityState === 'hidden') pauseForLifecycle(true, true); };
    const onPageHide = () => pauseForLifecycle(false, false);
    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pagehide', onPageHide);
      // Route changes/unmounts pause and persist. A crash is bounded by the most recent 1s snapshot.
      pauseForLifecycle(false, false);
    };
  }, [mode, store]);

  useEffect(() => {
    if (mode !== 'Review' || !initialRecord) {
      setReviewAnalysisStatus('idle');
      setReviewAnalysis(undefined);
      setLearningInsights(undefined);
      setAnalysisPersistence(undefined);
      setReviewAnalysisError('');
      return;
    }
    let active = true;
    setReviewAnalysisStatus('loading');
    setReviewAnalysis(undefined);
    setLearningInsights(undefined);
    setAnalysisPersistence('saving');
    setReviewAnalysisError('');
    void (async () => {
      let catalog;
      try { catalog = await loadBundledOpeningCatalog(); }
      catch { catalog = undefined; }
      const report = await analyzeReviewRecord(initialRecord, { catalog });
      const fingerprint = historyFingerprint(initialRecord);
      let persistence: 'saved' | 'error' = 'saved';
      try {
        await store.saveAnalysis({
          id: `phase7-review-v1:${fingerprint}`,
          gameId: initialRecord.id,
          updatedAt: new Date().toISOString(),
          payload: {
            analysisKind: 'phase7-review',
            schemaVersion: 1,
            historyFingerprint: fingerprint,
            totalPlies: report.totalPlies,
            analyzedPositionCount: report.aggregationPlies.length,
            evidence: report.evidence,
          },
        });
      } catch { persistence = 'error'; }
      let priorSets: LearningEvidenceSet[] = [];
      try { priorSets = await savedReviewEvidenceSets(store, fingerprint); }
      catch { /* recurring insights remain limited to the current review if local reads fail */ }
      const insights = deriveLearningInsights([
        ...priorSets,
        { gameKey: fingerprint, totalPlies: report.totalPlies, analyzedPositionCount: report.aggregationPlies.length, evidence: report.evidence },
      ]);
      if (!active) return;
      setReviewAnalysis(report);
      setLearningInsights(insights);
      setAnalysisPersistence(persistence);
      setReviewAnalysisStatus('ready');
    })().catch((reason: unknown) => {
      if (!active) return;
      setReviewAnalysisError(reason instanceof Error ? reason.message : 'The evidence analysis failed.');
      setAnalysisPersistence('error');
      setReviewAnalysisStatus('error');
    });
    return () => { active = false; };
  }, [initialRecord, mode, store]);

  const announceMove = (move: UciMove) => {
    const current = recordRef.current;
    try {
      if (current.cursorPly < current.moveHistory.length) {
        setMessage('पुरानी चाल-स्थिति से आगे खेलने के लिए पहले “यहाँ शाखा बनाएँ” चुनें।');
        return;
      }
      const nowMs = performance.now();
      const activeClock = clockRef.current;
      if (current.clock && activeClock && !activeClock.paused) {
        const display = snapshotClock(activeClock, nowMs);
        if (display.flaggedSide) {
          finishTimedGame(current, activeClock, nowMs);
          return;
        }
      }
      const result = applyMove(current, move, {
        committedAt: new Date().toISOString(),
        ...(current.clock && activeClock ? { clock: activeClock, monotonicNowMs: nowMs } : {}),
      });
      replaceRecord(result.record);
      if (result.clock) replaceClock(result.clock);
      setClockMessage('');
      setMessage(`${result.move.san} खेली गई। ${result.record.result ? resultLabel(result.record) : ''}`.trim());
    } catch (error) {
      setMessage(error instanceof Error ? `चाल नहीं चली गई: ${error.message}` : 'चाल दर्ज नहीं हो सकी।');
    }
  };

  const newGame = () => {
    pauseForLifecycle(false, true);
    const timeControl = mode === 'Practice' ? timeControlForPreset(selectedTimeControl) : undefined;
    const next = createGame({ mode, initialFen, ...(timeControl ? { timeControl } : {}) });
    replaceRecord(next);
    replaceClock(next.clock ? restoreClock(next.clock) : undefined);
    setFenInput('');
    setClockMessage('');
    setMessage(next.clock ? 'नया बोर्ड तैयार है। घड़ी शुरू करने के लिए चलाएँ दबाएँ।' : 'नया स्थानीय अभ्यास बोर्ड तैयार है।');
  };

  const loadFen = () => {
    try {
      const fen = fenInput.trim();
      if (!fen) throw new Error('पहले FEN स्थिति पेस्ट करें।');
      if (fen.length > 256) throw new Error('FEN इनपुट अधिकतम 256 अक्षर का हो सकता है।');
      const validated = new Chess(fen);
      pauseForLifecycle(false, true);
      const timeControl = timeControlForPreset(selectedTimeControl);
      const next = createGame({ mode: 'Practice', initialFen: validated.fen({ forceEnpassantSquare: true }), ...(timeControl ? { timeControl } : {}) });
      replaceRecord(next);
      replaceClock(next.clock ? restoreClock(next.clock) : undefined);
      setFenInput('');
      setClockMessage('');
      setMessage(`जाँचा हुआ FEN नई${next.clock ? ' घड़ी वाली' : ''} स्थिति के रूप में लोड हुआ। FEN से पुराना दोहराव-इतिहास नहीं निकाला गया।`);
    } catch (error) {
      setMessage(`FEN लोड नहीं हुआ: ${error instanceof Error ? error.message : 'अमान्य स्थिति'}`);
    }
  };

  const goToPly = (ply: number) => {
    try {
      setRecord((current) => navigateToPly(current, ply));
      setMessage(`चाल ${ply} के बाद की स्थिति दिखाई जा रही है।`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not navigate to that move.');
    }
  };

  const doTakeback = () => {
    try {
      setRecord((current) => takeback(current));
      setMessage('पिछली चाल वापस ली और अलग variation के रूप में रखी।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Takeback unavailable.');
    }
  };

  const doRedo = () => {
    try {
      setRecord((current) => redoTakeback(current));
      setMessage('हाल की सुरक्षित चाल-शाखा वापस लाई गई।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Redo unavailable.');
    }
  };

  const doBranch = () => {
    try {
      setRecord((current) => branchFromCursor(current));
      setMessage('अलग variation सहेजी गई; अब इस स्थिति से आगे खेलें।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not create a variation.');
    }
  };

  const clockOptionsForTerminalAction = (game: GameRecord): { clock: ClockState; monotonicNowMs: number } | Record<string, never> | null => {
    if (!game.clock) return {};
    const clock = clockRef.current;
    if (!clock) throw new Error('इस timed game की live clock उपलब्ध नहीं है।');
    const sideToMove = derivePosition(game).turn;
    if (clock.activeSide !== sideToMove) throw new Error('सहेजी घड़ी और बोर्ड का side-to-move मेल नहीं खाते।');
    if (clock.paused && (clock.activeSide === 'w' ? clock.whiteRemainingMs : clock.blackRemainingMs) <= 0) {
      throw new Error('घड़ी पहले ही शून्य पर है; इसे फिर नहीं चलाया जा सकता।');
    }
    const nowMs = performance.now();
    if (!clock.paused) {
      const display = snapshotClock(clock, nowMs);
      if (display.flaggedSide) {
        finishTimedGame(game, clock, nowMs);
        return null;
      }
    }
    return { clock, monotonicNowMs: nowMs };
  };

  const doClaim = (reason: 'threefold-repetition' | 'fifty-move-rule') => {
    const current = recordRef.current;
    try {
      const currentPosition = derivePosition(current);
      const claim = currentPosition.drawState.intendedClaims.find((option) => option.reason === reason) ?? {
        reason,
        kind: 'current-position' as const,
      };
      const clockOptions = clockOptionsForTerminalAction(current);
      if (!clockOptions) return;
      const next = claimDraw(current, claim, currentPosition.turn, undefined, clockOptions);
      replaceRecord(next);
      if (next.clock) replaceClock(restoreClock(next.clock));
      setMessage(`${currentPosition.turn === 'w' ? 'सफ़ेद' : 'काला'} ने ड्रॉ का दावा किया।`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'That draw claim is not available.');
    }
  };

  const doAbortPractice = () => {
    if (!window.confirm('स्थानीय अभ्यास रोकें? चालों का इतिहास रहेगा, लेकिन कोई जीत, हार या ड्रॉ परिणाम नहीं दिया जाएगा।')) return;
    const current = recordRef.current;
    try {
      const clockOptions = clockOptionsForTerminalAction(current);
      if (!clockOptions) return;
      const next = abortPractice(current, new Date().toISOString(), clockOptions);
      replaceRecord(next);
      if (next.clock) replaceClock(restoreClock(next.clock));
      setMessage('अभ्यास रोका गया; कोई शतरंज परिणाम नहीं जोड़ा गया।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'अभ्यास नहीं रोका जा सका।');
    }
  };

  const doResign = () => {
    const current = recordRef.current;
    const side = derivePosition(current).turn;
    if (!window.confirm(`${side === 'w' ? 'सफ़ेद' : 'काला'} समर्पण करे?`)) return;
    try {
      const clockOptions = clockOptionsForTerminalAction(current);
      if (!clockOptions) return;
      const next = current.clock
        ? resign(current, side, new Date().toISOString(), clockOptions)
        : resign(current, side);
      replaceRecord(next);
      if (next.clock) replaceClock(restoreClock(next.clock));
      setMessage('समर्पण दर्ज किया गया।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not record resignation.');
    }
  };

  const doAgreeDraw = () => {
    if (!window.confirm('क्या दोनों पक्ष इस स्थानीय अभ्यास खेल को ड्रॉ पर समाप्त करने के लिए सहमत हैं?')) return;
    const current = recordRef.current;
    try {
      const clockOptions = clockOptionsForTerminalAction(current);
      if (!clockOptions) return;
      const next = current.clock
        ? agreeDraw(current, new Date().toISOString(), clockOptions)
        : agreeDraw(current);
      replaceRecord(next);
      if (next.clock) replaceClock(restoreClock(next.clock));
      setMessage('दोनों पक्ष ड्रॉ पर सहमत हुए।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not record draw agreement.');
    }
  };

  const togglePracticeClock = () => {
    const current = recordRef.current;
    const clock = clockRef.current;
    if (!current.clock || !clock || current.status !== 'active') return;
    const nowMs = performance.now();
    try {
      if (clock.paused) {
        const sideToMove = derivePosition(current).turn;
        if (clock.activeSide !== sideToMove) throw new Error('सहेजी घड़ी और बोर्ड का side-to-move मेल नहीं खाते।');
        const started = startClock(clock, sideToMove, nowMs);
        replaceClock(started);
        setClockMessage('घड़ी चल रही है। टैब छिपाने या अभ्यास छोड़ने पर यह अपने-आप रुकेगी।');
      } else {
        const display = snapshotClock(clock, nowMs);
        if (display.flaggedSide) {
          finishTimedGame(current, clock, nowMs);
          return;
        }
        const paused = pauseClock(clock, nowMs);
        const next = { ...current, clock: persistClockSnapshot(paused, nowMs), updatedAt: new Date().toISOString() };
        replaceClock(paused);
        replaceRecord(next);
        setClockMessage('घड़ी रुकी है। दबाकर फिर से शुरू करें।');
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'घड़ी नहीं बदली जा सकी।');
    }
  };

  const retrySave = async () => {
    setSaveState('saving');
    try {
      await enqueueGameSave(recordRef.current);
      setSaveState('saved');
      setMessage('खेल इस डिवाइस पर सहेजा गया।');
    } catch (error) {
      setSaveState('error');
      setMessage(`सहेजना विफल हुआ: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण विफल'}`);
    }
  };

  const handleExportPgn = () => {
    try {
      const safeId = record.id.replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 80) || 'game';
      saveTextFile(`${safeId}.pgn`, exportPgn(record), 'application/x-chess-pgn;charset=utf-8');
      setMessage('वैध चाल-इतिहास से PGN निर्यात हुआ।');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'PGN export failed.');
    }
  };

  const copyFen = async () => {
    try {
      await navigator.clipboard.writeText(exportFen(record));
      setMessage('मौजूदा FEN कॉपी हुआ। इसमें पिछला repetition history शामिल नहीं है।');
    } catch {
      setMessage('Clipboard उपलब्ध नहीं है; नीचे FEN फ़ील्ड चुनकर कॉपी करें।');
    }
  };

  const promotionMove = (move: UciMove) => announceMove(move);
  const clockDisplay = liveClock ? snapshotClock(liveClock, clockNow) : undefined;
  const selectableMoves = policy.acceptsBoardMoves
    && record.status === 'active'
    && (!record.clock || Boolean(liveClock && !liveClock.paused));
  const canEndOrClaim = policy.acceptsBoardMoves && record.status === 'active';

  return (
    <section className="screen-content workspace-screen">
      <header className="screen-heading workspace-heading">
        <div>
          <p className="eyebrow">{mode === 'Review' ? 'खेल की समीक्षा' : 'स्थानीय अभ्यास'}</p>
          <h1>{title ?? (mode === 'Review' ? 'खेल की समीक्षा' : 'अभ्यास बोर्ड')}</h1>
          <p className="screen-description">{description ?? (mode === 'Review' ? 'आयातित या सहेजी चालें देखें। मूल चाल-इतिहास केवल-पठन है।' : 'वैध चालों के साथ स्वतंत्र अभ्यास करें। कोई रेटिंग, engine सुझाव या मानवीय मंशा का दावा नहीं।')}</p>
        </div>
        <div className="workspace-status">
          <span className={`mode-pill ${mode === 'Review' ? 'mode-review' : 'mode-practice'}`}>{mode === 'Review' ? 'समीक्षा · केवल-पठन' : 'अभ्यास · इंजन बंद'}</span>
          <span className={`save-indicator save-${saveState}`} role="status">
            <i aria-hidden="true" />{saveState === 'idle' ? 'पहली चाल पर सहेजा जाएगा' : saveState === 'saved' ? 'इस डिवाइस पर सहेजा' : saveState === 'saving' ? 'स्थानीय रूप से सहेज रहे हैं…' : 'सहेजा नहीं गया'}
          </span>
        </div>
      </header>

      {saveState === 'error' && (
        <div className="save-warning" role="alert">
          <strong>सहेजना विफल हुआ।</strong> बोर्ड अभी स्क्रीन पर है, लेकिन स्थायी रूप से सहेजा नहीं गया है।
          <button type="button" className="button-small" onClick={retrySave}>फिर से सहेजें</button>
        </div>
      )}

      <div className="workspace-grid">
        <div className="board-column">
          <div className="board-controls">
            <span className="turn-indicator"><i className={position.turn === 'w' ? 'turn-white' : 'turn-black'} />{position.turn === 'w' ? 'सफ़ेद' : 'काला'} की चाल</span>
            <button className="button-quiet" type="button" onClick={() => setOrientation((current) => {
              const next = current === 'w' ? 'b' : 'w';
              updateAppPreferences({ boardOrientation: next });
              return next;
            })} aria-label="बोर्ड की दिशा पलटें">↻ <span>पलटें</span></button>
          </div>
          {mode === 'Practice' && (
            <section className="practice-clock-panel" aria-label="अभ्यास की समय घड़ी">
              <label className="clock-preset-label">
                <span>समय नियंत्रण · अगली बाज़ी</span>
                <select aria-label="नई बाज़ी के लिए समय नियंत्रण" value={selectedTimeControl} onChange={(event) => {
                  const value = event.target.value as TimeControlPresetId;
                  setSelectedTimeControl(value);
                  updateAppPreferences({ timeControlPresetId: value });
                }}>
                  {TIME_CONTROL_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label}</option>)}
                </select>
              </label>
              <p className="clock-preset-note">यह चयन नया बोर्ड या नया FEN लोड करने पर लागू होगा। दोनों रंग इसी डिवाइस पर खेलेंगे।</p>
              {record.clock && clockDisplay && (
                <>
                  <div className="clock-readouts" aria-label="शेष समय">
                    <div className={`clock-readout${clockDisplay.activeSide === 'w' && !clockDisplay.paused ? ' clock-active' : ''}`}><span>सफ़ेद</span><output aria-live="off" aria-label={`सफ़ेद की घड़ी ${formatClock(clockDisplay.whiteRemainingMs)}`}>{formatClock(clockDisplay.whiteRemainingMs)}</output></div>
                    <div className={`clock-readout${clockDisplay.activeSide === 'b' && !clockDisplay.paused ? ' clock-active' : ''}`}><span>काला</span><output aria-live="off" aria-label={`काले की घड़ी ${formatClock(clockDisplay.blackRemainingMs)}`}>{formatClock(clockDisplay.blackRemainingMs)}</output></div>
                  </div>
                  {record.status === 'active' && <button className="button-secondary clock-toggle" type="button" onClick={togglePracticeClock} aria-pressed={!clockDisplay.paused}>{clockDisplay.paused ? 'घड़ी शुरू / फिर चलाएँ' : 'घड़ी रोकें'}</button>}
                  <p className="clock-preset-note">{clockDisplay.paused ? (record.status === 'active' ? 'घड़ी रुकी है; बोर्ड चालें चलाने के लिए घड़ी शुरू करें।' : resultLabel(record)) : `${clockDisplay.activeSide === 'w' ? 'सफ़ेद' : 'काला'} की चाल की घड़ी चल रही है। ऐप छिपाने पर घड़ी अपने-आप रुकेगी।`}</p>
                </>
              )}
              {clockMessage && <p className="clock-message" role="status" aria-live="polite">{clockMessage}</p>}
            </section>
          )}
          <ChessBoard
            position={position}
            orientation={orientation}
            showCoordinates={showCoordinates}
            disabled={!selectableMoves}
            lastMove={lastMove ? { from: lastMove.from, to: lastMove.to } : undefined}
            onMove={promotionMove}
          />
          <div className="result-banner" aria-live="polite">
            <span className={`result-mark ${record.result?.score === '1-0' ? 'white-won' : record.result?.score === '0-1' ? 'black-won' : record.result ? 'draw-result' : ''}`} aria-hidden="true" />
            <div><strong>{resultLabel(record)}</strong><small>{record.status === 'adjudication-pending' ? 'खेल लॉक है। फ़्लैग के बाद वैध परिणाम तय करने के लिए निर्णायक की आवश्यकता है।' : position.checkmate ? 'राजा मात में है।' : position.inCheck ? 'शह — अब वैध बचाव चाल चलें।' : `इस स्थिति में ${position.legalMoves.length} वैध चालें हैं।`}</small></div>
          </div>
          {message && <p className="workspace-message" role="status" aria-live="polite">{message}</p>}
        </div>

        <aside className="workspace-panel" aria-label="खेल नियंत्रण और बोर्ड के तथ्य">
          <div className="panel-tabs"><span className="panel-tab-active">चालें</span><span>बोर्ड के तथ्य</span></div>
          <div className="moves-toolbar">
            <span className="panel-title">चालों की सूची</span>
            <span className="move-count">{record.moveHistory.length} ply</span>
          </div>
          <div className="move-list-scroll"><MoveHistory record={record} onNavigate={goToPly} /></div>
          <div className="history-navigation">
            <button type="button" className="button-icon" onClick={() => goToPly(0)} aria-label="शुरुआती स्थिति पर जाएँ" disabled={Boolean(record.clock)}>|◀</button>
            <button type="button" className="button-icon" onClick={() => goToPly(Math.max(0, record.cursorPly - 1))} aria-label="पिछली स्थिति" disabled={Boolean(record.clock)}>‹</button>
            <button type="button" className="button-icon" onClick={() => goToPly(Math.min(record.moveHistory.length, record.cursorPly + 1))} aria-label="अगली स्थिति" disabled={Boolean(record.clock)}>›</button>
            <button type="button" className="button-icon" onClick={() => goToPly(record.moveHistory.length)} aria-label="नवीनतम स्थिति पर जाएँ" disabled={Boolean(record.clock)}>▶|</button>
          </div>

          <div className="panel-divider" />
          <section className="board-facts" aria-labelledby="facts-title">
            <div className="panel-section-heading"><div><p className="eyebrow">स्थिति का सार</p><h2 id="facts-title">बोर्ड के तथ्य</h2></div><span className="verified-chip">नियम-आधारित</span></div>
            <p className="facts-note">इसी बोर्ड से निकले तथ्य; engine evaluation नहीं।</p>
            <ul className="fact-list">
              {facts.facts.slice(0, 5).map((fact) => <li key={fact.id}><span className="fact-bullet" aria-hidden="true">✓</span><div><strong>{fact.title}</strong><p>{fact.explanation}</p></div></li>)}
            </ul>
            {facts.candidates.length > 0 && (
              <div className="candidate-facts">
                <p className="candidate-label">संभावित motif · गणना/पुष्टि नहीं</p>
                {facts.candidates.slice(0, 2).map((candidate) => <p key={candidate.id}>{candidate.title}</p>)}
              </div>
            )}
          </section>

          {canEndOrClaim && (
            <section className="draw-claims" aria-label="ड्रॉ के दावे">
              {(position.drawState.canClaimThreefoldNow || position.drawState.intendedClaims.some((claim) => claim.reason === 'threefold-repetition')) && (
                <button type="button" className="button-small" onClick={() => doClaim('threefold-repetition')}>तीन बार दोहराव पर ड्रॉ का दावा</button>
              )}
              {(position.drawState.canClaimFiftyMovesNow || position.drawState.intendedClaims.some((claim) => claim.reason === 'fifty-move-rule')) && (
                <button type="button" className="button-small" onClick={() => doClaim('fifty-move-rule')}>50 चाल के नियम पर ड्रॉ का दावा</button>
              )}
            </section>
          )}

          {mode === 'Practice' && (
            <section className="practice-actions" aria-label="अभ्यास नियंत्रण">
              <div className="panel-section-heading"><div><p className="eyebrow">अभ्यास</p><h2>नियंत्रण</h2></div></div>
              <div className="action-grid">
                <button className="button-small" type="button" onClick={doTakeback} disabled={record.cursorPly === 0 || Boolean(record.clock)} title={record.clock ? 'समय वाली बाज़ी में वापस लेना बंद है।' : undefined}>वापस लें</button>
                <button className="button-small" type="button" onClick={doRedo} disabled={!record.variations.length || Boolean(record.clock)} title={record.clock ? 'समय वाली बाज़ी में पुरानी चाल फिर नहीं चलाई जा सकती।' : undefined}>चाल-शाखा फिर चलाएँ</button>
                {record.cursorPly < record.moveHistory.length && <button className="button-small action-wide" type="button" onClick={doBranch} disabled={Boolean(record.clock)}>यहाँ शाखा बनाएँ</button>}
                <button className="button-small action-wide" type="button" onClick={newGame}>नया बोर्ड</button>
                {canEndOrClaim && record.moveHistory.length > 0 && <button className="button-small action-wide" type="button" onClick={doResign}>मौजूदा पक्ष समर्पण करे</button>}
                {canEndOrClaim && record.moveHistory.length > 0 && <button className="button-small action-wide" type="button" onClick={doAgreeDraw}>दोनों पक्ष ड्रॉ पर सहमत</button>}
                {canEndOrClaim && record.moveHistory.length > 0 && <button className="button-small action-wide" type="button" onClick={doAbortPractice}>बिना परिणाम अभ्यास रोकें</button>}
              </div>
              <label className="fen-field">
                <span>FEN स्थिति लोड करें</span>
                <textarea value={fenInput} onChange={(event) => setFenInput(event.target.value)} rows={2} maxLength={256} placeholder="छह फ़ील्ड वाला FEN पेस्ट करें" aria-label="FEN इनपुट" />
              </label>
              <button className="button-secondary full-width" type="button" onClick={loadFen}>FEN जाँचें और लोड करें</button>
              <div className="export-actions">
                <button className="button-link" type="button" onClick={copyFen}>मौजूदा FEN कॉपी करें</button>
                <button className="button-link" type="button" onClick={handleExportPgn}>PGN निर्यात करें</button>
              </div>
              <label className="fen-field export-fen-field">
                <span>निकला हुआ FEN checkpoint</span>
                <textarea readOnly value={exportFen(record)} rows={2} aria-label="मौजूदा derived FEN" onFocus={(event) => event.currentTarget.select()} />
                <small>FEN snapshot से पिछला दोहराव या पूरा खेल-इतिहास वापस नहीं मिलता।</small>
              </label>
            </section>
          )}

          {mode === 'Review' && (
            <section className="review-meta">
              <p className="eyebrow">मूल खेल-रिकॉर्ड</p>
              <p>समीक्षा में चालों पर जाना आयातित चाल-क्रम को नहीं बदलता।</p>
              {onRetry && <button className="button-primary full-width" type="button" onClick={() => onRetry(record)}>इस स्थिति पर अभ्यास करें</button>}
              <button className="button-secondary full-width" type="button" onClick={handleExportPgn}>PGN निर्यात करें</button>
            </section>
          )}

          <footer className="workspace-footer-note">केवल स्थानीय · cloud upload नहीं · मानव प्रतिस्पर्धी मोड नहीं</footer>
        </aside>
      </div>
      {mode === 'Review' && <ReviewIntelligencePanel
        report={reviewAnalysis}
        insights={learningInsights}
        activePositionKey={position.positionKey}
        activePly={record.cursorPly}
        status={reviewAnalysisStatus}
        persistence={analysisPersistence}
        error={reviewAnalysisError}
        onNavigate={goToPly}
      />}
    </section>
  );
}
