import { useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import type { Color, PieceSymbol, Square } from 'chess.js';
import type { PositionSnapshot, UciMove } from '../domain/chess/types';

const PIECE_GLYPHS: Record<Color, Record<PieceSymbol, string>> = {
  w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
  b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' },
};
const PIECE_NAMES: Record<PieceSymbol, string> = { k: 'राजा', q: 'वज़ीर', r: 'हाथी', b: 'ऊँट', n: 'घोड़ा', p: 'प्यादा' };
const FILES = 'abcdefgh';
const PROMOTION_ORDER: Array<Exclude<PieceSymbol, 'p' | 'k'>> = ['q', 'r', 'b', 'n'];
const PROMOTION_ACTIONS: Record<Exclude<PieceSymbol, 'p' | 'k'>, string> = { q: 'वज़ीर बनाएँ', r: 'हाथी बनाएँ', b: 'ऊँट बनाएँ', n: 'घोड़ा बनाएँ' };

export type ChessBoardProps = {
  position: PositionSnapshot;
  orientation?: Color;
  showCoordinates?: boolean;
  disabled?: boolean;
  lastMove?: { from: Square; to: Square };
  onMove: (move: UciMove) => void;
};

function pieceAt(position: PositionSnapshot, square: Square) {
  for (const row of position.board) {
    const piece = row.find((item) => item?.square === square);
    if (piece) return piece;
  }
  return null;
}

export function ChessBoard({ position, orientation = 'w', showCoordinates = true, disabled = false, lastMove, onMove }: ChessBoardProps) {
  const [selected, setSelected] = useState<Square>();
  const [focused, setFocused] = useState<Square>('e2');
  const [promotionMoves, setPromotionMoves] = useState<PositionSnapshot['legalMoves']>();
  const [announcement, setAnnouncement] = useState('');
  const squareButtons = useRef(new Map<Square, HTMLButtonElement>());
  const promotionDialog = useRef<HTMLDivElement>(null);
  const promotionOrigin = useRef<Square | undefined>(undefined);
  const priorPositionFen = useRef(position.fen);

  const ranks = useMemo(() => orientation === 'w' ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8], [orientation]);
  const files = useMemo(() => orientation === 'w' ? [...FILES] : [...FILES].reverse(), [orientation]);
  const legalFromSelected = selected ? position.legalMoves.filter((move) => move.from === selected) : [];
  const destinations = new Set(legalFromSelected.map((move) => move.to));
  const lastFrom = lastMove?.from;
  const lastTo = lastMove?.to;
  const checkedKing = position.inCheck
    ? position.board.flat().find((piece) => piece?.type === 'k' && piece.color === position.turn)?.square
    : undefined;

  useEffect(() => {
    if (priorPositionFen.current === position.fen) return;
    priorPositionFen.current = position.fen;
    setSelected(undefined);
    setPromotionMoves(undefined);
  }, [position.fen]);

  useEffect(() => {
    if (promotionMoves?.length) {
      promotionDialog.current?.querySelector<HTMLButtonElement>('button:not([disabled])')?.focus();
      return;
    }
    const origin = promotionOrigin.current;
    if (origin) {
      squareButtons.current.get(origin)?.focus();
      promotionOrigin.current = undefined;
    }
  }, [promotionMoves]);

  const closePromotion = () => {
    setSelected(undefined);
    setPromotionMoves(undefined);
    setAnnouncement('पदोन्नति रद्द हुई। चाल नहीं चली गई।');
  };

  const onPromotionKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closePromotion();
      return;
    }
    if (event.key !== 'Tab') return;
    const dialog = promotionDialog.current;
    if (!dialog) return;
    const controls = [...dialog.querySelectorAll<HTMLButtonElement>('button:not([disabled])')];
    const first = controls[0];
    const last = controls.at(-1);
    if (!first || !last) return;
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const commitMove = (move: PositionSnapshot['legalMoves'][number]) => {
    setSelected(undefined);
    setPromotionMoves(undefined);
    setAnnouncement(`चाल ${move.san}.`);
    onMove({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion as Exclude<PieceSymbol, 'p' | 'k'> } : {}) });
  };

  const activateSquare = (square: Square) => {
    if (disabled || position.checkmate || position.stalemate || position.result) return;
    if (selected) {
      const candidates = position.legalMoves.filter((move) => move.from === selected && move.to === square);
      if (candidates.length > 1 && candidates.some((move) => move.promotion)) {
        promotionOrigin.current = square;
        setPromotionMoves(candidates);
        setAnnouncement(`${square} पर पदोन्नति के लिए गोटी चुनें।`);
        return;
      }
      if (candidates.length === 1) {
        commitMove(candidates[0]);
        return;
      }
    }

    const piece = pieceAt(position, square);
    if (piece?.color === position.turn) {
      setSelected(square);
      setFocused(square);
      const legalCount = position.legalMoves.filter((move) => move.from === square).length;
      setAnnouncement(legalCount ? `${square} पर ${piece.color === 'w' ? 'सफ़ेद' : 'काले'} ${PIECE_NAMES[piece.type]} चुना। अब वैध गंतव्य चुनें।` : `${square} से कोई वैध चाल नहीं है।`);
      return;
    }
    if (selected) setAnnouncement(`${square} वैध गंतव्य नहीं है। चुनी गई गोटी ${selected} पर बनी रहेगी।`);
  };

  const onSquareKeyDown = (event: KeyboardEvent<HTMLButtonElement>, square: Square) => {
    const row = ranks.indexOf(Number(square[1]));
    const column = files.indexOf(square[0]);
    let nextRow = row;
    let nextColumn = column;
    if (event.key === 'ArrowUp') nextRow--;
    else if (event.key === 'ArrowDown') nextRow++;
    else if (event.key === 'ArrowLeft') nextColumn--;
    else if (event.key === 'ArrowRight') nextColumn++;
    else return;
    event.preventDefault();
    if (nextRow < 0 || nextRow > 7 || nextColumn < 0 || nextColumn > 7) return;
    const target = `${files[nextColumn]}${ranks[nextRow]}` as Square;
    setFocused(target);
    squareButtons.current.get(target)?.focus();
  };

  return (
    <div className="board-frame">
      <div className="board-player-bar board-player-top" aria-hidden="true">
        <span className={`player-piece-dot ${orientation === 'w' ? 'dark' : 'light'}`} />
        <span>{orientation === 'w' ? 'काला' : 'सफ़ेद'}</span>
        <span className="board-side-label">{position.turn === (orientation === 'w' ? 'b' : 'w') ? 'चाल' : 'प्रतीक्षा'}</span>
      </div>
      <div className={`board-layout${showCoordinates ? '' : ' board-layout-no-coordinates'}`}>
        {showCoordinates && <div className="rank-labels" aria-hidden="true">
          {ranks.map((rank) => <span key={rank}>{rank}</span>)}
        </div>}
        <div className="chessboard" role="grid" aria-label={`शतरंज बोर्ड। ${position.turn === 'w' ? 'सफ़ेद' : 'काले'} की चाल${position.inCheck ? ', शह में' : ''}। तीर कुंजियों से चौखानों के बीच जाएँ; Enter या Space से चौखाना चुनें।`}>
          {ranks.map((rank, rowIndex) => (
            <div className="board-row" role="row" key={rank}>
              {files.map((file, columnIndex) => {
                const square = `${file}${rank}` as Square;
                const piece = pieceAt(position, square);
                const isLight = (FILES.indexOf(file) + rank) % 2 === 1;
                const isSelected = selected === square;
                const isLegalTarget = destinations.has(square);
                const isCaptureTarget = isLegalTarget && legalFromSelected.some((move) => move.to === square && (move.flags.includes('c') || move.flags.includes('e')));
                const isLast = square === lastFrom || square === lastTo;
                const isChecked = square === checkedKing;
                const description = piece
                  ? `${square} पर ${piece.color === 'w' ? 'सफ़ेद' : 'काले'} ${PIECE_NAMES[piece.type]}`
                  : `खाली चौखाना ${square}`;
                return (
                  <button
                    className={`board-square ${isLight ? 'light-square' : 'dark-square'}${isLast ? ' last-move-square' : ''}${isSelected ? ' selected-square' : ''}${isLegalTarget ? ' legal-target-square' : ''}${isCaptureTarget ? ' capture-target-square' : ''}${isChecked ? ' checked-square' : ''}`}
                    type="button"
                    role="gridcell"
                    aria-label={`${description}${isSelected ? ', चुना हुआ' : ''}${isLegalTarget ? ', वैध गंतव्य' : ''}${isChecked ? ', राजा शह में' : ''}`}
                    aria-selected={isSelected}
                    aria-disabled={disabled}
                    tabIndex={focused === square ? 0 : -1}
                    key={square}
                    ref={(element) => { if (element) squareButtons.current.set(square, element); else squareButtons.current.delete(square); }}
                    onFocus={() => setFocused(square)}
                    onClick={() => activateSquare(square)}
                    onKeyDown={(event) => onSquareKeyDown(event, square)}
                  >
                    {piece && <span aria-hidden="true" className={`piece-glyph ${piece.color === 'w' ? 'white-piece' : 'black-piece'}`}>{PIECE_GLYPHS[piece.color][piece.type]}</span>}
                    {isLegalTarget && <span aria-hidden="true" className={`move-indicator${isCaptureTarget ? ' capture-indicator' : ''}`} />}
                    {showCoordinates && columnIndex === 0 && <span className="square-coordinate rank-coordinate" aria-hidden="true">{rank}</span>}
                    {showCoordinates && rowIndex === 7 && <span className="square-coordinate file-coordinate" aria-hidden="true">{file}</span>}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
        {showCoordinates && <div className="rank-labels trailing-ranks" aria-hidden="true">
          {ranks.map((rank) => <span key={rank}>{rank}</span>)}
        </div>}
      </div>
      {showCoordinates && <div className="file-labels" aria-hidden="true">
        <span />
        {files.map((file) => <span key={file}>{file}</span>)}
        <span />
      </div>}
      <div className="board-player-bar board-player-bottom" aria-hidden="true">
        <span className={`player-piece-dot ${orientation === 'w' ? 'light' : 'dark'}`} />
        <span>{orientation === 'w' ? 'White' : 'Black'}</span>
        <span className="board-side-label">{position.turn === orientation ? 'to move' : 'waiting'}</span>
      </div>
      <p className="sr-only" role="status" aria-live="polite">{announcement}</p>

      {promotionMoves && (
        <div className="promotion-scrim" onMouseDown={(event) => { if (event.target === event.currentTarget) closePromotion(); }}>
          <div className="promotion-dialog" role="dialog" aria-modal="true" aria-labelledby="promotion-title" tabIndex={-1} ref={promotionDialog} onKeyDown={onPromotionKeyDown}>
            <p className="eyebrow">पदोन्नति</p>
            <h3 id="promotion-title">गोटी चुनें</h3>
            <p>वज़ीर, हाथी, ऊँट या घोड़ा चुनें।</p>
            <div className="promotion-choices">
              {PROMOTION_ORDER.map((piece) => {
                const move = promotionMoves.find((candidate) => candidate.promotion === piece);
                if (!move) return null;
                return (
                  <button className="promotion-choice" type="button" key={piece} onClick={() => commitMove(move)} aria-label={PROMOTION_ACTIONS[piece]}>
                    <span aria-hidden="true">{PIECE_GLYPHS[position.turn][piece]}</span>
                    <small>{PIECE_NAMES[piece]}</small>
                  </button>
                );
              })}
            </div>
            <button className="button-quiet" type="button" onClick={closePromotion}>रद्द करें</button>
          </div>
        </div>
      )}
    </div>
  );
}
