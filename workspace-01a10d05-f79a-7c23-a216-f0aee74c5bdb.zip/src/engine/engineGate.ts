import type { UciEngineAdapter, UciTransport } from './UciEngineAdapter';

export const STOCKFISH_LICENSING_GATE = {
  engine: 'Stockfish 19',
  license: 'GPL-3.0-or-later',
  approvalStatus: 'pending-written-approval',
  bundled: false,
  workerImplemented: false,
  runtimeReady: false,
  adapterImplemented: true,
  featureEnabled: false,
} as const;

/** True only after approval, real-engine bundling, Worker implementation/readiness, and explicit enablement. */
export function isStockfishRuntimeAvailable(): boolean {
  const approvalStatus: string = STOCKFISH_LICENSING_GATE.approvalStatus;
  return approvalStatus === 'approved'
    && STOCKFISH_LICENSING_GATE.bundled
    && STOCKFISH_LICENSING_GATE.workerImplemented
    && STOCKFISH_LICENSING_GATE.runtimeReady
    && STOCKFISH_LICENSING_GATE.featureEnabled;
}

export class EngineUnavailableError extends Error {
  constructor(message = 'Stockfish is not bundled: written GPLv3 approval is still required.') {
    super(message);
    this.name = 'EngineUnavailableError';
  }
}

/** The factory is intentionally gated; no hidden engine fallback is permitted. */
export async function createLicensedEngineAdapter(
  _transportFactory?: () => UciTransport | Promise<UciTransport>,
): Promise<UciEngineAdapter> {
  throw new EngineUnavailableError();
}
