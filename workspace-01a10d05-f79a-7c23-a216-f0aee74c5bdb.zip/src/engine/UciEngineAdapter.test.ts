import { describe, expect, it } from 'vitest';
import { Chess } from 'chess.js';
import { EngineProtocolError, UciEngineAdapter, validatePrincipalVariation, type UciTransport } from './UciEngineAdapter';
import { createLicensedEngineAdapter, EngineUnavailableError, STOCKFISH_LICENSING_GATE } from './engineGate';

class FakeUciTransport implements UciTransport {
  readonly commands: string[] = [];
  readonly listeners = new Set<(event: MessageEvent<string>) => void>();
  onGo?: () => void;
  infoLines = ['info depth 8 multipv 1 score cp 33 nodes 1234 time 20 pv e2e4 e7e5'];
  bestMove = 'e2e4';

  postMessage(message: string) {
    this.commands.push(message);
    if (message === 'uci') {
      this.emit('id name Test UCI Engine 1.0');
      this.emit('uciok');
    } else if (message === 'isready') {
      this.emit('readyok');
    } else if (message.startsWith('go ')) {
      this.onGo?.();
      if (!this.commands.includes('stop')) {
        for (const line of this.infoLines) this.emit(line);
        this.emit(`bestmove ${this.bestMove}`);
      }
    } else if (message === 'stop') {
      this.emit(`bestmove ${this.bestMove}`);
    }
  }

  addEventListener(_type: 'message', listener: (event: MessageEvent<string>) => void) {
    this.listeners.add(listener);
  }

  removeEventListener(_type: 'message', listener: (event: MessageEvent<string>) => void) {
    this.listeners.delete(listener);
  }

  emit(data: string) {
    const event = { data } as MessageEvent<string>;
    for (const listener of this.listeners) listener(event);
  }
}

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

describe('UCI engine adapter boundary', () => {
  it('handshakes, returns metadata, and validates every displayed PV move', async () => {
    const transport = new FakeUciTransport();
    const adapter = new UciEngineAdapter(transport);
    const result = await adapter.analyze(START_FEN, { depth: 8, multiPv: 1 });
    expect(adapter.status).toBe('ready');
    expect(result).toMatchObject({ status: 'completed', engineVersion: 'Test UCI Engine 1.0', bestMoveUci: 'e2e4' });
    expect(result.lines[0]).toMatchObject({ depth: 8, score: { type: 'cp', value: 33, perspective: 'side-to-move' } });
    expect(result.lines[0].pv.sanMoves).toEqual(['e4', 'e5']);
    expect(transport.commands).toContain('uci');
    expect(transport.commands).toContain('position fen ' + START_FEN);
    adapter.dispose();
  });

  it('rejects illegal PV and illegal bestmove responses rather than exposing them', async () => {
    const invalidPv = new FakeUciTransport();
    invalidPv.infoLines = ['info depth 4 score cp 0 pv e2e5'];
    const adapter = new UciEngineAdapter(invalidPv);
    await expect(adapter.analyze(START_FEN, { depth: 4 })).rejects.toBeInstanceOf(EngineProtocolError);
    adapter.dispose();

    const invalidBest = new FakeUciTransport();
    invalidBest.infoLines = [];
    invalidBest.bestMove = 'e2e5';
    const second = new UciEngineAdapter(invalidBest);
    await expect(second.analyze(START_FEN, { depth: 4 })).rejects.toThrow(/illegal bestmove/i);
    second.dispose();
  });

  it('supports MultiPV and rejects conflicting or unsafe search limits', async () => {
    const transport = new FakeUciTransport();
    transport.infoLines = [
      'info depth 10 multipv 1 score cp 20 pv e2e4 e7e5',
      'info depth 10 multipv 2 score cp 10 pv d2d4 d7d5',
    ];
    const adapter = new UciEngineAdapter(transport);
    const result = await adapter.analyze(START_FEN, { depth: 10, multiPv: 2 });
    expect(result.lines.map((line) => line.multiPv)).toEqual([1, 2]);
    await expect(adapter.analyze(START_FEN, { depth: 10, nodes: 100 })).rejects.toThrow(/exactly one/i);
    await expect(adapter.analyze(START_FEN, { depth: 10, multiPv: 9 })).rejects.toThrow(/MultiPV/i);
    adapter.dispose();
  });

  it('rejects malformed info metadata and unexpected MultiPV output', async () => {
    const malformed = new FakeUciTransport();
    malformed.infoLines = ['info depth nope score cp 1 pv e2e4'];
    const malformedAdapter = new UciEngineAdapter(malformed);
    await expect(malformedAdapter.analyze(START_FEN, { depth: 4 })).rejects.toBeInstanceOf(EngineProtocolError);
    malformedAdapter.dispose();

    const unexpected = new FakeUciTransport();
    unexpected.infoLines = ['info depth 4 multipv 2 score cp 1 pv d2d4'];
    const unexpectedAdapter = new UciEngineAdapter(unexpected);
    await expect(unexpectedAdapter.analyze(START_FEN, { depth: 4, multiPv: 1 })).rejects.toThrow(/unexpected MultiPV/i);
    unexpectedAdapter.dispose();
  });

  it('disposes a timed-out transport so late UCI output cannot be attached to another request', async () => {
    const transport = new FakeUciTransport();
    transport.onGo = () => { transport.commands.push('stop'); };
    const adapter = new UciEngineAdapter(transport);
    await expect(adapter.analyze(START_FEN, { depth: 4, timeoutMs: 10 })).rejects.toThrow(/timed out/i);
    expect(adapter.status).toBe('disposed');
    await expect(adapter.analyze(START_FEN, { depth: 4 })).rejects.toThrow(/disposed/i);
    adapter.dispose();
  });

  it('returns a cancelled result when an AbortSignal stops the active search', async () => {
    const transport = new FakeUciTransport();
    const controller = new AbortController();
    transport.onGo = () => controller.abort();
    const adapter = new UciEngineAdapter(transport);
    const result = await adapter.analyze(START_FEN, { depth: 12, signal: controller.signal });
    expect(result.status).toBe('cancelled');
    expect(transport.commands).toContain('stop');
    adapter.dispose();
  });

  it('validates supplied PVs directly and keeps the GPL gate explicit', async () => {
    expect(validatePrincipalVariation(START_FEN, ['e2e4']).sanMoves).toEqual(['e4']);
    expect(() => validatePrincipalVariation(START_FEN, ['e2e5'])).toThrow(/illegal PV/i);
    expect(STOCKFISH_LICENSING_GATE).toMatchObject({ bundled: false, featureEnabled: false, approvalStatus: 'pending-written-approval' });
    let transportFactoryCalled = false;
    await expect(createLicensedEngineAdapter(() => {
      transportFactoryCalled = true;
      return new FakeUciTransport();
    })).rejects.toBeInstanceOf(EngineUnavailableError);
    expect(transportFactoryCalled).toBe(false);
    expect(new Chess(START_FEN).moves()).toHaveLength(20);
  });
});
