import { Chess } from 'chess.js';
import { fenSnapshot, parseUci, positionKey, uciForMove } from '../domain/chess/position';


export interface UciTransport {
  postMessage(message: string): void;
  addEventListener(type: 'message', listener: (event: MessageEvent<string>) => void): void;
  removeEventListener(type: 'message', listener: (event: MessageEvent<string>) => void): void;
  terminate?(): void;
}

export type EngineSearchOptions = {
  depth?: number;
  nodes?: number;
  movetimeMs?: number;
  multiPv?: number;
  timeoutMs?: number;
  signal?: AbortSignal;
};

export type EngineScore = {
  type: 'cp' | 'mate';
  value: number;
  perspective: 'side-to-move';
};

export type ValidatedPv = {
  uciMoves: string[];
  sanMoves: string[];
  finalFen: string;
};

export type EnginePv = {
  multiPv: number;
  depth?: number;
  nodes?: number;
  timeMs?: number;
  score?: EngineScore;
  pv: ValidatedPv;
};

export type EngineAnalysis = {
  status: 'completed' | 'cancelled';
  requestId: string;
  positionHash: string;
  engineVersion: string;
  search: { depth?: number; nodes?: number; movetimeMs?: number; multiPv: number };
  bestMoveUci?: string;
  lines: EnginePv[];
};

type ParsedInfo = {
  multiPv: number;
  depth?: number;
  nodes?: number;
  timeMs?: number;
  score?: EngineScore;
  uciMoves: string[];
};

type Waiter = {
  predicate: (line: string) => boolean;
  resolve: (line: string) => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
};

type ActiveSearch = {
  infoLines: string[];
  resolve: (bestMoveLine: string) => void;
  reject: (error: Error) => void;
  cancelled: boolean;
};

export class EngineProtocolError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'EngineProtocolError';
  }
}

function validPositiveInteger(value: number, name: string, max = Number.MAX_SAFE_INTEGER): number {
  if (!Number.isInteger(value) || value <= 0 || value > max) throw new RangeError(`${name} must be a positive integer no greater than ${max}.`);
  return value;
}

function parseInfoInteger(token: string | undefined, name: string, minimum = 0): number {
  const value = Number(token);
  if (!Number.isSafeInteger(value) || value < minimum) throw new EngineProtocolError(`Engine returned invalid ${name} metadata.`);
  return value;
}

function parseInfo(line: string): ParsedInfo | undefined {
  if (line.length > 16_384) throw new EngineProtocolError('Engine info line exceeds the protocol size limit.');
  const tokens = line.trim().split(/\s+/);
  if (tokens[0] !== 'info') return undefined;
  const parsed: ParsedInfo = { multiPv: 1, uciMoves: [] };
  for (let index = 1; index < tokens.length; index++) {
    const token = tokens[index];
    if (token === 'depth') parsed.depth = parseInfoInteger(tokens[++index], 'depth', 1);
    else if (token === 'nodes') parsed.nodes = parseInfoInteger(tokens[++index], 'node count');
    else if (token === 'time') parsed.timeMs = parseInfoInteger(tokens[++index], 'elapsed time');
    else if (token === 'multipv') parsed.multiPv = parseInfoInteger(tokens[++index], 'MultiPV index', 1);
    else if (token === 'score') {
      const type = tokens[++index];
      const rawValue = tokens[++index];
      const value = Number(rawValue);
      if (type !== 'cp' && type !== 'mate') throw new EngineProtocolError('Engine returned an unsupported score type.');
      if (!Number.isSafeInteger(value)) throw new EngineProtocolError('Engine returned invalid score metadata.');
      parsed.score = { type, value, perspective: 'side-to-move' };
    } else if (token === 'pv') {
      const moves = tokens.slice(index + 1);
      if (moves.length > 1_000 || !moves.every((item) => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(item))) {
        throw new EngineProtocolError('Engine returned malformed or overlong UCI PV notation.');
      }
      parsed.uciMoves = moves;
      break;
    }
  }
  return parsed;
}

export function validatePrincipalVariation(fen: string, uciMoves: string[]): ValidatedPv {
  const chess = new Chess(fen);
  const sanMoves: string[] = [];
  const legalUci: string[] = [];
  for (const rawMove of uciMoves) {
    const intent = parseUci(rawMove);
    try {
      const move = chess.move({ from: intent.from, to: intent.to, ...(intent.promotion ? { promotion: intent.promotion } : {}) });
      legalUci.push(uciForMove(move));
      sanMoves.push(move.san);
    } catch (error) {
      throw new EngineProtocolError(`Engine returned an illegal PV move: ${rawMove}`, { cause: error });
    }
  }
  return { uciMoves: legalUci, sanMoves, finalFen: fenSnapshot(chess) };
}

export class UciEngineAdapter {
  private readonly transport: UciTransport;
  private readonly waiters: Waiter[] = [];
  private readonly bufferedLines: string[] = [];
  private readonly listener: (event: MessageEvent<string>) => void;
  private initialization?: Promise<void>;
  private active?: ActiveSearch;
  private disposed = false;
  private version = 'Unknown UCI engine';
  private state: 'new' | 'initializing' | 'ready' | 'failed' | 'disposed' = 'new';

  constructor(transport: UciTransport) {
    this.transport = transport;
    this.listener = (event) => {
      if (typeof event.data === 'string') this.handleLine(event.data.trim());
    };
    transport.addEventListener('message', this.listener);
  }

  get status(): 'new' | 'initializing' | 'ready' | 'failed' | 'disposed' {
    return this.state;
  }

  get engineVersion(): string {
    return this.version;
  }

  private handleLine(line: string): void {
    if (!line) return;
    if (line.startsWith('id name ')) this.version = line.slice('id name '.length).trim() || this.version;
    if (line.startsWith('info ')) {
      if (this.active) this.active.infoLines.push(line);
      return; // Late UCI info is never assigned to a future request.
    }
    if (line.startsWith('bestmove ')) {
      if (this.active) this.active.resolve(line);
      return; // A bestmove without an active search is stale protocol output.
    }
    const waiterIndex = this.waiters.findIndex((waiter) => waiter.predicate(line));
    if (waiterIndex >= 0) {
      const [waiter] = this.waiters.splice(waiterIndex, 1);
      clearTimeout(waiter.timer);
      waiter.resolve(line);
    } else {
      this.bufferedLines.push(line);
      if (this.bufferedLines.length > 100) this.bufferedLines.shift();
    }
  }

  private waitFor(predicate: (line: string) => boolean, timeoutMs: number): Promise<string> {
    const bufferedIndex = this.bufferedLines.findIndex(predicate);
    if (bufferedIndex >= 0) return Promise.resolve(this.bufferedLines.splice(bufferedIndex, 1)[0]);
    return new Promise((resolve, reject) => {
      const waiter: Waiter = {
        predicate,
        resolve,
        reject,
        timer: setTimeout(() => {
          const index = this.waiters.indexOf(waiter);
          if (index >= 0) this.waiters.splice(index, 1);
          reject(new EngineProtocolError('Timed out waiting for the UCI engine.'));
        }, timeoutMs),
      };
      this.waiters.push(waiter);
    });
  }

  async initialize(timeoutMs = 10_000): Promise<void> {
    validPositiveInteger(timeoutMs, 'Initialization timeout', 120_000);
    if (this.disposed) throw new EngineProtocolError('Engine adapter is disposed.');
    if (this.state === 'failed') throw new EngineProtocolError('Engine initialization failed; create a new adapter and transport.');
    if (this.state === 'ready') return;
    if (this.initialization) return this.initialization;
    this.state = 'initializing';
    this.initialization = (async () => {
      try {
        const uciReady = this.waitFor((line) => line === 'uciok', timeoutMs);
        this.transport.postMessage('uci');
        await uciReady;
        const ready = this.waitFor((line) => line === 'readyok', timeoutMs);
        this.transport.postMessage('isready');
        await ready;
        this.state = 'ready';
      } catch (error) {
        this.state = 'failed';
        throw error;
      }
    })().finally(() => {
      this.initialization = undefined;
    });
    return this.initialization;
  }

  async analyze(fen: string, options: EngineSearchOptions = {}): Promise<EngineAnalysis> {
    await this.initialize();
    if (this.disposed) throw new EngineProtocolError('Engine adapter is disposed.');
    if (this.active) throw new EngineProtocolError('An analysis request is already running.');
    if (options.signal?.aborted) throw new DOMException('Analysis was cancelled.', 'AbortError');
    const bounds = [options.depth, options.nodes, options.movetimeMs].filter((value) => value !== undefined);
    if (bounds.length > 1) throw new RangeError('Choose exactly one engine search limit.');
    const depth = options.depth === undefined ? (options.nodes === undefined && options.movetimeMs === undefined ? 12 : undefined) : validPositiveInteger(options.depth, 'Depth', 64);
    const nodes = options.nodes === undefined ? undefined : validPositiveInteger(options.nodes, 'Nodes', 1_000_000_000);
    const movetimeMs = options.movetimeMs === undefined ? undefined : validPositiveInteger(options.movetimeMs, 'Move time', 120_000);
    const multiPv = validPositiveInteger(options.multiPv ?? 1, 'MultiPV', 8);
    const timeoutMs = validPositiveInteger(options.timeoutMs ?? (movetimeMs ? movetimeMs + 15_000 : 120_000), 'Timeout', 180_000);
    const chess = new Chess(fen);
    const normalizedFen = fenSnapshot(chess);
    const positionHash = positionKey(chess);
    const requestId = crypto.randomUUID();

    this.transport.postMessage(`setoption name MultiPV value ${multiPv}`);
    const ready = this.waitFor((line) => line === 'readyok', 10_000);
    this.transport.postMessage('isready');
    try {
      await ready;
    } catch (error) {
      this.dispose(); // A late readyok cannot satisfy a later request on this transport.
      throw error;
    }
    this.bufferedLines.length = 0;
    this.transport.postMessage('ucinewgame');
    this.transport.postMessage(`position fen ${normalizedFen}`);
    const goCommand = nodes ? `go nodes ${nodes}` : movetimeMs ? `go movetime ${movetimeMs}` : `go depth ${depth ?? 12}`;

    if (options.signal?.aborted) throw new DOMException('Analysis was cancelled.', 'AbortError');
    let abortHandler: (() => void) | undefined;
    let activeSearch: ActiveSearch | undefined;
    let searchTimeout: ReturnType<typeof setTimeout> | undefined;
    let bestMoveLine: string;
    try {
      bestMoveLine = await new Promise<string>((resolve, reject) => {
        const active: ActiveSearch = { infoLines: [], resolve, reject, cancelled: false };
        this.active = active;
        activeSearch = active;
        const originalResolve = active.resolve;
        active.resolve = (line) => { if (searchTimeout) clearTimeout(searchTimeout); originalResolve(line); };
        const originalReject = active.reject;
        active.reject = (error) => { if (searchTimeout) clearTimeout(searchTimeout); originalReject(error); };
        if (options.signal) {
          abortHandler = () => {
            active.cancelled = true;
            this.transport.postMessage('stop');
          };
          options.signal.addEventListener('abort', abortHandler, { once: true });
        }
        searchTimeout = setTimeout(() => {
          if (this.active === active) {
            active.reject(new EngineProtocolError('Engine search timed out.'));
            try { this.transport.postMessage('stop'); } catch { /* transport is already unusable */ }
            this.dispose(); // UCI has no request IDs; do not reuse a transport after a timed-out search.
          }
        }, timeoutMs);
        this.transport.postMessage(goCommand);
      });
    } catch (error) {
      this.active = undefined;
      throw error;
    } finally {
      if (searchTimeout) clearTimeout(searchTimeout);
      if (options.signal && abortHandler) options.signal.removeEventListener('abort', abortHandler);
    }

    const active = activeSearch;
    this.active = undefined;
    if (!active) throw new EngineProtocolError('Engine search state was lost.');
    if (active.cancelled) {
      return {
        status: 'cancelled', requestId, positionHash, engineVersion: this.version,
        search: { depth, nodes, movetimeMs, multiPv }, lines: [],
      };
    }
    const bestMatch = /^bestmove\s+([^\s]+)(?:\s+ponder\s+([^\s]+))?\s*$/.exec(bestMoveLine);
    if (!bestMatch) throw new EngineProtocolError('Engine returned malformed bestmove notation.');
    const rawBest = bestMatch[1];
    let bestMoveUci: string | undefined;
    if (rawBest !== '(none)' && rawBest !== '0000') {
      try {
        const intent = parseUci(rawBest);
        const clone = new Chess(normalizedFen);
        const move = clone.move({ from: intent.from, to: intent.to, ...(intent.promotion ? { promotion: intent.promotion } : {}) });
        bestMoveUci = uciForMove(move);
      } catch (error) {
        throw new EngineProtocolError(`Engine returned an illegal bestmove: ${rawBest}`, { cause: error });
      }
    } else if (chess.moves().length > 0) {
      throw new EngineProtocolError('Engine returned no best move in a position with legal moves.');
    }

    const latest = new Map<number, ParsedInfo>();
    for (const line of active.infoLines) {
      const info = parseInfo(line);
      if (!info) continue;
      if (info.multiPv > multiPv) throw new EngineProtocolError(`Engine returned unexpected MultiPV index ${info.multiPv}.`);
      if (!info.uciMoves.length) continue;
      const existing = latest.get(info.multiPv);
      if (!existing || (info.depth ?? 0) >= (existing.depth ?? 0)) latest.set(info.multiPv, info);
    }
    const lines = [...latest.values()].sort((a, b) => a.multiPv - b.multiPv).map((info) => ({
      multiPv: info.multiPv,
      ...(info.depth === undefined ? {} : { depth: info.depth }),
      ...(info.nodes === undefined ? {} : { nodes: info.nodes }),
      ...(info.timeMs === undefined ? {} : { timeMs: info.timeMs }),
      ...(info.score ? { score: info.score } : {}),
      pv: validatePrincipalVariation(normalizedFen, info.uciMoves),
    }));

    return {
      status: 'completed',
      requestId,
      positionHash,
      engineVersion: this.version,
      search: { depth, nodes, movetimeMs, multiPv },
      ...(bestMoveUci ? { bestMoveUci } : {}),
      lines,
    };
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.state = 'disposed';
    this.active?.reject(new EngineProtocolError('Engine adapter was disposed.'));
    this.active = undefined;
    for (const waiter of this.waiters) {
      clearTimeout(waiter.timer);
      waiter.reject(new EngineProtocolError('Engine adapter was disposed.'));
    }
    this.waiters.length = 0;
    this.transport.removeEventListener('message', this.listener);
    this.transport.terminate?.();
  }
}

