import { Chess } from 'chess.js';
import { FIDE_LAWS_SOURCE, RULESET_ID, type GameMode, type GameRecord } from '../domain/chess/types';
import { enPassantTargetAfterMove, fenAtPly, fenSnapshot, positionKey, uciForMove } from '../domain/chess/position';

const DATABASE_NAME = 'chess-game-master-local';
const DATABASE_VERSION = 2;
const GAME_SCHEMA_VERSION = 2;
const GAME_MODES = new Set<GameMode>(['Practice', 'Challenge', 'CoachedPractice', 'Learn', 'Puzzle', 'OpeningTraining', 'Review']);
const TERMINATION_REASONS = new Set([
  'checkmate', 'stalemate', 'dead-position', 'fivefold-repetition', 'seventy-five-move-rule',
  'threefold-claim', 'fifty-move-claim', 'resignation', 'draw-agreement', 'timeout',
  'timeout-pending-adjudication', 'imported-result', 'aborted',
]);
const MOVE_SOURCES = new Set(['human', 'engine', 'import', 'lesson', 'puzzle']);
const EVENT_TYPES = new Set(['takeback', 'draw-claim', 'draw-agreement', 'resignation', 'abort', 'timeout-pending']);

export type ProgressRecord = {
  id: string;
  type: 'lesson' | 'puzzle' | 'opening' | 'practice';
  updatedAt: string;
  payload: Record<string, unknown>;
};

export type AnalysisRecord = {
  id: string;
  gameId: string;
  updatedAt: string;
  payload: Record<string, unknown>;
};

export type RecoveryRecord = {
  id: string;
  source: 'games' | 'progress' | 'analysis';
  originalKey: string;
  quarantinedAt: string;
  reason: string;
  value: unknown;
};

export type LocalDataBackup = {
  format: 'chess-game-master-local-backup';
  schemaVersion: 1;
  exportedAt: string;
  games: GameRecord[];
  progress: ProgressRecord[];
  analysis: AnalysisRecord[];
  recovery: RecoveryRecord[];
};

export type BackupRestoreSummary = {
  added: { games: number; progress: number; analysis: number; recovery: number };
  skipped: { games: number; progress: number; analysis: number; recovery: number };
};

const BACKUP_FORMAT = 'chess-game-master-local-backup' as const;
const BACKUP_SCHEMA_VERSION = 1 as const;
const MAX_BACKUP_BYTES = 25_000_000;
const MAX_BACKUP_RECORDS = 10_000;

function utf8ByteLength(value: string): number {
  return new TextEncoder().encode(value).byteLength;
}

export class LocalStoreError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'LocalStoreError';
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isIsoTimestamp(value: unknown): value is string {
  return typeof value === 'string' && value.length <= 64 && Number.isFinite(Date.parse(value));
}

function isBoundedString(value: unknown, maximum = 10_000, allowEmpty = true): value is string {
  return typeof value === 'string' && value.length <= maximum && (allowEmpty || value.trim().length > 0);
}

function assertPlayer(value: unknown, label: string): asserts value is GameRecord['players']['white'] {
  if (!isObject(value) || !['human', 'engine', 'imported', 'unknown'].includes(String(value.kind))
    || !isBoundedString(value.id, 160, false)
    || (value.displayName !== undefined && !isBoundedString(value.displayName, 200))
    || (value.engineVersion !== undefined && !isBoundedString(value.engineVersion, 120))) {
    throw new LocalStoreError(`${label} player descriptor is malformed.`);
  }
}

function assertDrawState(value: unknown): asserts value is GameRecord['drawState'] {
  if (!isObject(value)
    || !Number.isInteger(value.repetitionCount) || Number(value.repetitionCount) < 1
    || typeof value.canClaimThreefoldNow !== 'boolean'
    || typeof value.canClaimFiftyMovesNow !== 'boolean'
    || typeof value.automaticFivefold !== 'boolean'
    || typeof value.automaticSeventyFiveMoves !== 'boolean'
    || typeof value.deadPositionDetected !== 'boolean'
    || !Array.isArray(value.intendedClaims)) {
    throw new LocalStoreError('Saved draw state is malformed.');
  }
  for (const claim of value.intendedClaims) {
    if (!isObject(claim)
      || !['threefold-repetition', 'fifty-move-rule'].includes(String(claim.reason))
      || !['current-position', 'intended-move'].includes(String(claim.kind))
      || (claim.intendedUci !== undefined && !/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(String(claim.intendedUci)))
      || (claim.intendedSan !== undefined && !isBoundedString(claim.intendedSan, 32, false))
      || (claim.kind === 'intended-move' && typeof claim.intendedUci !== 'string')
      || (claim.kind === 'current-position' && (claim.intendedUci !== undefined || claim.intendedSan !== undefined))) {
      throw new LocalStoreError('Saved draw claim is malformed.');
    }
  }
}

function assertPersistedClock(value: unknown): void {
  if (!isObject(value)
    || value.type !== 'fischer'
    || !Number.isSafeInteger(value.baseMs) || Number(value.baseMs) <= 0
    || !Number.isSafeInteger(value.incrementMs) || Number(value.incrementMs) < 0
    || !Number.isSafeInteger(value.whiteRemainingMs) || Number(value.whiteRemainingMs) < 0
    || !Number.isSafeInteger(value.blackRemainingMs) || Number(value.blackRemainingMs) < 0
    || (value.activeSide !== undefined && value.activeSide !== 'w' && value.activeSide !== 'b')
    || value.paused !== true
    || !Number.isSafeInteger(value.revision) || Number(value.revision) < 0
    || Object.hasOwn(value, 'monotonicAnchorMs')) {
    throw new LocalStoreError('Saved clock snapshot is malformed or not safely paused.');
  }
}

export function assertGameRecord(value: GameRecord): void {
  if (!isObject(value)) throw new LocalStoreError('Invalid game record.');
  const record = value as unknown as GameRecord;
  if (record.schemaVersion !== GAME_SCHEMA_VERSION || !isBoundedString(record.id, 160, false)) throw new LocalStoreError('Unsupported or incomplete game record.');
  if (!isIsoTimestamp(record.createdAt) || !isIsoTimestamp(record.updatedAt)) throw new LocalStoreError('Game timestamps are malformed.');
  if (!GAME_MODES.has(record.mode)) throw new LocalStoreError('Unsupported game mode.');
  if (!isObject(record.ruleset)
    || record.ruleset.id !== RULESET_ID
    || record.ruleset.variant !== 'standard'
    || record.ruleset.policyVersion !== 'FIDE-2023'
    || record.ruleset.sourceUrl !== FIDE_LAWS_SOURCE
    || !isIsoTimestamp(record.ruleset.verifiedAt)
    || record.ruleset.drawPolicy !== 'threefold-and-fifty-move-claims; fivefold-and-seventy-five-move-automatic') {
    throw new LocalStoreError('Saved ruleset metadata is unsupported or malformed.');
  }
  if (!isObject(record.initialPosition)
    || !isBoundedString(record.initialPosition.fen, 256, false)
    || !['standard', 'custom', 'imported'].includes(record.initialPosition.kind)) {
    throw new LocalStoreError('Saved initial position is malformed.');
  }
  if (!Array.isArray(record.moveHistory) || record.moveHistory.length > 10_000 || !Array.isArray(record.repetitionKeys)) throw new LocalStoreError('Game history is malformed or exceeds the local safety limit.');
  if (!Number.isInteger(record.cursorPly) || record.cursorPly < 0 || record.cursorPly > record.moveHistory.length) throw new LocalStoreError('Game cursor is outside move history.');
  if (record.repetitionKeys.length !== record.moveHistory.length + 1 || !record.repetitionKeys.every((key) => isBoundedString(key, 160, false))) {
    throw new LocalStoreError('Repetition history does not match legal move history.');
  }
  if (!['active', 'finished', 'reviewing', 'aborted', 'adjudication-pending'].includes(record.status)) throw new LocalStoreError('Saved game status is malformed.');
  if (!isObject(record.players)) throw new LocalStoreError('Saved player descriptors are malformed.');
  assertPlayer(record.players.white, 'White');
  assertPlayer(record.players.black, 'Black');
  assertDrawState(record.drawState);
  if (!Array.isArray(record.events) || record.events.length > 10_000 || !Array.isArray(record.variations)) throw new LocalStoreError('Saved events or variations are malformed or exceed the local safety limit.');
  for (const event of record.events) {
    if (!isObject(event) || !EVENT_TYPES.has(String(event.type)) || !isIsoTimestamp(event.at)
      || (event.actor !== undefined && !['w', 'b', 'system'].includes(String(event.actor)))
      || (event.detail !== undefined && !isBoundedString(event.detail, 2000))) {
      throw new LocalStoreError('Saved game event is malformed.');
    }
  }
  if (record.variations.length > 1_000) throw new LocalStoreError('Saved game has too many variations.');
  let variationMoveTotal = 0;
  for (const variation of record.variations) {
    if (!isObject(variation) || !isBoundedString(variation.id, 160, false)
      || !Number.isInteger(variation.fromPly) || Number(variation.fromPly) < 0 || Number(variation.fromPly) > record.moveHistory.length
      || !Array.isArray(variation.uciMoves) || variation.uciMoves.length > 2_000
      || !variation.uciMoves.every((uci) => typeof uci === 'string' && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci))
      || !isIsoTimestamp(variation.createdAt) || !isBoundedString(variation.label, 200, false)) {
      throw new LocalStoreError('Saved game variation is malformed.');
    }
    variationMoveTotal += variation.uciMoves.length;
    if (variationMoveTotal > 20_000) throw new LocalStoreError('Saved game variations exceed the local safety limit.');
    try {
      const line = new Chess(record.initialPosition.fen);
      for (const move of record.moveHistory.slice(0, variation.fromPly)) line.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
      for (const uci of variation.uciMoves) line.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
    } catch (error) {
      throw new LocalStoreError('Saved variation contains an illegal move.', { cause: error });
    }
  }
  if (record.result !== undefined) {
    if (!isObject(record.result) || !['1-0', '0-1', '1/2-1/2'].includes(String(record.result.score))
      || !TERMINATION_REASONS.has(String(record.result.reason))
      || (record.result.actor !== undefined && !['w', 'b', 'system'].includes(String(record.result.actor)))
      || (record.result.detail !== undefined && !isBoundedString(record.result.detail, 2000))) {
      throw new LocalStoreError('Saved game result is malformed.');
    }
  }
  if (record.status === 'finished' && record.result === undefined) throw new LocalStoreError('A finished game must include its result.');
  if (record.pgnHeaders !== undefined) {
    if (!isObject(record.pgnHeaders) || Object.entries(record.pgnHeaders).length > 100
      || Object.entries(record.pgnHeaders).some(([key, text]) => !/^[A-Za-z][A-Za-z0-9_]{0,31}$/.test(key) || !isBoundedString(text, 1000))) {
      throw new LocalStoreError('Saved PGN headers are malformed.');
    }
  }
  if (record.notes !== undefined && !isBoundedString(record.notes, 10_000)) throw new LocalStoreError('Saved game notes are malformed.');
  if (record.clock !== undefined) {
    assertPersistedClock(record.clock);
    if (record.cursorPly !== record.moveHistory.length) throw new LocalStoreError('A clocked game cannot be stored at an earlier navigation ply.');
  }
  if (record.status === 'adjudication-pending'
    && (record.result !== undefined || record.events.at(-1)?.type !== 'timeout-pending')) {
    throw new LocalStoreError('Pending timeout adjudication is missing its unresolved timeout event.');
  }

  try {
    const chess = new Chess(record.initialPosition.fen);
    let currentFen = fenSnapshot(chess, record.initialPosition.fen.split(' ')[3] ?? '-');
    let currentKey = positionKey(chess);
    const keys = [currentKey];
    if (record.repetitionKeys[0] !== currentKey) throw new LocalStoreError('Initial repetition key does not match the saved initial position.');
    for (const [index, entry] of record.moveHistory.entries()) {
      if (!isObject(entry)
        || entry.ply !== index + 1
        || !MOVE_SOURCES.has(String(entry.source))
        || !isBoundedString(entry.san, 32, false)
        || !isIsoTimestamp(entry.committedAt)
        || !/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(entry.uci)
        || !isBoundedString(entry.beforeFen, 256, false)
        || !isBoundedString(entry.afterFen, 256, false)
        || !isBoundedString(entry.beforeKey, 160, false)
        || !isBoundedString(entry.afterKey, 160, false)
        || !/^[a-h][1-8]$/.test(entry.from)
        || !/^[a-h][1-8]$/.test(entry.to)
        || (entry.promotion !== undefined && !['q', 'r', 'b', 'n'].includes(entry.promotion))) {
        throw new LocalStoreError(`Move record is malformed at ply ${index + 1}.`);
      }
      if (entry.beforeFen !== currentFen || entry.beforeKey !== currentKey) throw new LocalStoreError(`Move history is inconsistent at ply ${index + 1}.`);
      const move = chess.move({ from: entry.from, to: entry.to, ...(entry.promotion ? { promotion: entry.promotion } : {}) });
      const expectedUci = uciForMove(move);
      if (move.san !== entry.san || expectedUci !== entry.uci) throw new LocalStoreError(`Stored notation is inconsistent at ply ${index + 1}.`);
      currentKey = positionKey(chess);
      currentFen = fenSnapshot(chess, enPassantTargetAfterMove(move.piece, move.from, move.to));
      if (entry.afterFen !== currentFen || entry.afterKey !== currentKey) throw new LocalStoreError(`Move result is inconsistent at ply ${index + 1}.`);
      keys.push(currentKey);
    }
    if (keys.some((key, index) => record.repetitionKeys[index] !== key)) throw new LocalStoreError('Saved repetition keys do not match legal move history.');
    if (record.currentFen !== fenAtPly(record, record.cursorPly)) throw new LocalStoreError('Saved FEN checkpoint does not match canonical history.');
    if (record.clock && record.clock.activeSide !== chess.turn()) throw new LocalStoreError('Saved clock side does not match the current position.');
  } catch (error) {
    if (error instanceof LocalStoreError) throw error;
    throw new LocalStoreError('Saved game contains invalid FEN or move history.', { cause: error });
  }
}

function assertBoundedJsonPayload(payload: Record<string, unknown>, maximum: number, label: string): void {
  let serialized: string | undefined;
  try {
    serialized = JSON.stringify(payload);
  } catch (error) {
    throw new LocalStoreError(`${label} payload must be JSON-serializable.`, { cause: error });
  }
  if (!serialized || serialized.length > maximum) throw new LocalStoreError(`${label} payload exceeds the local safety limit.`);
}

function assertProgressRecord(value: unknown): asserts value is ProgressRecord {
  if (!isObject(value) || !isBoundedString(value.id, 240, false)
    || !['lesson', 'puzzle', 'opening', 'practice'].includes(String(value.type))
    || !isIsoTimestamp(value.updatedAt) || !isObject(value.payload)) {
    throw new LocalStoreError('Saved learning progress is malformed.');
  }
  assertBoundedJsonPayload(value.payload, 200_000, 'Learning progress');
}

function assertAnalysisRecord(value: unknown): asserts value is AnalysisRecord {
  if (!isObject(value) || !isBoundedString(value.id, 240, false)
    || !isBoundedString(value.gameId, 160, false) || !isIsoTimestamp(value.updatedAt)
    || !isObject(value.payload)) {
    throw new LocalStoreError('Saved analysis record is malformed.');
  }
  assertBoundedJsonPayload(value.payload, 2_000_000, 'Analysis');
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new LocalStoreError('IndexedDB request failed.'));
  });
}

function transactionResult<T>(transaction: IDBTransaction, value: Promise<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    let transactionComplete = false;
    let valueComplete = false;
    let valueResult: T;
    let settled = false;
    const fail = (error: unknown) => {
      if (settled) return;
      settled = true;
      reject(error instanceof Error ? error : new LocalStoreError('IndexedDB operation failed.'));
    };
    const finish = () => {
      if (transactionComplete && valueComplete && !settled) {
        settled = true;
        resolve(valueResult);
      }
    };
    value.then(
      (result) => { valueResult = result; valueComplete = true; finish(); },
      (error: unknown) => fail(error),
    );
    transaction.oncomplete = () => { transactionComplete = true; finish(); };
    transaction.onerror = () => fail(transaction.error ?? new LocalStoreError('IndexedDB transaction failed.'));
    transaction.onabort = () => fail(transaction.error ?? new LocalStoreError('IndexedDB transaction was aborted.'));
  });
}

function migrateGameValue(value: unknown): GameRecord {
  if (!isObject(value)) throw new LocalStoreError('Legacy game record is not an object.');
  if (value.schemaVersion !== 1 && value.schemaVersion !== GAME_SCHEMA_VERSION) throw new LocalStoreError('Legacy game schema version is unsupported.');
  const migrated = { ...value, schemaVersion: GAME_SCHEMA_VERSION } as unknown as GameRecord;
  assertGameRecord(migrated);
  return migrated;
}

function recoveryValue(source: RecoveryRecord['source'], key: IDBValidKey, value: unknown, reason: string): RecoveryRecord {
  return {
    id: `recovery-${crypto.randomUUID()}`,
    source,
    originalKey: String(key),
    quarantinedAt: new Date().toISOString(),
    reason: reason.slice(0, 1000),
    value,
  };
}

function isRecoveryRecord(value: unknown): value is RecoveryRecord {
  return isObject(value)
    && isBoundedString(value.id, 200, false)
    && ['games', 'progress', 'analysis'].includes(String(value.source))
    && isBoundedString(value.originalKey, 500)
    && isIsoTimestamp(value.quarantinedAt)
    && isBoundedString(value.reason, 1000, false)
    && Object.hasOwn(value, 'value');
}

function stringifyJsonSafely(value: unknown): string {
  const seen = new WeakSet<object>();
  const json = JSON.stringify(value, (_key, item: unknown) => {
    if (typeof item === 'bigint') return item.toString();
    if (item && typeof item === 'object') {
      if (seen.has(item)) return '[Circular reference omitted]';
      seen.add(item);
    }
    return item;
  }, 2);
  if (!json) throw new LocalStoreError('Local backup could not be serialized.');
  return json;
}

function parseBackupJson(json: string): LocalDataBackup {
  if (typeof json !== 'string' || utf8ByteLength(json) > MAX_BACKUP_BYTES) throw new LocalStoreError('Backup file exceeds the 25 MB safety limit.');
  let parsed: unknown;
  try { parsed = JSON.parse(json); }
  catch (error) { throw new LocalStoreError('Backup file is not valid JSON.', { cause: error }); }
  if (!isObject(parsed) || parsed.format !== BACKUP_FORMAT || parsed.schemaVersion !== BACKUP_SCHEMA_VERSION
    || !isIsoTimestamp(parsed.exportedAt) || !Array.isArray(parsed.games) || !Array.isArray(parsed.progress)
    || !Array.isArray(parsed.analysis) || !Array.isArray(parsed.recovery)) {
    throw new LocalStoreError('Backup format or version is not supported.');
  }
  const entries: Array<[string, unknown[]]> = [
    ['games', parsed.games], ['progress', parsed.progress], ['analysis', parsed.analysis], ['recovery', parsed.recovery],
  ];
  for (const [label, values] of entries) {
    if (values.length > MAX_BACKUP_RECORDS) throw new LocalStoreError(`Backup contains too many ${label} records.`);
  }
  const assertUniqueIds = (values: unknown[], label: string) => {
    const ids = new Set<string>();
    for (const value of values) {
      if (!isObject(value) || !isBoundedString(value.id, 240, false) || ids.has(value.id)) {
        throw new LocalStoreError(`Backup contains a malformed or duplicate ${label} ID.`);
      }
      ids.add(value.id);
    }
  };
  for (const game of parsed.games) assertGameRecord(game as GameRecord);
  for (const progress of parsed.progress) assertProgressRecord(progress);
  for (const analysis of parsed.analysis) assertAnalysisRecord(analysis);
  for (const recovery of parsed.recovery) {
    if (!isRecoveryRecord(recovery)) throw new LocalStoreError('Backup contains a malformed recovery record.');
  }
  assertUniqueIds(parsed.games, 'game');
  assertUniqueIds(parsed.progress, 'progress');
  assertUniqueIds(parsed.analysis, 'analysis');
  assertUniqueIds(parsed.recovery, 'recovery');
  return parsed as unknown as LocalDataBackup;
}

export class LocalChessStore {
  private databasePromise?: Promise<IDBDatabase>;
  private readonly factory?: IDBFactory;
  private readonly databaseName: string;

  constructor(factory: IDBFactory | null = globalThis.indexedDB ?? null, databaseName = DATABASE_NAME) {
    this.factory = factory ?? undefined;
    this.databaseName = databaseName;
  }

  private open(): Promise<IDBDatabase> {
    if (!this.factory) return Promise.reject(new LocalStoreError('IndexedDB is not available in this browser.'));
    if (this.databasePromise) return this.databasePromise;
    const factory = this.factory;
    this.databasePromise = new Promise<IDBDatabase>((resolve, reject) => {
      const request = factory.open(this.databaseName, DATABASE_VERSION);
      request.onupgradeneeded = (event) => {
        const database = request.result;
        const transaction = request.transaction;
        if (!transaction) throw new LocalStoreError('Database upgrade transaction is missing.');
        if (!database.objectStoreNames.contains('games')) {
          const games = database.createObjectStore('games', { keyPath: 'id' });
          games.createIndex('updatedAt', 'updatedAt');
          games.createIndex('status', 'status');
          games.createIndex('mode', 'mode');
        }
        if (!database.objectStoreNames.contains('progress')) {
          const progress = database.createObjectStore('progress', { keyPath: 'id' });
          progress.createIndex('type', 'type');
          progress.createIndex('updatedAt', 'updatedAt');
        }
        if (!database.objectStoreNames.contains('analysis')) {
          const analysis = database.createObjectStore('analysis', { keyPath: 'id' });
          analysis.createIndex('gameId', 'gameId');
          analysis.createIndex('updatedAt', 'updatedAt');
        }
        if (!database.objectStoreNames.contains('recovery')) {
          const recovery = database.createObjectStore('recovery', { keyPath: 'id' });
          recovery.createIndex('quarantinedAt', 'quarantinedAt');
          recovery.createIndex('source', 'source');
        }

        if (event.oldVersion > 0 && event.oldVersion < DATABASE_VERSION) {
          const games = transaction.objectStore('games');
          const recovery = transaction.objectStore('recovery');
          const cursorRequest = games.openCursor();
          cursorRequest.onerror = () => transaction.abort();
          cursorRequest.onsuccess = () => {
            const cursor = cursorRequest.result;
            if (!cursor) return;
            try {
              const migrated = migrateGameValue(cursor.value);
              cursor.update(migrated);
            } catch (error) {
              try {
                recovery.put(recoveryValue('games', cursor.primaryKey, cursor.value, error instanceof Error ? error.message : 'Legacy game could not be migrated.'));
                cursor.delete();
              } catch {
                transaction.abort();
                return;
              }
            }
            cursor.continue();
          };
        }
      };
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => database.close();
        resolve(database);
      };
      request.onerror = () => reject(new LocalStoreError('Could not open local storage.', { cause: request.error ?? undefined }));
      request.onblocked = () => reject(new LocalStoreError('Local storage upgrade is blocked by another open tab.'));
    }).catch((error: unknown) => {
      this.databasePromise = undefined;
      throw error;
    });
    return this.databasePromise!;
  }

  private async quarantine(source: RecoveryRecord['source'], key: IDBValidKey, value: unknown, reason: string): Promise<void> {
    const database = await this.open();
    const transaction = database.transaction([source, 'recovery'], 'readwrite');
    const recovery = recoveryValue(source, key, structuredClone(value), reason);
    const requestPromise = Promise.all([
      requestResult(transaction.objectStore(source).delete(key)),
      requestResult(transaction.objectStore('recovery').put(recovery)),
    ]).then(() => undefined);
    await transactionResult(transaction, requestPromise);
  }

  async saveGame(record: GameRecord): Promise<void> {
    assertGameRecord(record);
    const database = await this.open();
    const transaction = database.transaction('games', 'readwrite', { durability: 'strict' });
    const request = transaction.objectStore('games').put(structuredClone(record));
    await transactionResult(transaction, requestResult(request).then(() => undefined));
  }

  async getGame(id: string): Promise<GameRecord | undefined> {
    const database = await this.open();
    const transaction = database.transaction('games', 'readonly');
    const result = requestResult(transaction.objectStore('games').get(id)) as Promise<GameRecord | undefined>;
    const record = await transactionResult(transaction, result);
    if (!record) return undefined;
    try {
      assertGameRecord(record);
      return record;
    } catch (error) {
      try { await this.quarantine('games', id, record, error instanceof Error ? error.message : 'Game could not be validated.'); }
      catch { /* A bad row never blocks other local content if quota prevents recovery storage. */ }
      return undefined;
    }
  }

  async listGames(): Promise<GameRecord[]> {
    const database = await this.open();
    const transaction = database.transaction('games', 'readonly');
    const store = transaction.objectStore('games');
    const [records, keys] = await transactionResult(transaction, Promise.all([
      requestResult(store.getAll()) as Promise<unknown[]>,
      requestResult(store.getAllKeys()),
    ]));
    const valid: GameRecord[] = [];
    for (let index = 0; index < records.length; index += 1) {
      try {
        assertGameRecord(records[index] as GameRecord);
        valid.push(records[index] as GameRecord);
      } catch (error) {
        try { await this.quarantine('games', keys[index], records[index], error instanceof Error ? error.message : 'Game could not be validated.'); }
        catch { /* Continue listing unaffected games even if recovery storage is unavailable. */ }
      }
    }
    return valid.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async listRecoveryRecords(): Promise<RecoveryRecord[]> {
    const database = await this.open();
    const transaction = database.transaction('recovery', 'readonly');
    const records = await transactionResult(transaction, requestResult(transaction.objectStore('recovery').getAll()) as Promise<RecoveryRecord[]>);
    return records.filter(isRecoveryRecord).sort((a, b) => b.quarantinedAt.localeCompare(a.quarantinedAt));
  }

  async deleteRecoveryRecord(id: string): Promise<void> {
    const database = await this.open();
    const transaction = database.transaction('recovery', 'readwrite');
    await transactionResult(transaction, requestResult(transaction.objectStore('recovery').delete(id)).then(() => undefined));
  }

  async deleteGame(id: string): Promise<void> {
    const database = await this.open();
    const transaction = database.transaction(['games', 'analysis'], 'readwrite');
    const requestPromise = Promise.all([
      requestResult(transaction.objectStore('games').delete(id)),
      deleteByIndex(transaction.objectStore('analysis'), 'gameId', id),
    ]).then(() => undefined);
    await transactionResult(transaction, requestPromise);
  }

  async clearGames(): Promise<void> {
    const database = await this.open();
    const transaction = database.transaction(['games', 'analysis'], 'readwrite');
    const requestPromise = Promise.all([
      requestResult(transaction.objectStore('games').clear()),
      requestResult(transaction.objectStore('analysis').clear()),
    ]).then(() => undefined);
    await transactionResult(transaction, requestPromise);
  }

  async clearAllData(): Promise<void> {
    const database = await this.open();
    const transaction = database.transaction(['games', 'analysis', 'progress', 'recovery'], 'readwrite');
    const requestPromise = Promise.all([
      requestResult(transaction.objectStore('games').clear()),
      requestResult(transaction.objectStore('analysis').clear()),
      requestResult(transaction.objectStore('progress').clear()),
      requestResult(transaction.objectStore('recovery').clear()),
    ]).then(() => undefined);
    await transactionResult(transaction, requestPromise);
  }

  async exportBackup(): Promise<string> {
    // Validation may quarantine malformed rows; read recovery only after those
    // writes commit, so the same export includes every newly preserved record.
    const games = await this.listGames();
    const progress = await this.listProgress();
    const analysis = await this.listAllAnalysis();
    const recovery = await this.listRecoveryRecords();
    const backup: LocalDataBackup = {
      format: BACKUP_FORMAT,
      schemaVersion: BACKUP_SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      games,
      progress,
      analysis,
      recovery,
    };
    const json = stringifyJsonSafely(backup);
    if (utf8ByteLength(json) > MAX_BACKUP_BYTES) throw new LocalStoreError('Local backup exceeds the 25 MB download limit. Export or delete data in smaller groups.');
    return json;
  }

  /** Validate completely, then merge missing records atomically without overwriting local IDs. */
  async restoreBackup(json: string): Promise<BackupRestoreSummary> {
    const backup = parseBackupJson(json);
    const database = await this.open();
    const stores = ['games', 'progress', 'analysis', 'recovery'] as const;
    const transaction = database.transaction([...stores], 'readwrite', { durability: 'strict' });
    const existingKeys = Promise.all(stores.map((name) => requestResult(transaction.objectStore(name).getAllKeys())));
    const summary: BackupRestoreSummary = {
      added: { games: 0, progress: 0, analysis: 0, recovery: 0 },
      skipped: { games: 0, progress: 0, analysis: 0, recovery: 0 },
    };
    const operation = existingKeys.then((keysByStore) => {
      const keySets = keysByStore.map((keys) => new Set<IDBValidKey>(keys));
      const addMissing = <T extends { id: string }>(values: T[], storeName: typeof stores[number], keySet: Set<IDBValidKey>, category: keyof BackupRestoreSummary['added']) => {
        const store = transaction.objectStore(storeName);
        for (const value of values) {
          if (keySet.has(value.id)) {
            summary.skipped[category] += 1;
            continue;
          }
          store.add(structuredClone(value));
          keySet.add(value.id);
          summary.added[category] += 1;
        }
      };
      addMissing(backup.games, 'games', keySets[0], 'games');
      addMissing(backup.progress, 'progress', keySets[1], 'progress');
      addMissing(backup.analysis, 'analysis', keySets[2], 'analysis');
      addMissing(backup.recovery, 'recovery', keySets[3], 'recovery');
    });
    await transactionResult(transaction, operation);
    return summary;
  }

  async saveProgress(record: ProgressRecord): Promise<void> {
    assertProgressRecord(record);
    const database = await this.open();
    const transaction = database.transaction('progress', 'readwrite');
    const request = transaction.objectStore('progress').put(structuredClone(record));
    await transactionResult(transaction, requestResult(request).then(() => undefined));
  }

  async listProgress(type?: ProgressRecord['type']): Promise<ProgressRecord[]> {
    const database = await this.open();
    const transaction = database.transaction('progress', 'readonly');
    const store = transaction.objectStore('progress');
    const [records, keys] = await transactionResult(transaction, Promise.all([
      requestResult(store.getAll()) as Promise<unknown[]>,
      requestResult(store.getAllKeys()),
    ]));
    const valid: ProgressRecord[] = [];
    for (let index = 0; index < records.length; index += 1) {
      const record = records[index];
      try {
        assertProgressRecord(record);
        if (!type || record.type === type) valid.push(record);
      } catch (error) {
        try { await this.quarantine('progress', keys[index], record, error instanceof Error ? error.message : 'Progress could not be validated.'); }
        catch { /* Keep corrupt progress isolated from valid learning records. */ }
      }
    }
    return valid.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async saveAnalysis(record: AnalysisRecord): Promise<void> {
    assertAnalysisRecord(record);
    const database = await this.open();
    const transaction = database.transaction('analysis', 'readwrite');
    const request = transaction.objectStore('analysis').put(structuredClone(record));
    await transactionResult(transaction, requestResult(request).then(() => undefined));
  }

  async listAllAnalysis(): Promise<AnalysisRecord[]> {
    const database = await this.open();
    const transaction = database.transaction('analysis', 'readonly');
    const store = transaction.objectStore('analysis');
    const [records, keys] = await transactionResult(transaction, Promise.all([
      requestResult(store.getAll()) as Promise<unknown[]>,
      requestResult(store.getAllKeys()),
    ]));
    const valid: AnalysisRecord[] = [];
    for (let index = 0; index < records.length; index += 1) {
      const record = records[index];
      try {
        assertAnalysisRecord(record);
        valid.push(record);
      } catch (error) {
        try { await this.quarantine('analysis', keys[index], record, error instanceof Error ? error.message : 'Analysis could not be validated.'); }
        catch { /* Invalid analysis must not prevent reading a game's other content. */ }
      }
    }
    return valid.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async listAnalysis(gameId: string): Promise<AnalysisRecord[]> {
    return (await this.listAllAnalysis()).filter((record) => record.gameId === gameId);
  }

  async close(): Promise<void> {
    const database = await this.databasePromise;
    database?.close();
    this.databasePromise = undefined;
  }

  async deleteDatabase(): Promise<void> {
    await this.close();
    const factory = this.factory;
    if (!factory) throw new LocalStoreError('IndexedDB is not available in this browser.');
    await new Promise<void>((resolve, reject) => {
      const request = factory.deleteDatabase(this.databaseName);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(new LocalStoreError('Could not delete local database.', { cause: request.error ?? undefined }));
      request.onblocked = () => reject(new LocalStoreError('Database deletion is blocked by another open tab.'));
    });
  }
}

function deleteByIndex(store: IDBObjectStore, indexName: string, value: IDBValidKey): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = store.index(indexName).openKeyCursor(IDBKeyRange.only(value));
    request.onerror = () => reject(request.error ?? new LocalStoreError('Could not enumerate analysis records.'));
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) {
        resolve();
        return;
      }
      const deleteRequest = store.delete(cursor.primaryKey);
      deleteRequest.onerror = () => reject(deleteRequest.error ?? new LocalStoreError('Could not delete analysis record.'));
      cursor.continue();
    };
  });
}

