import { describe, expect, it } from 'vitest';
import { applyMove, createGame } from '../domain/chess/session';
import { resumeClock, restoreClock } from '../domain/clock/ChessClock';
import { assertGameRecord, LocalChessStore } from './LocalChessStore';

let databaseCounter = 0;
function databaseName(prefix = 'chess-game-master-test') {
  return `${prefix}-${++databaseCounter}`;
}
function makeStore(name = databaseName()) {
  return new LocalChessStore(indexedDB, name);
}

async function seedVersionOneDatabase(name: string, games: unknown[]): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.open(name, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      const gameStore = database.createObjectStore('games', { keyPath: 'id' });
      gameStore.createIndex('updatedAt', 'updatedAt');
      gameStore.createIndex('status', 'status');
      gameStore.createIndex('mode', 'mode');
      const progressStore = database.createObjectStore('progress', { keyPath: 'id' });
      progressStore.createIndex('type', 'type');
      progressStore.createIndex('updatedAt', 'updatedAt');
      const analysisStore = database.createObjectStore('analysis', { keyPath: 'id' });
      analysisStore.createIndex('gameId', 'gameId');
      analysisStore.createIndex('updatedAt', 'updatedAt');
    };
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const database = request.result;
      const transaction = database.transaction('games', 'readwrite');
      for (const game of games) transaction.objectStore('games').put(game);
      transaction.oncomplete = () => { database.close(); resolve(); };
      transaction.onerror = () => { database.close(); reject(transaction.error); };
      transaction.onabort = () => { database.close(); reject(transaction.error); };
    };
  });
}

async function putRaw(name: string, storeName: 'games' | 'progress' | 'analysis', value: unknown): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.open(name, 2);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const database = request.result;
      const transaction = database.transaction(storeName, 'readwrite');
      transaction.objectStore(storeName).put(value);
      transaction.oncomplete = () => { database.close(); resolve(); };
      transaction.onerror = () => { database.close(); reject(transaction.error); };
      transaction.onabort = () => { database.close(); reject(transaction.error); };
    };
  });
}

describe('IndexedDB local-first repository', () => {
  it('reports unsupported IndexedDB through async storage errors instead of crashing the app shell', async () => {
    const store = new LocalChessStore(null, 'no-indexeddb');
    await expect(store.listGames()).rejects.toThrow(/IndexedDB is not available/i);
  });

  it('commits and reloads the canonical game aggregate', async () => {
    const store = makeStore();
    let game = createGame({ id: 'saved-game', now: '2026-10-05T00:00:00.000Z' });
    game = applyMove(game, 'e2e4').record;
    game = applyMove(game, 'e7e5').record;
    await store.saveGame(game);
    const loaded = await store.getGame(game.id);
    expect(loaded).toEqual(game);
    expect((await store.listGames()).map((item) => item.id)).toEqual(['saved-game']);
    await store.close();
  });

  it('persists and restores a clocked game after a store close/reopen boundary', async () => {
    const name = databaseName('timed-reload');
    const store = makeStore(name);
    const game = createGame({ id: 'timed-reload-game', timeControl: { baseSeconds: 90, incrementSeconds: 3 } });
    const live = resumeClock(restoreClock(game.clock!), 5_000);
    const afterMove = applyMove(game, 'e2e4', { clock: live, monotonicNowMs: 9_000 }).record;
    await store.saveGame(afterMove);
    await store.close();

    const reopened = makeStore(name);
    const loaded = await reopened.getGame(game.id);
    expect(loaded).toEqual(afterMove);
    expect(loaded?.clock).toMatchObject({ whiteRemainingMs: 89_000, blackRemainingMs: 90_000, activeSide: 'b', paused: true });
    expect(Object.hasOwn(loaded!.clock!, 'monotonicAnchorMs')).toBe(false);
    await reopened.close();
  });

  it('rejects corrupted FEN checkpoints and inconsistent repetition state before write', async () => {
    const store = makeStore();
    const game = createGame({ id: 'bad-game' });
    expect(() => assertGameRecord({ ...game, currentFen: 'not a fen' })).toThrow(/checkpoint/i);
    expect(() => assertGameRecord({ ...game, repetitionKeys: [] })).toThrow(/repetition history/i);
    const unsupportedRules = { ...game, ruleset: { ...game.ruleset, id: 'unapproved-ruleset' } } as unknown as typeof game;
    expect(() => assertGameRecord(unsupportedRules)).toThrow(/ruleset metadata/i);
    expect(() => assertGameRecord({ ...game, status: 'finished' })).toThrow(/must include its result/i);
    await expect(store.saveGame({ ...game, currentFen: 'not a fen' })).rejects.toThrow(/checkpoint/i);
    await store.close();
  });

  it('bounds JSON sidecars before they enter local storage', async () => {
    const store = makeStore();
    const updatedAt = '2026-10-05T00:00:00.000Z';
    await expect(store.saveProgress({ id: 'oversized-progress', type: 'lesson', updatedAt, payload: { text: 'x'.repeat(200_001) } }))
      .rejects.toThrow(/payload exceeds/i);
    await expect(store.saveAnalysis({ id: 'oversized-analysis', gameId: 'game', updatedAt, payload: { text: 'x'.repeat(2_000_001) } }))
      .rejects.toThrow(/payload exceeds/i);
    await store.close();
  });

  it('migrates valid v1 game records to schema v2 without losing history', async () => {
    const name = databaseName('migration-valid');
    let legacy = createGame({ id: 'legacy-valid' });
    legacy = applyMove(legacy, 'e2e4').record;
    await seedVersionOneDatabase(name, [{ ...legacy, schemaVersion: 1 }]);
    const store = makeStore(name);
    const migrated = await store.getGame('legacy-valid');
    expect(migrated).toMatchObject({ id: 'legacy-valid', schemaVersion: 2, moveHistory: [{ uci: 'e2e4', san: 'e4' }] });
    expect(await store.listRecoveryRecords()).toHaveLength(0);
    await store.close();
  });

  it('quarantines a corrupt v1 row during migration while preserving the raw record', async () => {
    const name = databaseName('migration-corrupt');
    const legacy = createGame({ id: 'legacy-corrupt' });
    await seedVersionOneDatabase(name, [{ ...legacy, schemaVersion: 1, currentFen: 'corrupt-checkpoint' }]);
    const store = makeStore(name);
    expect(await store.listGames()).toHaveLength(0);
    const recovered = await store.listRecoveryRecords();
    expect(recovered).toHaveLength(1);
    expect(recovered[0]).toMatchObject({ source: 'games', originalKey: 'legacy-corrupt', value: { id: 'legacy-corrupt', currentFen: 'corrupt-checkpoint', schemaVersion: 1 } });
    await store.close();
  });

  it('recovers one corrupt game row without making other saved games unavailable', async () => {
    const name = databaseName('corrupt-row');
    const seed = makeStore(name);
    await seed.saveGame(createGame({ id: 'good-game' }));
    await seed.saveGame(createGame({ id: 'bad-row' }));
    await seed.close();
    const bad = createGame({ id: 'bad-row' });
    await putRaw(name, 'games', { ...bad, repetitionKeys: [] });

    const recoveredStore = makeStore(name);
    expect((await recoveredStore.listGames()).map((game) => game.id)).toEqual(['good-game']);
    expect(await recoveredStore.getGame('bad-row')).toBeUndefined();
    expect(await recoveredStore.listRecoveryRecords()).toMatchObject([{ source: 'games', originalKey: 'bad-row' }]);
    await recoveredStore.close();
  });

  it('quarantines malformed learning progress and analysis records individually', async () => {
    const name = databaseName('corrupt-sidecars');
    const store = makeStore(name);
    const game = createGame({ id: 'sidecar-game' });
    await store.saveGame(game);
    await store.saveProgress({ id: 'lesson:good', type: 'lesson', updatedAt: game.updatedAt, payload: { completed: true } });
    await store.saveAnalysis({ id: 'analysis:good', gameId: game.id, updatedAt: game.updatedAt, payload: { schemaVersion: 1 } });
    await store.close();
    await putRaw(name, 'progress', { id: 'lesson:bad', type: 'lesson', updatedAt: game.updatedAt, payload: 'not-an-object' });
    await putRaw(name, 'analysis', { id: 'analysis:bad', gameId: game.id, updatedAt: game.updatedAt, payload: null });

    const recoveredStore = makeStore(name);
    expect(await recoveredStore.listProgress('lesson')).toMatchObject([{ id: 'lesson:good' }]);
    expect(await recoveredStore.listAnalysis(game.id)).toMatchObject([{ id: 'analysis:good' }]);
    expect((await recoveredStore.listRecoveryRecords()).map((entry) => entry.source).sort()).toEqual(['analysis', 'progress']);
    await recoveredStore.close();
  });

  it('upserts learning progress and analysis records, and cascades analysis deletion with a game', async () => {
    const store = makeStore();
    const game = createGame({ id: 'cascade' });
    await store.saveGame(game);
    await store.saveProgress({ id: 'lesson:rules-1', type: 'lesson', updatedAt: '2026-10-05T00:00:00Z', payload: { attempts: 2 } });
    await store.saveProgress({ id: 'puzzle:mate-1', type: 'puzzle', updatedAt: '2026-10-05T00:00:01Z', payload: { solved: true } });
    await store.saveAnalysis({ id: 'analysis:1', gameId: game.id, updatedAt: '2026-10-05T00:00:02Z', payload: { engine: 'unavailable' } });
    expect(await store.listProgress('lesson')).toHaveLength(1);
    expect(await store.listAnalysis(game.id)).toHaveLength(1);
    await store.deleteGame(game.id);
    expect(await store.getGame(game.id)).toBeUndefined();
    expect(await store.listAnalysis(game.id)).toHaveLength(0);
    await store.close();
  });

  it('exports a versioned local backup, atomically restores validated records, and never overwrites conflicts', async () => {
    const sourceName = databaseName('backup-source');
    const source = makeStore(sourceName);
    const game = createGame({ id: 'backup-timed-game', timeControl: { baseSeconds: 180, incrementSeconds: 2 } });
    const played = applyMove(game, 'e2e4', { clock: resumeClock(restoreClock(game.clock!), 5_000), monotonicNowMs: 8_000 }).record;
    await source.saveGame(played);
    await source.saveProgress({ id: 'lesson:backup', type: 'lesson', updatedAt: game.updatedAt, payload: { completed: true } });
    await source.saveAnalysis({ id: 'analysis:backup', gameId: game.id, updatedAt: game.updatedAt, payload: { schemaVersion: 1, local: true } });
    const json = await source.exportBackup();
    await source.close();

    const destination = makeStore(databaseName('backup-destination'));
    await destination.saveProgress({ id: 'lesson:backup', type: 'lesson', updatedAt: game.updatedAt, payload: { local: 'keep this record' } });
    const restored = await destination.restoreBackup(json);
    expect(restored).toEqual({
      added: { games: 1, progress: 0, analysis: 1, recovery: 0 },
      skipped: { games: 0, progress: 1, analysis: 0, recovery: 0 },
    });
    expect(await destination.getGame(game.id)).toEqual(played);
    expect(await destination.listAllAnalysis()).toMatchObject([{ id: 'analysis:backup', gameId: game.id }]);
    expect(await destination.listProgress()).toMatchObject([{ id: 'lesson:backup', payload: { local: 'keep this record' } }]);
    expect(await destination.restoreBackup(json)).toEqual({
      added: { games: 0, progress: 0, analysis: 0, recovery: 0 },
      skipped: { games: 1, progress: 1, analysis: 1, recovery: 0 },
    });

    const invalidBackup = JSON.parse(json) as { games: Array<Record<string, unknown>> };
    invalidBackup.games[0].currentFen = 'not a fen';
    const empty = makeStore(databaseName('backup-invalid'));
    await expect(empty.restoreBackup(JSON.stringify(invalidBackup))).rejects.toThrow(/checkpoint/i);
    expect(await empty.listGames()).toHaveLength(0);
    await Promise.all([destination.close(), empty.close()]);
  });

  it('includes quarantined recovery copies in a full backup and restores them without dropping valid games', async () => {
    const sourceName = databaseName('backup-recovery-source');
    const seeded = makeStore(sourceName);
    await seeded.saveGame(createGame({ id: 'backup-valid-game' }));
    await seeded.close();
    const damaged = createGame({ id: 'backup-damaged-game' });
    await putRaw(sourceName, 'games', { ...damaged, currentFen: 'invalid checkpoint' });
    const source = makeStore(sourceName);
    const json = await source.exportBackup();
    const exported = JSON.parse(json) as { games: Array<{ id: string }>; recovery: Array<{ originalKey: string }> };
    expect(exported.games.map((game) => game.id)).toEqual(['backup-valid-game']);
    expect(exported.recovery).toMatchObject([{ originalKey: 'backup-damaged-game' }]);

    const destination = makeStore(databaseName('backup-recovery-destination'));
    const summary = await destination.restoreBackup(json);
    expect(summary.added).toEqual({ games: 1, progress: 0, analysis: 0, recovery: 1 });
    expect(await destination.listGames()).toMatchObject([{ id: 'backup-valid-game' }]);
    expect(await destination.listRecoveryRecords()).toMatchObject([{ originalKey: 'backup-damaged-game', source: 'games' }]);
    await Promise.all([source.close(), destination.close()]);
  });

  it('clears saved games and associated analysis in one transaction', async () => {
    const store = makeStore();
    const game = createGame({ id: 'clear-me' });
    await store.saveGame(game);
    await store.saveAnalysis({ id: 'a', gameId: game.id, updatedAt: game.updatedAt, payload: {} });
    await store.clearGames();
    expect(await store.listGames()).toHaveLength(0);
    expect(await store.listAnalysis(game.id)).toHaveLength(0);
    await store.close();
  });

  it('deletes all local game, analysis, recovery and learning-progress data on explicit erase', async () => {
    const store = makeStore();
    const game = createGame({ id: 'erase-all' });
    await store.saveGame(game);
    await store.saveAnalysis({ id: 'erase-analysis', gameId: game.id, updatedAt: game.updatedAt, payload: {} });
    await store.saveProgress({ id: 'lesson:erase', type: 'lesson', updatedAt: game.updatedAt, payload: { completed: true } });
    await store.clearAllData();
    expect(await store.listGames()).toHaveLength(0);
    expect(await store.listAnalysis(game.id)).toHaveLength(0);
    expect(await store.listProgress()).toHaveLength(0);
    expect(await store.listRecoveryRecords()).toHaveLength(0);
    await store.close();
  });
});
