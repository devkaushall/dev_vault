import type { Color } from 'chess.js';
import type { PersistedClockSnapshot } from '../chess/types';

export type ClockState = {
  type: 'fischer';
  baseMs: number;
  incrementMs: number;
  whiteRemainingMs: number;
  blackRemainingMs: number;
  activeSide?: Color;
  /** performance.now() anchor; never compare this value with Date.now(). */
  monotonicAnchorMs?: number;
  paused: boolean;
  revision: number;
};

export type ClockSnapshot = {
  whiteRemainingMs: number;
  blackRemainingMs: number;
  activeSide?: Color;
  paused: boolean;
  flaggedSide?: Color;
};

function isSafeMilliseconds(value: number, allowZero: boolean): boolean {
  return Number.isSafeInteger(value) && (allowZero ? value >= 0 : value > 0);
}

function assertClockState(clock: ClockState | PersistedClockSnapshot): void {
  if (clock.type !== 'fischer'
    || !isSafeMilliseconds(clock.baseMs, false)
    || !isSafeMilliseconds(clock.incrementMs, true)
    || !isSafeMilliseconds(clock.whiteRemainingMs, true)
    || !isSafeMilliseconds(clock.blackRemainingMs, true)
    || !Number.isSafeInteger(clock.revision) || clock.revision < 0
    || (clock.activeSide !== undefined && clock.activeSide !== 'w' && clock.activeSide !== 'b')
    || typeof clock.paused !== 'boolean') {
    throw new RangeError('Clock state is malformed.');
  }
  if ('monotonicAnchorMs' in clock && clock.monotonicAnchorMs !== undefined && !Number.isFinite(clock.monotonicAnchorMs)) {
    throw new RangeError('Clock anchor must be a finite monotonic timestamp.');
  }
  if (!clock.paused && (!clock.activeSide || !('monotonicAnchorMs' in clock) || clock.monotonicAnchorMs === undefined)) {
    throw new RangeError('A running clock needs an active side and monotonic anchor.');
  }
}

export function createClock(baseSeconds: number, incrementSeconds = 0): ClockState {
  const baseMs = Math.round(baseSeconds * 1000);
  const incrementMs = Math.round(incrementSeconds * 1000);
  if (!Number.isFinite(baseSeconds) || baseSeconds <= 0 || !isSafeMilliseconds(baseMs, false)) {
    throw new RangeError('Base time must round to a finite positive number of milliseconds.');
  }
  if (!Number.isFinite(incrementSeconds) || incrementSeconds < 0 || !isSafeMilliseconds(incrementMs, true)) {
    throw new RangeError('Increment must round to a finite non-negative number of milliseconds.');
  }
  return {
    type: 'fischer',
    baseMs,
    incrementMs,
    whiteRemainingMs: baseMs,
    blackRemainingMs: baseMs,
    paused: true,
    revision: 0,
  };
}

function nextRevision(clock: ClockState | PersistedClockSnapshot): number {
  const next = clock.revision + 1;
  if (!Number.isSafeInteger(next)) throw new RangeError('Clock revision exceeded the safe numeric range.');
  return next;
}

function assertMonotonicTimestamp(nowMs: number): void {
  if (!Number.isFinite(nowMs)) throw new RangeError('Clock needs a finite monotonic timestamp.');
}

function elapsedMs(anchor: number | undefined, now: number): number {
  if (anchor === undefined) return 0;
  if (now < anchor) throw new RangeError('Monotonic clock timestamp moved backwards.');
  // The host monotonic clock can be fractional. Round elapsed time up so every
  // durable countdown remains an integer millisecond and sub-ms fractions never
  // gift time back to a player.
  return Math.ceil(now - anchor);
}

export function snapshotClock(clock: ClockState, nowMs: number): ClockSnapshot {
  assertMonotonicTimestamp(nowMs);
  assertClockState(clock);
  if (!clock.activeSide || clock.paused || clock.monotonicAnchorMs === undefined) {
    return {
      whiteRemainingMs: clock.whiteRemainingMs,
      blackRemainingMs: clock.blackRemainingMs,
      activeSide: clock.activeSide,
      paused: clock.paused,
    };
  }
  const elapsed = elapsedMs(clock.monotonicAnchorMs, nowMs);
  const current = clock.activeSide === 'w' ? clock.whiteRemainingMs - elapsed : clock.blackRemainingMs - elapsed;
  return {
    whiteRemainingMs: clock.activeSide === 'w' ? Math.max(0, current) : clock.whiteRemainingMs,
    blackRemainingMs: clock.activeSide === 'b' ? Math.max(0, current) : clock.blackRemainingMs,
    activeSide: clock.activeSide,
    paused: false,
    ...(current <= 0 ? { flaggedSide: clock.activeSide } : {}),
  };
}

export function startClock(clock: ClockState, side: Color, nowMs: number): ClockState {
  assertMonotonicTimestamp(nowMs);
  assertClockState(clock);
  if (!clock.paused) throw new Error('Clock is already running.');
  const remaining = side === 'w' ? clock.whiteRemainingMs : clock.blackRemainingMs;
  if (remaining <= 0) throw new Error('A flagged clock cannot be restarted.');
  return { ...clock, activeSide: side, monotonicAnchorMs: nowMs, paused: false, revision: nextRevision(clock) };
}

export type ClockMoveResult = {
  clock: ClockState;
  flaggedSide?: Color;
};

/** Add the Fischer increment exactly once for an accepted move, then pass the turn. */
export function commitClockMove(clock: ClockState, mover: Color, nowMs: number): ClockMoveResult {
  assertMonotonicTimestamp(nowMs);
  assertClockState(clock);
  if (clock.paused || !clock.activeSide || clock.activeSide !== mover) throw new Error('Clock side does not match the move.');
  const display = snapshotClock(clock, nowMs);
  if (display.flaggedSide) {
    const flagged = display.flaggedSide;
    return {
      flaggedSide: flagged,
      clock: {
        ...clock,
        whiteRemainingMs: display.whiteRemainingMs,
        blackRemainingMs: display.blackRemainingMs,
        monotonicAnchorMs: undefined,
        paused: true,
        revision: nextRevision(clock),
      },
    };
  }
  const whiteRemainingMs = display.whiteRemainingMs + (mover === 'w' ? clock.incrementMs : 0);
  const blackRemainingMs = display.blackRemainingMs + (mover === 'b' ? clock.incrementMs : 0);
  if (!Number.isSafeInteger(whiteRemainingMs) || !Number.isSafeInteger(blackRemainingMs)) throw new RangeError('Clock time exceeded the safe numeric range.');
  return {
    clock: {
      ...clock,
      whiteRemainingMs,
      blackRemainingMs,
      activeSide: mover === 'w' ? 'b' : 'w',
      monotonicAnchorMs: nowMs,
      paused: false,
      revision: nextRevision(clock),
    },
  };
}

export function pauseClock(clock: ClockState, nowMs: number): ClockState {
  assertClockState(clock);
  if (clock.paused || !clock.activeSide) return clock;
  assertMonotonicTimestamp(nowMs);
  const display = snapshotClock(clock, nowMs);
  return {
    ...clock,
    whiteRemainingMs: display.whiteRemainingMs,
    blackRemainingMs: display.blackRemainingMs,
    monotonicAnchorMs: undefined,
    paused: true,
    revision: nextRevision(clock),
  };
}

export function resumeClock(clock: ClockState, nowMs: number): ClockState {
  assertMonotonicTimestamp(nowMs);
  assertClockState(clock);
  if (!clock.paused || !clock.activeSide) return clock;
  const remaining = clock.activeSide === 'w' ? clock.whiteRemainingMs : clock.blackRemainingMs;
  if (remaining <= 0) throw new Error('A flagged clock cannot be resumed.');
  return { ...clock, monotonicAnchorMs: nowMs, paused: false, revision: nextRevision(clock) };
}

/** Make a crash-safe durable snapshot; performance.now() is session-local and omitted. */
export function persistClockSnapshot(clock: ClockState, nowMs: number): PersistedClockSnapshot {
  const display = snapshotClock(clock, nowMs);
  const snapshot: PersistedClockSnapshot = {
    type: 'fischer',
    baseMs: clock.baseMs,
    incrementMs: clock.incrementMs,
    whiteRemainingMs: display.whiteRemainingMs,
    blackRemainingMs: display.blackRemainingMs,
    ...(display.activeSide ? { activeSide: display.activeSide } : {}),
    paused: true,
    // A storage projection is not a live transition; retain the revision so a
    // running in-memory clock can continue while this immutable snapshot saves.
    revision: clock.revision,
  };
  assertClockState(snapshot);
  return snapshot;
}

/** Rehydrate a persisted, already-paused snapshot: performance.now() is session-local. */
export function restoreClock(clock: ClockState | PersistedClockSnapshot): ClockState {
  assertClockState(clock);
  if (!clock.paused) throw new Error('Pause and snapshot a running clock before persisting it.');
  return {
    type: 'fischer',
    baseMs: clock.baseMs,
    incrementMs: clock.incrementMs,
    whiteRemainingMs: clock.whiteRemainingMs,
    blackRemainingMs: clock.blackRemainingMs,
    ...(clock.activeSide ? { activeSide: clock.activeSide } : {}),
    monotonicAnchorMs: undefined,
    paused: true,
    revision: nextRevision(clock),
  };
}
