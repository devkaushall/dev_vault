import { describe, expect, it } from 'vitest';
import { commitClockMove, createClock, pauseClock, persistClockSnapshot, resumeClock, restoreClock, snapshotClock, startClock } from './ChessClock';

describe('monotonic Fischer clock', () => {
  it('uses monotonic elapsed time and adds the increment exactly once after an accepted move', () => {
    let clock = createClock(60, 2);
    clock = startClock(clock, 'w', 10_000);
    expect(snapshotClock(clock, 15_000)).toMatchObject({ whiteRemainingMs: 55_000, blackRemainingMs: 60_000 });
    const result = commitClockMove(clock, 'w', 15_000);
    expect(result.flaggedSide).toBeUndefined();
    expect(result.clock.whiteRemainingMs).toBe(57_000);
    expect(result.clock.blackRemainingMs).toBe(60_000);
    expect(result.clock.activeSide).toBe('b');
    expect(result.clock.monotonicAnchorMs).toBe(15_000);
  });

  it('rounds fractional elapsed time up to integer milliseconds across snapshots and moves', () => {
    const clock = startClock(createClock(10, 1), 'w', 0.1);
    expect(snapshotClock(clock, 1.2).whiteRemainingMs).toBe(9_998);
    const moved = commitClockMove(clock, 'w', 1.2);
    expect(moved.clock.whiteRemainingMs).toBe(10_998);
    expect(persistClockSnapshot(moved.clock, 1.2).whiteRemainingMs).toBe(10_998);
  });

  it('flags at zero without adding an increment', () => {
    const clock = startClock(createClock(1, 5), 'w', 100);
    const result = commitClockMove(clock, 'w', 1_100);
    expect(result.flaggedSide).toBe('w');
    expect(result.clock.whiteRemainingMs).toBe(0);
    expect(result.clock.paused).toBe(true);
  });

  it('pauses, resumes and persists an elapsed snapshot without mixing wall-clock time', () => {
    let clock = startClock(createClock(30), 'b', 4_000);
    clock = pauseClock(clock, 9_000);
    expect(clock.blackRemainingMs).toBe(25_000);
    expect(clock.monotonicAnchorMs).toBeUndefined();
    clock = resumeClock(clock, 80_000);
    expect(snapshotClock(clock, 82_000).blackRemainingMs).toBe(23_000);
    expect(() => restoreClock(clock)).toThrow(/pause and snapshot/i);
    clock = pauseClock(clock, 82_000);
    const restored = restoreClock(clock);
    expect(restored.paused).toBe(true);
    expect(restored.monotonicAnchorMs).toBeUndefined();
    expect(restored.blackRemainingMs).toBe(23_000);
  });

  it('rejects invalid timestamps rather than writing NaN clock state', () => {
    const clock = startClock(createClock(30), 'w', 0);
    expect(() => snapshotClock(clock, Number.NaN)).toThrow(/finite monotonic timestamp/i);
    expect(() => commitClockMove(clock, 'w', Number.POSITIVE_INFINITY)).toThrow(/finite monotonic timestamp/i);
    const paused = pauseClock(clock, 100);
    expect(() => resumeClock(paused, Number.NaN)).toThrow(/finite monotonic timestamp/i);
  });

  it('rejects rounded-zero base times and revision overflow', () => {
    expect(() => createClock(0.0001)).toThrow(/positive number of milliseconds/i);
    const exhausted = { ...createClock(1), revision: Number.MAX_SAFE_INTEGER };
    expect(() => startClock(exhausted, 'w', 0)).toThrow(/revision exceeded/i);
  });

  it('rejects wrong-side and double-move clock transactions', () => {
    const clock = startClock(createClock(30, 1), 'w', 0);
    expect(() => commitClockMove(clock, 'b', 100)).toThrow(/side does not match/i);
    const next = commitClockMove(clock, 'w', 100).clock;
    expect(() => commitClockMove(next, 'w', 200)).toThrow(/side does not match/i);
  });
});
