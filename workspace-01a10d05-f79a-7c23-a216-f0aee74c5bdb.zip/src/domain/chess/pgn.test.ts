import { describe, expect, it } from 'vitest';
import { exportFen, exportPgn, importPgn } from './pgn';
import { createGame, applyMove } from './session';

const GAME_PGN = `[Event "Test Game"]\n[Site "Local"]\n[Date "2026.10.05"]\n[Round "1"]\n[White "Alice"]\n[Black "Bob"]\n[Result "1-0"]\n\n1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0`;

describe('PGN/FEN/SAN/UCI interoperability', () => {
  it('imports standard PGN into legal SAN/UCI history and a read-only review', () => {
    const imported = importPgn(GAME_PGN, '2026-10-05T00:00:00.000Z');
    expect(imported.record.mode).toBe('Review');
    expect(imported.record.status).toBe('reviewing');
    expect(imported.record.moveHistory.map((move) => move.san)).toEqual(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6']);
    expect(imported.record.moveHistory[0].uci).toBe('e2e4');
    expect(imported.record.players.white.displayName).toBe('Alice');
    expect(imported.record.result).toMatchObject({ score: '1-0', reason: 'imported-result' });
    expect(imported.warnings).toHaveLength(0);
  });

  it('round-trips PGN notation and produces a derived FEN at a chosen ply', () => {
    const imported = importPgn(GAME_PGN).record;
    const exported = exportPgn(imported);
    expect(exported).toContain('1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0');
    expect(exportFen(imported, 1)).toBe('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1');
    expect(() => exportFen(imported, 100)).toThrow(RangeError);
  });

  it('round-trips all six FEN fields including an actionable en-passant target', () => {
    const fen = '4k3/8/8/8/3pP3/8/8/4K3 b - e3 0 28';
    const game = createGame({ id: 'fen-fields', initialFen: fen });
    expect(exportFen(game)).toBe(fen);
    expect(importPgn(exportPgn(game)).record.initialPosition.fen).toBe(fen);
  });

  it('retains SAN disambiguation and UCI promotion through a PGN round trip', () => {
    const ambiguous = createGame({
      id: 'san-disambiguation',
      initialFen: '4k3/8/8/8/8/2N1N3/8/4K3 w - - 0 1',
    });
    const moved = applyMove(ambiguous, 'c3d5').record;
    expect(moved.moveHistory[0].san).toBe('Ncd5');
    const reimported = importPgn(exportPgn(moved)).record;
    expect(reimported.moveHistory[0]).toMatchObject({ san: 'Ncd5', uci: 'c3d5' });

    const promotion = createGame({ id: 'underpromotion', initialFen: '4k3/P7/8/8/8/8/8/4K3 w - - 0 1' });
    const underpromoted = applyMove(promotion, 'a7a8n').record;
    expect(underpromoted.moveHistory[0]).toMatchObject({ san: 'a8=N', uci: 'a7a8n', promotion: 'n' });
    expect(importPgn(exportPgn(underpromoted)).record.moveHistory[0].uci).toBe('a7a8n');
  });

  it('exports custom starting FEN using SetUp/FEN tags', () => {
    const custom = createGame({ id: 'custom', initialFen: '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1' });
    const played = applyMove(custom, 'e2e4').record;
    const pgn = exportPgn(played);
    expect(pgn).toContain('[SetUp "1"]');
    expect(pgn).toContain('[FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"]');
    const reimported = importPgn(pgn).record;
    expect(reimported.initialPosition.fen).toBe(custom.initialPosition.fen);
    expect(reimported.moveHistory[0].uci).toBe('e2e4');
  });

  it('bounds untrusted imports and rejects invalid notation and variants', () => {
    expect(() => importPgn(' '.repeat(500_001))).toThrow(/too large/i);
    expect(() => importPgn('not a PGN move list')).toThrow(/could not be parsed/i);
    const unsupported = `[Event "Variant Test"]\n[Variant "Crazyhouse"]\n[Result "*"]\n\n1. e4 *`;
    expect(() => importPgn(unsupported)).toThrow(/unsupported PGN variant/i);
  });

  it('warns when comments, side variations or annotations are discarded while retaining only legal mainline', () => {
    const parsed = importPgn('[Result "*"]\n\n1. e4 {untrusted note} (1. d4 d5) e5 $1 *');
    expect(parsed.record.result).toBeUndefined();
    expect(parsed.record.moveHistory.map((move) => move.uci)).toEqual(['e2e4', 'e7e5']);
    expect(parsed.warnings.join(' ')).toMatch(/comments.*not preserved/i);
    expect(parsed.warnings.join(' ')).toMatch(/side variations/i);
    expect(parsed.warnings.join(' ')).toMatch(/NAG annotations/i);
    expect(parsed.warnings.join(' ')).toMatch(/unfinished/i);
  });

  it('sanitizes untrusted PGN header keys and values before serialization', () => {
    const base = createGame({ id: 'header-injection' });
    const hostile: typeof base = {
      ...base,
      players: {
        white: { ...base.players.white, displayName: 'Alice"\n[Result "0-1"]' },
        black: { ...base.players.black, displayName: 'Bob\\\r[Black "Mallory"]' },
      },
      pgnHeaders: {
        Event: 'Training\n[Result "0-1"]',
        'Injected] [Result': '0-1',
        Annotator: 'Study"\n[White "Mallory"]',
      },
    };
    const exported = exportPgn(hostile);
    expect(exported).not.toContain('\n[Result "0-1"]');
    expect(exported).not.toContain('\n[White "Mallory"]');
    expect(exported.match(/^\[Result /gm)).toHaveLength(1);
    expect(exported.match(/^\[White /gm)).toHaveLength(1);
    expect(exported).toContain('[Annotator "Study [White Mallory ]"]');
  });

  it('rejects contradictory custom FEN setup metadata', () => {
    expect(() => importPgn('[SetUp "1"]\n[Result "*"]\n\n1. e4 *')).toThrow(/could not be parsed|requires a FEN/i);
    expect(() => importPgn('[SetUp "0"]\n[FEN "4k3/8/8/8/8/8/8/4K3 w - - 0 1"]\n[Result "*"]\n\n*')).toThrow(/could not be parsed|conflicts/i);
  });
});
