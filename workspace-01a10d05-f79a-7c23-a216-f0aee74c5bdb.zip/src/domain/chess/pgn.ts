import { Chess, DEFAULT_POSITION, type PieceSymbol } from 'chess.js';
import { deriveDrawState, enPassantTargetAfterMove, fenAtPly, fenSnapshot, isRecognizedDeadPosition, positionKey, uciForMove } from './position';
import { createGame } from './session';
import type { GameRecord, GameResult, MoveRecord } from './types';

const MAX_PGN_CHARACTERS = 500_000;
const MAX_IMPORTED_PLIES = 2_000;
const PGN_RESULTS = new Set(['1-0', '0-1', '1/2-1/2', '*']);
const PGN_HEADER_KEY = /^[A-Za-z][A-Za-z0-9_]{0,31}$/;

function safeHeaderValue(value: string, maximum = 200): string {
  // chess.js currently writes PGN tag strings without escaping quote/newline
  // characters. Flatten these before handing the value to its serializer.
  return value.normalize('NFC').replace(/["\\\x00-\x1f\x7f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, maximum);
}

function resultScore(value: string | undefined): GameResult['score'] | undefined {
  if (value === '1-0' || value === '0-1' || value === '1/2-1/2') return value;
  return undefined;
}

function resultFromBoard(chess: Chess, repetitionCount: number): GameResult | undefined {
  if (chess.isCheckmate()) return { score: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'checkmate', actor: 'system' };
  if (chess.isStalemate()) return { score: '1/2-1/2', reason: 'stalemate', actor: 'system' };
  if (isRecognizedDeadPosition(chess)) return { score: '1/2-1/2', reason: 'dead-position', actor: 'system' };
  if (repetitionCount >= 5) return { score: '1/2-1/2', reason: 'fivefold-repetition', actor: 'system' };
  if (Number(fenSnapshot(chess).split(' ')[4]) >= 150) return { score: '1/2-1/2', reason: 'seventy-five-move-rule', actor: 'system' };
  return undefined;
}

export type PgnImportResult = {
  record: GameRecord;
  warnings: string[];
};

/** Parse untrusted standard PGN into a read-only review record. */
export function importPgn(input: string, now = new Date().toISOString()): PgnImportResult {
  if (input.length > MAX_PGN_CHARACTERS) throw new Error(`PGN is too large (maximum ${MAX_PGN_CHARACTERS.toLocaleString()} characters).`);
  if (!input.trim()) throw new Error('Paste a PGN game first.');
  const parsed = new Chess();
  try {
    parsed.loadPgn(input, { strict: true });
  } catch (error) {
    throw new Error(`PGN could not be parsed: ${error instanceof Error ? error.message : 'invalid notation'}`);
  }
  const headers = parsed.getHeaders();
  const variant = headers.Variant?.trim().toLowerCase();
  if (variant && variant !== 'standard' && variant !== 'chess') {
    throw new Error(`Unsupported PGN variant: ${headers.Variant}`);
  }
  const setup = headers.SetUp?.trim();
  const fenHeader = headers.FEN?.trim();
  if (setup && setup !== '0' && setup !== '1') throw new Error(`Unsupported PGN SetUp tag: ${setup}`);
  if (setup === '0' && fenHeader) throw new Error('PGN SetUp "0" conflicts with a custom FEN tag.');
  if (setup === '1' && !fenHeader) throw new Error('PGN SetUp "1" requires a FEN tag.');
  if (fenHeader && fenHeader.length > 256) throw new Error('PGN FEN tag is too long.');

  const headerResult = headers.Result?.trim() ?? '*';
  if (!PGN_RESULTS.has(headerResult)) throw new Error(`Unsupported PGN result tag: ${headerResult}`);
  const importedMoves = parsed.history({ verbose: true });
  if (importedMoves.length > MAX_IMPORTED_PLIES) throw new Error(`PGN is too long (maximum ${MAX_IMPORTED_PLIES} half-moves).`);
  const initialFen = fenHeader || DEFAULT_POSITION;
  const replay = new Chess(initialFen);
  const initialFenSnapshot = fenSnapshot(replay, initialFen.trim().split(' ')[3] ?? '-');
  let currentFenSnapshot = initialFenSnapshot;
  const game = createGame({ mode: 'Review', initialFen, now });
  const moveHistory: MoveRecord[] = [];
  const repetitionKeys = [positionKey(replay)];

  for (const imported of importedMoves) {
    const beforeFen = currentFenSnapshot;
    const beforeKey = positionKey(replay);
    const committed = replay.move({
      from: imported.from,
      to: imported.to,
      ...(imported.promotion ? { promotion: imported.promotion } : {}),
    });
    const afterFen = fenSnapshot(replay, enPassantTargetAfterMove(committed.piece, committed.from, committed.to));
    currentFenSnapshot = afterFen;
    const afterKey = positionKey(replay);
    moveHistory.push({
      ply: moveHistory.length + 1,
      from: committed.from,
      to: committed.to,
      ...(committed.promotion ? { promotion: committed.promotion as Exclude<PieceSymbol, 'p' | 'k'> } : {}),
      uci: uciForMove(committed),
      san: committed.san,
      beforeFen,
      afterFen,
      beforeKey,
      afterKey,
      source: 'import',
      committedAt: now,
    });
    repetitionKeys.push(afterKey);
  }

  const lastKey = repetitionKeys.at(-1)!;
  const repetitionCount = repetitionKeys.filter((key) => key === lastKey).length;
  const boundedHeaders: Record<string, string> = {};
  let headerWasSanitized = false;
  for (const [key, value] of Object.entries(headers).slice(0, 100)) {
    if (!PGN_HEADER_KEY.test(key)) {
      headerWasSanitized = true;
      continue;
    }
    const safe = safeHeaderValue(value, 1000);
    if (safe !== value) headerWasSanitized = true;
    boundedHeaders[key] = safe;
  }
  const white = safeHeaderValue(headers.White || 'White');
  const black = safeHeaderValue(headers.Black || 'Black');
  const record: GameRecord = {
    ...game,
    updatedAt: now,
    initialPosition: { fen: initialFenSnapshot, kind: initialFen === DEFAULT_POSITION ? 'standard' : 'imported' },
    moveHistory,
    cursorPly: moveHistory.length,
    currentFen: currentFenSnapshot,
    repetitionKeys,
    pgnHeaders: boundedHeaders,
    players: {
      white: { kind: 'imported', id: 'pgn-white', displayName: white || 'White' },
      black: { kind: 'imported', id: 'pgn-black', displayName: black || 'Black' },
    },
    status: 'reviewing',
    drawState: deriveDrawState(replay, { ...game, moveHistory, repetitionKeys, cursorPly: moveHistory.length }, moveHistory.length),
  };

  const automaticResult = resultFromBoard(replay, repetitionCount);
  const importedScore = resultScore(headerResult);
  if (automaticResult) record.result = automaticResult;
  else if (importedScore) {
    record.result = {
      score: importedScore,
      reason: 'imported-result',
      actor: 'system',
      detail: 'Imported PGN result tag; the original termination reason was not provided or verified.',
    };
  }

  const warnings: string[] = [];
  if (headerResult === '*' && !automaticResult) warnings.push('This PGN is marked unfinished; the review record has no final result.');
  if (headerResult !== '*' && automaticResult && automaticResult.score !== headerResult) {
    warnings.push(`PGN result ${headerResult} conflicts with the terminal board result ${automaticResult.score}; the board result is shown.`);
  }
  if (headerWasSanitized) warnings.push('Some PGN header text was normalized and bounded before saving/exporting.');
  if (fenHeader && setup !== '1') warnings.push('A FEN tag without SetUp "1" was accepted as a custom start position for compatibility.');

  const moveText = input.replace(/^\s*\[[^\r\n]*\]\s*$/gm, '');
  const hasComments = /\{[^}]*\}|;[^\r\n]*/.test(moveText);
  const hasVariations = /[()]/.test(moveText);
  const hasAnnotations = /\$\d{1,3}|(?:^|\s)[!?]{1,2}(?=\s|$)/.test(moveText);
  if (hasComments || hasVariations || hasAnnotations) {
    const omitted = [hasComments && 'comments', hasVariations && 'side variations', hasAnnotations && 'NAG annotations'].filter(Boolean).join(', ');
    warnings.push(`Only the legal mainline is retained; ${omitted} are parsed where supported but not preserved in the review record.`);
  }
  return { record, warnings };
}

/** Export SAN/PGN from the legal canonical move sequence, never from the FEN checkpoint. */
export function exportPgn(record: GameRecord): string {
  const chess = new Chess(record.initialPosition.fen);
  for (const move of record.moveHistory) {
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  }
  const headers = record.pgnHeaders ?? {};
  const reserved = new Set(['Event', 'Site', 'Date', 'Round', 'White', 'Black', 'Result', 'Variant', 'SetUp', 'FEN']);
  for (const [key, value] of Object.entries(headers)) {
    if (reserved.has(key) || !PGN_HEADER_KEY.test(key)) continue;
    if (typeof value === 'string') {
      const safe = safeHeaderValue(value, 1000);
      if (safe) chess.setHeader(key, safe);
    }
  }
  chess.setHeader('Event', safeHeaderValue(headers.Event || 'Chess Game Master') || 'Chess Game Master');
  chess.setHeader('White', safeHeaderValue(record.players.white.displayName || 'White'));
  chess.setHeader('Black', safeHeaderValue(record.players.black.displayName || 'Black'));
  if (record.initialPosition.kind !== 'standard' || record.initialPosition.fen !== DEFAULT_POSITION) {
    chess.setHeader('SetUp', '1');
    chess.setHeader('FEN', record.initialPosition.fen);
  }
  const result = record.result?.score ?? '*';
  chess.setHeader('Result', result);
  return chess.pgn({ maxWidth: 80 });
}

export function exportFen(record: GameRecord, ply = record.cursorPly): string {
  if (!Number.isInteger(ply) || ply < 0 || ply > record.moveHistory.length) throw new RangeError('Move index is out of range.');
  return fenAtPly(record, ply);
}
