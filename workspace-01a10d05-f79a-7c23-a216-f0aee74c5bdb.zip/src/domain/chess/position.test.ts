import { describe, expect, it } from 'vitest';
import { Chess } from 'chess.js';
import { parseUci, positionKey, uciForMove } from './position';
import { createGame } from './session';

const KIWIPETE = 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1';
const EP_EXPOSES_KING = '8/8/8/4KPpr/8/8/8/4k3 w - g6 0 1';
const EP_NO_TARGET = '8/8/8/4KPpr/8/8/8/4k3 w - - 0 1';

describe('authoritative chess.js rules adapter', () => {
  it('matches standard perft reference counts for the initial position', () => {
    const chess = new Chess();
    expect(chess.perft(1)).toBe(20);
    expect(chess.perft(2)).toBe(400);
    expect(chess.perft(3)).toBe(8_902);
    expect(chess.perft(4)).toBe(197_281);
  });

  it('matches Kiwipete counts including castling and pins', () => {
    const chess = new Chess(KIWIPETE);
    expect(chess.perft(1)).toBe(48);
    expect(chess.perft(2)).toBe(2_039);
    expect(chess.perft(3)).toBe(97_862);
  });

  it('matches reference perft counts in en-passant and promotion-rich positions', () => {
    const ep = new Chess('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1');
    expect(ep.perft(1)).toBe(14);
    expect(ep.perft(2)).toBe(191);
    expect(ep.perft(3)).toBe(2_812);

    const promotions = new Chess('r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1');
    expect(promotions.perft(1)).toBe(6);
    expect(promotions.perft(2)).toBe(264);
    expect(promotions.perft(3)).toBe(9_467);
  });

  it('allows castling only when all king transit squares are safe', () => {
    const safe = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
    const castles = safe.moves({ verbose: true }).filter((move) => move.isKingsideCastle() || move.isQueensideCastle());
    expect(castles.map((move) => move.san).sort()).toEqual(['O-O', 'O-O-O']);

    const attackedTransit = new Chess('r3k2r/8/8/8/8/8/5r2/R3K2R w KQkq - 0 1');
    const legalCastleUci = attackedTransit.moves({ verbose: true }).filter((move) => move.isKingsideCastle() || move.isQueensideCastle()).map(uciForMove);
    expect(legalCastleUci).not.toContain('e1g1');
    expect(legalCastleUci).toContain('e1c1');
  });

  it('rejects en passant if removing both pawns exposes the moving king', () => {
    const chess = new Chess(EP_EXPOSES_KING);
    expect(chess.moves({ verbose: true }).some((move) => move.isEnPassant())).toBe(false);
  });

  it('offers all four promotion pieces and does not silently auto-queen', () => {
    const chess = new Chess('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');
    const promotions = chess.moves({ verbose: true }).filter((move) => move.from === 'a7' && move.to === 'a8');
    expect(promotions.map((move) => move.promotion).sort()).toEqual(['b', 'n', 'q', 'r']);
    expect(() => chess.move({ from: 'a7', to: 'a8' })).toThrow();
  });

  it('normalizes an unusable en-passant target out of repetition identity', () => {
    expect(positionKey(new Chess(EP_EXPOSES_KING))).toBe(positionKey(new Chess(EP_NO_TARGET)));
    const legalEp = new Chess('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1');
    expect(positionKey(legalEp)).toContain(' d6');
  });

  it('round-trips UCI promotion moves and rejects malformed coordinates', () => {
    const promotionPosition = new Chess('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');
    const move = promotionPosition.move({ from: 'a7', to: 'a8', promotion: 'n' });
    const uci = uciForMove(move);
    expect(uci).toBe('a7a8n');
    expect(parseUci(uci)).toEqual({ from: 'a7', to: 'a8', promotion: 'n' });
    expect(parseUci('e2e4')).toEqual({ from: 'e2', to: 'e4' });
    expect(() => parseUci('a7a8k')).toThrow(/invalid UCI move/i);
    expect(() => parseUci('i2i4')).toThrow(/invalid UCI move/i);
  });

  it('derives valid FEN from a move record instead of treating a checkpoint as game truth', () => {
    const game = createGame({ id: 'position-test', now: '2026-10-05T00:00:00.000Z' });
    expect(game.currentFen).toBe(game.initialPosition.fen);
    expect(game.moveHistory).toHaveLength(0);
  });
});
