import type { Color, PieceSymbol, Square } from 'chess.js';

export const DEFAULT_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
export const RULESET_ID = 'standard-chess-fide-2023-claim-based-v1';
export const FIDE_LAWS_SOURCE = 'https://handbook.fide.com/chapter/E012023';

export type GameMode =
  | 'Practice'
  | 'Challenge'
  | 'CoachedPractice'
  | 'Learn'
  | 'Puzzle'
  | 'OpeningTraining'
  | 'Review';

export type Ruleset = {
  id: typeof RULESET_ID;
  variant: 'standard';
  policyVersion: 'FIDE-2023';
  sourceUrl: typeof FIDE_LAWS_SOURCE;
  verifiedAt: string;
  drawPolicy: 'threefold-and-fifty-move-claims; fivefold-and-seventy-five-move-automatic';
};

export type PlayerDescriptor = {
  kind: 'human' | 'engine' | 'imported' | 'unknown';
  id: string;
  displayName?: string;
  engineVersion?: string;
};

export type MoveSource = 'human' | 'engine' | 'import' | 'lesson' | 'puzzle';

export type MoveRecord = {
  ply: number;
  from: Square;
  to: Square;
  promotion?: Exclude<PieceSymbol, 'p' | 'k'>;
  uci: string;
  san: string;
  beforeFen: string;
  afterFen: string;
  beforeKey: string;
  afterKey: string;
  source: MoveSource;
  committedAt: string;
};

export type ResultScore = '1-0' | '0-1' | '1/2-1/2';
export type TerminationReason =
  | 'checkmate'
  | 'stalemate'
  | 'dead-position'
  | 'fivefold-repetition'
  | 'seventy-five-move-rule'
  | 'threefold-claim'
  | 'fifty-move-claim'
  | 'resignation'
  | 'draw-agreement'
  | 'timeout'
  | 'timeout-pending-adjudication'
  | 'imported-result'
  | 'aborted';

export type GameResult = {
  score: ResultScore;
  reason: TerminationReason;
  actor?: Color | 'system';
  detail?: string;
};

export type DrawClaimOption = {
  reason: 'threefold-repetition' | 'fifty-move-rule';
  kind: 'current-position' | 'intended-move';
  intendedUci?: string;
  intendedSan?: string;
};

export type DrawState = {
  repetitionCount: number;
  canClaimThreefoldNow: boolean;
  canClaimFiftyMovesNow: boolean;
  intendedClaims: DrawClaimOption[];
  automaticFivefold: boolean;
  automaticSeventyFiveMoves: boolean;
  deadPositionDetected: boolean;
};

export type GameEvent = {
  type: 'takeback' | 'draw-claim' | 'draw-agreement' | 'resignation' | 'abort' | 'timeout-pending';
  at: string;
  actor?: Color | 'system';
  detail?: string;
};

export type SavedVariation = {
  id: string;
  fromPly: number;
  uciMoves: string[];
  createdAt: string;
  label: string;
};

/** Durable clock snapshot. Running clocks are never written to IndexedDB. */
export type PersistedClockSnapshot = {
  type: 'fischer';
  baseMs: number;
  incrementMs: number;
  whiteRemainingMs: number;
  blackRemainingMs: number;
  activeSide?: Color;
  paused: true;
  revision: number;
};

export type GameRecord = {
  id: string;
  schemaVersion: 2;
  createdAt: string;
  updatedAt: string;
  mode: GameMode;
  ruleset: Ruleset;
  initialPosition: {
    fen: string;
    kind: 'standard' | 'custom' | 'imported';
  };
  moveHistory: MoveRecord[];
  /** Current navigation/play cursor. FEN remains a derived checkpoint, not game truth. */
  cursorPly: number;
  currentFen: string;
  repetitionKeys: string[];
  players: { white: PlayerDescriptor; black: PlayerDescriptor };
  status: 'active' | 'finished' | 'reviewing' | 'aborted' | 'adjudication-pending';
  result?: GameResult;
  /** Present only for timed games; always paused in the durable record. */
  clock?: PersistedClockSnapshot;
  drawState: DrawState;
  events: GameEvent[];
  variations: SavedVariation[];
  pgnHeaders?: Record<string, string>;
  notes?: string;
};

export type PositionSnapshot = {
  fen: string;
  positionKey: string;
  turn: Color;
  board: ReturnType<import('chess.js').Chess['board']>;
  inCheck: boolean;
  checkmate: boolean;
  stalemate: boolean;
  legalMoves: Array<{
    from: Square;
    to: Square;
    san: string;
    uci: string;
    promotion?: PieceSymbol;
    flags: string;
  }>;
  drawState: DrawState;
  result?: GameResult;
  ply: number;
  halfMoves: number;
  fullMoves: number;
};

export type NewGameOptions = {
  id?: string;
  initialFen?: string;
  mode?: GameMode;
  players?: Partial<GameRecord['players']>;
  timeControl?: { baseSeconds: number; incrementSeconds?: number };
  now?: string;
};

export type UciMove = {
  from: Square;
  to: Square;
  promotion?: Exclude<PieceSymbol, 'p' | 'k'>;
};
