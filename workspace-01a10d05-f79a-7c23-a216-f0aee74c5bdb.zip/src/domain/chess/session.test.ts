import { describe, expect, it } from 'vitest';
import { abortPractice, applyMove, branchFromCursor, claimDraw, createGame, navigateToPly, redoTakeback, resign, takeback, recordTimeout, classifyTimeout } from './session';
import { derivePosition } from './position';
import { resumeClock, restoreClock, startClock } from '../clock/ChessClock';

describe('canonical game history and outcome rules', () => {
  it('stores legal moves as SAN/UCI events and derives the current FEN', () => {
    const game = createGame({ id: 'game-1', now: '2026-10-05T00:00:00.000Z' });
    const after = applyMove(game, 'e2e4', { committedAt: '2026-10-05T00:00:01.000Z' });
    expect(after.move.san).toBe('e4');
    expect(after.move.uci).toBe('e2e4');
    expect(after.move.beforeFen).toBe(game.initialPosition.fen);
    expect(after.record.currentFen).toBe('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1');
    expect(after.record.repetitionKeys).toHaveLength(2);
    expect(after.record.cursorPly).toBe(1);
  });

  it('rejects illegal moves without mutating the supplied game record', () => {
    const game = createGame({ id: 'illegal' });
    expect(() => applyMove(game, 'e2e5')).toThrow();
    expect(game.moveHistory).toHaveLength(0);
    expect(game.currentFen).toBe(game.initialPosition.fen);
    expect(() => createGame({ initialFen: 'x'.repeat(257) })).toThrow(/FEN is too long/i);
  });

  it('preserves the original line as a variation when a practice takeback is made', () => {
    let game = createGame({ id: 'takeback' });
    game = applyMove(game, 'e2e4').record;
    game = applyMove(game, 'e7e5').record;
    const undone = takeback(game, '2026-10-05T00:00:03.000Z');
    expect(undone.moveHistory.map((move) => move.uci)).toEqual(['e2e4']);
    expect(undone.variations[0].uciMoves).toEqual(['e7e5']);
    expect(undone.events.at(-1)?.type).toBe('takeback');
  });

  it('supports redo from a retained takeback line and branching from a selected ply', () => {
    let game = createGame({ id: 'redo' });
    game = applyMove(game, 'e2e4').record;
    game = applyMove(game, 'e7e5').record;
    const undone = takeback(game);
    const redone = redoTakeback(undone);
    expect(redone.moveHistory.map((move) => move.uci)).toEqual(['e2e4', 'e7e5']);
    expect(redone.variations).toHaveLength(0);

    let longer = redone;
    longer = applyMove(longer, 'g1f3').record;
    longer = applyMove(longer, 'b8c6').record;
    const earlier = navigateToPly(longer, 1);
    const branch = branchFromCursor(earlier);
    expect(branch.moveHistory.map((move) => move.uci)).toEqual(['e2e4']);
    expect(branch.variations.at(-1)?.uciMoves).toEqual(['e7e5', 'g1f3', 'b8c6']);
    const alternate = applyMove(branch, 'c7c5').record;
    expect(alternate.moveHistory.map((move) => move.uci)).toEqual(['e2e4', 'c7c5']);
  });

  it('exposes threefold as a claim and supports claiming before the intended move', () => {
    let game = createGame({ id: 'threefold' });
    for (const uci of ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1']) {
      game = applyMove(game, uci).record;
    }
    const state = derivePosition(game).drawState;
    expect(state.canClaimThreefoldNow).toBe(false);
    expect(state.intendedClaims).toContainEqual(expect.objectContaining({
      reason: 'threefold-repetition',
      kind: 'intended-move',
      intendedUci: 'f6g8',
    }));
    const claimed = claimDraw(game, {
      reason: 'threefold-repetition',
      kind: 'intended-move',
      intendedUci: 'f6g8',
    }, 'b');
    expect(claimed.status).toBe('finished');
    expect(claimed.result).toMatchObject({ score: '1/2-1/2', reason: 'threefold-claim', actor: 'b' });
    expect(claimed.moveHistory).toHaveLength(7); // declared move is not played
  });

  it('makes threefold claimable at the current position but not automatic', () => {
    let game = createGame({ id: 'threefold-now' });
    for (const uci of ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1', 'f6g8']) {
      game = applyMove(game, uci).record;
    }
    expect(game.status).toBe('active');
    expect(game.drawState.canClaimThreefoldNow).toBe(true);
    const claimed = claimDraw(game, { reason: 'threefold-repetition', kind: 'current-position' }, 'w');
    expect(claimed.result?.reason).toBe('threefold-claim');
  });

  it('automatically draws on the fifth occurrence', () => {
    let game = createGame({ id: 'fivefold' });
    for (let cycle = 0; cycle < 4; cycle++) {
      for (const uci of ['g1f3', 'g8f6', 'f3g1', 'f6g8']) game = applyMove(game, uci).record;
    }
    expect(game.status).toBe('finished');
    expect(game.result).toMatchObject({ score: '1/2-1/2', reason: 'fivefold-repetition' });
  });

  it('keeps the 50-move rule claim-based and validates a quiet intended move', () => {
    const game = createGame({ id: 'fifty', initialFen: '4k3/8/8/8/8/8/8/R3K3 w - - 99 50' });
    expect(game.drawState.canClaimFiftyMovesNow).toBe(false);
    expect(game.drawState.intendedClaims).toContainEqual(expect.objectContaining({
      reason: 'fifty-move-rule',
      kind: 'intended-move',
      intendedUci: expect.any(String),
    }));
    const claim = game.drawState.intendedClaims.find((item) => item.reason === 'fifty-move-rule')!;
    const claimed = claimDraw(game, claim, 'w');
    expect(claimed.result?.reason).toBe('fifty-move-claim');
    expect(claimed.moveHistory).toHaveLength(0);
  });

  it('does not offer a 50-move intended claim for a pawn move and resets the half-move clock', () => {
    const pawnMove = createGame({ initialFen: '4k3/8/8/8/8/8/P7/4K3 w - - 99 50' });
    expect(pawnMove.drawState.intendedClaims).not.toContainEqual(expect.objectContaining({
      reason: 'fifty-move-rule',
      intendedUci: 'a2a3',
    }));
    expect(applyMove(pawnMove, 'a2a3').record.currentFen.split(' ')[4]).toBe('0');
  });

  it('applies the automatic 75-move rule and preserves checkmate precedence', () => {
    const near75 = createGame({ id: '75', initialFen: '4k3/8/8/8/8/8/8/R3K3 w - - 149 75' });
    const drawn = applyMove(near75, 'a1a2').record;
    expect(drawn.result?.reason).toBe('seventy-five-move-rule');

    const mateAt150 = createGame({ id: 'mate-150', initialFen: '7k/5Q2/6K1/8/8/8/8/8 w - - 149 75' });
    const mated = applyMove(mateAt150, 'f7g7').record;
    expect(mated.result).toMatchObject({ score: '1-0', reason: 'checkmate' });
  });

  it('stops a Practice record without fabricating a result and preserves a paused clock/history', () => {
    const timed = createGame({ id: 'abort-practice', timeControl: { baseSeconds: 90, incrementSeconds: 2 } });
    const liveClock = startClock(restoreClock(timed.clock!), 'w', 10_000);
    const stopped = abortPractice(timed, '2026-10-05T00:00:05.000Z', { clock: liveClock, monotonicNowMs: 15_000 });
    expect(stopped.status).toBe('aborted');
    expect(stopped.result).toBeUndefined();
    expect(stopped.clock).toMatchObject({ whiteRemainingMs: 85_000, activeSide: 'w', paused: true });
    expect(stopped.events.at(-1)).toMatchObject({ type: 'abort', actor: 'system' });
    expect(() => applyMove(stopped, 'e2e4')).toThrow(/not accepting moves/i);
    expect(() => abortPractice({ ...timed, mode: 'Review' })).toThrow(/active Practice/i);
  });

  it('automatically draws recognized dead positions, but keeps resignation distinct', () => {
    const dead = createGame({ id: 'dead', initialFen: '8/8/8/8/8/8/4k3/7K w - - 0 1' });
    expect(dead.result?.reason).toBe('dead-position');

    let live = createGame({ id: 'resign' });
    live = applyMove(live, 'e2e4').record;
    const resigned = resign(live, 'b');
    expect(resigned.result).toMatchObject({ score: '1-0', reason: 'resignation', actor: 'b' });
  });

  it('awards a timeout draw when the non-flagging side has only a king, and stays conservative otherwise', () => {
    const opponentBareKing = createGame({ id: 'timeout-bare-king', initialFen: '4k3/8/8/8/8/8/R7/4K3 w - - 0 1' });
    expect(classifyTimeout(opponentBareKing, 'w')).toBe('draw');
    expect(recordTimeout(opponentBareKing, 'w').result).toMatchObject({ score: '1/2-1/2', reason: 'timeout' });

    const opponentRook = createGame({ id: 'timeout-rook', initialFen: '4k3/8/8/8/8/8/8/4K2r w - - 0 1' });
    expect(classifyTimeout(opponentRook, 'w')).toBe('pending');
    expect(recordTimeout(opponentRook, 'w').status).toBe('adjudication-pending');
  });

  it('does not award a timeout win when mating possibility is not proven', () => {
    const game = createGame({ id: 'timeout' });
    expect(classifyTimeout(game, 'w')).toBe('pending');
    const pending = recordTimeout(game, 'w');
    expect(pending.status).toBe('adjudication-pending');
    expect(pending.result).toBeUndefined();
    expect(pending.events.at(-1)?.type).toBe('timeout-pending');
    expect(() => applyMove(pending, 'e2e4')).toThrow(/not accepting moves/i);
  });

  it('does not auto-draw an unrecognized material position or award a timeout result without proof', () => {
    const twoKnights = createGame({ id: 'two-knights', initialFen: '4k3/8/8/8/8/8/3NN3/4K2n w - - 0 1' });
    expect(twoKnights.status).toBe('active');
    expect(twoKnights.result).toBeUndefined();
    expect(twoKnights.drawState.deadPositionDetected).toBe(false);
    expect(classifyTimeout(twoKnights, 'w')).toBe('pending');
  });

  it('persists timed moves as paused clock snapshots and requires a live monotonic clock to move', () => {
    const game = createGame({ id: 'timed-game', timeControl: { baseSeconds: 60, incrementSeconds: 2 } });
    expect(game.clock).toMatchObject({ type: 'fischer', whiteRemainingMs: 60_000, blackRemainingMs: 60_000, activeSide: 'w', paused: true });
    expect(Object.hasOwn(game.clock!, 'monotonicAnchorMs')).toBe(false);

    const liveClock = resumeClock(restoreClock(game.clock!), 10_000);
    const first = applyMove(game, 'e2e4', { clock: liveClock, monotonicNowMs: 15_000, committedAt: '2026-10-05T00:00:15.000Z' });
    expect(first.record.moveHistory).toHaveLength(1);
    expect(first.clock).toMatchObject({ activeSide: 'b', whiteRemainingMs: 57_000, blackRemainingMs: 60_000, paused: false });
    expect(first.record.clock).toMatchObject({ activeSide: 'b', whiteRemainingMs: 57_000, paused: true });
    expect(Object.hasOwn(first.record.clock!, 'monotonicAnchorMs')).toBe(false);
    expect(() => applyMove(first.record, 'e7e5')).toThrow(/running clock/i);

    const resumedBlackClock = resumeClock(restoreClock(first.record.clock!), 30_000);
    const second = applyMove(first.record, 'e7e5', { clock: resumedBlackClock, monotonicNowMs: 31_000 });
    expect(second.record.clock).toMatchObject({ activeSide: 'w', blackRemainingMs: 61_000, paused: true });
  });

  it('locks a timed game after flag fall when mating possibility needs adjudication', () => {
    const matingGame = createGame({ id: 'timed-mate', initialFen: '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1', timeControl: { baseSeconds: 1 } });
    const beforeFlag = startClock(restoreClock(matingGame.clock!), 'w', 0);
    const mate = applyMove(matingGame, 'f7g7', { clock: beforeFlag, monotonicNowMs: 999 });
    expect(mate.record.result).toMatchObject({ score: '1-0', reason: 'checkmate' });
    expect(mate.record.clock?.paused).toBe(true);

    const game = createGame({ id: 'timed-flag', timeControl: { baseSeconds: 1 } });
    const liveClock = startClock(restoreClock(game.clock!), 'w', 0);
    expect(() => applyMove(game, 'e2e4', { clock: liveClock, monotonicNowMs: 1_000 })).toThrow(/clock has expired/i);
    const pending = recordTimeout(game, 'w', '2026-10-05T00:00:01.000Z', { clock: liveClock, monotonicNowMs: 1_000 });
    expect(pending.status).toBe('adjudication-pending');
    expect(pending.clock).toMatchObject({ whiteRemainingMs: 0, activeSide: 'w', paused: true });
    expect(() => applyMove(pending, 'e2e4')).toThrow(/not accepting moves/i);

    const claimable = createGame({
      initialFen: '4k3/8/8/8/8/8/8/R3K3 w - - 100 50',
      timeControl: { baseSeconds: 1 },
    });
    const expired = startClock(restoreClock(claimable.clock!), 'w', 0);
    expect(() => claimDraw(claimable, { reason: 'fifty-move-rule', kind: 'current-position' }, 'w', '2026-10-05T00:00:01.000Z', { clock: expired, monotonicNowMs: 1_000 }))
      .toThrow(/clock has expired/i);
  });

  it('navigates imported/review lines without mutating move history', () => {
    let game = createGame({ id: 'review' });
    game = applyMove(game, 'e2e4').record;
    game = applyMove(game, 'e7e5').record;
    game = { ...game, mode: 'Review', status: 'reviewing' };
    const previous = navigateToPly(game, 1);
    expect(previous.moveHistory).toHaveLength(2);
    expect(previous.currentFen).toContain('4P3');
    expect(previous.cursorPly).toBe(1);
    expect(() => applyMove(previous, 'g1f3')).toThrow();
    expect(() => takeback(previous)).toThrow();
  });
});
