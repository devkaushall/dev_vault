import { Chess, type Color, type Move, type PieceSymbol, type Square } from 'chess.js';
import type { DrawClaimOption, DrawState, GameRecord, PositionSnapshot, UciMove } from './types';

export function createChess(fen: string): Chess {
  return new Chess(fen);
}

/**
 * A deliberately narrow dead-position detector delegated to chess.js.
 * `false` means "not recognized", not proof that mate is possible.
 */
export function isRecognizedDeadPosition(chess: Chess): boolean {
  return chess.isInsufficientMaterial();
}

/** FEN serialization retaining the standards-compatible EP target after a double pawn move. */
export function fenSnapshot(chess: Chess, enPassantTarget?: string): string {
  const fields = chess.fen({ forceEnpassantSquare: true }).split(' ');
  if (enPassantTarget !== undefined) fields[3] = enPassantTarget;
  return fields.join(' ');
}

export function enPassantTargetAfterMove(piece: PieceSymbol, from: Square, to: Square): string {
  if (piece !== 'p' || from[0] !== to[0]) return '-';
  const fromRank = Number(from[1]);
  const toRank = Number(to[1]);
  if (Math.abs(toRank - fromRank) !== 2) return '-';
  return `${from[0]}${(fromRank + toRank) / 2}`;
}

/** Derive serialized FEN at a history ply, preserving a non-capturable EP target. */
export function fenAtPly(record: GameRecord, ply = record.cursorPly): string {
  const chess = rebuildChess(record, ply);
  if (ply === 0) {
    const initialEp = record.initialPosition.fen.trim().split(' ')[3] ?? '-';
    return fenSnapshot(chess, initialEp);
  }
  const lastMove = record.moveHistory[ply - 1];
  const previous = new Chess(lastMove.beforeFen);
  const piece = previous.get(lastMove.from)?.type;
  return fenSnapshot(chess, piece ? enPassantTargetAfterMove(piece, lastMove.from, lastMove.to) : '-');
}

/**
 * FIDE repetition identity omits move counters and includes en-passant state only
 * when a legal en-passant capture is available. chess.js's internal repetition hash
 * includes the raw EP target, so this adapter intentionally computes the key itself.
 */
export function positionKey(chess: Chess): string {
  const fields = fenSnapshot(chess).split(' ');
  const epIsLegallyCapturable = chess.moves({ verbose: true }).some((move) => move.isEnPassant());
  return `${fields[0]} ${fields[1]} ${fields[2]} ${epIsLegallyCapturable ? fields[3] : '-'}`;
}

export function uciForMove(move: Pick<Move, 'from' | 'to' | 'promotion'>): string {
  return `${move.from}${move.to}${move.promotion ?? ''}`;
}

export function parseUci(uci: string): UciMove {
  const match = /^([a-h][1-8])([a-h][1-8])([qrbn])?$/.exec(uci.trim());
  if (!match) throw new Error(`Invalid UCI move: ${uci}`);
  return {
    from: match[1] as Square,
    to: match[2] as Square,
    ...(match[3] ? { promotion: match[3] as Exclude<PieceSymbol, 'p' | 'k'> } : {}),
  };
}

function getPrefixKeys(record: GameRecord, ply = record.cursorPly): string[] {
  return record.repetitionKeys.slice(0, Math.min(ply, record.repetitionKeys.length - 1) + 1);
}

function countKey(keys: string[], key: string): number {
  let count = 0;
  for (const candidate of keys) if (candidate === key) count++;
  return count;
}

function intendedDrawClaims(chess: Chess, prefixKeys: string[]): DrawClaimOption[] {
  const claims: DrawClaimOption[] = [];
  const currentHalfMoves = Number(fenSnapshot(chess).split(' ')[4]);
  const moves = chess.moves({ verbose: true });

  for (const move of moves) {
    const clone = new Chess(fenSnapshot(chess));
    clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const afterKey = positionKey(clone);
    const intendedUci = uciForMove(move);

    // FIDE Article 9.2 permits a claim before making a move that will create the
    // third occurrence. The move itself is not committed when the claim succeeds.
    if (countKey(prefixKeys, afterKey) >= 2) {
      claims.push({ reason: 'threefold-repetition', kind: 'intended-move', intendedUci, intendedSan: move.san });
    }

    // Article 9.3 permits the same for the 50-move rule. Checkmate on the
    // intended move takes precedence, so a mating move is never offered as a claim.
    const resetsClock = move.piece === 'p' || move.isCapture();
    if (!resetsClock && currentHalfMoves >= 99 && !clone.isCheckmate()) {
      claims.push({ reason: 'fifty-move-rule', kind: 'intended-move', intendedUci, intendedSan: move.san });
    }
  }
  return claims;
}

export function deriveDrawState(chess: Chess, record: GameRecord, ply = record.cursorPly): DrawState {
  const key = positionKey(chess);
  const keys = getPrefixKeys(record, ply);
  const halfMoves = Number(fenSnapshot(chess).split(' ')[4]);
  const repetitionCount = countKey(keys, key);
  const deadPositionDetected = isRecognizedDeadPosition(chess);
  return {
    repetitionCount,
    canClaimThreefoldNow: repetitionCount >= 3,
    canClaimFiftyMovesNow: halfMoves >= 100,
    intendedClaims: intendedDrawClaims(chess, keys),
    automaticFivefold: repetitionCount >= 5,
    automaticSeventyFiveMoves: halfMoves >= 150,
    deadPositionDetected,
  };
}

export function derivePosition(record: GameRecord, ply = record.cursorPly): PositionSnapshot {
  if (!Number.isInteger(ply) || ply < 0 || ply > record.moveHistory.length) {
    throw new RangeError(`Ply ${ply} is outside this game's move history`);
  }
  const chess = new Chess(record.initialPosition.fen);
  for (const entry of record.moveHistory.slice(0, ply)) {
    chess.move({ from: entry.from, to: entry.to, ...(entry.promotion ? { promotion: entry.promotion } : {}) });
  }
  const fen = fenAtPly(record, ply);
  const legalMoves = chess.moves({ verbose: true }).map((move) => ({
    from: move.from,
    to: move.to,
    san: move.san,
    uci: uciForMove(move),
    ...(move.promotion ? { promotion: move.promotion } : {}),
    flags: move.flags,
  }));
  const fenFields = fen.split(' ');
  return {
    fen,
    positionKey: positionKey(chess),
    turn: chess.turn(),
    board: chess.board(),
    inCheck: chess.isCheck(),
    checkmate: chess.isCheckmate(),
    stalemate: chess.isStalemate(),
    legalMoves,
    drawState: deriveDrawState(chess, record, ply),
    result: record.result,
    ply,
    halfMoves: Number(fenFields[4]),
    fullMoves: Number(fenFields[5]),
  };
}

export function rebuildChess(record: GameRecord, ply = record.cursorPly): Chess {
  const chess = new Chess(record.initialPosition.fen);
  for (const entry of record.moveHistory.slice(0, ply)) {
    const move = chess.move({ from: entry.from, to: entry.to, ...(entry.promotion ? { promotion: entry.promotion } : {}) });
    if (move.san !== entry.san) throw new Error(`Corrupt move history at ply ${entry.ply}: stored ${entry.san}, replayed ${move.san}`);
  }
  return chess;
}

export function currentPrefixKeys(record: GameRecord, ply = record.cursorPly): string[] {
  return getPrefixKeys(record, ply);
}

export function activeColor(chess: Chess): Color {
  return chess.turn();
}
