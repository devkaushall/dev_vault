import { Chess, DEFAULT_POSITION, type Color, type PieceSymbol, type Square } from 'chess.js';
import { commitClockMove, createClock, persistClockSnapshot, pauseClock, snapshotClock, type ClockState } from '../clock/ChessClock';
import {
  currentPrefixKeys,
  deriveDrawState,
  enPassantTargetAfterMove,
  fenAtPly,
  fenSnapshot,
  isRecognizedDeadPosition,
  parseUci,
  positionKey,
  rebuildChess,
  uciForMove,
} from './position';
import {
  DEFAULT_FEN,
  FIDE_LAWS_SOURCE,
  RULESET_ID,
  type DrawClaimOption,
  type DrawState,
  type GameMode,
  type GameRecord,
  type GameResult,
  type MoveRecord,
  type MoveSource,
  type NewGameOptions,
  type SavedVariation,
  type UciMove,
} from './types';

const RULESET = {
  id: RULESET_ID,
  variant: 'standard',
  policyVersion: 'FIDE-2023',
  sourceUrl: FIDE_LAWS_SOURCE,
  verifiedAt: '2026-10-05',
  drawPolicy: 'threefold-and-fifty-move-claims; fivefold-and-seventy-five-move-automatic',
} as const;

function defaultPlayers(mode: GameMode): GameRecord['players'] {
  if (mode === 'Challenge' || mode === 'CoachedPractice') {
    return {
      white: { kind: 'human', id: 'local-human', displayName: 'You' },
      black: { kind: 'engine', id: 'engine-unavailable', displayName: 'Engine (not installed)' },
    };
  }
  return {
    white: { kind: 'human', id: 'local-human', displayName: 'White' },
    black: { kind: 'human', id: 'local-human-black', displayName: 'Black' },
  };
}

function blankDrawState(): DrawState {
  return {
    repetitionCount: 1,
    canClaimThreefoldNow: false,
    canClaimFiftyMovesNow: false,
    intendedClaims: [],
    automaticFivefold: false,
    automaticSeventyFiveMoves: false,
    deadPositionDetected: false,
  };
}

function resultForAutomaticPosition(chess: Chess, repetitionCount: number): GameResult | undefined {
  // Checkmate takes precedence over the 75-move automatic draw.
  if (chess.isCheckmate()) return { score: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'checkmate', actor: 'system' };
  if (chess.isStalemate()) return { score: '1/2-1/2', reason: 'stalemate', actor: 'system' };
  // Only recognized dead positions are auto-drawn; unrecognized positions are not assumed live.
  if (isRecognizedDeadPosition(chess)) return { score: '1/2-1/2', reason: 'dead-position', actor: 'system' };
  if (repetitionCount >= 5) return { score: '1/2-1/2', reason: 'fivefold-repetition', actor: 'system' };
  if (Number(fenSnapshot(chess).split(' ')[4]) >= 150) return { score: '1/2-1/2', reason: 'seventy-five-move-rule', actor: 'system' };
  return undefined;
}

function countIn(values: string[], key: string): number {
  let count = 0;
  for (const value of values) if (value === key) count++;
  return count;
}

type ClockTransitionOptions = { clock?: ClockState; monotonicNowMs?: number };

function clockSnapshotForTransition(record: GameRecord, options: ClockTransitionOptions = {}, allowFlaggedClock = false) {
  if (!record.clock) {
    if (options.clock) throw new Error('A clock cannot be attached implicitly to an unclocked game.');
    return undefined;
  }
  if (!options.clock || options.monotonicNowMs === undefined) throw new Error('A current clock snapshot is required to update a timed game.');
  const sideToMove = rebuildChess(record, record.cursorPly).turn();
  if (options.clock.activeSide !== sideToMove
    || options.clock.baseMs !== record.clock.baseMs
    || options.clock.incrementMs !== record.clock.incrementMs) {
    throw new Error('The live clock does not match the saved game clock.');
  }
  if (snapshotClock(options.clock, options.monotonicNowMs).flaggedSide && !allowFlaggedClock) {
    throw new Error('The clock has expired; record the timeout before ending the game.');
  }
  return persistClockSnapshot(options.clock, options.monotonicNowMs);
}

export function createGame(options: NewGameOptions = {}): GameRecord {
  const fen = options.initialFen?.trim() || DEFAULT_FEN;
  if (fen.length > 256) throw new Error('FEN is too long (maximum 256 characters).');
  const chess = new Chess(fen);
  const now = options.now ?? new Date().toISOString();
  const mode = options.mode ?? 'Practice';
  const canonicalInitialFen = fenSnapshot(chess, fen.trim().split(' ')[3] ?? '-');
  const initialKey = positionKey(chess);
  const record: GameRecord = {
    id: options.id ?? crypto.randomUUID(),
    schemaVersion: 2,
    createdAt: now,
    updatedAt: now,
    mode,
    ruleset: { ...RULESET },
    initialPosition: { fen: canonicalInitialFen, kind: fen === DEFAULT_POSITION ? 'standard' : 'custom' },
    moveHistory: [],
    cursorPly: 0,
    currentFen: canonicalInitialFen,
    repetitionKeys: [initialKey],
    players: { ...defaultPlayers(mode), ...options.players },
    status: mode === 'Review' ? 'reviewing' : 'active',
    drawState: blankDrawState(),
    events: [],
    variations: [],
  };
  const result = resultForAutomaticPosition(chess, 1);
  if (result) {
    record.result = result;
    record.status = 'finished';
  }
  if (options.timeControl && record.status === 'active') {
    const initialClock = createClock(options.timeControl.baseSeconds, options.timeControl.incrementSeconds ?? 0);
    record.clock = persistClockSnapshot({ ...initialClock, activeSide: chess.turn() }, 0);
  }
  record.drawState = deriveDrawState(chess, record, 0);
  return record;
}

export type ApplyMoveOptions = {
  source?: MoveSource;
  committedAt?: string;
  /** Required for clocked records; supplied by the live monotonic clock owner. */
  clock?: ClockState;
  monotonicNowMs?: number;
};

export function applyMove(record: GameRecord, move: UciMove | string, options: ApplyMoveOptions = {}): { record: GameRecord; move: MoveRecord; clock?: ClockState } {
  if (record.status !== 'active') throw new Error('This game is not accepting moves.');
  if (record.mode === 'Review') throw new Error('Review games are read-only; create a retry variation instead.');
  if (record.cursorPly !== record.moveHistory.length) throw new Error('Move from the current end of the line or branch first.');
  if (record.result) throw new Error('This game has already finished.');

  const intent = typeof move === 'string' ? parseUci(move) : move;
  const chess = rebuildChess(record, record.cursorPly);
  const mover = chess.turn();
  let clockForMove: ClockState | undefined;
  let monotonicNowMs: number | undefined;
  if (record.clock) {
    if (!options.clock || options.clock.paused || options.clock.activeSide !== mover) {
      throw new Error('A running clock for the side to move is required for a timed-game move.');
    }
    if (options.clock.baseMs !== record.clock.baseMs || options.clock.incrementMs !== record.clock.incrementMs || record.clock.activeSide !== mover) {
      throw new Error('The live clock does not match the saved game clock.');
    }
    if (options.monotonicNowMs === undefined) throw new Error('A monotonic timestamp is required for a timed-game move.');
    monotonicNowMs = options.monotonicNowMs;
    if (snapshotClock(options.clock, monotonicNowMs).flaggedSide) throw new Error('The clock has expired; record the timeout before making another move.');
    clockForMove = options.clock;
  } else if (options.clock) {
    throw new Error('A clock cannot be attached implicitly to an unclocked game.');
  }
  const beforeFen = fenAtPly(record, record.cursorPly);
  const beforeKey = positionKey(chess);
  const committed = chess.move({
    from: intent.from,
    to: intent.to,
    ...(intent.promotion ? { promotion: intent.promotion } : {}),
  });
  const afterFen = fenSnapshot(chess, enPassantTargetAfterMove(committed.piece, committed.from, committed.to));
  const timedMove = clockForMove ? commitClockMove(clockForMove, mover, monotonicNowMs!) : undefined;
  if (timedMove?.flaggedSide) throw new Error('The clock expired before this move could be committed.');
  let nextClock = timedMove?.clock;
  const afterKey = positionKey(chess);
  const repetitionKeys = [...currentPrefixKeys(record), afterKey];
  const repetitionCount = countIn(repetitionKeys, afterKey);
  const committedAt = options.committedAt ?? new Date().toISOString();
  const moveRecord: MoveRecord = {
    ply: record.cursorPly + 1,
    from: committed.from,
    to: committed.to,
    ...(committed.promotion ? { promotion: committed.promotion as Exclude<PieceSymbol, 'p' | 'k'> } : {}),
    uci: uciForMove(committed),
    san: committed.san,
    beforeFen,
    afterFen,
    beforeKey,
    afterKey,
    source: options.source ?? 'human',
    committedAt,
  };
  const next: GameRecord = {
    ...record,
    updatedAt: committedAt,
    moveHistory: [...record.moveHistory, moveRecord],
    cursorPly: record.cursorPly + 1,
    currentFen: afterFen,
    repetitionKeys,
    drawState: blankDrawState(),
  };
  const result = resultForAutomaticPosition(chess, repetitionCount);
  if (result) {
    next.result = result;
    next.status = 'finished';
    if (nextClock && monotonicNowMs !== undefined) nextClock = pauseClock(nextClock, monotonicNowMs);
  }
  if (nextClock && monotonicNowMs !== undefined) next.clock = persistClockSnapshot(nextClock, monotonicNowMs);
  next.drawState = deriveDrawState(chess, next, next.cursorPly);
  return { record: next, move: moveRecord, ...(nextClock ? { clock: nextClock } : {}) };
}

function addVariation(record: GameRecord, moves: MoveRecord[], fromPly: number, label: string, at: string): SavedVariation[] {
  if (!moves.length) return record.variations;
  const variation: SavedVariation = {
    id: crypto.randomUUID(),
    fromPly,
    uciMoves: moves.map((move) => move.uci),
    createdAt: at,
    label,
  };
  return [...record.variations, variation];
}

/** Takeback is a local-game action; the removed line is retained as a variation. */
export function takeback(record: GameRecord, at = new Date().toISOString()): GameRecord {
  if (record.mode === 'Review') throw new Error('Original review history is immutable.');
  if (record.clock) throw new Error('Takebacks are disabled for clocked games so saved time cannot be restored unfairly.');
  if (record.cursorPly < 1) return record;
  const removed = record.moveHistory.slice(record.cursorPly - 1);
  const moveHistory = record.moveHistory.slice(0, record.cursorPly - 1);
  const repetitionKeys = record.repetitionKeys.slice(0, moveHistory.length + 1);
  const cursorPly = moveHistory.length;
  const chess = rebuildChess({ ...record, moveHistory, cursorPly }, cursorPly);
  const next: GameRecord = {
    ...record,
    updatedAt: at,
    moveHistory,
    cursorPly,
    currentFen: fenAtPly({ ...record, moveHistory, cursorPly }, cursorPly),
    repetitionKeys,
    status: 'active',
    result: undefined,
    events: [...record.events, { type: 'takeback', at, detail: `Returned to ply ${cursorPly}.` }],
    variations: addVariation(record, removed, cursorPly, 'Line saved before takeback', at),
    drawState: blankDrawState(),
  };
  next.drawState = deriveDrawState(chess, next, cursorPly);
  return next;
}

/** Archive the played tail and create a new editable line from a navigated position. */
export function branchFromCursor(record: GameRecord, at = new Date().toISOString()): GameRecord {
  if (record.mode === 'Review') throw new Error('Original review history is immutable.');
  if (record.clock) throw new Error('Branching is disabled for clocked games so clock history cannot be rewritten.');
  if (record.cursorPly === record.moveHistory.length) return record;
  const archived = record.moveHistory.slice(record.cursorPly);
  const moveHistory = record.moveHistory.slice(0, record.cursorPly);
  const repetitionKeys = record.repetitionKeys.slice(0, record.cursorPly + 1);
  const chess = rebuildChess({ ...record, moveHistory, cursorPly: record.cursorPly }, record.cursorPly);
  const next: GameRecord = {
    ...record,
    updatedAt: at,
    moveHistory,
    repetitionKeys,
    currentFen: fenAtPly(record, record.cursorPly),
    status: 'active',
    result: undefined,
    events: [...record.events, { type: 'takeback', at, detail: `Created an analysis branch at ply ${record.cursorPly}.` }],
    variations: addVariation(record, archived, record.cursorPly, 'Alternate line before branch', at),
    drawState: blankDrawState(),
  };
  const result = resultForAutomaticPosition(chess, countIn(repetitionKeys, positionKey(chess)));
  if (result) {
    next.result = result;
    next.status = 'finished';
  }
  next.drawState = deriveDrawState(chess, next, next.cursorPly);
  return next;
}

/** Reapply the most recently archived line from the current branch point. */
export function redoTakeback(record: GameRecord, at = new Date().toISOString()): GameRecord {
  if (record.mode === 'Review') throw new Error('Review navigation is not a takeback.');
  if (record.clock) throw new Error('Redo is disabled for clocked games so clock history cannot be restored unfairly.');
  const variation = [...record.variations].reverse().find((item) => item.fromPly === record.cursorPly);
  if (!variation) return record;
  let next = record;
  for (const uci of variation.uciMoves) {
    if (next.status !== 'active') break;
    next = applyMove(next, uci, { source: 'human', committedAt: at }).record;
  }
  return { ...next, updatedAt: at, variations: next.variations.filter((item) => item.id !== variation.id) };
}

export function navigateToPly(record: GameRecord, ply: number): GameRecord {
  if (record.clock) throw new Error('Move navigation is disabled for clocked games.');
  if (!Number.isInteger(ply) || ply < 0 || ply > record.moveHistory.length) throw new RangeError('Move index is out of range.');
  const chess = rebuildChess(record, ply);
  const next = { ...record, cursorPly: ply, currentFen: fenAtPly(record, ply) };
  next.drawState = deriveDrawState(chess, next, ply);
  return next;
}

export function claimDraw(record: GameRecord, claim: DrawClaimOption, claimant?: Color, at = new Date().toISOString(), clockOptions: ClockTransitionOptions = {}): GameRecord {
  if (record.status !== 'active') throw new Error('Draw claims are only available in an active game.');
  const chess = rebuildChess(record, record.cursorPly);
  if (claimant && claimant !== chess.turn()) throw new Error('Only the side to move may claim a draw.');
  const keys = currentPrefixKeys(record);
  const currentKey = positionKey(chess);
  const repetitionCount = countIn(keys, currentKey);
  let valid = false;
  if (claim.reason === 'threefold-repetition') {
    if (claim.kind === 'current-position') valid = repetitionCount >= 3;
    else if (claim.intendedUci) {
      const intent = parseUci(claim.intendedUci);
      const clone = new Chess(fenSnapshot(chess));
      const move = clone.move({ from: intent.from, to: intent.to, ...(intent.promotion ? { promotion: intent.promotion } : {}) });
      const intendedKey = positionKey(clone);
      valid = countIn(keys, intendedKey) >= 2 && (!claim.intendedSan || move.san === claim.intendedSan);
    }
  } else {
    const halfMoves = Number(fenSnapshot(chess).split(' ')[4]);
    if (claim.kind === 'current-position') valid = halfMoves >= 100;
    else if (claim.intendedUci) {
      const intent = parseUci(claim.intendedUci);
      const clone = new Chess(fenSnapshot(chess));
      const move = clone.move({ from: intent.from, to: intent.to, ...(intent.promotion ? { promotion: intent.promotion } : {}) });
      const resetsClock = move.piece === 'p' || move.isCapture();
      valid = !resetsClock && halfMoves >= 99 && !clone.isCheckmate() && (!claim.intendedSan || move.san === claim.intendedSan);
    }
  }
  if (!valid) throw new Error('The requested draw claim is not valid in the current position.');
  const result: GameResult = {
    score: '1/2-1/2',
    reason: claim.reason === 'threefold-repetition' ? 'threefold-claim' : 'fifty-move-claim',
    actor: claimant,
    detail: claim.kind === 'intended-move' ? `Claim validated before ${claim.intendedSan ?? claim.intendedUci}.` : 'Claim validated in the current position.',
  };
  const clock = clockSnapshotForTransition(record, clockOptions);
  return {
    ...record,
    ...(clock ? { clock } : {}),
    updatedAt: at,
    status: 'finished',
    result,
    events: [...record.events, { type: 'draw-claim', at, actor: claimant, detail: result.detail }],
  };
}

export function agreeDraw(record: GameRecord, at = new Date().toISOString(), clockOptions: ClockTransitionOptions = {}): GameRecord {
  if (record.status !== 'active') throw new Error('This game is not active.');
  const clock = clockSnapshotForTransition(record, clockOptions);
  return {
    ...record,
    ...(clock ? { clock } : {}),
    updatedAt: at,
    status: 'finished',
    result: { score: '1/2-1/2', reason: 'draw-agreement', actor: 'system' },
    events: [...record.events, { type: 'draw-agreement', at }],
  };
}

/** Stop a local Practice record without awarding a chess result or deleting its move history. */
export function abortPractice(record: GameRecord, at = new Date().toISOString(), clockOptions: ClockTransitionOptions = {}): GameRecord {
  if (record.mode !== 'Practice' || record.status !== 'active') throw new Error('Only an active Practice game can be stopped without a result.');
  const clock = clockSnapshotForTransition(record, clockOptions);
  return {
    ...record,
    ...(clock ? { clock } : {}),
    updatedAt: at,
    status: 'aborted',
    result: undefined,
    events: [...record.events, { type: 'abort', at, actor: 'system', detail: 'Local Practice stopped without assigning a chess result.' }],
  };
}

export function resign(record: GameRecord, side: Color, at = new Date().toISOString(), clockOptions: ClockTransitionOptions = {}): GameRecord {
  if (record.status !== 'active') throw new Error('This game is not active.');
  const clock = clockSnapshotForTransition(record, clockOptions);
  const chess = rebuildChess(record, record.cursorPly);
  // FIDE Article 5.2.2: a detected dead position turns resignation into a draw.
  const result: GameResult = isRecognizedDeadPosition(chess)
    ? { score: '1/2-1/2', reason: 'dead-position', actor: side, detail: 'Resignation is a draw because this adapter detects a dead position.' }
    : { score: side === 'w' ? '0-1' : '1-0', reason: 'resignation', actor: side };
  return {
    ...record,
    ...(clock ? { clock } : {}),
    updatedAt: at,
    status: 'finished',
    result,
    events: [...record.events, { type: 'resignation', at, actor: side }],
  };
}

export type TimeoutAdjudication = 'draw' | 'loss' | 'pending';

/**
 * Conservative timeout adjudication. The installed rules library recognizes a
 * subset of dead positions; for other material configurations this returns
 * pending rather than award a potentially false win.
 */
export function classifyTimeout(record: GameRecord, flaggingSide: Color): TimeoutAdjudication {
  const chess = rebuildChess(record, record.cursorPly);
  if (isRecognizedDeadPosition(chess)) return 'draw';
  const nonKingPieces = chess.board().flat().filter((piece) => piece && piece.type !== 'k');
  const flaggingPieces = nonKingPieces.filter((piece) => piece?.color === flaggingSide);
  const opponentPieces = nonKingPieces.filter((piece) => piece?.color !== flaggingSide);
  if (opponentPieces.length === 0 && flaggingPieces.length > 0) return 'draw';
  return 'pending';
}

export function recordTimeout(record: GameRecord, flaggingSide: Color, at = new Date().toISOString(), clockOptions: ClockTransitionOptions = {}): GameRecord {
  if (record.status !== 'active') throw new Error('This game is not active.');
  if (record.clock) {
    if (!clockOptions.clock || clockOptions.monotonicNowMs === undefined) throw new Error('A flagged live clock is required to record a timed-game timeout.');
    const display = snapshotClock(clockOptions.clock, clockOptions.monotonicNowMs);
    if (clockOptions.clock.activeSide !== flaggingSide || display.flaggedSide !== flaggingSide) {
      throw new Error('The requested timeout does not match a clock that has actually flagged.');
    }
  }
  const clock = clockSnapshotForTransition(record, clockOptions, true);
  const outcome = classifyTimeout(record, flaggingSide);
  if (outcome === 'draw') {
    return {
      ...record,
      ...(clock ? { clock } : {}),
      updatedAt: at,
      status: 'finished',
      result: { score: '1/2-1/2', reason: 'timeout', actor: 'system', detail: 'Flag fall; opponent cannot possibly mate with the detected material.' },
    };
  }
  if (outcome === 'loss') {
    return {
      ...record,
      ...(clock ? { clock } : {}),
      updatedAt: at,
      status: 'finished',
      result: { score: flaggingSide === 'w' ? '0-1' : '1-0', reason: 'timeout', actor: 'system' },
    };
  }
  return {
    ...record,
    ...(clock ? { clock } : {}),
    updatedAt: at,
    status: 'adjudication-pending',
    events: [...record.events, { type: 'timeout-pending', at, actor: flaggingSide, detail: 'Flag fell; official result requires a complete mating-possibility adjudicator. Further moves are disabled.' }],
  };
}

export function currentPosition(record: GameRecord) {
  return rebuildChess(record, record.cursorPly);
}

export function moveUci(record: GameRecord, move: { from: Square; to: Square; promotion?: PieceSymbol }): string {
  const chess = rebuildChess(record, record.cursorPly);
  const committed = chess.move(move);
  return uciForMove(committed);
}

export function positionAfterUci(record: GameRecord, uci: string): string {
  const move = parseUci(uci);
  const chess = rebuildChess(record, record.cursorPly);
  chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  return positionKey(chess);
}
