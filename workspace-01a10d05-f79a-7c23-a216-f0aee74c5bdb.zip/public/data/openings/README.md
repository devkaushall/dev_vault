# Opening dataset provenance

Files `a.tsv` through `e.tsv` are copied from `lichess-org/chess-openings` commit `5a13018164f6bd88f48b3dc31a8e2a39f31a060a`, imported on 2026-10-05. The project releases the curated opening-name collection under CC0-1.0. See `manifest.json` and https://github.com/lichess-org/chess-openings.

The data supplies ECO/name/move-sequence labels only. It is not an engine evaluation or strategy authority. Transpositions can map multiple entries to one position.
