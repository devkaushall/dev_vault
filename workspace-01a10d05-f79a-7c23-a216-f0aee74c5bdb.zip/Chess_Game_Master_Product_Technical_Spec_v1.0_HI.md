# Chess Game Master — Product & Technical Specification v1.0

**Version:** 1.0  
**स्थिति:** implementation specification; अभी कोई code/implementation शुरू नहीं करना है  
**तैयारी की तारीख:** 5 अक्टूबर 2026  
**मुख्य स्रोत:** [Chess Game Master — Master Research](./Chess_Game_Master_Research_HI.md) और [Chess Game Master — Chess Atlas](./Chess_Game_Master_Chess_Atlas_HI.md)

> **उद्देश्य:** यह document आगे के AI coding agent के लिए product contract है। इसमें product decisions, mode behavior, chess rules, intelligence boundaries, local-first architecture, testing, licensing gates और release acceptance criteria तय हैं। यह source code नहीं है।

## भाषा और requirement शब्द

- **ज़रूरी (MUST):** V1 release से पहले लागू और test होना अनिवार्य।
- **चाहिए (SHOULD):** V1 में लागू करें; छूटने पर documented reason और owner approval चाहिए।
- **हो सकता है (MAY):** वैकल्पिक; V1 में शामिल करना जरूरी नहीं।
- **[स्रोत-तथ्य]:** दोनों research documents/उनके primary references में सत्यापित बात।
- **[उत्पाद-निर्णय]:** इस v1.0 specification में चुना गया product behavior।
- **[सिफारिश]:** research से निकला implementation/product प्रस्ताव; chess rule नहीं।
- **[सीमा]:** ऐसा निष्कर्ष जिसे system को दावा नहीं करना चाहिए।

---

# 1. Product

## 1.1 Product purpose

**Chess Game Master का काम खिलाड़ी को यह समझाना है कि board पर क्या हो रहा है, कौन-से plans या threats सम्भव हैं, और अगली बार उस pattern को कैसे पहचाना जाए।** यह केवल engine की best move बताने वाला move-advisor नहीं होगा।

V1 का learning loop:

**सीखें → position में idea पहचानें → स्वयं चाल आज़माएँ → engine/curated feedback पाएँ → game के बाद मुख्य निर्णय दोबारा देखें।**

## 1.2 Target user

**[उत्पाद-निर्णय; research में audience final नहीं थी]** प्राथमिक उपयोगकर्ता हिन्दी-प्रथम beginner से club-level खिलाड़ी है:

- basic chess rules सीख रहा है या हाल में सीख चुका है;
- engine notation/evaluation को सीधे समझना कठिन पाता है;
- openings के नाम और plans पहचानना चाहता है, पर भारी theory याद नहीं करना चाहता;
- tactics, defence और endgames को वास्तविक game positions से जोड़कर सीखना चाहता है;
- फोन/सामान्य laptop पर, सम्भवतः अस्थिर internet के साथ खेलता है।

अनुभवी खिलाड़ी detailed/advanced layer में engine line, notation, candidate plans और analysis settings खोल सकेगा। Hindi default होगी; standard SAN/PGN/UCI notation और प्रचलित English chess terms बनाए रखे जाएँगे। यह product intermediate/advanced खिलाड़ी को “engine से बेहतर” होने का दावा नहीं करेगा।

## 1.3 Core problem

अधिकांश chess tools चाल, evaluation, opening label या accuracy score दिखा सकते हैं; खिलाड़ी को फिर भी यह समझना पड़ता है कि:

- पिछली चाल ने क्या बदला;
- कौन-सी चाल वास्तव में threat है और कौन-सी सिर्फ सम्भावना;
- pawn structure से कौन-सी plan निकलती है;
- tactical pattern कैसे काम करता है;
- engine की line और इंसान की सम्भावित योजना में क्या अंतर है;
- हार/ड्रॉ के बाद अगली बार क्या अभ्यास करना चाहिए।

Chess Game Master इन चीज़ों को board facts, legal variations, engine analysis और curated chess knowledge के सहारे समझाएगा—human intent का अनुमान fact बनाकर नहीं।

## 1.4 Product philosophy और guardrails

1. **Understand first, best-move second.** Best move दिखे तो “क्यों” और “किस line में” साथ दिखाएँ।
2. **Evidence before explanation.** हर chess claim का स्रोत Game Facts, Engine Facts, versioned opening/pattern data या curated lesson में होना चाहिए।
3. **Position-dependent guidance.** Dictionary definition अकेले न दिखाएँ; बताएं यह concept अभी क्यों relevant है।
4. **मानव मंशा अज्ञात है।** “likely idea”, “possible threat”, “candidate plan”, “typical plan in this structure”, “engine-supported continuation”, “tactical possibility” और “confidence” जैसे शब्द इस्तेमाल करें। “उसने यही सोचा” न कहें।
5. **Engine score सत्य नहीं, analysis signal है।** Search budget, engine version और perspective साथ रखें।
6. **Opening name, popularity और engine strength अलग signals हैं।** Popular move अपने-आप best move नहीं।
7. **No forced label.** Evidence अपर्याप्त हो तो “अभी पहचाना नहीं गया” कहें।
8. **Fair play.** V1 human competitive play नहीं देता; भविष्य में भी live human game के दौरान engine, hints या move suggestions नहीं।
9. **Local-first.** V1 में login/backend के बिना सीखना/खेलना/अपने games save करना सम्भव हो।
10. **No false skill score.** Accuracy %, bot setting या puzzle rating को verified human Elo/overall chess strength न कहें।

## 1.5 V1 product decisions और research में खुले बिंदुओं का समाधान

| विषय | V1 का चुना हुआ आधार | स्रोत/सीमा |
|---|---|---|
| Platform | Responsive web app + installable PWA | Master Research §2, §11; recommendation |
| Audience | Hindi-first beginner–club range; advanced detail optional | Product assumption; audience पहले तय नहीं थी |
| Game type | Solo/local: user vs engine, learn, practice, review, puzzles | Human matchmaking V1 में नहीं |
| Rules | Standard chess; FIDE claim-based threefold/50-move semantics; automatic rules अलग | Master Research §3; implementation से पहले FIDE edition recheck |
| Opening lookup | Bundled local Lichess CC0 opening-name dataset; no required external API | Master Research §8; API auth/quota unverified |
| Engine | Stockfish 19 WebAssembly, dedicated Worker, UCI adapter—**GPLv3 clearance gate के बाद** | Master Research §§7, 10; license unresolved business choice |
| Explanation | V1 में deterministic templates/curated content; general LLM coach नहीं | Master Research §14; hallucination risk |
| Human-vs-human | V1 में नहीं; post-game import/review केवल game finished होने पर | Master Research §§5, 11, 13 |
| Rating/accuracy | No public Elo/rating; no single accuracy % as skill judgement | Master Research §§5, 7; policy |
| Opening completeness | Major families + common minor/offbeat taxonomy; no promise to enumerate every line | Chess Atlas §1; opening tree/transpositions |

**License decision gate:** इस spec का build baseline यह मानता है कि V1 को GPLv3-compatible तरीके से वितरित किया जा सकता है। यदि product owner GPLv3 obligations स्वीकार नहीं करता, तो coding agent Stockfish को bundle न करे, अलग Worker में छिपाकर license risk को bypass न करे और कोई engine silently substitute न करे। यह launch blocker होगा; engine choice पर written approval चाहिए।

## 1.6 Success signals (product recommendation)

- **Correctness gate:** legal moves, game outcomes and every shown PV pass rules/integration tests; no false game-result adjudication.
- **Learning outcome:** moderated user tests ask a player to explain why a move/plan matters and to retry a related position; measure understanding/transfer, not only button clicks.
- **Review usefulness:** track whether users open a key moment, inspect a line, retry it or practice a linked theme; treat this as engagement signal, not chess strength.
- **Recognition quality:** audit opening/tactic/structure/endgame false positives against curated position sets; report candidate vs confirmed precision separately.
- **Fair play/privacy:** zero in-app engine/hint outputs in any future live-human mode; zero unconsented remote game-data uploads in V1.
- **Not success metrics:** public Elo, accuracy percentage, number of games played, or “time in app” alone. These may be misleading for a learning tool.

## 1.7 मुख्य user journeys

### Journey A — पहली बार सीखना
1. Home पर “सीखना शुरू करें” चुनें।
2. User अपना स्तर चुने: `बिल्कुल नया`, `मूल चालें आती हैं`, `पहले खेल चुका हूँ`; यह lesson order बदले, strength rating नहीं।
3. छोटे lesson में board पर चाल चलकर rule/idea सीखे।
4. Hint ladder से संकेत पाए; उत्तर देने के बाद “क्या हुआ / क्यों मायने रखता है / अगली बार कैसे पहचानें” पढ़े।
5. Completion और प्रयास local progress में save हों।

### Journey B — Engine के विरुद्ध खेल
1. Colour, approximate difficulty और optional base time/increment चुनें।
2. `Challenge` या `Coached Practice` चुनें।
3. Challenge में analysis/hints hidden; Coached mode में user opt-in hints/takeback पाए और game को unranked practice label मिले।
4. Game खत्म होने पर result reason दिखे और “Review this game” CTA हो।
5. Game, moves, time control, engine/version/settings और result local store हों।

### Journey C — पहले से खेला game समझना
1. Saved game चुनें या PGN import करें।
2. Parser errors/unsupported tags स्पष्ट दिखें; malformed data को silently repair न करें।
3. Self-review prompt के बाद engine analysis शुरू करें।
4. पहले 2–5 सबसे उपयोगी moments दिखें; पूरी move list/analysis optional हो।
5. Move चुनने पर board, played move, candidate move, short reason, concept, legal line और retry उपलब्ध हों।
6. Original game immutable रहे; retry variation अलग analysis branch बने।

### Journey D — Puzzle और theme अभ्यास
1. Theme/difficulty या “मेरा अभ्यास” चुनें।
2. Puzzle का side-to-move, task और आवश्यक board cues दिखें; solution/PV hidden रहे।
3. User चाल आज़माए; hint माँग सकता है।
4. गलत चाल attempt में दर्ज हो; reset नया attempt हो।
5. सही/छूटी line और concept explanation दिखे; progress local save हो।

### Journey E — Opening पहचानना
1. Training prompt में opening position या move sequence मिले।
2. User family/opening/variation चुने, या typical plan/next break पहचाने।
3. उत्तर से पहले full name, best move, engine line या variation tree न खुले।
4. उत्तर के बाद name/ECO, defining sequence, transposition note, structure और typical ideas दिखें—यदि data supported हो।
5. Opening session और hints-used progress में save हों।

### Journey F — Offline वापसी
1. App पहली बार online load/install हो।
2. Static app shell, selected engine asset, opening index और filtered puzzle subset cache हों।
3. बाद में offline user saved games, engine-vs-user, local lessons/puzzles और review चला सके।
4. Network-only stats/import source unavailable हो तो graceful offline state; board/move input प्रभावित न हो।

---

# 2. Application modes

## 2.1 Mode policy matrix

| Mode | Engine | Hints | Takebacks | क्या छिपा रहेगा | End/save |
|---|---|---|---|---|---|
| **Learn** | Lesson-specific; raw eval default hidden | Progressive, allowed | Lesson exercise में unlimited retry; history मिटाने की बजाय attempts record | अगली lesson answer/advanced line जब तक माँगी न जाए | Lesson complete/exit; progress, attempts, lesson version save |
| **Practice** | User-initiated local analysis; optional | On-demand; no forced suggestions | Unlimited undo/redo/variation | Default में eval/PV; user “Analyze” से खोलता है | User exit/save position; named positions/variations opt-in save |
| **Play vs Engine — Challenge** | Engine opponent only | In-game coach off | Default off; setup में casual takeback toggle हो सकता है, तब mode “assisted practice” बनेगा | Eval, PV, opening explorer, tactical hints | Mate/draw/resign/timeout; game + result + engine metadata save |
| **Play vs Engine — Coached Practice** | Engine opponent + optional analysis hint | Explicitly allowed, request-based | Allowed; takeback/undo logs रहेगा | Raw PV default hidden; advanced view user खोलता है | End same rules; game unranked/coached marker सहित save |
| **Review Game** | Finished/imported game पर allowed | Allowed | Original game पर नहीं; branch/retry copy पर reset/undo | Human intent claim; unsupported plan label | Review complete/exit; analysis, retry attempts, annotations save |
| **Puzzle/Training** | Curated answer validation; optional engine validation internal | Progressive hint allowed | Current attempt में erase-takeback नहीं; Reset नया recorded attempt | Solution/PV until solve/skip/reveal | Solve/skip/exit; theme, attempts, hints, outcome save |
| **Opening Training** | Engine hidden; content authoring/curation के लिए offline/internal | Progressive hint; answer के बाद detail | Submitted answer undo नहीं; retry नया attempt | Opening label/line/answer until submit | Answer/skip/exit; dataset version, answer, hints save |
| **Human competitive (future)** | Live game में disabled/not loaded in UI | Live move hints disabled | Competitive game में नहीं | Engine, book/explorer, eval, post-move suggestions | Authoritative server result; post-game analysis only |

**Global rule:** live human competitive game के दौरान app engine assistance, opening data recommendations, tactical hint या post-move coaching नहीं देगा। V1 में ऐसा online mode बनाया ही नहीं जाएगा।

## 2.2 Learn

- **User देखता है:** guided lesson title, objective, relevant board, move list/sequence, one concept card और step progress।
- **Actions:** board पर चाल चलना, answer submit करना, next/back lesson, hint माँगना, line replay करना।
- **Information:** curated rule/concept, legal continuation, simple why/recognition cue।
- **Engine:** runtime engine default off; lesson authoring में engine-checked answer/line की provenance रखी जा सकती है।
- **Hints/takeback:** 1) क्षेत्र/target, 2) motif/plan, 3) candidate move, 4) line reveal. Retry allowed; failed attempts मिटाए नहीं जाएँ।
- **Deliberately hidden:** unexplained raw centipawn scores, unrelated alternatives, unreleased answer।
- **End:** objective पूरा, lesson छोड़ना या session pause।
- **Saved:** lesson ID/version, result, tries, hints, elapsed time bucket; no sensitive profile required।

## 2.3 Practice

- **User देखता है:** free board, move list, variation tree, side to move, optional FEN input/setup position, save/export controls।
- **Actions:** legal moves, undo/redo, branch, reset, flip, set position, request analysis, save position।
- **Information:** Board facts तुरंत; engine lines सिर्फ `Analyze` दबाने पर; knowledge cards/coach hints explicit request पर।
- **Engine:** local Stockfish optional and user-initiated; active analysis cancelable।
- **Hints/takeback:** unlimited undo/redo; यह sandbox है, competitive result नहीं।
- **Deliberately hidden:** score as default distraction; user advanced panel खोल सकता है।
- **End:** reset/exit; unsaved state पर confirmation।
- **Saved:** only named/saved positions and variations; temporary scratch work auto-save optional preference।

## 2.4 Play vs Engine

- **User देखता है:** setup screen (colour, opponent strength label, clock, Challenge/Coached Practice), board, move list, clocks, mode badge, game result।
- **Actions:** legal move, resign, offer/claim draw where allowed, pause only where local practice policy permits, review after finish।
- **Engine:** opponent engine Worker; during `Challenge` its internal evaluation/PV hidden. Bot move is generated by UCI engine under bounded limits. In `Coached Practice`, user can request hint/analysis, explicitly marked as assisted.
- **Hints/takebacks:** Challenge default none; takeback toggle only casual, before start; enabling it changes mode label and saved record. Coached Practice: hints/takebacks allowed. No ladder/rating.
- **Deliberately hidden:** live eval bar, best-move arrow, opening explorer and engine PV in Challenge. Coached mode can reveal only on user request.
- **End:** checkmate, stalemate, dead position, draw claim/automatic draw, resignation, timeout. Result + reason shown distinctly. Engine crash is not a chess result—pause and offer restart/abort.
- **Saved:** complete move history, SAN/UCI, starting setup, ruleset, clock config/events, result, engine build/options and assistance-used flag.

## 2.5 Review Game

- **User देखता है:** original board replay, move list, evaluation graph (optional), key moments list, explanation panel and retry variation board।
- **Actions:** import/select game, navigate moves, choose simple/detailed/advanced, show candidate line, retry position, add note, export PGN।
- **Engine:** allowed only on completed/imported game. Search progress and cancel available. Previous analysis metadata shown for reproducibility.
- **Hints/takeback:** hints allowed; original game immutable; branch/retry can take back freely without changing original score/history.
- **Deliberately hidden:** unsupported player-intent statements, fake exact “accuracy”, unrelated engine alternatives by default.
- **End:** close review or mark review complete; user can return later.
- **Saved:** original PGN + analysis version + selected moments + retry branch + user annotations.

## 2.6 Puzzle/Training

- **User देखता है:** position, side-to-move, objective, optional difficulty/theme, legal move input, attempt/hint state।
- **Actions:** solve, ask hint, reset as new attempt, reveal solution, skip, switch theme/difficulty।
- **Engine:** can validate the curated line/alternative solutions internally; raw engine output hidden during attempt. No engine-required network call.
- **Hints/takeback:** progressive hints allowed. A submitted wrong move is recorded; `Reset` starts a new attempt rather than deleting it. Settings may allow a non-scored free practice queue, but V1 default records attempts locally.
- **Deliberately hidden:** solution/engine PV before user responds; puzzle rating as global player rating.
- **End:** solve, reveal, skip, or exit; no timer by default.
- **Saved:** puzzle ID/source/theme, attempt count, correct/failed, hint level, time bucket, dataset version.

## 2.7 Opening Training

- **User देखता है:** a move-order, board position, or pawn structure with one learning question at a time: identify family, variation, plan, pawn break or gambit status।
- **Actions:** select/type name or choose a candidate plan; play a typical move; reveal hint; view transposition note after answer।
- **Engine:** hidden; static opening dataset and curated cards drive content. Optional advanced engine analysis only after answer and outside scored attempt.
- **Hints/takeback:** hint ladder; submitted response stands; retry counts as a new attempt. Move-order exploration can happen later in Practice, not inside assessment.
- **Deliberately hidden:** full branch tree, engine best move, database popularity and answer until submission.
- **End:** answer/skip/exit; show correctness plus confidence of opening label.
- **Saved:** opening node/source dataset version, response, hints, time bucket and post-answer review status.

---

# 3. User Experience and UI

## 3.1 Global navigation and information hierarchy

Primary navigation: **Home · Learn · Practice · Play vs Engine · Review · Puzzles · Openings**. `Game history` and `Settings` remain accessible but secondary. No V1 social feed, chat, tournament lobby or leaderboards.

Every active screen MUST visibly identify its mode. Engine/hint controls MUST be visually distinct and show whether enabled. In a human-competitive mode (future), no engine/hint control is rendered.

## 3.2 Screens

### Home/Dashboard
- Primary cards: Continue learning; Play vs Engine; Review/import PGN; Practice; Puzzle; Opening Training.
- Secondary: recent saved games, “review later” list, small practice themes; no global Elo score.
- Empty state: explain local-first behavior and offer first lesson/game.
- Offline state: badge showing offline, with local modes still clickable; network-dependent feature disabled with reason.

### Chess Board Workspace (shared component)
- Desktop: board in primary left/center area; right panel tabs for move list, coach, analysis, lesson content; clock and mode status above board.
- Mobile: board and clocks first; move list/coach/analysis as accessible bottom sheet/tabs; no panel may cover legal destination squares while dragging.
- Board controls: orientation flip, coordinates, piece style (permissive asset only), move list, undo/redo only if current mode permits, FEN/PGN actions by mode.
- Visual cues: selected piece, legal destinations, last move, check, checkmate, target/threat, hint arrow must use different styles; color alone never communicates meaning.
- Input: click-select-click and keyboard alternative are required alongside drag/touch.
- Illegal move: reject, preserve board, announce concise explanation if helpful; no silent snapback without accessible status.
- Promotion: modal/popup with Queen/Rook/Bishop/Knight; no forced auto-queen.

### Learn Screen
- Lesson list by rules, tactics, strategy, openings, endgames; first version curated and short.
- Lesson page shows objective, board step, progressive hint, explanation, retry and completion. Raw engine eval hidden.
- Empty/search state states that more content may come later; no placeholder content pretending to be authoritative.

### Practice Screen
- Free board with optional FEN setup/import, branch tree and user-controlled analysis.
- Default engine off; `Analyze position` opens a clearly labeled analysis panel. `Reset`, `Undo`, `Redo`, `Save position`, `Export FEN/PGN` available.
- Invalid FEN shows field-level parse error; no game history/repetition claims invented from a single FEN.

### Play vs Engine setup/game
- Setup: side, opponent strength descriptor, optional clock, Challenge/Coached Practice, optional takeback. Warnings explain no human Elo equivalence.
- Game: board, clocks, move list, mode badge; no eval/PV in Challenge. Coached mode controls remain user-triggered.
- Engine error/loading states: show “Engine is loading/paused/failed”; never freeze board; do not make a substitute random bot move silently.
- Result view: result, exact reason, key event, review CTA, rematch; no rating delta.

### Review Game Screen
- Import from PGN paste/file and select saved game. Validate with clear warnings on truncated/invalid PGN, unsupported variant or missing move history.
- Replay controls: first/previous/next/last, keyboard shortcuts, variation branch, go-to-key-moment.
- Review list: top moments first; filter by tactics, defence, opening, king safety, endgame, missed opportunity. A label includes evidence/confidence.
- Explanation panel: Simple/Details/Advanced; line board replay; “Try this position” creates branch.
- Evaluation graph is optional/contextual, never sole explanation. `0.00` style engine scores must specify perspective/engine model if visible.

### Puzzle/Training Screen
- Theme selection, no timer by default, board, objective, hint button, reset/skip, attempt feedback.
- After solve: solution line, theme, why it works, defensive best reply, “recognise next time” cue.
- Wrong move: say whether illegal or legal-but-does-not-solve; do not imply it loses the game unless analysis supports that.

### Opening Explorer/Recognition Screen
- Position/move input; result card shows confidence, matched name/ECO, family/variation, defining sequence, structure, plans/breaks and alternatives only when source supports them.
- Local opening index is default. Book popularity/online stats are V1.5+ and must show source/sample size/date.
- If multiple names/transpositions match, display a small list with “same position reached by …” and do not claim one unique opening name.

### Opening Training Screen
- Quiz modes: name the opening; distinguish variation; choose candidate plan/break; identify gambit offer/acceptance; connect structure to typical plan.
- Do not test rote moves beyond curated lesson scope. Show full answer and typical counterplan after submission.

### History/Saved Games Screen
- Search/filter by date, mode, result, review status, opening tag; local only.
- Import/export/delete individual or all games. Confirm destructive deletion. No cloud backup in V1.

### Settings/Privacy Screen
- Language, piece style, coordinates, board orientation, sound, reduced motion, notation, engine settings, time controls, offline storage, export/delete data, license notices.
- Explain that IndexedDB/local storage is on this browser/device and may be cleared by the user/browser; it is not encrypted vault storage.

## 3.3 Shared states and responsive behavior

- **Loading:** skeleton/progress and cancel where applicable; do not render a broken board.
- **Empty:** one next action, no dead end.
- **Error:** plain Hindi cause/action; keep already saved games safe.
- **Offline:** distinguish features available locally from network-only features; no retry loop that blocks play.
- **Mobile:** support portrait as default; landscape optional. Touch hit areas and promotion dialog tested on small screens.
- **Accessibility:** see §18; accessibility is release criterion, not polish.

---

# 4. Chess Game Domain Model and Rules

## 4.1 Canonical game aggregate

**Canonical truth is an ordered, legal move history plus initial position and ruleset.** Current FEN is a derived snapshot/checkpoint, not the complete game record.

| Entity/field group | Required content | Notes |
|---|---|---|
| `GameIdentity` | Stable local ID, schema version, created/updated timestamp | IDs independent of usernames |
| `Mode` | Learn/Practice/EngineGame/Review/Puzzle/OpeningTraining; assisted/unassisted flags | Mode controls what UI/intelligence is allowed |
| `Ruleset` | `standard-chess`; rules policy version; FIDE edition/reference; claim/auto draw behavior | Variant field reserved; V1 only standard chess |
| `InitialPosition` | Standard initial setup or supplied FEN; `SetUp` marker/metadata; source of position | Needed for custom start and PGN export |
| `BoardState` | Piece placement, side-to-move, castling rights, EP state, halfmove clock, fullmove number | Expose validated FEN projection and internal board object |
| `MoveHistory[]` | Ply index, from/to square, promotion piece if any, UCI move, SAN, before/after position keys/FEN, timestamp/clock snapshot, source (human/engine/import) | Store committed legal moves; SAN can be regenerated but keep canonical exported form for audit |
| `RepetitionHistory` | Position-key count per move prefix | Must use FIDE-equivalent position identity; not derivable from final FEN |
| `DrawState` | Current claimable conditions, intended-move claim candidates, auto-draw conditions | Claims and automatic endings are distinct |
| `Result` | `ongoing / 1-0 / 0-1 / 1/2-1/2`; termination reason; result actor/source | Reason enum distinguishes mate, stalemate, dead position, claim, fivefold, 75-move, resignation, timeout, agreement, abort |
| `Players` | White/Black player descriptors; local human or engine ID/version/options; optional imported PGN names | No accounts required in V1 |
| `ClockState` | Time-control type/base/increment/delay, remaining per side, active side, monotonic anchor, paused state | Clock is a separate game service; do not infer from FEN |
| `Annotations` | User notes, review tags, candidate explanation ID | Untrusted imported text escaped on render |
| `AnalysisReference` | Engine version, options, search budget, analysis date, PGN/position hash | Search output cache can be invalidated/reproduced |

## 4.2 Board facts and formats

- **FEN** stores a single position snapshot: piece placement, side to move, castling availability, en-passant target field, halfmove clock and fullmove number. It can reconstruct the listed snapshot fields if valid.
- **FEN alone cannot reconstruct:** prior move order, SAN/PGN comments/variations, how many times a position occurred, whether a side previously offered draw/resigned, player identity, game result, clock state, game mode, engine metadata or old annotations.
- Castling rights in FEN are current historical rights, not something to infer from whether King/rook currently sit on home squares. A moved rook/King cannot regain castling rights by returning.
- En-passant target in serialized FEN must be parsed according to chosen FEN standard; repetition comparison must use whether an en-passant capture is actually legally available, not blindly compare a non-capturable target field.
- **PGN** is the game record/import-export format; standard tags, SAN movetext, result, comments/variations as supported. Custom initial FEN requires appropriate setup/FEN metadata.
- **SAN** is human-readable notation derived from the legal position, including disambiguation, capture, check, mate, castling, promotion.
- **UCI move** is engine move encoding (source/destination/promotion); distinct from UCI protocol commands (`uci`, `position`, `go`, `stop`).
- In UI, use standard English SAN/PGN for interoperability; localise explanations, not the canonical move notation.

## 4.3 Move transaction and state transitions

1. UI receives user-selected move intent.
2. Domain calls rules library for legality against current state; rejects illegal move without mutating canonical history.
3. On legal move, domain commits an immutable move event, updates board projection, side-to-move, castling/EP/counters, SAN, repetition key/count and clock transition atomically.
4. Rules adjudicator checks checkmate/stalemate/dead position and automatic draw conditions; for claimable draw, exposes a claim action instead of auto-ending.
5. Storage transaction persists move and game aggregate; UI update is immediate, but write failure is announced and recovery offered.
6. Engine/knowledge layers receive a versioned immutable position snapshot; their responses never mutate board state directly.

Game status state machine: `setup → active ↔ paused (local modes only) → finished`; import/review has `imported/reviewing` state separate from active play. A finished game cannot accept moves; review variations are new analysis branches, not canonical move history edits.

## 4.4 Chess rule requirements

V1 is standard chess. Rules engine is authoritative; UI must not implement separate conflicting move rules.

- **Check:** King under attack; the player must make a legal response that removes check. Attack detection follows chess attack-square semantics; it is not identical to “attacker has a legal move that does not expose its own king.”
- **Checkmate:** side-to-move is in check and has no legal move; result immediately assigned to other side, termination `checkmate`.
- **Stalemate:** side-to-move is not in check and has no legal move; automatic draw, termination `stalemate`.
- **Dead position:** if no possible legal sequence can lead to checkmate by either player, game is drawn. This is not synonymous with a simple “insufficient material” heuristic. Rules layer must not declare dead solely because a heuristic is unsure. Detector must be audited; if full rules-compliant behavior is not achieved, release blocks rather than silently changing the rule.
- **Threefold repetition:** claimable by player whose turn it is when same position has occurred three times, or via a legal intended move that will create the third occurrence. It is not automatic in V1. Identity includes piece placement, side to move, castling rights and legal EP possibility; counters/clock do not identify repetition.
- **Fivefold repetition:** automatic draw on the fifth occurrence under selected FIDE rules policy.
- **Fifty-move rule:** claimable after each player has completed 50 moves without pawn move or capture (100 half-moves), or by a valid intended-move claim; do not automatically terminate at 50 in claim-based mode.
- **Seventy-five-move rule:** automatic draw after 75 moves by each player (150 half-moves) without pawn move/capture; checkmate delivered by the final move takes precedence.
- **Draw claim UI:** show claim only when current or declared-next-move condition is validated. Intended-move claim is checked against a legal move but the move is not committed if claim succeeds. Record claimant/condition.
- **Castling:** King and selected rook have never moved; intervening squares clear; King not currently in check, not crossing an attacked square, and not ending on attacked square. Rook being attacked or crossing an attacked square alone does not forbid castling. Rights are historical state.
- **En passant:** available only immediately after opponent's two-square pawn move when adjacent pawn can capture; captured pawn is removed from its actual square. Reject if the move leaves own King in check.
- **Promotion:** pawn reaching final rank must promote on that move to Queen/Rook/Bishop/Knight. All four options are available and recorded in SAN/UCI. Underpromotion is not an optional afterthought.
- **Timeout:** flag fall generally loses, but draw if opponent cannot possibly checkmate by any legal sequence under the rules. Do not implement timeout as automatic loss without mating-possibility test.
- **Resignation:** distinct from checkmate; FIDE dead-position exception can make result draw if no legal sequence permits opponent to mate. Result reason not inferable from board snapshot.
- **Draw agreement/claim/resignation/abort:** separate termination reasons; record who initiated and whether accepted where applicable.

**Ruleset gate:** Master Research verified FIDE Laws effective 1 January 2023. Before implementation/release, verify whether FIDE has amended the relevant law text since that source. If changed, update `rulesPolicyVersion`, rules behavior and acceptance tests explicitly; do not silently ship a different rule.

## 4.5 Clock behavior

- V1 supports untimed and basic base-time + Fischer increment. Other clock systems are future scope.
- Clock service stores remaining time, increment, active side, and monotonic start anchor. UI refresh is display only; do not subtract time based on a throttled interval loop.
- Increment is added exactly once after each accepted legal move, according to the selected policy; test boundary semantics.
- Learn/Practice/Puzzle timers are optional and off by default; timeouts in these modes do not end a chess game unless user explicitly chooses clocked practice.
- Hidden tab/resume recalculates elapsed time from monotonic timestamps; local pause only where mode permits.
- Future online games use server-authoritative time, not client wall-clock.

---

# 5. Chess Intelligence Architecture

## 5.1 Separate layers and data contracts

| Layer | What it owns | Must not do |
|---|---|---|
| **Game Facts** | Validated board, side-to-move, history, legal moves, check/result, material, king/pawn/piece features, repetition, clock, phase candidates | Guess human intention, use engine score as a rule, label unsupported patterns |
| **Engine Facts** | Engine version/options, depth/nodes/time, cp/mate, perspective, PV, MultiPV, optional WDL, search status | Mutate game, decide FIDE legality, claim exact human Elo/intention |
| **Chess Knowledge** | Versioned opening family/variation data, gambit nodes, motif definitions, structures, curated plans/mistakes, endgame pattern rules | Override a legal position, assert evaluation without support, invent source status |
| **Learning Facts** | User answers, attempts, hints, errors, review moments, saved themes, lesson/puzzle history | Convert practice data into unvalidated chess strength or public rating |
| **Explanation** | Evidence-backed text assembled from the layers; confidence and wording policy | Invent board facts/lines, output illegal move, turn PV into human-intent claim |
| **UI/Mode Policy** | What controls/data are visible/allowed in current mode | Bypass fair-play restrictions or call engine directly from board component |

## 5.2 Layer interaction

1. A committed legal move produces a versioned `PositionSnapshot` and deterministic `GameFacts`.
2. Opening/pattern detectors query versioned `ChessKnowledge` and may emit matched/candidate labels with evidence.
3. Engine adapter receives immutable snapshot + analysis request and returns `EngineFacts`; response includes `positionHash`, `requestId`, `engineVersion`, budget and status.
4. Learning layer can associate a move/answer with a theme only after relevant detector/analysis evidence; it records what the user did and what feedback was shown.
5. Explanation service accepts only structured facts/curated text/validated legal PV. It outputs a message with source fields, confidence, and allowed wording class.
6. UI renders it according to mode. The same engine fact may be hidden in Challenge, shown after game completion, or simplified in Learn.

## 5.3 Confidence and evidence vocabulary

- **Verified board fact:** directly computed from legal position/history (e.g., “Black’s bishop attacks f2”).
- **Exact database match:** move sequence/position matches an opening dataset entry; report the entry and transposition caveat.
- **Typical plan:** curated plan associated with a structure; label “typical”, not guaranteed.
- **Candidate motif/plan:** static pattern or partial engine search suggests an idea but continuation not sufficiently verified.
- **Engine-supported continuation:** search supplies legal PV and evaluation metadata; not mathematical proof unless exhaustive/tablebase proof is available.
- **High/medium/low confidence:** confidence refers to evidence/recognition quality, not player skill. V1 must define and test thresholds per detector; if below its minimum, suppress named label and show only verified board fact.

V1 does not use a freeform LLM. Future language models may paraphrase a bounded evidence packet, but a rules engine must revalidate every move/line and a guard must reject claims without evidence IDs. The model cannot create Game Facts or Engine Facts.

---

# 6. Chess Knowledge and Recognition Systems

## 6.1 Opening recognition

### Taxonomy

Use hierarchy **Family → Opening → Variation → Subvariation** with alias/transposition links. The backing structure is a graph of known positions/move sequences, not a single tree, because distinct move orders may transpose.

Opening Atlas coverage includes Open Games, semi-open `1.e4` defences, Queen’s-pawn and Indian families, flank systems, major gambits, and common minor/offbeat lines. Literally every named subline is not a fixed practical list; user-facing copy must say “known/common line” rather than “all theory.” See [Chess Atlas §1](./Chess_Game_Master_Chess_Atlas_HI.md) and Master Research §8.

### Recognition order

1. Match canonical move sequence and board position against local dataset.
2. Check transposition aliases/position keys and defining moves.
3. If exact match absent, compare pawn structure and piece placement for a **family-like** candidate only.
4. Similarity must not create a named variation automatically. If only structural resemblance exists, label “structure resembles …” with low confidence, or return unknown.

### Required opening record

Where supported, expose: name, ECO, family, variation/subvariation, defining sequence, current matching position, source/dataset version, typical pawn structure, typical plans for both sides, common tactical ideas, typical piece placement, pawn breaks, common mistakes, associated gambits, transposition notes and confidence.

Fields such as “typical plan/mistake” require curated source content. They are not inferred from name alone. If a field is missing, omit it—not fill it from a generic guess.

### Opening recognition vs advice

- Recognition answers: “What known opening/position label fits this move sequence?”
- Advice answers: “What plans/candidate moves fit this current board?”
- Opening name/database popularity is not advice. Advice must use current position and the player’s side-to-move; a familiar opening can transpose into a different structure.

### In-game output

Example wording: “यह position Queen’s Gambit Declined family से मेल खाती है (medium confidence). Typical plan: …c5 से d4 पर दबाव। इस exact move order के लिए नाम अलग databases में बदल सकता है.” Never say “you must play …c5” without concrete evaluation/context.

## 6.2 Gambit recognition

### Definitions and classes

- **Named gambit:** curated opening sequence uses a recognized gambit name.
- **Functional gambit offer:** a move intentionally permits a pawn/material capture for plausible compensation. The system may label “possible gambit offer” only after checking the move/continuation.
- **Accepted:** opponent actually captures the identified offered material in the relevant branch; “accepted” does not mean the pawn is permanently held.
- **Declined/rejected:** opponent does not take the offered material and chooses a different response.
- **Countergambit:** a gambit/counteroffer used to challenge the opponent’s gambit or centre.
- **Purpose tags:** development/open-lines, centre, initiative/attack, long-term positional compensation, king-safety, tactical complication, surprise/offbeat. These are curated descriptive tags, not formal quality scores.

### Atlas taxonomy foundation

White: King’s, Evans, Danish, Göring/Scotch, Smith–Morra, Wing, Blackmar–Diemer, Staunton, From’s, Réti, Tennison, Milner–Barry, Ponziani Countergambit. Black: Marshall, Latvian, Elephant, Albin, Budapest/Fajarowicz, Benko/Volga, Blumenfeld, Englund, and related countergambits. Refer to [Chess Atlas §2](./Chess_Game_Master_Chess_Atlas_HI.md).

### Gambit analysis output

For each identified offer, state separately:
- material offered/temporarily conceded;
- development lead or delay (computed from actual pieces/tempo, if available);
- open lines/centre gained or lost;
- king-safety change for both sides;
- initiative and forcing threats;
- tactical justification/PV if engine-supported;
- positional compensation cues (files, outposts, weak pawns, long-term pressure);
- accepted/declined status;
- theoretical status only if a dated curated source exists;
- confidence and caveat.

**Forbidden inferences:** “pawn offered → good gambit”; “pawn lost → bad gambit”; “named gambit → theoretically sound”; “opponent took pawn → accepted permanently.”

## 6.3 Strategy and positional recognition

### Required concepts

The detector/catalog must cover centre, development/tempo, king safety, space, piece activity, open/semi-open files, weak squares, outposts, bishop quality, bishop pair, pawn breaks, prophylaxis, exchange strategy, initiative, counterplay, blockade, pawn majorities/minorities.

### Position relevance contract

Every strategy card needs:
1. **Current evidence:** a factual board feature (e.g., isolated d-pawn, open file, weak square, king exposure).
2. **Why it matters now:** development, activity, target, space or endgame consequence.
3. **Candidate plan:** typical/possible plan with side and legal first step where known.
4. **Counterplan:** what opponent can do/which break or exchange changes it.
5. **Confidence:** exact detector, curated structure match or tentative analogy.

No card may show only a dictionary definition. Strategic recommendation must be linked to board evidence and feasibility. Strategy is not reduced to engine evaluation or one “best move.”

### Pawn structure detectors

| Structure | Recognition input | Typical relevant plans (conditional, not universal) |
|---|---|---|
| IQP | Isolated pawn on c/d/e-file and no supporting same-color adjacent-file pawn | IQP side: activity, outposts, pawn advance/break; opponent: blockade/exchanges/target pressure |
| Hanging pawns | Adjacent central pawns (often c/d) with no adjacent friendly pawn support | Owner: activity and timed advance; opponent: blockade/trade pieces and attack them |
| Doubled pawns | Same-file friendly pawns | Weigh open file/centre control vs targets/limited pawn support |
| Backward pawn | Pawn cannot advance safely/support adjacent chain; weak square in front | File pressure/blockade; only call “backward” with structure test |
| Pawn chain | Diagonal linked pawns | Attack base/head or counterbreak; attack direction is a clue, not fixed instruction |
| Passed/connected passers | No enemy pawn can stop/capture on forward/adjacent files; connected pair | Escort/support/blockade; evaluate king/rook distance and promotion race |
| Carlsbad | Recognized pawn skeleton/sequence; often QGD Exchange | Minority attack (`b4-b5`) or central `e4`; identify which side has which pawn majority |
| Maroczy Bind | White pawns c4/e4 in matching structure | Restrict …d5/…b5 and improve pieces; avoid claims of automatic advantage |
| Hedgehog | Compact Black structure with advanced White space and typical latent breaks | Black prepares …b5/…d5/…e5; White consolidates and restricts breaks |
| French chain | White e5/d4 chain vs Black e6/d5 base | Black …c5/…f6 undermining; White supports/attacks opposite wing as structure permits |
| Benoni | White d5 space vs Black asymmetric …c-file/queenside activity | White uses space/central play; Black seeks …b5/…f5/central breaks where legal |
| Dutch Stonewall | Black pawn chain …f5/…e6/…d5/…c6 | e4 control and kingside activity vs dark-square/bishop weaknesses |
| Majority/minority | Count pawns per wing/centre and passed-pawn potential | Majority may create passer; minority may create backward/isolated pawn; test actual break |

These are common structures from the Atlas, not exhaustive pawn-position classification. Curated tags should include position examples and counterplans. See [Chess Atlas §3](./Chess_Game_Master_Chess_Atlas_HI.md).

## 6.4 Tactical motif recognition and validation

### Motif catalog

| Motif | Candidate detector cue | What explanation must validate |
|---|---|---|
| Fork/double attack | One legal move attacks two or more valuable/critical targets | Whether targets can escape/defend and net material/result |
| Pin | Line piece attacks blocker with king/valuable target behind | Absolute vs relative; can pinned piece legally move; follow-up wins something |
| Skewer | Line attack on valuable piece with target behind | Capture/escape after first piece moves; net gain |
| Discovered attack/check | Blocker move opens line from rook/bishop/queen | Blocker destination, newly attacked target, opponent reply |
| Double check | Moving piece and revealed piece check together | Legal king responses and whether mate/material follows |
| X-ray | Line pressure through/behind enemy piece | Whether exchange/removal actually exposes target |
| Battery | Two aligned pieces on same line | Required blocker move/exchange and defended targets |
| Remove defender | Candidate capture/exchange targets a piece guarding something | Recapture sequence and whether target becomes loose |
| Deflection | A defender is forced off duty/square | Forced nature of move and follow-up |
| Decoy/attraction | Sacrifice/check induces piece to vulnerable square | Whether target is actually lured and tactical continuation works |
| Overload | One defender has multiple duties | Which threat it cannot meet; calculate both branches |
| Interference | A move blocks connection between two enemy pieces | Which support/check line is cut and resulting consequence |
| Clearance | Move vacates a square/file/diagonal | Follow-up line is legal and meaningfully stronger |
| Zwischenzug | Forcing in-between check/capture/threat before expected recapture | Compare with immediate recapture; validate response branches |
| Trapped piece | Low escape mobility plus incoming attack | All legal escape squares/captures, not visual corner alone |
| Loose/hanging piece | Undefended or insufficiently defended target | King legality, pin, overprotection, recapture and exchange count |
| Desperado | Losing/trapped piece has forcing capture/check | Material outcome vs passive loss |
| Sacrifice | Material offered for line/attack/promotion/position | Concrete compensation and best defence; no automatic praise |
| Underpromotion | Pawn can promote to R/B/N | Queen stalemate/tempo issue, knight-check, forced win or draw consequence |
| Promotion race | Opposing passers near promotion | Exact move count, checks, capture, opposition and underpromotion |
| Perpetual check | Repeating legal checks available | Is repetition unavoidable or merely possible? Draw claim/rule |
| Stalemate resource | Losing side may remove all legal moves without check | Exact legal move set and result under standard rules |
| Zugzwang | Any legal move worsens position | Show relevant alternatives and why tempo loss matters |
| Windmill | Discovered-check sequence can repeat checks and wins | Full legal sequence, king escape, captures and counterchecks |

### Mating patterns

| Pattern | Recognition signal | Required caution |
|---|---|---|
| Back-rank mate | King boxed behind pawns; rook/queen reaches final rank | Confirm no luft/escape/interposition |
| Smothered mate | King’s own pieces limit escape; knight delivers mate | Verify all legal king/capture squares |
| Arabian mate | Rook plus knight coordinate near edge/corner | Pattern label only if exact mating geometry matches |
| Anastasia’s mate | Rook/queen line attack along edge with knight restricting escapes | Verify forced mate, not just similar piece placement |
| Boden’s mate | Crossed bishop diagonals, boxed king | Confirm blockers/escape squares |
| Scholar’s mate | Early queen+bishop pressure on f7/f2 | Not a recommended forced opening plan; show counterplay |
| Fool’s mate | Immediate king-side weakening permits queen mate | Educational pattern, rare practical target |
| Greek Gift | Bxh7+/Bxh2+ bishop sacrifice draws king into attack | Must calculate escape squares, defenders, checks and follow-up; never declare “works” by shape alone |

### Validation pipeline

1. **Pattern candidate:** static board/move detector generates one or more candidate legal moves/sequences.
2. **Legal verification:** rules layer confirms every move, check response, castle/EP/promotion and final side-to-move.
3. **Forcing reply generation:** check all opponent checks, captures, king escapes, interpositions, recaptures and strongest defensive moves; do not validate against a single cooperative reply.
4. **Continuation search:** use bounded engine search/MultiPV or curated exact pattern line; record engine and budget.
5. **Outcome comparison:** evaluate material, mate state, king safety, promotion and draw outcome at line end relative to best defence and baseline.
6. **Stability:** if result changes materially with additional budget or alternatives remain, display `candidate motif`/`tactical possibility` with confidence, not a confirmed win.
7. **Claim wording:** “engine-supported continuation” for searched line; “forced” only when exact proof/tablebase/rule calculation supports it. Engine mate score alone is not treated as a mathematical proof.
8. **UI replay:** show line and player’s actual option; allow user to play the defence. Hide unvalidated bold labels.

## 6.5 Attack recognition

Attack system emits a prioritized **candidate threat/plan**, backed by facts, not an intent claim. Atlas patterns:

- uncastled/exposed king and open central files;
- f2/f7 focal square (actual defenders must be counted);
- queen+bishop or rook batteries;
- open/semi-open file and seventh-rank pressure;
- rook lift with clear path;
- opposite-side castling and pawn storm;
- central breaks against a king in the centre;
- Greek Gift candidate;
- kingside/queenside attack based on king location and pawn structure;
- minority attack as a positional pawn plan, not automatically a king attack.

**Priority:** forced mate/blocking threat → concrete king attack with forcing line → tactical target → positional candidate plan. The top item must be engine-supported or rule/geometry verified; generic “attack now” message is prohibited.

**Explanation:** current attackers/defenders, open line, escape squares, needed supporting move, possible defence/counterattack, confidence. State “possible attack on …” unless a forced line is validated.

## 6.6 Defensive recognition

Defence module first runs opponent’s **Checks-Captures-Threats** scan, then tests these resource families:

- remove/exchange attacker;
- reinforce target / add defender;
- interpose/block file or diagonal;
- create luft/escape square;
- king reposition or legal safe castling;
- cut attacker supply/close file/prevent pawn break (prophylaxis);
- return material to reduce attack;
- counterattack/forcing countercheck;
- queen trade, repetition/perpetual;
- blockade, fortress, stalemate resource;
- defensive sacrifice.

Each output identifies the threat it answers, the candidate move/line, what remains loose, and whether it prevents/mitigates/draws or merely complicates. Rank by strongest verified or engine-supported opponent idea. Do not produce generic “defend your king” if there is a concrete mate threat available.

## 6.7 Endgame recognition

### Phase detection

Phase is based on material/board features, not move number alone. Store: queens present/absent, rooks/minor piece counts, pawn counts/structure, active kings, passed pawns, checks and promotion distances. Endgame label may be mixed (e.g. queen + rook ending); no forced label if material is not a clean pattern.

### Patterns and relevance conditions

| Pattern | Match conditions and relevant board facts | Output policy |
|---|---|---|
| King-and-pawn | Only kings/pawns or transition where minor pieces do not affect pawn race | Explain opposition, key squares, square rule, tempo, outflanking, triangulation or breakthrough only when relevant to exact king/pawn placement |
| Opposition | Kings face with pawn/entry square and tempo matters | Show side-to-move, target square and line; never label solely by facing kings |
| Key squares | Passed pawn and king route to promotion | Identify actual promotion/key squares and enemy king reach |
| Square rule | Lone passed pawn and opposing king’s catch distance | Mark as quick test; account for side-to-move, checks, blockers and legal special cases |
| Triangulation/reserve tempo | A king/pawn tempo move changes who must move | Show exact route and zugzwang consequence |
| Rook ending | Rooks + pawns; king cut-off, activity, passer distance | Rook behind passer/side checks/cut-off only if actual geometry supports it |
| Lucena | Recognized rook+pawn vs rook winning construction with correct ranks/king/rook placement | Show bridge technique; require exact pattern match, not broad “rook endgame” tag |
| Philidor | Recognized rook+pawn vs rook draw setup | Show third-rank/behind-check method and required conditions |
| Vancura | Rook-pawn vs rook defensive geometry | “Possible draw resource” unless exact conditions verify |
| Bishop/knight ending | Piece types, pawn color complexes, outposts, wings | Explain bishop range vs knight outpost conditionally; no universal piece ranking |
| Opposite-coloured bishops | One bishop each side on different square colours | Note drawing tendency only when material/attack supports; not automatic draw |
| Wrong-coloured bishop + rook pawn | Promotion square color vs bishop and defending king’s corner | Check actual king route and stalemate geometry before draw claim |
| Queen ending | Queens/pawns with king exposed/passed pawns | Prioritize check safety, perpetual/repetition, shelter and promotion race |
| Basic mate | K+Q/K or K+R vs lone king; K+B+N ending | Show technique only in exact material/endgame, not in unrelated position |
| Fortress | Recognized blockade/zone prevents progress | V1 labels `possible fortress`; confirmed only by curated proof/known exact pattern or deeper validated analysis |
| Perpetual/stalemate | Forced check cycle or no-legal-move draw idea | Verify exact rules and legal replies |

Full taxonomy from [Chess Atlas §7](./Chess_Game_Master_Chess_Atlas_HI.md). Lichess practice material is a source for standard opposition/key-square/Lucena/Philidor training patterns; app’s own recognition must still validate position fit.

---

# 7. Explanation System

## 7.1 Required explanation shape

For any meaningful feedback, include as relevant:

1. **क्या हुआ?** (verified board/move fact)
2. **यह क्यों मायने रखता है?** (target, king safety, development, pawn structure, material or endgame effect)
3. **Opponent क्या हासिल कर सकता है?** Use “possible threat/plan”, never mind-reading.
4. **मुझे क्या देखना चाहिए?** (checks/captures/threats, loose piece, line, break, king/passer)
5. **मेरे candidate responses क्या हैं?** Include legal move(s) and best known reply/caveat.
6. **कौन-सा concept है?** Motif/structure name with confidence.
7. **अगली बार कैसे पहचानूँ?** A short transferable cue.

If some part lacks evidence, omit that part. The UI should not force an explanation template to hallucinate a “why.”

## 7.2 Progressive depth

- **Simple:** 1–2 plain Hindi sentences; one board fact and one implication; no raw centipawns/PV.
- **Detailed:** candidate move + short legal line, one opponent defence, motif/plan and confidence.
- **Advanced:** MultiPV, score type/perspective, depth/nodes/time, alternative replies, dataset/source and limitations.

User explicitly requests deeper detail; otherwise show concise text and replayable board line.

## 7.3 Approved wording and prohibited wording

**Approved:** “यह चाल c4 पर दबाव बढ़ाती है”; “एक सम्भावित plan … है”; “इस pawn structure में आम idea …”; “engine-supported line में …”; “यह fork candidate दिखता है, पर … से बचाव सम्भव है”; “confidence मध्यम है क्योंकि दो move-orders इस position तक पहुँचते हैं.”

**Prohibited:** “आपके opponent ने निश्चित रूप से सोचा …”; “यह चाल हमेशा जीतती है”; “यह gambit सही/गलत है” बिना dated evidence/context; “यह खिलाड़ी 1200 Elo का है”; “आपकी accuracy 93%, इसलिए आपका खेल … rating के बराबर”; “engine ने कहा इसलिए यह human intention है.”

## 7.4 V1 explanation implementation

Use curated bilingual templates/content blocks with fields for verified fact, line, evidence source, detector, confidence, mode and depth. No freeform LLM. If future LLM is proposed, it must only paraphrase a bounded evidence packet; generated move names/lines are rejected unless rules layer validates them. Human intent is never an output field.

---

# 8. Post-game Analysis and Review

## 8.1 Review workflow

1. Finish game/import PGN; verify all moves and result.
2. Store original record immutable; create analysis session linked by game ID and position hashes.
3. Let user self-review key moment first if enabled (“आपको कहाँ लगा position बदली?”).
4. Run bounded analysis; show progress/cancel. Do not block move playback.
5. Select key moments: forced mate/result transition, large stable evaluation swing, tactical turning point, missed tactical win/defence, game-ending blunder, opening deviation (neutral label), king-safety event, endgame decision, strong move or defensive resource. A “strategic mistake” may be named only when a curated positional feature/plan and corroborating analysis support it; otherwise present a candidate plan, not a mistake verdict.
6. Default display first 2–5 moments sorted by learning value and confidence; show “all moments” on request.
7. Each moment: position, side to move, played move, one or more better candidates, engine/curated line, why it mattered, concept tag, confidence, retry.
8. Retry runs on a copy/branch. User’s alternative line is recorded separately from the original result.
9. Finish/save review status and optional practice-theme recommendation.

## 8.2 Move classification policy

Move labels are product classifications, not FIDE terms. V1 canonical labels are `No major loss`, `Inaccuracy`, `Mistake`, `Blunder`, `Missed opportunity`, `Tactical turning point`, `Strong move` and `Defensive resource`, each with a versioned policy. `Strong move` is shown only when the played move is in a stable engine top candidate set or is a validated unique defensive resource within the product tolerance; V1 does not use a subjective `Brilliant` badge. `Strategic mistake` requires curated positional evidence plus corroborating analysis; otherwise display a candidate plan/caution.

**Initial product thresholds [recommendation, must be tuned/benchmarked]:** compare the mover’s best pre-move evaluation with the post-played-move evaluation at comparable engine budget and normalized mover perspective. Suggested centipawn-loss bands: `Inaccuracy ≥0.50 and <1.00`, `Mistake ≥1.00 and <2.00`, `Blunder ≥2.00`; these are internal heuristic bands, not universal chess truth. Mate transitions and forced draw/win changes use separate mate/result logic, not arbitrary centipawn conversion. If search instability is high, label `Needs deeper analysis` or omit classification.

- Use same engine/version, options, side-to-move perspective and comparable node/time budget for each side of comparison.
- Evaluate actual played move, not only one PV; consider MultiPV/candidate choices.
- Mate scores remain mate-state labels; record distance-to-mate separately if useful.
- A missed win/defence is reported only if a candidate line is legal and meaningfully better against strong replies.
- “Brilliant”/subjective sacrifice badges are out of V1 scope.
- Opening deviation is not an error by itself; database frequency is not engine evaluation.
- Accuracy percentage is optional future research metric only; never a standalone rating or player-quality claim.

## 8.3 Review error behavior

Engine unavailable/crash: retain game, mark analysis incomplete, offer retry. Stale analysis: discard if position hash/settings/generation do not match. Unsupported PGN/variant: allow raw text export, but do not pass it into standard-chess rules as if valid. Storage failure: show export/backup route.

---

# 9. Training and Progress

## 9.1 Training categories

Use Chess Atlas taxonomy:

- Opening families/variations/transpositions;
- gambits and material compensation;
- tactics: fork, pin, skewer, discovered attack, double check, x-ray, battery, remove defender, deflection, decoy, overload, interference, clearance, zwischenzug, trapped/loose piece, desperado, sacrifice, underpromotion, promotion race, perpetual, stalemate, zugzwang, windmill;
- mating patterns: back rank, smothered, Arabian, Anastasia, Boden, Scholar’s/Fool’s patterns, Greek Gift;
- attacks and defence;
- strategy/pawn structures: IQP, hanging/doubled/backward pawns, chains, passed pawns, Carlsbad, Maroczy, Hedgehog, French chain, Benoni, Dutch Stonewall, majorities/minorities;
- endgames: pawn, rook, minor-piece, queen, basic mates, fortress/perpetual/stalemate.

V1 data volume is deliberately curated; taxonomy support does not promise that every motif has a full course on launch.

## 9.2 Puzzle selection and difficulty

- Select only puzzles with valid standard-chess FEN and legal solution line; validate first move orientation/side-to-move.
- **Lichess puzzle import convention:** its FEN is the position before the opponent’s mistake; the first move in the solution sequence is normally that opponent move. Apply that first move to construct the user-facing puzzle position; the next move is the solver’s first response. Verify this per record and store the actual displayed FEN/side-to-move so a bad row cannot invert the puzzle.
- Use source theme/rating if available; store provenance and dataset version. Rating is puzzle difficulty signal, not user Elo.
- Default selection: chosen theme or mixed; avoid repeating recently solved puzzle immediately; V1 can use simple local recency shuffle.
- Difficulty labels: `आरम्भिक / मध्यम / चुनौतीपूर्ण` derived from source rating bands with versioned mapping, or curated label; do not invent exact skill rating.
- Accept every verified winning/drawing solution relevant to objective where feasible; do not mark alternate correct move wrong due to a single stored PV. For mate-in-one, validate all legal mating moves and accept any correct mate, not only the stored first PV.
- Hints reveal pattern then target/idea then candidate move; full line only on request/after attempt.

## 9.3 Training feedback and progress

Store locally: theme IDs, attempts, first-attempt success, hint level, solved status, time bucket, lesson version, opening recognition confidence and review-retry outcome. Show progress as “आपने इस theme का अभ्यास किया / यहाँ फिर अभ्यास उपयोगी होगा,” not “आप इस theme में विशेषज्ञ हैं.”

- **V1:** simple history and “review/practice this again” list; no public rating, streak pressure or rank.
- **V1.5:** spaced/repeated practice queue if user testing supports it; minimum sample requirements and transparent logic.
- **Weak-topic detection:** infer only from repeated observed errors (e.g., at least several independent attempts); label “practice suggestion”, not diagnosis.

---

# 10. Data Persistence, Local and Offline Behavior

## 10.1 Storage allocation

| Storage | V1 use | Do not store there |
|---|---|---|
| In-memory app state | Current selection, visible panel, temporary analysis request, current Worker state, unsaved branch | Sole copy of a committed game |
| IndexedDB | Games/moves, analysis snapshots, puzzle/opening attempts, annotations, user progress, saved FEN positions, migrations | Trusted executable content or raw HTML |
| localStorage | Small non-sensitive preferences: language, theme, board coordinates, last mode, reduced motion | Game history, PGN corpus, engine data, private secrets |
| Static PWA cache | App shell, versioned WASM/Worker assets, bundled CC0 opening/puzzle subsets, curated lesson content | User private games unless explicit offline cache strategy requires it |

IndexedDB is the primary durable store. Persist each accepted move transactionally; a failed write cannot silently leave a game shown as saved. Store schema version and migration path. Quota errors show export/clear-cache options without erasing unrelated user records.

## 10.2 Offline policy

After first successful load/install and asset caching, V1 MUST support offline:

- Learn content bundled for V1;
- Practice/saved FEN positions;
- Play vs Engine if Stockfish asset is cached and licensed;
- review saved PGNs and analysis already computed;
- selected puzzles and local opening recognition;
- export PGN/FEN and manage local data.

No offline promise for external game fetch, online popularity counts, account sync or third-party API. If an asset is not cached, say so and provide a clear reconnect/download action. App update must not destroy existing IndexedDB; engine/content versions remain recorded.

## 10.3 Import/export and data privacy

- Accept PGN text/file and FEN text. Parse with size/line limits, reject unsupported variants unless explicitly declared, validate all moves and show first parse error.
- FEN import creates a new position with history marked `unknown-before-start`; initialize repetition count to one, do not fabricate prior repetitions. Preserve FEN halfmove/fullmove/castling/EP state if valid.
- PGN export includes standard headers/result/SAN; custom start includes setup/FEN tags; analysis branches included only if user explicitly selects a compatible export format.
- User can export all data, export single game, delete game, delete progress, and wipe all local data.
- Local browser storage is not secure encryption; show privacy note on shared devices. No telemetry or remote upload in V1 unless separately consented and specified.

---

# 11. Technical Architecture and Dependencies

## 11.1 Architecture boundaries

**Conceptual flow:**

**Accessible UI → Mode/Application Services → Chess Domain/Rules → Local Storage**  
**                                            ↘ Knowledge/Recognition**  
**                                            ↘ Engine Adapter → Dedicated UCI Worker**  
**Knowledge + Game Facts + Engine Facts + Learning Facts → Explanation/Review Service → UI**

- UI components send user actions to application services; they do not mutate the board or send arbitrary UCI strings.
- Chess domain owns legal moves, history, results, draw claims and clock transition.
- Engine Adapter owns protocol/lifecycle/request budgets; it returns data only.
- Knowledge repository owns static datasets and provenance.
- Explanation/Review services take structured facts; they cannot adjudicate rules.
- Storage is behind repository interfaces; browser IndexedDB is V1 implementation.
- No backend or network service is required for local V1 workflows.

## 11.2 Required V1 stack

**[उत्पाद निर्णय/सिफारिश]**

| Dependency | Purpose | License | Why suitable / V1 status | Risks and release checks |
|---|---|---|---|---|
| React + TypeScript | UI and typed application/domain boundary | React MIT; TypeScript Apache-2.0; verify exact distributions | **Required V1.** Fits reusable screen/mode UI and makes layer contracts explicit; recommendation, not a fact from chess research | Pin versions, audit transitive licenses; chess rules must not live in React components |
| Vite | Static SPA/PWA build; Worker/WASM asset handling | MIT; verify exact version | **Required V1 recommendation.** Suits a local-first browser app without server rendering/backend | Production Worker paths, CSP, offline build, WASM loading; dev server must not be a runtime dependency |
| PWA Service Worker | Cache app shell and static licensed assets | Native browser API; no package inherently required | **Required V1 behavior.** Enables offline return after first cache | Versioned caches, safe update/migration, no stale rules/data without visible version |
| `chess.js` | Standard move legality/generation and notation helpers | BSD-2-Clause | **Required V1 candidate.** Permissive JS/TS rules foundation and easy integration with browser client | Audit draw-claim, repetition, dead-position, FEN/EP semantics; add tested rule-policy layer instead of assuming helper coverage |
| `react-chessboard` | Board rendering and user input | MIT at Master Research cutoff; verify version | **Required V1 candidate.** React integration accelerates standard board interactions | Must pass keyboard/screen-reader/touch/promotion tests; wrap or replace if it fails—license and accessibility both gate release |
| Stockfish 19 WASM | Engine opponent and post-game analysis | GPLv3 | **Required engine candidate, conditional on written GPL approval.** Strong local UCI analysis and bot without cloud compute | Source/NNUE notices, GPL distribution review, Worker lifecycle, WASM size/CPU/battery; never main thread or live human assistance |
| IndexedDB | Durable local games/progress/analysis | Native Web API; no package license | **Required V1.** Browser-native storage supports local-first/offline user data | Quota/migration/transaction failures; export/recovery; don't use localStorage for games |
| Lichess opening names dataset | Local opening recognition | CC0/public domain per project | **Required V1 data source.** A–E names/ECO/move positions enable offline labels and transposition lookup | Keep version/source; English names and aliases; dataset is an index, not advice or proof of opening quality |
| Filtered Lichess puzzle subset | Local puzzle/training items | CC0 database export | **Required V1 training source.** Has FEN/move/theme/rating fields to seed a curated theme set | Validate every FEN/solution and multiple correct lines; store source/version; do not bundle full corpus by default |

**Not selected for V1:** `Chessground` and `chessops` are GPL-3-or-later; do not add under an assumed permissive license. They may be reconsidered only after license approval. React Native/mobile-native, a remote database and a chess server are not required.

Exact package version is intentionally not frozen in this research-derived spec; coding agent must use supported stable versions, inspect each actual license file and record lockfile/SBOM before build. Version selection does not change the required license gate or acceptance criteria.

## 11.3 Source data requirements

- Opening labels: bundle the Lichess opening dataset (A–E tables/compiled index) locally; create exact position and move-sequence lookup; record CC0/source commit date.
- Lessons: original curated bilingual content derived from concepts, not copied wholesale from Chess.com/Lichess lesson text or proprietary diagrams.
- Puzzles: filtered CC0 subset only; store FEN, solution UCI, theme/source metadata, rating as puzzle signal, and validation status.
- Avoid copyrighted book lines/diagrams, proprietary databases and broadcast PGNs without specific permission/license review.

---

# 12. Engine Integration Specification

## 12.1 Engine lifecycle

1. Lazy-load dedicated Worker only when user enters Play vs Engine or explicitly requests analysis.
2. Worker loads versioned Stockfish 19 WASM assets; initialize with UCI handshake and ready check. UI exposes `loading / ready / thinking / stopped / error` state.
3. Query engine options/capabilities; do not assume options or hard-code unsupported values.
4. For a new game, send new-game reset; send `position startpos moves …` for complete game history or `position fen …` for standalone position. Complete move sequence is preferred when available for repetition/context.
5. Send bounded `go` request; parse `info`, MultiPV, cp/mate, optional WDL, PV and `bestmove`.
6. Validate every returned move/PV against current rules snapshot before display/commit.
7. New position, mode exit or user cancel sends stop; increment generation/request ID; discard any response whose request ID/hash no longer matches.
8. On Worker crash, timeout or invalid output: terminate/recreate once; if retry fails, mark unavailable and preserve game/analysis. Never commit arbitrary fallback move.
9. Free Worker/memory when mode closes or after idle timeout; keep UI responsive throughout.

## 12.2 Position synchronization and stale-result protection

Every request includes: `requestId`, `gameId/analysisId`, `positionHash`, `movePly`, `sideToMove`, `engineVersion`, relevant options and budget. Response must echo identity. UI accepts result only if request is still active and hash matches displayed position. If user navigates backward, changes branch, imports game or flips mode, old result is cancelled/ignored.

UCI commands must come from the adapter’s typed operation set, not raw user input. Sanitize all imported FEN/PGN before converting to commands.

## 12.3 Analysis settings

- **Threads:** V1 default 1.
- **Hash:** V1 default 32 MB on consumer/mobile profile; expose no low-level controls by default. Memory can be tuned after device benchmarks.
- **MultiPV:** 1 for bot move; 1 for simple hint; 2–3 only in Review/Advanced and under budget. MultiPV reduces search focus and is a set of candidates, not a guarantee of all good moves.
- **Search bounds:** use node/time bounds; depth may be displayed but is not a time guarantee. Always include stop/cancel.
- **Initial budget targets [recommendation; benchmark required]:** hint 0.5–1.5 sec; casual engine move 0.2–2.0 sec with 3 sec hard response ceiling outside user clock; review key moments ≤1 sec each by default, capped to 10 initial moments (≤10–15 sec target) then deeper on user request up to 10 sec per position. These are engineering budgets, not engine-strength claims. Tune on baseline devices before release.
- **Clocked bot games:** use actual remaining times/increment via UCI clock controls; maintain safety margin so worker overhead does not cause artificial flag fall. If the engine is unexpectedly slow, pause local clock only under documented engine-failure recovery, not to benefit a player in a rated match (V1 has none).

## 12.4 Evaluation and WDL

- Store `scoreType = cp | mate`, `perspective = side-to-move/White/Black`, depth, nodes, elapsed, PV and engine version.
- Convert to White/mover perspective in one tested analysis utility; never apply sign changes ad hoc in UI.
- Keep mate separate from centipawns. Do not turn `mate in N` into a plain pawn number for user display.
- WDL is optional and shown only if supported/valid; label as model estimate for engine/self-play conditions, not personal win probability.
- Engine evaluation is never a game result adjudicator; rules layer handles checkmate/draw. Engine “forced mate” text must say engine found a mate line unless exact proof exists.
- No claim that setting `UCI_Elo`/Skill Level equals a human’s validated Elo. Use labels `relaxed / casual / challenging` and help text “approximate engine setting.”

## 12.5 Bot strength behavior

- Query supported options at runtime; use official Stockfish strength controls when present and tested.
- Do not custom-randomize illegal moves or deliberately make a “human blunder” without a defined training setting.
- If a weak bot chooses among candidates, candidate generation/selection must remain legal and reproducible for a saved game; record the option/seed if used.
- User interface shows no numeric Elo unless a separately validated calibration study exists. V1 uses descriptive levels only.

---

# 13. Performance Requirements

These are **V1 acceptance targets proposed by this spec**, not measured guarantees. Baseline-device assumption: a mid-range Android phone with 4 GB RAM and current stable Chrome, plus a general laptop with 8 GB RAM and current stable Chrome/Firefox/Edge; include current iOS Safari in functional/accessibility tests. Benchmark on named physical devices before release and adjust only through a versioned change.

| Requirement | Target |
|---|---|
| Board input/render | Local legal move feedback ≤100 ms p95 after piece selection/commit on baseline device; no main-thread engine work |
| Rules move generation | Synchronous standard legal move/check/result queries feel immediate; if slow in measured complex positions, move heavy work to Worker without weakening validation |
| Local opening lookup | ≤100 ms p95 after data loaded |
| Engine Worker startup | Show progress; target ≤5 sec on baseline device after cached asset; first uncached download may take longer and is clearly stated |
| Engine responsiveness | Board navigation/UI remains responsive during all search; cancel acknowledgment target ≤250 ms (search stop may finish after) |
| Hint | First useful status/progress in ≤500 ms; result target ≤1.5 sec, with cancel and “still analyzing” state |
| Bot response | Target 0.2–2 sec for normal casual settings; hard cap 3 sec outside explicit long clock management; if budget expires, use current best legal engine candidate or pause/error according to policy—never fabricate move |
| Review | Default review targets ≤10 key positions and ≤15 sec total on baseline device; user can cancel and request deeper per position |
| Memory | One Engine Worker, 1 thread, 32 MB Hash default; measure total WASM/Worker/client memory on phone, guard against repeated Worker leaks |
| Offline | After first successful cache, app shell + bundled content + selected engine/datasets work offline; test airplane-mode flow |
| Dataset/lookup | No external API is required for a board move, local opening recognition, puzzle, or saved-game review |

A release report must identify device/browser used and measured p50/p95/max for board responsiveness, engine startup, hint, bot response and review. Do not advertise targets as universal performance claims.

---

# 14. Testing Requirements

## 14.1 Chess rules and domain tests

- Standard start position perft counts: depth 1=20, depth 2=400, depth 3=8,902, depth 4=197,281.
- FEN round-trip: all six fields, valid/invalid castling and EP state, custom start, halfmove/fullmove counters.
- SAN: disambiguation, captures, check/checkmate suffix, castling, promotions/underpromotions, ambiguous legal pieces.
- UCI move serialization/parsing including promotion; distinguish UCI move strings from UCI commands.
- Castling: King/rook moved then returned; blocked path; King in check; attacked transit/destination; rook attacked; attacked rook transit square; rights in FEN/history.
- En passant: immediate-only; missed opportunity expires; captured pawn removed correctly; illegal if own King exposed; legal EP included in repetition identity only when actually possible.
- Promotion: all four choices, capture promotion, check/mate suffix, no missing promotion choice.
- Check/checkmate/stalemate: no illegal response, no King capture, all evasions (capture/block/move) covered.
- Dead position: known dead examples, known non-dead material examples, no false “insufficient material” shortcut; rules-version regression tests.
- Repetition: same board with different side/castling rights/EP rights is not same key; same position with irrelevant clocks is same key; threefold claim current and intended move; fivefold automatic.
- Fifty/seventy-five: pawn move/capture resets halfmove clock; 100 halfmoves is claimable; 150 is automatic; final-move checkmate takes precedence; intended-move claim does not commit move.
- Timeout: opponent possible-mate vs impossible-mate draw edge cases; resignation/dead-position handling.
- Result reason: mate, stalemate, dead position, claim, automatic draw, resignation, timeout, agreement and abort never collapse to one label.
- Move transaction: undo/redo in allowed modes; finished game cannot mutate; branch does not edit original.

## 14.2 Engine tests

- UCI state machine: `uci/uciok`, `isready/readyok`, options, `ucinewgame`, `position`, `go`, `stop`, `bestmove`, worker error/restart.
- Position synchronization from startpos+UCI history and custom FEN; move history included when available.
- Score sign normalization from side-to-move to White/mover; mate vs cp; WDL omitted if unsupported.
- MultiPV sort/order; PV moves all legal; bestmove legal in current state.
- Stale response ignored on navigation/branch/new game/Worker restart; request ID + hash tests.
- Stop and cancel behavior; engine never runs on main thread; page remains interactive while search runs.
- Difficulty option fallback only to supported, documented options; no invented Elo mapping.
- Worker crash/invalid protocol line leads to safe error, not silent board mutation.

## 14.3 Knowledge/intelligence tests

- Opening exact sequence, alias/transposition, multiple possible labels, unknown line, custom FEN with missing history, move-order not unique.
- Opening hierarchy/version/source/provenance displayed; “typical plan” missing data omitted; opening popularity never relabeled as engine-best.
- Gambit accepted/declined based on actual move; temporary recapture nuance; functional offer vs ordinary tactical sacrifice; no good/bad status without evidence.
- Pawn structures for IQP, hanging, doubled, backward, chain, passed/connected, Carlsbad, Maroczy, Hedgehog, French, Benoni, Dutch Stonewall, majority/minority; test counterexamples/structure changes.
- Strategy relevance gates: a definition cannot render without matching position evidence; illegal candidate plan rejected.
- Tactics: one positive and one visually similar negative example per motif; best defensive reply, recapture, king escape, promotion and stalemate alternatives; label downgraded to candidate when unstable.
- Attack/defence prioritization: immediate mate threat outranks generic plan; remove attacker/luft/interposition/counterattack only when line is legal and relevant.
- Endgames: opposition only when tempo supports; exact Lucena/Philidor/Vancura geometry; wrong-colour bishop; opposite bishops not auto-draw; fortress only candidate without proof.
- Explanation claims trace to evidence IDs; no generated line without rules validation; forbidden-intent phrasing blocked.

## 14.4 Data, UI, accessibility, offline and security tests

- PGN import/export: standard tags, comments, variations, result, custom FEN, malformed/truncated PGN, Unicode names, oversized file, unknown variants.
- FEN import error boundaries; parser crash containment; no HTML/script execution from comments.
- IndexedDB transaction, quota, schema migration, refresh/reopen, delete/export, corrupted record recovery.
- PWA install/cache/update; first load vs offline after install; offline engine asset missing; service worker update not corrupting data.
- E2E for all modes including hints/takebacks visibility; challenge mode hides evaluation; finished game review only.
- Accessibility: keyboard-only, screen reader names/status, visible focus, click-select-click, contrast/color-only, target size, zoom, reduced motion, mobile promotion dialog.
- Responsive browser tests: current Chrome/Edge, Firefox, Safari desktop; current Android Chrome/iOS Safari baseline. Record unsupported behavior clearly.
- Security: malformed FEN/PGN, path/command injection, XSS comments, untrusted imported URLs, engine worker crash, stale messages, dependency audit.

---

# 15. Security, Reliability and Privacy

- Treat PGN/FEN, comments, player names, file names and imported game links as untrusted input.
- Enforce import size and parser operation limits; validate every move. Do not execute PGN comments/HTML or accept arbitrary UCI commands from user data.
- Use Content Security Policy appropriate for self-hosted scripts/WASM/Worker; no unsafe eval unless formally reviewed and required by chosen engine package.
- Worker message schema is validated; engine output is parsed as text, bounds-checked and rules-validated before use.
- IndexedDB corruption/quota failure must not silently delete games; provide retry/export/reset options and versioned migrations.
- Stale analysis cannot overwrite current board; every response tied to position hash/request generation.
- V1 has no remote multiplayer endpoint; no game telemetry or AI training upload by default.
- Future backend must add authentication/authorization, input limits, engine resource quotas, Origin validation, rate limiting and server-side move validation.
- No automated cheating accusation, player profiling or “intent” classification.

---

# 16. Accessibility Requirements

V1 aims for WCAG 2.2 AA across application screens, with documented exceptions only where a specific success criterion’s scope/exception genuinely applies. Board remains usable without color perception, drag input or audio.

- Keyboard access to every action; keyboard-selectable board squares and legal destinations.
- Click-select-click alternative to drag; visible drag/tap state.
- Piece/square names, move list and status as text; screen-reader announcement for move, check, game end and errors; avoid noisy clock updates.
- Focus visible and not hidden behind board overlays; modal promotion/hints trap/return focus correctly.
- Legal-move, check, selected, last move, threat and hint use redundant non-color cues (shape/icon/text/border).
- Contrast, zoom/reflow, target size, reduced motion, language declaration, labels/errors, untimed training default.
- Mobile portrait and landscape tests; board controls do not overlap squares.
- Board library accessibility claims are not accepted without manual/automated audit. If `react-chessboard` cannot meet requirements, provide an accessible wrapper or replace component before V1 release.

---

# 17. Licensing and Attribution

## 17.1 V1 license policy

| Asset/dependency | Required policy |
|---|---|
| Stockfish 19 WASM | GPLv3 compliance decision before bundling. Include required notices, corresponding source/source pointer, version/build details and NNUE network obligations as applicable. Worker separation is not a legal exemption. |
| chess.js | BSD-2-Clause notice preserved; pin audited version. |
| React / Vite / TypeScript / react-chessboard | Verify exact distribution/notice files and transitive dependency licenses during implementation; retain notices. |
| Lichess opening names | CC0/public-domain attribution recommended and dataset version recorded. |
| Lichess puzzle export | CC0 for the selected database export; retain provenance/version and verify selected source is the CC0 export, not broadcast PGNs with another license. |
| Piece art, icons, fonts, sounds | Use original or explicitly permissive licensed assets; record source/license. Do not reuse Chess.com/Lichess proprietary visual assets. |
| Lesson copy/diagrams | Write original explanations/examples or use data with explicit compatible license. Public educational page does not grant permission to copy it wholesale. |

## 17.2 Release gates

1. Generate dependency inventory/SBOM and license notice file.
2. Confirm project distribution model accepts GPLv3 obligations for Stockfish. If not approved in writing, block engine bundle/build; do not silently swap engine or assume process isolation removes obligations.
3. Verify exact Stockfish version, WASM build, NNUE asset and source correspondence.
4. Verify all opening/puzzle data are the specified CC0 collections and filtered files retain provenance.
5. Run legal review for third-party APIs, branding, downloaded PGNs and any future user-data/cloud processing.

This section is an engineering compliance checklist, not legal advice.

---

# 18. Future Multiplayer Direction

Human multiplayer is **not V1**. If later approved, it is a separate server-backed phase, not a toggle on the local engine game.

- Server is authoritative for legal moves, clocks, draw claims, game result and event order.
- Client can render optimistic moves but must reconcile/reject from server; store monotonic sequence/version and idempotent command IDs for reconnects.
- Use authenticated WebSocket/HTTPS, Origin allowlist, per-game authorization, message schema/size limits and rate limiting; protect engine resources.
- Competitive live mode must not show engine, PV, evaluation, opening explorer/popularity, hint buttons or AI-generated coaching. Disable relevant Worker/action paths in mode policy, not only hide buttons.
- Once server confirms game complete, offer separate post-game Review mode. Human move analysis never overlays a live match.
- No V1 social clone: no chat, tournaments, matchmaking, rating ladder, public profiles, clubs or automated cheating allegations.
- Future milestone must separately specify server ops, moderation/safety, fair-play policy, privacy/retention, load/cost, abuse and legal review.

---

# 19. Roadmap and Scope Control

## V1 — required product proof

- Responsive Hindi-first React/TypeScript PWA; installable/cacheable app shell.
- Standard chess domain/rules, canonical move history, FEN/PGN/SAN/UCI handling, clocks and correct game results/draw semantics.
- Local Play vs Engine (Challenge + Coached Practice), subject to GPL gate.
- Learn: small original curated rules/tactics/strategy/opening/endgame starter lessons.
- Practice: free board, set position, branch/undo, user-requested analysis.
- Review: saved/imported PGN, bounded engine review, key moments, line replay, retry branch.
- Puzzle/Training: filtered CC0 subset, core motifs, hints/retry/progress.
- Opening Training/Recognition: local dataset, family/variation confidence, gambit status, typical-plan cards only where curated.
- V1 intelligence: reliable board facts; common tactics/king safety; common pawn structures and selected endgame patterns; candidate vs engine-supported labeling.
- Local IndexedDB, export/delete, offline mode, accessibility/security/test gates.

## V1.5 — only after V1 correctness and user tests

- Broader tactical/mate-pattern coverage and more Chess Atlas structures.
- Personalized review-to-puzzle queue and simple repeated practice.
- More endgame motifs and curated opening micro-courses.
- Opening Explorer stats via an official, verified API or licensed local data; source/sample count/cache/offline fallback.
- Optional account/cloud sync only after privacy design and consent.

## Future / not commit to yet

- Human online games, matchmaking, rating, social/community/tournaments.
- Live assistant/anti-cheat features (live engine help remains prohibited; no cheating accusation system).
- General LLM chess coach; only evidence-bounded natural-language layer after validation study.
- Chess960/variants, tablebases/full endgame solver, large cloud-engine fleet.
- Exhaustive opening theory, full commercial game database, repertoire automation.
- Public accuracy/Elo ranking or personality/intent inference.

---

# 20. Explicit Non-Goals — Coding Agent MUST NOT Build in V1

1. No source code or implementation work as part of this specification phase.
2. No human matchmaking, live rated games, chat, tournaments, social feed, profiles or ranking ladder.
3. No engine/hint/book/evaluation assistance in any live human competitive game—now or as a hidden feature flag.
4. No LLM-generated move advice or free-form “what opponent was thinking” claims.
5. No forced opening, tactic, strategy, attack, defence or endgame label without evidence/confidence gate.
6. No claim that a pawn offer proves a good gambit or a material loss proves a bad gambit.
7. No accuracy % as sole skill score, no invented human Elo mapping for Stockfish strength controls.
8. No claim that an opening is best because it is popular or that engine-best equals common plan.
9. No live dependency on unverified Lichess Opening Explorer auth/quota or any third-party API for core V1.
10. No full opening-theory catalogue promise; cover curated common families and use a versioned dataset index.
11. No copied proprietary lessons/diagrams/piece art/PGN dataset without compatible license.
12. No GPL component hidden in a Worker as a licensing workaround.
13. No backend/account/cloud sync unless separately approved; local-first is default.
14. No variants, tablebases, server-scale infrastructure, AI training pipeline or anti-cheat before separate specification.
15. No random/illegal fallback bot move when engine fails; pause/report/recover safely.
16. No automatic-queen-only promotion; underpromotion must be selectable.
17. No “insufficient material” shortcut that misrepresents dead-position rules.
18. No silent repair of malformed PGN/FEN, no silent game-history loss, and no false repetition claim from FEN alone.

---

# 21. Traceability to the Two Research Foundations

- **Master Research:** rules/FIDE semantics §§3–4; product UX/modes §§5.1–5.7; tactical/strategy taxonomy §6; Stockfish/UCI §7; opening/API boundary §8; accessible UX references §9; dependencies/licenses §10; architecture/multiplayer §11; performance/security/accessibility/tests §12; roadmap §13; intent/governance §14; open decisions §15.
- **Chess Atlas:** opening map §§1.1–1.6; gambits §2; strategy and pawn structure §3; tactics/mates §4; attacks §5; defence §6; endgames §7; in-game recognition §8; Chess Game Master recommendations §9.
- Where Master Research marked API quota/auth or final audience/platform as unverified/open, this spec uses local-first PWA and local opening data as V1 defaults; external API remains optional future work.
- Where the Atlas catalog is necessarily non-exhaustive, this spec uses its families/motifs as taxonomy and does not promise every line or an unsupported named variant.
- Where Stockfish’s GPLv3 license conflicts with a possible closed-source distribution model, this spec exposes an explicit pre-build approval gate instead of silently choosing a legal interpretation.

---

# 22. Implementation Contract for the AI Coding Agent

## 22.1 Required stack

- **Client:** React + TypeScript responsive web application, built as an installable PWA; Vite is the V1 build-system recommendation.
- **Board:** `react-chessboard` candidate with required accessibility wrapper/audit; replacement requires same behavior and permissive license approval.
- **Chess rules:** `chess.js` (BSD-2-Clause) for standard legal move operations plus a domain `RulePolicy` layer for FIDE claim/automatic draws, repetition history, dead-position adjudication, result reasons and clock semantics. Audit library behavior; do not assume a helper covers full FIDE rules.
- **Engine:** Stockfish 19 WebAssembly in a Dedicated Web Worker through a typed UCI adapter, **only after GPLv3 approval and notices/source plan**.
- **Persistence:** IndexedDB for games/progress/analysis; localStorage only small preferences; no backend in V1.
- **Data:** Local Lichess CC0 opening-name dataset and selected CC0 puzzles; original curated Hindi content.

## 22.2 Required architecture

Implement separate modules/layers for:

1. Chess domain/game aggregate and rules adjudication.
2. Move notation/import/export adapters (FEN/PGN/SAN/UCI).
3. Mode/application services and permission policy.
4. Clock service.
5. Engine lifecycle/UCI Worker adapter.
6. Opening/gambit/pawn-structure/tactic/attack/defence/endgame knowledge repository and detectors.
7. Learning/progress store.
8. Evidence-bound explanation/review service.
9. IndexedDB repositories/migrations/export.
10. Accessible UI/PWA.

No UI component directly mutates FEN, performs engine protocol, or declares game result. Engine/LLM explanation never owns legality.

## 22.3 Required chess rules and data model

- Standard chess with correct check/attack semantics, castling history/attacked King squares, EP, all four promotions, SAN/UCI/FEN/PGN, move history, repetition, claimable/automatic draws, dead position, timeout mating-possibility rule and distinct termination reasons.
- Canonical game is initial position + committed legal moves + ruleset + event/result/clock metadata; final FEN is a snapshot only.
- FEN import marks prior move/repetition history unknown; PGN replay builds history.
- Claimable threefold/50-move rules are not automatically terminated; fivefold/75-move/dead/stalemate are automatic under selected FIDE policy; mate precedence is correct.
- Game records/analysis store engine/dataset/rules versions needed to reproduce output.

## 22.4 Required intelligence and UX principles

- Keep Game Facts, Engine Facts, Chess Knowledge, Learning Facts and Explanation separate.
- Opening hierarchy Family→Opening→Variation→Subvariation; transpositions supported; uncertain match returns unknown/structure resemblance, never forced named line.
- Gambit/strategy/tactics/attack/defence/endgame labels require current evidence; tactical pattern resemblance alone is not validation.
- All PV moves legal and tied to matching position hash/request ID.
- Wording uses “likely/possible/candidate/typical/engine-supported/confidence”; never asserts private human intent.
- V1 explanation is deterministic/curated; no general LLM.
- Human competitive live game: no engine, hints, opening explorer or live analysis. V1 does not build this mode.
- Learn/Practice/Puzzle/Opening Training/Review/Engine play follow §2 policies; mode badge and hidden/visible controls tested.
- No public Elo/accuracy/strength promise.

## 22.5 Required data and offline behavior

- IndexedDB schema/migrations for games, move history, analysis, puzzles, opening training, progress, annotations and saved positions.
- LocalStorage only small preferences.
- Local export/import PGN/FEN; malformed input safe; delete/export-all available.
- PWA caches app shell and selected licensed assets; saved games and core local modes work offline after first cache.
- External API cannot be a core dependency. Offline/network failure does not block board moves or local review.

## 22.6 Required engine constraints

- One Worker, one thread, bounded hash/search, asynchronous UCI lifecycle, progress, stop/cancel, generation IDs, stale response rejection, position synchronization, score normalization and safe crash behavior.
- Initial provisional budgets in §12.3 must be benchmarked; board remains responsive. Do not represent Skill Level/UCI_Elo as verified human rating.
- Engine Worker and WASM comply with GPL gate; no silent fallback move.

## 22.7 Required testing and accessibility

- Pass every rule, draw, repetition, castling, EP, promotion, SAN/PGN/UCI/FEN and clock test in §14.1.
- Pass UCI Worker, stale-result, crash, eval-perspective and legality tests in §14.2.
- Pass knowledge false-positive, evidence, confidence, transposition and line-validation tests in §14.3.
- Pass import/security/IndexedDB/offline/mobile/end-to-end/accessibility tests in §14.4.
- Keyboard-only operation, click-select-click, screen-reader text, visible focus, non-color cues, touch targets and promotion usability are release blockers.
- Produce test report and perft confirmation; do not substitute mocked legal move logic for integration tests.

## 22.8 Licensing/performance/non-goals

- Complete license/SBOM/asset attribution review before distribution. If GPLv3 approval is absent, block Stockfish bundling and request owner decision; do not bypass.
- Meet §13 initial performance budgets on named baseline device, or document approved adjustment before release.
- Do not implement items in §20.
- No human multiplayer in V1; no service or storage backend unless this contract is revised.

## 22.9 Definition of Done

V1 is done only when:

1. All modes work with the visibility/hint/takeback policies in §2.
2. Standard chess moves and endings pass rules/perft/regression tests; game history/result is replayable from storage.
3. FEN/PGN/SAN/UCI round-trip correctly within declared V1 scope; FEN-only history limitations are shown honestly.
4. Engine analysis runs only in Worker, can be stopped, cannot block UI, and stale outputs never affect current state.
5. Opening/gambit/strategy/tactic/attack/defence/endgame outputs are evidence-backed and confidence-gated; no unsupported human-intent or Elo claim.
6. Review shows played move, candidate, relevant line, concept, short explanation and retry for every surfaced key moment.
7. IndexedDB persistence, export/delete, offline reload and migration tests pass.
8. Accessibility, mobile, malformed import, engine failure, storage failure and offline states pass acceptance tests.
9. GPL/data/asset dependency checks and notices are approved and included.
10. No live human competitive assistance or V1 non-goal has been implemented.

## 22.10 Final acceptance checklist

- [ ] Hindi-first, beginner-to-club learning flow works without account/network after first cache.
- [ ] User can Learn, Practice, Play vs Engine, Review Game, Puzzle/Training and Opening Training as separate modes.
- [ ] Challenge and Coached Practice are visibly distinct; evaluation/hints hidden in Challenge by default.
- [ ] No source code was written during this specification stage; implementation begins only after this contract is approved.
- [ ] FIDE claim/automatic draw behavior, dead position, timeout and termination reasons are explicit and tested.
- [ ] FEN is not treated as a complete game; repetition/history limitations are explicit.
- [ ] Openings include major/common minor branches; uncertainty/transposition handled; no forced label.
- [ ] Gambit merit is assessed by compensation and concrete lines, not pawn count/name.
- [ ] Strategic message explains why relevant to current position.
- [ ] Tactic labels follow forcing-line validation; unproven patterns remain candidate motifs.
- [ ] Attack/defence surfaces the most dangerous verified/engine-supported issue, not generic advice.
- [ ] Endgame patterns are shown only when exact geometry/material makes them relevant.
- [ ] Every explanation supports simple/detailed/advanced depth and avoids claims of human intent.
- [ ] Post-game analysis is reproducible by engine/version/budget and does not use accuracy as sole skill measure.
- [ ] PWA/local data, PGN/FEN portability, offline fallback and delete/export are verified.
- [ ] Licensing gate, dependency notices, accessibility tests, performance tests, security tests and regression tests are complete.
- [ ] V1 non-goals remain absent.

---

# 23. Primary References for Implementation Verification

The two workspace research documents remain the primary product/research source. These official or project-maintained references support rules, format, engine, license, data, accessibility and security checks; recheck version-sensitive material at implementation time.

- **FIDE Laws of Chess** (edition checked in Master Research; confirm amendments before coding): https://handbook.fide.com/chapter/e012023
- **PGN/FEN specification:** http://www.saremba.de/chessgml/standards/pgn/pgn-complete.htm
- **Stockfish 19 release:** https://stockfishchess.org/blog/2026/stockfish-19/
- **Stockfish UCI protocol/commands:** https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html
- **Stockfish source and GPL license:** https://github.com/official-stockfish/stockfish
- **Stockfish WDL model caveats:** https://github.com/official-stockfish/WDL_model
- **Lichess opening names dataset (ECO/name/PGN/position fields, conventions, CC0):** https://github.com/lichess-org/chess-openings
- **Lichess database and puzzle exports:** https://database.lichess.org/
- **Lichess fair-play policy:** https://lichess.org/page/fair-play
- **Chess.com fair-play policy:** https://support.chess.com/en/articles/8568369-what-do-i-need-to-know-about-fair-play-on-chess-com
- **Web Workers (MDN):** https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers
- **WCAG 2.2 (W3C):** https://www.w3.org/TR/WCAG22/
- **Chess.js repository/license:** https://github.com/jhlywa/chess.js/
- **React / TypeScript / Vite licenses:** https://github.com/facebook/react/blob/main/LICENSE · https://github.com/microsoft/TypeScript/blob/main/LICENSE.txt · https://github.com/vitejs/vite/blob/main/LICENSE
- **React chessboard candidate/license:** https://github.com/clariity/react-chessboard
- **Chessground/chessops license references:** https://github.com/lichess-org/chessground · https://github.com/niklasf/chessops
- **OWASP WebSocket Security Cheat Sheet** (future multiplayer): https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html
- **Source taxonomy:** [Master Research](./Chess_Game_Master_Research_HI.md) · [Chess Atlas](./Chess_Game_Master_Chess_Atlas_HI.md)

---

## Final product statement

**Chess Game Master is a local-first, Hindi-first chess learning application that combines correct standard-chess rules, a playing engine, curated chess knowledge and post-game practice to help players understand positions. It reports what the board and validated analysis support, distinguishes candidate ideas from verified continuations, never claims to know a human opponent’s private intent, and never provides live engine assistance in human competitive play.**