import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    target: 'es2022',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/chess.js')) return 'chess';
          if (id.includes('node_modules/react')) return 'react';
        },
      },
    },
  },
  server: {
    host: '0.0.0.0',
    strictPort: true,
    allowedHosts: true,
  },
  preview: {
    host: '0.0.0.0',
    strictPort: true,
    allowedHosts: true,
  },
});
