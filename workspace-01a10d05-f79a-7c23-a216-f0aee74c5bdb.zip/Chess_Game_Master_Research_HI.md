# Chess Game Master Specification के लिए Research Foundation

**स्थिति:** केवल research और product analysis — अभी कोई code नहीं बनाया गया।  
**Research cutoff:** 5 अक्टूबर 2026  
**उद्देश्य:** भविष्य की “Chess Game Master Specification” के लिए नियम, UX, engine, data, architecture, learning और risk की एक practical नींव बनाना।

> **कैसे पढ़ें**  
> **सत्यापित तथ्य** = FIDE, W3C या किसी project की अपनी documentation से जाँची गई बात।  
> **सिफारिश** = इस product के लिए प्रस्ताव; यह नियम या बाहरी तथ्य नहीं है।  
> **अभी सत्यापित नहीं** = implementation से पहले primary source में दोबारा जाँचना होगा।

---

## 1. एक पेज में निष्कर्ष

1. **शतरंज के नियम और game state को UI से अलग रखें।** बोर्ड केवल चाल दिखाए; नियम वाला component तय करे कि चाल legal है या खेल खत्म हुआ।
2. **FEN अकेले पूरी game history नहीं है।** FEN एक position बताता है; तीन बार एक ही position आने जैसी बातें जाँचने के लिए चालों का इतिहास भी रखना होगा।
3. **Opening database, chess engine और “खिलाड़ी की मंशा” तीन अलग चीजें हैं।** लोकप्रिय चाल का अर्थ engine की सबसे अच्छी चाल नहीं; engine की चाल का अर्थ किसी इंसान की असली मंशा नहीं।
4. **Stockfish को UI thread में न चलाएँ।** Web app में उसे Web Worker में चलाना बेहतर है। Stockfish 19 की आधिकारिक release में WebAssembly targets शामिल हैं; उसका license GPLv3 है। [1](https://stockfishchess.org/blog/2026/stockfish-19/) [1](https://github.com/official-stockfish/stockfish)
5. **मानव opponent के live game में engine/hint न दिखाएँ।** Lichess और Chess.com दोनों चल रहे human games में बाहरी engine मदद को रोकते हैं; Chess.com Live में किसी भी बाहरी सहायता की अनुमति नहीं बताता। [1](https://lichess.org/page/fair-play) [1](https://support.chess.com/en/articles/8568369-what-do-i-need-to-know-about-fair-play-on-chess-com)
6. **V1 के लिए सिफारिश:** responsive Web/PWA, standard chess, local game save, user-vs-engine practice, post-game review, opening-name lookup और चुने हुए puzzles। Human matchmaking, public opening API और AI द्वारा “वह यही सोचना चाहता था” जैसे दावे बाद के चरण में रखें।
7. **Lichess Opening Explorer की मौजूदा auth/quota शर्तें इस research में primary documentation से सत्यापित नहीं हुईं।** इसलिए V1 को उस online API पर निर्भर न करें; implementation से ठीक पहले official API contract जाँचें।
8. **“Accuracy 92%” को खेल-कौशल का सार्वभौमिक score न बनाएँ।** Engine version, search depth, score-conversion और product की labels बदलने से परिणाम बदल सकते हैं। Chess.com भी quick और deeper review में labels बदल सकने की बात कहता है। [5](https://support.chess.com/en/articles/11845102-why-did-my-move-classification-change-in-game-review)

---

## 2. दायरा और प्रस्तावित assumptions

**तथ्य:** अभी platform (web, mobile app), multiplayer launch, account system और target player level तय नहीं हैं। इन्हें fact मानकर architecture lock करना उचित नहीं होगा।

**सिफारिश:** नीचे का प्रारंभिक architecture **responsive web/PWA** को उदाहरण मानता है, क्योंकि इससे browser में बोर्ड, local persistence और WebAssembly engine एक साथ जाँचे जा सकते हैं। Rules/data model को platform-neutral रखें ताकि बाद में native client जोड़ा जा सके।

**प्रस्तावित product positioning:** “खेलो → अपने विचार आज़माओ → सही समय पर hint लो → game के बाद समझो।” केवल engine का best move दिखाना learning product नहीं बनाता; उस move का कारण, उपयोगकर्ता का अपना प्रयास और सही समय पर feedback भी जरूरी है। यह product recommendation है, किसी शोधपत्र का दावा नहीं।

---

## 3. शतरंज के नियम: product को क्या सही लागू करना होगा

मुख्य authoritative स्रोत FIDE Laws of Chess हैं। वे 1 जनवरी 2023 से लागू rules देते हैं। Digital app को FIDE के हर physical tournament procedure की नकल नहीं करनी, पर move legality, game result और चुने हुए draw नियमों को स्पष्ट रूप से लागू करना चाहिए। [1](https://handbook.fide.com/chapter/e012023)

### 3.1 बोर्ड और सामान्य चालें

- बोर्ड 8×8 है। files `a` से `h`, ranks `1` से `8`; standard starting position में White की पहली rank 1 और Black की पहली rank 8 है।
- **King:** एक square किसी भी दिशा में; attacked square पर नहीं जा सकता। King को capture नहीं किया जाता।
- **Queen:** file, rank या diagonal पर कोई भी दूरी; बीच में piece हो तो उसके ऊपर से नहीं जा सकती।
- **Rook:** file या rank पर कोई भी दूरी; बीच के pieces से नहीं गुजर सकती।
- **Bishop:** diagonal पर कोई भी दूरी; बीच के pieces से नहीं गुजर सकता।
- **Knight:** “L” आकार में चलता है और बीच के pieces के ऊपर से कूद सकता है।
- **Pawn:** खाली आगे वाले square पर एक कदम; अपनी starting rank से पहली चाल में रास्ता साफ हो तो दो कदम; सामान्य capture एक कदम आगे तिरछा। Pawn पीछे नहीं जाता।
- अपने King को check में छोड़ने वाली चाल illegal है। Check का उत्तर देना जरूरी है—King को हटाना, checking piece को capture करना, या बीच में block करना, यदि legal हो।
- FIDE में किसी piece को “square पर हमला करता है” माना जा सकता है, भले वह piece अपने King को check में छोड़ने के कारण स्वयं वहाँ जा न सकता हो। इसलिए check/castling के लिए attack-test को साधारण “क्या यह legal move है?” से अलग सही implement करना जरूरी है। [1](https://handbook.fide.com/chapter/e012023)

### 3.2 तीन विशेष चालें

**Castling (`O-O` या `O-O-O`)**

- King और संबंधित rook पहले move न कर चुके हों; यदि वे move करके वापस आ गए हों, castling right फिर भी खो चुका है।
- उनके बीच के squares खाली हों।
- King अभी check में न हो, जिस square से गुजरता है वह attacked न हो, और जिस square पर पहुँचता है वह भी attacked न हो।
- Rook attacked हो या rook के गुजरने वाले square पर attack हो, इससे अपने-आप castling illegal नहीं होता; नियम King के squares पर लागू होता है।
- Engine/library में castling-rights को केवल वर्तमान piece placement देखकर न निकालें; वे history का हिस्सा हैं।

**En passant**

- Opponent के pawn ने अपनी starting rank से दो squares की चाल अभी चली हो और आपका pawn उसके बगल में हो तो अगली चाल पर ही en passant capture संभव है। मौका उसी चाल के बाद खत्म हो जाता है।
- Capture में पकड़ा गया pawn उस square से हटता है जहाँ वह वास्तव में था—यह सामान्य destination-square capture नहीं है।
- इस capture से अपना King खुली file/diagonal में आ सकता है; ऐसी स्थिति में en passant illegal है।

**Promotion**

- Pawn आखिरी rank पर पहुँचते ही उसी चाल में Queen, Rook, Bishop या Knight में बदलता है। चुनी गई piece पहले capture हुई हो, यह जरूरी नहीं।
- केवल Queen default कर देना कमजोर UX है; underpromotion कई positions में जरूरी है। Promotion dialog/keyboard selection में चारों विकल्प दें। [1](https://handbook.fide.com/chapter/e012023)

### 3.3 Checkmate, stalemate और game result

- **Checkmate:** King attacked है और उस खिलाड़ी की कोई legal चाल नहीं; attacker जीतता है।
- **Stalemate:** चाल चलने वाले खिलाड़ी की कोई legal चाल नहीं, पर उसका King check में नहीं; draw।
- **Dead position:** किसी भी legal चाल-श्रृंखला से दोनों में से कोई opponent को checkmate नहीं कर सकता; draw। इसे केवल “कम material है” कहकर अनुमान लगाने के बजाय rules engine/विशिष्ट rules logic से जाँचें। “Insufficient material” अक्सर इस व्यापक rule का सरल shorthand है, पर यह हर case का औपचारिक नाम नहीं।
- Resignation, draw agreement, draw claim, timeout और automatic draw के अलग termination reasons रखें। इन्हें एक सामान्य “Game over” में न मिला दें।
- समय खत्म होने पर सामान्यतः flag गिरने वाला खिलाड़ी हारता है; लेकिन यदि दूसरा खिलाड़ी किसी legal sequence में checkmate कर ही नहीं सकता, तो FIDE rule के अनुसार परिणाम draw हो सकता है। Resignation पर भी असंभव-mate वाली स्थिति में draw का अपवाद है। [1](https://handbook.fide.com/chapter/e012023)

### 3.4 Draw नियम: claimable और automatic को अलग रखें

FIDE नियमों में कुछ draws खिलाड़ी को **claim** करने होते हैं और कुछ अपने-आप होते हैं:

| स्थिति | FIDE नियम | Product में आवश्यक व्यवहार |
|---|---|---|
| तीन बार वही position | खिलाड़ी सही claim करे; कुछ स्थितियों में घोषित अगली चाल से तीसरी occurrence बननी हो तब भी claim किया जा सकता है | “Draw claim” केवल तब दें जब चालने का इतिहास इसकी अनुमति दे; वैकल्पिक रूप से claim-by-intended-move दें |
| 50-move rule | पिछली 50 चालें प्रत्येक खिलाड़ी ने पूरी की हों (कुल 100 half-moves) और इस दौरान pawn move/capture न हुई हो तो claim | Halfmove counter रखें; claim UI और claim procedure तय करें |
| पाँच बार वही position | automatic draw | पाँचवीं qualifying occurrence पर game समाप्त करें |
| 75-move rule | प्रत्येक खिलाड़ी की 75 चालें (कुल 150 half-moves) pawn move/capture के बिना पूरी हों तो automatic draw | Halfmove counter 150 half-moves तक पहुँचने पर लागू; अंतिम चाल checkmate हो तो checkmate precedence रखता है |
| Stalemate/dead position | automatic draw | game result और कारण अलग दिखाएँ |

तीनfold/50-move को automatic बनाना कई online servers में आम product convention है, लेकिन इसे FIDE OTB claim semantics के साथ चुपचाप न मिलाएँ। **सिफारिश:** ruleset का नाम/व्यवहार तय करें—उदाहरण के लिए `FIDE claim-based` या `online auto-draw`—और UI/help में बताएँ। V1 के learning/tournament-like mode के लिए FIDE claim-based व्यवहार अधिक शिक्षाप्रद है। [1](https://handbook.fide.com/chapter/e012023)

### 3.5 Digital game में clocks

**Clock state को board state से अलग रखें।** Basic time control में starting time, active player और increment/delay नियम होते हैं। उदाहरण `5+3` का अर्थ आम तौर पर पाँच मिनट और हर चाल के बाद तीन सेकंड increment है; UI में format साफ लिखें। FIDE Laws में chess-clock नियम हैं, लेकिन browser में चलने वाले clock को सही रखने के लिए product को अपने event semantics तय करने होंगे। [1](https://handbook.fide.com/chapter/e012023)

- Single-device practice में समय घटाने के लिए हर सेकंड counter घटाने के बजाय एक monotonic clock (`performance.now()` जैसी) से elapsed time निकालने की सिफारिश है। Tab background में जाने/वापस आने पर display को पुनः गणना करें।
- Increment कब जुड़ता है, move commit के पहले या बाद, यह एक ही जगह पर स्पष्ट तय करें और test करें।
- यदि भविष्य में दो लोग online खेलें, तो **server का clock authoritative** हो; client का timer केवल display हो। Reconnect पर server state से resync हो।
- V1 में base time + Fischer increment पर्याप्त है। Multiple time periods, delay/hourglass और tournament director controls बाद में रखें।

### 3.6 OTB बनाम digital interaction

FIDE touch-move, arbiter, clock press, illegal-move penalty और physical board orientation जैसी tournament procedures भी बताता है। Digital app में drag/drop को “touch-move” समझना ठीक नहीं होगा। नियमों का digital version लिखें: illegal move reject होगा, promotion confirm होगी, draw claim UI से होगा, और training mode में takeback केवल स्पष्ट practice सुविधा होगी।

---

## 4. Game state, FEN, PGN, SAN और UCI

### 4.1 एक canonical game record में क्या हो

**सिफारिश:** canonical record केवल “अब बोर्ड पर कौन कहाँ है” न हो। इसमें यह रखें:

| भाग | क्यों जरूरी है |
|---|---|
| Standard starting setup या custom starting FEN | Position को दोबारा बनाना |
| क्रमवार legal moves, ideally UCI-style source/destination/promotion | Replay, undo, branch, PGN export, repetition history |
| प्रत्येक move का SAN display value या उसे फिर से बनाने का तरीका | इंसान-पढ़ने योग्य move list |
| Current state: side to move, castling rights, en-passant status, halfmove/fullmove counters | सही legal move/draw checks |
| Position-history/repetition keys | तीनfold/fivefold repetition पहचानना |
| Time-control config, दोनों clocks, move timestamps | Game timeline और future online sync |
| Result + termination reason | Checkmate, resignation, timeout, draw claim आदि का भेद |
| Ruleset/variant + engine/version/settings metadata | Reproducible review, future variants |
| Players, date, language/annotations | PGN metadata, user history |

### 4.2 चार formats—चार अलग काम

| नाम | क्या है | इसका उपयोग |
|---|---|---|
| **FEN** | एक position का compact snapshot; piece placement, side to move, castling availability, en-passant target, halfmove clock, fullmove number—छह fields | Position share करना, puzzle शुरू करना, engine को position देना |
| **PGN** | Game record का text format; tags/metadata, चालें, परिणाम, comments और variations | Game import/export, archive, review |
| **SAN** | खिलाड़ी के लिए move notation, जैसे `Nf3`, `O-O`, `exd8=Q+` | Move list और PGN movetext |
| **UCI move notation** | Engine protocol में source-square → destination-square, जैसे `e2e4`, promotion `e7e8q` | Engine को चालें भेजना/उत्तर पढ़ना |
| **UCI protocol** | GUI और chess engine के बीच text commands/responses—`uci`, `isready`, `position`, `go`, `stop`, `bestmove` आदि | Stockfish integration; इसे UCI move string से अलग समझें |

FEN/PGN की formal definitions PGN specification में दी गई हैं। PGN moves के लिए SAN रखता है; engine protocol में position + UCI moves भेजना आम है। [2](http://www.saremba.de/chessgml/standards/pgn/pgn-complete.htm) [2](https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html)

**अहम सीमा:** FEN move history नहीं रखता। इसलिए एक ही FEN snapshot से यह नहीं पता चलेगा कि वही position पहले दो बार आई थी या नहीं। तीनfold claim जैसी जाँच के लिए FEN के साथ move history/repetition table चाहिए।

**Repetition key:** FIDE के “same possible moves” सिद्धांत के अनुसार piece placement, side-to-move, castling rights और वास्तविक legal en-passant possibility महत्त्वपूर्ण हैं। Halfmove/fullmove counters repetition identity नहीं हैं। ध्यान दें कि standard FEN en-passant field आखिरी double pawn push के बाद target square दर्ज कर सकता है, भले कोई legal en-passant capture उपलब्ध न हो; repetition key में इसे consistently normalize करें। इसीलिए library की FEN serialization और repetition semantics को बिना test किए एक जैसा न मानें। [1](https://handbook.fide.com/chapter/e012023) [2](http://www.saremba.de/chessgml/standards/pgn/pgn-complete.htm)

**Notation संबंधी सिफारिश:** UI में हिन्दी explanation, piece icon या local labels दिखाए जा सकते हैं; लेकिन PGN export/import के लिए standard English-piece SAN को ही canonical रखें। `O-O` castling में अक्षर O है, zero नहीं।

---

## 5. Learning-focused product UX: feature, कारण, तरीका, risk

### 5.1 Board और move interaction — **V1 में जरूरी**

- **क्या:** Responsive 2D board; click/drag/touch move; legal destinations; selected piece, last move, check और promotion state; move list; board flip.
- **क्यों:** बोर्ड main play surface है। सही move feedback शुरुआती खिलाड़ी को rules सीखने में मदद करता है।
- **कैसे:** Rules engine से legal destination लेकर UI में दिखाएँ; click-select-click और drag दोनों दें; move list, undo/redo (practice only), promotion picker और keyboard support रखें। UI state को rules state न बनाएँ।
- **जोखिम:** Legal-move dots, last-move highlight और check highlight एक ही रंग से दिखाने पर भ्रम होगा; promotion auto-queen हो सकती है; मोबाइल पर बोर्ड/clock/notation panel cramped हो सकते हैं। प्रत्येक visual cue का अलग रंग+shape/text रखें।

### 5.2 Game modes — **V1 में साफ separation**

- **क्या:** `Learn/Practice` (hints/takeback), `Play vs Engine` (difficulty/time controls) और `Review` (finished game analysis) को अलग modes बनाना।
- **क्यों:** Engine assistance स्वीकार्य और उपयोगी है जब उपयोगकर्ता सीखने के लिए bot से खेल रहा हो; human competitive game में वही सुविधा unfair external help बन सकती है।
- **कैसे:** Mode badge हमेशा दिखाएँ; practice mode में hints/undo चालू; bot-game में hints opt-in; किसी external human match को import करते समय analysis केवल game समाप्त होने पर।
- **जोखिम:** एक ही स्क्रीन में engine pane छुपाकर/दिखाकर mode बदलने से accidental assistance हो सकती है। Explicit mode boundary और data flow रखें। Lichess और Chess.com live human games में engine help को रोकते हैं। [1](https://lichess.org/page/fair-play) [1](https://support.chess.com/en/articles/8568369-what-do-i-need-to-know-about-fair-play-on-chess-com)

### 5.3 Opponent की चाल, threat और “intention” — **सीमित V1, गहरा काम बाद में**

- **क्या:** Bot/training mode में opponent की पिछली चाल के बाद उपयोगकर्ता को यह समझने में मदद कि क्या बदला, कौन-सा piece/square attacked है, कौन-सी forcing line दिख रही है और कौन-सा candidate response जाँचना है।
- **क्यों:** “सिर्फ best move” बताने के बजाय विचार प्रक्रिया सिखानी है—checks, captures, threats और opponent के जवाब देखना।
- **कैसे:** पहले उपयोगकर्ता से पूछें “पिछली चाल से क्या खतरा बना?”; फिर क्रमिक hints दें—(1) किस piece/square पर दबाव है, (2) forcing move का प्रकार, (3) एक legal line, (4) engine candidate. Explanation को actual legal variation, board facts और move history से जोड़ें।
- **जोखिम/सीमा:** Engine का principal variation (PV) मुख्यतः यह बताता है कि search में कौन-सी चाल/line मजबूत दिखी; वह खिलाड़ी के मन की मंशा पढ़ता नहीं। Engine PV को “opponent यही सोच रहा था” न कहें। “इस move से … का खतरा बन सकता है” या “engine की candidate line में … है” कहें। यदि कई plausible lines हों, uncertainty साफ दिखाएँ।
- **Implementation संकेत:** केवल आखिरी move की before/after evaluation पर्याप्त नहीं। संभावित defensive/quiet responses और उनके बाद opponent की forcing replies देखनी पड़ सकती हैं। Tactical detector + bounded engine search से प्रमाणित line बनाएँ; “pass move” मानकर झूठी threat न बनाएँ।
- **Fair-play सीमा:** यह coaching केवल user-vs-engine/training sandbox या game समाप्त होने के बाद दें। Chess.com/Lichess पर चल रहे human game के दौरान opening explorer, engine evaluation या move hint न दिखाएँ। [1](https://lichess.org/page/fair-play) [1](https://support.chess.com/en/articles/8568369-what-do-i-need-to-know-about-fair-play-on-chess-com)

### 5.4 Opening पहचान और opening explorer — **नाम V1; live stats बाद में**

- **क्या:** ज्ञात opening/variation का नाम, ECO code, position तक पहुँची चालें; आगे चलकर popular moves, game counts और परिणाम।
- **क्यों:** उपयोगकर्ता अपनी opening को पहचानता है और move-order/transposition सीखता है।
- **कैसे:** Local opening-name dataset को position-based lookup से चलाएँ। Opening stats चाहिए तो database source, rating/time-control filter, game count और timestamp दिखाएँ; response cache करें। Opening name, database frequency और engine evaluation को अलग-अलग labels दें।
- **जोखिम:** Opening names की सीमा fuzzy हो सकती है; transpositions से एक ही position कई move orders से मिल सकती है; global W/D/L rating/time control/source से bias हो सकता है। छोटे sample को “best move” न कहें।
- **V1:** Local opening name/closest known tag और opening line; external stats नहीं। Lichess का opening-name dataset ECO/name/PGN/UCI/position fields देता है और CC0/public domain के रूप में जारी है। [1](https://github.com/lichess-org/chess-openings)
- **UX reference:** Lichess Opening Explorer position name (transpositions सहित), popular moves, sample counts, results और related games दिखाने का उदाहरण है; यह pattern है, आपके product का API contract नहीं। [1](https://lichess.org/blog/Vs0xMTAAAD4We4Ey/opening-explorer)

### 5.5 Post-game review — **V1 का मुख्य learning loop**

- **क्या:** Game graph, महत्वपूर्ण moments, move feedback, candidate line, “फिर से कोशिश करें” और सरल explanation.
- **क्यों:** Finished game के बाद player बिना unfair live assistance के अपने निर्णय देख सकता है।
- **कैसे:** हर move के लिए before/after position analyze करें; mover के perspective को normalize करें; समान engine/version/settings उपयोग करें; checkmate scores को centipawns से अलग रखें। पहले खिलाड़ी से self-review कराएँ, फिर hints/line दिखाएँ। केवल 2–5 मुख्य moments को पहले surface करें; पूरा move list खोलने का विकल्प रहे।
- **जोखिम:** कमजोर search depth पर classification बदल सकती है; engine का “best” हमेशा इंसान की व्यावहारिक चाल नहीं; 0–100 score गलत आत्मविश्वास दे सकता है। Move labels product-defined हैं, chess नियम नहीं। Chess.com का Game Review graph, key moves, retry और predicted lines जैसे usable UX patterns दिखाता है; उन्हें UX reference मानें, algorithm specification नहीं। [1](https://support.chess.com/en/articles/8584089-how-does-game-review-work) [4](https://support.chess.com/en/articles/8572705-how-are-moves-classified-what-is-a-blunder-or-brilliant-etc)

### 5.6 Puzzles, lessons और difficulty — **V1 में छोटा, curated हिस्सा**

- **क्या:** Beginner rules drills, mate-in-one, simple tactics, tactical motifs, बाद में endgame/opening practice.
- **क्यों:** एक idea को छोटी position में दोहराना और game review की गलतियों को अभ्यास से जोड़ना आसान है।
- **कैसे:** Difficulty को केवल puzzle rating से न तय करें; solve correctness, hints, tries और समय जैसे signals मिलाएँ। Hint ladder दें; कई valid mate-in-one answers स्वीकारें; wrong move पर line समझाएँ। User की game mistakes से “review later” queue बाद के milestone में जोड़ें।
- **जोखिम:** Auto-tag गलत हो सकता है; “only move” puzzle में कई जीतने वाली चालें छूट सकती हैं; timer beginner को निराश कर सकता है। Untimed/default practice रखें, speed mode वैकल्पिक।
- **Data note:** Lichess puzzle database CSV में FEN, UCI moves, rating/deviation, popularity और themes जैसे fields हैं। Puzzle FEN में opponent की गलती से *पहले* की position रहती है; दिखाने से पहले `Moves` की पहली चाल apply करनी होती है; उसके बाद अगली चाल solver की पहली उत्तर-चाल है। Mate-in-one में एक से अधिक सही checkmate स्वीकार करना चाहिए। Lichess database exports CC0 हैं। [1](https://database.lichess.org/)
- **UX reference:** Lichess Learn by playing और theme-based puzzle pages; Chess.com lessons में openings, tactics, strategy, endgames और master games की structured categories—दो उपयोगी product patterns हैं। [1](https://lichess.org/learn) [1](https://lichess.org/training/themes) [1](https://www.chess.com/lessons)

### 5.7 User progress — **V1 में हल्का**

- **क्या:** कौन-से themes सही/गलत हुए, किन review positions को फिर देखना है, opening choices और practice streak जैसी जानकारी।
- **कैसे:** V1 में local profile/progress रखें; बाद में account/cloud sync। Statistics को “कौशल का प्रमाण” नहीं बल्कि practice signal कहें।
- **जोखिम:** User rating/personal game data sensitive हो सकते हैं; retention, deletion और export नीति बनानी होगी। दूसरे users के game data को बिना lawful source/terms के profile-building में न मिलाएँ।

---

## 6. Tactics और strategy की taxonomy

ये tags explanation और training में काम आएँगे; engine खुद आम तौर पर किसी position को हिन्दी में “यह fork है” कहकर नहीं समझाता। Tags legal move graph, board features, engine PV और curated examples से derive करने होंगे। Lichess puzzle themes में skewer, trapped piece, attraction जैसे motifs के अलग tags हैं। [1](https://lichess.org/training/themes)

### 6.1 Tactical motifs (अल्पकालिक, forcing sequence)

| समूह | उदाहरण | Explanation में क्या दिखाएँ |
|---|---|---|
| Double attack | Fork, pawn fork | एक move के बाद दो या अधिक targets पर हमला |
| Line tactic | Pin, skewer, x-ray | कौन-सी piece/line बँधी है; पीछे कौन-सा target है |
| Discovered attack | Discovered check, double check | कौन-सी piece हटने से कौन-सी line खुली |
| Defender/coordination | Overload, remove the defender, deflection, interference, clearance | कौन defender हटता/भटकता है और किस square/line पर असर पड़ता है |
| Forcing move | Check, capture, zwischenzug/intermezzo | सामान्य प्रत्युत्तर से पहले बीच की forcing चाल क्यों है |
| King attack/mating | Back-rank mate, smothered mate, mating net | legal escape squares और forced line |
| Material/tempo | Sacrifice, trapped piece, desperado | दिए गए material के बदले क्या concrete gain दिखता है |
| Pawn/endgame tactic | Promotion race, underpromotion, stalemate trick, zugzwang | promotion/tempo/forced legal move का परिणाम |

**सिफारिश:** Puzzle labels multi-label हों; उदाहरण में “fork + discovered attack” दोनों हो सकते हैं। किसी tag को तभी show करें जब उस tag को support करने वाली line या board evidence उपलब्ध हो।

### 6.2 Strategic concepts (दीर्घकालिक plan)

- **King safety:** pawn shelter, खुली lines, attack और defence की उपलब्धता।
- **Center/development/initiative:** center पर control, pieces विकसित हैं या नहीं, कौन side tempo/threat बना रहा है।
- **Piece activity/coordination:** सक्रिय piece, कमजोर piece सुधारना, outpost, bishop pair, good/bad bishop, pieces का एक साथ काम करना।
- **Pawn structure:** isolated/doubled/backward pawns, pawn chain/islands, passed pawn, pawn majority, weak squares/holes, pawn breaks, minority attack।
- **Files/space:** open या half-open files, rooks की activity, space advantage और opponent की cramped position।
- **Weakness/plan:** defend करने में कठिन pawn/square, खराब piece, king safety या endgame structure।
- **Endgame:** active king, opposition, passed pawn, rook activity, conversion, fortress और zugzwang।

**सावधानी:** “Doubled pawns खराब ही होते हैं” या “rook हमेशा open file पर होना चाहिए” जैसे absolute नियम गलत feedback देंगे। Strategy context-dependent है; हर structural feature को material/activity/king safety और concrete move से जोड़ें।

### 6.3 Engine से labels तक

**सिफारिश:** अलग confidence/quality स्तर रखें:

1. **निश्चित board fact:** “e-file खुली है”; “इस चाल से bishop attack में है।”
2. **Concrete search line:** “अगर आप यह शांत चाल चलें, engine line में अगली चाल पर fork आता है।” साथ में पूरा legal line दिखाएँ।
3. **Positional idea:** “संभव plan: weak square पर knight लाना।” यह engine evaluation + curated motif/content से निकला hypothesis हो सकता है; इसे certainty की तरह न कहें।
4. **Intent:** खिलाड़ी की मानसिक मंशा सीधे position से नहीं पढ़ी जा सकती। एक move से intent prediction को verified fact न बनाएँ।

---

## 7. Stockfish integration: सही तकनीकी व्यवहार

### 7.1 Stockfish क्या देता है—और क्या नहीं

**सत्यापित:** Stockfish 19 5 सितंबर 2026 को जारी हुआ; official release में WebAssembly targets और नए universal binaries का उल्लेख है। Stockfish chess engine है, rules/UI/lesson generator नहीं। [1](https://stockfishchess.org/blog/2026/stockfish-19/)

Engine आम तौर पर UCI के जरिए candidate move, score, depth, nodes और principal variation (PV) देता है। Official Stockfish docs `uci`, `isready`, `ucinewgame`, `position`, `go`, `stop`, options, `MultiPV`, `UCI_ShowWDL` आदि दिखाते हैं। Static `eval` command को official docs rough/no-search evaluation बताते हैं; वास्तविक analysis के लिए bounded `go` search चाहिए। [2](https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html) [2](https://official-stockfish.github.io/docs/stockfish-wiki/Developers.html)

**Interpretation:** `score cp` या `score mate` और PV engine output हैं—यह “मानव opponent ऐसा सोचेगा” या “यह पक्का जीत है” नहीं। Stockfish का WDL (Win/Draw/Loss) model self-play/fishtest conditions से calibrated है; यह किसी खास मानव की वास्तविक win probability नहीं। Score और WDL को model estimate के रूप में label करें, absolute fact के रूप में नहीं। [1](https://github.com/official-stockfish/WDL_model) [1](https://official-stockfish.github.io/docs/stockfish-wiki/Useful-data.html)

### 7.2 Browser architecture और UCI lifecycle

**सिफारिश:** Engine को `Worker` में रखें; main thread केवल UI/rendering करे और Worker से messages ले। MDN के अनुसार Worker background thread में काम करता है, DOM को सीधे manipulate नहीं करता और `postMessage()` से communication करता है। [1](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers)

Conceptual lifecycle:

1. Stockfish WASM/engine Worker load करें; `uci` भेजें; `uciok` आने तक initialize करें।
2. `isready`/`readyok` से readiness confirm करें; नए game पर `ucinewgame` दें।
3. Position को `position startpos moves …` या `position fen …` से भेजें। पूरी game उपलब्ध हो तो initial setup + move history भेजना bare final FEN से बेहतर है—engine repetition context रख सकेगा।
4. `go depth`, `go nodes`, `go movetime`, या game clock के साथ `go wtime/btime/winc/binc` जैसी सीमित search दें।
5. `info` lines से depth, multipv, cp/mate, WDL, PV दिखाएँ; `bestmove` को domain rules engine से validate करें।
6. नई position/route change पर पुरानी search रोकें (`stop`) और पुराने response को generation/request id से discard करें; देर से आया result नई position को overwrite न करे।
7. `score` का perspective normalize करें; Stockfish-style search score अक्सर side-to-move perspective में होता है। White/mover perspective में conversion और mate sign के tests रखें। [2](https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html) [2](https://python-chess.readthedocs.io/en/latest/engine.html)

**Resource सिफारिश:** V1 में one worker, 1 thread, सीमित Hash और bounded node/time budget से शुरू करें; mobile CPU/battery पर test करें। SharedArrayBuffer/multithreaded WASM को V1 dependency न बनाएँ; browser shared memory के लिए secure cross-origin isolated context चाहिए। [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer)

### 7.3 Bot strength और post-game score

- Stockfish में `Skill Level`, `UCI_LimitStrength`, `UCI_Elo` जैसे options उपलब्ध हो सकते हैं; engine options को runtime पर query करें, hard-code नहीं। Stockfish स्वयं strength calibration को particular benchmark time control से जोड़ता है। इसलिए user-facing “~1200 strength” को approximate कहें, rating guarantee नहीं। [2](https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html) [3](https://official-stockfish.github.io/docs/stockfish-wiki/Stockfish-FAQ.html)
- Post-game move loss की एक उपयोगी internal परिभाषा: **उस खिलाड़ी के perspective से pre-move best evaluation और actual move के बाद की evaluation का अंतर**। दोनों का score perspective normalize करें; comparable engine/version/search budget रखें; mate को अलग semantic case मानें। यह product metric है, official chess rule नहीं।
- Move labels (`best/good/inaccuracy/mistake/blunder`) product policy हैं। Threshold, engine version, search budget और methodology दर्ज करें। Chess.com का Expected Points model उसका अपना design है; उसे copy करने की जरूरत नहीं। [4](https://support.chess.com/en/articles/8572705-how-are-moves-classified-what-is-a-blunder-or-brilliant-etc)
- Accuracy को rating या इंसान की chess understanding न बताएँ। “महत्वपूर्ण 2 moments” और “इस line में क्या बदला” अक्सर एक अकेले percentage से ज्यादा सीखने योग्य हैं।

---

## 8. Opening recognition और statistics

### 8.1 नाम lookup

**V1 प्रस्ताव:** Bundle में छोटा/साफ opening-name dataset रखें। Move sequence और normalized position दोनों से lookup करें; transposition मिलने पर “इस position को इस known opening/line से भी पहचाना जाता है” दिखाएँ। Unknown line में “Opening अभी पहचानी नहीं गई” कहना गलत नाम देने से बेहतर है। Lichess `chess-openings` dataset में ECO, English name, PGN/UCI move sequence और EPD position fields हैं; project इसे facts collection/public domain तथा CC0 बताता है। [1](https://github.com/lichess-org/chess-openings)

### 8.2 Book popularity और engine recommendation

UI में signals को अलग रखें:

- **Opening database:** कितने games में कौन-सी चाल खेली गई; sample size, source, player/time-control filters और W/D/L.
- **Engine:** अभी की position में engine candidate/PV/evaluation.
- **Opening name:** position classification.

“सबसे popular” का अर्थ “सबसे अच्छी” नहीं। W/D/L database के खिलाड़ियों, rating, time control, data period और selection bias से प्रभावित होते हैं। Small sample को छुपाएँ नहीं। Lichess Opening Explorer position-wise popular moves, average rating/number of games और results दिखाने का एक UX उदाहरण है। [1](https://lichess.org/blog/Vs0xMTAAAD4We4Ey/opening-explorer)

### 8.3 Third-party API: अभी खुला जोखिम

- Lichess का general API reference requests rate-limited होने और controlled access की सलाह देता है; लेकिन इस research में Opening Explorer के current token/auth, exact quotas और availability contract को primary source से confirm नहीं किया गया। [Lichess API](https://lichess.org/api)
- Web search में third-party summaries ने 2026 में Explorer auth बदलाव की बातें कीं, पर उन्हें verified fact नहीं माना गया। **Open item:** Implementation के समय official current OpenAPI/docs और actual response headers जाँचें; API optional रखें, cache/fallback रखें, हर move पर request न करें।
- Chess.com Published-Data API public data का **read-only** API है; उससे Chess.com को चालें भेजना संभव नहीं। उसके caching headers/serial request guidance मानें और parallel load में 429 का ख्याल रखें। [1](https://www.chess.com/news/view/published-data-api)

---

## 9. Existing products से सीखने योग्य UX patterns

यह section feature inspiration है, किसी दूसरे product का exact implementation या licensing permission नहीं।

| Product pattern | उपयोगी सीख | स्रोत |
|---|---|---|
| Lichess “Learn chess by playing” | Beginner को छोटे action से सीखने देना | [1](https://lichess.org/learn) |
| Lichess puzzle themes | Fork, skewer, trapped piece जैसी categories में अभ्यास | [1](https://lichess.org/training/themes) |
| Lichess analysis/opening explorer | Move list + position + opening data साथ, transposition और related games | [1](https://lichess.org/analysis) [1](https://lichess.org/blog/Vs0xMTAAAD4We4Ey/opening-explorer) |
| Chess.com Game Review | Game graph, key moments, engine lines, retry, guided feedback | [1](https://support.chess.com/en/articles/8584089-how-does-game-review-work) |
| Chess.com structured lessons | Opening, tactics, strategy, endgame और master-game learning paths | [1](https://www.chess.com/lessons) |

**सिफारिश:** उपयोगी interaction patterns अपनाएँ—critical moments पर retry, line replay, progressive hint, result graph—पर दूसरे product के logo, piece art, sounds, exact visual identity या proprietary copy को बिना permission न अपनाएँ। Open-source code और public data के licenses अलग-अलग जाँचें।

---

## 10. Open-source libraries, engines और data

| विकल्प | काम | License/स्थिति (जाँची गई) | सीमाएँ/सावधानी | प्रस्ताव |
|---|---|---|---|---|
| `chess.js` | TypeScript/JS move generation, validation, position और check/checkmate/stalemate | BSD-2-Clause; repo इसे “everything but the AI” कहता है | UI/engine नहीं; exact draw-claim policy और repetition key को अपनी rules layer में परखें; version pin करें | V1 rules foundation के लिए अच्छा permissive starting point |
| `react-chessboard` | React board interaction/rendering | npm पर research समय version 5.12.1, MIT; repo accessibility feature claim करता है | Accessibility claim WCAG audit नहीं; keyboard, screen-reader, mobile, promotion और 64-square focus खुद test करें | React web चुनें तो पहले evaluate करें; gap हो तो custom board या alternative |
| `Chessground` | Lichess का powerful board UI | GPL-3.0-or-later; repository कहता है combined website work को GPL पर distribute/source release करना होगा | Closed-source/commercial product के लिए legal review जरूरी | V1 में तभी जब GPL-compatible strategy हो |
| `chessops` | TypeScript chess operations, FEN/SAN/PGN/UCI और variants | GPL-3-or-later | Copyleft; standard board component नहीं; license impact देखें | Variant/feature need और open-source licensing स्वीकार होने पर evaluate करें |
| Stockfish 19 | Engine analysis और bot moves | GPLv3; official docs release में WebAssembly targets | Engine is not game-state UI; browser CPU/battery; GPL distribution compliance; NNUE network/source include check करें | Strong candidate if GPL obligations accepted |
| Lichess opening names | Opening classification dataset | Project CC0/public domain | English names; taxonomy/position collisions संभव | Local V1 lookup के लिए candidate |
| Lichess puzzle database | Puzzle positions, moves, rating/theme metadata | Lichess database exports CC0 | पूरी dataset भारी; FEN first-move convention संभालें; tags/alternatives validate करें | Filtered subset से शुरू करें |
| Chess.com PubAPI | Public game/profile data | Read-only API, caching/rate limits | API itself permission for any downstream redistribution/branding नहीं; terms अलग से पढ़ें | Optional import adapter only; V1 dependency नहीं |

Sources: [chess.js](https://github.com/jhlywa/chess.js/) [react-chessboard repo](https://github.com/clariity/react-chessboard) [npm package](https://www.npmjs.com/package/react-chessboard) [Chessground](https://github.com/lichess-org/chessground) [chessops](https://github.com/niklasf/chessops) [Stockfish license](https://github.com/official-stockfish/stockfish) [Lichess opening data](https://github.com/lichess-org/chess-openings) [Lichess database](https://database.lichess.org/) [Chess.com PubAPI](https://www.chess.com/news/view/published-data-api)

### License निर्णय V1 से पहले

- Stockfish GPLv3 की official distribution guidance में license और exact binary बनाने योग्य source code (या उसका pointer) शामिल करने की बात है; binary distribution में NNUE network भी engine का हिस्सा हो सकता है। Browser में engine WASM bundle distribute करना legal/compliance समीक्षा का विषय है। “Worker में अलग चला रहा हूँ, इसलिए बाकी app पर license का कोई असर नहीं” मानकर न चलें।
- यदि proprietary/closed-source distribution लक्ष्य है, तो GPL integration और bundled pieces/assets पर कानूनी सलाह लें या commercial/alternative engine licensing evaluate करें। यह कानूनी राय नहीं, architecture gate है। [1](https://github.com/official-stockfish/stockfish)
- Lichess open database page listed exports के लिए CC0 बताता है, लेकिन official broadcast PGNs के लिए अलग CC BY-SA 4.0 बताता है। “Lichess का हर data CC0 है” ऐसा generalize न करें। [1](https://database.lichess.org/)

---

## 11. प्रस्तावित architecture

### 11.1 Domain separation

```text
Board / Move-list UI
        │ user input, accessible feedback
        ▼
Game Domain ── rules engine, legal moves, result, draw claims, history
   ├── Clock service
   ├── PGN/FEN/SAN/UCI adapters
   ├── Local game/progress storage
   ├── Opening-name & puzzle data adapter
   └── Engine adapter ── UCI Worker (separate process/thread)
                         └── PV/eval → Learning/Review layer
```

इसे source-code plan नहीं बल्कि component boundary समझें। Board package rules engine नहीं; Stockfish rules interface नहीं; opening data engine नहीं; learning text engine output नहीं। हर adapter को बदल सकने योग्य रखें।

### 11.2 V1 platform recommendation

- **Client:** TypeScript + React web/PWA (अभी proposal; final decision नहीं)।
- **Rules:** chess.js जैसा permissive JS/TS rules package + छोटा `GameSession/RulePolicy` wrapper जो FIDE claim/automatic draw policy, repetition history, clock और result reason संभाले।
- **Board:** react-chessboard का evaluated version या accessible custom board; पहले keyboard/screen-reader audit।
- **Engine:** Official Stockfish 19 WebAssembly build, UCI adapter के जरिए Web Worker में; GPL decision पहले।
- **Storage:** V1 में browser IndexedDB/local storage layer में games, puzzle progress और settings; PGN export से user portability।
- **Opening/puzzles:** CC0 datasets का filtered local subset; external API optional fallback भी V1 के बाद।
- **Backend:** solo local-first V1 में जरूरी नहीं। यदि login/cloud sync जोड़ना हो तो अलग API + durable game store रखें।

### 11.3 Future human multiplayer architecture

यदि human-human online games V1/V2 में आएँ:

- Server हर incoming move को rules engine से revalidate करे; client move/clock को authoritative न माने।
- हर game event में monotonic sequence/version और unique command ID रखें; duplicate/retry/reconnect पर idempotent result दें।
- Server clock update, result, draw claim और game terminal transition commit करे; फिर WebSocket से opponent को broadcast करे।
- PostgreSQL/समकक्ष durable game history; matchmaking/presence/pubsub के लिए आवश्यकता होने पर Redis/समकक्ष। पहले load/operations need के अनुसार चुनें।
- Client-local rules rendering में उपयोगी हैं, पर server की independent validation की जगह नहीं।
- WebSocket handshake पर Origin allowlist, auth, message schema validation, payload size limit और per-user rate limits लागू करें। OWASP untrusted messages, origin validation और denial-of-service controls पर जोर देता है। [1](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html)

---

## 12. Performance, security, accessibility और testing

### 12.1 Performance

- Engine और batch PGN review UI thread से बाहर चलाएँ; search cancel करें और stale output reject करें। MDN Web Workers के background-thread/message model को document करता है। [1](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers)
- Engine lazily load करें; load/progress state दिखाएँ; analysis budget configurable रखें; position+engine-version+settings से result cache करने का विकल्प रखें।
- Opening stats को debounce/cache करें; network failure से board move input कभी block न हो।
- Device target तय करें—कम-से-कम मध्यम Android mobile पर drag/move smooth रहे, board input और engine output responsiveness अलग-अलग measure हों। Numeric performance targets specification stage में product/device tests से तय करें; यहाँ कोई unverified guarantee नहीं दी जा रही।
- CPU/battery/memory और WASM asset size मापें; deeper analysis user के मांगने पर शुरू हो।

### 12.2 Security और privacy

- FEN/PGN/URL/query, imported game names और comments को untrusted input मानें; size/length limits, parser errors और legal move validation दें। PGN comments को HTML की तरह render न करें; text के रूप में escape करें।
- Server-side analysis endpoint हो तो max depth/nodes/time और per-user queue/rate limit रखें—अन्यथा एक user engine compute से service exhaust कर सकता है।
- WebSocket future phase में Origin allowlist, authentication/authorization, schema validation, message size, rate limit और reconnect/duplicate-event tests जरूरी। [1](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html)
- User games को डिफ़ॉल्ट रूप से local रखने का विकल्प दें; cloud upload, public analysis, AI training या external game-source linking के लिए स्पष्ट consent और deletion/export नीति बनाएँ। यह product/privacy recommendation है।
- Dependency versions pin करें; license notices/SBOM और upstream security updates track करें। Piece set/sounds भी अलग asset license हैं।

### 12.3 Accessibility

WCAG 2.2 W3C Recommendation है। Board को सिर्फ रंग/drag पर निर्भर न रखें। [W3C WCAG 2.2](https://www.w3.org/TR/WCAG22/)

- **Keyboard:** सभी functionality keyboard से चलनी चाहिए; square selection/navigation, legal destination, promotion dialog और move history keyboard से usable हों। [SC 2.1.1](https://www.w3.org/TR/WCAG22/#keyboard)
- **Drag alternative:** drag से move करने के साथ click-select-click (या keyboard) का single-pointer विकल्प दें। [SC 2.5.7](https://www.w3.org/TR/WCAG22/#dragging-movements)
- **Color:** check, selected square, legal destination, last move और error केवल लाल/हरा रंग से न बताएँ; shape, border, icon, text/aria label भी दें। [SC 1.4.1](https://www.w3.org/TR/WCAG22/#use-of-color)
- **Targets:** छोटी controls के लिए 24×24 CSS-pixel minimum criterion और उसके exceptions देखें; board इतना छोटा न करें कि squares मुश्किल से चुनें। [SC 2.5.8](https://www.w3.org/TR/WCAG22/#target-size-minimum)
- Keyboard focus स्पष्ट दिखे। [SC 2.4.7](https://www.w3.org/TR/WCAG22/#focus-visible)
- Screen reader के लिए squares/pieces के meaningful names, move text और game result दें; board के बाहर text move-list भी रखें। Move/check announcements उपयोगी हों, पर हर सेकंड clock tick को बार-बार announce न करें। ये अतिरिक्त design recommendations हैं, केवल criterion का दावा नहीं।
- हिन्दी page language, सरल instructions, piece/notation glossary, reduced-motion विकल्प और sound toggle रखें। Timed competitive mode के साथ untimed practice mode भी दें; WCAG time criteria और real-time activity exceptions को अलग से समझें। [SC 3.1.1](https://www.w3.org/TR/WCAG22/#language-of-page) [SC 2.2.1](https://www.w3.org/TR/WCAG22/#timing-adjustable)

### 12.4 Test plan: coding शुरू होते ही आवश्यक

| Test area | उदाहरण/acceptance |
|---|---|
| Legal rules/perft | Start position legal move totals: depth 1 = 20, depth 2 = 400, depth 3 = 8,902, depth 4 = 197,281; known positions पर special-rule perft |
| Special moves | Castling: moved king/rook, blocked path, king in check, transit/destination attacked, pinned attacker; en passant immediate-only और discovered-check illegality; promotion Q/R/B/N |
| Game endings | Checkmate बनाम stalemate, dead position, resignation, timeout/mating-possibility draw, draw agreement, repetition और move-count claims/automatic draws; mate on 75-move boundary precedence |
| Position/history | Apply/undo और FEN round-trip; castling/EP/counters; repetition key में side/rights/legal EP; PGN replay और starting FEN |
| Notation | SAN disambiguation, capture/check/mate, castling, promotion, PGN tags/comments/variations; UCI promotion move |
| Engine contract | `uci/uciok`, `isready/readyok`, `position`, `go`, `stop`, `bestmove`; legal PV; cp/mate signs; MultiPV; stale result rejection |
| Clock | Increment केवल accepted move पर; timeout boundary; pause/resume; visibility change; local monotonic display; online future में reconnect/server-authority |
| Accessibility/E2E | Keyboard-only move, click-select-click, screen reader labels, visible focus, color-only audit, mobile orientation, promotion, reduced motion |
| Import/security | Malformed/oversized PGN/FEN, HTML/script comments, invalid promotion, illegal move, unusual names/Unicode, parser crash/fuzz inputs |
| Multiplayer later | Duplicate event/idempotency, out-of-order version, unauthorized game move, disconnect/reconnect, Origin validation, rate-limit/large payload |

अलग libraries से differential testing उपयोगी है, लेकिन test-only library को भी dependency/license review में दर्ज करें। Random legal move sequences से invariant/property tests चलाएँ—किसी move के बाद अपने King को check में छोड़ने की अनुमति न हो।

---

## 13. V1 बनाम आगे के चरण

### V1 — सीखने योग्य, सीमित और deliverable

**शामिल करें**

- Standard chess rules; custom FEN position से शुरू करने और PGN import/export का basic support।
- Responsive board; click/drag/touch + keyboard alternative; promotion chooser; move list; board flip; last move/check/status।
- Rules/history layer; FIDE claim-based draw behavior या चुने हुए alternate online profile की स्पष्ट documentation। Recommendation: V1 में claim-based semantics।
- User-vs-engine game; engine difficulty approximate setting; optional base time + increment।
- Practice mode में hints/takeback; bot-game में explicit “practice coach” control।
- Local post-game analysis; engine eval graph; limited key moments; legal PV replay; retry/hint; simple evidence-based explanations।
- Local opening name/ECO lookup via CC0 data; popular/book move और engine move को अलग दिखाना।
- CC0 puzzle dataset का filtered subset; basic motifs; multiple valid mate-in-one answers; untimed mode default।
- Local save/progress, source/license notice, accessibility and import/security tests।

**V1 से बाहर रखें**

- Human matchmaking/rated live games, chats, tournaments, anti-cheat/cheating accusation system।
- किसी live human game में engine move, opening book/explorer, tactical hint या “opponent intent” coaching।
- Third-party Opening Explorer API को required dependency बनाना—वर्तमान Explorer auth/quota contract पहले primary source से verify नहीं है।
- Full LLM/chatbot-generated analysis; deep strategy classification with unsupported claims।
- Chess960/variants, multiple tournament time controls, tablebases, cloud engine queue, social network/study sharing।

### V1.5 / V2 — उपयोग और accuracy साबित होने के बाद

- Account/cloud sync और PGN import integrations, privacy controls और API terms review के साथ।
- Opening stats, rating/time-control filters, source/sample count, cache और offline fallback।
- Review mistakes से personalized puzzle queue; tactics/endgame themes; simple progress dashboard।
- Coach-authored short Hindi lessons और opening/structure mini-courses।
- Human multiplayer तभी जब authoritative server, clock sync, reconnect/idempotency और fairness policy तैयार हो। Live human matches में analysis/hints disabled रहें।
- Chess960/variants, Syzygy endgame tablebase या cloud analysis only after licensing/storage/resource review।

---

## 14. आगे AI learning और intention analysis की foundation

### 14.1 पहले trusted facts, फिर भाषा

भविष्य के explanation system को एक generic prompt से नहीं, बल्कि structured evidence से feed करें:

1. **Game facts:** legal position, move history, side to move, clock situation, attacked pieces/squares, material/king safety/structure indicators।
2. **Engine facts:** top candidate lines, score type (`cp`/`mate`), score perspective, search depth/nodes/time, engine version, PV stability across searches।
3. **Database facts:** recognized opening, source/date, filtered game count and moves; database popularity अलग field।
4. **Learning facts:** उपयोगकर्ता ने कौन-सा candidate चुना, कौन-सा hint माँगा, कौन-सा motif बार-बार miss किया।
5. **Explanation:** नियम/template/AI भाषा केवल इन facts पर; shown move-line को chess rules engine से validate करें।

### 14.2 “Intent” को कैसे नाम दें

- **अभी:** “इस चाल से c4 पर दबाव बढ़ा”, “संभावित idea …”, “अगर इसे ignore किया, engine line में …” जैसे conditional, verifiable वाक्य।
- **बाद में:** कई चालों का sequence, opening repertoire, pawn structure और repeated plans को साथ देखकर “संभावित योजना” का अनुमान लगाया जा सकता है; फिर भी यह calibrated probability/hypothesis होगा, खिलाड़ी की वास्तविक मानसिक अवस्था का प्रमाण नहीं।
- **मत कहें:** “उसने यही सोचा था”, “यह पक्का trap है”, “आपने engine जैसी चाल नहीं चली इसलिए cheating” जैसे असमर्थित निष्कर्ष।
- Model evaluation में line correctness, motif label correctness, uncertainty calibration और user learning outcome मापें—सिर्फ fluent Hindi या 0–100 accuracy नहीं।

### 14.3 Data और governance

Own games/learning events को उपयोगकर्ता की सहमति के साथ, न्यूनतम आवश्यक fields और retention/deletion controls के साथ रखें। Public dataset, licensed master games, user-imported PGN और private games को अलग provenance दें। बाद की AI training में dataset license, privacy, identifiable player names और event rules दोबारा जाँचें।

---

## 15. Future Specification से पहले खुले निर्णय

1. **Platform:** Web/PWA, Android/iOS native, या cross-platform? नीचे का architecture web-oriented recommendation है, अंतिम निर्णय नहीं।
2. **V1 opponent:** केवल engine, local hot-seat, या online human? Online human जोड़ने से authoritative backend और live fair-play policy अनिवार्य होंगे।
3. **Audience:** absolute beginners, school-age learners, club players, या mixed? Hindi terminology/glossary और difficulty progression इसी पर निर्भर है।
4. **Draw behavior:** FIDE claim-based semantics या online-style automatic draw? दोनों में से चुने हुए policy को game rules/UX में version करें।
5. **Open-source strategy:** क्या product Stockfish/Chessground जैसे GPL components और corresponding source obligations स्वीकार कर सकता है? यह code से पहले तय हो।
6. **Offline/privacy:** क्या local-first, anonymous use स्वीकार्य है, या launch से account/cloud sync चाहिए?
7. **Data:** Opening stats के लिए external service की dependency स्वीकार है, या केवल bundled CC0 data चाहिए? Lichess Explorer का current endpoint contract implementation time पर official docs से सत्यापित करना होगा।
8. **Analysis policy:** कितनी depth/latency/mobile heat/battery मंजूर है? “Instant hint” और “high-confidence post-game review” अलग budgets माँगते हैं।
9. **Language:** हिन्दी-only explanation, bilingual chess terms, या user-selectable Hindi/English? PGN notation standard रखना और explanation localization अलग रखना बेहतर है।

---

## 16. Core sources consulted

- **FIDE Laws of Chess (effective 1 Jan 2023):** [1](https://handbook.fide.com/chapter/e012023)
- **PGN/FEN specification:** [2](http://www.saremba.de/chessgml/standards/pgn/pgn-complete.htm)
- **Stockfish 19 release, UCI documentation, WDL model, license:** [release](https://stockfishchess.org/blog/2026/stockfish-19/) · [UCI](https://official-stockfish.github.io/docs/stockfish-wiki/UCI-Protocol-and-Stockfish-Commands.html) · [WDL model](https://github.com/official-stockfish/WDL_model) · [license](https://github.com/official-stockfish/stockfish)
- **W3C WCAG 2.2:** [Recommendation](https://www.w3.org/TR/WCAG22/) · [Keyboard](https://www.w3.org/TR/WCAG22/#keyboard) · [Use of Color](https://www.w3.org/TR/WCAG22/#use-of-color) · [Dragging Movements](https://www.w3.org/TR/WCAG22/#dragging-movements) · [Target Size](https://www.w3.org/TR/WCAG22/#target-size-minimum)
- **MDN Web Workers:** [1](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers)
- **Lichess fair play, learning, puzzle database, opening names:** [fair play](https://lichess.org/page/fair-play) · [learn](https://lichess.org/learn) · [database](https://database.lichess.org/) · [opening names](https://github.com/lichess-org/chess-openings)
- **Chess.com official UX/API/fair-play references:** [Game Review](https://support.chess.com/en/articles/8584089-how-does-game-review-work) · [move classifications](https://support.chess.com/en/articles/8572705-how-are-moves-classified-what-is-a-blunder-or-brilliant-etc) · [fair play](https://support.chess.com/en/articles/8568369-what-do-i-need-to-know-about-fair-play-on-chess-com) · [Published-Data API](https://www.chess.com/news/view/published-data-api)
- **Open-source implementation references:** [chess.js](https://github.com/jhlywa/chess.js/) · [react-chessboard](https://github.com/clariity/react-chessboard) · [Chessground](https://github.com/lichess-org/chessground) · [chessops](https://github.com/niklasf/chessops)
- **OWASP WebSocket security guidance:** [1](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html)

---

## Bottom line

V1 को “हर chess feature एक साथ” बनाने की कोशिश न करें। पहले **सही rules/history + accessible board + local Stockfish analysis + guided post-game learning + साफ fair-play boundaries** बनाएँ। Opening popularity को engine truth न बनाएँ, engine line को इंसानी intention न कहें, और FEN को full game history न समझें। यही separation आगे के “Chess Game Master Specification” और बाद की AI learning/intention analysis को मजबूत बनाएगी।
