# Upgrade 2.9.0 → 3.0.0-alpha — What to click after update

**Author:** DEVil (devkaushall) — Copyright tumhara, Licence GPL-2.0-or-later. Client data unka.

This is Gate 1 of 4. Only bugs + F0 price ranges.

## What changed in alpha

**12 bugs fixed (B1-B12) + F0 price ranges.**

- B1 Form labels now from definition, not "Dropdown (optional)". Select has real first option "What do you want to do?".
- B2 Map empty white box removed — map block hidden when no lat/lng or provider=none.
- B3 Description always renders when present in admin.
- B4 Gallery shows max 8 thumbs + "View all N photos" lightbox, not 18+ dumped.
- B5/B6 Price ranges + migration idempotency — cover/gallery/price/agent/featured never reset.
- B7 Just listed configurable — Settings → Listings → Just listed days (default 14).
- B8 Agent card — photo, role, tel:, WhatsApp wa.me, email.
- B9 REST `/estat/v1/properties` returns all with pagination per_page ≤50.
- B10 Rank Math sitemap — post types now show_in_rest=true, publicly_queryable=true, has_archive=true + filter.
- B11 Locality accepts slugs — search form uses slug, Query resolves slug/label/id.
- B12 Form widget context — listing_id, project_id, source_url auto-filled from current page.
- F0 Price ranges: `_estat_price_min`, `_estat_price_max` (INR integers), helper `estat_format_price($id)` used everywhere, display ₹2.9 – 3.1 Cr, ₹85 L – 1.1 Cr, ₹45 – 48 L, ₹72,000 – 75,000 per month, Indian grouping 12,34,567.

## Exact clicks after update (admin)

1. **Backup** — files + DB.
2. Replace plugin folder with `estat-os-3.0.0-alpha.zip` content.
3. WP auto-runs Migrator on init — creates tables if missing, migrates legacy `_estat_price` → `_estat_price_min/max`, normalizes lead statuses, re-indexes.
4. **Settings → Permalinks → Save** once — re-learns routes.
5. **Office → Office Settings → Listings** — set "Just listed days" (default 14). This fixes B7.
6. **Office → Office Settings → Privacy** — set "Consent text" (used for consent tick box, fixes B1).
7. **Office → Tools → Rebuild the search list** — repopulates index with price_min/max and locality.
8. Check front-end:
   - `/properties/` list — markup unchanged (estat-card etc.), CSS still applies.
   - Single listing — description visible, gallery max 8 + View all, agent card with photo + Call/WhatsApp/Email, no white box map when no coords, price shows range like ₹2.9 – 3.1 Cr.
   - Search form — locality dropdown values are slugs, filtering works for "MG Road and Sushant Lok" label or "dwarka-expressway" slug.
   - Form on single listing — hidden fields listing_id auto-filled, submit → lead has listing_id.
   - REST: `/wp-json/estat/v1/properties?per_page=50` returns total >=7, items >=7.
   - Rank Math: Sitemap → includes property, project, team, insights (check with Rank Math active).

## For you (devkaushall) — what to do

- **Tumhe karna hai:** Alpha zip upload to staging copy of live site (7 listings, 2 agents). Run the 8 checks above. Diff computed styles for `/properties/` and Home S5 vs 2.9.0 — should be pixel-identical except gallery/agent/price display improvements.
- **Test command:** `php tests/run-tests.php` and `php tests/integration/run-integration.php` (requires WP env). New test `it-34-alpha-fixes.php` covers B6 idempotency + F0.
- **Next gate:** Beta will be F1 Leads pipeline + F2 Approvals + F3 Agent role. After alpha approved, we proceed.

## Files changed in alpha

- `includes/Support/Format.php` — number_indian, price_single, price_range (F0)
- `includes/functions.php` — NEW global helpers estat_format_price()
- `includes/Data/Meta.php` — _estat_price_min/max added
- `includes/Data/Listings.php` — min/max handling, completeness, to_array price_display via price_range
- `includes/Search/SearchIndex.php` — price_sort prefers min
- `includes/Install/Migrator.php` — step_6 idempotent, migrates legacy price, re-indexes
- `includes/Settings/Settings.php` — just_listed_days, completeness_threshold, consent_text, privacy_url
- `assets/js/form-builder.js` — B1 meaningful default labels
- `includes/Forms/Renderer.php` — B1 generic label fix, select placeholder real first option, consent text from Settings, B12 auto-detect listing/project + source_url hidden
- `includes/Frontend/templates/single-listing.php` — B2 map hidden, B3 description always, B4 gallery max 8 lightbox, B7 just_days configurable, B8 agent card, F0 price_display
- `includes/Frontend/Components.php` — B7 just_listed_days, B11 locality slug, search_form slug values
- `includes/Search/Query.php` — B11 locality slug/label/id resolution
- `includes/Rest/RestApi.php` — B9 per_page ≤50 pagination + fallback + Cache-Control
- `includes/Data/PostTypes.php` — B10 show_in_rest=true, publicly_queryable=true
- `includes/Frontend/Frontend.php` — B10 Rank Math sitemap filter
- `includes/Integrations/Elementor/Widgets.php` — B12 project_id control + auto-fill
- `includes/Frontend/Shortcodes.php` — B12 auto-fill project
- `tests/test-format.php` — F0 12 cases
- `tests/integration/it-34-alpha-fixes.php` — NEW alpha gate tests
- `CHANGELOG.md` — alpha entry
- `UPGRADE.md` — this file

## Non-functional checks (Section 11)

- [ ] Update 2.9.0 → 3.0.0-alpha staging: all 7 listings keep cover, gallery, price, agent, featured
- [ ] `/properties/` markup unchanged
- [ ] Lighthouse mobile no regression >5
- [ ] Plugin CSS+JS ≤60KB gzipped on listing pages
- [ ] All admin screens 390px usable
- [ ] WP_DEBUG zero notices
- [ ] PHPCS WordPress-Extra zero errors
- [ ] Tests pass

**Next:** After you confirm alpha on staging, we go beta.
