/**
 * Share row — WhatsApp, Copy link, Email, Facebook, X, Print, Native Share + logging + search alerts form.
 * F5 polished + F4 alerts.
 */
document.addEventListener('DOMContentLoaded', function(){
  // Share rows
  document.querySelectorAll('.estat-share-row').forEach(function(row){
    const listingId = row.getAttribute('data-listing');
    const nativeBtn = row.querySelector('.estat-share-native');
    // Show native share if supported
    if(nativeBtn && navigator.share){
      nativeBtn.style.display='inline-flex';
    }
    row.querySelectorAll('[data-channel]').forEach(function(btn){
      btn.addEventListener('click', function(e){
        const channel = btn.getAttribute('data-channel');
        const url = btn.getAttribute('data-url') || window.location.href;
        const title = btn.getAttribute('data-title') || document.title;
        if(channel === 'copy'){
          e.preventDefault();
          if(navigator.clipboard && navigator.clipboard.writeText){
            navigator.clipboard.writeText(url).then(function(){
              const orig = btn.textContent;
              btn.textContent = '✓ Copied!';
              btn.classList.add('is-copied');
              setTimeout(function(){ btn.textContent = orig; btn.classList.remove('is-copied'); }, 1500);
            }).catch(function(){
              // Fallback prompt
              window.prompt('Copy link:', url);
            });
          } else {
            window.prompt('Copy link:', url);
          }
        }
        if(channel === 'native'){
          e.preventDefault();
          if(navigator.share){
            navigator.share({title: title, url: url}).catch(function(){});
          }
        }
        // Log share event via REST.
        try{
          fetch((window.estatPublic?.restUrl || '/wp-json/estat/v1/') + 'share', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({listing_id: parseInt(listingId,10), channel: channel})
          });
        }catch(err){}
      });
    });
  });

  // Search alerts form — supports both old (FormData) and new JSON (F4)
  document.querySelectorAll('.estat-alert-form').forEach(function(form){
    // Avoid double binding if already handled by inline script (F4)
    if(form.dataset.bound) return;
    form.dataset.bound='1';
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const fd = new FormData(form);
      const btn = form.querySelector('button[type=submit]');
      const orig = btn ? btn.textContent : '';
      if(btn){ btn.disabled=true; btn.textContent='Saving...'; }
      // Detect if form has hidden filters JSON (shortcode) or uses URLSearchParams (search page)
      let filters = {};
      const filtersRaw = fd.get('filters');
      if(filtersRaw){
        try{ filters = JSON.parse(filtersRaw); }catch(err){ filters = {}; }
      } else {
        const params = new URLSearchParams(window.location.search);
        for(const [k,v] of params.entries()){ filters[k]=v; }
      }
      const payload = {
        name: fd.get('name') || document.querySelector('input[name=alert_name]')?.value || '',
        email: fd.get('email') || document.querySelector('input[name=alert_email]')?.value || '',
        phone: fd.get('phone') || document.querySelector('input[name=alert_phone]')?.value || '',
        frequency: fd.get('frequency') || document.querySelector('select[name=alert_frequency]')?.value || 'instant',
        filters: filters,
        query: filters,
        source_url: fd.get('source_url') || window.location.href
      };
      fetch((window.estatPublic?.restUrl || '/wp-json/estat/v1/') + 'alerts', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      }).then(r=>r.json()).then(j=>{
        const msg = form.querySelector('.estat-alert-msg');
        if(j.success || j.id){
          if(msg) msg.textContent = 'Alert saved! Check your email to confirm. (F4/F5)';
          form.reset();
        } else {
          if(msg) msg.textContent = j.message || 'Could not save alert';
        }
      }).catch(()=>{
        const msg = form.querySelector('.estat-alert-msg');
        if(msg) msg.textContent='Network error';
      }).finally(()=>{
        if(btn){ btn.disabled=false; btn.textContent=orig; }
      });
    });
  });
});
