# Phase 3 — Full Mayfair + Public

Phase 3 completes the redesign after Phase 2 staging OK.

## Admin — remaining screens (behind same per-user switch, real data only)

- [x] PipelineNew — Kanban 5 columns New/Contacted/Scheduled/Won/Lost, real Leads::query, drag cards, no inline styles
- [x] VisitsNew — filter by outcome, table When/Who/Property/Outcome, real Visits::query
- [x] FormsNew — list real Forms::all(), Add form button
- [x] InsightsNew (admin) — search, table Title/Status/Date, real PostTypes::INSIGHT
- [x] Email templates full — Phase 3 Mayfair UI in Leads group: from name/address/footer + subject/body per event (new_lead, lead_assigned, new_visit, visit_completed, listing_published, form_submitted) with placeholders {{name}}, {{phone}}, {{property}}
- [ ] SearchAlertsNew, Reports, Gallery & Media — next minor

## Public — 6 views per brief §0-13

Tokens: bg #F9F7F2 surface #FFFFFF sand #F2EDE4 line #E6E2D9 ink #1A1A1A ink-2 #444748 muted #6B6E6E accent #725B2F accent-2 #A68B5B soft #F5F0E7 radius 2px no shadows left-aligned

- [x] public.css rewritten to Mayfair tokens, ≤60KB (12KB), no shadows, left-aligned, 390px no scroll, 1240 container at 1440
- [x] public.js ≤20KB (9KB) defer via script_loader_tag filter
- [x] Templates updated to wrapper <main class="estat-public estat-{view}"><div class="estat-container"> + get_header()/get_footer():
  - archive-listing.php → estat-properties
  - single-listing.php → estat-property (facts: type/offer/price/area/beds, regulatory only if field)
  - archive-project.php → estat-projects
  - single-project.php → estat-project
  - archive-estat_insight.php → estat-insights (new)
  - single-estat_insight.php → estat-insight (new)
- [x] No fake copy, no Mayfair hardcoded, no emoji, SVG currentColor 20px 1.5 stroke, no brokerage/RERA unless field, additive fields only
- [ ] Screenshots 1440/1024/390 real data, Lighthouse ≥85/95/95, axe, schema validator — to run on staging with 9 real listings

## Rules still enforced
- No Agencies module (rejected)
- No fake data — real counts only
- No hardcoded city — from Office settings
- No counts in labels — "Enable all" not "Enable all 23"
- No inline style="" in SettingsNew — component library in admin-new.css
- Classic screens untouched, switch works both ways
