# Phase 2 — Mayfair Redesign (After Phase 1 Staging OK)

Phase 1 (behind per-user switch `estat_use_new_ui`):
- tokens + shell (admin-new.css, Source Serif 4, bg #F9F7F2, ink #1A1A1A, surface #FFFFFF, radius 2px, no shadows)
- TodayNew, ListingsNew, AddHomeNew (4 groups), SettingsNew grouped cards (overview, general, listings & workflow, leads & enquiries, integrations, advanced)
- Office menu grouping
- Classic screens untouched, switch works both ways
- Counts in labels banned fixed (Enable all, no "23")

## Phase 2 — Implemented in this build (3.1-phase2)

### Settings — full parity (fixed per review)
- [x] Email templates only in classic → Phase 2 item, now documented; core fields added to Leads group (from name/address/footer) with note classic has full templates when switch OFF
- [x] Pages helper (3.0.7 fix) → under Listings & workflow: draft-only list + create button
- [x] Search filters → under Listings & workflow: enable/disable + drag order, label "Enable all" (no 23)
- [x] Advanced Tools → under Advanced as dedicated section #estat-tools-section, fixes broken tab=tools link (redirects to advanced with highlight), classic Tools remains when switch OFF
- [x] General missing: logo upload (image field), tagline, cities list (comma separated) added
- [x] Inline styles → classes: SettingsNew now uses component library classes only (estat-settings-layout, estat-field-grid, etc.)

### Admin screens — Phase 2 (real data only, no fake, city from settings)
- [x] EnquiriesNew — two-panel inbox + detail notebook, KPI strip real counts, filters status/intent/search, inbox list real Leads::query, detail with phone/email/property/intent/message, timeline LeadEvents, visits
- [x] Societies & ProjectsNew — KPI total/live/drafts real, search + stage filter, left grid project cards thumb + title + locality pin + developer + status pill, right detail gallery + metrics + Edit/View
- [x] TeamNew — search, grid team cards 56px photo + name/role/phone + city from settings (no hardcoded Gurugram), detail panel 64px + contact
- [x] SpreadsheetNew — proper spreadsheet grid with bulk checkbox, photo 48x32, headline + ID, locality, price, area, beds, status pill, updated, pagination 50 per page, real listings only
- [ ] Pipeline — Kanban (real leads) — next
- [ ] Site Visits — real visits — next
- [ ] Reports, Insights admin, Gallery & Media, Forms, Search Alerts — next

### Rules still enforced
- No new modules (Agencies rejected)
- No fake data — real counts only (verified via grep, no MF00/Godrej/248)
- No hardcoded city — from Office settings
- No counts in labels — fixed
- No inline style="" in SettingsNew — moved to admin-new.css component library
- Classic screens untouched, switch works both ways via NewUI

### Public (separate track, additive fields only)
- /properties/, /property/{slug}/, /projects/, /project/{slug}/, /insights/, /insight/{slug}/
- public.css ≤60KB, public.js ≤20KB, get_header()/get_footer(), wrapper <main class="estat-public estat-{view}"><div class="estat-container">
- No Mayfair hardcoded, no emoji SVG currentColor, no brokerage/RERA unless field

### Rules (3.0.7 non-negotiable, still apply)
- No new modules (Agencies was rejected — do not re-add)
- No fake data — real counts only
- No hardcoded city — from Office settings
- No counts in labels (e.g. "Search filters (23)" banned) — fixed
- No new features in 3.0.7 zip — 3.0.7 remains fix-only
- Every public string translatable __(), no dev strings public

Added per user note 30 Sep 2026: Email templates only in classic = Phase 2 item (this file).
