# Team / Agent Management — Current Functionality Audit
Date: 2026-09-30
Purpose: Reference for Stitch UI redesign — DO NOT CHANGE BACKEND

## 1. Entry Points
- Menu: `estat-team` → Team (capability `estat_manage_team`)
- Grouped under "Team & reports" with `estat-reports`, `estat-insights`
- Classic handler: `TeamScreen::render()` in `includes/Admin/Screens/TeamScreen.php`
- New UI handler (behind per-user switch `estat_use_new_ui`): `TeamNew.php` — currently card grid + detail, but will be redesigned

## 2. Data Model — Post Type `estat_agent`
- Registered in `PostTypes.php` with caps `simple_caps('estat_manage_team','estat_agent')`
- Title = full name (`post_title`)
- Content = bio (`post_content`)
- Status: `publish` / `draft` (supports draft)
- Thumbnail = photo (WordPress featured image)
- Meta keys (from `Meta::agent_schema()`):
  - `_estat_role` (text) — e.g. "Sales Manager"
  - `_estat_phone` (phone) — sanitized phone
  - `_estat_whatsapp` (phone) — optional, if empty same as phone
  - `_estat_email` (email)
  - `_estat_agency_id` (int) — company link (currently unused, reserved)
  - `_estat_user_id` (int) — linked WordPress user ID for login/pocket
  - `_estat_external_id` (text) — reference number for CSV import dedupe
  - `_estat_practice` (bool) — computed, marks practice/demo records

## 3. CRUD Operations
- **Create/Edit**: Form in classic screen `TeamScreen`:
  - Fields: title (required), role, phone, whatsapp (help: leave empty if same), email, bio (textarea), photo_id (image type), external_id, user_id (select from up to 200 WP users, option 0 = No login)
  - POST action `save_agent` → `Actions::save_agent()` → `Agents::save($input, $agent_id)`
  - Validation: name required on create, email validated if provided
  - Photo: `set_post_thumbnail($agent_id, $photo_id)` if photo_id provided
  - Audit: `agent.created` / `agent.updated` via `AuditLog::record`
  - Undo snapshot via `Undo::capture($post_id)` before update
  - Redirect to `admin.php?page=estat-team&edit={id}` with saved notice
- **List**: `WP_Query` for `estat_agent`, `post_status=[publish,draft]`, `posts_per_page=25` classic, 20 new, `orderby=title ASC`, search `s`
- **Delete/Trash**: Standard WP post actions via `Partials::record_actions` — triggers `Agents::on_delete`:
  - Unassigns listings: `delete_post_meta(listing, '_estat_agent_id')` + `Listings::refresh_derived`
  - Unassigns leads: `$wpdb->update('estat_leads', agent_id=0 WHERE agent_id=post_id)`
  - Unassigns visits: same for `estat_visits`
  - Audit `agent.deleted`
- **Pagination**: `Partials::pagination`

## 4. Permissions
- Capability: `estat_manage_team` (defined in `Roles.php`)
- Check at top of both screens: `current_user_can('estat_manage_team')` → wp_die otherwise
- Meta registration auth_callback checks `estat_manage_listings` (intentional, same office role)

## 5. Agent-Listing Relationships
- Listing meta `_estat_agent_id` → agent post ID
- Stored in search index `estat_index` table column `agent_id` for fast counting
- Counting: `Agents::listing_count($agent_id)` = `SELECT COUNT(*) FROM estat_index WHERE agent_id=%d AND post_status='publish'`
- Exposed in `Agents::to_array()` as `listings` count
- Listing editor (ListingsScreen) has picker: `Picker::options(AGENT, 'Nobody yet', current_agent_id)` → select field `_estat_agent_id`
- On agent delete, listings become unassigned (not deleted)

## 6. WordPress User Linking
- Meta `_estat_user_id` stores WP user ID
- User options: `get_users(number=200, fields=[ID,display_name])` → dropdown, first option 0 = No login
- Reverse lookup: `Agents::for_user($user_id)` → `get_posts(meta_key=_estat_user_id, meta_value=user_id, numberposts=1)`
- Used in:
  - Pocket: `Pocket::agent_for_current_user()` to show agent's own listings/leads
  - Leads: when current user is agent, filters leads to their own
  - Security: agent can sign in and see own work via pocket login `/agent/`
- Help text: "Link this person to a login so they can sign in and see their own work."

## 7. Contact Fields Handling
- Phone/WhatsApp: sanitized via `Sanitize::phone`
- Email: `Sanitize::email`, validated on save — error if looks invalid
- All displayed in table: `trim(phone + ' ' + email)` in classic, separate in new
- Tel links: `tel:` for phone, `mailto:` for email
- WhatsApp: stored but not displayed in list (available in to_array)

## 8. Photo Handling
- Field type `image` in classic → media library picker, stores attachment ID
- Save: `set_post_thumbnail(agent_id, photo_id)` — uses WP featured image
- Display:
  - Classic list: no photo
  - New grid: `get_the_post_thumbnail(id, [56,56])` else avatar placeholder initial letter
  - Detail: `[64,64]` thumb
  - `Agents::to_array()` returns `photo` URL via `get_the_post_thumbnail_url(medium)`
- No cropping enforced, but UI expects square

## 9. Existing Backend Logic to Preserve
- `Agents::save()` handles both create and update, sanitizes via `Meta::sanitize_value` + schema
- `Agents::listing_count()` direct DB query on `estat_index`
- `Agents::for_user()` lookup
- `Agents::on_delete()` cascade unassign (listings, leads, visits) — must stay
- `Agents::to_array()` public safe representation used by REST, Schema, Components, Elementor
- CSV import: `Spreadsheet.php` calls `Agents::save($row, $existing)` for bulk import
- REST: `RestApi.php` exposes agent data via `Agents::to_array`
- Search index: `SearchIndex.php` indexes `agent_id`
- Leads auto-assign: `Leads.php` tries `get_post_meta(listing_id, '_estat_agent_id')` as fallback agent
- Audit log: created/updated/deleted events
- Undo: snapshot before update

## 10. Current UI Structure (Classic)
- Top: Add/Edit form in card (`Partials::card_open`) — vertical stack of fields
- Bottom: "Your team" card with toolbar (search by name, count people), table with columns Name, Role, Contact, Listings (num), Actions (Edit + trash/draft via `record_actions`)
- Empty state: icon person, message about adding colleagues, reassuring copy
- No city — city comes from Office settings in new UI only

## 11. Current UI Structure (New — Phase 2)
- Topbar: H1 Team, subtitle "%d team members — {city}", toggle switch + Add button
- Filters: search form `s` placeholder "Search by name, role, phone"
- Layout: `.estat-team-layout` = 1fr 360px (grid left, detail right)
- Left: `.estat-team-grid` → cards `.estat-team-card` 200px, photo 56px avatar placeholder, name/role/phone/city (city from `Settings::all()['city']` or `cities[0]`, no hardcoded Gurugram)
- Right: detail panel with 64px photo, role, phone/email/city, Edit button
- Real data only, 20 per page, no fake IDs

## 12. What Must Stay Identical After Redesign
- All meta keys, sanitization, validation
- Photo as featured image
- User linking dropdown 200 users + No login
- External ID field
- Agent-listing link via `_estat_agent_id`
- Listing count via `estat_index`
- On-delete cascade
- Permissions `estat_manage_team`
- Audit + Undo
- CRUD redirects and notices
- REST + CSV + Pocket integrations via `Agents::to_array()`
- No new required fields, no removal of existing fields

## 13. Constraints for Stitch Design
- No inline style="" in PHP — use classes in `admin-new.css` (component library rule)
- No hardcoded city, no fake data, no Mayfair hardcoded strings
- No counts in labels ("Enable all" not "Enable all 23")
- No emoji icons — SVG currentColor 20px 1.5 stroke via `Icon::render()`
- Translatable strings `__()`
- Preserve `NewUI::toggle_markup()` switch
- Wrapper must be inside `.estat-new-ui` (Mayfair tokens already defined)
- Left-aligned, no shadows, radius 2px per tokens
- Accessibility: labels for inputs, aria
- Must work at 390px without horizontal scroll

## 14. Files Involved
- `includes/Admin/Screens/TeamScreen.php` — classic (DO NOT MODIFY per task, but reference)
- `includes/Admin/Screens/TeamNew.php` — to be redesigned (only file to change for UI)
- `includes/Data/Agents.php` — backend, DO NOT MODIFY
- `includes/Data/Meta.php` agent_schema — DO NOT MODIFY
- `includes/Admin/Actions.php` save_agent — DO NOT MODIFY
- `assets/css/admin-new.css` — add new classes for redesign, no inline styles
- `includes/Admin/Admin.php` routing — already routes to TeamNew when switch on, no change needed

Ready for Stitch reference.
