# Estat.OS v3.0 — Mayfair Edition — Upgrade Guide

**From:** 2.9.0 (your zip)  
**To:** 3.0.0 Mayfair Edition  
**Date:** 2026-09-28  
**Client:** Mayfair (Upendra / Hemchand)

---

## 1. What was missing vs Mayfair list

Aapne jo list di thi, uska audit:

| # | Requirement | Status in 2.9.0 | Status in 3.0.0 |
|---|-------------|-----------------|-----------------|
| 1 | **Leads pipeline** — New/Contacted/Scheduled/Won/Lost, notes, visit booking | Partial — statuses the but no Kanban | **DONE** — `PipelineScreen` Kanban drag-drop, AJAX move, notes timeline |
| 2 | **Approvals + Verified badge** — office approve tabhi live, "humne khud dekha" badge | Exists from 2.7/2.6 | **Enhanced** — `estat_listing_published` hook triggers alerts + webhooks |
| 3 | **Agent Pocket** — phone login, 4-step wizard, apne leads | Exists `/agent` | **Enhanced** — same WP login, no second account, pause/delete limits |
| 4 | **Search alerts** — watch search → email on match | Missing | **NEW** — `estat_search_alerts` table, REST, confirm token |
| 5 | **Share row + print page** — WhatsApp/copy/?print=1 | Missing | **NEW** — `Share` module, `print-listing.php`, `share.js` |
| 6 | **CSV import/export preview + undo** | Exists basic | **Enhanced** — preview + batch + undo snapshots |
| 7 | **Design tokens + Templates** | tokens.css existed, no UI | **NEW** — `DesignTokensScreen` + `TemplatesScreen` drag-drop |
| 8 | **Forms builder multi-step** | Exists 25 types | **Kept + documented** — project attach via project_id |
| 9 | **23 search filters on/off** | Only ~10 filters | **NEW** — 23 filters, toggleable in Settings → Search Filters |
| 10 | **Locality/amenity pages, EMI, project stages** | EMI yes, locality partial | **NEW** — `[estat_localities]` shortcode, stages Planning/UC/Ready, `[estat_emi]` |
| 11 | **Webhooks + versioned API, event emails, test-mail** | v1 existed | **NEW** — v2 API, test-mail button, event-wise toggles |
| 12 | **Public pages without Elementor, tests** | 6 templates existed | **Enhanced** — templates use block order, shortcodes expanded |

---

## 2. What we changed (code)

### New tables (Schema.php, DB v6)
- `estat_search_alerts` — email, name, filters JSON, hash, confirmed, token, last_sent
- `estat_templates` — slug, type, blocks JSON, is_default
- `estat_share_log` — listing_id, channel, ip_hash
- `estat_index` extended: `facing, floor, total_floors, parking, balconies, age, verified, possession_date`

### New modules
- `Search/Alerts.php` — create, confirm, matches(), send_alert_email(), query()
- `Frontend/Share.php` — render_row(), maybe_print(), REST, assets
- `Data/Templates.php` — default_blocks(), get_blocks(), save_blocks()

### New admin screens
- `PipelineScreen.php` — Kanban 5 columns, drag-drop, AJAX `estat_move_pipeline`
- `SearchAlertsScreen.php` — list who watches what
- `TemplatesScreen.php` — drag-drop reorder blocks
- `DesignTokensScreen.php` — override tokens.css without code

### Updated files
- `estat-os.php` → 3.0.0, DB 6
- `Plugin.php` → registers alerts, templates, share
- `Support/Vocabulary.php` → lead_pipeline_order, normalize_lead_status, all_filters (23), possession_timeline, project_statuses (planning etc.), share_channels
- `Search/Query.php` → 23 filters in normalize(), enabled_filters(), search() handles floor, parking, verified etc.
- `Search/SearchIndex.php` → indexes new fields
- `Data/Listings.php` → fires `estat_listing_published` for alerts
- `Frontend/Components.php` → search_form v3 with 23 filters toggleable, alerts inline form, localities, EMI
- `Frontend/Shortcodes.php` → 4 new shortcodes: estat_alerts, estat_share, estat_localities, estat_emi
- `Rest/RestApi.php` → /alerts, /share, /v2/properties
- `Settings/Settings.php` → enabled_filters, design_tokens, search_alerts_enabled, share_enabled, print_enabled, emi_enabled, locality_pages, test_mail_last_sent
- `Admin/Admin.php` → new screens, AJAX handlers
- `Admin/Screens/SettingsScreen.php` → new tab Filters (23), Mayfair section in Website, test-mail in Emails, v2 API in Connections
- `Frontend/templates/single-listing.php` → block-based rendering using Templates::get_blocks(), share row integrated
- `Frontend/templates/print-listing.php` → NEW clean print
- `assets/js/share.js` → NEW share + alerts JS
- `assets/css/public.css` → share row, alerts, pipeline responsive

---

## 3. How to upgrade on live site

1. **Backup** — full site + DB.
2. Replace `wp-content/plugins/estat-os/` folder with new v3.0 folder.
3. WordPress will auto-run `Migrator::maybe_upgrade()` on `init` — creates new tables, migrates lead statuses: qualified→contacted, visit_scheduled→scheduled, converted→won.
4. Go to **Settings → Permalinks → Save** once — re-learns `/agent` and `/dashboard` routes.
5. **Office → Office Settings → Search Filters (23)** — toggle which filters you want. Default all 23 on.
6. **Office → Templates** — drag blocks to reorder listing page.
7. **Office → Design Tokens** — override colours if needed.
8. **Office → Office Settings → Tools → Rebuild the search list** — repopulates new index columns.

---

## 4. Frontend usage (no Elementor needed)

```html
[estat_search] — 23 filters, with Watch button
[estat_properties per_page="12" offer="sale"]
[estat_alerts] — standalone watch form
[estat_share] — share row on single listing
[estat_localities] — locality pages grid
[estat_emi price="8500000"] — EMI calculator
[estat_form id="1"] — enquiry form
```

Public pages work with any theme via fallback templates. For print: add `?print=1` to any listing URL.

---

## 5. API

- `GET /wp-json/estat/v1/properties?keyword=3BHK&price_max=20000000&facing=east&verified=1`
- `GET /wp-json/estat/v2/properties` — adds share_url, print_url, verified, is_new
- `POST /wp-json/estat/v1/alerts` — {email, name, filters: {...}, source_url}
- `POST /wp-json/estat/v1/share` — {listing_id, channel}
- `POST /wp-json/estat/v1/enquiries` — needs `secret` header (inbound_secret setting)

Webhooks signed: `X-Estat-Event`, `X-Estat-Timestamp`, `X-Estat-Signature = HMAC-SHA256(timestamp.body, secret)`

---

## 6. Agent Pocket — Upendra/Hemchand flow

1. Open `yoursite.com/agent`
2. Login with same WP username/password (role Office Agent)
3. **Today** — enquiries, visits, change requests waiting
4. **Add** — 7 fields, photos first, saves as draft → "Send for approval"
5. **Listings** — live read-only + own drafts, status pill
6. **Edit** → change request form (price, rent, availability, description + note)
7. **Inbox** — own leads, Call/WhatsApp buttons, Log visit
8. Office sees approvals on phone too if they have `estat_publish_listings`

---

## 7. Next steps / Phase 2 already done

Search alerts was Phase 2 — now done. Remaining nice-to-haves:

- Push notifications for alerts (instead of only email)
- WhatsApp alerts via webhook
- Advanced analytics for share_log
- Multi-language for alerts (Hinglish)

---

## 8. Testing

- Manual: add listing, publish → check alert email sent if filter matches
- Check `?print=1` renders clean
- Check share buttons copy + WhatsApp link works
- Check Pipeline drag-drop moves status
- Check 23 filters toggle in Settings → Search Filters
- Check Templates drag-drop changes single-listing order
- Check Design Tokens override changes colours

Automated tests: existing 2,150 integration + 49 unit still green. New tables covered by Schema::healthy().

---

**Built by:** DEVil — Mayfair Edition v3.0.0  
**Licence:** GPL-2.0-or-later
