<?php
/**
 * Estat.OS — Bug checker for Stitch redesign.
 * Run: php tools/bug-check.php
 */

$root = dirname(__DIR__);
$errors = [];
$warnings = [];

function scan($dir, $cb) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    foreach ($it as $file) {
        if ($file->isFile()) $cb($file->getPathname());
    }
}

// 1. Uninstall must drop all tables from Schema::tables() — parse tables() method only
$schemaFile = $root . '/includes/Install/Schema.php';
$uninstallFile = $root . '/uninstall.php';
if (file_exists($schemaFile) && file_exists($uninstallFile)) {
    $schemaContent = file_get_contents($schemaFile);
    // Extract only tables() return array
    if (preg_match('/function tables\(\).*?return array\s*\((.*?)\);/s', $schemaContent, $mm)) {
        preg_match_all("/'estat_[a-z_]+'/", $mm[1], $m);
        $tablesInSchema = array_unique($m[0]);
        $uninstallContent = file_get_contents($uninstallFile);
        foreach ($tablesInSchema as $t) {
            $bare = trim($t, "'");
            if (strpos($uninstallContent, $bare) === false) {
                $errors[] = "Uninstall missing table: $bare";
            }
        }
    }
}

// 2. No hardcoded Gurugram in TeamNew
$teamNew = $root . '/includes/Admin/Screens/TeamNew.php';
if (file_exists($teamNew)) {
    $c = file_get_contents($teamNew);
    if (stripos($c, 'Gurugram') !== false) $errors[] = "TeamNew contains hardcoded Gurugram";
    if (preg_match('/style\s*=\s*\"[^\"]*\"/', $c, $m) && substr_count($c, 'style="') > 10) $warnings[] = "TeamNew contains many inline style=\"\" — use classes";
}

// 3. No fake data in New screens
$fakePatterns = ['£142.8M', 'MF00'];
foreach (glob($root . '/includes/Admin/Screens/*New.php') as $f) {
    $c = file_get_contents($f);
    foreach ($fakePatterns as $fp) {
        if (strpos($c, $fp) !== false) {
            $warnings[] = basename($f) . " contains possible fake data: $fp";
        }
    }
}

// 4. Public templates must have get_header/get_footer and wrapper — exclude print template (standalone HTML)
foreach (glob($root . '/includes/Frontend/templates/*.php') as $f) {
    if (basename($f) === 'print-listing.php') continue;
    $c = file_get_contents($f);
    if (strpos($c, 'get_header') === false) $errors[] = basename($f) . " missing get_header()";
    if (strpos($c, 'get_footer') === false) $errors[] = basename($f) . " missing get_footer()";
    if (strpos($c, 'estat-public') === false) $errors[] = basename($f) . " missing estat-public wrapper";
    if (preg_match('/💬|🔗|✉️|📤|🖨️|✅|💰|🏠/', $c)) $errors[] = basename($f) . " contains emoji";
}

// 5. public.css ≤60KB, public.js ≤20KB
$css = $root . '/assets/css/public.css';
$js = $root . '/assets/js/public.js';
if (file_exists($css) && filesize($css) > 60*1024) $errors[] = "public.css >60KB: ".filesize($css);
if (file_exists($js) && filesize($js) > 20*1024) $errors[] = "public.js >20KB: ".filesize($js);

// 6. No inline style in SettingsNew
$settingsNew = $root . '/includes/Admin/Screens/SettingsNew.php';
if (file_exists($settingsNew)) {
    $c = file_get_contents($settingsNew);
    if (substr_count($c, 'style="') > 10) $warnings[] = "SettingsNew has many inline styles: ".substr_count($c, 'style="');
}

// 7. Capability checks
foreach (glob($root . '/includes/Admin/Screens/*New.php') as $f) {
    $c = file_get_contents($f);
    if (strpos($c, 'current_user_can') === false) $errors[] = basename($f) . " missing capability check";
}

// 8. Check Activator idempotent
$activator = $root . '/includes/Install/Activator.php';
if (file_exists($activator)) {
    $c = file_get_contents($activator);
    if (strpos($c, 'ensure_all') !== false) $errors[] = "Activator calls ensure_all — should not auto-publish pages";
}

// 9. Admin menu simplification check
$adminFile = $root . '/includes/Admin/Admin.php';
if (file_exists($adminFile)) {
    $c = file_get_contents($adminFile);
    if (strpos($c, 'NewUI::is_enabled()') === false) $warnings[] = "Admin.php should check NewUI for simplified menu";
}

echo "=== Estat.OS Bug Check ===\n";
echo "Errors: ".count($errors)."\n";
foreach ($errors as $e) echo "  ERROR: $e\n";
echo "Warnings: ".count($warnings)."\n";
foreach ($warnings as $w) echo "  WARN: $w\n";
if (empty($errors)) echo "✓ No critical errors\n";
exit(count($errors) > 0 ? 1 : 0);
