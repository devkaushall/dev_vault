# The Estat.OS design system

This file is the law. Not a suggestion list, not a mood board — the law. Any
screen, any email, any invoice, any new component that this plugin will ever
draw obeys it, and the tests named at the bottom of each section enforce
exactly that. If you change a rule, you change the rule here, change the token
block in `assets/css/admin.css`, and change the test — all three, one commit,
or none.

Why this file exists in words instead of vibes: the moment a design system
lives only in whoever's head built it, every future contributor — human or
agent — quietly invents their own. That is how a product starts to look like
three products wearing one logo.

The visual taste encoded here was decided and locked before a line of it was
styled (see the training report): calm, dense, quiet; gradients that go
nowhere, glass everywhere, emoji as icons, identical card grids, one giant
number with a tiny label beside it, dark mode with a neon accent, headings in
gradient text, colour outside tokens — all rejected, all of it, permanently.
None of the banned things are in this system, and most of them now fail a test
if they try to move in.

## 1. Colour

### The one rule that outranks all others

**Every colour lives in a token block at the top of `assets/css/admin.css` and
nowhere else.** There are exactly three blocks: the light theme on
`.estat-screen`, the manual dark theme on `.estat-screen.estat-theme-dark`, and
the automatic dark theme — the same dark values inside
`@media ( prefers-color-scheme: dark )` on `.estat-screen.estat-theme-auto`. A
selector may say `var(--estat-muted)`; it may never say `#616c7c`. The only
exception: `rgba()` tints for shadows, focus rings and tap highlights, declared
at the token itself, so each colour still has one home. `it-23` greps for any
hex outside the three blocks and fails the suite; the same test pins that
`estat-theme-auto` mirrors every dark colour token exactly, because dark
without the class needs its own values and the classic mistake is updating one
and forgetting the other (this found a real bug at 2.7.0: auto mode had no
`on-accent`, and drew off-white button labels on the dark-mode accent).

### The tokens, and what each one is *for*

| Token | Light | Dark + auto | Job |
| --- | --- | --- | --- |
| `ink` | `#16202c` | `#e9eef5` | Body text. Not pure black — pure black on off-white fights the eye. |
| `ink-soft` | `#3d4b5c` | `#c2cddb` | Labels, values, text that matters but doesn't lead. |
| `muted` | `#616c7c` | `#93a1b3` | Helper text, metadata, timestamps, placeholders, empty-state copy. |
| `faint` | `#93a0b1` | `#6d7c90` | **Decoration only:** the two icon wells (dropzone, empty state), button hover borders, the strike through a replaced value. Nothing may paint text with it — `it-23` keeps `faint` on an allowlist of selectors for exactly this reason. |
| `accent` | `#2768e8` | `#5b91ff` | The one primary action on a screen. |
| `accent-soft` | `#eaf1fe` | `#1b2b47` | Selected rows, info pill fills, focus washes. |
| `accent-ink` | `#1a4fbd` | `#a8c5ff` | Links, and small text sitting on soft tints where accent itself would hum. |
| `on-accent` | `#f8fafd` | `#0b1016` | The label on an accent-filled button. Off-white on blue, near-black on the lightened dark-mode blue — pure white on a saturated colour vibrates. |
| `good` + `-soft` | `#107a53` `#e6f7ef` | `#3fbb85` `#122b22` | Published, verified, approved. Text role and fill role are different tokens; never swap them. |
| `warn` + `-soft` | `#985f09` `#fdf3e2` | `#e0a44a` `#2e2415` | Pending, expiring, needs-a-human. |
| `danger` + `-soft` | `#c0392f` `#fdeceb` | `#f0736a` `#331c1b` | Deletion, failed verification. Red is rare on purpose: if a screen draws two reds, one is wrong. |
| `bg` | `#f4f6f9` | `#0f151d` | The page. Nothing is read directly on `bg`. |
| `card` | `#fdfdfe` | `#171f2a` | The surface things are read on. |
| `card-alt` | `#f8fafc` | `#1c2632` | Hover, stripes, secondary panels. |
| `sunken` | `#eef1f6` | `#131b24` | Recessed: table heads, icon wells, the `kbd` chips, code previews. |
| `line` / `line-strong` | `#e3e8ef` `#cfd7e3` | `#29343f` `#3a4756` | Hairline structure vs. the line that is itself information. |

Spacing, type and radius tokens are also here (§2–§4); they're shared by both
themes, so they're declared once.

### The contrast law, measured — `it-23`

Audited against every surface it can sit on, both themes, with the real WCAG
formula at run time on the live token block — not eyeballs, not a screenshot
from 2024. The floor:

* **Text: ≥ 4.5:1 on its worst surface, at every size the theme draws it at.**
  11px helper text gets no "large text" exemption because none of this is
  large text.
* **Graphics (icons, borders, strokes): ≥ 3:1.**
* The button's own label counts as text: light is 4.75:1 on the accent.

The loosest real pair in the light theme is 4.62:1; in the dark theme, 4.97.
Those are floors, not averages. Before this was pinned, the same measurement
found four failures (helper text 3.93, the two status colours 4.06 and 4.17,
button label 4.37) — that audit and its fixes are what 2.7.0's palette is.

### The outside world

`public.css` and `forms.css` keep their own token blocks and their own audit,
and since 2.9.0 they are cut to the shop they stand in: the live Mayfair site
(Elementor, kit colours `#725b2f` gold on cream `#f9f7f2`, system fonts, warm
dark `#171411`) is where these screens render, so the visitor-facing palette
is that gold — not the office blue the pocket and dashboard use. Re-verified
after the move: worst public text pair 5.24, dark floor 6.59, form labels
5.51+, button label on gold 6.34. They may drift from the office where a public screen needs to — a
screen a client sees has to survive theme languages we don't control.

Everything the office itself renders — wp-admin screens, the phone pocket,
and the dashboard to come — reads one file: `assets/css/tokens.css`. Since
the 2.9.0 token consolidation the pocket no longer keeps a copy "locked to
match"; it loads the same values, so matching is structural, not audited.
`it-32` pins that neither `pocket.css` nor `admin.css` restates a single
palette value, and `it-23` runs the contrast maths on the shared file.

## 2. Type

* **Seven steps, that's all: 11 / 12 / 13 / 15 / 17 / 22 / 28**
  (`--estat-text-xs` → `--estat-text-2xl`, base `--estat-text: 13px`). The
  token comment calls it six steps plus a base; either name, the law is the
  list. `it-23` counts the definitions, requires whole pixels, and requires no
  duplicates. A size off the scale is a bug report, not a design choice.
* **The interface is one stack:** the system sans (`-apple-system, Segoe UI,
  Roboto, …`). Serif (Georgia) and monospace exist only inside the form
  builder's font switcher — they're *the client's* preview, not our chrome —
  plus monospace `kbd` chips in the shortcuts panel. That's the entire list.
* **Weights:** 400 body, 500 labels, 600 titles and buttons, 700 for the two
  biggest display sizes only. (550/650/680 appear nowhere static; if a
  variable-font experiment ever uses them, it's a PR, not a tweak.)
* **Line heights:** 1.25 headings, 1.45 body, 1.6 long-form (`xs` through
  `loose` tokens). Three, not four.
* **Letter-spacing:** −0.01 to −0.03em tightening at 17px+, +0.01 to +0.05em
  tracking on tiny caps-style labels. The one place typography is allowed to
  be visible.
* A heading is never gradient text, never uppercase at full size, and never
  larger than 28px. This is a tool.

## 3. Space

Six steps — **4 / 8 / 16 / 20 / 28 / 40** (`--estat-gap-xs` …
`--estat-gap-xl`) — and nothing between them. Consequences that make screens
feel designed instead of assembled:

* Inside a control: 8. Between controls: 16. Inside a card: 20. Card to card:
  16. Page margins and section breaks: 28–40.
* Table cells get 10/12 — the one functional exception, because cell metrics
  are a grid problem, not a layout one; it is written here so it stays the
  only one.
* Two elements never keep the same number by coincidence. If a gap looks one
  step too wide, change the step; never invent 14px.

## 4. Shape, line, elevation

* **Radius:** 8 for inputs, buttons and small chips; 12 for cards, tables and
  panels; 16 for the biggest hero panels; 999 for pills and avatars. Four
  values; nothing half-rounds into a blob.
* **Lines:** `line` hairline for structure; `line-strong` only where the line
  is information — a dropzone's dashed border, a focused control's edge.
* **Elevation:** three shadows (`sm`, default, `lg`), each a tight contact
  layer plus a wide ambient one, 4–10% in light, 35–50% in dark. A card holds
  `shadow-sm` with a 0.15s transition on border and shadow; nothing floats
  past `lg`, and the only glow in the product is the focus ring.
* **Focus ring:** exactly one — `--estat-ring`, 3px at 18% of the accent
  (28% in dark). Every interactive thing, both themes, keyboard users are not
  optional; `it-23` checks the ring exists.

## 5. Icons

* One family: **Phosphor Regular on the 256-unit grid**, 98 icons, served only
  by `includes/Support/Icon.php`. New glyph = extend the set and its test —
  never inline a hand-drawn `<svg>`, never an icon font, never an emoji.
  `it-23`'s "Icons are a set, not whatever emoji was to hand" group greps for
  emoji in product code and fails on them, and checks the grid constant.
* Icons inherit `currentColor`, sit at the size of the text they accompany,
  and never get their own colour opinion: accent-painted icons are how
  dashboards start looking like toys.
* An icon never carries meaning alone — every icon ships with its word (a
  label, a `title`, visible text beside it). `it-23` asserts it.

## 6. Components (one shape each, everywhere)

These are the shipped shapes, measured from `admin.css` — the standard is that
new screens reuse them, not that they match this file by accident.

* **Buttons.** Primary: `accent` fill and border, `on-accent` label, 600
  weight, radius 8, `shadow-sm`. Secondary: `card` fill, `line-strong`
  border, `ink` label; hover steps the background to `card-alt` and the
  border to `faint` — background moves, nothing bounces. Touch size grows to
  40px min-height at the 782px breakpoint — WordPress's own touch-layout
  switch, borrowed rather than reinvented. One primary per screen;
  if two compete, one becomes secondary, not both get louder.
* **Pills.** `--estat-pill`: `sunken` fill, radius 999, 12px text, padding
  1px/10px — neutral by default. Status variants (`is-good`, `is-warn`,
  `is-danger`) swap the fill to the soft and the text to the strong token of
  the same family, border transparent. Never a raw colour; never two pill
  families fighting in one row.
* **Cards.** `card` fill on `bg`, 1px `line` border, radius 12, `shadow-sm`,
  padding 20, 16 between cards, 0.15s transition on border and shadow. A card
  header is `md`/600 — that is the whole decoration budget.
* **Tables.** Wrapper carries the radius and hairline with `overflow: hidden`;
  `thead th` sits on `sunken` at 13px; cells 10px/12px, top-aligned. No
  stripes on short tables — rows are separated by hairlines; `card-alt` is for
  hover and selection only.
* **Empty states.** A 60px circle in `sunken` with the `faint` icon at 22px,
  one `muted` sentence, exactly one primary action. No illustration, no
  second button, no "Oops!".
* **Dropzones.** `card` fill, 2px dashed `line-strong`, radius 12, padding
  28/20, centred, `faint` icon; the drag-over state moves the border to the
  accent and the fill to `accent-soft` — the only time those two appear
  together as feedback.
* **The Today list** is the home screen's only hero. `card` rows, bottom
  hairlines, 8px gaps; urgency is a 34px `sunken` icon well that tints to the
  relevant soft (`is-danger`/`is-warn`/`is-accent`) — a coloured dot of
  urgency, not a loud banner. That line is in the CSS comment and it is the
  rule.
* **Notices** take the same four families as pills (info/warn/good/danger on
  their softs) and never a fifth visual language.

## 7. Motion

* Durations: **0.08s** press feedback, **0.12–0.15s** state changes (the
  card, button and dropzone transitions above), **0.25s** panel reveals, one
  **0.7s** spin for genuinely long waits. Slower means it should be a
  skeleton, not a showreel; anything sliding more than 8px is a page change,
  not feedback. Numbers never count up by themselves.
* `@media (prefers-reduced-motion: reduce)` turns all of it off globally, in
  every block of the sheet.

## 8. Voice (the copy half of the design system)

* Plain English, sentence case, contractions fine, nothing cute.
* Errors name the fact and the remedy in two sentences ("This nonce has passed
  its window. Open the page again and confirm."). Never an apology paragraph;
  never an exclamation mark in a failure state.
* Buttons say what happens in words the user would repeat back — "Yes, change
  it", "Send for review".
* Hinglish surfaces (setup docs, onboarding) obey the same scale and colour
  law; Dev-facing prose may be warm, the interface may not be chatty.

## 9. The "never looks AI-generated" checklist

Every line is either a banned pattern with a test or a manual review item, so
"make it less AI" is checkable, not a feeling:

| Tell | Guard |
| --- | --- |
| Colour off the token blocks | `it-23` hex audit (this release) |
| Unmeasured contrast decay | `it-23` WCAG audit on the live tokens (this release) |
| Dark/auto palette drift | `it-23` mirror test (this release) |
| Invented sizes, half pixels, duplicate steps | `it-23` type-scale group |
| Emoji, mixed icon grids, lone icons | `it-23` icon groups |
| Missing focus ring, dead hover states | `it-23` interaction group |
| Gradient headings, glass, glow, count-up theatrics | banned in §2/§4/§7; any PR touching CSS attaches a screenshot of each affected screen in all three themes — light, dark, auto-in-dark |
| Card-grid sameness, giant-number dashboards | rejected at taste level; a new screen needs a §6 paragraph here before it ships |

## Changing the system

1. Edit this file, the token blocks, and the test — together or not at all.
2. Run `tests/integration/it-23-design-discipline.php`; a failure names the
   pair or the rule broken.
3. Screenshots of touched screens, all three themes, in the PR.
4. A new *component* gets a §6 paragraph first. One-off styling gets nothing,
   because it isn't allowed.

Locked at 2.8.0 (2026-09), where the pocket screens came under the same law. If a number in this file stops matching
`admin.css`, the tests failed and someone shipped anyway.
