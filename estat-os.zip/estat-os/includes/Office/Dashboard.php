<?php
/**
 * The office dashboard — the desktop half of the same product as the pocket.
 *
 * It is a front-end route (/dashboard) that prints its own document, exactly
 * like the pocket does, for the same reason: template_redirect exits before
 * any theme chrome could be relied on, and the office wants one layout on a
 * laptop, a tablet and a phone. No logic lives here. Approval goes through
 * Field\Requests, counts come from Leads and Visits, icons come from the one
 * icon set, and every colour comes from tokens.css — the file the phone loads
 * too. The phone rules are the dashboard rules: nothing publishes itself.
 *
 * @package EstatOS
 */

namespace EstatOS\Office;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Pocket\Pocket;
use EstatOS\Support\Sanitize;

defined( 'ABSPATH' ) || exit;

/**
 * Routes, guards and the two actions the office can take from here.
 */
class Dashboard {

	const ROUTE = 'dashboard';
	const NONCE = 'estat_office';

	/**
	 * Known views. Keys double as the URL slug; '' is Today.
	 *
	 * @return array<string,string>
	 */
	public static function views(): array {
		return array(
			''         => __( 'Today', 'estat-os' ),
			'listings' => __( 'Listings', 'estat-os' ),
			'requests' => __( 'Approvals', 'estat-os' ),
		);
	}

	/**
	 * Hook the route in.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'init', array( __CLASS__, 'add_rewrites' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle' ), 4 );
	}

	/**
	 * The /dashboard routes.
	 *
	 * @return void
	 */
	public static function add_rewrites(): void {
		if ( ! function_exists( 'add_rewrite_rule' ) || ! function_exists( 'flush_rewrite_rules' ) ) {
			return; // CLI harnesses and early contexts: routing is a web concern.
		}
		add_rewrite_rule( '^' . self::ROUTE . '/([a-z-]+)/([0-9]+)/?$', 'index.php?estat_office_view=$matches[1]&estat_office_id=$matches[2]', 'top' );
		add_rewrite_rule( '^' . self::ROUTE . '(?:/([a-z-]+))?/?$', 'index.php?estat_office_view=$matches[1]', 'top' );

		if ( get_option( 'estat_office_flush' ) !== ESTAT_VERSION ) {
			update_option( 'estat_office_flush', ESTAT_VERSION, false );
			flush_rewrite_rules();
		}
	}

	/**
	 * Make the route variables known to WordPress.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public static function query_vars( array $vars ): array {
		$vars[] = 'estat_office_view';
		$vars[] = 'estat_office_id';
		return $vars;
	}

	/**
	 * Is this request for the dashboard?
	 *
	 * @return bool
	 */
	public static function serving(): bool {
		return isset( $GLOBALS['wp']->query_vars['estat_office_view'] );
	}

	/**
	 * Who may see what, in one honest question.
	 *
	 * Screens::render asks the same gate, so a direct render call in a test
	 * or a template cannot skip it. 'login' sends strangers to wp-login with
	 * a way back; 'office-only' is the polite refusal agents get — their
	 * tools are on the phone, at /agent.
	 *
	 * @return string '' when all is well, else the reason.
	 */
	public static function gate(): string {
		if ( ! is_user_logged_in() ) {
			return 'login';
		}
		if ( ! Pocket::is_office() ) {
			return 'office-only';
		}
		return '';
	}

	/**
	 * Route, guard, act, render.
	 *
	 * @return void
	 */
	public static function handle(): void {
		if ( ! self::serving() ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$view = (string) get_query_var( 'estat_office_view' );
		$id   = (int) get_query_var( 'estat_office_id' );
		// phpcs:enable

		if ( ! array_key_exists( $view, self::views() ) ) {
			status_header( 404 );
			echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>' . esc_html__( 'Not found', 'estat-os' ) . '</title></head><body style="font-family:sans-serif;padding:2rem 1rem"><p>' .
				esc_html__( 'That page of the dashboard does not exist.', 'estat-os' ) .
				'</p><p><a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Go to Today', 'estat-os' ) . '</a></p></body></html>';
			exit; // the theme must not paste its own page underneath this one
		}

		$gate = self::gate();
		if ( 'login' === $gate ) {
			wp_safe_redirect( wp_login_url( self::url( $view, $id ) ) );
			exit; // a redirect that keeps running answers the request twice
		}

		if ( 'POST' === strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			self::post(); // redirects, never returns.
		}

		Screens::render( $view, $id );
	}

	/**
	 * One POST entry point: nonce, capability, action, in that order. The
	 * same shape as the pocket's — a click here is the same business act
	 * as the identical click on a phone, through the same functions.
	 *
	 * @return void
	 */
	public static function post(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$nonce  = isset( $_POST['_estat_office'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['_estat_office']) ? '' : $_POST['_estat_office'] ) ) ) : '';
		$action = isset( $_POST['estat_office_action'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_office_action']) ? '' : $_POST['estat_office_action'] ) ) ) : '';
		// phpcs:enable

		if ( ! is_user_logged_in() || ! wp_verify_nonce( $nonce, self::NONCE ) ) {
			self::redirect( '', 0, 'nope' );
		}
		if ( ! Pocket::is_office() ) {
			self::redirect( '', 0, 'nope' );
		}

		switch ( $action ) {
			case 'request_approve':
			case 'request_decline':
				self::settle_request( 'request_approve' === $action ? 'approve' : 'decline' );
				return;
			case 'listing_publish':
				self::move_listing( 'pending', 'publish', 'listing.published', __( 'Approved and published from the dashboard.', 'estat-os' ), 'listed', true );
				return;
			case 'listing_return':
				self::move_listing( 'pending', 'draft', 'listing.returned', __( 'Sent back to the agent as a draft, from the dashboard.', 'estat-os' ), 'listed_back', true );
				return;
			case 'listing_pause':
				self::move_listing( 'publish', 'private', 'listing.paused', __( 'Paused from the dashboard.', 'estat-os' ), 'paused', false );
				return;
			case 'listing_resume':
				self::move_listing( 'private', 'publish', 'listing.resumed', __( 'Made live again from the dashboard.', 'estat-os' ), 'resumed', false );
				return;
			default:
				self::redirect( '', 0, 'nope' );
		}
	}

	/**
	 * Approve or turn down a change request — through the same
	 * Requests::approve()/decline() the pocket and the wp-admin screen use.
	 * Three doors, one lock.
	 *
	 * @param string $verb approve|decline.
	 * @return void
	 */
	private static function settle_request( string $verb ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$request_id = isset( $_POST['request_id'] ) ? (int) wp_unslash( (string) ( is_array($_POST['request_id']) ? '' : $_POST['request_id'] ) ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason     = isset( $_POST['reason'] ) ? Sanitize::textarea( wp_unslash( (string) ( is_array($_POST['reason']) ? '' : $_POST['reason'] ) ) ) : '';

		$result = 'approve' === $verb ? Requests::approve( $request_id ) : Requests::decline( $request_id, $reason );
		if ( is_wp_error( $result ) ) {
			self::redirect( 'requests', 0, 'failed' );
		}
		self::redirect( 'requests', 0, 'approve' === $verb ? 'approved' : 'declined' );
	}

	/**
	 * One status move on a listing, with its audit line — a deliberate
	 * double of the pocket's move_status(): same shape, same honesty, only
	 * the channel word differs. Publishing and returning keep the stricter
	 * key: they need the same capability wp-admin's editor asks for. Pause
	 * and resume stay within ordinary office rights, on either surface.
	 *
	 * @param string $from   Status the row must still carry, or '' for any.
	 * @param string $to     Target status.
	 * @param string $action Audit action word.
	 * @param string $note   One human sentence for the audit row.
	 * @param string $flash  Key for the return trip.
	 * @param bool   $strict Require the publish capability.
	 * @return void
	 */
	private static function move_listing( string $from, string $to, string $action, string $note, string $flash, bool $strict ): void {
		if ( $strict && ! current_user_can( 'estat_publish_listings' ) && ! current_user_can( 'estat_manage_settings' ) ) {
			self::redirect( 'listings', 0, 'nope' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$record_id = isset( $_POST['record_id'] ) ? (int) wp_unslash( (string) ( is_array($_POST['record_id']) ? '' : $_POST['record_id'] ) ) : 0;
		$post      = $record_id > 0 ? get_post( $record_id ) : null;

		if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
			self::redirect( 'listings', 0, 'nope' );
		}
		if ( '' !== $from && $post->post_status !== $from ) {
			self::redirect( 'listings', 0, 'stale' ); // Somebody else moved it first; refresh and look again.
		}

		wp_update_post(
			array(
				'ID'          => $record_id,
				'post_status' => $to,
			)
		);
		AuditLog::record( $action, $post->post_type, $record_id, array( 'channel' => 'dashboard', 'note' => $note ) );

		self::redirect( 'listings', 0, $flash );
	}

	/* ---------------------------------------------------------------------
	 * URLs and flashes — the pocket's rules restated, because they are good.
	 * ------------------------------------------------------------------ */

	/**
	 * Dashboard URL for a view (and optional record).
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID.
	 * @return string
	 */
	public static function url( string $view = '', int $id = 0 ): string {
		$path = home_url( '/' . self::ROUTE . '/' );
		if ( '' !== $view ) {
			$path .= $view . '/';
		}
		if ( $id > 0 ) {
			$path .= $id . '/';
		}
		return $path;
	}

	/**
	 * Redirect to a view with a flash key. Keys come from a fixed table;
	 * user text never travels through the URL.
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID.
	 * @param string $ok   Flash key.
	 * @return void
	 */
	public static function redirect( string $view, int $id = 0, string $ok = '' ): void {
		$url = self::url( $view, $id );
		if ( '' !== $ok ) {
			$url = add_query_arg( 'flash', rawurlencode( $ok ), $url );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * The flash sentence for this request, or ''.
	 *
	 * @return string
	 */
	public static function flash(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$key = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['flash']) ? '' : $_GET['flash'] ) ) ) : '';
		if ( '' === $key ) {
			return '';
		}
		$table = array(
			'approved' => __( 'Change applied — the listing now shows the new values.', 'estat-os' ),
			'declined' => __( 'Request turned down. The agent sees why.', 'estat-os' ),
			'failed'   => __( 'That request could not be settled. Refresh and try again.', 'estat-os' ),
			'listed'   => __( 'The listing is live — the public site shows it now.', 'estat-os' ),
			'listed_back' => __( 'Sent back to the agent as a draft.', 'estat-os' ),
			'paused'   => __( 'Listing paused. The page comes down; nothing is lost.', 'estat-os' ),
			'resumed'  => __( 'Listing is live again.', 'estat-os' ),
			'stale'    => __( 'That listing moved since the page was drawn. Refresh and look again.', 'estat-os' ),
			'nope'     => __( 'That did not look like your request, so nothing was changed.', 'estat-os' ),
		);
		return $table[ $key ] ?? '';
	}
}
