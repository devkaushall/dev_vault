<?php
/**
 * Print template — clean summary for ?print=1.
 *
 * No external CSS, inline styles only for print preview and PDF.
 * Includes: title, verified badge humne khud dekha, price, price per sqft, locality, address, cover, gallery (6), facts, description, amenities, agent, EMI, QR, footer disclaimer.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Listings;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

$listing_id = get_the_ID();
$listing    = Listings::to_array( $listing_id, false );
$office_name = Settings::get( 'office_name', get_bloginfo( 'name' ) );
$office_phone = Settings::get( 'office_phone', '' );
$office_email = Settings::get( 'office_email', '' );

$price = $listing['price'] ?? 0;
$area = $listing['area'] ?? 0;
$price_per_sqft = ( $price > 0 && $area > 0 ) ? ( $price / $area ) : 0;

$gallery = $listing['gallery'] ?? array();
$gallery = is_array( $gallery ) ? array_slice( $gallery, 0, 6 ) : array();

$agent = $listing['agent'] ?? null;
if ( ! $agent ) {
	// Try to get agent from listing meta via to_array already includes agent.
	$agent = array();
}

$verified = 'office_verified' === (string) ( $listing['verification'] ?? '' );
$url = get_permalink( $listing_id );
$qr_api = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=' . rawurlencode( $url );

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( get_the_title() ); ?> — <?php echo esc_html( $office_name ); ?></title>
<style>
*{box-sizing:border-box}
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;max-width:840px;margin:0 auto;padding:24px;color:#111;line-height:1.6;background:#fff}
h1{font-size:28px;margin:0 0 6px;line-height:1.2}
h2{font-size:18px;margin:20px 0 10px;border-bottom:1px solid #e5e7eb;padding-bottom:6px}
.meta{color:#555;margin-bottom:12px;font-size:14px}
.price{font-size:24px;font-weight:800;margin:12px 0;color:#111}
.price small{font-size:13px;font-weight:400;color:#6b7280}
.facts{columns:2;list-style:none;padding:0;margin:0}
.facts li{margin:6px 0;font-size:13px;break-inside:avoid}
.cover img{max-width:100%;height:auto;border-radius:10px;display:block}
.gallery{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}
.gallery img{width:120px;height:80px;object-fit:cover;border-radius:6px;border:1px solid #e5e7eb}
.verified{display:inline-block;background:#dcfce7;color:#166534;border:1px solid #bbf7d0;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;margin-left:8px}
.badge{display:inline-block;background:#f3f4f6;color:#111;border:1px solid #e5e7eb;padding:2px 8px;border-radius:999px;font-size:11px;margin-right:4px}
.agent-card{display:flex;gap:16px;align-items:flex-start;border:1px solid #e5e7eb;border-radius:12px;padding:14px;background:#f9fafb;margin:16px 0}
.agent-card img{width:64px;height:64px;border-radius:50%;object-fit:cover}
.emi{border:1px dashed #e5e7eb;border-radius:10px;padding:12px;background:#fffbeb;margin:12px 0;font-size:13px}
.qr{float:right;text-align:center;margin:0 0 12px 12px}
.qr img{width:120px;height:120px;border:1px solid #e5e7eb;border-radius:8px}
.desc{font-size:14px}
.footer{margin-top:24px;padding-top:12px;border-top:1px solid #e5e7eb;font-size:11px;color:#6b7280}
@media print{
  body{padding:0}
  .no-print{display:none !important}
  a{color:#111;text-decoration:none}
  .cover img{max-height:320px}
}
</style>
</head>
<body>
<div class="qr no-print">
	<img src="<?php echo esc_url( $qr_api ); ?>" alt="QR" loading="lazy">
	<div style="font-size:10px;color:#6b7280;margin-top:4px">Scan to view</div>
</div>

<h1><?php the_title(); ?><?php if ( $verified ) : ?><span class="verified">Verified by <?php echo esc_html( $office_name ); ?></span><?php endif; ?></h1>

<div class="meta">
	<?php echo esc_html( implode( ', ', (array) ( $listing['locality'] ?? array() ) ) ); ?>
	<?php if ( ! empty( $listing['address'] ) ) : ?> · <?php echo esc_html( (string) $listing['address'] ); ?><?php endif; ?>
	<?php if ( ! empty( $listing['days_listed'] ) ) : ?> · <?php printf( esc_html( _n( '%d day on website', '%d days on website', (int) $listing['days_listed'], 'estat-os' ) ), (int) $listing['days_listed'] ); ?><?php endif; ?>
</div>

<div class="price">
	<?php echo esc_html( (string) ( $listing['price_display'] ?? Format::money( (float) $price ) ) ); ?>
	<?php if ( $price_per_sqft > 0 ) : ?><small> · <?php echo esc_html( Format::money( $price_per_sqft ) ); ?>/sqft</small><?php endif; ?>
	<?php if ( ! empty( $listing['offer'] ) ) : ?><span class="badge"><?php echo esc_html( Vocabulary::label( 'offers', (string) $listing['offer'] ) ); ?></span><?php endif; ?>
	<?php if ( ! empty( $listing['property_type'] ) ) : ?><span class="badge"><?php echo esc_html( Vocabulary::label( 'property_types', (string) $listing['property_type'] ) ); ?></span><?php endif; ?>
</div>

<?php if ( '' !== (string) ( $listing['cover'] ?? '' ) ) : ?>
<div class="cover"><img src="<?php echo esc_url( (string) $listing['cover'] ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>"></div>
<?php endif; ?>

<?php if ( $gallery ) : ?>
<div class="gallery">
	<?php foreach ( $gallery as $img_url ) : ?>
		<img src="<?php echo esc_url( is_array( $img_url ) ? ( $img_url['url'] ?? '' ) : (string) $img_url ); ?>" alt="" loading="lazy">
	<?php endforeach; ?>
</div>
<?php endif; ?>

<h2><?php esc_html_e( 'Facts', 'estat-os' ); ?></h2>
<ul class="facts">
	<?php if ( (float) $area > 0 ) : ?><li><strong><?php esc_html_e( 'Size', 'estat-os' ); ?>:</strong> <?php echo esc_html( Format::area( (float) $area, (string) ( $listing['area_unit'] ?? 'sqft' ) ) ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['bedrooms'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Bedrooms', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $listing['bedrooms'] ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['bathrooms'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Bathrooms', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $listing['bathrooms'] ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['floor'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Floor', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $listing['floor'] ); ?><?php if ( (int) ( $listing['total_floors'] ?? 0 ) > 0 ) : ?> / <?php echo esc_html( (string) $listing['total_floors'] ); ?><?php endif; ?></li><?php endif; ?>
	<li><strong><?php esc_html_e( 'Availability', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'availability', (string) ( $listing['availability'] ?? '' ) ) ); ?></li>
	<li><strong><?php esc_html_e( 'Construction', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'construction', (string) ( $listing['construction'] ?? '' ) ) ); ?></li>
	<?php if ( '' !== (string) ( $listing['facing'] ?? '' ) ) : ?><li><strong><?php esc_html_e( 'Facing', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'facing', (string) $listing['facing'] ) ); ?></li><?php endif; ?>
	<?php if ( '' !== (string) ( $listing['furnishing'] ?? '' ) ) : ?><li><strong><?php esc_html_e( 'Furnishing', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'furnishing', (string) $listing['furnishing'] ) ); ?></li><?php endif; ?>
	<?php if ( '' !== (string) ( $listing['possession'] ?? '' ) ) : ?><li><strong><?php esc_html_e( 'Possession', 'estat-os' ); ?>:</strong> <?php echo esc_html( Vocabulary::label( 'possession_timeline', (string) $listing['possession'] ) ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['age'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Age', 'estat-os' ); ?>:</strong> <?php printf( esc_html( _n( '%d year', '%d years', (int) $listing['age'], 'estat-os' ) ), (int) $listing['age'] ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['parking'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Parking', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $listing['parking'] ); ?></li><?php endif; ?>
	<?php if ( (int) ( $listing['balconies'] ?? 0 ) > 0 ) : ?><li><strong><?php esc_html_e( 'Balconies', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $listing['balconies'] ); ?></li><?php endif; ?>
	<?php if ( '' !== (string) ( $listing['rera_id'] ?? '' ) ) : ?><li><strong>RERA:</strong> <?php echo esc_html( (string) $listing['rera_id'] ); ?></li><?php endif; ?>
</ul>

<?php if ( ! empty( $listing['amenities'] ) || ! empty( $listing['features'] ) ) : ?>
<h2><?php esc_html_e( 'Amenities & Features', 'estat-os' ); ?></h2>
<p style="font-size:13px">
	<?php
	$amenities = array();
	foreach ( (array) ( $listing['amenities'] ?? array() ) as $am ) {
		$amenities[] = is_array( $am ) ? ( $am['name'] ?? '' ) : (string) $am;
	}
	foreach ( (array) ( $listing['features'] ?? array() ) as $ft ) {
		$amenities[] = is_array( $ft ) ? ( $ft['name'] ?? '' ) : (string) $ft;
	}
	echo esc_html( implode( ' · ', array_filter( $amenities ) ) );
	?>
</p>
<?php endif; ?>

<div class="desc">
	<h2><?php esc_html_e( 'About this property', 'estat-os' ); ?></h2>
	<?php echo wp_kses_post( get_the_content() ); ?>
</div>

<?php if ( Settings::get( 'emi_enabled' ) && $price > 0 ) : ?>
<div class="emi">
	<strong><?php esc_html_e( 'EMI Estimate', 'estat-os' ); ?></strong><br>
	<?php
	$rate = 8.5; $years = 20;
	$monthly_rate = $rate / 12 / 100;
	$n = $years * 12;
	$emi = $price * $monthly_rate * pow(1+$monthly_rate, $n) / (pow(1+$monthly_rate, $n)-1);
	echo esc_html( sprintf( __( 'Loan ₹%s @ %.1f%% for %d years ≈ ₹%s / month', 'estat-os' ), number_format( $price * 0.8 ), $rate, $years, number_format( $emi ) ) );
	?>
	<div style="font-size:11px;color:#6b7280;margin-top:4px"><?php esc_html_e( '80% loan, indicative only. Contact office for exact.', 'estat-os' ); ?></div>
</div>
<?php endif; ?>

<?php if ( ! empty( $agent ) && is_array( $agent ) ) : ?>
<h2><?php esc_html_e( 'Contact', 'estat-os' ); ?></h2>
<div class="agent-card">
	<?php if ( ! empty( $agent['photo'] ) ) : ?><img src="<?php echo esc_url( (string) $agent['photo'] ); ?>" alt=""><?php endif; ?>
	<div>
		<strong><?php echo esc_html( (string) ( $agent['name'] ?? $office_name ) ); ?></strong><br>
		<?php if ( ! empty( $agent['role'] ) ) : ?><span style="font-size:12px;color:#6b7280"><?php echo esc_html( (string) $agent['role'] ); ?></span><br><?php endif; ?>
		<?php if ( ! empty( $agent['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $agent['phone'] ) ); ?>"><?php echo esc_html( (string) $agent['phone'] ); ?></a> · <?php endif; ?>
		<?php if ( ! empty( $agent['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( (string) $agent['email'] ); ?>"><?php echo esc_html( (string) $agent['email'] ); ?></a><?php endif; ?>
		<div style="font-size:12px;color:#6b7280;margin-top:4px"><?php echo esc_html( $office_name ); ?><?php if ( $office_phone ) : ?> · <?php echo esc_html( $office_phone ); ?><?php endif; ?></div>
	</div>
</div>
<?php else : ?>
<div class="agent-card">
	<div>
		<strong><?php echo esc_html( $office_name ); ?></strong><br>
		<?php if ( $office_phone ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $office_phone ) ); ?>"><?php echo esc_html( $office_phone ); ?></a> · <?php endif; ?>
		<?php if ( $office_email ) : ?><a href="mailto:<?php echo esc_attr( $office_email ); ?>"><?php echo esc_html( $office_email ); ?></a><?php endif; ?>
		<div style="font-size:12px;color:#6b7280;margin-top:4px"><?php echo esc_html( home_url() ); ?></div>
	</div>
</div>
<?php endif; ?>

<div class="no-print" style="margin-top:20px;display:flex;gap:8px;flex-wrap:wrap">
	<button onclick="window.print()" style="padding:10px 16px;border-radius:8px;border:1px solid #111;background:#111;color:#fff;cursor:pointer"><?php esc_html_e( 'Print this page', 'estat-os' ); ?></button>
	<a href="<?php echo esc_url( $url ); ?>" style="padding:10px 16px;border-radius:8px;border:1px solid #e5e7eb;background:#fff;color:#111;text-decoration:none">← <?php esc_html_e( 'Back to listing', 'estat-os' ); ?></a>
</div>

<div class="footer">
	<p><?php echo esc_html( sprintf( __( 'Printed from %s — %s — %s', 'estat-os' ), home_url(), $url, gmdate( 'Y-m-d H:i' ) ) ); ?></p>
	<p><?php esc_html_e( 'Disclaimer: Information is collected from owner and verified by office where marked humne khud dekha. Prices, availability and details may change. Please confirm with office before visiting.', 'estat-os' ); ?></p>
	<?php if ( $verified ) : ?><p><strong><?php esc_html_e( 'Verified by our office — humne khud dekha ', 'estat-os' ); ?></strong> — <?php echo esc_html( sprintf( __( 'Inspected by %s', 'estat-os' ), $office_name ) ); ?></p><?php endif; ?>
</div>
</body>
</html>
