<?php
/**
 * Single project — /project/{slug}/ — Phase 3 Mayfair
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Projects;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) : the_post();
	$id = (int) get_the_ID();
	$project = Projects::to_array( $id );
	?>
<main class="estat-public estat-project" id="main">
<div class="estat-container">
	<header class="estat-single-header">
		<h1 class="estat-single-title"><?php the_title(); ?></h1>
		<?php if ( ! empty( $project['developer'] ) ) : ?>
			<p class="estat-page-subtitle"><?php echo esc_html( $project['developer'] ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( has_post_thumbnail( $id ) ) : ?>
		<figure class="estat-card-media"><?php the_post_thumbnail( 'large', array( 'loading'=>'eager' ) ); ?></figure>
	<?php endif; ?>

	<div class="estat-facts">
		<?php if ( ! empty( $project['project_status'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Stage', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( Vocabulary::label( 'project_statuses', (string) $project['project_status'] ) ); ?></div></div>
		<?php endif; ?>
		<?php if ( ! empty( $project['total_units'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Total units', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( (string) $project['total_units'] ); ?></div></div>
		<?php endif; ?>
	</div>

	<div class="estat-article">
		<?php the_content(); ?>
	</div>
</div>
</main>
<?php endwhile;
get_footer();
