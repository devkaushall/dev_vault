<?php
/**
 * Properties archive — /properties/ — Phase 3 Mayfair
 * Wrapper: <main class="estat-public estat-properties"><div class="estat-container">
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Frontend\Components;
use EstatOS\Search\Query;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-properties" id="main">
<div class="estat-container">
	<header class="estat-page-header">
		<h1><?php esc_html_e( 'Properties', 'estat-os' ); ?></h1>
		<?php
		$result = Query::search( array_merge( $_GET, array( 'per_page'=>12 ) ) );
		$total = $result['total'] ?? 0;
		if ( $total > 0 ) {
			echo '<p class="estat-page-subtitle">' . esc_html( sprintf( _n( '%d property', '%d properties', $total, 'estat-os' ), $total ) ) . '</p>';
		}
		?>
	</header>

	<?php echo Components::search_form(); // phpcs:ignore ?>

	<?php if ( have_posts() ) : ?>
		<div class="estat-grid">
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="estat-card">
					<a class="estat-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large', array( 'loading'=>'lazy' ) ); ?></a>
					<div class="estat-card-body">
						<h2 class="estat-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="estat-card-meta">
							<?php
							$price = get_post_meta( get_the_ID(), '_estat_price_display', true ) ?: get_post_meta( get_the_ID(), '_estat_price', true );
							if ( $price ) {
								echo '<span>' . esc_html( $price ) . '</span>';
							}
							$beds = get_post_meta( get_the_ID(), '_estat_bedrooms', true );
							if ( $beds ) {
								echo '<span>' . esc_html( sprintf( __( '%s beds', 'estat-os' ), $beds ) ) . '</span>';
							}
							?>
						</div>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No properties found.', 'estat-os' ); ?></p>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
