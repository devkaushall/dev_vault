<?php
/**
 * Single property — /property/{slug}/ — Phase 3 Mayfair
 * Wrapper: <main class="estat-public estat-property"><div class="estat-container">
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Listings;
use EstatOS\Frontend\Components;
use EstatOS\Settings\Settings;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) : the_post();
	$id = (int) get_the_ID();
	$listing = Listings::to_array( $id, false );
	?>
<main class="estat-public estat-property" id="main">
<div class="estat-container">
	<header class="estat-single-header">
		<h1 class="estat-single-title"><?php the_title(); ?></h1>
		<?php if ( ! empty( $listing['locality'] ) ) : ?>
			<p class="estat-page-subtitle"><?php echo esc_html( implode( ', ', (array) $listing['locality'] ) ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( has_post_thumbnail( $id ) ) : ?>
		<figure class="estat-card-media"><?php the_post_thumbnail( 'large', array( 'loading'=>'eager', 'fetchpriority'=>'high' ) ); ?></figure>
	<?php endif; ?>

	<div class="estat-facts">
		<?php if ( ! empty( $listing['property_type'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Type', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( Vocabulary::label( 'property_types', (string) $listing['property_type'] ) ); ?></div></div>
		<?php endif; ?>
		<?php if ( ! empty( $listing['offer'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Offer', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( Vocabulary::label( 'offers', (string) $listing['offer'] ) ); ?></div></div>
		<?php endif; ?>
		<?php if ( ! empty( $listing['price_display'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Price', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( $listing['price_display'] ); ?></div></div>
		<?php endif; ?>
		<?php if ( ! empty( $listing['area'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Area', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( (string) $listing['area'] . ' ' . (string) $listing['area_unit'] ); ?></div></div>
		<?php endif; ?>
		<?php if ( ! empty( $listing['bedrooms'] ) ) : ?>
			<div><div class="estat-fact-label"><?php esc_html_e( 'Bedrooms', 'estat-os' ); ?></div><div class="estat-fact-value"><?php echo esc_html( (string) $listing['bedrooms'] ); ?></div></div>
		<?php endif; ?>
		<?php
		// RERA / regulatory only if field exists — per brief no brokerage/RERA unless field
		if ( ! empty( $listing['regulatory_id'] ) ) :
		?>
			<div><div class="estat-fact-label"><?php echo esc_html( Settings::get( 'regulatory_label', 'RERA' ) ); ?></div><div class="estat-fact-value"><?php echo esc_html( $listing['regulatory_id'] ); ?></div></div>
		<?php endif; ?>
	</div>

	<div class="estat-article">
		<?php the_content(); ?>
	</div>

	<?php echo Components::enquiry_form( $id ); // phpcs:ignore ?>
</div>
</main>
<?php endwhile;
get_footer();
