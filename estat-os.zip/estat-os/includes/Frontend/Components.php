<?php
/**
 * Reusable public HTML components shared by shortcodes and Elementor widgets.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Agents;
use EstatOS\Data\Highlights;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Search\Query;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;
use EstatOS\Support\Icon;

defined( 'ABSPATH' ) || exit;

/**
 * One implementation of every visible component. Elementor widgets and
 * shortcodes both call these, so the two can never drift apart.
 */
final class Components {

	/**
	 * A property card.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function card( int $listing_id ): string {
		$data = Listings::to_array( $listing_id, false );
		if ( ! $data ) {
			return '';
		}
		if ( 'publish' !== (string) $data['status'] && ! current_user_can( 'estat_manage_listings' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$locality = ! empty( $data['locality'] ) ? (string) $data['locality'][0] : '';
		$beds     = (int) $data['bedrooms'];
		$baths    = (int) $data['bathrooms'];
		$area_sqft = (float) ( $data['area_sqft'] ?? $data['area'] ?? 0 );
		$ptype    = (string) $data['property_type'];

		// Build facts: "4 BHK · 4 bath · 2,555 sq ft · Flat"
		$facts = array();
		if ( $beds > 0 ) {
			$facts[] = sprintf( _n( '%d BHK', '%d BHK', $beds, 'estat-os' ), $beds );
		}
		if ( $baths > 0 ) {
			$facts[] = sprintf( _n( '%d bath', '%d bath', $baths, 'estat-os' ), $baths );
		}
		if ( $area_sqft > 0 ) {
			$facts[] = sprintf( __( '%s sq ft', 'estat-os' ), number_format_i18n( (int) $area_sqft ) );
		} elseif ( (float) $data['area'] > 0 ) {
			$unit = $data['area_unit'] ?: 'sqft';
			$facts[] = sprintf( '%s %s', number_format_i18n( (float) $data['area'] ), $unit );
		}
		if ( '' !== $ptype ) {
			$facts[] = Vocabulary::label( 'property_types', $ptype );
		}
		$facts_str = implode( ' · ', $facts );

		// Price per month fix
		$price_display = (string) $data['price_display'];
		$offer = (string) $data['offer'];
		if ( in_array( $offer, array( 'rent', 'lease' ), true ) && '' !== $price_display && false === strpos( $price_display, 'per month' ) ) {
			$price_display .= ' ' . __( 'per month', 'estat-os' );
		}

		ob_start();
		?>
		<article class="estat-card" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>">
			<a class="estat-card-media" href="<?php echo esc_url( (string) $data['url'] ); ?>">
				<?php
				$cover_id = (int) get_post_thumbnail_id( $listing_id );
				if ( $cover_id > 0 ) {
					echo wp_get_attachment_image(
						$cover_id,
						'large',
						false,
						array(
							'alt' => esc_attr( (string) $data['title'] ),
							'loading' => 'lazy',
							'decoding' => 'async',
							'class' => 'estat-card-img',
							'sizes' => '(max-width: 600px) 100vw, 400px',
						)
					);
				} elseif ( '' !== (string) $data['cover'] ) {
					$card_w = (int) ( $data['cover_width'] ?? 0 );
					$card_h = (int) ( $data['cover_height'] ?? 0 );
					?>
					<img
						src="<?php echo esc_url( (string) $data['cover'] ); ?>"
						alt="<?php echo esc_attr( (string) $data['title'] ); ?>"
						<?php if ( $card_w > 0 && $card_h > 0 ) : ?>
							width="<?php echo esc_attr( (string) $card_w ); ?>"
							height="<?php echo esc_attr( (string) $card_h ); ?>"
						<?php endif; ?>
						loading="lazy"
						decoding="async"
						srcset="<?php echo esc_attr( (string) $data['cover'] ); ?> 400w"
						sizes="(max-width: 600px) 100vw, 400px"
					/>
				<?php } else { ?>
					<span class="estat-card-noimage" aria-hidden="true"></span>
				<?php } ?>
				<?php if ( ! empty( $data['featured'] ) ) : ?>
					<span class="estat-badge estat-badge-featured"><?php esc_html_e( 'Featured', 'estat-os' ); ?></span>
				<?php endif; ?>
				<span class="estat-badge estat-badge-offer"><?php echo esc_html( Vocabulary::label( 'offers', $offer ) ); ?></span>
				<?php if ( 'office_verified' === (string) $data['verification'] ) : ?>
					<span class="estat-badge estat-badge-verified" title="<?php esc_attr_e( 'Verified listing', 'estat-os' ); ?>">
						<?php echo Icon::render( 'verified', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Verified', 'estat-os' ); ?>
					</span>
				<?php endif; ?>
			</a>
			<div class="estat-card-body">
				<h3 class="estat-card-title"><a href="<?php echo esc_url( (string) $data['url'] ); ?>"><?php echo esc_html( (string) $data['title'] ); ?></a></h3>
				<?php if ( '' !== $locality ) : ?>
					<p class="estat-card-locality"><?php echo esc_html( $locality ); ?></p>
				<?php endif; ?>
				<p class="estat-card-price"><?php echo esc_html( $price_display ); ?></p>
				<?php
				$just_days = 7;
				$setting_days = (int) Settings::get( 'just_listed_days', 7 );
				if ( $setting_days > 0 && $setting_days < 7 ) { $just_days = $setting_days; }
				if ( $just_days > 7 ) { $just_days = 7; }
				if ( 'publish' === (string) $data['status'] && (int) ( $data['days_listed'] ?? 0 ) <= $just_days && (int) ( $data['days_listed'] ?? 0 ) >= 0 ) :
					?>
					<p class="estat-card-fresh"><?php esc_html_e( 'Just listed', 'estat-os' ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $facts_str ) : ?>
				<ul class="estat-card-facts"><li><?php echo esc_html( $facts_str ); ?></li></ul>
				<?php endif; ?>
				<?php
				$chips = Highlights::for_card( $listing_id );
				if ( $chips ) :
					?>
					<ul class="estat-chips">
						<?php foreach ( $chips as $chip ) : ?>
							<li class="estat-chip">
								<?php if ( '' !== (string) $chip['icon'] ) : ?>
									<span class="estat-chip-icon"><?php echo Icon::render( (string) $chip['icon'], 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php endif; ?>
								<span class="estat-chip-text"><?php echo esc_html( (string) $chip['label'] ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<div class="estat-card-actions">
					<?php if ( Settings::get( 'enable_favorites' ) ) : ?>
						<button type="button" class="estat-fav" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<span class="screen-reader-text"><?php esc_html_e( 'Save this property', 'estat-os' ); ?></span>
							<span class="estat-fav-icon"><?php echo Icon::render( 'heart', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						</button>
					<?php endif; ?>
					<?php if ( Settings::get( 'enable_compare' ) ) : ?>
						<button type="button" class="estat-compare" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<?php esc_html_e( 'Compare', 'estat-os' ); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>
		</article>
		<?php
		return (string) ob_get_clean();
	}


	/**
	 * A property directory with pagination — 3.0.7 fixed wrapper + H1 + count + sort.
	 *
	 * @param array<string,mixed> $args Search filters.
	 * @return string
	 */
	public static function directory( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		$results = Query::search( $args );

		if ( empty( $results['ids'] ) && ! self::has_filters( $args ) && 0 === self::published_count() ) {
			if ( ! current_user_can( 'estat_manage_listings' ) ) {
				return '';
			}
			return '<main class="estat-archive"><div class="estat-container"><p class="estat-empty">' . esc_html__( 'Nothing is live yet. Publish a listing and it appears in this directory.', 'estat-os' ) . '</p></div></main>';
		}

			$no_wrapper = isset( $args['wrapper'] ) && false === $args['wrapper'];
		ob_start();
		// Wrapper required by acceptance: main.estat-archive > div.estat-container + H1 count 1
		if ( ! $no_wrapper ) {
			echo '<main class="estat-archive"><div class="estat-container">';
			echo '<header class="estat-archive-header"><h1>' . esc_html__( 'Properties', 'estat-os' ) . '</h1></header>';
		}

		// Result count + sort
		$total = (int) ( $results['total'] ?? count( $results['ids'] ) );
		if ( $total > 0 ) {
			echo '<div class="estat-directory-meta" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin:12px 0">';
			echo '<p class="estat-result-count" style="margin:0">' . sprintf( _n( '%d property', '%d properties', $total, 'estat-os' ), $total ) . '</p>';
			// Sort dropdown
			$current_order = $args['orderby'] ?? 'recent';
			echo '<form method="get" class="estat-sort" style="margin:0"><label for="estat-orderby" class="screen-reader-text">' . esc_html__( 'Sort by', 'estat-os' ) . '</label><select id="estat-orderby" name="orderby" onchange="this.form.submit()">';
			$orders = array( 'recent' => __( 'Newest', 'estat-os' ), 'price_asc' => __( 'Price: low to high', 'estat-os' ), 'price_desc' => __( 'Price: high to low', 'estat-os' ), 'area_desc' => __( 'Area: large to small', 'estat-os' ) );
			foreach ( $orders as $val => $label ) {
				echo '<option value="' . esc_attr( $val ) . '" ' . selected( $current_order, $val, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select>';
			// Preserve current filters as hidden inputs
			foreach ( $_GET as $k => $v ) {
				if ( 'orderby' === $k || 'estat_page' === $k ) continue;
				$k = sanitize_key( $k );
				if ( is_array( $v ) ) {
					foreach ( $v as $vv ) {
						echo '<input type="hidden" name="' . esc_attr( $k ) . '[]" value="' . esc_attr( sanitize_text_field( $vv ) ) . '">';
					}
				} else {
					echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( sanitize_text_field( wp_unslash( $v ) ) ) . '">';
				}
			}
			echo '</form></div>';
		}

		echo '<div class="estat-directory">';
		if ( empty( $results['ids'] ) ) {
			echo '<p class="estat-empty">' . esc_html__( 'No properties match what you are looking for. Try widening your search.', 'estat-os' ) . '</p>';
		} else {
			echo '<div class="estat-grid">';
			foreach ( $results['ids'] as $id ) {
				echo self::card( (int) $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
			echo self::pagination( (int) $results['page'], (int) $results['pages'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
		if ( ! $no_wrapper ) {
			echo '</div></main>';
		}
		return (string) ob_get_clean();
	}

	/**
	 * Does this call carry a real filter (anything a visitor could have
	 * narrowed with, beyond paging)?
	 *
	 * @param array<string,mixed> $args Directory arguments.
	 * @return bool
	 */
	private static function has_filters( array $args ): bool {
		foreach ( $args as $key => $value ) {
			if ( in_array( $key, array( 'page', 'per_page', 'status' ), true ) ) {
				continue;
			}
			if ( null !== $value && '' !== $value && array() !== $value && 0 !== $value && '0' !== $value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Published listings on the whole site — the difference between "no
	 * matches" and "no shop yet".
	 *
	 * @return int
	 */
	private static function published_count(): int {
		if ( function_exists( 'wp_count_posts' ) ) {
			$counts = wp_count_posts( \EstatOS\Data\PostTypes::LISTING );
			return isset( $counts->publish ) ? (int) $counts->publish : 0;
		}
		$q     = new \WP_Query(
			array(
				'post_type'      => \EstatOS\Data\PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
			)
		);
		return (int) $q->found_posts;
	}

	/**
	 * Pagination links.
	 *
	 * @param int $page  Current page.
	 * @param int $pages Total pages.
	 * @return string
	 */
	public static function pagination( int $page, int $pages ): string {
		if ( $pages < 2 ) {
			return '';
		}
		$links = paginate_links(
			array(
				'base'      => add_query_arg( 'estat_page', '%#%' ),
				'format'    => '',
				'current'   => max( 1, $page ),
				'total'     => $pages,
				'type'      => 'array',
				'prev_text' => __( 'Previous', 'estat-os' ),
				'next_text' => __( 'Next', 'estat-os' ),
			)
		);
		if ( ! is_array( $links ) ) {
			return '';
		}
		$out = '<nav class="estat-pagination" aria-label="' . esc_attr__( 'Property pages', 'estat-os' ) . '"><ul>';
		foreach ( $links as $link ) {
			$out .= '<li>' . wp_kses_post( $link ) . '</li>';
		}
		return $out . '</ul></nav>';
	}

	/**
	 * The search form — 3.0.7 fixed: 6 default, details closed, ids/for, SVG, no overflow.
	 *
	 * @param array<string,mixed> $args Options: action.
	 * @return string
	 */
		public static function search_form( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-share' );
		$action = isset( $args['action'] ) ? esc_url( (string) $args['action'] ) : esc_url( (string) get_post_type_archive_link( PostTypes::LISTING ) );

		$enabled = Query::enabled_filters();
		$ordered_all = Query::ordered_filters();

		$localities = get_transient( 'estat_terms_locality' );
		if ( false === $localities ) {
			$localities = get_terms( array( 'taxonomy' => Taxonomies::LOCALITY, 'hide_empty' => true, 'number' => 200 ) );
			$localities = is_wp_error( $localities ) ? array() : $localities;
			set_transient( 'estat_terms_locality', $localities, HOUR_IN_SECONDS );
		}

		$amenities_terms = get_transient( 'estat_terms_amenity' );
		if ( false === $amenities_terms ) {
			$amenities_terms = get_terms( array( 'taxonomy' => Taxonomies::AMENITY, 'hide_empty' => true, 'number' => 100 ) );
			$amenities_terms = is_wp_error( $amenities_terms ) ? array() : $amenities_terms;
			set_transient( 'estat_terms_amenity', $amenities_terms, HOUR_IN_SECONDS );
		}

		$features_terms = get_transient( 'estat_terms_feature' );
		if ( false === $features_terms ) {
			$features_terms = get_terms( array( 'taxonomy' => Taxonomies::FEATURE, 'hide_empty' => true, 'number' => 100 ) );
			$features_terms = is_wp_error( $features_terms ) ? array() : $features_terms;
			set_transient( 'estat_terms_feature', $features_terms, HOUR_IN_SECONDS );
		}

		$projects = get_transient( 'estat_projects_ids' );
		if ( false === $projects ) {
			$projects = get_posts( array( 'post_type' => PostTypes::PROJECT, 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids', 'no_found_rows' => true ) );
			set_transient( 'estat_projects_ids', $projects, HOUR_IN_SECONDS );
		}

		$get = static function ( string $key ): string {
			if ( ! isset( $_GET[ $key ] ) ) {
				return '';
			}
			$raw = $_GET[ $key ];
			if ( is_array( $raw ) ) {
				$raw = reset( $raw );
				if ( is_array( $raw ) ) {
					$raw = '';
				}
			}
			return sanitize_text_field( wp_unslash( (string) $raw ) );
		};
		$get_arr = static function ( string $key ): array {
			$raw = $_GET[ $key ] ?? array();
			if ( is_string( $raw ) ) { $raw = array( $raw ); }
			return array_map( 'sanitize_text_field', (array) $raw );
		};

		// Render helpers with proper ids/for and SVG icons (no emoji)
		$renderers = array(
			'offer' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-offer"><?php esc_html_e( 'Buy or rent', 'estat-os' ); ?></label><select id="estat-offer" name="offer"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::offers() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'offer' ), $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'property_type' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-type"><?php esc_html_e( 'Property type', 'estat-os' ); ?></label><select id="estat-type" name="property_type"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::property_types() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'property_type' ), $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'locality' => function() use ( $get, $localities ) {
				if ( ! $localities ) { return ''; }
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-locality"><?php esc_html_e( 'Locality', 'estat-os' ); ?></label><select id="estat-locality" name="locality"><option value=""><?php esc_html_e( 'Anywhere', 'estat-os' ); ?></option><?php foreach ( $localities as $term ) : ?><option value="<?php echo esc_attr( (string) $term->slug ); ?>" <?php selected( $get( 'locality' ), (string) $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'bedrooms' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-beds"><?php esc_html_e( 'Bedrooms (min)', 'estat-os' ); ?></label><input type="number" id="estat-beds" name="bedrooms_min" min="0" max="20" value="<?php echo esc_attr( $get( 'bedrooms_min' ) ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'bathrooms' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-baths"><?php esc_html_e( 'Bathrooms (min)', 'estat-os' ); ?></label><input type="number" id="estat-baths" name="bathrooms_min" min="0" max="20" value="<?php echo esc_attr( $get( 'bathrooms_min' ) ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'price' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-price-max"><?php esc_html_e( 'Budget up to', 'estat-os' ); ?></label><input type="number" id="estat-price-max" name="price_max" min="0" step="1000" value="<?php echo esc_attr( $get( 'price_max' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 9000000', 'estat-os' ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'area' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-area-min"><?php esc_html_e( 'Area min (sqft)', 'estat-os' ); ?></label><input type="number" id="estat-area-min" name="area_min" value="<?php echo esc_attr( $get( 'area_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'furnishing' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-furnishing"><?php esc_html_e( 'Furnishing', 'estat-os' ); ?></label><select id="estat-furnishing" name="furnishing"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::furnishing() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'furnishing' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'facing' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-facing"><?php esc_html_e( 'Facing', 'estat-os' ); ?></label><select id="estat-facing" name="facing"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::facing() as $v=>$l ) : if(''===$v) continue; ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'facing' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'floor' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-floor-min"><?php esc_html_e( 'Floor min', 'estat-os' ); ?></label><input type="number" id="estat-floor-min" name="floor_min" value="<?php echo esc_attr( $get( 'floor_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'total_floors' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-total-floors-min"><?php esc_html_e( 'Total floors min', 'estat-os' ); ?></label><input type="number" id="estat-total-floors-min" name="total_floors_min" value="<?php echo esc_attr( $get( 'total_floors_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'construction' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-construction"><?php esc_html_e( 'Construction', 'estat-os' ); ?></label><select id="estat-construction" name="construction"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::construction() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'construction' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'availability' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-availability"><?php esc_html_e( 'Availability', 'estat-os' ); ?></label><select id="estat-availability" name="availability"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::availability() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'availability' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'possession' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-possession"><?php esc_html_e( 'Possession', 'estat-os' ); ?></label><select id="estat-possession" name="possession"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::possession_timeline() as $v=>$l ) : if(''===$v) continue; ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'possession' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'parking' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-parking-min"><?php esc_html_e( 'Parking min', 'estat-os' ); ?></label><input type="number" id="estat-parking-min" name="parking_min" value="<?php echo esc_attr( $get( 'parking_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'balconies' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-balconies-min"><?php esc_html_e( 'Balconies min', 'estat-os' ); ?></label><input type="number" id="estat-balconies-min" name="balconies_min" value="<?php echo esc_attr( $get( 'balconies_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'age' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-age-max"><?php esc_html_e( 'Max age (years)', 'estat-os' ); ?></label><input type="number" id="estat-age-max" name="age_max" value="<?php echo esc_attr( $get( 'age_max' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'project' => function() use ( $get, $projects ) {
				if ( ! $projects ) { return ''; }
				ob_start(); ?>
				<div class="estat-search-field"><label for="estat-project-id"><?php esc_html_e( 'Project', 'estat-os' ); ?></label><select id="estat-project-id" name="project_id"><option value=""><?php esc_html_e( 'Any project', 'estat-os' ); ?></option><?php foreach ( $projects as $pid ) : ?><option value="<?php echo esc_attr( $pid ); ?>" <?php selected( $get( 'project_id' ), (string) $pid ); ?>><?php echo esc_html( get_the_title( $pid ) ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'verified' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field estat-search-field--check"><input type="checkbox" id="estat-verified" name="verified" value="1" <?php checked( $get( 'verified' ), '1' ); ?>><label for="estat-verified"><?php esc_html_e( 'Verified only', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'featured' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field estat-search-field--check"><input type="checkbox" id="estat-featured" name="featured" value="1" <?php checked( $get( 'featured' ), '1' ); ?>><label for="estat-featured"><?php esc_html_e( 'Featured only', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'investment' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-search-field estat-search-field--check"><input type="checkbox" id="estat-investment" name="investment" value="1" <?php checked( $get( 'investment' ), '1' ); ?>><label for="estat-investment"><?php esc_html_e( 'Investment', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'amenities' => function() use ( $get_arr, $amenities_terms ) {
				if ( ! $amenities_terms ) { return ''; }
				$selected = $get_arr( 'amenities' );
				ob_start(); ?>
				<fieldset class="estat-search-field"><legend><?php esc_html_e( 'Amenities', 'estat-os' ); ?></legend><div style="display:flex;flex-direction:column;gap:4px;max-height:160px;overflow:auto"><?php foreach ( $amenities_terms as $term ) : $cid = 'estat-amenity-' . $term->term_id; ?><div><input type="checkbox" id="<?php echo esc_attr( $cid ); ?>" name="amenities[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php echo in_array( (string) $term->term_id, $selected, true ) ? 'checked' : ''; ?>><label for="<?php echo esc_attr( $cid ); ?>"><?php echo esc_html( $term->name ); ?></label></div><?php endforeach; ?></div></fieldset>
				<?php return ob_get_clean();
			},
			'features' => function() use ( $get_arr, $features_terms ) {
				if ( ! $features_terms ) { return ''; }
				$selected = $get_arr( 'features' );
				ob_start(); ?>
				<fieldset class="estat-search-field"><legend><?php esc_html_e( 'Features / Highlights', 'estat-os' ); ?></legend><div style="display:flex;flex-direction:column;gap:4px;max-height:160px;overflow:auto"><?php foreach ( $features_terms as $term ) : $cid = 'estat-feature-' . $term->term_id; ?><div><input type="checkbox" id="<?php echo esc_attr( $cid ); ?>" name="features[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php echo in_array( (string) $term->term_id, $selected, true ) ? 'checked' : ''; ?>><label for="<?php echo esc_attr( $cid ); ?>"><?php echo esc_html( $term->name ); ?></label></div><?php endforeach; ?></div></fieldset>
				<?php return ob_get_clean();
			},
		);

		ob_start();
		?>
		<form class="estat-search estat-search-v3" method="get" action="<?php echo esc_url( $action ); ?>" role="search" style="max-width:100%;box-sizing:border-box">
			<div class="estat-search-row" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;max-width:100%">
				<div class="estat-search-field">
					<label for="estat-q"><?php esc_html_e( 'What are you looking for?', 'estat-os' ); ?></label>
					<input type="search" id="estat-q" name="keyword" value="<?php echo esc_attr( $get( 'keyword' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 3 BHK near the metro', 'estat-os' ); ?>" />
				</div>
				<?php
				$count = 0;
				$remaining = array();
				foreach ( $enabled as $key ) {
					if ( ! isset( $renderers[ $key ] ) ) { continue; }
					if ( $count < 5 ) {
						echo $renderers[ $key ]();
						$count++;
					} else {
						$remaining[] = $key;
					}
				}
				?>
			</div>

			<details class="estat-search-more" style="margin-top:12px;max-width:100%;box-sizing:border-box">
				<summary style="cursor:pointer;font-weight:600;display:flex;align-items:center;gap:8px"><?php echo \EstatOS\Support\Icon::render( 'filter', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'More filters', 'estat-os' ); ?></summary>
				<div class="estat-search-row" style="margin-top:12px;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;max-width:100%">
					<?php
					foreach ( $remaining as $key ) {
						if ( isset( $renderers[ $key ] ) ) {
							echo $renderers[ $key ]();
						}
					}
					?>
				</div>
			</details>

			<div class="estat-search-actions" style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">
				<button type="submit" class="estat-btn estat-btn-primary"><?php esc_html_e( 'Search properties', 'estat-os' ); ?></button>
				<?php if ( Settings::get( 'search_alerts_enabled' ) ) : ?>
				<button type="button" class="estat-btn" onclick="document.getElementById('estat-alerts-inline').style.display='block'"><?php esc_html_e( 'Watch this search', 'estat-os' ); ?></button>
				<?php endif; ?>
				<a href="<?php echo esc_url( strtok( $action, '?' ) ); ?>" class="estat-btn"><?php esc_html_e( 'Clear', 'estat-os' ); ?></a>
			</div>

			<?php if ( Settings::get( 'search_alerts_enabled' ) ) : ?>
			<div id="estat-alerts-inline" style="display:none;margin-top:16px;border:1px solid var(--estat-line);padding:16px;border-radius:12px;background:var(--estat-card);max-width:100%;box-sizing:border-box">
				<h4 style="margin:0 0 8px"><?php esc_html_e( 'Get email when match goes live', 'estat-os' ); ?></h4>
				<p class="estat-muted" style="font-size:13px;margin:0 0 8px"><?php esc_html_e( 'Watch this search — get email when a matching home goes live.', 'estat-os' ); ?></p>
				<div class="estat-alert-form" style="display:flex;gap:8px;flex-wrap:wrap">
					<input type="text" name="alert_name" placeholder="<?php esc_attr_e( 'Your name', 'estat-os' ); ?>" style="flex:1;min-width:140px">
					<input type="email" name="alert_email" placeholder="<?php esc_attr_e( 'Your email', 'estat-os' ); ?>" required style="flex:1;min-width:180px">
					<input type="tel" name="alert_phone" placeholder="<?php esc_attr_e( 'Phone (optional)', 'estat-os' ); ?>" style="flex:1;min-width:140px">
					<select name="alert_frequency" style="min-width:120px"><option value="instant"><?php esc_html_e( 'Instant', 'estat-os' ); ?></option><option value="daily"><?php esc_html_e( 'Daily digest', 'estat-os' ); ?></option></select>
					<button type="button" class="button button-primary estat-alert-save"><?php esc_html_e( 'Save alert', 'estat-os' ); ?></button>
				</div>
				<p class="estat-alert-msg" style="font-size:13px;margin-top:8px"></p>
			</div>
			<script>
			document.addEventListener('DOMContentLoaded', function(){
				const btn = document.querySelector('.estat-alert-save');
				if(!btn) return;
				btn.addEventListener('click', function(){
					const name = document.querySelector('input[name=alert_name]')?.value || '';
					const email = document.querySelector('input[name=alert_email]')?.value || '';
					const phone = document.querySelector('input[name=alert_phone]')?.value || '';
					const frequency = document.querySelector('select[name=alert_frequency]')?.value || 'instant';
					if(!email){ alert('Email needed'); return; }
					const params = new URLSearchParams(window.location.search);
					const filters = {};
					for(const [k,v] of params.entries()){ filters[k]=v; }
					btn.disabled=true; btn.textContent='Saving...';
					fetch((window.estatPublic?.restUrl || '/wp-json/estat/v1/') + 'alerts', {
						method:'POST',
						headers:{'Content-Type':'application/json'},
						body: JSON.stringify({name:name, email:email, phone:phone, frequency:frequency, filters:filters, query:filters, source_url: window.location.href})
					}).then(r=>r.json()).then(j=>{
						const msg = document.querySelector('.estat-alert-msg');
						if(j.id || j.success){ if(msg) msg.textContent='Alert saved! Check email to confirm.'; }
						else { if(msg) msg.textContent=j.message||'Failed'; }
						btn.disabled=false; btn.textContent='Save alert';
					}).catch(e=>{ const msg=document.querySelector('.estat-alert-msg'); if(msg) msg.textContent='Network error'; btn.disabled=false; });
				});
			});
			</script>
			<?php endif; ?>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A monthly repayment estimate.

	 *
	 * Research on Indian property portals is consistent that this is the most
	 * used tool on a listing page: a buyer who works out that a flat is
	 * affordable is far likelier to enquire than one left guessing. It is also
	 * a reason to come back, which a static listing never is.
	 *
	 * The arithmetic runs entirely in the browser. Nothing is sent anywhere,
	 * nothing is stored, and no bank or API is involved - so this works whether
	 * or not the office has any integration, and a visitor playing with the
	 * numbers is not quietly generating a lead.
	 *
	 * The standard formula every Indian lender publishes:
	 *
	 *     EMI = P x R x (1+R)^N / ((1+R)^N - 1)
	 *
	 * where R is the monthly rate and N the number of months.
	 *
	 * @param float $price Property price, used as the starting figure.
	 * @return string
	 */
	public static function emi( float $price ): string {
		if ( $price <= 0 ) {
			return '';
		}

		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$currency = (string) Settings::get( 'currency_symbol' );
		if ( '' === $currency ) {
			$currency = '&#8377;';
		}

		// Enhanced EMI — down %, processing fee, amortization, chart.
		$default_down_pct = 20;
		$deposit = round( $price * $default_down_pct / 100 );
		$loan    = max( 0, $price - $deposit );
		$default_rate = (float) Settings::get( 'emi_default_rate', 8.5 );
		if ( $default_rate <= 0 ) { $default_rate = 8.5; }
		$default_years = (int) Settings::get( 'emi_default_years', 20 );
		if ( $default_years <= 0 ) { $default_years = 20; }

		ob_start();
		?>
		<section
			class="estat-emi estat-emi-v2"
			aria-label="<?php esc_attr_e( 'Work out the monthly payment', 'estat-os' ); ?>"
			data-price="<?php echo esc_attr( (string) (int) $price ); ?>"
			style="border:1px solid var(--estat-line, #e5e7eb);border-radius:12px;padding:16px;background:var(--estat-card, #fff)"
		>
			<h2 class="estat-emi-title" style="margin:0 0 12px;font-size:18px"><?php esc_html_e( 'What would this cost a month?', 'estat-os' ); ?></h2>

			<div class="estat-emi-controls" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-price"><?php esc_html_e( 'Property price', 'estat-os' ); ?></label>
					<span class="estat-emi-input" style="display:flex;align-items:center;gap:4px"><span class="estat-emi-currency" aria-hidden="true"><?php echo esc_html( $currency ); ?></span><input type="number" id="estat-emi-price" class="estat-emi-price" value="<?php echo esc_attr( (string) (int) $price ); ?>" min="0" step="10000" inputmode="numeric" style="flex:1" /></span>
				</p>
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-downpct"><?php esc_html_e( 'Down payment %', 'estat-os' ); ?></label>
					<span class="estat-emi-input" style="display:flex;align-items:center;gap:4px"><input type="number" id="estat-emi-downpct" class="estat-emi-downpct" value="<?php echo esc_attr( (string) $default_down_pct ); ?>" min="0" max="90" step="1" style="flex:1" /><span>%</span></span>
					<span class="estat-emi-note" style="font-size:11px;color:#666"><?php printf( esc_html__( 'Deposit %s — editable', 'estat-os' ), esc_html( Format::money( (float) $deposit ) ) ); ?></span>
				</p>
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-loan"><?php esc_html_e( 'Loan amount', 'estat-os' ); ?></label>
					<span class="estat-emi-input" style="display:flex;align-items:center;gap:4px"><span class="estat-emi-currency"><?php echo esc_html( $currency ); ?></span><input type="number" id="estat-emi-loan" class="estat-emi-loan" value="<?php echo esc_attr( (string) (int) $loan ); ?>" min="0" step="10000" inputmode="numeric" style="flex:1" /></span>
				</p>
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-rate"><?php esc_html_e( 'Interest rate', 'estat-os' ); ?></label>
					<span class="estat-emi-input" style="display:flex;align-items:center;gap:4px"><input type="number" id="estat-emi-rate" class="estat-emi-rate" value="<?php echo esc_attr( (string) $default_rate ); ?>" min="1" max="20" step="0.05" inputmode="decimal" style="flex:1" /><span>%</span></span>
					<span class="estat-emi-note" style="font-size:11px;color:#666"><?php esc_html_e( 'Per year. Ask your bank.', 'estat-os' ); ?></span>
				</p>
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-years"><?php esc_html_e( 'Over how many years', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><input type="number" id="estat-emi-years" class="estat-emi-years" value="<?php echo esc_attr( (string) $default_years ); ?>" min="1" max="30" step="1" inputmode="numeric" style="width:100%" /></span>
				</p>
				<p class="estat-emi-field" style="margin:0">
					<label for="estat-emi-fee"><?php esc_html_e( 'Processing fee %', 'estat-os' ); ?></label>
					<span class="estat-emi-input" style="display:flex;align-items:center;gap:4px"><input type="number" id="estat-emi-fee" class="estat-emi-fee" value="1" min="0" max="10" step="0.1" style="flex:1" /><span>%</span></span>
				</p>
			</div>

			<div class="estat-emi-result" role="status" aria-live="polite" style="margin-top:16px;padding:12px;background:#f8fafc;border-radius:8px">
				<p class="estat-emi-amount" style="margin:0;font-size:22px;font-weight:700"><span class="estat-emi-value">&mdash;</span> <span class="estat-emi-per" style="font-size:14px;font-weight:400"><?php esc_html_e( 'a month', 'estat-os' ); ?></span></p>
				<p class="estat-emi-breakdown" style="margin:6px 0 0;font-size:13px;color:#444"><span class="estat-emi-total"></span><br><span class="estat-emi-interest"></span><br><span class="estat-emi-feeout"></span></p>
				<div class="estat-emi-bar" style="margin-top:10px;height:12px;background:#e5e7eb;border-radius:999px;overflow:hidden;display:flex"><div class="estat-emi-bar-principal" style="height:100%;background:#111"></div><div class="estat-emi-bar-interest" style="height:100%;background:#f59e0b"></div></div>
				<div style="display:flex;justify-content:space-between;font-size:11px;color:#666;margin-top:4px"><span><?php esc_html_e( 'Principal', 'estat-os' ); ?></span><span><?php esc_html_e( 'Interest', 'estat-os' ); ?></span></div>
			</div>

			<details class="estat-emi-schedule" style="margin-top:12px"><summary style="cursor:pointer;font-weight:600"><?php esc_html_e( 'Show year-wise amortization', 'estat-os' ); ?></summary><div class="estat-emi-table" style="max-height:240px;overflow:auto;margin-top:8px;font-size:12px"></div></details>

			<p class="estat-emi-caveat" style="font-size:11px;color:#666;margin-top:10px"><?php esc_html_e( 'This is an estimate to help you plan, not an offer. Your bank decides the real figure.', 'estat-os' ); ?></p>

			<script>
			document.addEventListener('DOMContentLoaded', function(){
				const sec = document.currentScript ? document.currentScript.closest('.estat-emi') : document.querySelector('.estat-emi-v2');
				// Fallback: find last emi
				const root = document.querySelectorAll('.estat-emi-v2');
				const el = root[root.length-1];
				if(!el) return;
				const priceInput = el.querySelector('.estat-emi-price');
				const downPctInput = el.querySelector('.estat-emi-downpct');
				const loanInput = el.querySelector('.estat-emi-loan');
				const rateInput = el.querySelector('.estat-emi-rate');
				const yearsInput = el.querySelector('.estat-emi-years');
				const feeInput = el.querySelector('.estat-emi-fee');
				const valueOut = el.querySelector('.estat-emi-value');
				const totalOut = el.querySelector('.estat-emi-total');
				const interestOut = el.querySelector('.estat-emi-interest');
				const feeOut = el.querySelector('.estat-emi-feeout');
				const barP = el.querySelector('.estat-emi-bar-principal');
				const barI = el.querySelector('.estat-emi-bar-interest');
				const tableOut = el.querySelector('.estat-emi-table');
				function fmt(n){ try{ return new Intl.NumberFormat('en-IN').format(Math.round(n)); }catch(e){ return Math.round(n).toString(); } }
				function calc(){
					let price = parseFloat(priceInput.value)||0;
					let downPct = parseFloat(downPctInput.value)||0;
					let loan = parseFloat(loanInput.value)||0;
					let rate = parseFloat(rateInput.value)||0;
					let years = parseFloat(yearsInput.value)||0;
					let feePct = parseFloat(feeInput.value)||0;
					// If price or down% changed, recalc loan
					if(document.activeElement===priceInput || document.activeElement===downPctInput){
						let dep = price*downPct/100;
						loan = Math.max(0, price-dep);
						loanInput.value = Math.round(loan);
					}
					if(loan<=0 || rate<=0 || years<=0){ valueOut.textContent='—'; return; }
					let r = rate/12/100;
					let n = years*12;
					let emi = loan*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
					let total = emi*n;
					let interest = total-loan;
					let fee = loan*feePct/100;
					valueOut.textContent = '₹' + fmt(emi);
					totalOut.textContent = 'Total repaid: ₹' + fmt(total) + ' (Principal ₹' + fmt(loan) + ' + Interest ₹' + fmt(interest) + ')';
					interestOut.textContent = 'Total interest: ₹' + fmt(interest);
					feeOut.textContent = fee>0 ? 'Processing fee ('+feePct+'%): ₹' + fmt(fee) : '';
					let pPct = loan/total*100;
					let iPct = interest/total*100;
					if(barP) barP.style.width = pPct+'%';
					if(barI) barI.style.width = iPct+'%';
					// Amortization year-wise
					if(tableOut){
						let bal = loan;
						let html = '<table style="width:100%;border-collapse:collapse"><tr><th style="text-align:left;border-bottom:1px solid #ddd;padding:4px">Year</th><th style="text-align:right;border-bottom:1px solid #ddd;padding:4px">Principal paid</th><th style="text-align:right;border-bottom:1px solid #ddd;padding:4px">Interest paid</th><th style="text-align:right;border-bottom:1px solid #ddd;padding:4px">Balance</th></tr>';
						let cumP=0,cumI=0;
						for(let y=1;y<=years;y++){
							let yP=0,yI=0;
							for(let m=1;m<=12;m++){
								if(bal<=0) break;
								let i = bal*r;
								let pmt = Math.min(emi, bal+i);
								let princ = pmt - i;
								if(princ<0) princ=0;
								bal -= princ;
								if(bal<0.01) bal=0;
								yP+=princ; yI+=i; cumP+=princ; cumI+=i;
							}
							html += '<tr><td style="padding:4px;border-bottom:1px solid #f0f0f0">'+y+'</td><td style="text-align:right;padding:4px;border-bottom:1px solid #f0f0f0">₹'+fmt(yP)+'</td><td style="text-align:right;padding:4px;border-bottom:1px solid #f0f0f0">₹'+fmt(yI)+'</td><td style="text-align:right;padding:4px;border-bottom:1px solid #f0f0f0">₹'+fmt(bal)+'</td></tr>';
							if(bal<=0) break;
						}
						html+='</table>';
						tableOut.innerHTML = html;
					}
				}
				['input','change'].forEach(ev=>{
					priceInput.addEventListener(ev, calc);
					downPctInput.addEventListener(ev, calc);
					loanInput.addEventListener(ev, calc);
					rateInput.addEventListener(ev, calc);
					yearsInput.addEventListener(ev, calc);
					feeInput.addEventListener(ev, calc);
				});
				calc();
			});
			</script>
		</section>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Project stage timeline — Planning / Under Construction / Ready.
	 *
	 * @param string $current_stage Current stage key.
	 * @return string
	 */
	public static function project_timeline( string $current_stage ): string {
		$stages = \EstatOS\Support\Vocabulary::project_stage_order();
		$progress_map = \EstatOS\Support\Vocabulary::project_stage_progress();
		$current_progress = $progress_map[ $current_stage ] ?? 0;
		ob_start();
		?>
		<div class="estat-project-timeline" style="margin:16px 0;padding:12px;border:1px solid #e5e7eb;border-radius:10px;background:#fafafa">
			<h3 style="margin:0 0 10px;font-size:14px"><?php esc_html_e( 'Project Timeline', 'estat-os' ); ?></h3>
			<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
				<?php foreach ( $stages as $idx => $st ) :
					$is_current = $st === $current_stage;
					$is_past = array_search( $st, $stages ) < array_search( $current_stage, $stages );
					$bg = $is_current ? '#111' : ( $is_past ? '#10b981' : '#e5e7eb' );
					$color = $is_current || $is_past ? '#fff' : '#111';
				?>
					<div style="display:flex;align-items:center;gap:6px">
						<span style="width:24px;height:24px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;background:<?php echo esc_attr( $bg ); ?>;color:<?php echo esc_attr( $color ); ?>;font-size:11px"><?php echo (int) $idx + 1; ?></span>
						<span style="font-size:12px;font-weight:<?php echo $is_current ? '700' : '400'; ?>"><?php echo esc_html( \EstatOS\Support\Vocabulary::project_stage_label( $st ) ); ?></span>
					</div>
					<?php if ( $idx < count( $stages ) - 1 ) : ?><span style="flex:1;height:2px;background:<?php echo $is_past ? '#10b981' : '#e5e7eb'; ?>;min-width:12px"></span><?php endif; ?>
				<?php endforeach; ?>
			</div>
			<div style="margin-top:10px;height:6px;background:#e5e7eb;border-radius:999px;overflow:hidden"><div style="width:<?php echo (int) $current_progress; ?>%;height:100%;background:#111"></div></div>
			<div style="font-size:11px;color:#666;margin-top:4px"><?php echo (int) $current_progress; ?>% <?php esc_html_e( 'complete', 'estat-os' ); ?></div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Locality card.
	 *
	 * @param \WP_Term $term Term.
	 * @return string
	 */
	public static function locality_card( $term ): string {
		if ( ! $term || is_wp_error( $term ) ) { return ''; }
		$count = (int) $term->count;
		ob_start();
		?>
		<a href="<?php echo esc_url( get_term_link( $term ) ); ?>" style="border:1px solid #e5e7eb;padding:12px;border-radius:10px;display:block;text-decoration:none;background:#fff">
			<strong><?php echo esc_html( $term->name ); ?></strong><br>
			<span style="font-size:12px;color:#666"><?php echo sprintf( _n( '%d property', '%d properties', $count, 'estat-os' ), $count ); ?></span>
		</a>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A map, using OpenStreetMap by default so no paid key is needed.
	 *
	 * @param float  $lat   Latitude.
	 * @param float  $lng   Longitude.
	 * @param string $label Marker label.
	 * @return string
	 */
	public static function map( float $lat, float $lng, string $label = '' ): string {
		$provider = (string) Settings::get( 'map_provider', 'osm' );
		if ( 'none' === $provider || ( 0.0 === $lat && 0.0 === $lng ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );

		if ( 'google' === $provider && '' !== (string) Settings::get( 'google_maps_key' ) ) {
			$src = add_query_arg(
				array(
					'key' => rawurlencode( (string) Settings::get( 'google_maps_key' ) ),
					'q'   => rawurlencode( $lat . ',' . $lng ),
				),
				'https://www.google.com/maps/embed/v1/place'
			);
		} else {
			$delta = 0.01;
			$bbox  = ( $lng - $delta ) . ',' . ( $lat - $delta ) . ',' . ( $lng + $delta ) . ',' . ( $lat + $delta );
			$src   = add_query_arg(
				array( 'bbox' => $bbox, 'layer' => 'mapnik', 'marker' => $lat . ',' . $lng ),
				'https://www.openstreetmap.org/export/embed.html'
			);
		}

		return '<div class="estat-map"><iframe title="' . esc_attr( '' !== $label ? $label : __( 'Map', 'estat-os' ) ) . '" src="' . esc_url( $src ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>';
	}

	/**
	 * The team directory.
	 *
	 * @param int $limit Maximum team members.
	 * @return string
	 */
	public static function agents( int $limit = 12 ): string {
		wp_enqueue_style( 'estat-public' );
		$ids = get_posts(
			array(
				'post_type'      => PostTypes::AGENT,
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, min( 100, $limit ) ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		if ( ! $ids ) {
			return '<p class="estat-empty">' . esc_html__( 'No team members have been added yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-grid estat-team">';
		foreach ( $ids as $id ) {
			$agent = Agents::to_array( (int) $id );
			?>
			<article class="estat-agent">
				<?php if ( '' !== (string) $agent['photo'] ) : ?>
					<?php
					// The stylesheet renders this at a fixed 88px circle, so
					// the size is known here without asking the database.
					?>
					<img
						class="estat-agent-photo"
						src="<?php echo esc_url( (string) $agent['photo'] ); ?>"
						alt="<?php echo esc_attr( (string) $agent['name'] ); ?>"
						width="88"
						height="88"
						loading="lazy"
						decoding="async"
					/>
				<?php endif; ?>
				<h3><a href="<?php echo esc_url( (string) $agent['url'] ); ?>"><?php echo esc_html( (string) $agent['name'] ); ?></a></h3>
				<?php if ( '' !== (string) $agent['role'] ) : ?>
					<p class="estat-agent-role"><?php echo esc_html( (string) $agent['role'] ); ?></p>
				<?php endif; ?>
				<p class="estat-agent-contact">
					<?php if ( '' !== (string) $agent['phone'] ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $agent['phone'] ) ); ?>"><?php esc_html_e( 'Call', 'estat-os' ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== (string) $agent['whatsapp'] ) : ?>
						<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', (string) $agent['whatsapp'] ) ); ?>" rel="nofollow noopener"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
					<?php endif; ?>
				</p>
			</article>
			<?php
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * The comparison tray.
	 *
	 * @return string
	 */
	public static function compare(): string {
		if ( ! Settings::get( 'enable_compare' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		return '<section class="estat-compare-panel" id="estat-compare-panel" aria-live="polite">'
			. '<h2>' . esc_html__( 'Compare properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-empty">' . esc_html__( 'Choose "Compare" on a few properties and they will appear here side by side.', 'estat-os' ) . '</p>'
			. '<div class="estat-compare-table"></div></section>';
	}

	/**
	 * The saved-properties list.
	 *
	 * @return string
	 */
	public static function favorites(): string {
		if ( ! Settings::get( 'enable_favorites' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		return '<section class="estat-favorites" id="estat-favorites" aria-live="polite">'
			. '<h2>' . esc_html__( 'Your saved properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-empty">' . esc_html__( 'Nothing saved yet. Tap the heart on any property to keep it here.', 'estat-os' ) . '</p>'
			. '<div class="estat-grid"></div></section>';
	}
}
