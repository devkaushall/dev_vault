<?php
/**
 * Public Pages without Elementor — F12 Mayfair Edition
 *
 * Creates real WP pages with shortcodes so the site works out of the box
 * with any theme, no Elementor, no page builder needed.
 *
 * - 14 public pages: properties, search, projects, projects-by-stage,
 *   team, localities, amenities, features, favorites, compare, emi,
 *   alerts, locality-map, office
 * - Auto-create on activation, manual recreate via Tools
 * - Settings toggle: enable/disable auto-create
 * - Theme compatibility: template_include fallback to plugin's page-public.php
 *   if theme has no page.php (rare) or if page is ours and theme is block theme
 * - URLs: uses normal page permalinks, so SEO friendly
 * - Shortcodes are the same as [estat_properties] etc, so Elementor widgets
 *   and shortcodes never drift
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Pages {

	/**
	 * Option key storing created page IDs: slug => ID
	 */
	public const OPTION = 'estat_public_pages';

	/**
	 * All public pages the plugin can create.
	 *
	 * @var array<string,array{title:string,shortcode:string,desc:string,icon:string}>
	 */
	public const PAGES = array(
		'properties' => array(
			'title'     => 'Properties',
			'shortcode' => '[estat_properties per_page="12"]',
			'desc'      => 'All properties directory with pagination',
			'icon'      => 'home',
		),
		'search' => array(
			'title'     => 'Search Properties',
			'shortcode' => '[estat_search]',
			'desc'      => 'Search form with filters',
			'icon'      => 'search',
		),
		'projects' => array(
			'title'     => 'Projects',
			'shortcode' => '[estat_projects per_page="12"]',
			'desc'      => 'All projects grid with stage and progress',
			'icon'      => 'building',
		),
		'projects-by-stage' => array(
			'title'     => 'Projects by Stage',
			'shortcode' => '[estat_projects_by_stage]',
			'desc'      => 'Projects grouped by stage',
			'icon'      => 'chart',
		),
		'team' => array(
			'title'     => 'Our Team',
			'shortcode' => '[estat_team limit="24"]',
			'desc'      => 'Team directory',
			'icon'      => 'users',
		),
		'localities' => array(
			'title'     => 'Localities',
			'shortcode' => '[estat_localities]',
			'desc'      => 'Locality pages with counts',
			'icon'      => 'map-pin',
		),
		'locality-map' => array(
			'title'     => 'Locality Map',
			'shortcode' => '[estat_locality_map]',
			'desc'      => 'Explore by locality',
			'icon'      => 'map',
		),
		'amenities' => array(
			'title'     => 'Amenities',
			'shortcode' => '[estat_amenities]',
			'desc'      => 'Amenity pages with counts',
			'icon'      => 'star',
		),
		'features' => array(
			'title'     => 'Features',
			'shortcode' => '[estat_features]',
			'desc'      => 'Feature pages with counts',
			'icon'      => 'sparkles',
		),
		'favorites' => array(
			'title'     => 'Saved Properties',
			'shortcode' => '[estat_favorites]',
			'desc'      => 'Saved properties',
			'icon'      => 'heart',
		),
		'compare' => array(
			'title'     => 'Compare Properties',
			'shortcode' => '[estat_compare]',
			'desc'      => 'Compare properties side by side',
			'icon'      => 'scale',
		),
		'emi' => array(
			'title'     => 'EMI Calculator',
			'shortcode' => '[estat_emi price="5000000"]',
			'desc'      => 'EMI calculator',
			'icon'      => 'calculator',
		),
		'alerts' => array(
			'title'     => 'Search Alerts',
			'shortcode' => '[estat_alerts]',
			'desc'      => 'Search alerts',
			'icon'      => 'bell',
		),
	);

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'init', array( __CLASS__, 'maybe_create_on_init' ), 20 );
		add_filter( 'template_include', array( __CLASS__, 'template_fallback' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register settings UI hint — actual setting lives in Settings::defaults().
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		// No-op, settings are in main Settings class. This exists so future
		// extensions can hook.
	}

	/**
	 * All defined pages.
	 *
	 * @return array<string,array{title:string,shortcode:string,desc:string,icon:string}>
	 */
	public static function all(): array {
		/**
		 * Filter public pages list.
		 *
		 * @param array $pages Pages.
		 */
		return (array) apply_filters( 'estat_public_pages', self::PAGES );
	}

	/**
	 * Get stored page IDs.
	 *
	 * @return array<string,int>
	 */
	public static function stored(): array {
		$stored = get_option( self::OPTION, array() );
		return is_array( $stored ) ? array_map( 'absint', $stored ) : array();
	}

	/**
	 * Get URL for a public page slug, or empty if not created.
	 *
	 * @param string $slug Slug.
	 * @return string
	 */
	public static function get_url( string $slug ): string {
		$stored = self::stored();
		$id = $stored[ $slug ] ?? 0;
		if ( $id > 0 ) {
			$url = get_permalink( $id );
			if ( $url ) {
				return $url;
			}
		}
		// Fallback to archive if properties page missing.
		if ( 'properties' === $slug ) {
			$archive = get_post_type_archive_link( \EstatOS\Data\PostTypes::LISTING );
			return $archive ?: '';
		}
		return '';
	}

	/**
	 * Maybe auto-create pages on init if enabled and not yet done.
	 *
	 * @return void
	 */
	public static function maybe_create_on_init(): void {
		// Never auto-create on frontend or upgrade. Only via Settings → Pages button.
		// This prevents 13 pages auto-published on 28 Sep.
		return;
	}

	/**
	 * Create all public pages as drafts — skips existing slugs, only shortcode.
	 *
	 * @param bool $force Force recreate even if exists.
	 * @return array<string,int> Created IDs.
	 */
	public static function create_all( bool $force = false ): array {
		$all = self::all();
		$stored = self::stored();
		$created = array();

		foreach ( $all as $slug => $def ) {
			$existing_id = $stored[ $slug ] ?? 0;
			if ( ! $force && $existing_id > 0 && get_post_status( $existing_id ) ) {
				$created[ $slug ] = $existing_id;
				continue;
			}
			// Check by slug if page already exists (user may have created manually).
			$page = get_page_by_path( $slug, OBJECT, 'page' );
			if ( ! $force && $page instanceof \WP_Post ) {
				$created[ $slug ] = $page->ID;
				continue;
			}
			$id = self::create_one( $slug, $def );
			if ( $id > 0 ) {
				$created[ $slug ] = $id;
			}
		}

		// Merge with existing stored, prefer new.
		$merged = array_merge( $stored, $created );
		update_option( self::OPTION, $merged, false );

		return $created;
	}

	/**
	 * Create one public page.
	 *
	 * @param string $slug Slug.
	 * @param array  $def  Definition.
	 * @return int Page ID or 0.
	 */
	public static function create_one( string $slug, array $def = array() ): int {
		if ( '' === $slug ) {
			return 0;
		}
		if ( ! $def ) {
			$all = self::all();
			$def = $all[ $slug ] ?? array();
		}
		if ( ! $def ) {
			return 0;
		}
		$title = $def['title'] ?? ucfirst( $slug );
		$shortcode = $def['shortcode'] ?? '';

		// Only shortcode, no developer notes, draft per rules
		$content = $shortcode;

		$postarr = array(
			'post_title'   => $title,
			'post_name'    => sanitize_title( $slug ),
			'post_content' => $content,
			'post_status'  => 'draft',
			'post_type'    => 'page',
			'comment_status' => 'closed',
		);

		// Check again by path to avoid duplicate on race.
		$existing = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $existing instanceof \WP_Post ) {
			// Update content if it still has our marker? Keep user edits if they removed shortcode? We update only if forced.
			return $existing->ID;
		}

		$id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $id ) ) {
			return 0;
		}
		// Mark as ours.
		update_post_meta( (int) $id, '_estat_public_page', $slug );
		update_post_meta( (int) $id, '_estat_public_page_version', ESTAT_VERSION );

		return (int) $id;
	}

	/**
	 * Delete all public pages (for testing / reset).
	 *
	 * @return int Number deleted.
	 */
	public static function delete_all(): int {
		$stored = self::stored();
		$count = 0;
		foreach ( $stored as $id ) {
			if ( $id > 0 && get_post_type( $id ) === 'page' ) {
				wp_trash_post( $id );
				$count++;
			}
		}
		delete_option( self::OPTION );
		delete_option( 'estat_public_pages_created' );
		return $count;
	}

	/**
	 * Template fallback for public pages when theme is missing page.php
	 * or is a block theme that doesn't render shortcodes well in some edge.
	 *
	 * We only intervene if:
	 * - is_page() and page is one of ours
	 * - theme has no page.php and no singular.php and no index.php? Actually
	 *   WordPress always has index.php, but block themes may have templates
	 *   that don't call the_content in a way we expect. So we provide a minimal
	 *   fallback that still shows header/footer if available, else bare HTML.
	 *
	 * @param string $template Current template.
	 * @return string
	 */
	public static function template_fallback( $template ) {
		if ( ! is_page() ) {
			return $template;
		}
		$page_id = get_queried_object_id();
		if ( ! $page_id ) {
			return $template;
		}
		$slug = get_post_meta( $page_id, '_estat_public_page', true );
		if ( '' === $slug ) {
			// Also check if ID is in stored list.
			$stored = self::stored();
			$slug = array_search( $page_id, $stored, true );
			if ( false === $slug ) {
				return $template;
			}
		}

		// If theme has page.php, let it handle — shortcodes work fine.
		// But if theme is block theme and template is block template that
		// doesn't include post content? WordPress block templates do include
		// post content via template part. So we don't need to override unless
		// template is empty or user explicitly wants our wrapper.
		// For F12, we provide opt-in via filter 'estat_use_public_page_template'.

		/**
		 * Filter whether to use plugin's public page template for our pages.
		 *
		 * @param bool   $use      Whether to use plugin template.
		 * @param int    $page_id  Page ID.
		 * @param string $slug     Public page slug.
		 */
		$use = (bool) apply_filters( 'estat_use_public_page_template', false, $page_id, $slug );

		// Also auto-use if theme has no page.php and is not block theme — very old theme edge.
		if ( ! $use ) {
			$has_page = locate_template( array( 'page.php', 'singular.php' ) );
			if ( '' === $has_page && ! function_exists( 'wp_is_block_theme' ) ) {
				$use = true;
			} elseif ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
				// Block theme: check if template is block template with no content? We stay false by default
				// to respect FSE. Only use ours if filter says so.
				$use = false;
			}
		}

		if ( ! $use ) {
			return $template;
		}

		$fallback = ESTAT_DIR . 'includes/Frontend/templates/page-public.php';
		if ( is_readable( $fallback ) ) {
			return $fallback;
		}
		return $template;
	}

	/**
	 * Render a public page list for admin.
	 *
	 * @return string HTML
	 */
	public static function admin_list_html(): string {
		$all = self::all();
		$stored = self::stored();
		ob_start();
		echo '<table class="widefat striped"><thead><tr><th>Page</th><th>Slug</th><th>Shortcode</th><th>Status</th><th>View</th></tr></thead><tbody>';
		foreach ( $all as $slug => $def ) {
			$id = $stored[ $slug ] ?? 0;
			$exists = $id > 0 && get_post_status( $id );
			$url = $exists ? get_permalink( $id ) : '';
			$edit = $exists ? get_edit_post_link( $id ) : '';
			echo '<tr>';
			echo '<td>' . esc_html( $def['icon'] . ' ' . $def['title'] ) . '<br><small>' . esc_html( $def['desc'] ) . '</small></td>';
			echo '<td><code>' . esc_html( $slug ) . '</code></td>';
			echo '<td><code class="estat-copyable">' . esc_html( $def['shortcode'] ) . '</code></td>';
			echo '<td>' . ( $exists ? '✓ Created (ID ' . $id . ')' : '— Not created' ) . '</td>';
			echo '<td>' . ( $url ? '<a href="' . esc_url( $url ) . '" target="_blank">View</a>' . ( $edit ? ' | <a href="' . esc_url( $edit ) . '">Edit</a>' : '' ) : '<em>—</em>' ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		return (string) ob_get_clean();
	}
}
