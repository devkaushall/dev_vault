<?php
/**
 * Shortcodes: the Elementor-free way to place plugin components.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Forms\Renderer;
use EstatOS\I18n\Language;
use EstatOS\Support\Sanitize;

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode names are a public contract.
 */
final class Shortcodes {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_shortcode( 'estat_properties', array( __CLASS__, 'properties' ) );
		add_shortcode( 'estat_search', array( __CLASS__, 'search' ) );
		add_shortcode( 'estat_form', array( __CLASS__, 'form' ) );
		add_shortcode( 'estat_team', array( __CLASS__, 'team' ) );
		add_shortcode( 'estat_compare', array( __CLASS__, 'compare' ) );
		add_shortcode( 'estat_favorites', array( __CLASS__, 'favorites' ) );
		add_shortcode( 'estat_language', array( __CLASS__, 'language' ) );
		add_shortcode( 'estat_alerts', array( __CLASS__, 'alerts' ) );
		add_shortcode( 'estat_share', array( __CLASS__, 'share' ) );
		add_shortcode( 'estat_localities', array( __CLASS__, 'localities' ) );
		add_shortcode( 'estat_amenities', array( __CLASS__, 'amenities' ) );
		add_shortcode( 'estat_features', array( __CLASS__, 'features' ) );
		add_shortcode( 'estat_projects', array( __CLASS__, 'projects' ) );
		add_shortcode( 'estat_projects_by_stage', array( __CLASS__, 'projects_by_stage' ) );
		add_shortcode( 'estat_emi', array( __CLASS__, 'emi' ) );
		add_shortcode( 'estat_locality_map', array( __CLASS__, 'locality_map' ) );
		add_shortcode( 'estat_public_pages', array( __CLASS__, 'public_pages' ) );
		add_shortcode( 'estat_office', array( __CLASS__, 'office_page' ) );
	}

	/**
	 * [estat_properties] property directory.
	 *
	 * @param array<string,mixed>|string $atts Attributes.
	 * @return string
	 */
	public static function properties( $atts ): string {
		$atts = shortcode_atts(
			array(
				'offer'      => '',
				'type'       => '',
				'locality'   => '',
				'featured'   => '',
				'project'    => '',
				'agent'      => '',
				'orderby'    => '',
				'per_page'   => 12,
			),
			(array) $atts,
			'estat_properties'
		);

		// Read every GET parameter the search form emits — must work with JS off.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$get_raw = array();
		foreach ( $_GET as $k => $v ) {
			$k = sanitize_key( (string) $k );
			// Allow only known filter keys to avoid pollution
			$allowed = array( 'keyword','offer','property_type','locality','bedrooms_min','bedrooms_max','bathrooms_min','price_min','price_max','area_min','area_max','furnishing','facing','floor_min','floor_max','total_floors_min','parking_min','balconies_min','age_max','possession','construction','availability','verified','featured','investment','project_id','agent_id','amenities','features','orderby','estat_page' );
			if ( ! in_array( $k, $allowed, true ) ) { continue; }
			if ( is_array( $v ) ) {
				$get_raw[ $k ] = array_map( 'sanitize_text_field', array_slice( $v, 0, 30 ) );
			} else {
				$get_raw[ $k ] = sanitize_text_field( wp_unslash( (string) ( is_array( $v ) ? '' : $v ) ) );
			}
		}
		// phpcs:enable

		$page = isset( $get_raw['estat_page'] ) ? \EstatOS\Support\Sanitize::int( $get_raw['estat_page'], 1, 10000 ) : 1;
		if ( isset( $_GET['estat_page'] ) ) {
			$page = \EstatOS\Support\Sanitize::int( wp_unslash( is_array($_GET['estat_page']) ? '' : $_GET['estat_page'] ), 1, 10000 );
		}

		// Merge shortcode atts with GET — GET wins for filtering, except per_page/orderby from atts if not in GET
		$merged = array(
			'offer'         => '' !== ( $get_raw['offer'] ?? '' ) ? $get_raw['offer'] : $atts['offer'],
			'property_type' => ! empty( $get_raw['property_type'] ) ? (array) $get_raw['property_type'] : ( '' !== $atts['type'] ? explode( ',', (string) $atts['type'] ) : array() ),
			'locality'      => ! empty( $get_raw['locality'] ) ? (array) $get_raw['locality'] : ( '' !== $atts['locality'] ? explode( ',', (string) $atts['locality'] ) : array() ),
			'featured'      => isset( $get_raw['featured'] ) ? ( '1' === $get_raw['featured'] || 'true' === $get_raw['featured'] ) : ( '' !== $atts['featured'] ),
			'project_id'    => isset( $get_raw['project_id'] ) ? (int) $get_raw['project_id'] : (int) $atts['project'],
			'agent_id'      => isset( $get_raw['agent_id'] ) ? (int) $get_raw['agent_id'] : (int) $atts['agent'],
			'orderby'       => '' !== ( $get_raw['orderby'] ?? '' ) ? $get_raw['orderby'] : ( '' !== $atts['orderby'] ? $atts['orderby'] : 'recent' ),
			'per_page'      => (int) $atts['per_page'],
			'page'          => $page,
		);
		// Add all other filters from GET directly
		$extra_keys = array( 'keyword','bedrooms_min','bedrooms_max','bathrooms_min','price_min','price_max','area_min','area_max','furnishing','facing','floor_min','floor_max','total_floors_min','parking_min','balconies_min','age_max','possession','construction','availability','verified','featured','investment','amenities','features' );
		foreach ( $extra_keys as $ek ) {
			if ( isset( $get_raw[ $ek ] ) ) {
				$merged[ $ek ] = $get_raw[ $ek ];
			}
		}

		return Components::directory( $merged );
	}

	/**
	 * [estat_search] search form.
	 *
	 * @param array<string,mixed>|string $atts Attributes.
	 * @return string
	 */
	public static function search( $atts ): string {
		$atts = shortcode_atts( array( 'action' => '' ), (array) $atts, 'estat_search' );
		return Components::search_form( array( 'action' => $atts['action'] ) );
	}

	/**
	 * [estat_form id="1"] a plugin form.
	 * B12 fix: hidden context fields listing_id, project_id, source_url auto-filled.
	 *
	 * @param array<string,mixed>|string $atts Attributes.
	 * @return string
	 */
	public static function form( $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0, 'listing' => 0, 'project' => 0, 'agent' => 0, 'class' => '' ), (array) $atts, 'estat_form' );
		$id   = (int) $atts['id'];
		if ( $id <= 0 ) {
			return '';
		}
		$listing = (int) $atts['listing'];
		$project = (int) $atts['project'];
		// Auto-fill from current page context.
		if ( 0 === $listing && is_singular( \EstatOS\Data\PostTypes::LISTING ) ) {
			$listing = (int) get_queried_object_id() ?: (int) get_the_ID();
		}
		if ( 0 === $project && is_singular( \EstatOS\Data\PostTypes::PROJECT ) ) {
			$project = (int) get_queried_object_id() ?: (int) get_the_ID();
		}
		// Also try global post if queried object not set (shortcode in content).
		if ( 0 === $listing ) {
			$maybe = get_the_ID();
			if ( $maybe && \EstatOS\Data\PostTypes::LISTING === get_post_type( $maybe ) ) {
				$listing = (int) $maybe;
			}
		}
		if ( 0 === $project ) {
			$maybe = get_the_ID();
			if ( $maybe && \EstatOS\Data\PostTypes::PROJECT === get_post_type( $maybe ) ) {
				$project = (int) $maybe;
			}
		}
		return Renderer::render(
			$id,
			array(
				'listing_id' => $listing,
				'project_id' => $project,
				'agent_id'   => (int) $atts['agent'],
				'class'      => (string) $atts['class'],
			)
		);
	}

	/**
	 * [estat_team] team directory.
	 *
	 * @param array<string,mixed>|string $atts Attributes.
	 * @return string
	 */
	public static function team( $atts ): string {
		$atts = shortcode_atts( array( 'limit' => 12 ), (array) $atts, 'estat_team' );
		return Components::agents( (int) $atts['limit'] );
	}

	/**
	 * [estat_compare] comparison tray.
	 *
	 * @return string
	 */
	public static function compare(): string {
		return Components::compare();
	}

	/**
	 * [estat_favorites] saved properties.
	 *
	 * @return string
	 */
	public static function favorites(): string {
		return Components::favorites();
	}

	/**
	 * [estat_language] language selector.
	 *
	 * @return string
	 */
	public static function language(): string {
		return Language::selector();
	}

	/**
	 * [estat_alerts] search alerts form.
	 *
	 * @return string
	 */
	public static function alerts(): string {
		// 3.0.7: hidden behind setting default OFF.
		if ( ! \EstatOS\Settings\Settings::get( 'search_alerts_enabled', false ) ) {
			return '';
		}
		wp_enqueue_script( 'estat-share' );
		ob_start();
		?>
		<div class="estat-alerts-box" style="border:1px solid var(--estat-line);border-radius:12px;padding:20px;background:var(--estat-card)">
			<h3><?php esc_html_e( 'Watch this search', 'estat-os' ); ?></h3>
			<p class="estat-muted"><?php esc_html_e( 'Get email when matching home goes live. Confirm via email.', 'estat-os' ); ?></p>
			<form class="estat-alert-form">
				<p><label><?php esc_html_e( 'Your name', 'estat-os' ); ?><br><input type="text" name="name" required style="width:100%"></label></p>
				<p><label><?php esc_html_e( 'Email', 'estat-os' ); ?><br><input type="email" name="email" required style="width:100%"></label></p>
				<p><label><?php esc_html_e( 'Phone (optional)', 'estat-os' ); ?><br><input type="tel" name="phone" style="width:100%"></label></p>
				<p><label><?php esc_html_e( 'Frequency', 'estat-os' ); ?><br><select name="frequency" style="width:100%"><option value="instant"><?php esc_html_e( 'Instant', 'estat-os' ); ?></option><option value="daily"><?php esc_html_e( 'Daily digest', 'estat-os' ); ?></option></select></label></p>
				<?php
				// Sanitize $_GET to prevent large/malicious payloads and array-to-string warnings.
				$safe_filters = array();
				foreach ( $_GET as $k => $v ) {
					$k = sanitize_key( $k );
					if ( is_array( $v ) ) {
						$safe_filters[ $k ] = array_map( 'sanitize_text_field', array_slice( $v, 0, 20 ) );
					} else {
						$safe_filters[ $k ] = sanitize_text_field( wp_unslash( (string) ( is_array( $v ) ? '' : $v ) ) );
					}
				}
				?>
				<input type="hidden" name="filters" value="<?php echo esc_attr( wp_json_encode( $safe_filters ) ); ?>">
				<input type="hidden" name="source_url" value="<?php echo esc_attr( ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( is_array($_SERVER['REQUEST_URI']) ? '' : $_SERVER['REQUEST_URI'] ) ) : '' ) ); ?>">
				<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Watch this search', 'estat-os' ); ?></button></p>
				<p class="estat-alert-msg" style="font-size:13px"></p>
			</form>
			<script>
			document.addEventListener('DOMContentLoaded', function(){
				const form = document.querySelector('.estat-alerts-box .estat-alert-form');
				if(!form) return;
				form.addEventListener('submit', function(e){
					e.preventDefault();
					const fd = new FormData(form);
					const data = {name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone'), frequency: fd.get('frequency'), filters: JSON.parse(fd.get('filters')||'{}'), query: JSON.parse(fd.get('filters')||'{}'), source_url: fd.get('source_url')};
					fetch((window.estatPublic?.restUrl || '/wp-json/estat/v1/') + 'alerts', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)}).then(r=>r.json()).then(j=>{
						const msg = form.querySelector('.estat-alert-msg');
						if(j.id||j.success){ if(msg) msg.textContent='Alert saved! Check email to confirm.'; }
						else { if(msg) msg.textContent=j.message||'Failed'; }
					});
				});
			});
			</script>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * [estat_share] share row for current listing.
	 *
	 * @return string
	 */
	public static function share(): string {
		if ( ! is_singular( 'estat_listing' ) ) {
			return '';
		}
		return \EstatOS\Frontend\Share::render_row( get_the_ID() );
	}

	/**
	 * [estat_localities] locality pages.
	 *
	 * @return string
	 */
	public static function localities(): string {
		$terms = get_terms( array( 'taxonomy' => 'estat_locality', 'hide_empty' => false, 'number' => 100 ) );
		if ( is_wp_error( $terms ) || ! $terms ) {
			return '<p>' . esc_html__( 'No localities yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-localities-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">';
		foreach ( $terms as $term ) {
			$count = $term->count;
			echo '<a href="' . esc_url( get_term_link( $term ) ) . '" style="border:1px solid var(--estat-line);padding:12px;border-radius:8px;display:block;text-decoration:none">';
			echo '<strong>' . esc_html( $term->name ) . '</strong><br><span style="font-size:12px;color:var(--estat-muted)">' . sprintf( _n( '%d property', '%d properties', $count, 'estat-os' ), $count ) . '</span>';
			echo '</a>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_amenities] amenity pages grid
	 *
	 * @return string
	 */
	public static function amenities(): string {
		$terms = get_terms( array( 'taxonomy' => 'estat_amenity', 'hide_empty' => false, 'number' => 100 ) );
		if ( is_wp_error( $terms ) || ! $terms ) {
			return '<p>' . esc_html__( 'No amenities yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-amenities-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px">';
		foreach ( $terms as $term ) {
			$count = $term->count;
			echo '<a href="' . esc_url( get_term_link( $term ) ) . '" style="border:1px solid var(--estat-line);padding:12px;border-radius:8px;display:block;text-decoration:none;text-align:center">';
			echo '<div style="font-size:24px;color:var(--estat-primary, #111)" aria-hidden="true"><svg width="24" height="24" viewBox="0 0 256 256" fill="currentColor"><path d="M88,149.39a8,8,0,0,0,8-8V128h64v15.29a8,8,0,0,0,16,0V32a8,8,0,0,0-16,0V48H96V32a8,8,0,0,0-16,0V141.39A8,8,0,0,0,88,149.39ZM96,112V96h64v16Zm64-48V80H96V64ZM24,168a8,8,0,0,1,8-8c14.42,0,22.19,5.18,28.44,9.34C66,173.06,70.42,176,80,176s14-2.94,19.56-6.66c6.24-4.16,14-9.34,28.43-9.34s22.2,5.18,28.44,9.34c5.58,3.72,10,6.66,19.57,6.66s14-2.94,19.56-6.66c6.25-4.16,14-9.34,28.44-9.34a8,8,0,0,1,0,16c-9.58,0-14,2.94-19.56,6.66-6.25,4.16-14,9.34-28.44,9.34s-22.2-5.18-28.44-9.34C142,178.94,137.57,176,128,176s-14,2.94-19.56,6.66c-6.24,4.16-14,9.34-28.43,9.34s-22.19-5.18-28.44-9.34C46,178.94,41.58,176,32,176A8,8,0,0,1,24,168Z"/></svg></div><strong>' . esc_html( $term->name ) . '</strong><br><span style="font-size:12px;color:var(--estat-muted)">' . sprintf( _n( '%d property', '%d properties', $count, 'estat-os' ), $count ) . '</span>';
			echo '</a>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_features] feature grid
	 *
	 * @return string
	 */
	public static function features(): string {
		$terms = get_terms( array( 'taxonomy' => 'estat_feature', 'hide_empty' => false, 'number' => 100 ) );
		if ( is_wp_error( $terms ) || ! $terms ) {
			return '<p>' . esc_html__( 'No features yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-features-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px">';
		foreach ( $terms as $term ) {
			$count = $term->count;
			echo '<a href="' . esc_url( get_term_link( $term ) ) . '" style="border:1px solid var(--estat-line);padding:12px;border-radius:8px;display:block;text-decoration:none">';
			echo '<strong>' . esc_html( $term->name ) . '</strong><br><span style="font-size:12px;color:var(--estat-muted)">' . sprintf( _n( '%d property', '%d properties', $count, 'estat-os' ), $count ) . '</span>';
			echo '</a>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_projects] all projects grid.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function projects( $atts ): string {
		$atts = shortcode_atts( array( 'stage' => '', 'per_page' => 12 ), (array) $atts, 'estat_projects' );
		$args = array( 'post_type' => \EstatOS\Data\PostTypes::PROJECT, 'post_status' => 'publish', 'posts_per_page' => (int) $atts['per_page'], 'fields' => 'ids' );
		if ( '' !== $atts['stage'] ) {
			$args['meta_key'] = '_estat_project_status';
			$args['meta_value'] = sanitize_key( $atts['stage'] );
		}
		$ids = get_posts( $args );
		if ( ! $ids ) { return '<p>' . esc_html__( 'No projects found.', 'estat-os' ) . '</p>'; }
		ob_start();
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px">';
		foreach ( $ids as $pid ) {
			$proj = \EstatOS\Data\Projects::to_array( $pid );
			$stage = $proj['stage'] ?? '';
			$label = $stage ? \EstatOS\Support\Vocabulary::project_stage_label( $stage ) : '';
			$progress = $stage ? ( \EstatOS\Support\Vocabulary::project_stage_progress()[ $stage ] ?? 0 ) : 0;
			echo '<a href="' . esc_url( $proj['url'] ) . '" style="border:1px solid #e5e7eb;border-radius:10px;padding:12px;text-decoration:none;color:#111;display:block">';
			echo '<strong>' . esc_html( $proj['title'] ) . '</strong><br>';
			if ( $label ) { echo '<span style="font-size:12px;background:#f3f4f6;padding:2px 6px;border-radius:999px">' . esc_html( $label ) . '</span><br>'; }
			echo '<div style="margin-top:8px;height:6px;background:#e5e7eb;border-radius:999px;overflow:hidden"><div style="width:' . (int) $progress . '%;height:100%;background:#111"></div></div>';
			if ( $proj['price_min_display'] ) { echo '<div style="margin-top:6px;font-size:13px">' . esc_html( $proj['price_min_display'] . ' - ' . $proj['price_max_display'] ) . '</div>'; }
			echo '</a>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_projects_by_stage] grouped by stage — grouped by Planning / Under Construction / Ready.
	 *
	 * @return string
	 */
	public static function projects_by_stage(): string {
		$stages = \EstatOS\Support\Vocabulary::project_stage_order();
		ob_start();
		echo '<div class="estat-projects-by-stage">';
		foreach ( $stages as $stage ) {
			$label = \EstatOS\Support\Vocabulary::project_stage_label( $stage );
			$ids = get_posts( array( 'post_type' => \EstatOS\Data\PostTypes::PROJECT, 'post_status' => 'publish', 'meta_key' => '_estat_project_status', 'meta_value' => $stage, 'posts_per_page' => 20, 'fields' => 'ids' ) );
			if ( ! $ids ) { continue; }
			echo '<h3 style="margin:20px 0 10px">' . esc_html( $label ) . ' <span style="font-size:12px;color:#666">(' . count( $ids ) . ')</span></h3>';
			echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px">';
			foreach ( $ids as $pid ) {
				echo '<a href="' . esc_url( get_permalink( $pid ) ) . '" style="border:1px solid #e5e7eb;border-radius:8px;padding:10px;text-decoration:none;display:block">' . esc_html( get_the_title( $pid ) ) . '</a>';
			}
			echo '</div>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_locality_map] map of localities
	 *
	 * @return string
	 */
	public static function locality_map(): string {
		$terms = get_terms( array( 'taxonomy' => 'estat_locality', 'hide_empty' => false, 'number' => 100 ) );
		if ( is_wp_error( $terms ) || ! $terms ) { return ''; }
		ob_start();
		echo '<div style="border:1px solid #e5e7eb;border-radius:12px;padding:16px">';
		echo '<h3>' . esc_html__( 'Explore by locality', 'estat-os' ) . '</h3>';
		echo '<div style="display:flex;flex-wrap:wrap;gap:8px">';
		foreach ( $terms as $term ) {
			$meta = get_term_meta( $term->term_id, '_estat_map', true );
			echo '<a href="' . esc_url( get_term_link( $term ) ) . '" style="padding:6px 10px;border:1px solid #e5e7eb;border-radius:999px;text-decoration:none;font-size:13px">' . esc_html( $term->name ) . ' (' . (int) $term->count . ')</a>';
		}
		echo '</div></div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_emi] EMI calculator standalone
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function emi( $atts ): string {
		$atts = shortcode_atts( array( 'price' => 5000000 ), (array) $atts, 'estat_emi' );
		return \EstatOS\Frontend\Components::emi( (float) $atts['price'] );
	}

	/**
	 * [estat_public_pages] list all public pages
	 *
	 * @return string
	 */
	public static function public_pages(): string {
		$all = \EstatOS\Frontend\Pages::all();
		$stored = \EstatOS\Frontend\Pages::stored();
		ob_start();
		echo '<div class="estat-public-pages-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px">';
		foreach ( $all as $slug => $def ) {
			$id = $stored[ $slug ] ?? 0;
			$url = $id ? get_permalink( $id ) : '#';
			$exists = $id && get_post_status( $id );
			echo '<a href="' . esc_url( $url ) . '" style="border:1px solid #e5e7eb;border-radius:10px;padding:14px;text-decoration:none;display:block;background:#fff">';
			echo '<div style="font-size:24px">' . esc_html( $def['icon'] ) . '</div>';
			echo '<strong>' . esc_html( $def['title'] ) . '</strong><br>';
			echo '<small style="color:#666">' . esc_html( $def['desc'] ) . '</small><br>';
			if ( $exists ) {
				echo '<span style="font-size:11px;color:#10b981">✓ ' . esc_html( $slug ) . '</span>';
			} else {
				echo '<span style="font-size:11px;color:#f59e0b">— /' . esc_html( $slug ) . '</span>';
			}
			echo '</a>';
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [estat_office] combined homepage without Elementor
	 *
	 * @return string
	 */
	public static function office_page(): string {
		ob_start();
		echo '<div class="estat-office-page">';
		echo '<section style="margin-bottom:24px">' . self::search( array() ) . '</section>';
		echo '<section style="margin-bottom:24px"><h2>' . esc_html__( 'Latest Properties', 'estat-os' ) . '</h2>' . self::properties( array( 'per_page' => 6 ) ) . '</section>';
		echo '<section style="margin-bottom:24px"><h2>' . esc_html__( 'Projects by Stage', 'estat-os' ) . '</h2>' . self::projects_by_stage() . '</section>';
		echo '<section style="margin-bottom:24px"><h2>' . esc_html__( 'Explore Localities', 'estat-os' ) . '</h2>' . self::localities() . '</section>';
		echo '<section style="margin-bottom:24px">' . self::public_pages() . '</section>';
		echo '</div>';
		return (string) ob_get_clean();
	}
}
