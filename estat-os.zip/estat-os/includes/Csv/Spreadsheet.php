<?php
/**
 * Spreadsheet import and export — F6: preview+undo + bridge from old system.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Csv;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Notifications\Notifier;
use EstatOS\Search\SearchIndex;
use EstatOS\Support\Sanitize;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Imports run in resumable batches and are duplicate safe: rows carrying a
 * reference number update the existing record instead of creating a second one,
 * so importing the same file twice changes nothing.
 *
 * F6: preview before import, undo after import, bridge from old portals.
 */
final class Spreadsheet {

	/**
	 * Rows handled per batch.
	 */
	public const BATCH = 50;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {}

	/**
	 * The documented column contract per record kind.
	 *
	 * @param string $kind listings|projects|agents|leads.
	 * @return array<string,string> Column => description.
	 */
	public static function columns( string $kind ): array {
		switch ( $kind ) {
			case 'projects':
				return array(
					'external_id'     => __( 'Your own reference number (used to avoid duplicates)', 'estat-os' ),
					'title'           => __( 'Name of the society or project', 'estat-os' ),
					'description'     => __( 'Description', 'estat-os' ),
					'locality'        => __( 'Locality', 'estat-os' ),
					'developer'       => __( 'Builder or developer', 'estat-os' ),
					'project_status'  => __( 'Stage: ready, construction, new_launch, completed', 'estat-os' ),
					'possession_date' => __( 'Possession date (YYYY-MM-DD)', 'estat-os' ),
					'price_min'       => __( 'Lowest price (numbers only)', 'estat-os' ),
					'price_max'       => __( 'Highest price (numbers only)', 'estat-os' ),
					'total_units'     => __( 'Total units', 'estat-os' ),
					'available_units' => __( 'Units still available', 'estat-os' ),
					'unit_types'      => __( 'Unit types, for example 2 BHK, 3 BHK', 'estat-os' ),
					'regulatory_id'   => __( 'Registration number', 'estat-os' ),
					'latitude'        => __( 'Map latitude', 'estat-os' ),
					'longitude'       => __( 'Map longitude', 'estat-os' ),
				);
			case 'agents':
				return array(
					'external_id' => __( 'Your own reference number', 'estat-os' ),
					'title'       => __( 'Full name', 'estat-os' ),
					'role'        => __( 'Role in the office', 'estat-os' ),
					'phone'       => __( 'Phone number', 'estat-os' ),
					'whatsapp'    => __( 'WhatsApp number', 'estat-os' ),
					'email'       => __( 'Email address', 'estat-os' ),
					'bio'         => __( 'Short biography', 'estat-os' ),
				);
			case 'leads':
				return array(
					'name'        => __( 'Name of the person', 'estat-os' ),
					'phone'       => __( 'Phone number', 'estat-os' ),
					'email'       => __( 'Email address', 'estat-os' ),
					'message'     => __( 'What they asked', 'estat-os' ),
					'source'      => __( 'Where it came from', 'estat-os' ),
					'listing_ref' => __( 'Reference number of the property they asked about', 'estat-os' ),
					'status'      => __( 'Status: new, contacted, qualified, visit_scheduled, converted, lost', 'estat-os' ),
				);
			case 'visits':
				return array(
					'scheduled_at' => __( 'When the visit is', 'estat-os' ),
					'name'         => __( 'Who is visiting', 'estat-os' ),
					'phone'        => __( 'Phone number', 'estat-os' ),
					'listing_ref'  => __( 'Reference number of the property', 'estat-os' ),
					'listing_name' => __( 'Name of the property', 'estat-os' ),
					'agent'        => __( 'Team member showing them round', 'estat-os' ),
					'outcome'      => __( 'How it went: pending, done, no_show, cancelled', 'estat-os' ),
					'notes'        => __( 'Notes', 'estat-os' ),
				);
			case 'listings':
			default:
				return array(
					'external_id'     => __( 'Your own reference number (used to avoid duplicates)', 'estat-os' ),
					'title'           => __( 'Headline for the property', 'estat-os' ),
					'description'     => __( 'Full description', 'estat-os' ),
					'offer'           => __( 'sale, rent or lease', 'estat-os' ),
					'property_type'   => __( 'apartment, villa, plot, office and so on', 'estat-os' ),
					'price'           => __( 'Price (numbers only)', 'estat-os' ),
					'price_type'      => __( 'fixed, negotiable, starting_from or on_request', 'estat-os' ),
					'rent'            => __( 'Monthly rent (numbers only)', 'estat-os' ),
					'deposit'         => __( 'Security deposit', 'estat-os' ),
					'maintenance'     => __( 'Monthly maintenance', 'estat-os' ),
					'area'            => __( 'Size (numbers only)', 'estat-os' ),
					'area_unit'       => __( 'sqft, sqyd or sqm', 'estat-os' ),
					'area_type'       => __( 'carpet, builtup, super or plot', 'estat-os' ),
					'bedrooms'        => __( 'Number of bedrooms', 'estat-os' ),
					'bathrooms'       => __( 'Number of bathrooms', 'estat-os' ),
					'balconies'       => __( 'Number of balconies', 'estat-os' ),
					'parking'         => __( 'Parking spaces', 'estat-os' ),
					'floor'           => __( 'Which floor', 'estat-os' ),
					'total_floors'    => __( 'Floors in the building', 'estat-os' ),
					'age'             => __( 'Age in years', 'estat-os' ),
					'facing'          => __( 'Direction it faces', 'estat-os' ),
					'furnishing'      => __( 'unfurnished, semi or furnished', 'estat-os' ),
					'address'         => __( 'Full address', 'estat-os' ),
					'locality'        => __( 'Locality (separate several with commas)', 'estat-os' ),
					'amenities'       => __( 'Amenities (separate several with commas)', 'estat-os' ),
					'latitude'        => __( 'Map latitude', 'estat-os' ),
					'longitude'       => __( 'Map longitude', 'estat-os' ),
					'availability'    => __( 'available, on_hold, sold or rented', 'estat-os' ),
					'construction'    => __( 'ready, construction or new_launch', 'estat-os' ),
					'possession_date' => __( 'Possession date (YYYY-MM-DD)', 'estat-os' ),
					'project_ref'     => __( 'Reference number of the society/project', 'estat-os' ),
					'agent_ref'       => __( 'Reference number of the team member', 'estat-os' ),
					'developer'       => __( 'Builder or developer', 'estat-os' ),
					'regulatory_id'   => __( 'Registration number', 'estat-os' ),
					'featured'        => __( 'yes or no', 'estat-os' ),
					'investment'      => __( 'yes or no', 'estat-os' ),
					'status'          => __( 'draft or publish', 'estat-os' ),
				);
		}
	}

	/**
	 * F6: Bridge mappings from old portals to our columns.
	 * Each old header (lowercase, underscore) maps to our column.
	 *
	 * @param string $system System key.
	 * @return array<string,string> old_header_normalized => our_column
	 */
	public static function bridge_mappings( string $system = '' ): array {
		$common = array(
			'property_id'   => 'external_id',
			'prop_id'       => 'external_id',
			'ref'           => 'external_id',
			'reference'     => 'external_id',
			'id'            => 'external_id',
			'title'         => 'title',
			'property_title'=> 'title',
			'name'          => 'title',
			'property_name' => 'title',
			'description'   => 'description',
			'desc'          => 'description',
			'details'       => 'description',
			'price'         => 'price',
			'asking_price'  => 'price',
			'sale_price'    => 'price',
			'cost'          => 'price',
			'rent'          => 'rent',
			'monthly_rent'  => 'rent',
			'area'          => 'area',
			'size'          => 'area',
			'sqft'          => 'area',
			'built_up_area' => 'area',
			'carpet_area'   => 'area',
			'bedroom'       => 'bedrooms',
			'bedrooms'      => 'bedrooms',
			'bhk'           => 'bedrooms',
			'bathroom'      => 'bathrooms',
			'bathrooms'     => 'bathrooms',
			'address'       => 'address',
			'full_address'  => 'address',
			'location'      => 'locality',
			'locality'      => 'locality',
			'area_name'     => 'locality',
			'city'          => 'locality',
			'property_type' => 'property_type',
			'type'          => 'property_type',
			'offer'         => 'offer',
			'transaction'   => 'offer',
			'for'           => 'offer',
			'furnishing'    => 'furnishing',
			'furnished'     => 'furnishing',
			'facing'        => 'facing',
			'floor'         => 'floor',
			'floor_no'      => 'floor',
			'total_floor'   => 'total_floors',
			'total_floors'  => 'total_floors',
			'age'           => 'age',
			'property_age'  => 'age',
			'possession'    => 'possession_date',
			'possession_date'=> 'possession_date',
			'latitude'      => 'latitude',
			'lat'           => 'latitude',
			'longitude'     => 'longitude',
			'lng'           => 'longitude',
			'long'          => 'longitude',
			'agent'         => 'agent_ref',
			'agent_id'      => 'agent_ref',
			'project'       => 'project_ref',
			'society'       => 'project_ref',
		);

		$systems = array(
			'generic' => $common,
			'99acres' => array_merge( $common, array(
				'propid'        => 'external_id',
				'proptype'      => 'property_type',
				'transactiontype'=> 'offer',
				'locality_label'=> 'locality',
			) ),
			'magicbricks' => array_merge( $common, array(
				'propertyid'    => 'external_id',
				'propertytype'  => 'property_type',
				'transactiontype'=> 'offer',
			) ),
			'housing' => array_merge( $common, array(
				'housing_id'    => 'external_id',
			) ),
			'nobroker' => array_merge( $common, array(
				'nb_id'         => 'external_id',
			) ),
			'makaan' => $common,
			'commonfloor' => $common,
			'old_estat' => $common,
		);

		if ( '' !== $system && isset( $systems[ $system ] ) ) {
			return $systems[ $system ];
		}
		return $common;
	}

	/**
	 * List of bridge system keys.
	 *
	 * @return array<string,string> key => label
	 */
	public static function bridge_systems(): array {
		return array(
			'generic'     => __( 'Generic CSV', 'estat-os' ),
			'99acres'     => __( '99acres export', 'estat-os' ),
			'magicbricks' => __( 'MagicBricks export', 'estat-os' ),
			'housing'     => __( 'Housing.com export', 'estat-os' ),
			'nobroker'    => __( 'NoBroker export', 'estat-os' ),
			'makaan'      => __( 'Makaan export', 'estat-os' ),
			'commonfloor' => __( 'CommonFloor export', 'estat-os' ),
			'old_estat'   => __( 'Old Estat-OS / custom', 'estat-os' ),
		);
	}

	/**
	 * Read the header row and a few sample rows from an uploaded file.
	 *
	 * @param string $path File path.
	 * @param int    $sample_rows Sample rows to read.
	 * @return array{headers:string[],rows:array<int,string[]>,total:int}|WP_Error
	 */
	public static function preview( string $path, int $sample_rows = 5 ) {
		$handle = self::open( $path );
		if ( is_wp_error( $handle ) ) {
			return $handle;
		}
		$headers = fgetcsv( $handle, 0, ',', '"', '' );
		if ( ! is_array( $headers ) ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new WP_Error( 'estat_bad_csv', __( 'We could not read the first line of this file. Please check that it is a CSV with column names.', 'estat-os' ) );
		}
		$headers = array_map( static fn( $h ) => Sanitize::text( (string) $h ), $headers );

		$rows  = array();
		$total = 0;
		while ( false !== ( $row = fgetcsv( $handle, 0, ',', '"', '' ) ) ) { // phpcs:ignore
			++$total;
			if ( count( $rows ) < $sample_rows ) {
				$rows[] = array_map( static fn( $v ) => Sanitize::text( (string) $v ), (array) $row );
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		return array( 'headers' => $headers, 'rows' => $rows, 'total' => $total );
	}

	/**
	 * Guess a mapping from file headers to known columns, with bridge support.
	 *
	 * @param string[] $headers File headers.
	 * @param string   $kind    Record kind.
	 * @param string   $bridge  Bridge system key.
	 * @return array<string,string> Column => header.
	 */
	public static function guess_mapping( array $headers, string $kind, string $bridge = '' ): array {
		$mapping = array();
		$known   = array_keys( self::columns( $kind ) );
		$bridge_map = $bridge ? self::bridge_mappings( $bridge ) : array();

		// First try direct match.
		foreach ( $known as $column ) {
			foreach ( $headers as $header ) {
				$normalized = strtolower( str_replace( array( ' ', '-' ), '_', trim( $header ) ) );
				if ( $normalized === $column ) {
					$mapping[ $column ] = $header;
					break;
				}
			}
		}
		// Then try bridge map.
		if ( $bridge_map ) {
			foreach ( $headers as $header ) {
				$norm = strtolower( str_replace( array( ' ', '-' ), '_', trim( $header ) ) );
				$norm = preg_replace( '/[^a-z0-9_]/', '', $norm );
				if ( isset( $bridge_map[ $norm ] ) ) {
					$our_col = $bridge_map[ $norm ];
					if ( in_array( $our_col, $known, true ) && ! isset( $mapping[ $our_col ] ) ) {
						$mapping[ $our_col ] = $header;
					}
				}
			}
		}
		return $mapping;
	}

	/**
	 * Create an import job — F6 adds bridge_type.
	 *
	 * @param string               $path    Stored file path.
	 * @param string               $kind    Record kind.
	 * @param array<string,string> $mapping Column mapping.
	 * @param string               $bridge  Bridge system key.
	 * @return int|WP_Error Job ID.
	 */
	public static function create_job( string $path, string $kind, array $mapping, string $bridge = '' ) {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return new WP_Error( 'estat_no_storage', __( 'The office database is not ready yet.', 'estat-os' ) );
		}
		if ( ! is_readable( $path ) ) {
			return new WP_Error( 'estat_missing_file', __( 'The uploaded file could not be found. Please upload it again.', 'estat-os' ) );
		}
		$kind    = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads' ), 'listings' );
		$preview = self::preview( $path, 0 );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$hash  = (string) hash_file( 'sha256', $path );
		$table = Schema::table( 'estat_import_jobs' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$table,
			array(
				'created_at'   => $now,
				'updated_at'   => $now,
				'user_id'      => get_current_user_id(),
				'kind'         => $kind,
				'file_path'    => $path,
				'mapping'      => (string) wp_json_encode( array_map( array( Sanitize::class, 'text' ), $mapping ) ),
				'state'        => 'running',
				'total_rows'   => (int) $preview['total'],
				'file_hash'    => $hash,
				'bridge_type'  => Sanitize::choice( $bridge, array_keys( self::bridge_systems() ), '' ),
				'created_ids'  => wp_json_encode( array() ),
				'undo_data'    => wp_json_encode( array() ),
			)
		);
		$job_id = (int) $wpdb->insert_id;
		AuditLog::record( 'import.started', 'import', $job_id, array( 'kind' => $kind, 'rows' => $preview['total'], 'bridge' => $bridge ) );
		return $job_id;
	}

	/**
	 * Process one batch of an import job — F6 records undo data.
	 *
	 * @param int  $job_id  Job ID.
	 * @param bool $dry_run Validate without writing.
	 * @return array<string,mixed>|WP_Error Progress summary.
	 */
	public static function process_batch( int $job_id, bool $dry_run = false ) {
		global $wpdb;
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $job ) {
			return new WP_Error( 'estat_not_found', __( 'That import could not be found.', 'estat-os' ) );
		}
		if ( 'done' === $job['state'] && ! $dry_run ) {
			return self::summary( $job );
		}

		$handle = self::open( (string) $job['file_path'] );
		if ( is_wp_error( $handle ) ) {
			return $handle;
		}

		$mapping = json_decode( (string) $job['mapping'], true );
		$mapping = is_array( $mapping ) ? $mapping : array();
		$headers = fgetcsv( $handle, 0, ',', '"', '' );
		$headers = is_array( $headers ) ? array_map( 'strval', $headers ) : array();

		$skip_to   = (int) $job['processed_rows'];
		$processed = 0;
		$counts    = array( 'created' => (int) $job['created_count'], 'updated' => (int) $job['updated_count'], 'skipped' => (int) $job['skipped_count'] );
		$errors    = json_decode( (string) $job['errors'], true );
		$errors    = is_array( $errors ) ? $errors : array();

		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		$created_ids = is_array( $created_ids ) ? $created_ids : array();
		$undo_data = json_decode( (string) ( $job['undo_data'] ?? '[]' ), true );
		$undo_data = is_array( $undo_data ) ? $undo_data : array();

		$row_number = 0;
		while ( false !== ( $raw = fgetcsv( $handle, 0, ',', '"', '' ) ) ) { // phpcs:ignore
			++$row_number;
			if ( $row_number <= $skip_to ) {
				continue;
			}
			if ( $processed >= self::BATCH ) {
				break;
			}
			++$processed;

			$assoc  = self::map_row( $headers, (array) $raw, $mapping );
			$result = self::import_row( (string) $job['kind'], $assoc, $dry_run, $created_ids, $undo_data );

			if ( is_wp_error( $result ) ) {
				if ( count( $errors ) < 500 ) {
					$errors[] = array(
						'row'     => $row_number + 1,
						'message' => $result->get_error_message(),
						'data'    => $assoc,
					);
				}
				++$counts['skipped'];
				continue;
			}
			++$counts[ $result ];
		}

		$position = $skip_to + $processed;
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$done = $position >= (int) $job['total_rows'] || 0 === $processed;

		if ( ! $dry_run ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$table,
				array(
					'updated_at'     => current_time( 'mysql', true ),
					'processed_rows' => $position,
					'created_count'  => $counts['created'],
					'updated_count'  => $counts['updated'],
					'skipped_count'  => $counts['skipped'],
					'errors'         => (string) wp_json_encode( $errors ),
					'created_ids'    => (string) wp_json_encode( $created_ids ),
					'undo_data'      => (string) wp_json_encode( $undo_data ),
					'state'          => $done ? 'done' : 'running',
				),
				array( 'id' => $job_id )
			);

			if ( $done ) {
				AuditLog::record( 'import.completed', 'import', $job_id, $counts );
				Notifier::import_finished( $counts );
			}
		} else {
			// Dry run summary without saving.
			return array(
				'job_id'    => $job_id,
				'state'     => $done ? 'done' : 'running',
				'total'     => (int) $job['total_rows'],
				'processed' => $position,
				'created'   => $counts['created'],
				'updated'   => $counts['updated'],
				'skipped'   => $counts['skipped'],
				'errors'    => $errors,
				'dry_run'   => true,
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$fresh = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		return self::summary( is_array( $fresh ) ? $fresh : $job );
	}

	/**
	 * Undo an import job — trash created posts, restore updated from snapshot if available.
	 *
	 * @param int $job_id Job ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function undo_job( int $job_id ) {
		global $wpdb;
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $job ) {
			return new WP_Error( 'estat_not_found', __( 'That import could not be found.', 'estat-os' ) );
		}
		if ( 'undone' === $job['state'] ) {
			return new WP_Error( 'estat_already_undone', __( 'This import has already been undone.', 'estat-os' ) );
		}

		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		$created_ids = is_array( $created_ids ) ? $created_ids : array();
		$undo_data = json_decode( (string) ( $job['undo_data'] ?? '[]' ), true );
		$undo_data = is_array( $undo_data ) ? $undo_data : array();

		$trashed = 0;
		$restored = 0;

		foreach ( $created_ids as $pid ) {
			$pid = (int) $pid;
			if ( $pid > 0 && get_post( $pid ) ) {
				wp_trash_post( $pid );
				++$trashed;
			}
		}

		foreach ( $undo_data as $snap ) {
			if ( empty( $snap['post_id'] ) ) { continue; }
			$post_id = (int) $snap['post_id'];
			$post = get_post( $post_id );
			if ( ! $post ) { continue; }
			// Restore title/content if snapshot has them.
			if ( isset( $snap['post_title'] ) || isset( $snap['post_content'] ) ) {
				wp_update_post( array(
					'ID'           => $post_id,
					'post_title'   => $snap['post_title'] ?? $post->post_title,
					'post_content' => $snap['post_content'] ?? $post->post_content,
				) );
				++$restored;
			}
			// Restore meta snapshot.
			if ( ! empty( $snap['meta'] ) && is_array( $snap['meta'] ) ) {
				foreach ( $snap['meta'] as $k => $v ) {
					update_post_meta( $post_id, $k, $v );
				}
				++$restored;
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			$table,
			array(
				'updated_at' => current_time( 'mysql', true ),
				'state'      => 'undone',
			),
			array( 'id' => $job_id )
		);

		AuditLog::record( 'import.undone', 'import', $job_id, array( 'trashed' => $trashed, 'restored' => $restored ) );

		return array(
			'job_id'   => $job_id,
			'trashed'  => $trashed,
			'restored' => $restored,
			'state'    => 'undone',
		);
	}

	/**
	 * Build a progress summary — F6 includes undo info.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return array<string,mixed>
	 */
	private static function summary( array $job ): array {
		$errors = json_decode( (string) $job['errors'], true );
		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		return array(
			'job_id'       => (int) $job['id'],
			'state'        => (string) $job['state'],
			'total'        => (int) $job['total_rows'],
			'processed'    => (int) $job['processed_rows'],
			'created'      => (int) $job['created_count'],
			'updated'      => (int) $job['updated_count'],
			'skipped'      => (int) $job['skipped_count'],
			'errors'       => is_array( $errors ) ? $errors : array(),
			'created_ids'  => is_array( $created_ids ) ? $created_ids : array(),
			'bridge_type'  => $job['bridge_type'] ?? '',
			'can_undo'     => ! empty( $created_ids ) && 'undone' !== $job['state'] && 'done' === $job['state'],
		);
	}

	/**
	 * Turn a raw CSV row into a mapped associative array.
	 *
	 * @param string[]             $headers Header row.
	 * @param array<int,mixed>     $raw     Raw values.
	 * @param array<string,string> $mapping Column => header.
	 * @return array<string,string>
	 */
	private static function map_row( array $headers, array $raw, array $mapping ): array {
		$by_header = array();
		foreach ( $headers as $index => $header ) {
			$by_header[ $header ] = isset( $raw[ $index ] ) ? Sanitize::text( (string) $raw[ $index ] ) : '';
		}
		$out = array();
		foreach ( $mapping as $column => $header ) {
			$out[ $column ] = $by_header[ $header ] ?? '';
		}
		return $out;
	}

	/**
	 * Import one row — F6 records undo data.
	 *
	 * @param string                $kind    Record kind.
	 * @param array<string,string>  $row     Mapped row.
	 * @param bool                  $dry_run Validate only.
	 * @param array<int,int>        $created_ids Reference to created IDs array.
	 * @param array<int,array>      $undo_data Reference to undo snapshots.
	 * @return string|WP_Error 'created', 'updated' or an error.
	 */
	private static function import_row( string $kind, array $row, bool $dry_run, array &$created_ids = array(), array &$undo_data = array() ) {
		switch ( $kind ) {
			case 'projects':
				$existing = Projects::find_by_external_id( $row['external_id'] ?? '' );
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['title'] ?? '' ) ) && ! $existing
						? new WP_Error( 'estat_missing_title', __( 'This row has no project name.', 'estat-os' ) )
						: ( $existing ? 'updated' : 'created' );
				}
				if ( $existing ) {
					// Snapshot for undo.
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
							'meta'         => array(
								'_estat_external_id' => get_post_meta( $existing, '_estat_external_id', true ),
							),
						);
					}
				}
				$result = Projects::save( $row, $existing );
				if ( is_wp_error( $result ) ) { return $result; }
				if ( ! $existing ) { $created_ids[] = (int) $result; }
				return $existing ? 'updated' : 'created';

			case 'agents':
				$existing = self::find_agent( $row['external_id'] ?? '', $row['email'] ?? '' );
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['title'] ?? '' ) ) && ! $existing
						? new WP_Error( 'estat_missing_name', __( 'This row has no name.', 'estat-os' ) )
						: ( $existing ? 'updated' : 'created' );
				}
				if ( $existing ) {
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
						);
					}
				}
				$result = Agents::save( $row, $existing );
				if ( is_wp_error( $result ) ) { return $result; }
				if ( ! $existing ) { $created_ids[] = (int) $result; }
				return $existing ? 'updated' : 'created';

			case 'leads':
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['name'] ?? '' ) )
						? new WP_Error( 'estat_missing_name', __( 'This row has no name.', 'estat-os' ) )
						: 'created';
				}
				$listing_id = Listings::find_by_external_id( $row['listing_ref'] ?? '' );
				$lead       = Leads::create(
					array(
						'name'            => $row['name'] ?? '',
						'phone'           => $row['phone'] ?? '',
						'email'           => $row['email'] ?? '',
						'message'         => $row['message'] ?? '',
						'source'          => 'import',
						'listing_id'      => $listing_id,
						'idempotency_key' => 'import|' . md5( wp_json_encode( $row ) ),
					)
				);
				return is_wp_error( $lead ) ? $lead : 'created';

			case 'listings':
			default:
				$existing = Listings::find_by_external_id( $row['external_id'] ?? '' );
				$input    = $row;
				if ( isset( $row['project_ref'] ) && '' !== $row['project_ref'] ) {
					$input['project_id'] = Projects::find_by_external_id( $row['project_ref'] );
				}
				if ( isset( $row['agent_ref'] ) && '' !== $row['agent_ref'] ) {
					$input['agent_id'] = self::find_agent( $row['agent_ref'], '' );
				}
				if ( isset( $row['featured'] ) ) {
					$input['featured'] = in_array( strtolower( $row['featured'] ), array( 'yes', '1', 'true', 'y' ), true );
				}
				if ( isset( $row['investment'] ) ) {
					$input['investment'] = in_array( strtolower( $row['investment'] ), array( 'yes', '1', 'true', 'y' ), true );
				}
				$input['status'] = Sanitize::choice( $row['status'] ?? 'draft', array( 'draft', 'publish' ), 'draft' );

				if ( $dry_run ) {
					$errors = Listings::validate( $input, $existing );
					if ( $errors ) {
						return new WP_Error( 'estat_invalid_row', implode( ' ', $errors ) );
					}
					return $existing ? 'updated' : 'created';
				}

				if ( $existing ) {
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
							'meta'         => array(
								'_estat_price'       => get_post_meta( $existing, '_estat_price', true ),
								'_estat_external_id' => get_post_meta( $existing, '_estat_external_id', true ),
							),
						);
					}
				}

				$result = Listings::save( $input, $existing );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
				SearchIndex::index_listing( (int) $result );
				if ( ! $existing ) {
					$created_ids[] = (int) $result;
				}
				return $existing ? 'updated' : 'created';
		}
	}

	/**
	 * Find an agent by reference number or email.
	 *
	 * @param string $external_id Reference.
	 * @param string $email       Email.
	 * @return int
	 */
	private static function find_agent( string $external_id, string $email ): int {
		$external_id = Sanitize::text( $external_id );
		if ( '' !== $external_id ) {
			$found = get_posts(
				array(
					'post_type'     => PostTypes::AGENT,
					'numberposts'   => 1,
					'fields'        => 'ids',
					'meta_key'      => '_estat_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'    => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery
					'no_found_rows' => true,
				)
			);
			if ( $found ) {
				return (int) $found[0];
			}
		}
		$email = Sanitize::email( $email );
		if ( '' !== $email ) {
			$found = get_posts(
				array(
					'post_type'     => PostTypes::AGENT,
					'numberposts'   => 1,
					'fields'        => 'ids',
					'meta_key'      => '_estat_email', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'    => $email, // phpcs:ignore WordPress.DB.SlowDBQuery
					'no_found_rows' => true,
				)
			);
			if ( $found ) {
				return (int) $found[0];
			}
		}
		return 0;
	}

	/**
	 * Export records as CSV text.
	 *
	 * @param string $kind  Record kind.
	 * @param int    $limit Maximum rows.
	 * @return string CSV content.
	 */
	public static function export( string $kind, int $limit = 5000 ): string {
		$kind    = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads', 'visits' ), 'listings' );
		$columns = array_keys( self::columns( $kind ) );
		$rows    = array();

		if ( 'visits' === $kind ) {
			$visits = Visits::query( array( 'per_page' => max( 1, min( 500, $limit ) ), 'page' => 1 ) );

			foreach ( (array) $visits['items'] as $visit ) {
				$lead       = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
				$listing_id = (int) $visit['listing_id'];

				$rows[] = array(
					'scheduled_at' => (string) $visit['scheduled_at'],
					'name'         => $lead ? (string) $lead['name'] : '',
					'phone'        => $lead ? (string) $lead['phone'] : '',
					'listing_ref'  => $listing_id > 0 ? (string) get_post_meta( $listing_id, '_estat_external_id', true ) : '',
					'listing_name' => $listing_id > 0 ? (string) get_the_title( $listing_id ) : '',
					'agent'        => (int) $visit['agent_id'] > 0 ? (string) get_the_title( (int) $visit['agent_id'] ) : '',
					'outcome'      => (string) $visit['outcome'],
					'notes'        => (string) ( $visit['notes'] ?? '' ),
				);
			}
		} elseif ( 'leads' === $kind ) {
			$leads = Leads::query( array( 'per_page' => min( 100, $limit ), 'page' => 1 ) );
			foreach ( $leads['items'] as $lead ) {
				$rows[] = array(
					'name'        => $lead['name'],
					'phone'       => $lead['phone'],
					'email'       => $lead['email'],
					'message'     => $lead['message'],
					'source'      => $lead['source'],
					'listing_ref' => (int) $lead['listing_id'] > 0 ? (string) get_post_meta( (int) $lead['listing_id'], '_estat_external_id', true ) : '',
					'status'      => $lead['status'],
				);
			}
		} else {
			$map   = array( 'listings' => PostTypes::LISTING, 'projects' => PostTypes::PROJECT, 'agents' => PostTypes::AGENT );
			$posts = get_posts(
				array(
					'post_type'      => $map[ $kind ],
					'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page' => max( 1, min( 5000, $limit ) ),
					'no_found_rows'  => true,
					'orderby'        => 'ID',
					'order'          => 'ASC',
				)
			);
			foreach ( $posts as $post ) {
				$row = array();
				foreach ( $columns as $column ) {
					$row[ $column ] = self::export_value( $post, $column, $kind );
				}
				$rows[] = $row;
			}
		}

		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $handle ) {
			return '';
		}
		fputcsv( $handle, $columns, ',', '"', '' );
		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $column ) {
				$line[] = self::safe_cell( (string) ( $row[ $column ] ?? '' ) );
			}
			fputcsv( $handle, $line, ',', '"', '' );
		}
		rewind( $handle );
		$csv = (string) stream_get_contents( $handle );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $csv;
	}

	/**
	 * Export preview — first N rows without downloading.
	 *
	 * @param string $kind  Record kind.
	 * @param int    $limit Rows to preview.
	 * @return array{columns:string[],rows:array<int,array<string,string>>,total:int}
	 */
	public static function export_preview( string $kind, int $limit = 5 ): array {
		$csv = self::export( $kind, $limit );
		$lines = explode( "\n", trim( $csv ) );
		$columns = array();
		$rows = array();
		if ( $lines ) {
			$columns = str_getcsv( array_shift( $lines ) );
			foreach ( array_slice( $lines, 0, $limit ) as $line ) {
				if ( '' === trim( $line ) ) { continue; }
				$vals = str_getcsv( $line );
				$assoc = array();
				foreach ( $columns as $i => $col ) {
					$assoc[ $col ] = $vals[ $i ] ?? '';
				}
				$rows[] = $assoc;
			}
		}
		return array( 'columns' => $columns, 'rows' => $rows, 'total' => count( $rows ) );
	}

	/**
	 * Resolve one export cell.
	 *
	 * @param \WP_Post $post   Post.
	 * @param string   $column Column name.
	 * @param string   $kind   Record kind.
	 * @return string
	 */
	private static function export_value( \WP_Post $post, string $column, string $kind ): string {
		switch ( $column ) {
			case 'title':
				return $post->post_title;
			case 'description':
			case 'bio':
				return wp_strip_all_tags( $post->post_content );
			case 'status':
				return $post->post_status;
			case 'locality':
				$terms = wp_get_object_terms( $post->ID, \EstatOS\Data\Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); if (is_wp_error($terms)) $terms = array();
				return is_wp_error( $terms ) ? '' : implode( ', ', $terms );
			case 'amenities':
				$terms = wp_get_object_terms( $post->ID, \EstatOS\Data\Taxonomies::AMENITY, array( 'fields' => 'names' ) ); if (is_wp_error($terms)) $terms = array();
				return is_wp_error( $terms ) ? '' : implode( ', ', $terms );
			case 'project_ref':
				$project_id = (int) get_post_meta( $post->ID, '_estat_project_id', true );
				return $project_id ? (string) get_post_meta( $project_id, '_estat_external_id', true ) : '';
			case 'agent_ref':
				$agent_id = (int) get_post_meta( $post->ID, '_estat_agent_id', true );
				return $agent_id ? (string) get_post_meta( $agent_id, '_estat_external_id', true ) : '';
			case 'featured':
			case 'investment':
				return get_post_meta( $post->ID, '_estat_' . $column, true ) ? 'yes' : 'no';
			default:
				$value = get_post_meta( $post->ID, '_estat_' . $column, true );
				if ( is_array( $value ) ) {
					return implode( ',', array_map( 'strval', $value ) );
				}
				return (string) $value;
		}
	}

	/**
	 * Make one cell safe to open in a spreadsheet.
	 *
	 * @param string $value Raw cell value.
	 * @return string Safe cell value.
	 */
	private static function safe_cell( string $value ): string {
		if ( '' === $value ) {
			return $value;
		}
		if ( is_numeric( $value ) ) {
			return $value;
		}
		$first = substr( $value, 0, 1 );
		if ( in_array( $first, array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Open a CSV file safely.
	 *
	 * @param string $path Path.
	 * @return resource|WP_Error
	 */
	private static function open( string $path ) {
		$uploads = wp_get_upload_dir();
		$real    = realpath( $path );
		$base    = realpath( (string) $uploads['basedir'] );
		if ( ! $real || ! $base || 0 !== strpos( $real, $base ) ) {
			return new WP_Error( 'estat_bad_path', __( 'That file is not in the uploads folder, so we cannot read it.', 'estat-os' ) );
		}
		$handle = fopen( $real, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $handle ) {
			return new WP_Error( 'estat_unreadable', __( 'We could not open the file. Please upload it again.', 'estat-os' ) );
		}
		return $handle;
	}

	/**
	 * The most recent import jobs, newest first.
	 *
	 * @param int $limit Maximum rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function recent_jobs( int $limit = 10 ): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array();
		}
		$table = Schema::table( 'estat_import_jobs' );
		$limit = Sanitize::int( $limit, 1, 100 );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Get one job.
	 *
	 * @param int $job_id Job ID.
	 * @return array<string,mixed>|null
	 */
	public static function get_job( int $job_id ): ?array {
		global $wpdb;
		if ( ! Schema::healthy() ) { return null; }
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Store an uploaded CSV in a private folder inside uploads.
	 *
	 * @param array<string,mixed> $file One entry from $_FILES.
	 * @return string|WP_Error Stored path.
	 */
	public static function store_upload( array $file ) {
		if ( ! isset( $file['tmp_name'], $file['name'] ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			return new WP_Error( 'estat_no_file', __( 'Please choose a CSV file to upload.', 'estat-os' ) );
		}
		$check = wp_check_filetype( (string) $file['name'], array( 'csv' => 'text/csv' ) );
		if ( 'csv' !== $check['ext'] ) {
			return new WP_Error( 'estat_bad_type', __( 'Only CSV files can be imported. Save your spreadsheet as CSV and try again.', 'estat-os' ) );
		}
		if ( (int) ( $file['size'] ?? 0 ) > 20 * MB_IN_BYTES ) {
			return new WP_Error( 'estat_too_big', __( 'That file is larger than 20 MB. Please split it into smaller files.', 'estat-os' ) );
		}

		$uploads = wp_get_upload_dir();
		$dir     = trailingslashit( $uploads['basedir'] ) . 'estat-imports';
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'estat_no_dir', __( 'We could not create a folder for imports.', 'estat-os' ) );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "Deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		$name = wp_unique_filename( $dir, 'import-' . gmdate( 'Ymd-His' ) . '.csv' );
		$path = trailingslashit( $dir ) . $name;
		if ( ! move_uploaded_file( (string) $file['tmp_name'], $path ) ) {
			return new WP_Error( 'estat_move_failed', __( 'We could not save the uploaded file.', 'estat-os' ) );
		}
		return $path;
	}
}
