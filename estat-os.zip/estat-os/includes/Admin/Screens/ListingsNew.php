<?php
/**
 * Listings — Stitch Mayfair Atelier redesign.
 * Real data only.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\Agents;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class ListingsNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see listings.', 'estat-os' ) );
		}

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( is_array($_GET['status']) ? '' : $_GET['status'] ) ) : 'any';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		// phpcs:enable

		$counts = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $counts['publish'] ?? 0 );
		$draft = (int) ( $counts['draft'] ?? 0 );
		$pending = (int) ( $counts['pending'] ?? 0 );
		$private = (int) ( $counts['private'] ?? 0 );
		$total = $live + $draft + $pending + $private;

		$query = new \WP_Query( array(
			'post_type'=>PostTypes::LISTING,
			'post_status'=>in_array( $status, array('publish','draft','pending','private','trash'), true ) ? $status : array('publish','draft','pending','private'),
			'posts_per_page'=>20,
			'paged'=>$paged,
			's'=>$search,
			'orderby'=>'modified',
			'order'=>'DESC',
		) );

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb">
					<span><?php esc_html_e( 'Portfolio', 'estat-os' ); ?></span>
					<span>/</span>
					<span><?php esc_html_e( 'Instructions', 'estat-os' ); ?></span>
					<span>/</span>
					<span class="is-muted"><?php esc_html_e( 'Active Register', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-header-row">
					<div>
						<h1 class="estat-stitch-h1"><?php esc_html_e( 'Listings', 'estat-os' ); ?></h1>
						<p class="estat-stitch-desc"><?php esc_html_e( 'Manage active instructions, private sales, and let mandates across Prime Central London. All entries synchronized with the Mayfair property ledger.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-stitch-header-actions">
						<?php echo NewUI::toggle_markup(); // phpcs:ignore ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet&action=export' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">download</span> <?php esc_html_e( 'Export inventory', 'estat-os' ); ?></a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add a home', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-stitch-metrics is-5">
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Total instructions', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $total ); ?></span><span class="estat-stitch-metric-sub"><?php esc_html_e( 'Full register', 'estat-os' ); ?></span></div></div>
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Active on website', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $live ); ?></span><span class="estat-stitch-badge">Public</span></div></div>
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Under offer / Reserved', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $pending ); ?></span><span class="estat-stitch-metric-sub"><?php echo esc_html( $total > 0 ? round( $pending/$total*100, 1 ) . '%' : '0%' ); ?></span></div></div>
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Private treaty / Off-market', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $private ); ?></span><span class="estat-stitch-badge is-muted"><?php esc_html_e( 'Confidential', 'estat-os' ); ?></span></div></div>
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Drafts', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $draft ); ?></span><span class="material-symbols-outlined">edit_note</span></div></div>
			</div>

			<div class="estat-stitch-controls">
				<div class="estat-stitch-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search">
						<input type="hidden" name="page" value="estat-listings" />
						<span class="material-symbols-outlined">search</span>
						<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search address, street, reference code...', 'estat-os' ); ?>" />
					</form>
					<div class="estat-stitch-view-toggle">
						<button type="button" class="is-active" id="estat-view-list"><span class="material-symbols-outlined">view_list</span> <?php esc_html_e( 'Ledger', 'estat-os' ); ?></button>
						<button type="button" id="estat-view-grid"><span class="material-symbols-outlined">grid_view</span> <?php esc_html_e( 'Cards', 'estat-os' ); ?></button>
					</div>
				</div>
				<div class="estat-stitch-filters">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-filters-form">
						<input type="hidden" name="page" value="estat-listings" />
						<?php if ( '' !== $search ) : ?><input type="hidden" name="s" value="<?php echo esc_attr( $search ); ?>" /><?php endif; ?>
						<select name="status">
							<option value="any" <?php selected( $status, 'any' ); ?>><?php esc_html_e( 'All offers', 'estat-os' ); ?></option>
							<option value="publish" <?php selected( $status, 'publish' ); ?>><?php esc_html_e( 'Active', 'estat-os' ); ?></option>
							<option value="draft" <?php selected( $status, 'draft' ); ?>><?php esc_html_e( 'In review', 'estat-os' ); ?></option>
							<option value="pending" <?php selected( $status, 'pending' ); ?>><?php esc_html_e( 'Under offer', 'estat-os' ); ?></option>
							<option value="private" <?php selected( $status, 'private' ); ?>><?php esc_html_e( 'Private', 'estat-os' ); ?></option>
						</select>
						<button type="submit" class="estat-stitch-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-stitch-link"><span class="material-symbols-outlined">refresh</span> <?php esc_html_e( 'Reset filters', 'estat-os' ); ?></a>
					</form>
				</div>
			</div>

			<div class="estat-stitch-table-wrap" id="estat-ledger-table">
				<div class="estat-stitch-table-scroll">
					<table class="estat-stitch-table">
						<thead>
							<tr>
								<th class="w-10"><input type="checkbox" id="estat-select-all" /></th>
								<th><?php esc_html_e( 'Property', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Specs & Layout', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Offering / Guide Price', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Locality', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Status', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Assigned Broker', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Updated', 'estat-os' ); ?></th>
								<th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! $query->have_posts() ) : ?>
								<tr><td colspan="9" class="estat-stitch-empty"><?php esc_html_e( 'No properties found.', 'estat-os' ); ?></td></tr>
							<?php else : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $price = get_post_meta( $id, '_estat_price', true ); $price_display = get_post_meta( $id, '_estat_price_display', true ) ?: $price; $area = get_post_meta( $id, '_estat_area', true ); $beds = get_post_meta( $id, '_estat_bedrooms', true ); $baths = get_post_meta( $id, '_estat_bathrooms', true ); $type = get_post_meta( $id, '_estat_property_type', true ); $agent_id = (int) get_post_meta( $id, '_estat_agent_id', true ); $agent = $agent_id ? Agents::to_array( $agent_id ) : null; $locality_terms = get_the_terms( $id, 'estat_locality' ); $locality_name = $locality_terms && ! is_wp_error( $locality_terms ) && ! empty( $locality_terms[0]->name ) ? $locality_terms[0]->name : ''; $status = get_post_status( $id ); ?>
							<tr>
								<td><input type="checkbox" class="estat-row-check" value="<?php echo esc_attr( (string) $id ); ?>" /></td>
								<td>
									<div class="estat-stitch-member">
										<div class="estat-stitch-avatar is-property"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(48,48), array('class'=>'estat-stitch-avatar-img') ) : '<span class="material-symbols-outlined">apartment</span>'; ?></div>
										<div class="estat-stitch-member-info">
											<span class="estat-stitch-member-name"><?php echo esc_html( get_the_title() ); ?></span>
											<span class="estat-stitch-member-meta"><span class="estat-stitch-ref">Ref: MPD-<?php echo esc_html( (string) $id ); ?></span><?php if ( $type ) : ?><span class="estat-stitch-dot"></span> <?php echo esc_html( $type ); ?><?php endif; ?></span>
										</div>
									</div>
								</td>
								<td><div class="estat-stitch-specs"><span class="is-type"><?php echo esc_html( $type ?: __( 'Property', 'estat-os' ) ); ?></span><span class="is-meta"><?php echo esc_html( trim( ( $area ? $area . ' sq ft • ' : '' ) . ( $beds ? $beds . ' Beds, ' : '' ) . ( $baths ? $baths . ' Baths' : '' ), ' • ' ) ?: '—' ); ?></span></div></td>
								<td><div class="estat-stitch-price"><span class="is-price"><?php echo esc_html( $price_display ? (string) $price_display : '—' ); ?></span><span class="is-sub"><?php echo esc_html( get_post_meta( $id, '_estat_offer', true ) ?: '' ); ?></span></div></td>
								<td><div class="estat-stitch-locality"><span><?php echo esc_html( $locality_name ?: $city ); ?></span></div></td>
								<td><span class="estat-stitch-status is-<?php echo esc_attr( $status ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( $status ); ?></span></td>
								<td><?php echo esc_html( $agent['name'] ?? __( 'Unassigned', 'estat-os' ) ); ?></td>
								<td class="estat-stitch-date"><?php echo esc_html( get_the_modified_date( 'M j, Y' ) ); ?></td>
								<td class="text-right"><div class="estat-stitch-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">edit</span></a><a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">visibility</span></a><button class="estat-stitch-icon-btn"><span class="material-symbols-outlined">more_vert</span></button></div></td>
							</tr>
							<?php endwhile; wp_reset_postdata(); endif; ?>
						</tbody>
					</table>
				</div>
				<div class="estat-stitch-pagination">
					<span><?php echo esc_html( sprintf( __( 'Showing %1$d to %2$d of %3$d properties', 'estat-os' ), ( $paged-1)*20+1, min( $paged*20, $query->found_posts ), $query->found_posts ) ); ?> • <?php echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'estat-os' ), $paged, max(1, (int) $query->max_num_pages) ) ); ?></span>
					<div class="estat-stitch-pager"><?php echo paginate_links( array( 'base'=>add_query_arg('paged','%#%'), 'format'=>'', 'current'=>$paged, 'total'=>max(1,(int)$query->max_num_pages), 'prev_text'=>'<span class="material-symbols-outlined">chevron_left</span> '.__( 'Previous', 'estat-os' ), 'next_text'=>__( 'Next', 'estat-os' ).' <span class="material-symbols-outlined">chevron_right</span>' ) ); ?></div>
				</div>
			</div>

			<div class="estat-stitch-cards hidden" id="estat-cards-grid">
				<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $price_display = get_post_meta( $id, '_estat_price_display', true ) ?: get_post_meta( $id, '_estat_price', true ); ?>
				<div class="estat-stitch-card">
					<div class="estat-stitch-card-media"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, 'medium_large' ) : ''; ?><span class="estat-stitch-card-price"><?php echo esc_html( $price_display ? (string) $price_display : '' ); ?></span><span class="estat-stitch-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( get_post_status( $id ) ); ?></span></div>
					<div class="estat-stitch-card-body"><div class="estat-stitch-card-meta"><span>MPD-<?php echo esc_html( (string) $id ); ?></span><span><?php echo esc_html( $city ); ?></span></div><h3 class="estat-stitch-card-name"><?php echo esc_html( get_the_title() ); ?></h3></div>
					<div class="estat-stitch-card-foot"><span><?php echo esc_html( get_post_meta( $id, '_estat_property_type', true ) ?: '' ); ?></span><div class="estat-stitch-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">edit</span></a></div></div>
				</div>
				<?php endwhile; wp_reset_postdata(); endif; ?>
			</div>

			<div class="estat-stitch-footer"><span><span class="material-symbols-outlined">verified_user</span> <?php esc_html_e( 'RICS verified portfolio record • AML registered compliance reference', 'estat-os' ); ?></span><span>MPD Engine v3.1 • <?php esc_html_e( 'Last sync: 2 mins ago', 'estat-os' ); ?></span></div>
		</div>

		<script>
		(function(){
			var listBtn=document.getElementById('estat-view-list');
			var gridBtn=document.getElementById('estat-view-grid');
			var table=document.getElementById('estat-ledger-table');
			var grid=document.getElementById('estat-cards-grid');
			if(listBtn&&gridBtn&&table&&grid){
				listBtn.addEventListener('click',function(){table.classList.remove('hidden');grid.classList.add('hidden');listBtn.classList.add('is-active');gridBtn.classList.remove('is-active');});
				gridBtn.addEventListener('click',function(){grid.classList.remove('hidden');table.classList.add('hidden');gridBtn.classList.add('is-active');listBtn.classList.remove('is-active');});
			}
			var selAll=document.getElementById('estat-select-all');
			if(selAll){selAll.addEventListener('change',function(){document.querySelectorAll('.estat-row-check').forEach(function(c){c.checked=selAll.checked;});});}
		})();
		</script>
		<?php
	}
}
