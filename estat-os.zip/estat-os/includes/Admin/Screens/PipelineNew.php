<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;
defined( 'ABSPATH' ) || exit;
final class PipelineNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' ); $order = Vocabulary::lead_pipeline_order(); $labels = Vocabulary::lead_statuses();
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Pipeline</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Pipeline', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php esc_html_e( 'Drag cards between columns. Real leads only.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php
				$sub = array('estat-enquiries'=>__( 'Inbox', 'estat-os' ),'estat-pipeline'=>__( 'Pipeline', 'estat-os' ),'estat-visits'=>__( 'Site Visits', 'estat-os' ),'estat-requests'=>__( 'Change Requests', 'estat-os' ),'estat-search-alerts'=>__( 'Search Alerts', 'estat-os' ),'estat-forms'=>__( 'Forms', 'estat-os' ));
				foreach ( $sub as $slug=>$label ) { $is_active = 'estat-pipeline' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; }
				?>
			</div>
			<div class="estat-stitch-pipeline">
				<?php foreach ( $order as $status ) : $results = Leads::query( array( 'status'=>$status,'per_page'=>50,'page'=>1 ) ); $label = $labels[ $status ] ?? $status; ?>
				<div class="estat-stitch-pipeline-col" data-status="<?php echo esc_attr( $status ); ?>"><div class="estat-stitch-panel-header"><h2><?php echo esc_html( $label ); ?></h2><span class="estat-stitch-badge"><?php echo (int) $results['total']; ?></span></div><?php if ( empty( $results['items'] ) ) : ?><p class="estat-stitch-muted" style="padding:12px"><?php esc_html_e( 'Nothing here yet.', 'estat-os' ); ?></p><?php else : foreach ( $results['items'] as $lead ) : ?><div class="estat-stitch-pipeline-card" data-lead="<?php echo (int) $lead['id']; ?>" draggable="true"><strong><?php echo esc_html( (string) $lead['name'] ); ?></strong><?php if ( $lead['phone'] ) : ?><div class="estat-stitch-muted" style="font-size:11px;margin-top:4px"><a href="tel:<?php echo esc_attr( $lead['phone'] ); ?>"><?php echo esc_html( $lead['phone'] ); ?></a></div><?php endif; ?><?php if ( $lead['message'] ) : ?><div class="estat-stitch-muted" style="font-size:11px;margin-top:6px"><?php echo esc_html( mb_substr( (string) $lead['message'], 0, 60 ) ); ?></div><?php endif; ?><div style="margin-top:8px"><a class="estat-stitch-btn small" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries&lead_id=' . $lead['id'] ) ); ?>"><?php esc_html_e( 'Open', 'estat-os' ); ?></a></div></div><?php endforeach; endif; ?></div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
