<?php
/**
 * Today — Stitch Mayfair Atelier redesign.
 * Real data only, no fake portfolio volume.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Worklist;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class TodayNew {

	private static function greeting_name( $user ): string {
		$first = isset( $user->first_name ) ? trim( (string) $user->first_name ) : '';
		if ( '' !== $first ) { return $first; }
		$display = isset( $user->display_name ) ? trim( (string) $user->display_name ) : '';
		return '' !== $display ? $display : __( 'there', 'estat-os' );
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see the office dashboard.', 'estat-os' ) );
		}

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		$user = wp_get_current_user();
		$listings = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $listings['publish'] ?? 0 );
		$drafts = (int) ( $listings['draft'] ?? 0 );
		$leads_counts = Leads::counts();
		$visits_counts = Visits::counts();
		$new_enquiries = (int) ( $leads_counts['new'] ?? 0 );
		$visits_today = (int) ( $visits_counts['today'] ?? 0 );
		$s = Settings::all();
		$city = (string) ( $s['city'] ?? $s['cities'][0] ?? '' );
		$office_name = (string) ( $s['office_name'] ?? '' );

		$worklist = Worklist::all();
		$recent_leads = Leads::query( array( 'per_page'=>2, 'page'=>1, 'status'=>'new' ) );
		$today_visits = Visits::query( array( 'per_page'=>3, 'page'=>1, 'date'=>'today' ) );
		$recent_listings_q = new \WP_Query( array( 'post_type'=>PostTypes::LISTING, 'post_status'=>array('publish','draft'), 'posts_per_page'=>3, 'orderby'=>'modified', 'order'=>'DESC' ) );

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header is-today">
				<div class="estat-stitch-breadcrumb">
					<span class="estat-stitch-dot-accent"></span>
					<?php esc_html_e( "Today's overview", 'estat-os' ); ?>
				</div>
				<div class="estat-stitch-header-row">
					<div>
						<h1 class="estat-stitch-h1"><?php esc_html_e( 'Today', 'estat-os' ); ?></h1>
						<p class="estat-stitch-desc"><?php printf( esc_html__( 'Good day, %s. A quick view of what needs attention today across active mandates and enquiries.', 'estat-os' ), esc_html( self::greeting_name( $user ) ) ); ?><?php if ( '' !== $office_name ) { echo ' ' . esc_html( $office_name ); } ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-stitch-header-actions">
						<?php echo NewUI::toggle_markup(); // phpcs:ignore ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">tune</span> <?php esc_html_e( 'Filter view', 'estat-os' ); ?></a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add a home', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-stitch-metrics">
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Active mandates', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $live ); ?></span><span class="estat-stitch-metric-sub"><?php esc_html_e( 'Live on website', 'estat-os' ); ?></span></div>
					<span class="estat-stitch-metric-hint"><?php esc_html_e( 'Consolidated portfolio', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Scheduled today', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $visits_today ); ?></span><span class="estat-stitch-badge"><?php esc_html_e( 'Viewings', 'estat-os' ); ?></span></div>
					<span class="estat-stitch-metric-hint"><?php esc_html_e( 'Next visits', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Enquiries awaiting', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $new_enquiries ); ?></span><span class="estat-stitch-badge is-alert"><?php esc_html_e( 'New', 'estat-os' ); ?></span></div>
					<span class="estat-stitch-metric-hint"><?php esc_html_e( 'Awaiting allocation', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Pending review', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $drafts ); ?></span><span class="estat-stitch-metric-sub"><?php esc_html_e( 'Draft listings', 'estat-os' ); ?></span></div>
					<span class="estat-stitch-metric-hint"><?php esc_html_e( 'Awaiting signoff', 'estat-os' ); ?></span>
				</div>
			</div>

			<div class="estat-stitch-today-grid">
				<div class="estat-stitch-today-main">
					<?php if ( ! empty( $worklist ) ) : ?>
					<div class="estat-stitch-card-panel">
						<div class="estat-stitch-panel-header">
							<span class="material-symbols-outlined">priority_high</span>
							<h2><?php esc_html_e( 'Needs attention', 'estat-os' ); ?></h2>
							<span class="estat-stitch-badge"><?php echo esc_html( sprintf( __( '%d critical items', 'estat-os' ), count( $worklist ) ) ); ?></span>
						</div>
						<div class="estat-stitch-list">
							<?php foreach ( $worklist as $item ) : ?>
							<div class="estat-stitch-list-item">
								<span class="estat-stitch-list-icon"><span class="material-symbols-outlined">description</span></span>
								<div class="estat-stitch-list-body">
									<h3><?php echo esc_html( $item['label'] ?? '' ); ?></h3>
									<p><?php echo esc_html( $item['hint'] ?? '' ); ?></p>
								</div>
								<a href="<?php echo esc_url( $item['url'] ?? '#' ); ?>" class="estat-stitch-btn"><?php echo esc_html( $item['action'] ?? __( 'Open', 'estat-os' ) ); ?></a>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
					<?php endif; ?>

					<div class="estat-stitch-card-panel">
						<div class="estat-stitch-panel-header">
							<span class="material-symbols-outlined">calendar_today</span>
							<h2><?php esc_html_e( "Today's visits", 'estat-os' ); ?></h2>
							<span class="estat-stitch-muted"><?php echo esc_html( sprintf( __( '%d remaining', 'estat-os' ), $visits_today ) ); ?></span>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-visits' ) ); ?>" class="estat-stitch-link"><?php esc_html_e( 'View full diary', 'estat-os' ); ?> <span class="material-symbols-outlined">arrow_forward</span></a>
						</div>
						<div class="estat-stitch-list">
							<?php if ( empty( $today_visits['items'] ) ) : ?>
								<p class="estat-stitch-muted" style="padding:16px"><?php esc_html_e( 'No visits scheduled for today.', 'estat-os' ); ?></p>
							<?php else : foreach ( $today_visits['items'] as $visit ) : ?>
							<div class="estat-stitch-list-item is-visit">
								<div class="estat-stitch-time"><span class="estat-stitch-time-h"><?php echo esc_html( substr( (string) ( $visit['scheduled_at'] ?? '' ), 11, 5 ) ?: '—' ); ?></span></div>
								<div class="estat-stitch-list-body">
									<h3><?php echo esc_html( $visit['listing_title'] ?? (string) ( $visit['listing_id'] ?? '' ) ); ?></h3>
									<div class="estat-stitch-visit-meta"><span><?php esc_html_e( 'Visitor:', 'estat-os' ); ?> <?php echo esc_html( $visit['lead_name'] ?? '' ); ?></span><span><?php esc_html_e( 'Accompanied by:', 'estat-os' ); ?> <?php echo esc_html( $visit['agent_name'] ?? '' ); ?></span></div>
								</div>
								<span class="estat-stitch-status is-publish"><span class="estat-stitch-dot"></span> <?php echo esc_html( $visit['outcome'] ?? __( 'Confirmed', 'estat-os' ) ); ?></span>
							</div>
							<?php endforeach; endif; ?>
						</div>
					</div>
				</div>

				<div class="estat-stitch-today-side">
					<div class="estat-stitch-card-panel">
						<div class="estat-stitch-panel-header">
							<span class="material-symbols-outlined">inbox</span>
							<h2><?php esc_html_e( 'Recent enquiries', 'estat-os' ); ?></h2>
							<span class="estat-stitch-muted"><?php echo esc_html( sprintf( __( '%d pending', 'estat-os' ), $new_enquiries ) ); ?></span>
						</div>
						<div class="estat-stitch-list">
							<?php if ( empty( $recent_leads['items'] ) ) : ?>
								<p class="estat-stitch-muted" style="padding:16px"><?php esc_html_e( 'No recent enquiries.', 'estat-os' ); ?></p>
							<?php else : foreach ( $recent_leads['items'] as $lead ) : ?>
							<div class="estat-stitch-enquiry">
								<div class="estat-stitch-enquiry-head"><span class="estat-stitch-enquiry-name"><?php echo esc_html( $lead['name'] ?? '' ); ?></span><span class="estat-stitch-muted"><?php echo esc_html( $lead['created_at'] ?? '' ); ?></span></div>
								<div class="estat-stitch-enquiry-prop"><span class="material-symbols-outlined">apartment</span> <?php echo esc_html( $lead['listing_title'] ?? '' ); ?></div>
								<?php if ( ! empty( $lead['message'] ) ) : ?><div class="estat-stitch-enquiry-msg">“<?php echo esc_html( mb_substr( (string) $lead['message'], 0, 80 ) ); ?>”</div><?php endif; ?>
								<div class="estat-stitch-enquiry-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries&lead_id=' . $lead['id'] ) ); ?>" class="estat-stitch-btn small"><span class="material-symbols-outlined">visibility</span> <?php esc_html_e( 'Review', 'estat-os' ); ?></a></div>
							</div>
							<?php endforeach; endif; ?>
						</div>
					</div>

					<div class="estat-stitch-card-panel">
						<div class="estat-stitch-panel-header">
							<span class="material-symbols-outlined">update</span>
							<h2><?php esc_html_e( 'Recently updated listings', 'estat-os' ); ?></h2>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-stitch-link"><?php esc_html_e( 'All listings', 'estat-os' ); ?></a>
						</div>
						<div class="estat-stitch-list">
							<?php while ( $recent_listings_q->have_posts() ) : $recent_listings_q->the_post(); $id = get_the_ID(); ?>
							<div class="estat-stitch-list-item small">
								<div class="estat-stitch-list-body">
									<h3><?php echo esc_html( get_the_title() ); ?></h3>
									<p><?php esc_html_e( 'Updated', 'estat-os' ); ?> <?php echo esc_html( get_the_modified_date() ); ?></p>
								</div>
								<span class="estat-stitch-badge"><?php echo esc_html( get_post_status() ); ?></span>
							</div>
							<?php endwhile; wp_reset_postdata(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
