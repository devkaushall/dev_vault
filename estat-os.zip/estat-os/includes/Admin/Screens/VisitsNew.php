<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;
defined( 'ABSPATH' ) || exit;
final class VisitsNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_visits' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$outcome = isset( $_GET['outcome'] ) ? sanitize_key( wp_unslash( is_array($_GET['outcome']) ? '' : $_GET['outcome'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$results = Visits::query( array( 'outcome'=>$outcome,'page'=>$paged,'per_page'=>20 ) );
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' );
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Visits</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Site Visits', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d visits', 'estat-os' ), (int) $results['total'] ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-enquiries'=>__( 'Inbox', 'estat-os' ),'estat-pipeline'=>__( 'Pipeline', 'estat-os' ),'estat-visits'=>__( 'Site Visits', 'estat-os' ),'estat-requests'=>__( 'Change Requests', 'estat-os' ),'estat-search-alerts'=>__( 'Search Alerts', 'estat-os' ),'estat-forms'=>__( 'Forms', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-visits' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-controls"><div class="estat-stitch-filters"><form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-filters-form"><input type="hidden" name="page" value="estat-visits" /><select name="outcome"><option value=""><?php esc_html_e( 'All visits', 'estat-os' ); ?></option><?php foreach ( Vocabulary::visit_outcomes() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $outcome, $k ); ?>><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select><button type="submit" class="estat-stitch-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button></form></div></div>
			<?php if ( empty( $results['items'] ) ) : ?><div class="estat-stitch-card-panel"><p class="estat-stitch-muted"><?php esc_html_e( 'No site visits booked.', 'estat-os' ); ?></p></div><?php else : ?><div class="estat-stitch-table-wrap"><div class="estat-stitch-table-scroll"><table class="estat-stitch-table"><thead><tr><th><?php esc_html_e( 'When', 'estat-os' ); ?></th><th><?php esc_html_e( 'Who', 'estat-os' ); ?></th><th><?php esc_html_e( 'Property', 'estat-os' ); ?></th><th><?php esc_html_e( 'Outcome', 'estat-os' ); ?></th></tr></thead><tbody><?php foreach ( $results['items'] as $visit ) : ?><tr><td><?php echo esc_html( $visit['scheduled_at'] ?? '' ); ?></td><td><?php echo esc_html( $visit['lead_name'] ?? '' ); ?></td><td><?php echo esc_html( $visit['listing_title'] ?? (string) ( $visit['listing_id'] ?? '' ) ); ?></td><td><span class="estat-stitch-status is-<?php echo esc_attr( $visit['outcome'] ?? '' ); ?>"><?php echo esc_html( $visit['outcome'] ?? '' ); ?></span></td></tr><?php endforeach; ?></tbody></table></div></div><?php endif; ?>
		</div>
		<?php
	}
}
