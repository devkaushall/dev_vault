<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Search\Alerts;
use EstatOS\Settings\Settings;
defined( 'ABSPATH' ) || exit;
final class SearchAlertsNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$results = Alerts::query( array( 'page'=>$paged, 'per_page'=>20 ) );
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' );
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Search Alerts</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Search Alerts', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d alerts', 'estat-os' ), (int) $results['total'] ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-enquiries'=>__( 'Inbox', 'estat-os' ),'estat-pipeline'=>__( 'Pipeline', 'estat-os' ),'estat-visits'=>__( 'Site Visits', 'estat-os' ),'estat-requests'=>__( 'Change Requests', 'estat-os' ),'estat-search-alerts'=>__( 'Search Alerts', 'estat-os' ),'estat-forms'=>__( 'Forms', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-search-alerts' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-table-wrap"><div class="estat-stitch-table-scroll"><table class="estat-stitch-table"><thead><tr><th><?php esc_html_e( 'Email', 'estat-os' ); ?></th><th><?php esc_html_e( 'Filters', 'estat-os' ); ?></th><th><?php esc_html_e( 'Frequency', 'estat-os' ); ?></th><th><?php esc_html_e( 'Confirmed', 'estat-os' ); ?></th><th><?php esc_html_e( 'Created', 'estat-os' ); ?></th></tr></thead><tbody><?php foreach ( $results['items'] as $alert ) : ?><tr><td><?php echo esc_html( $alert['email'] ?? '' ); ?></td><td class="estat-stitch-muted" style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html( is_array( $alert['filters'] ?? null ) ? wp_json_encode( $alert['filters'] ) : (string) ( $alert['query'] ?? '' ) ); ?></td><td><?php echo esc_html( $alert['frequency'] ?? '' ); ?></td><td><span class="estat-stitch-status is-<?php echo ! empty( $alert['confirmed'] ) ? 'publish' : 'draft'; ?>"><?php echo ! empty( $alert['confirmed'] ) ? __( 'Yes', 'estat-os' ) : __( 'No', 'estat-os' ); ?></span></td><td class="estat-stitch-date"><?php echo esc_html( $alert['created_at'] ?? '' ); ?></td></tr><?php endforeach; ?></tbody></table></div></div>
		</div>
		<?php
	}
}
