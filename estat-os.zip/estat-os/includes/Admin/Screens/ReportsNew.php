<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;
defined( 'ABSPATH' ) || exit;
final class ReportsNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_view_reports' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' ); $counts = (array) wp_count_posts( PostTypes::LISTING ); $live = (int) ( $counts['publish'] ?? 0 ); $draft = (int) ( $counts['draft'] ?? 0 ); $leads = Leads::counts();
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Reports</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Reports', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php esc_html_e( 'Operational overview of listings, leads and team workload.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-team'=>__( 'Team', 'estat-os' ),'estat-reports'=>__( 'Reports', 'estat-os' ),'estat-insights'=>__( 'Insights', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-reports' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-metrics"><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Live listings', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $live ); ?></span></div></div><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Drafts', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $draft ); ?></span></div></div><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'New leads', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) ( $leads['new'] ?? 0 ) ); ?></span></div></div><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Won', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num is-accent"><?php echo esc_html( (string) ( $leads['won'] ?? 0 ) ); ?></span></div></div></div>
			<div class="estat-stitch-card-panel"><div class="estat-stitch-panel-header"><span class="material-symbols-outlined">bar_chart</span><h2><?php esc_html_e( 'Lead pipeline', 'estat-os' ); ?></h2></div><div class="estat-stitch-detail-grid"><?php foreach ( array('new','contacted','scheduled','won','lost') as $k ) : ?><div><span class="estat-stitch-metric-label"><?php echo esc_html( ucfirst( $k ) ); ?></span><br><span class="estat-stitch-metric-num"><?php echo esc_html( (string) ( $leads[ $k ] ?? 0 ) ); ?></span></div><?php endforeach; ?></div></div>
		</div>
		<?php
	}
}
