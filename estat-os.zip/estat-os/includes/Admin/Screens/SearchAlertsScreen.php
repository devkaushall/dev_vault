<?php
/**
 * Search Alerts admin screen — F4 upgraded.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Search\Alerts;

defined( 'ABSPATH' ) || exit;

final class SearchAlertsScreen {

	/**
	 * Render.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		// Handle delete.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['estat_delete_alert'] ) ) {
			$id = absint( wp_unslash( is_array($_GET['estat_delete_alert']) ? '' : $_GET['estat_delete_alert'] ) );
			$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( is_array($_GET['source']) ? '' : $_GET['source'] ) ) : 'new';
			if ( $id ) {
				check_admin_referer( 'estat_delete_alert_' . $id );
				Alerts::delete( $id, 'legacy' === $source ? 'legacy' : 'new' );
				echo '<div class="notice notice-success"><p>' . esc_html__( 'Alert deleted.', 'estat-os' ) . '</p></div>';
			}
		}

		$data = Alerts::query();

		echo '<div class="wrap estat-admin">';
		echo '<h1>' . esc_html__( 'Search Alerts — Watch & Notify (F4)', 'estat-os' ) . '</h1>';
		echo '<p class="estat-muted">' . esc_html__( 'F4: Visitors watch a search (e.g. 3BHK in Saket under 2Cr). Instant alerts email when matching listing goes live; daily alerts send digest via daily cron. Confirm via email token, unsubscribe anytime. Both estat_alerts (F4) and legacy estat_search_alerts shown.', 'estat-os' ) . '</p>';
		echo '<p><strong>New:</strong> ' . (int) $data['new_total'] . ' | Legacy: ' . (int) $data['old_total'] . ' | Total: ' . (int) $data['total'] . '</p>';

		if ( ! $data['items'] ) {
			Partials::empty_state(
				array(
					'title'   => __( 'No alerts yet', 'estat-os' ),
					'message' => __( 'When visitors save a search, their alert appears here. You can see who is watching what.', 'estat-os' ),
					'icon'    => 'bell',
				)
			);
			echo '</div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>Email</th><th>Name/Phone</th><th>Freq</th><th>Filters (summary)</th><th>Confirmed</th><th>Last Sent</th><th>Source</th><th>Actions</th>';
		echo '</tr></thead><tbody>';
		foreach ( $data['items'] as $row ) {
			$filters = json_decode( (string) $row['filters'], true );
			$summary = '';
			if ( is_array( $filters ) ) {
				$bits = array();
				foreach ( array( 'property_type', 'offer', 'bedrooms_min', 'bedrooms_max', 'price_min', 'price_max', 'locality', 'furnishing', 'verified', 'frequency' ) as $k ) {
					if ( isset( $filters[ $k ] ) && '' !== (string) $filters[ $k ] && array() !== $filters[ $k ] && 0 !== $filters[ $k ] && false !== $filters[ $k ] ) {
						$v = $filters[ $k ];
						if ( is_array( $v ) ) { $v = implode( '/', array_slice( $v, 0, 3 ) ); }
						if ( '' === (string) $v || '0' === (string) $v ) { continue; }
						$bits[] = $k . ':' . mb_substr( (string) $v, 0, 30 );
					}
				}
				$summary = implode( ', ', $bits );
			}
			$confirm = $row['confirmed'] ? '<span style="color:#10b981">Yes</span>' : '<span style="color:#f59e0b">No</span>';
			if ( ! empty( $row['unsubscribed'] ) ) {
				$confirm .= ' <span style="color:#ef4444">(unsub)</span>';
			}
			$del_url = wp_nonce_url( add_query_arg( array( 'page' => 'estat-search-alerts', 'estat_delete_alert' => $row['id'], 'source' => 'legacy' === $row['source'] ? 'legacy' : 'new' ), admin_url( 'admin.php' ) ), 'estat_delete_alert_' . $row['id'] );

			echo '<tr>';
			echo '<td>' . (int) $row['id'] . '</td>';
			echo '<td>' . esc_html( $row['email'] ) . '</td>';
			echo '<td>' . esc_html( $row['name'] ) . ( ! empty( $row['phone'] ) ? '<br>' . esc_html( $row['phone'] ) : '' ) . '</td>';
			echo '<td>' . esc_html( $row['frequency'] ?? 'instant' ) . '</td>';
			echo '<td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' . esc_attr( (string) $row['filters'] ) . '">' . esc_html( $summary ) . '</td>';
			echo '<td>' . $confirm . '</td>';
			echo '<td>' . esc_html( $row['last_sent_at'] ?? '' ) . ( ! empty( $row['send_count'] ) ? ' (' . (int) $row['send_count'] . ')' : '' ) . '</td>';
			echo '<td>' . esc_html( $row['source'] ) . '</td>';
			echo '<td><a href="' . esc_url( $del_url ) . '" onclick="return confirm(\'Delete?\')" class="button button-small">Delete</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<h2 style="margin-top:24px">' . esc_html__( 'How it works (F4)', 'estat-os' ) . '</h2>';
		echo '<ol>';
		echo '<li>' . esc_html__( 'Search page: Watch this search button opens form (name/email/phone/frequency instant|daily). JS captures URLSearchParams as filters and POSTs to /wp-json/estat/v1/alerts', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'REST creates row in estat_alerts with query json, token, frequency. Sends confirmation email with ?estat_confirm_alert_v2=token', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'Confirm sets confirmed=1. Unsubscribe via ?estat_unsubscribe_alert=token sets unsubscribed_at', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'On listing publish/verify: instant alerts matched via matches() (23 filters) and email sent with verified badge, share/print links, unsubscribe link', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'Daily cron estat_daily_housekeeping calls process_queue() — finds listings in last 24h, matches daily alerts, sends digest (up to 10)', 'estat-os' ) . '</li>';
		echo '</ol>';

		echo '</div>';
	}
}
