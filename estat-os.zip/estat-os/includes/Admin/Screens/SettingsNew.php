<?php
/**
 * Office Settings — Mayfair Phase 1 grouped cards behind per-user switch.
 * 6 groups: Office overview, General, Listings & workflow, Leads & enquiries, Integrations, Advanced
 * All existing functionality accessible: Pages, Search filters, Emails, logo, tagline, cities.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class SettingsNew {

	private static function groups(): array {
		return array(
			'overview' => array(
				'label' => __( 'Office overview', 'estat-os' ),
				'desc'  => __( 'A simple overview of the office, including key information, setup status, and basic configuration.', 'estat-os' ),
				'icon'  => 'office',
			),
			'general' => array(
				'label' => __( 'General', 'estat-os' ),
				'desc'  => __( 'Office name, contact details, address, currency, number format, language, and other basic preferences.', 'estat-os' ),
				'icon'  => 'form',
			),
			'listings' => array(
				'label' => __( 'Listings & workflow', 'estat-os' ),
				'desc'  => __( 'Default listing settings, availability rules, expiry settings, verification options, and other controls related to managing properties.', 'estat-os' ),
				'icon'  => 'home',
			),
			'leads' => array(
				'label' => __( 'Leads & enquiries', 'estat-os' ),
				'desc'  => __( 'Enquiry preferences, notification email, lead handling, form behaviour, and related communication settings.', 'estat-os' ),
				'icon'  => 'inbox',
			),
			'integrations' => array(
				'label' => __( 'Integrations', 'estat-os' ),
				'desc'  => __( 'Maps, webhooks, API keys, and other external service connections.', 'estat-os' ),
				'icon'  => 'compass',
			),
			'advanced' => array(
				'label' => __( 'Advanced', 'estat-os' ),
				'desc'  => __( 'Less frequently used options such as data retention, debugging, practice mode, and technical settings.', 'estat-os' ),
				'icon'  => 'filter',
			),
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to change office settings.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( is_array($_GET['tab']) ? '' : $_GET['tab'] ) ) : 'overview';
		$groups = self::groups();

		// Fix broken link: tab=tools should show Advanced with Tools section, not redirect to overview.
		if ( 'tools' === $tab ) {
			$tab = 'advanced';
			// Set flag to scroll to tools.
			$_GET['estat_scroll'] = 'tools';
		}

		if ( ! isset( $groups[ $tab ] ) ) {
			$tab = 'overview';
		}
		$s = Settings::all();

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Office</span><span>/</span><span class="is-muted"><?php echo esc_html( $groups[ $tab ]['label'] ); ?></span></div>
				<div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Office Settings', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php esc_html_e( 'Configure your office in clear groups. All existing functionality remains accessible.', 'estat-os' ); ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><?php if ( 'overview' !== $tab ) : ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=overview' ) ); ?>" class="estat-stitch-btn"><?php esc_html_e( 'All groups', 'estat-os' ); ?></a><?php endif; ?></div></div>
			</div>

		<?php if ( 'overview' === $tab ) : ?>
			<?php self::render_overview( $groups, $s ); ?>
		<?php else : ?>
			<div class="estat-settings-layout">
				<nav class="estat-settings-nav" aria-label="<?php esc_attr_e( 'Settings groups', 'estat-os' ); ?>">
					<?php foreach ( $groups as $key => $g ) : $active = $key === $tab; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $key ) ); ?>" class="<?php echo $active ? 'is-active' : ''; ?>">
						<span class="estat-settings-nav-item">
							<span class="estat-settings-nav-icon"><?php echo Icon::render( $g['icon'], 18 ); // phpcs:ignore ?></span>
							<span><?php echo esc_html( $g['label'] ); ?></span>
						</span>
					</a>
					<?php endforeach; ?>
				</nav>
				<div class="estat-settings-content">
					<div class="estat-settings-header">
						<div>
							<h2 class="estat-section-title"><?php echo esc_html( $groups[ $tab ]['label'] ); ?></h2>
							<p class="description"><?php echo esc_html( $groups[ $tab ]['desc'] ); ?></p>
						</div>
					</div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $tab ) ); ?>" class="estat-settings-form">
						<?php wp_nonce_field( 'estat_save_settings', 'estat_nonce' ); ?>
						<input type="hidden" name="estat_action" value="save_settings" />
						<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" />
						<?php
						switch ( $tab ) {
							case 'general': self::general( $s ); break;
							case 'listings': self::listings( $s ); break;
							case 'leads': self::leads( $s ); break;
							case 'integrations': self::integrations( $s ); break;
							case 'advanced': self::advanced( $s ); break;
							default: self::overview_details( $s ); break;
						}
						?>
						<div class="estat-form-actions">
							<button type="submit" class="button button-primary"><?php esc_html_e( 'Save changes', 'estat-os' ); ?></button>
						</div>
					</form>
				</div>
			</div>
		<?php endif; ?>
		</div>
		<?php
	}

	private static function render_overview( array $groups, array $s ): void {
		$counts = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $counts['publish'] ?? 0 );
		$office_name = (string) ( $s['office_name'] ?? '' );
		$city = (string) ( $s['city'] ?? '' );
		if ( '' === $city && isset( $s['cities'][0] ) ) {
			$city = (string) $s['cities'][0];
		}
		$setup_needed = \EstatOS\Admin\Screens\SetupScreen::needed();
		?>
		<div class="estat-settings-overview">
			<div class="estat-settings-cards">
				<?php foreach ( $groups as $key => $g ) : if ( 'overview' === $key ) continue; ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $key ) ); ?>" class="estat-settings-card-link">
					<div class="estat-card-panel estat-settings-card">
						<span class="estat-settings-card-icon"><?php echo Icon::render( $g['icon'], 20 ); // phpcs:ignore ?></span>
						<span class="estat-settings-card-body">
							<span class="estat-settings-card-title"><?php echo esc_html( $g['label'] ); ?></span>
							<span class="estat-settings-card-desc"><?php echo esc_html( $g['desc'] ); ?></span>
							<span class="estat-settings-card-open"><?php esc_html_e( 'Open', 'estat-os' ); ?> →</span>
						</span>
					</div>
				</a>
				<?php endforeach; ?>
			</div>
			<div class="estat-settings-overview-side">
				<div class="estat-card-panel">
					<h3 class="estat-section-title-sm"><?php esc_html_e( 'Office overview', 'estat-os' ); ?></h3>
					<div class="estat-overview-list">
						<?php if ( '' !== $office_name ) : ?><div><strong><?php esc_html_e( 'Office', 'estat-os' ); ?>:</strong> <?php echo esc_html( $office_name ); ?></div><?php endif; ?>
						<?php if ( '' !== $city ) : ?><div><strong><?php esc_html_e( 'City', 'estat-os' ); ?>:</strong> <?php echo esc_html( $city ); ?></div><?php endif; ?>
						<div><strong><?php esc_html_e( 'Live listings', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $live ); ?></div>
						<div class="estat-overview-status">
							<?php if ( $setup_needed ) : ?>
								<span class="estat-pill is-warn"><?php esc_html_e( 'Setup needed', 'estat-os' ); ?></span>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-setup' ) ); ?>" class="button button-small"><?php esc_html_e( 'Finish setup', 'estat-os' ); ?></a>
							<?php else : ?>
								<span class="estat-pill is-good"><?php esc_html_e( 'Setup complete', 'estat-os' ); ?></span>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="estat-card-panel estat-mt">
					<h4 class="estat-section-title-sm"><?php esc_html_e( 'Quick links', 'estat-os' ); ?></h4>
					<ul class="estat-quick-links">
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>"><?php esc_html_e( 'Listings', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>"><?php esc_html_e( 'Enquiries', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-projects' ) ); ?>"><?php esc_html_e( 'Projects', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ); ?>"><?php esc_html_e( 'Spreadsheet', 'estat-os' ); ?></a></li>
					</ul>
					<h4 class="estat-section-title-sm" style="margin-top:16px"><?php esc_html_e( 'More screens — hidden from 8-item menu, reachable here', 'estat-os' ); ?></h4>
					<p class="description" style="margin:4px 0 8px"><?php esc_html_e( 'Stitch simplified menu shows 8 items. Other screens are grouped as tabs inside Enquiries, Team and Office.', 'estat-os' ); ?></p>
					<ul class="estat-quick-links">
						<li><strong><?php esc_html_e( 'Leads & enquiries tabs', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>"><?php esc_html_e( 'Inbox', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-pipeline' ) ); ?>"><?php esc_html_e( 'Pipeline', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-visits' ) ); ?>"><?php esc_html_e( 'Visits', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-requests' ) ); ?>"><?php esc_html_e( 'Requests', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-search-alerts' ) ); ?>"><?php esc_html_e( 'Search Alerts', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>"><?php esc_html_e( 'Forms', 'estat-os' ); ?></a></li>
						<li><strong><?php esc_html_e( 'Team tabs', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-reports' ) ); ?>"><?php esc_html_e( 'Reports', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-insights' ) ); ?>"><?php esc_html_e( 'Insights', 'estat-os' ); ?></a></li>
						<li><strong><?php esc_html_e( 'Office tabs', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings' ) ); ?>"><?php esc_html_e( 'Office Settings', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-gallery' ) ); ?>"><?php esc_html_e( 'Gallery & Media', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-templates' ) ); ?>"><?php esc_html_e( 'Templates', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-design-tokens' ) ); ?>"><?php esc_html_e( 'Design Tokens', 'estat-os' ); ?></a></li>
					</ul>
				</div>
			</div>
		</div>
		<?php
	}

	private static function overview_details( array $s ): void {
		echo '<div class="estat-card-panel"><p class="description">' . esc_html__( 'Overview details are shown on the main groups page.', 'estat-os' ) . '</p></div>';
	}

	private static function general( array $s ): void {
		$cities_value = is_array( $s['cities'] ?? null ) ? implode( ', ', $s['cities'] ) : (string) ( $s['cities'] ?? '' );
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Office profile', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'office_name', __( 'Office name', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'tagline', __( 'Tagline / One line about the office', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'contact_person', __( 'Contact person', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'logo_id', __( 'Office logo', 'estat-os' ), $s, 'image' ); ?>
				<?php self::field( 'address', __( 'Office address', 'estat-os' ), $s, 'textarea' ); ?>
				<?php self::field( 'office_hours', __( 'Office hours', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'phone', __( 'Phone', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'whatsapp', __( 'WhatsApp', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'email', __( 'Contact email', 'estat-os' ), $s, 'email' ); ?>
				<?php self::field( 'cities', __( 'Cities you work in (comma separated)', 'estat-os' ), array( 'cities' => $cities_value ), 'text' ); ?>
			</div>
		</div>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Locale & format', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-3">
				<?php self::field( 'country', __( 'Country', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'city', __( 'Primary city', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'currency', __( 'Currency', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'currency_symbol', __( 'Currency symbol', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'price_format', __( 'Price format', 'estat-os' ), $s, 'select', array( 'indian'=>__( 'Indian', 'estat-os' ), 'international'=>__( 'International', 'estat-os' ), 'compact'=>__( 'Compact', 'estat-os' ), 'plain'=>__( 'Plain', 'estat-os' ) ) ); ?>
				<?php self::field( 'default_area_unit', __( 'Default area unit', 'estat-os' ), $s, 'select', Vocabulary::area_units() ); ?>
				<?php self::field( 'language', __( 'Language', 'estat-os' ), $s, 'select', array( 'auto'=>__( 'Auto', 'estat-os' ), 'en'=>__( 'English', 'estat-os' ), 'hi'=>__( 'Hindi', 'estat-os' ) ) ); ?>
				<?php self::field( 'frontend_language', __( 'Frontend language', 'estat-os' ), $s, 'select', array( 'auto'=>__( 'Auto', 'estat-os' ), 'en'=>__( 'English', 'estat-os' ), 'hi'=>__( 'Hindi', 'estat-os' ) ) ); ?>
			</div>
		</div>
		<?php
	}

	private static function listings( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Website & listings', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'listings_per_page', __( 'Listings per page', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field_checkbox( 'enable_favorites', __( 'Enable favorites', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'enable_compare', __( 'Enable compare', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'enable_schema', __( 'Enable schema', 'estat-os' ), $s ); ?>
				<?php self::field( 'verification_mode', __( 'Verification mode', 'estat-os' ), $s, 'select', array( 'optional'=>__( 'Optional', 'estat-os' ), 'required'=>__( 'Required', 'estat-os' ), 'off'=>__( 'Off', 'estat-os' ) ) ); ?>
				<?php self::field( 'listing_expiry_days', __( 'Listing expiry days (0 = never)', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'regulatory_label', __( 'Regulatory label', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field_checkbox( 'show_regulatory', __( 'Show regulatory info', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'share_enabled', __( 'Share row (WhatsApp / Copy / Print)', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'print_enabled', __( 'Print page', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'emi_enabled', __( 'EMI calculator', 'estat-os' ), $s ); ?>
				<?php self::field( 'emi_default_rate', __( 'EMI default rate %', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'emi_default_years', __( 'EMI default years', 'estat-os' ), $s, 'number' ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Helper pages — archive mapping (3.0.7 fix)', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Pages are created as drafts and need a click to publish. This preserves the 3.0.7 fix for archive page mapping.', 'estat-os' ); ?></p>
			<div class="estat-pages-list">
				<?php echo \EstatOS\Frontend\Pages::admin_list_html(); // phpcs:ignore ?>
			</div>
			<div class="estat-field-actions">
				<?php
				$url = admin_url( 'admin.php?page=estat-settings&tab=listings' );
				echo '<form method="post" class="estat-inline-form" action="' . esc_url( $url ) . '">';
				wp_nonce_field( 'estat_tool_create_public_pages', 'estat_nonce' );
				echo '<input type="hidden" name="estat_action" value="create_public_pages" />';
				echo '<button type="submit" class="button">' . esc_html__( 'Create helper pages as drafts', 'estat-os' ) . '</button>';
				echo '</form>';
				?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Search filters — which filters show on website', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Choose which filters appear and drag to reorder. Visitors only see enabled ones.', 'estat-os' ); ?></p>
			<?php self::filters_block( $s ); ?>
		</div>
		<?php
	}

	private static function filters_block( array $s ): void {
		$enabled = is_array( $s['enabled_filters'] ?? null ) ? $s['enabled_filters'] : array_keys( Vocabulary::all_filters() );
		$order   = is_array( $s['filter_order'] ?? null ) ? $s['filter_order'] : array_keys( Vocabulary::all_filters() );
		$all     = Vocabulary::all_filters();
		foreach ( array_keys( $all ) as $k ) {
			if ( ! in_array( $k, $order, true ) ) {
				$order[] = $k;
			}
		}
		$order = array_values( array_intersect( $order, array_keys( $all ) ) );
		?>
		<div class="estat-filters-toolbar">
			<button type="button" class="button" id="estat-filters-enable-all"><?php esc_html_e( 'Enable all', 'estat-os' ); ?></button>
			<button type="button" class="button" id="estat-filters-disable-all"><?php esc_html_e( 'Disable all', 'estat-os' ); ?></button>
			<button type="button" class="button" id="estat-filters-reset-order"><?php esc_html_e( 'Reset order', 'estat-os' ); ?></button>
		</div>
		<input type="hidden" name="settings[filter_order_csv]" id="estat-filter-order-csv" value="<?php echo esc_attr( implode( ',', $order ) ); ?>">
		<div id="estat-filters-list" class="estat-filters-list">
			<?php foreach ( $order as $key ) : if ( ! isset( $all[ $key ] ) ) continue; $info = $all[ $key ]; $checked = in_array( $key, $enabled, true ); $is_on = $checked ? 'is-on' : 'is-off'; ?>
			<div class="estat-filter-item <?php echo esc_attr( $is_on ); ?>" data-key="<?php echo esc_attr( $key ); ?>" draggable="true">
				<span class="estat-drag-handle">↕</span>
				<input type="checkbox" name="settings[enabled_filters][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $checked ); ?>>
				<span class="estat-filter-label"><strong><?php echo esc_html( $info['label'] ); ?></strong> <span class="estat-filter-meta"><?php echo esc_html( $key . ' · ' . $info['group'] ); ?></span></span>
				<span class="estat-filter-group"><?php echo esc_html( $info['group'] ); ?></span>
			</div>
			<?php endforeach; ?>
		</div>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const list = document.getElementById('estat-filters-list');
			const orderInput = document.getElementById('estat-filter-order-csv');
			if(!list || !orderInput) return;
			let dragEl = null;
			function updateOrder(){
				const keys = Array.from(list.querySelectorAll('.estat-filter-item')).map(el=>el.getAttribute('data-key'));
				orderInput.value = keys.join(',');
			}
			list.addEventListener('dragstart', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(!item) return;
				dragEl = item;
				e.dataTransfer.effectAllowed = 'move';
				item.style.opacity='0.5';
			});
			list.addEventListener('dragend', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(item) item.style.opacity='1';
				dragEl=null;
				updateOrder();
			});
			list.addEventListener('dragover', function(e){
				e.preventDefault();
				const target = e.target.closest('.estat-filter-item');
				if(!target || target===dragEl) return;
				const rect = target.getBoundingClientRect();
				const next = (e.clientY - rect.top) / (rect.height) > 0.5;
				if(next){ target.parentNode.insertBefore(dragEl, target.nextSibling); }else{ target.parentNode.insertBefore(dragEl, target); }
			});
			list.addEventListener('drop', function(e){ e.preventDefault(); updateOrder(); });
			const enAll = document.getElementById('estat-filters-enable-all');
			const disAll = document.getElementById('estat-filters-disable-all');
			const resetBtn = document.getElementById('estat-filters-reset-order');
			if(enAll) enAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=true); });
			if(disAll) disAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=false); });
			if(resetBtn) resetBtn.addEventListener('click', function(){
				const defaults = <?php echo wp_json_encode( array_keys( Vocabulary::all_filters() ) ); ?>;
				orderInput.value = defaults.join(',');
				const map = {};
				list.querySelectorAll('.estat-filter-item').forEach(el=>{ map[el.getAttribute('data-key')] = el; });
				defaults.forEach(k=>{ if(map[k]) list.appendChild(map[k]); });
			});
			list.addEventListener('change', function(e){
				if(e.target.type==='checkbox'){
					const item = e.target.closest('.estat-filter-item');
					if(item){ item.classList.toggle('is-on', e.target.checked); item.classList.toggle('is-off', !e.target.checked); }
				}
			});
		});
		</script>
		<?php
	}

	private static function leads( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Lead pipeline & assignment', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'lead_fallback_agent', __( 'Fallback agent', 'estat-os' ), $s, 'select', \EstatOS\Data\Picker::options( \EstatOS\Data\PostTypes::AGENT, __( '— No auto-assign —', 'estat-os' ) )['options'] ); ?>
				<?php self::field( 'retention_days', __( 'Auto-erase personal data after days', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'consent_text', __( 'Consent text', 'estat-os' ), $s, 'textarea' ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Enquiry preferences & notification email', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'notify_email', __( 'Notification email', 'estat-os' ), $s, 'email' ); ?>
				<?php self::field_checkbox( 'notify_new_lead', __( 'New enquiry', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_lead_status', __( 'Lead status changed', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_lead_assigned', __( 'Lead assigned', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_new_visit', __( 'Site visit booked', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_visit_completed', __( 'Visit completed', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_change_request', __( 'Change request', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_listing_published', __( 'Listing published', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_listing_verified', __( 'Listing verified', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_form_submitted', __( 'Form submitted', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_followup', __( 'Follow-up reminders', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_expiry', __( 'Retired listings', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_import', __( 'Finished imports', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_webhook_fail', __( 'Webhook failures', 'estat-os' ), $s ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Emails — templates', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Full Mayfair email templates — Phase 3. Subject and body for each event, with placeholders like {{name}}, {{phone}}, {{property}}.', 'estat-os' ); ?></p>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'email_from_name', __( 'From name', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'email_from_address', __( 'From address', 'estat-os' ), $s, 'email' ); ?>
				<?php self::field( 'email_footer_text', __( 'Footer text', 'estat-os' ), $s, 'textarea' ); ?>
			</div>

			<div class="estat-email-templates">
				<?php
				$email_events = array(
					'new_lead' => __( 'New enquiry', 'estat-os' ),
					'lead_assigned' => __( 'Lead assigned', 'estat-os' ),
					'new_visit' => __( 'Site visit booked', 'estat-os' ),
					'visit_completed' => __( 'Visit completed', 'estat-os' ),
					'listing_published' => __( 'Listing published', 'estat-os' ),
					'form_submitted' => __( 'Form submitted', 'estat-os' ),
				);
				foreach ( $email_events as $ev_key => $ev_label ) :
					$subj_key = 'email_subject_' . $ev_key;
					$body_key = 'email_body_' . $ev_key;
				?>
				<div class="estat-email-template">
					<h4 class="estat-email-template-title"><?php echo esc_html( $ev_label ); ?></h4>
					<div class="estat-field-grid estat-field-grid-2">
						<?php self::field( $subj_key, sprintf( __( '%s subject', 'estat-os' ), $ev_label ), $s, 'text' ); ?>
						<?php self::field( $body_key, sprintf( __( '%s body', 'estat-os' ), $ev_label ), $s, 'textarea' ); ?>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	private static function integrations( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Maps', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'map_provider', __( 'Map provider', 'estat-os' ), $s, 'select', array( 'osm'=>__( 'OpenStreetMap', 'estat-os' ), 'google'=>__( 'Google Maps', 'estat-os' ), 'none'=>__( 'None', 'estat-os' ) ) ); ?>
				<?php self::field( 'google_maps_key', __( 'Google Maps API key', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_lat', __( 'Default latitude', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_lng', __( 'Default longitude', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_zoom', __( 'Default zoom', 'estat-os' ), $s, 'number' ); ?>
			</div>
		</div>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Webhooks & API', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field_checkbox( 'webhook_enabled', __( 'Enable webhooks', 'estat-os' ), $s ); ?>
				<?php self::field( 'webhook_url', __( 'Primary webhook URL', 'estat-os' ), $s, 'url' ); ?>
				<?php self::field( 'webhook_url_2', __( 'Secondary webhook URL', 'estat-os' ), $s, 'url' ); ?>
				<?php self::field( 'webhook_secret', __( 'Webhook secret', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'webhook_version', __( 'Payload version', 'estat-os' ), $s, 'select', array( 'v1'=>__( 'v1', 'estat-os' ), 'v2'=>__( 'v2', 'estat-os' ) ) ); ?>
				<?php self::field( 'inbound_secret', __( 'Inbound secret', 'estat-os' ), $s, 'text' ); ?>
			</div>
		</div>
		<?php
	}

	private static function advanced( array $s ): void {
		$is_tools = isset( $_GET['estat_scroll'] ) && 'tools' === $_GET['estat_scroll'];
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Data & advanced', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'retention_days', __( 'Data retention days', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'admin_theme', __( 'Admin theme', 'estat-os' ), $s, 'select', array( 'light'=>__( 'Light', 'estat-os' ), 'dark'=>__( 'Dark', 'estat-os' ), 'auto'=>__( 'Auto', 'estat-os' ) ) ); ?>
				<?php self::field_checkbox( 'practice_mode', __( 'Practice mode', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'multi_agency', __( 'Multi-agency', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'delete_data_on_uninstall', __( 'Delete data on uninstall', 'estat-os' ), $s ); ?>
			</div>
		</div>

		<div id="estat-tools-section" class="estat-card-panel <?php echo $is_tools ? 'estat-highlight' : ''; ?>">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Tools — maintenance & debugging (3.0.7 fix)', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'This section replaces the broken tab=tools link. All classic Tools functionality is accessible here.', 'estat-os' ); ?></p>
			<div class="estat-tools-grid">
				<?php
				$url = admin_url( 'admin.php?page=estat-settings&tab=advanced&estat_scroll=tools' );
				self::tool_button( 'rebuild_index', __( 'Rebuild search list', 'estat-os' ), $url );
				self::tool_button( 'repair_tables', __( 'Repair database', 'estat-os' ), $url );
				self::tool_button( 'clear_cache', __( 'Clear temporary data', 'estat-os' ), $url );
				self::tool_button( 'run_housekeeping', __( 'Run daily jobs now', 'estat-os' ), $url );
				self::tool_button( 'repair_broken_data', __( 'Repair broken localities + draft pages (3.0.6 → 3.0.7)', 'estat-os' ), $url );
				self::tool_button( 'seed_practice', __( 'Add sample data', 'estat-os' ), $url );
				self::tool_button( 'clear_practice', __( 'Remove sample data', 'estat-os' ), $url );
				?>
			</div>
			<div class="estat-field-actions">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=tools' ) ); ?>" class="button" onclick="event.preventDefault(); document.getElementById('estat-tools-section').scrollIntoView({behavior:'smooth'});"><?php esc_html_e( 'Classic Tools screen (when new UI off)', 'estat-os' ); ?></a>
			</div>
		</div>
		<?php
	}

	/* helpers — no inline styles, all via admin-new.css classes */
	private static function field( string $key, string $label, array $s, string $type = 'text', array $options = array() ): void {
		$value = $s[ $key ] ?? '';
		$name = 'settings[' . $key . ']';
		echo '<div class="estat-field-row"><label class="estat-field-label">' . esc_html( $label ) . '</label>';
		if ( 'textarea' === $type ) {
			echo '<textarea name="' . esc_attr( $name ) . '" rows="3">' . esc_textarea( (string) $value ) . '</textarea>';
		} elseif ( 'select' === $type ) {
			echo '<select name="' . esc_attr( $name ) . '">';
			foreach ( $options as $opt_val => $opt_label ) {
				$opt_val = (string) $opt_val;
				echo '<option value="' . esc_attr( $opt_val ) . '" ' . selected( (string) $value, $opt_val, false ) . '>' . esc_html( (string) $opt_label ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'number' === $type ) {
			echo '<input type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		} elseif ( 'email' === $type || 'url' === $type ) {
			echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		} elseif ( 'image' === $type ) {
			$img_id = (int) $value;
			$img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : '';
			echo '<div class="estat-image-field">';
			if ( $img_url ) {
				echo '<img src="' . esc_url( $img_url ) . '" alt="" class="estat-image-preview" />';
			}
			echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
			echo '<button type="button" class="button estat-media-button">' . esc_html__( 'Select image', 'estat-os' ) . '</button>';
			if ( $img_id ) {
				echo '<button type="button" class="button estat-media-remove">' . esc_html__( 'Remove', 'estat-os' ) . '</button>';
			}
			echo '</div>';
		} else {
			echo '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		}
		echo '</div>';
	}

	private static function field_checkbox( string $key, string $label, array $s ): void {
		$value = ! empty( $s[ $key ] );
		$name = 'settings[' . $key . ']';
		echo '<div class="estat-field-row estat-field-row-checkbox"><label class="estat-field-label"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . ' /> ' . esc_html( $label ) . '</label></div>';
	}

	private static function tool_button( string $action, string $label, string $url ): void {
		echo '<form method="post" class="estat-inline-form" action="' . esc_url( $url ) . '">';
		wp_nonce_field( 'estat_tool_' . $action, 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="' . esc_attr( $action ) . '" />';
		echo '<button type="submit" class="button">' . esc_html( $label ) . '</button>';
		echo '</form>';
	}
}
