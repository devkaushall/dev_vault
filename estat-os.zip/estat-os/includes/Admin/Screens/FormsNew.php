<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Forms\Forms;
use EstatOS\Settings\Settings;
defined( 'ABSPATH' ) || exit;
final class FormsNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_forms' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' ); $forms = Forms::all();
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Forms</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Forms', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d forms', 'estat-os' ), count( $forms ) ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms&edit=0' ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add a form', 'estat-os' ); ?></a></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-enquiries'=>__( 'Inbox', 'estat-os' ),'estat-pipeline'=>__( 'Pipeline', 'estat-os' ),'estat-visits'=>__( 'Site Visits', 'estat-os' ),'estat-requests'=>__( 'Change Requests', 'estat-os' ),'estat-search-alerts'=>__( 'Search Alerts', 'estat-os' ),'estat-forms'=>__( 'Forms', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-forms' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-cards" style="grid-template-columns:repeat(3,1fr)"><?php foreach ( $forms as $form ) : ?><div class="estat-stitch-card-panel"><div class="estat-stitch-panel-header"><span class="material-symbols-outlined">description</span><h2><?php echo esc_html( $form['name'] ?? $form['title'] ?? '' ); ?></h2></div><p class="estat-stitch-muted"><?php echo esc_html( $form['description'] ?? '' ); ?></p><div style="margin-top:12px"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms&edit=' . ( $form['id'] ?? 0 ) ) ); ?>" class="estat-stitch-btn small"><?php esc_html_e( 'Edit', 'estat-os' ); ?></a></div></div><?php endforeach; ?></div>
		</div>
		<?php
	}
}
