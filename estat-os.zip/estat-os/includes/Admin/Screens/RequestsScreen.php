<?php
/**
 * Change requests + Pending listings approval — F2.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class RequestsScreen {

	public const SLUG = 'estat-requests';
	private const PER_PAGE = 20;

	public static function render(): void {
		if ( ! current_user_can( 'estat_review_listings' ) && ! current_user_can( 'estat_publish_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to review change requests.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['status']) ? '' : $_GET['status'] ) ) ) : 'pending';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( (string) ( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) ) : 1;
		// phpcs:enable

		$status = isset( Requests::statuses()[ $status ] ) ? $status : 'pending';

		$pending_listings = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'pending',
				'posts_per_page' => 20,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		$results = Requests::query(
			array(
				'status'   => $status,
				'page'     => $paged,
				'per_page' => self::PER_PAGE,
			)
		);

		Partials::toolbar(
			array(
				'page'        => self::SLUG,
				'show_search' => false,
				'count'       => (int) $results['total'] + (int) $pending_listings->found_posts,
				'filters'     => array(
					array(
						'name'    => 'status',
						'label'   => __( 'Show', 'estat-os' ),
						'value'   => $status,
						'options' => array_merge(
							array( '' => __( 'Everything waiting and dealt with', 'estat-os' ) ),
							self::status_labels()
						),
					),
				),
			)
		);

		if ( $pending_listings->have_posts() ) {
			echo '<h2 style="margin:16px 0 8px">' . esc_html__( 'New listings waiting for approval — office approve before live (F2)', 'estat-os' ) . ' (' . (int) $pending_listings->found_posts . ')</h2>';
			echo '<div class="estat-request-list">';
			while ( $pending_listings->have_posts() ) {
				$pending_listings->the_post();
				$id = (int) get_the_ID();
				self::pending_listing_item( $id );
			}
			echo '</div>';
			wp_reset_postdata();
		}

		if ( ! $results['items'] && 0 === (int) $pending_listings->found_posts ) {
			$waiting = 'pending' === $status;
			Partials::empty_state(
				array(
					'icon'       => 'check-circle',
					'title'      => $waiting ? __( 'Nothing is waiting for you', 'estat-os' ) : __( 'Nothing filed under that yet', 'estat-os' ),
					'message'    => $waiting ? __( 'The website is showing exactly what your office has confirmed. When somebody on the ground proposes a change, it arrives here for you to say yes or no.', 'estat-os' ) : __( 'Once requests start being dealt with, the decided ones will be listed here.', 'estat-os' ),
					'reassuring' => $waiting,
					'action'     => $waiting ? '' : admin_url( 'admin.php?page=' . self::SLUG ),
					'label'      => $waiting ? '' : __( 'Back to what is waiting', 'estat-os' ),
				)
			);
			return;
		}

		if ( $results['items'] ) {
			echo '<h2 style="margin:24px 0 8px">' . esc_html__( 'Change requests from field', 'estat-os' ) . '</h2>';
			echo '<div class="estat-request-list">';
			foreach ( $results['items'] as $request ) {
				self::item( (array) $request );
			}
			echo '</div>';
			Partials::pagination( (int) $results['pages'], $paged, __( 'Pages of change requests', 'estat-os' ) );
		}
	}

	private static function pending_listing_item( int $listing_id ): void {
		$title = get_the_title( $listing_id );
		$author = get_post_field( 'post_author', $listing_id );
		$user = get_userdata( (int) $author );
		$agent_name = $user ? $user->display_name : __( 'Agent', 'estat-os' );
		echo '<article class="estat-request" style="border-left:4px solid #f59e0b;padding:12px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:12px">';
		echo '<header class="estat-request-head" style="display:flex;justify-content:space-between"><div class="estat-request-head-text">';
		printf( '<p class="estat-request-title" style="margin:0;font-weight:600">%s</p>', esc_html( sprintf( __( 'New listing: “%s”', 'estat-os' ), $title ) ) );
		printf( '<p class="estat-request-meta" style="margin:4px 0;color:#6b7280;font-size:13px">%s · %s</p>', esc_html( $agent_name ), esc_html( get_the_date( '', $listing_id ) ) );
		echo '</div><span class="estat-pill" style="background:#fef3c7;padding:4px 8px;border-radius:999px;font-size:12px">' . esc_html__( 'Pending approval', 'estat-os' ) . '</span></header>';
		$ver = (string) get_post_meta( $listing_id, '_estat_verification', true );
		if ( '' !== $ver ) {
			echo '<p style="font-size:13px;margin:8px 0">' . esc_html__( 'Current verification:', 'estat-os' ) . ' ' . esc_html( Vocabulary::label( 'verification', $ver ) ) . '</p>';
		}
		$url = admin_url( 'admin.php?page=' . self::SLUG );
		echo '<footer class="estat-request-actions" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">';
		echo '<form method="post" action="' . esc_url( $url ) . '">';
		wp_nonce_field( 'estat_approve_listing_' . $listing_id, 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="listing_approve" />';
		echo '<input type="hidden" name="listing_id" value="' . esc_attr( (string) $listing_id ) . '" />';
		echo '<button type="submit" class="button button-primary">' . esc_html__( 'Approve & Publish + Verify ✓ humne khud dekha', 'estat-os' ) . '</button>';
		echo '</form>';
		echo '<form method="post" action="' . esc_url( $url ) . '">';
		wp_nonce_field( 'estat_decline_listing_' . $listing_id, 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="listing_decline" />';
		echo '<input type="hidden" name="listing_id" value="' . esc_attr( (string) $listing_id ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'Send back to draft', 'estat-os' ) . '</button>';
		echo '</form>';
		echo '<a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ) ) . '">' . esc_html__( 'Open listing', 'estat-os' ) . '</a>';
		// Quick verify button
		if ( current_user_can( 'estat_verify_listings' ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ) ) . '">';
			wp_nonce_field( 'estat_verify_listing_' . $listing_id, 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="verify_listing" />';
			echo '<input type="hidden" name="listing_id" value="' . esc_attr( (string) $listing_id ) . '" />';
			echo '<input type="hidden" name="verification" value="office_verified" />';
			echo '<button type="submit" class="button" style="background:#dcfce7">✓ ' . esc_html__( 'Mark Verified — humne khud dekha', 'estat-os' ) . '</button>';
			echo '</form>';
		}
		echo '</footer>';
		echo '</article>';
	}

	private static function item( array $request ): void {
		$id        = (int) $request['id'];
		$record_id = (int) $request['record_id'];
		$status    = (string) $request['status'];
		$agent     = get_userdata( (int) $request['requested_by'] );
		$agent_name = is_object( $agent ) && isset( $agent->display_name ) ? (string) $agent->display_name : '';
		$changes   = (array) $request['changes'];
		$note      = (string) ( $changes['note'] ?? '' );
		$title     = (string) get_the_title( $record_id );

		echo '<article class="estat-request" style="padding:12px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:12px">';

		echo '<header class="estat-request-head" style="display:flex;gap:8px">';
		echo '<span class="estat-request-icon">' . Icon::render( 'inbox', 20 ) . '</span>';
		echo '<div class="estat-request-head-text">';
		printf(
			'<p class="estat-request-title" style="margin:0;font-weight:600">%1$s</p>',
			esc_html(
				sprintf(
					__( 'Change to “%s”', 'estat-os' ),
					'' !== trim( $title ) ? $title : __( 'a property that has since gone', 'estat-os' )
				)
			)
		);
		printf(
			'<p class="estat-request-meta" style="margin:4px 0;color:#6b7280;font-size:13px">%1$s · %2$s</p>',
			esc_html( '' !== $agent_name ? $agent_name : __( 'Someone on your team', 'estat-os' ) ),
			esc_html( get_date_from_gmt( (string) $request['created_at'], (string) get_option( 'date_format', 'Y-m-d' ) ) )
		);
		echo '</div>';
		if ( 'pending' !== $status ) {
			printf(
				'<span class="estat-pill%1$s" style="padding:4px 8px;border-radius:999px">%2$s</span>',
				esc_attr( 'approved' === $status ? ' is-good' : '' ),
				esc_html( self::status_labels()[ $status ] ?? $status )
			);
		}
		echo '</header>';

		echo '<ul class="estat-request-changes" style="margin:8px 0;padding-left:16px">';
		foreach ( Requests::editable_fields() as $field => $meta ) {
			if ( 'note' === $field || ! isset( $changes[ $field ] ) ) {
				continue;
			}
			printf(
				'<li><span class="estat-request-field" style="font-weight:600">%1$s</span> <span class="estat-request-from" style="color:#6b7280">%2$s</span> → <span class="estat-request-to" style="color:#111">%3$s</span></li>',
				esc_html( (string) $meta['label'] ),
				esc_html( Requests::describe( (string) $field, Requests::current_value( $record_id, (string) $field ) ) ),
				esc_html( Requests::describe( (string) $field, (string) $changes[ $field ] ) )
			);
		}
		echo '</ul>';

		if ( '' !== $note ) {
			printf(
				'<p class="estat-request-note" style="background:#f9fafb;padding:8px;border-radius:6px"><span class="screen-reader-text">%1$s</span>%2$s</p>',
				esc_html__( 'They wrote:', 'estat-os' ),
				esc_html( $note )
			);
		}

		if ( '' !== (string) ( $request['reason'] ?? '' ) ) {
			printf(
				'<p class="estat-request-reason"><span class="screen-reader-text">%1$s</span>%2$s</p>',
				esc_html__( 'You answered:', 'estat-os' ),
				esc_html( (string) $request['reason'] )
			);
		}

		if ( 'pending' === $status ) {
			$url = admin_url( 'admin.php?page=' . self::SLUG );
			echo '<footer class="estat-request-actions" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">';
			echo '<form method="post" action="' . esc_url( $url ) . '">';
			wp_nonce_field( 'estat_approve_request_' . $id, 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="approve_request" />';
			echo '<input type="hidden" name="request_id" value="' . esc_attr( (string) $id ) . '" />';
			echo '<button type="submit" class="button button-primary">' . esc_html__( 'Yes, change it', 'estat-os' ) . '</button>';
			echo '</form>';
			echo '<form method="post" action="' . esc_url( $url ) . '" class="estat-request-decline" style="display:flex;gap:4px">';
			wp_nonce_field( 'estat_decline_request_' . $id, 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="decline_request" />';
			echo '<input type="hidden" name="request_id" value="' . esc_attr( (string) $id ) . '" />';
			echo '<input type="text" id="estat-decline-' . esc_attr( (string) $id ) . '" name="reason" maxlength="200" placeholder="' . esc_attr__( 'Why not, in a few words…', 'estat-os' ) . '" />';
			echo '<button type="submit" class="button">' . esc_html__( 'Not now', 'estat-os' ) . '</button>';
			echo '</form>';
			echo '</footer>';
		}

		printf(
			'<a class="estat-request-open button button-small" style="margin-top:8px" href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $record_id ) ),
			esc_html__( 'Open the property', 'estat-os' )
		);

		echo '</article>';
	}

	private static function status_labels(): array {
		$labels = Requests::statuses();
		$labels['pending'] = __( 'Waiting for a decision', 'estat-os' );
		return $labels;
	}
}
