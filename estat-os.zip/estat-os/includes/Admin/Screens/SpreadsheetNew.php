<?php
/**
 * Spreadsheet — Stitch redesign, real listings grid.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class SpreadsheetNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		// phpcs:enable

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );

		$args = array( 'post_type'=>PostTypes::LISTING, 'post_status'=>array('publish','draft','pending','private'), 'posts_per_page'=>50, 'paged'=>$paged, 'orderby'=>'modified', 'order'=>'DESC' );
		if ( '' !== $search ) { $args['s'] = $search; }
		$query = new \WP_Query( $args );

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb"><span><?php esc_html_e( 'Portfolio', 'estat-os' ); ?></span><span>/</span><span><?php esc_html_e( 'Spreadsheet', 'estat-os' ); ?></span></div>
				<div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Spreadsheet', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d properties', 'estat-os' ), $query->found_posts ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet&action=export' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">download</span> <?php esc_html_e( 'Export', 'estat-os' ); ?></a></div></div>
			</div>

			<div class="estat-stitch-controls"><div class="estat-stitch-controls-top"><form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search"><input type="hidden" name="page" value="estat-spreadsheet" /><span class="material-symbols-outlined">search</span><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search by headline, ID, locality', 'estat-os' ); ?>" /></form></div></div>

			<div class="estat-stitch-table-wrap">
				<div class="estat-stitch-table-scroll">
					<table class="estat-stitch-table">
						<thead><tr><th class="w-10"><input type="checkbox" id="estat-select-all" /></th><th><?php esc_html_e( 'Property', 'estat-os' ); ?></th><th><?php esc_html_e( 'Locality', 'estat-os' ); ?></th><th><?php esc_html_e( 'Price', 'estat-os' ); ?></th><th><?php esc_html_e( 'Area', 'estat-os' ); ?></th><th><?php esc_html_e( 'Beds', 'estat-os' ); ?></th><th><?php esc_html_e( 'Status', 'estat-os' ); ?></th><th><?php esc_html_e( 'Updated', 'estat-os' ); ?></th></tr></thead>
						<tbody>
							<?php while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $price = get_post_meta( $id, '_estat_price_display', true ) ?: get_post_meta( $id, '_estat_price', true ); $area = get_post_meta( $id, '_estat_area', true ); $beds = get_post_meta( $id, '_estat_bedrooms', true ); $terms = get_the_terms( $id, 'estat_locality' ); $loc = $terms && ! is_wp_error( $terms ) && ! empty( $terms[0]->name ) ? $terms[0]->name : ''; ?>
							<tr><td><input type="checkbox" class="estat-row-check" value="<?php echo esc_attr( (string) $id ); ?>" /></td><td><div class="estat-stitch-member"><div class="estat-stitch-avatar is-property" style="width:48px;height:32px"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(48,32) ) : '<span class="material-symbols-outlined">image</span>'; ?></div><div><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>" style="font-weight:600;color:#1b1c19;text-decoration:none"><?php echo esc_html( get_the_title() ); ?></a><div class="estat-stitch-ref">#<?php echo esc_html( (string) $id ); ?></div></div></div></td><td><?php echo esc_html( $loc ); ?></td><td class="estat-stitch-date" style="font-variant-numeric:tabular-nums"><?php echo esc_html( $price ? (string) $price : '—' ); ?></td><td><?php echo esc_html( $area ? (string) $area : '—' ); ?></td><td><?php echo esc_html( $beds ? (string) $beds : '—' ); ?></td><td><span class="estat-stitch-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><?php echo esc_html( get_post_status( $id ) ); ?></span></td><td class="estat-stitch-date"><?php echo esc_html( get_the_modified_date() ); ?></td></tr>
							<?php endwhile; wp_reset_postdata(); ?>
						</tbody>
					</table>
				</div>
				<div class="estat-stitch-pagination"><span><?php echo esc_html( sprintf( __( 'Page %d of %d', 'estat-os' ), $paged, max(1,(int)$query->max_num_pages) ) ); ?></span><div class="estat-stitch-pager"><?php echo paginate_links( array( 'base'=>add_query_arg('paged','%#%'), 'format'=>'', 'current'=>$paged, 'total'=>max(1,(int)$query->max_num_pages) ) ); ?></div></div>
			</div>
		</div>
		<script>(function(){var selAll=document.getElementById('estat-select-all');if(selAll){selAll.addEventListener('change',function(){document.querySelectorAll('.estat-row-check').forEach(function(c){c.checked=selAll.checked;});});}})();</script>
		<?php
	}
}
