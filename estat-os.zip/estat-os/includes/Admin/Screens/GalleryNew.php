<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Settings\Settings;
defined( 'ABSPATH' ) || exit;
final class GalleryNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		wp_enqueue_media();
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' );
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Gallery & Media</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Gallery & Media', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php esc_html_e( 'Manage media library for listings and projects. Real media only.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><a href="<?php echo esc_url( admin_url( 'upload.php' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">photo_library</span> <?php esc_html_e( 'Media library', 'estat-os' ); ?></a></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-settings'=>__( 'Office Settings', 'estat-os' ),'estat-gallery'=>__( 'Gallery & Media', 'estat-os' ),'estat-templates'=>__( 'Templates', 'estat-os' ),'estat-design-tokens'=>__( 'Design Tokens', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-gallery' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-card-panel"><div class="estat-stitch-panel-header"><span class="material-symbols-outlined">image</span><h2><?php esc_html_e( 'Media', 'estat-os' ); ?></h2></div><p class="estat-stitch-muted"><?php esc_html_e( 'Use the WordPress media library to upload and manage images for your properties. All photos are stored as WordPress attachments.', 'estat-os' ); ?></p><div style="margin-top:12px"><button type="button" class="estat-stitch-btn-primary" id="estat-media-open"><span class="material-symbols-outlined">add_a_photo</span> <?php esc_html_e( 'Open media library', 'estat-os' ); ?></button></div></div>
		</div>
		<script>(function(){var btn=document.getElementById('estat-media-open');if(btn){btn.addEventListener('click',function(){wp.media().open();});}})();</script>
		<?php
	}
}
