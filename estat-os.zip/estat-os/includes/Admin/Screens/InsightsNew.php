<?php
declare( strict_types = 1 );
namespace EstatOS\Admin\Screens;
use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;
defined( 'ABSPATH' ) || exit;
final class InsightsNew {
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_insights' ) ) { wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) ); }
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$s = Settings::all(); $city = (string) ( $s['city'] ?? '' );
		$args = array( 'post_type'=>PostTypes::INSIGHT, 'post_status'=>array('publish','draft'), 'posts_per_page'=>20, 'paged'=>$paged, 'orderby'=>'modified', 'order'=>'DESC' );
		if ( '' !== $search ) { $args['s'] = $search; }
		$query = new \WP_Query( $args );
		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header"><div class="estat-stitch-breadcrumb"><span>Portfolio</span><span>/</span><span>Insights</span></div><div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Insights', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d articles', 'estat-os' ), $query->found_posts ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . PostTypes::INSIGHT ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add insight', 'estat-os' ); ?></a></div></div></div>
			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-team'=>__( 'Team', 'estat-os' ),'estat-reports'=>__( 'Reports', 'estat-os' ),'estat-insights'=>__( 'Insights', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-insights' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>
			<div class="estat-stitch-controls"><div class="estat-stitch-controls-top"><form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search"><input type="hidden" name="page" value="estat-insights" /><span class="material-symbols-outlined">search</span><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search insights', 'estat-os' ); ?>" /></form></div></div>
			<div class="estat-stitch-table-wrap"><div class="estat-stitch-table-scroll"><table class="estat-stitch-table"><thead><tr><th><?php esc_html_e( 'Title', 'estat-os' ); ?></th><th><?php esc_html_e( 'Status', 'estat-os' ); ?></th><th><?php esc_html_e( 'Date', 'estat-os' ); ?></th><th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th></tr></thead><tbody><?php while ( $query->have_posts() ) : $query->the_post(); ?><tr><td><a href="<?php echo esc_url( get_edit_post_link() ); ?>" style="font-weight:600;color:#1b1c19;text-decoration:none"><?php the_title(); ?></a></td><td><span class="estat-stitch-status is-<?php echo esc_attr( get_post_status() ); ?>"><?php echo esc_html( get_post_status() ); ?></span></td><td class="estat-stitch-date"><?php echo esc_html( get_the_date() ); ?></td><td class="text-right"><div class="estat-stitch-actions"><a href="<?php echo esc_url( get_edit_post_link() ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">edit</span></a></div></td></tr><?php endwhile; wp_reset_postdata(); ?></tbody></table></div></div>
		</div>
		<?php
	}
}
