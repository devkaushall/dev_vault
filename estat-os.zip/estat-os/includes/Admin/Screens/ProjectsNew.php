<?php
/**
 * Projects — Stitch redesign, real data.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class ProjectsNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_projects' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$selected_id = isset( $_GET['project_id'] ) ? absint( wp_unslash( is_array($_GET['project_id']) ? '' : $_GET['project_id'] ) ) : 0;
		// phpcs:enable

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );

		$counts = (array) wp_count_posts( PostTypes::PROJECT );
		$total = (int) ( $counts['publish'] ?? 0 ) + (int) ( $counts['draft'] ?? 0 );
		$live = (int) ( $counts['publish'] ?? 0 );
		$draft = (int) ( $counts['draft'] ?? 0 );

		$args = array( 'post_type'=>PostTypes::PROJECT, 'post_status'=>array('publish','draft'), 'posts_per_page'=>20, 'paged'=>$paged, 'orderby'=>'modified', 'order'=>'DESC' );
		if ( '' !== $search ) { $args['s'] = $search; }
		$query = new \WP_Query( $args );

		$selected = null;
		if ( $selected_id > 0 ) { $selected = get_post( $selected_id ); }
		elseif ( $query->have_posts() ) { $selected = $query->posts[0]; $selected_id = $selected->ID; }

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb"><span><?php esc_html_e( 'Portfolio', 'estat-os' ); ?></span><span>/</span><span><?php esc_html_e( 'Societies / Projects', 'estat-os' ); ?></span></div>
				<div class="estat-stitch-header-row"><div><h1 class="estat-stitch-h1"><?php esc_html_e( 'Projects', 'estat-os' ); ?></h1><p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d projects — %d live, %d drafts', 'estat-os' ), $total, $live, $draft ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p></div><div class="estat-stitch-header-actions"><?php echo NewUI::toggle_markup(); // phpcs:ignore ?><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . PostTypes::PROJECT ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add project', 'estat-os' ); ?></a></div></div>
			</div>

			<div class="estat-stitch-metrics"><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Total', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $total ); ?></span></div></div><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Live', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $live ); ?></span><span class="estat-stitch-badge">Public</span></div></div><div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php esc_html_e( 'Drafts', 'estat-os' ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $draft ); ?></span></div></div></div>

			<div class="estat-stitch-controls"><div class="estat-stitch-controls-top"><form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search"><input type="hidden" name="page" value="estat-projects" /><span class="material-symbols-outlined">search</span><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search projects', 'estat-os' ); ?>" /></form></div></div>

			<div class="estat-stitch-enquiries-layout">
				<div class="estat-stitch-cards" style="grid-template-columns:repeat(2,1fr)">
					<?php if ( ! $query->have_posts() ) : ?><div class="estat-stitch-card-panel"><?php esc_html_e( 'No projects found.', 'estat-os' ); ?></div><?php else : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $is_active = $id === $selected_id; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-projects&project_id=' . $id . '&s=' . urlencode( $search ) ) ); ?>" class="estat-stitch-card <?php echo $is_active ? 'is-active' : ''; ?>">
						<div class="estat-stitch-card-media" style="height:120px"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, 'medium_large' ) : '<div class="estat-stitch-preview-placeholder"><span class="material-symbols-outlined">domain</span></div>'; ?></div>
						<div class="estat-stitch-card-body"><h3 class="estat-stitch-card-name"><?php echo esc_html( get_the_title() ); ?></h3><p class="estat-stitch-card-role"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 12 ) ); ?></p></div>
						<div class="estat-stitch-card-foot"><span class="estat-stitch-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><?php echo esc_html( get_post_status( $id ) ); ?></span><span><?php echo esc_html( get_the_modified_date() ); ?></span></div>
					</a>
					<?php endwhile; wp_reset_postdata(); endif; ?>
				</div>

				<div class="estat-stitch-enquiries-detail">
					<?php if ( ! $selected ) : ?><div class="estat-stitch-card-panel"><p class="estat-stitch-muted"><?php esc_html_e( 'Select a project.', 'estat-os' ); ?></p></div><?php else : $project = Projects::to_array( $selected->ID ); ?>
					<div class="estat-stitch-card-panel"><div class="estat-stitch-panel-header"><h2><?php echo esc_html( $selected->post_title ); ?></h2><span class="estat-stitch-status is-<?php echo esc_attr( $selected->post_status ); ?>"><?php echo esc_html( $selected->post_status ); ?></span></div><?php if ( has_post_thumbnail( $selected->ID ) ) : ?><div style="margin-bottom:12px"><?php echo get_the_post_thumbnail( $selected->ID, 'large' ); ?></div><?php endif; ?><div class="estat-stitch-detail-grid"><div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Developer', 'estat-os' ); ?></span><br><?php echo esc_html( $project['developer'] ?? '' ); ?></div><div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Stage', 'estat-os' ); ?></span><br><?php echo esc_html( $project['project_status'] ?? '' ); ?></div></div><div style="margin-top:12px"><a href="<?php echo esc_url( get_edit_post_link( $selected->ID ) ); ?>" class="estat-stitch-btn"><?php esc_html_e( 'Edit', 'estat-os' ); ?></a> <a href="<?php echo esc_url( get_permalink( $selected->ID ) ); ?>" class="estat-stitch-btn"><?php esc_html_e( 'View', 'estat-os' ); ?></a></div></div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
