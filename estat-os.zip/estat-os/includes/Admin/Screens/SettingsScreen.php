<?php
/**
 * Office settings.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\I18n\Language;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;
use EstatOS\Webhooks\Webhooks;

defined( 'ABSPATH' ) || exit;

/**
 * Everything about the office in one place, grouped into plain-language tabs.
 */
final class SettingsScreen {

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to change office settings.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( is_array($_GET['tab']) ? '' : $_GET['tab'] ) ) : 'office';
		$tabs = array(
			'office'    => __( 'Your office', 'estat-os' ),
			'website'   => __( 'Website', 'estat-os' ),
			'pages'     => __( 'Pages', 'estat-os' ),
			'filters'   => __( 'Search Filters', 'estat-os' ),
			'leads'     => __( 'Leads', 'estat-os' ),
			'language'  => __( 'Language', 'estat-os' ),
			'emails'    => __( 'Emails', 'estat-os' ),
			'advanced'  => __( 'Connections', 'estat-os' ),
			'tools'     => __( 'Tools', 'estat-os' ),
		);
		$tab = isset( $tabs[ $tab ] ) ? $tab : 'office';
		$s   = Settings::all();

		echo '<nav class="nav-tab-wrapper estat-tabs">';
		foreach ( $tabs as $slug => $label ) {
			printf(
				'<a class="nav-tab %1$s" href="%2$s">%3$s</a>',
				esc_attr( $slug === $tab ? 'nav-tab-active' : '' ),
				esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $slug ) ),
				esc_html( (string) $label )
			);
		}
		echo '</nav>';

		if ( 'tools' === $tab ) {
			self::tools();
			return;
		}
		if ( 'pages' === $tab ) {
			self::pages_tab();
			return;
		}
		?>
		<form method="post" class="estat-form-admin" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $tab ) ); ?>">
			<?php
			wp_nonce_field( 'estat_save_settings', 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="save_settings" />';
			echo '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />';

			switch ( $tab ) {
				case 'website':
					self::website( $s );
					break;
				case 'pages':
					self::pages_tab();
					break;
				case 'filters':
					self::filters( $s );
					break;
				case 'leads':
					self::leads( $s );
					break;
				case 'language':
					self::language( $s );
					break;
				case 'emails':
					self::emails( $s );
					break;
				case 'advanced':
					self::advanced( $s );
					break;
				default:
					self::office( $s );
			}
			?>
			<div class="estat-form-actions-admin estat-sticky-actions">
				<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Save settings', 'estat-os' ); ?></button>
			</div>
		</form>
		<?php
	}

	/**
	 * Office identity fields.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function office( array $s ): void {
		Partials::card_open( __( 'Who you are', 'estat-os' ), __( 'This appears on your website and in the emails you send.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[office_name]', 'label' => __( 'Office name', 'estat-os' ), 'value' => $s['office_name'], 'example' => __( 'Sharma Properties', 'estat-os' ) ) );
		Partials::field( array( 'name' => 'settings[tagline]', 'label' => __( 'One line about the office', 'estat-os' ), 'value' => $s['tagline'] ) );
		Partials::field( array( 'name' => 'settings[contact_person]', 'label' => __( 'Main contact person', 'estat-os' ), 'value' => $s['contact_person'] ) );
		Partials::field( array( 'name' => 'settings[phone]', 'label' => __( 'Phone number', 'estat-os' ), 'value' => $s['phone'], 'example' => '+91 98765 43210' ) );
		Partials::field( array( 'name' => 'settings[whatsapp]', 'label' => __( 'WhatsApp number', 'estat-os' ), 'value' => $s['whatsapp'] ) );
		Partials::field( array( 'name' => 'settings[email]', 'type' => 'email', 'label' => __( 'Email address', 'estat-os' ), 'value' => $s['email'] ) );
		Partials::field( array( 'name' => 'settings[address]', 'type' => 'textarea', 'rows' => 3, 'label' => __( 'Office address', 'estat-os' ), 'value' => $s['address'] ) );
		Partials::field( array( 'name' => 'settings[office_hours]', 'label' => __( 'Opening hours', 'estat-os' ), 'value' => $s['office_hours'], 'example' => __( 'Mon to Sat, 10am to 7pm', 'estat-os' ) ) );
		Partials::field( array( 'name' => 'settings[logo_id]', 'type' => 'image', 'label' => __( 'Office logo', 'estat-os' ), 'value' => $s['logo_id'] ) );
		Partials::card_close();

		Partials::card_open(
			__( 'How the office screens look', 'estat-os' ),
			__( 'This only changes what you and your team see while working. Your website is not affected.', 'estat-os' )
		);
		Partials::field(
			array(
				'name'    => 'settings[admin_theme]',
				'type'    => 'select',
				'label'   => __( 'Screen colours', 'estat-os' ),
				'value'   => $s['admin_theme'],
				'options' => array(
					'light' => __( 'Light — bright background', 'estat-os' ),
					'dark'  => __( 'Dark — easier at night', 'estat-os' ),
					'auto'  => __( 'Automatic — follow this computer', 'estat-os' ),
				),
				'help'    => __( 'Automatic switches with your computer, so it goes dark in the evening on its own.', 'estat-os' ),
			)
		);
		Partials::card_close();

		Partials::card_open( __( 'Money and measurements', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[currency_symbol]', 'label' => __( 'Currency symbol', 'estat-os' ), 'value' => $s['currency_symbol'] ) );
		Partials::field( array( 'name' => 'settings[currency]', 'label' => __( 'Currency code', 'estat-os' ), 'value' => $s['currency'], 'example' => 'INR' ) );
		Partials::field(
			array(
				'name'    => 'settings[price_format]',
				'type'    => 'select',
				'label'   => __( 'How prices should read', 'estat-os' ),
				'value'   => $s['price_format'],
				'options' => array(
					'indian'    => __( 'Indian style: ₹8.5 Cr, ₹45 Lakh', 'estat-os' ),
					'compact'   => __( 'Short style: ₹8.5M, ₹450K', 'estat-os' ),
					'plain'     => __( 'Full number: ₹85,000,000', 'estat-os' ),
				),
				'help'    => __( 'You always type the plain number. This only changes how visitors see it.', 'estat-os' ),
			)
		);
		Partials::field( array( 'name' => 'settings[default_area_unit]', 'type' => 'select', 'label' => __( 'Area unit you use most', 'estat-os' ), 'value' => $s['default_area_unit'], 'options' => Vocabulary::area_units(), 'help' => __( 'Everything is stored in square feet behind the scenes, so you can mix units safely.', 'estat-os' ) ) );
		Partials::field( array( 'name' => 'settings[regulatory_label]', 'label' => __( 'Name of your registration authority', 'estat-os' ), 'value' => $s['regulatory_label'], 'example' => 'RERA' ) );
		Partials::field( array( 'name' => 'settings[show_regulatory]', 'type' => 'checkbox', 'label' => __( 'Registration numbers', 'estat-os' ), 'checkbox_label' => __( 'Show them publicly on each property', 'estat-os' ), 'value' => (bool) $s['show_regulatory'] ) );
		Partials::card_close();
	}

	/**
	 * Website behaviour fields — Mayfair v3 adds share, print, EMI, locality pages, alerts.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function website( array $s ): void {
		Partials::card_open( __( 'How your property pages behave', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[listings_per_page]', 'type' => 'number', 'label' => __( 'Properties shown per page', 'estat-os' ), 'value' => (int) $s['listings_per_page'], 'min' => 3, 'max' => 60 ) );
		Partials::field( array( 'name' => 'settings[enable_favorites]', 'type' => 'checkbox', 'label' => __( 'Saved properties', 'estat-os' ), 'checkbox_label' => __( 'Let visitors save properties they like', 'estat-os' ), 'value' => (bool) $s['enable_favorites'] ) );
		Partials::field( array( 'name' => 'settings[enable_compare]', 'type' => 'checkbox', 'label' => __( 'Side by side', 'estat-os' ), 'checkbox_label' => __( 'Let visitors compare up to four properties', 'estat-os' ), 'value' => (bool) $s['enable_compare'] ) );
		Partials::field( array( 'name' => 'settings[enable_schema]', 'type' => 'checkbox', 'label' => __( 'Search engines', 'estat-os' ), 'checkbox_label' => __( 'Help Google understand your listings', 'estat-os' ), 'value' => (bool) $s['enable_schema'], 'help' => __( 'Recommended. This adds hidden information that search engines read.', 'estat-os' ) ) );
		Partials::field( array( 'name' => 'settings[verification_mode]', 'type' => 'select', 'label' => __( 'Checking listings before they go live', 'estat-os' ), 'value' => $s['verification_mode'], 'options' => array( 'optional' => __( 'Anyone can publish', 'estat-os' ), 'required' => __( 'Only verified listings appear on the website', 'estat-os' ) ) ) );
		Partials::field( array( 'name' => 'settings[listing_expiry_days]', 'type' => 'number', 'label' => __( 'Retire listings after this many days', 'estat-os' ), 'value' => (int) $s['listing_expiry_days'], 'min' => 0, 'max' => 3650, 'help' => __( 'Zero means never. Retired listings are moved to drafts, never deleted.', 'estat-os' ) ) );
		Partials::card_close();

		Partials::card_open( __( 'Share, Print, EMI, Locality, Alerts', 'estat-os' ), __( 'Control how listings can be shared and what tools appear.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[share_enabled]', 'type' => 'checkbox', 'label' => __( 'Share row', 'estat-os' ), 'checkbox_label' => __( 'Show WhatsApp / Copy link / Print on each listing', 'estat-os' ), 'value' => (bool) ( $s['share_enabled'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[print_enabled]', 'type' => 'checkbox', 'label' => __( 'Print page', 'estat-os' ), 'checkbox_label' => __( 'Enable print summary', 'estat-os' ), 'value' => (bool) ( $s['print_enabled'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[emi_enabled]', 'type' => 'checkbox', 'label' => __( 'EMI Calculator', 'estat-os' ), 'checkbox_label' => __( 'Show monthly repayment estimate on sale listings', 'estat-os' ), 'value' => (bool) ( $s['emi_enabled'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[emi_default_rate]', 'type' => 'number', 'label' => __( 'EMI default interest %', 'estat-os' ), 'value' => (float) ( $s['emi_default_rate'] ?? 8.5 ), 'min' => 1, 'max' => 20, 'step' => 0.1 ) );
		Partials::field( array( 'name' => 'settings[emi_default_years]', 'type' => 'number', 'label' => __( 'EMI default tenure years', 'estat-os' ), 'value' => (int) ( $s['emi_default_years'] ?? 20 ), 'min' => 1, 'max' => 40 ) );
		Partials::field( array( 'name' => 'settings[locality_pages]', 'type' => 'checkbox', 'label' => __( 'Locality pages', 'estat-os' ), 'checkbox_label' => __( 'Enable locality, amenity and feature pages', 'estat-os' ), 'value' => (bool) ( $s['locality_pages'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[search_alerts_enabled]', 'type' => 'checkbox', 'label' => __( 'Search alerts', 'estat-os' ), 'checkbox_label' => __( 'Let visitors watch a search and get email when match goes live', 'estat-os' ), 'value' => (bool) ( $s['search_alerts_enabled'] ?? false ), 'help' => __( 'Default OFF until double opt-in verified. Enable only after testing confirm flow.', 'estat-os' ) ) );
		Partials::card_close();

		Partials::card_open( __( 'Maps', 'estat-os' ), __( 'Maps work out of the box with free OpenStreetMap. A Google key is only needed if you prefer Google maps.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[map_provider]', 'type' => 'select', 'label' => __( 'Map style', 'estat-os' ), 'value' => $s['map_provider'], 'options' => array( 'osm' => __( 'OpenStreetMap (free, no setup)', 'estat-os' ), 'google' => __( 'Google Maps (needs a key)', 'estat-os' ), 'none' => __( 'Do not show maps', 'estat-os' ) ) ) );
		Partials::field( array( 'name' => 'settings[google_maps_key]', 'label' => __( 'Google Maps key', 'estat-os' ), 'value' => $s['google_maps_key'] ) );
		Partials::field( array( 'name' => 'settings[map_default_lat]', 'label' => __( 'Map starts at this latitude', 'estat-os' ), 'value' => $s['map_default_lat'], 'example' => '28.6139' ) );
		Partials::field( array( 'name' => 'settings[map_default_lng]', 'label' => __( 'Map starts at this longitude', 'estat-os' ), 'value' => $s['map_default_lng'], 'example' => '77.2090' ) );
		Partials::field( array( 'name' => 'settings[map_default_zoom]', 'type' => 'number', 'label' => __( 'How close the map starts', 'estat-os' ), 'value' => (int) $s['map_default_zoom'], 'min' => 1, 'max' => 20 ) );
		Partials::card_close();
	}

	/**
	 * 23 filters toggle + drag order — F9.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function filters( array $s ): void {
		$enabled = is_array( $s['enabled_filters'] ?? null ) ? $s['enabled_filters'] : array_keys( Vocabulary::all_filters() );
		$order   = is_array( $s['filter_order'] ?? null ) ? $s['filter_order'] : array_keys( Vocabulary::all_filters() );
		$all     = Vocabulary::all_filters();
		// Ensure order contains all keys.
		foreach ( array_keys( $all ) as $k ) {
			if ( ! in_array( $k, $order, true ) ) {
				$order[] = $k;
			}
		}
		$order = array_values( array_intersect( $order, array_keys( $all ) ) );

		Partials::card_open( __( 'Search Filters', 'estat-os' ), __( 'Choose which filters appear and drag to reorder. Visitors only see enabled ones.', 'estat-os' ) );

		echo '<p class="description">' . esc_html__( 'Drag the handle to change order. Untick to hide a filter from visitors. Order here is exactly the order visitors see in search form.', 'estat-os' ) . '</p>';
		echo '<p><button type="button" class="button" id="estat-filters-enable-all">Enable all</button> <button type="button" class="button" id="estat-filters-disable-all">Disable all</button> <button type="button" class="button" id="estat-filters-reset-order">Reset order</button></p>';
		echo '<input type="hidden" name="settings[filter_order_csv]" id="estat-filter-order-csv" value="' . esc_attr( implode( ',', $order ) ) . '">';

		// Grouped rendering but draggable as one list.
		echo '<div id="estat-filters-list" style="display:flex;flex-direction:column;gap:6px;max-width:800px">';
		foreach ( $order as $key ) {
			if ( ! isset( $all[ $key ] ) ) { continue; }
			$info = $all[ $key ];
			$checked = in_array( $key, $enabled, true ) ? 'checked' : '';
			$is_on = $checked ? 'is-on' : 'is-off';
			echo '<div class="estat-filter-item ' . esc_attr( $is_on ) . '" data-key="' . esc_attr( $key ) . '" draggable="true" style="display:flex;align-items:center;gap:10px;border:1px solid var(--estat-line);padding:8px 10px;border-radius:8px;background:var(--estat-card);cursor:grab">';
			echo '<span class="estat-drag-handle" style="cursor:grab;font-size:16px" title="Drag to reorder">↕</span>';
			echo '<input type="checkbox" name="settings[enabled_filters][]" value="' . esc_attr( $key ) . '" ' . $checked . ' style="margin:0">';
			echo '<span style="flex:1"><strong>' . esc_html( $info['label'] ) . '</strong> <span style="font-size:11px;color:var(--estat-muted)">' . esc_html( $key . ' · ' . $info['group'] ) . '</span></span>';
			echo '<span style="font-size:11px;padding:2px 6px;border-radius:999px;background:#f3f4f6">' . esc_html( $info['group'] ) . '</span>';
			echo '</div>';
		}
		echo '</div>';

		// Inline JS for drag-drop.
		?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const list = document.getElementById('estat-filters-list');
			const orderInput = document.getElementById('estat-filter-order-csv');
			if(!list || !orderInput) return;
			let dragEl = null;
			function updateOrder(){
				const keys = Array.from(list.querySelectorAll('.estat-filter-item')).map(el=>el.getAttribute('data-key'));
				orderInput.value = keys.join(',');
			}
			list.addEventListener('dragstart', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(!item) return;
				dragEl = item;
				e.dataTransfer.effectAllowed = 'move';
				item.style.opacity='0.5';
			});
			list.addEventListener('dragend', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(item) item.style.opacity='1';
				dragEl=null;
				updateOrder();
			});
			list.addEventListener('dragover', function(e){
				e.preventDefault();
				const target = e.target.closest('.estat-filter-item');
				if(!target || target===dragEl) return;
				const rect = target.getBoundingClientRect();
				const next = (e.clientY - rect.top) / (rect.height) > 0.5;
				if(next){
					target.parentNode.insertBefore(dragEl, target.nextSibling);
				}else{
					target.parentNode.insertBefore(dragEl, target);
				}
			});
			list.addEventListener('drop', function(e){
				e.preventDefault();
				updateOrder();
			});
			// Enable/disable all
			const enAll = document.getElementById('estat-filters-enable-all');
			const disAll = document.getElementById('estat-filters-disable-all');
			const resetBtn = document.getElementById('estat-filters-reset-order');
			if(enAll) enAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=true); });
			if(disAll) disAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=false); });
			if(resetBtn) resetBtn.addEventListener('click', function(){
				const defaults = <?php echo wp_json_encode( array_keys( \EstatOS\Support\Vocabulary::all_filters() ) ); ?>;
				orderInput.value = defaults.join(',');
				// Reorder DOM to defaults
				const map = {};
				list.querySelectorAll('.estat-filter-item').forEach(el=>{ map[el.getAttribute('data-key')] = el; });
				defaults.forEach(k=>{ if(map[k]) list.appendChild(map[k]); });
			});
			// Toggle visual class on checkbox change
			list.addEventListener('change', function(e){
				if(e.target.type==='checkbox'){
					const item = e.target.closest('.estat-filter-item');
					if(item){
						item.classList.toggle('is-on', e.target.checked);
						item.classList.toggle('is-off', !e.target.checked);
					}
				}
			});
		});
		</script>
		<style>
		.estat-filter-item.is-off{opacity:0.55;background:#fafafa !important}
		.estat-filter-item.is-on{border-color:#111 !important}
		</style>
		<?php

		Partials::card_close();

		echo '<p><em>' . esc_html__( 'Tip: Keep locality, property_type, offer, price, bedrooms on for best results. Drag amenities/features near the bottom, they appear in More filters section.', 'estat-os' ) . '</em></p>';
	}

	/**
	 * Leads pipeline settings — F1 auto-assign by intent, fallback, retention, consent.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function leads( array $s ): void {
		$rules = is_array( $s['lead_assign_rules'] ?? null ) ? $s['lead_assign_rules'] : array();
		$agents = \EstatOS\Data\Picker::options( \EstatOS\Data\PostTypes::AGENT, __( '— No auto-assign —', 'estat-os' ) );
		$options = $agents['options'];

		Partials::card_open( __( 'Leads pipeline', 'estat-os' ), __( 'Manage lead stages and auto-assign by intent.', 'estat-os' ) );

		echo '<p><strong>' . esc_html__( 'Auto-assign by intent', 'estat-os' ) . '</strong></p>';
		echo '<p class="description">' . esc_html__( 'When a lead comes in, if it has an intent (Buy, Rent, Sell...), assign it to this team member automatically. Falls back to listing agent, then fallback below.', 'estat-os' ) . '</p>';
		foreach ( Vocabulary::lead_intents() as $intent_key => $intent_label ) {
			$current = $rules[ $intent_key ] ?? 0;
			echo '<div class="estat-field-row" style="display:flex;gap:8px;align-items:center;margin:6px 0"><span style="min-width:100px">' . esc_html( $intent_label ) . '</span>';
			echo '<select name="settings[lead_assign_rules][' . esc_attr( $intent_key ) . ']">';
			foreach ( $options as $opt_val => $opt_label ) {
				echo '<option value="' . esc_attr( (string) $opt_val ) . '" ' . selected( (string) $current, (string) $opt_val, false ) . '>' . esc_html( $opt_label ) . '</option>';
			}
			echo '</select></div>';
		}

		echo '<div style="margin-top:16px">';
		Partials::field( array( 'name' => 'settings[lead_fallback_agent]', 'type' => 'select', 'label' => __( 'Fallback agent when no rule matches', 'estat-os' ), 'value' => (int) ( $s['lead_fallback_agent'] ?? 0 ), 'options' => $options ) );
		Partials::field( array( 'name' => 'settings[retention_days]', 'type' => 'number', 'label' => __( 'Auto-erase personal data after days (0 = never)', 'estat-os' ), 'value' => (int) $s['retention_days'], 'min' => 0, 'max' => 3650 ) );
		Partials::field( array( 'name' => 'settings[consent_text]', 'type' => 'textarea', 'rows' => 2, 'label' => __( 'Consent text version', 'estat-os' ), 'value' => $s['consent_text'] ) );
		echo '</div>';

		Partials::card_close();
	}

	/**
	 * Language fields.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function language( array $s ): void {
		$choices = Language::available();

		Partials::card_open( __( 'Language', 'estat-os' ), __( 'Hinglish is written in normal English letters, the way most offices actually speak.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[language]', 'type' => 'select', 'label' => __( 'Language inside the office screens', 'estat-os' ), 'value' => $s['language'], 'options' => array_merge( array( 'auto' => __( 'Follow the website language', 'estat-os' ) ), $choices ) ) );
		Partials::field( array( 'name' => 'settings[frontend_language]', 'type' => 'select', 'label' => __( 'Language on the public website', 'estat-os' ), 'value' => $s['frontend_language'], 'options' => array_merge( array( 'auto' => __( 'Follow the website language', 'estat-os' ) ), $choices ) ) );
		Partials::field( array( 'name' => 'settings[allow_visitor_lang]', 'type' => 'checkbox', 'label' => __( 'Visitor choice', 'estat-os' ), 'checkbox_label' => __( 'Let visitors switch language themselves', 'estat-os' ), 'value' => (bool) $s['allow_visitor_lang'] ) );
		Partials::card_close();

		Partials::card_open( __( 'Adding another language', 'estat-os' ) );
		echo '<p>' . esc_html__( 'Copy the translation file from the plugin\'s languages folder, translate it with a free tool such as Poedit, and save it into wp-content/languages/plugins. It will appear in the list above automatically.', 'estat-os' ) . '</p>';
		Partials::card_close();
	}

	/**
	 * Notification fields — Mayfair #11 event-wise emails + test-mail button.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function emails( array $s ): void {
		Partials::card_open( __( 'When should we email you?', 'estat-os' ), __( 'Choose which events trigger an email.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[notify_email]', 'type' => 'email', 'label' => __( 'Send office emails to', 'estat-os' ), 'value' => $s['notify_email'], 'help' => __( 'Leave empty to use the website administrator address.', 'estat-os' ) ) );
		echo '<p><strong>' . esc_html__( 'Core events', 'estat-os' ) . '</strong></p>';
		Partials::field( array( 'name' => 'settings[notify_new_lead]', 'type' => 'checkbox', 'label' => __( 'New enquiry', 'estat-os' ), 'checkbox_label' => __( 'Email me when someone enquires', 'estat-os' ), 'value' => (bool) $s['notify_new_lead'] ) );
		Partials::field( array( 'name' => 'settings[notify_lead_status]', 'type' => 'checkbox', 'label' => __( 'Lead status changed', 'estat-os' ), 'checkbox_label' => __( 'Email when lead status changes', 'estat-os' ), 'value' => (bool) ( $s['notify_lead_status'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[notify_lead_assigned]', 'type' => 'checkbox', 'label' => __( 'Lead assigned', 'estat-os' ), 'checkbox_label' => __( 'Email when lead assigned to agent', 'estat-os' ), 'value' => (bool) ( $s['notify_lead_assigned'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[notify_new_visit]', 'type' => 'checkbox', 'label' => __( 'Site visit booked', 'estat-os' ), 'checkbox_label' => __( 'Email me when a visit is arranged', 'estat-os' ), 'value' => (bool) $s['notify_new_visit'] ) );
		Partials::field( array( 'name' => 'settings[notify_visit_completed]', 'type' => 'checkbox', 'label' => __( 'Visit completed', 'estat-os' ), 'checkbox_label' => __( 'Email when a site visit is marked completed', 'estat-os' ), 'value' => (bool) ( $s['notify_visit_completed'] ?? false ) ) );
		Partials::field( array( 'name' => 'settings[notify_change_request]', 'type' => 'checkbox', 'label' => __( 'A change asked for from the field', 'estat-os' ), 'checkbox_label' => __( 'Email me when someone proposes a change to a property', 'estat-os' ), 'value' => (bool) $s['notify_change_request'] ) );
		Partials::field( array( 'name' => 'settings[notify_listing_published]', 'type' => 'checkbox', 'label' => __( 'Listing published', 'estat-os' ), 'checkbox_label' => __( 'Email when listing goes live', 'estat-os' ), 'value' => (bool) ( $s['notify_listing_published'] ?? false ) ) );
		Partials::field( array( 'name' => 'settings[notify_listing_verified]', 'type' => 'checkbox', 'label' => __( 'Listing verified', 'estat-os' ), 'checkbox_label' => __( 'Email when Verified badge added', 'estat-os' ), 'value' => (bool) ( $s['notify_listing_verified'] ?? false ) ) );
		Partials::field( array( 'name' => 'settings[notify_project_stage]', 'type' => 'checkbox', 'label' => __( 'Project stage changed', 'estat-os' ), 'checkbox_label' => __( 'Email when project stage changes', 'estat-os' ), 'value' => (bool) ( $s['notify_project_stage'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[notify_form_submitted]', 'type' => 'checkbox', 'label' => __( 'Form submitted', 'estat-os' ), 'checkbox_label' => __( 'Email when custom form submitted', 'estat-os' ), 'value' => (bool) ( $s['notify_form_submitted'] ?? true ) ) );
		Partials::field( array( 'name' => 'settings[notify_alert_created]', 'type' => 'checkbox', 'label' => __( 'Search alert created', 'estat-os' ), 'checkbox_label' => __( 'Email when someone creates search alert', 'estat-os' ), 'value' => (bool) ( $s['notify_alert_created'] ?? false ) ) );
		Partials::field( array( 'name' => 'settings[notify_share]', 'type' => 'checkbox', 'label' => __( 'Property shared', 'estat-os' ), 'checkbox_label' => __( 'Email when property shared', 'estat-os' ), 'value' => (bool) ( $s['notify_share'] ?? false ) ) );
		echo '<hr style="margin:16px 0"/><p><strong>' . esc_html__( 'Maintenance', 'estat-os' ) . '</strong></p>';
		Partials::field( array( 'name' => 'settings[notify_followup]', 'type' => 'checkbox', 'label' => __( 'Follow-up reminders', 'estat-os' ), 'checkbox_label' => __( 'Remind me each morning about follow-ups due today', 'estat-os' ), 'value' => (bool) $s['notify_followup'] ) );
		Partials::field( array( 'name' => 'settings[notify_expiry]', 'type' => 'checkbox', 'label' => __( 'Retired listings', 'estat-os' ), 'checkbox_label' => __( 'Tell me when listings are retired automatically', 'estat-os' ), 'value' => (bool) $s['notify_expiry'] ) );
		Partials::field( array( 'name' => 'settings[notify_import]', 'type' => 'checkbox', 'label' => __( 'Finished imports', 'estat-os' ), 'checkbox_label' => __( 'Tell me when a spreadsheet import finishes', 'estat-os' ), 'value' => (bool) $s['notify_import'] ) );
		Partials::field( array( 'name' => 'settings[notify_webhook_fail]', 'type' => 'checkbox', 'label' => __( 'Connection problems', 'estat-os' ), 'checkbox_label' => __( 'Tell me if a connected app stops receiving data', 'estat-os' ), 'value' => (bool) $s['notify_webhook_fail'] ) );
		Partials::card_close();

		Partials::card_open( __( 'Test your email setup', 'estat-os' ), __( 'Sends a test email to your notification address.', 'estat-os' ) );
		echo '<p><button type="button" class="button" id="estat-test-mail-btn">' . esc_html__( 'Send test email now', 'estat-os' ) . '</button> <span id="estat-test-mail-msg" style="margin-left:8px"></span></p>';
		if ( ! empty( $s['test_mail_last_sent'] ) ) {
			echo '<p class="description">' . sprintf( esc_html__( 'Last sent: %s', 'estat-os' ), esc_html( $s['test_mail_last_sent'] ) ) . '</p>';
		}
		?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const btn = document.getElementById('estat-test-mail-btn');
			if(!btn) return;
			btn.addEventListener('click', function(){
				btn.disabled=true; btn.textContent='Sending...';
				const msg = document.getElementById('estat-test-mail-msg');
				fetch(estatAdmin.ajaxUrl, {
					method:'POST',
					headers:{'Content-Type':'application/x-www-form-urlencoded'},
					body: new URLSearchParams({action:'estat_test_mail', nonce:'<?php echo esc_js( wp_create_nonce( 'estat_test_mail' ) ); ?>'})
				}).then(r=>r.json()).then(j=>{
					if(msg) msg.textContent = j.data?.message || j.message || (j.success ? 'Sent!' : 'Failed');
					if(msg) msg.style.color = j.success ? 'green' : 'red';
				}).catch(()=>{ if(msg) msg.textContent='Network error'; }).finally(()=>{ btn.disabled=false; btn.textContent='Send test email now'; });
			});
		});
		</script>
		<?php
		Partials::card_close();
	}

	/**
	 * Webhook fields.
	 *
	 * @param array<string,mixed> $s Settings.
	 * @return void
	 */
	private static function advanced( array $s ): void {
		$events   = is_array( $s['webhook_events'] ) ? $s['webhook_events'] : array();
		$selected = array_map( 'strval', $events );

		Partials::card_open( __( 'Send your data to another app', 'estat-os' ), __( 'Webhooks for Zapier, Make, CRM etc.', 'estat-os' ) );
		Partials::field( array( 'name' => 'settings[webhook_enabled]', 'type' => 'checkbox', 'label' => __( 'Connection', 'estat-os' ), 'checkbox_label' => __( 'Turn webhooks on', 'estat-os' ), 'value' => (bool) $s['webhook_enabled'] ) );
		Partials::field( array( 'name' => 'settings[webhook_url]', 'type' => 'url', 'label' => __( 'Primary webhook URL', 'estat-os' ), 'value' => $s['webhook_url'], 'example' => 'https://hooks.example.com/estat' ) );
		Partials::field( array( 'name' => 'settings[webhook_url_2]', 'type' => 'url', 'label' => __( 'Secondary webhook URL (optional)', 'estat-os' ), 'value' => $s['webhook_url_2'] ?? '', 'example' => 'https://hooks.example.com/estat2' ) );
		Partials::field( array( 'name' => 'settings[webhook_secret]', 'label' => __( 'Shared secret', 'estat-os' ), 'value' => $s['webhook_secret'], 'help' => __( 'The other app uses this to check the message really came from you. Any long random text works. Sent as X-Estat-Signature = HMAC-SHA256(timestamp.body, secret)', 'estat-os' ) ) );
		Partials::field( array( 'name' => 'settings[webhook_version]', 'type' => 'select', 'label' => __( 'Payload version', 'estat-os' ), 'value' => $s['webhook_version'] ?? 'v2', 'options' => array( 'v1' => 'v1 — basic', 'v2' => 'v2 — includes office_url, estat_version, share_url, print_url, verified, stage progress (F11)' ) ) );
		Partials::field( array( 'name' => 'settings[webhook_retry]', 'type' => 'checkbox', 'label' => __( 'Retry', 'estat-os' ), 'checkbox_label' => __( 'Retry failed deliveries 3 times (every 5 min)', 'estat-os' ), 'value' => (bool) ( $s['webhook_retry'] ?? true ) ) );

		echo '<div class="estat-field-row" style="flex-direction:column;align-items:flex-start"><span class="estat-field-label">' . esc_html__( 'What to send — 12 events (F11)', 'estat-os' ) . '</span><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px;width:100%">';
		foreach ( Webhooks::events() as $event => $label ) {
			printf(
				'<label class="estat-inline-check" style="border:1px solid var(--estat-line);padding:6px 8px;border-radius:6px"><input type="checkbox" name="settings[webhook_events][]" value="%1$s" %2$s /> %3$s<br><small style="color:#666">%1$s</small></label>',
				esc_attr( (string) $event ),
				checked( in_array( (string) $event, $selected, true ), true, false ),
				esc_html( (string) $label )
			);
		}
		echo '</div></div>';
		echo '<p class="description">' . esc_html__( 'Every message is signed so the receiving app can confirm it is genuine. v2 adds office_url, estat_version, share_url, print_url, verified, is_new, stage progress.', 'estat-os' ) . '</p>';
		// Test webhook button
		echo '<p><button type="button" class="button" id="estat-test-webhook-btn">' . esc_html__( 'Send test webhook now', 'estat-os' ) . '</button> <span id="estat-test-webhook-msg" style="margin-left:8px"></span></p>';
		?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const btn = document.getElementById('estat-test-webhook-btn');
			if(!btn) return;
			btn.addEventListener('click', function(){
				btn.disabled=true; btn.textContent='Sending...';
				const msg = document.getElementById('estat-test-webhook-msg');
				fetch(estatAdmin.ajaxUrl, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: new URLSearchParams({action:'estat_test_webhook', nonce:'<?php echo esc_js( wp_create_nonce( 'estat_test_webhook' ) ); ?>'})})
				.then(r=>r.json()).then(j=>{
					if(msg) msg.textContent = j.data?.message || j.message || (j.success ? 'Sent! code '+j.data?.code : 'Failed');
					if(msg) msg.style.color = j.success ? 'green' : 'red';
				}).catch(()=>{ if(msg) msg.textContent='Network error'; }).finally(()=>{ btn.disabled=false; btn.textContent='Send test webhook now'; });
			});
		});
		</script>
		<?php
		// Recent log
		$logs = \EstatOS\Webhooks\Webhooks::recent( 10 );
		if ( $logs ) {
			echo '<h4>' . esc_html__( 'Recent deliveries (last 10)', 'estat-os' ) . '</h4>';
			echo '<table class="widefat striped" style="font-size:12px"><thead><tr><th>Time</th><th>Event</th><th>Object</th><th>Code</th><th>Success</th><th>Attempt</th><th>Error</th></tr></thead><tbody>';
			foreach ( $logs as $row ) {
				echo '<tr><td>' . esc_html( $row['created_at'] ) . '</td><td>' . esc_html( $row['event'] ) . '</td><td>' . esc_html( (string) $row['object_id'] ) . '</td><td>' . esc_html( (string) $row['status_code'] ) . '</td><td>' . ( $row['success'] ? '✅' : '❌' ) . '</td><td>' . esc_html( (string) $row['attempt'] ) . '</td><td>' . esc_html( mb_substr( $row['error'] ?? '', 0, 80 ) ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		Partials::card_close();

		Partials::card_open( __( 'Access for other software', 'estat-os' ) );
		echo '<p>' . esc_html__( 'Developers can read and write your office data through these addresses, using a normal WordPress application password (Users → Profile → Application Passwords):', 'estat-os' ) . '</p>';
		echo '<p><strong>v1 (stable):</strong> <code class="estat-copyable">' . esc_html( rest_url( 'estat/v1/' ) ) . '</code> — properties, agents, leads, visits, forms, alerts, share</p>';
		echo '<p><strong>v2 (Mayfair F11 — includes share_url, print_url, verified, is_new, EMI, localities, amenities, features, stages, filters, webhook log, OpenAPI):</strong> <code class="estat-copyable">' . esc_html( rest_url( 'estat/v2/' ) ) . '</code></p>';
		echo '<p><code class="estat-copyable">' . esc_html( rest_url( 'estat/v2/openapi' ) ) . '</code> — OpenAPI 3.0 spec</p>';
		echo '<details style="margin-top:12px"><summary style="cursor:pointer;font-weight:600">API examples (F11)</summary>';
		echo '<pre style="background:#f6f7f7;padding:12px;border-radius:8px;overflow:auto;font-size:12px">';
		echo esc_html( "GET /wp-json/estat/v2/properties?keyword=3BHK&price_max=20000000&amenities[]=5&verified=1\nGET /wp-json/estat/v2/properties/123 — detail with share_url, print_url, localities, amenities, features\nGET /wp-json/estat/v2/projects — with stage_label, progress\nGET /wp-json/estat/v2/projects/stages — Planning/UC/Ready order & progress\nGET /wp-json/estat/v2/localities — id, name, slug, count, url\nGET /wp-json/estat/v2/amenities — same\nGET /wp-json/estat/v2/features\nGET /wp-json/estat/v2/filters — enabled, ordered, all (23)\nGET /wp-json/estat/v2/forms — id, name, shortcode\nGET /wp-json/estat/v2/webhooks/log — recent deliveries (needs estat_manage_settings)\nPOST /wp-json/estat/v1/alerts — {email, name, filters}\nPOST /wp-json/estat/v1/share — {listing_id, channel}\nWebhook headers: X-Estat-Event, X-Estat-Version, X-Estat-Timestamp, X-Estat-Signature=sha256=HMAC\n" );
		echo '</pre></details>';
		Partials::card_close();

		Partials::card_open(
			__( 'Let another form tool send you enquiries', 'estat-os' ),
			__( 'Only needed if you already build forms with Elementor Pro or another plugin and want those to land in your Enquiries inbox.', 'estat-os' )
		);

		Partials::field(
			array(
				'name'  => 'inbound_secret',
				'label' => __( 'Secret key', 'estat-os' ),
				'value' => (string) $s['inbound_secret'],
				'help'  => __( 'Make up a long phrase and paste it into the other tool. Leave this empty to keep incoming enquiries switched off.', 'estat-os' ),
			)
		);

		echo '<p>' . esc_html__( 'In Elementor Pro: open your form, go to Actions After Submit, add "Webhook", and paste this address:', 'estat-os' ) . '</p>';
		echo '<code class="estat-copyable">' . esc_html( rest_url( 'estat/v1/enquiries' ) ) . '</code>';
		echo '<p class="description">' . esc_html__( 'Then add a hidden field called "secret" holding the key above. Name your other boxes name, phone, email and message so we know what they are.', 'estat-os' ) . '</p>';

		Partials::card_close();
	}

	/**
	 * Maintenance tools and the danger zone.
	 *
	 * @return void
	 */
	private static function tools(): void {
		$s      = Settings::all();
		$status = SearchIndex::status();
		$url    = admin_url( 'admin.php?page=estat-settings&tab=tools' );

		// Public pages now live under Pages tab as drafts only
		Partials::card_open( __( 'Public pages', 'estat-os' ), __( 'Use Settings → Pages to create helper pages as drafts.', 'estat-os' ) );
		echo '<p class="description">' . esc_html__( 'Pages are created as drafts and need a click to publish.', 'estat-os' ) . '</p>';
		Partials::card_close();

		Partials::card_open( __( 'Keep things running smoothly', 'estat-os' ) );
		echo '<div class="estat-stats">';
		Partials::stat( __( 'Properties', 'estat-os' ), (string) (int) $status['listings'], '', 'plain' );
		Partials::stat( __( 'Ready for searching', 'estat-os' ), (string) (int) $status['indexed'], '', $status['in_sync'] ? 'good' : 'warn' );
		echo '</div>';
		echo '<p>' . esc_html__( 'If search results look wrong or out of date, rebuilding the search list usually fixes it. It is completely safe and changes nothing about your properties.', 'estat-os' ) . '</p>';
		echo '<p class="estat-quick-actions">';
		self::tool_button( 'rebuild_index', __( 'Rebuild the search list', 'estat-os' ), $url );
		self::tool_button( 'repair_tables', __( 'Repair the office database', 'estat-os' ), $url );
		self::tool_button( 'clear_cache', __( 'Clear temporary data', 'estat-os' ), $url );
		self::tool_button( 'run_housekeeping', __( 'Run the daily jobs now', 'estat-os' ), $url );
		echo '</p>';
		Partials::card_close();

		Partials::card_open( __( 'Fix broken data from 3.0.6', 'estat-os' ), __( 'One-click repair for two known issues: locality terms split by comma and 13 helper pages auto-published.', 'estat-os' ) );
		echo '<p>' . esc_html__( 'This will:', 'estat-os' ) . '</p>';
		echo '<ul style="list-style:disc;margin-left:20px">';
		echo '<li>' . esc_html__( 'Merge locality terms "Sohna Road (Sector 49" + "Uppal Southend)" into "Sohna Road (Sector 49, Uppal Southend)" and reassign listings.', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'Find any locality with unbalanced brackets and flag it (safe, no delete).', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'Draft pages IDs 8193-8205 (search, projects, team, localities, amenities, favorites, compare, emi, alerts, office, etc) if they are published — code alone cannot fix existing DB.', 'estat-os' ) . '</li>';
		echo '</ul>';
		echo '<p class="description">' . esc_html__( 'Idempotent — safe to run multiple times. Does not delete data, only merges terms and drafts pages.', 'estat-os' ) . '</p>';
		echo '<p class="estat-quick-actions">';
		self::tool_button( 'repair_broken_data', __( 'Repair broken localities + draft helper pages (3.0.6 → 3.0.7)', 'estat-os' ), $url );
		echo '</p>';
		Partials::card_close();

		Partials::card_open( __( 'Practice mode', 'estat-os' ), __( 'Fill the office with realistic sample properties so you can learn safely. Everything created this way is clearly marked and can be removed in one click.', 'estat-os' ) );
		echo '<p>';
		echo $s['practice_mode'] ? esc_html__( 'Practice mode is on.', 'estat-os' ) : esc_html__( 'Practice mode is off.', 'estat-os' );
		echo '</p>';
		echo '<p class="estat-quick-actions">';
		self::tool_button( 'seed_practice', __( 'Add sample data', 'estat-os' ), $url );
		self::tool_button( 'clear_practice', __( 'Remove all sample data', 'estat-os' ), $url );
		echo '</p>';
		Partials::card_close();

		Partials::card_open( __( 'If you ever remove this plugin', 'estat-os' ) );
		?>
		<form method="post" class="estat-form-admin" action="<?php echo esc_url( $url ); ?>">
			<?php wp_nonce_field( 'estat_save_settings', 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="save_settings" />
			<input type="hidden" name="tab" value="tools" />
			<p><?php esc_html_e( 'By default your properties, enquiries and visits stay exactly where they are, even if the plugin is deleted. Nothing is ever thrown away without you asking.', 'estat-os' ); ?></p>
			<?php
			Partials::field(
				array(
					'name'           => 'settings[delete_data_on_uninstall]',
					'type'           => 'checkbox',
					'label'          => __( 'Deleting the plugin', 'estat-os' ),
					'checkbox_label' => __( 'Also erase all office data when the plugin is deleted', 'estat-os' ),
					'value'          => (bool) $s['delete_data_on_uninstall'],
					'help'           => __( 'This cannot be undone. Only tick this if you have exported anything you want to keep.', 'estat-os' ),
				)
			);
			?>
			<button type="submit" class="button"><?php esc_html_e( 'Save this choice', 'estat-os' ); ?></button>
		</form>
		<?php
		Partials::card_close();

		Partials::diagnostics();
	}

	/**
	 * Pages tab — create helper pages as drafts only, never publish automatically.
	 *
	 * @return void
	 */
	private static function pages_tab(): void {
		$url = admin_url( 'admin.php?page=estat-settings&tab=pages' );
		Partials::card_open( __( 'Helper pages', 'estat-os' ), __( 'Create pages as drafts. You review and publish them manually.', 'estat-os' ) );
		echo \EstatOS\Frontend\Pages::admin_list_html();
		echo '<p class="estat-quick-actions" style="margin-top:12px">';
		self::tool_button( 'create_public_pages', __( 'Create helper pages as drafts', 'estat-os' ), $url );
		echo '</p>';
		echo '<p class="description">' . esc_html__( 'Creates pages like /properties, /search, /projects, /team etc as drafts. If a page already exists by slug, it is kept. No pages are published automatically.', 'estat-os' ) . '</p>';
		Partials::card_close();

		// Also show Install\Pages catalogue if needed
		if ( class_exists( \EstatOS\Install\Pages::class ) ) {
			$existing = \EstatOS\Install\Pages::existing();
			if ( $existing ) {
				Partials::card_open( __( 'Existing pages map', 'estat-os' ) );
				echo '<ul>';
				foreach ( $existing as $k => $id ) {
					echo '<li>' . esc_html( $k . ' → ' . $id ) . ' <a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html__( 'Edit', 'estat-os' ) . '</a></li>';
				}
				echo '</ul>';
				Partials::card_close();
			}
		}
	}

	/**
	 * A single nonce-protected maintenance button.
	 *
	 * @param string $action Action key.
	 * @param string $label  Button label.
	 * @param string $url    Return URL.
	 * @return void
	 */
	private static function tool_button( string $action, string $label, string $url ): void {
		?>
		<form method="post" class="estat-inline-form" action="<?php echo esc_url( $url ); ?>">
			<?php wp_nonce_field( 'estat_tool_' . $action, 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="<?php echo esc_attr( $action ); ?>" />
			<button type="submit" class="button"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}
}
