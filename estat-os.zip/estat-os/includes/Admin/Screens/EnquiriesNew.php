<?php
/**
 * Enquiries — Stitch Mayfair Atelier redesign.
 * Simplified menu: secondary tabs for Pipeline, Visits, Requests, Search Alerts, Forms.
 * Real data only.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Leads\Leads;
use EstatOS\Leads\LeadEvents;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class EnquiriesNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) && ! current_user_can( 'estat_agent' ) ) {
			wp_die( esc_html__( 'You do not have permission to see enquiries.', 'estat-os' ) );
		}

		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( is_array($_GET['status']) ? '' : $_GET['status'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$intent = isset( $_GET['intent'] ) ? sanitize_key( wp_unslash( is_array($_GET['intent']) ? '' : $_GET['intent'] ) ) : '';
		$selected_id = isset( $_GET['lead_id'] ) ? absint( wp_unslash( is_array($_GET['lead_id']) ? '' : $_GET['lead_id'] ) ) : 0;
		// phpcs:enable

		$results = Leads::query( array( 'status'=>$status,'intent'=>$intent,'search'=>$search,'page'=>$paged,'per_page'=>20 ) );
		$counts = Leads::counts();
		$s = Settings::all();
		$city = (string) ( $s['city'] ?? $s['cities'][0] ?? '' );

		$selected = null;
		if ( $selected_id > 0 ) { $selected = Leads::get( $selected_id ); }
		if ( ! $selected && ! empty( $results['items'][0] ) ) { $selected = $results['items'][0]; $selected_id = (int) $selected['id']; }

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb">
					<span><?php esc_html_e( 'Portfolio', 'estat-os' ); ?></span><span>/</span><span><?php esc_html_e( 'Enquiries', 'estat-os' ); ?></span><span>/</span><span class="is-muted"><?php esc_html_e( 'Inbox', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-header-row">
					<div>
						<h1 class="estat-stitch-h1"><?php esc_html_e( 'Enquiries', 'estat-os' ); ?></h1>
						<p class="estat-stitch-desc"><?php echo esc_html( sprintf( __( '%d enquiries in total', 'estat-os' ), (int) ( $results['total'] ?? 0 ) ) ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-stitch-header-actions">
						<?php echo NewUI::toggle_markup(); // phpcs:ignore ?>
						<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=estat-enquiries&estat_action=export_csv&what=leads' ), 'estat_export_csv', 'estat_nonce' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">download</span> <?php esc_html_e( 'Export CSV', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php
				$sub = array(
					'estat-enquiries' => __( 'Inbox', 'estat-os' ),
					'estat-pipeline' => __( 'Pipeline', 'estat-os' ),
					'estat-visits' => __( 'Site Visits', 'estat-os' ),
					'estat-requests' => __( 'Change Requests', 'estat-os' ),
					'estat-search-alerts' => __( 'Search Alerts', 'estat-os' ),
					'estat-forms' => __( 'Forms', 'estat-os' ),
				);
				foreach ( $sub as $slug=>$label ) {
					$is_active = 'estat-enquiries' === $slug;
					$url = admin_url( 'admin.php?page=' . $slug );
					echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>';
				}
				?>
			</div>

			<div class="estat-stitch-metrics is-5">
				<?php foreach ( array( 'new'=>__( 'New', 'estat-os' ), 'contacted'=>__( 'Contacted', 'estat-os' ), 'scheduled'=>__( 'Scheduled', 'estat-os' ), 'won'=>__( 'Won', 'estat-os' ), 'lost'=>__( 'Lost', 'estat-os' ) ) as $k=>$label ) : ?>
				<div class="estat-stitch-metric"><span class="estat-stitch-metric-label"><?php echo esc_html( $label ); ?></span><div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) ( $counts[ $k ] ?? 0 ) ); ?></span></div></div>
				<?php endforeach; ?>
			</div>

			<div class="estat-stitch-controls">
				<div class="estat-stitch-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search">
						<input type="hidden" name="page" value="estat-enquiries" />
						<span class="material-symbols-outlined">search</span>
						<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search by name, phone or email', 'estat-os' ); ?>" />
					</form>
				</div>
				<div class="estat-stitch-filters">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-filters-form">
						<input type="hidden" name="page" value="estat-enquiries" />
						<?php if ( '' !== $search ) : ?><input type="hidden" name="s" value="<?php echo esc_attr( $search ); ?>" /><?php endif; ?>
						<select name="status"><option value=""><?php esc_html_e( 'All statuses', 'estat-os' ); ?></option><?php foreach ( Vocabulary::lead_statuses() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $status, $k ); ?>><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select>
						<select name="intent"><option value=""><?php esc_html_e( 'All intents', 'estat-os' ); ?></option><?php foreach ( Vocabulary::lead_intents() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $intent, $k ); ?>><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select>
						<button type="submit" class="estat-stitch-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>" class="estat-stitch-link"><span class="material-symbols-outlined">refresh</span> <?php esc_html_e( 'Reset', 'estat-os' ); ?></a>
					</form>
				</div>
			</div>

			<div class="estat-stitch-enquiries-layout">
				<div class="estat-stitch-table-wrap is-inbox">
					<?php if ( empty( $results['items'] ) ) : ?>
						<div class="estat-stitch-empty"><?php esc_html_e( 'No enquiries yet.', 'estat-os' ); ?></div>
					<?php else : ?>
						<div class="estat-stitch-inbox-list">
							<?php foreach ( $results['items'] as $lead ) : $is_active = (int) $lead['id'] === $selected_id; ?>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries&lead_id=' . (int) $lead['id'] . '&s=' . urlencode( $search ) . '&status=' . urlencode( $status ) ) ); ?>" class="estat-stitch-inbox-item <?php echo $is_active ? 'is-active' : ''; ?>">
								<div class="estat-stitch-inbox-head"><span class="estat-stitch-inbox-name"><?php echo esc_html( $lead['name'] ?: __( 'No name', 'estat-os' ) ); ?></span><span class="estat-stitch-status is-<?php echo esc_attr( $lead['status'] ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( $lead['status'] ); ?></span></div>
								<div class="estat-stitch-inbox-meta"><span><?php echo esc_html( $lead['phone'] ?: $lead['email'] ); ?></span><span class="estat-stitch-date"><?php echo esc_html( $lead['created_at'] ?? '' ); ?></span></div>
								<?php if ( ! empty( $lead['message'] ) ) : ?><div class="estat-stitch-inbox-excerpt"><?php echo esc_html( mb_strimwidth( (string) $lead['message'], 0, 80, '…' ) ); ?></div><?php endif; ?>
							</a>
							<?php endforeach; ?>
						</div>
						<div class="estat-stitch-pagination"><span><?php echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'estat-os' ), $paged, (int) ( $results['pages'] ?? 1 ) ) ); ?></span><div class="estat-stitch-pager"><?php echo paginate_links( array( 'base'=>add_query_arg('paged','%#%'), 'format'=>'', 'current'=>$paged, 'total'=>(int)( $results['pages'] ?? 1 ) ) ); ?></div></div>
					<?php endif; ?>
				</div>

				<div class="estat-stitch-enquiries-detail">
					<?php if ( ! $selected ) : ?>
						<div class="estat-stitch-card-panel"><p class="estat-stitch-muted"><?php esc_html_e( 'Select an enquiry to see details.', 'estat-os' ); ?></p></div>
					<?php else : $events = LeadEvents::for_lead( (int) $selected['id'] ); $visits = Visits::query( array( 'lead_id'=>(int) $selected['id'], 'per_page'=>10 ) ); ?>
						<div class="estat-stitch-card-panel">
							<div class="estat-stitch-panel-header"><h2><?php echo esc_html( $selected['name'] ); ?></h2><span class="estat-stitch-status is-<?php echo esc_attr( $selected['status'] ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( $selected['status'] ); ?></span></div>
							<div class="estat-stitch-detail-grid">
								<?php if ( $selected['phone'] ) : ?><div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Phone', 'estat-os' ); ?></span><br><a href="tel:<?php echo esc_attr( $selected['phone'] ); ?>"><?php echo esc_html( $selected['phone'] ); ?></a></div><?php endif; ?>
								<?php if ( $selected['email'] ) : ?><div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Email', 'estat-os' ); ?></span><br><a href="mailto:<?php echo esc_attr( $selected['email'] ); ?>"><?php echo esc_html( $selected['email'] ); ?></a></div><?php endif; ?>
								<?php if ( $selected['listing_id'] ) : ?><div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Property', 'estat-os' ); ?></span><br><a href="<?php echo esc_url( get_edit_post_link( (int) $selected['listing_id'] ) ); ?>">#<?php echo esc_html( (string) $selected['listing_id'] ); ?> <?php echo esc_html( get_the_title( (int) $selected['listing_id'] ) ); ?></a></div><?php endif; ?>
								<div><span class="estat-stitch-metric-label"><?php esc_html_e( 'Intent', 'estat-os' ); ?></span><br><?php echo esc_html( $selected['intent'] ?? '—' ); ?></div>
							</div>
							<?php if ( ! empty( $selected['message'] ) ) : ?><div class="estat-stitch-enquiry-msg" style="margin-top:12px"><?php echo esc_html( $selected['message'] ); ?></div><?php endif; ?>
						</div>

						<div class="estat-stitch-card-panel" style="margin-top:16px">
							<div class="estat-stitch-panel-header"><span class="material-symbols-outlined">history</span><h2><?php esc_html_e( 'Timeline', 'estat-os' ); ?></h2></div>
							<?php if ( empty( $events ) ) : ?><p class="estat-stitch-muted"><?php esc_html_e( 'No events yet.', 'estat-os' ); ?></p><?php else : ?><div class="estat-stitch-timeline"><?php foreach ( $events as $ev ) : ?><div class="estat-stitch-timeline-item"><span class="estat-stitch-timeline-dot"></span><div><strong><?php echo esc_html( $ev['type'] ?? $ev['event'] ?? '' ); ?></strong> <span class="estat-stitch-date"><?php echo esc_html( $ev['created_at'] ?? '' ); ?></span><?php if ( ! empty( $ev['note'] ) ) : ?><div class="estat-stitch-muted"><?php echo esc_html( $ev['note'] ); ?></div><?php endif; ?></div></div><?php endforeach; ?></div><?php endif; ?>
						</div>

						<div class="estat-stitch-card-panel" style="margin-top:16px">
							<div class="estat-stitch-panel-header"><span class="material-symbols-outlined">calendar_today</span><h2><?php esc_html_e( 'Visits', 'estat-os' ); ?></h2></div>
							<?php if ( empty( $visits['items'] ) ) : ?><p class="estat-stitch-muted"><?php esc_html_e( 'No visits scheduled.', 'estat-os' ); ?></p><?php else : ?><ul style="margin:0;padding-left:16px"><?php foreach ( $visits['items'] as $v ) : ?><li><?php echo esc_html( $v['scheduled_at'] ?? '' ); ?> — <?php echo esc_html( $v['outcome'] ?? $v['status'] ?? '' ); ?></li><?php endforeach; ?></ul><?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
