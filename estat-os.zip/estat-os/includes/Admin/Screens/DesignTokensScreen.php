<?php
/**
 * Design Tokens screen — colours / fonts / spacing in one place (F7 polished).
 *
 * Mayfair #7: Design tokens screen + Templates drag order.
 * All colours, spacing and fonts live in tokens.css. This screen lets you override them without editing code.
 * F7: live preview, custom tokens, export CSS, reset, grouped sections.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class DesignTokensScreen {

	/**
	 * Render.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		if ( isset( $_POST['estat_save_tokens'] ) && check_admin_referer( 'estat_tokens', 'estat_nonce' ) ) {
			$raw = isset( $_POST['tokens'] ) && is_array( $_POST['tokens'] ) ? $_POST['tokens'] : array();
			$tokens = array();
			foreach ( $raw as $k => $v ) {
				$k = sanitize_key( (string) $k );
				// Allow -- prefix but sanitize_key strips -, so handle specially.
				// We accept keys like --estat-accent, sanitize as -- + sanitize_key.
				$orig_k = (string) $k;
				// Reconstruct with -- if original had it.
				if ( isset( $_POST['tokens_raw_keys'] ) && is_array( $_POST['tokens_raw_keys'] ) ) {
					// Use raw keys mapping.
				}
				$v = sanitize_text_field( (string) $v );
				if ( '' !== $orig_k && '' !== $v ) {
					// Restore -- prefix if needed.
					$save_key = $orig_k;
					// If key doesn't start with --, add if it looks like estat var.
					if ( 0 !== strpos($save_key, '--') && 0 === strpos($save_key, 'estat') ) {
						$save_key = '--' . $save_key;
					}
					// For custom keys, keep as is from extra inputs.
					$tokens[ $save_key ] = $v;
				}
			}
			// Handle extra custom tokens: tokens_extra_key_0, tokens_extra_val_0 etc.
			for ( $i = 0; $i < 10; $i++ ) {
				$ek = isset( $_POST[ 'tokens_extra_key_' . $i ] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST[ 'tokens_extra_key_' . $i ]) ? '' : $_POST[ 'tokens_extra_key_' . $i ] ) ) ) : '';
				$ev = isset( $_POST[ 'tokens_extra_val_' . $i ] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST[ 'tokens_extra_val_' . $i ]) ? '' : $_POST[ 'tokens_extra_val_' . $i ] ) ) ) : '';
				if ( '' !== $ek && '' !== $ev ) {
					$ek = trim( $ek );
					if ( 0 !== strpos($ek, '--') ) {
						$ek = '--' . ltrim( $ek, '-' );
					}
					$tokens[ $ek ] = $ev;
				}
			}
			// Handle raw keys for --estat- vars (since sanitize_key strips --).
			$raw_keys = isset( $_POST['tokens_raw_keys'] ) && is_array( $_POST['tokens_raw_keys'] ) ? (array) wp_unslash( is_array($_POST['tokens_raw_keys']) ? '' : $_POST['tokens_raw_keys'] ) : array();
			$final_tokens = array();
			foreach ( $tokens as $k => $v ) {
				// If k is like estat-accent, convert to --estat-accent.
				if ( 0 !== strpos($k, '--') ) {
					$k = '--' . ltrim( $k, '-' );
				}
				$final_tokens[ $k ] = $v;
			}
			// Merge with raw_keys mapping to preserve exact -- names.
			foreach ( $raw_keys as $idx => $raw_key ) {
				$raw_key = sanitize_text_field( (string) $raw_key );
				if ( '' === $raw_key ) { continue; }
				// Find corresponding value from tokens array by idx? Instead use tokens array order.
				// We'll use the posted tokens values by index.
				$val_key = 'tokens_val_' . $idx;
				if ( isset( $_POST[ $val_key ] ) ) {
					$val = sanitize_text_field( wp_unslash( (string) ( is_array($_POST[ $val_key ]) ? '' : $_POST[ $val_key ] ) ) );
					if ( '' !== $val ) {
						if ( 0 !== strpos($raw_key, '--') ) {
							$raw_key = '--' . ltrim( $raw_key, '-' );
						}
						$final_tokens[ $raw_key ] = $val;
					}
				}
			}

			// Actually simpler: rebuild from posted tokens with explicit raw keys list.
			// The form below posts tokens as associative but we also post raw list; we will use raw list for final.
			// Let's re-parse from $_POST['tokens'] with raw keys if available.
			if ( ! empty( $raw_keys ) ) {
				$final_tokens = array();
				foreach ( $raw_keys as $rk ) {
					$rk = trim( (string) $rk );
					if ( '' === $rk ) { continue; }
					// Value is in $_POST['tokens'][sanitized_key] — we need to map.
					$sanitized = sanitize_key( $rk );
					$sanitized = ltrim( $sanitized, '-' );
					// Try to find value.
					$val = $raw[ $sanitized ] ?? $raw[ $rk ] ?? '';
					if ( is_string( $val ) ) {
						$val = sanitize_text_field( $val );
					}
					if ( '' !== $val ) {
						if ( 0 !== strpos($rk, '--') ) {
							$rk = '--' . ltrim( $rk, '-' );
						}
						$final_tokens[ $rk ] = $val;
					}
				}
				// Add extras again.
				for ( $i = 0; $i < 10; $i++ ) {
					$ek = isset( $_POST[ 'tokens_extra_key_' . $i ] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST[ 'tokens_extra_key_' . $i ]) ? '' : $_POST[ 'tokens_extra_key_' . $i ] ) ) ) : '';
					$ev = isset( $_POST[ 'tokens_extra_val_' . $i ] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST[ 'tokens_extra_val_' . $i ]) ? '' : $_POST[ 'tokens_extra_val_' . $i ] ) ) ) : '';
					if ( '' !== $ek && '' !== $ev ) {
						$ek = trim( $ek );
						if ( 0 !== strpos($ek, '--') ) {
							$ek = '--' . ltrim( $ek, '-' );
						}
						$final_tokens[ $ek ] = $ev;
					}
				}
			} else {
				$final_tokens = $tokens;
			}

			Settings::update( array( 'design_tokens' => $final_tokens ) );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Design tokens saved. They apply to Office, Pocket (/agent) and public pages instantly.', 'estat-os' ) . '</p></div>';
		}

		if ( isset( $_POST['estat_reset_tokens'] ) && check_admin_referer( 'estat_tokens', 'estat_nonce' ) ) {
			Settings::update( array( 'design_tokens' => array() ) );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Design tokens reset to defaults from tokens.css.', 'estat-os' ) . '</p></div>';
		}

		$tokens = Settings::get( 'design_tokens', array() );

		// Full token list from tokens.css with grouping.
		$groups = array(
			'Text' => array(
				'--estat-ink'       => array( 'default' => '#16202c', 'type' => 'color', 'label' => 'Ink (main text)' ),
				'--estat-ink-soft'  => array( 'default' => '#3d4b5c', 'type' => 'color', 'label' => 'Ink soft (secondary)' ),
				'--estat-muted'     => array( 'default' => '#616c7c', 'type' => 'color', 'label' => 'Muted (hints)' ),
				'--estat-faint'     => array( 'default' => '#93a0b1', 'type' => 'color', 'label' => 'Faint (borders, decoration)' ),
				'--estat-text-xs'   => array( 'default' => '11px', 'type' => 'text', 'label' => 'Text XS' ),
				'--estat-text-sm'   => array( 'default' => '12px', 'type' => 'text', 'label' => 'Text SM' ),
				'--estat-text'      => array( 'default' => '13px', 'type' => 'text', 'label' => 'Text base' ),
				'--estat-text-md'   => array( 'default' => '15px', 'type' => 'text', 'label' => 'Text MD' ),
				'--estat-text-lg'   => array( 'default' => '17px', 'type' => 'text', 'label' => 'Text LG' ),
				'--estat-text-xl'   => array( 'default' => '22px', 'type' => 'text', 'label' => 'Text XL' ),
				'--estat-text-2xl'  => array( 'default' => '28px', 'type' => 'text', 'label' => 'Text 2XL' ),
			),
			'Surfaces' => array(
				'--estat-bg'        => array( 'default' => '#f4f6f9', 'type' => 'color', 'label' => 'Background' ),
				'--estat-card'      => array( 'default' => '#fdfdfe', 'type' => 'color', 'label' => 'Card' ),
				'--estat-card-alt'  => array( 'default' => '#f8fafc', 'type' => 'color', 'label' => 'Card alt' ),
				'--estat-sunken'    => array( 'default' => '#eef1f6', 'type' => 'color', 'label' => 'Sunken' ),
				'--estat-line'      => array( 'default' => '#e3e8ef', 'type' => 'color', 'label' => 'Line' ),
				'--estat-line-strong'=> array( 'default' => '#cfd7e3', 'type' => 'color', 'label' => 'Line strong' ),
			),
			'Brand & States' => array(
				'--estat-accent'      => array( 'default' => '#2768e8', 'type' => 'color', 'label' => 'Accent (primary)' ),
				'--estat-accent-soft' => array( 'default' => '#eaf1fe', 'type' => 'color', 'label' => 'Accent soft' ),
				'--estat-accent-ink'  => array( 'default' => '#1a4fbd', 'type' => 'color', 'label' => 'Accent ink' ),
				'--estat-on-accent'   => array( 'default' => '#f8fafd', 'type' => 'color', 'label' => 'Text on accent' ),
				'--estat-good'        => array( 'default' => '#107a53', 'type' => 'color', 'label' => 'Good (verified, success)' ),
				'--estat-good-soft'   => array( 'default' => '#e6f7ef', 'type' => 'color', 'label' => 'Good soft' ),
				'--estat-warn'        => array( 'default' => '#985f09', 'type' => 'color', 'label' => 'Warn' ),
				'--estat-warn-soft'   => array( 'default' => '#fdf3e2', 'type' => 'color', 'label' => 'Warn soft' ),
				'--estat-danger'      => array( 'default' => '#c0392f', 'type' => 'color', 'label' => 'Danger' ),
				'--estat-danger-soft' => array( 'default' => '#fdeceb', 'type' => 'color', 'label' => 'Danger soft' ),
			),
			'Shape & Depth' => array(
				'--estat-radius'      => array( 'default' => '12px', 'type' => 'text', 'label' => 'Radius' ),
				'--estat-radius-sm'   => array( 'default' => '8px', 'type' => 'text', 'label' => 'Radius SM' ),
				'--estat-radius-lg'   => array( 'default' => '16px', 'type' => 'text', 'label' => 'Radius LG' ),
				'--estat-radius-pill' => array( 'default' => '999px', 'type' => 'text', 'label' => 'Radius pill' ),
				'--estat-shadow-sm'   => array( 'default' => '0 1px 2px rgba(16,24,40,0.04)', 'type' => 'text', 'label' => 'Shadow SM' ),
				'--estat-shadow'      => array( 'default' => '0 1px 3px rgba(16,24,40,0.05)', 'type' => 'text', 'label' => 'Shadow' ),
				'--estat-shadow-lg'   => array( 'default' => '0 4px 10px rgba(16,24,40,0.06)', 'type' => 'text', 'label' => 'Shadow LG' ),
				'--estat-gap-xs'      => array( 'default' => '4px', 'type' => 'text', 'label' => 'Gap XS' ),
				'--estat-gap-sm'      => array( 'default' => '8px', 'type' => 'text', 'label' => 'Gap SM' ),
				'--estat-gap'         => array( 'default' => '16px', 'type' => 'text', 'label' => 'Gap' ),
				'--estat-gap-md'      => array( 'default' => '20px', 'type' => 'text', 'label' => 'Gap MD' ),
				'--estat-gap-lg'      => array( 'default' => '28px', 'type' => 'text', 'label' => 'Gap LG' ),
				'--estat-gap-xl'      => array( 'default' => '40px', 'type' => 'text', 'label' => 'Gap XL' ),
			),
		);

		// Build CSS export.
		$export_css = ":root {\n";
		foreach ( $groups as $group => $vars ) {
			$export_css .= "  /* {$group} */\n";
			foreach ( $vars as $var => $info ) {
				$val = $tokens[ $var ] ?? $info['default'];
				$export_css .= "  {$var}: {$val};\n";
			}
		}
		// Custom tokens.
		foreach ( $tokens as $k => $v ) {
			$found = false;
			foreach ( $groups as $g ) { if ( isset( $g[ $k ] ) ) { $found = true; break; } }
			if ( ! $found ) {
				$export_css .= "  {$k}: {$v};\n";
			}
		}
		$export_css .= "}\n";

		echo '<div class="wrap estat-admin">';
		echo '<h1>' . esc_html__( 'Design Tokens — One Place for Colours & Fonts (F7)', 'estat-os' ) . '</h1>';
		echo '<p class="estat-muted">' . esc_html__( 'All colours, spacing and fonts live in tokens.css. This screen overrides them without editing code. Overrides apply to Office, Pocket (/agent) and public pages instantly. Mayfair #7.', 'estat-os' ) . '</p>';

		// Live preview.
		echo '<div style="display:flex;gap:16px;flex-wrap:wrap;margin:16px 0">';
		echo '<div style="flex:1;min-width:280px;border:1px solid var(--estat-line);border-radius:var(--estat-radius);padding:16px;background:var(--estat-card)">';
		echo '<h3 style="margin:0 0 8px">Live preview</h3>';
		echo '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">';
		echo '<span style="display:inline-block;padding:6px 12px;border-radius:var(--estat-radius-pill);background:var(--estat-accent);color:var(--estat-on-accent)">Primary button</span>';
		echo '<span style="display:inline-block;padding:6px 12px;border-radius:var(--estat-radius);background:var(--estat-good-soft);color:var(--estat-good);border:1px solid var(--estat-line)">✓ humne khud dekha</span>';
		echo '<span style="display:inline-block;padding:6px 12px;border-radius:var(--estat-radius);background:var(--estat-warn-soft);color:var(--estat-warn)">Warn</span>';
		echo '</div>';
		echo '<div style="border:1px solid var(--estat-line);border-radius:var(--estat-radius);padding:12px;background:var(--estat-bg);margin-bottom:12px">';
		echo '<div style="font-size:var(--estat-text-lg);color:var(--estat-ink);font-weight:600">Card title — 17px / ink</div>';
		echo '<div style="font-size:var(--estat-text);color:var(--estat-muted);margin-top:4px">Muted text 13px — this is how a listing fact looks. Gap is var(--estat-gap) 16px.</div>';
		echo '</div>';
		echo '<div style="display:flex;gap:var(--estat-gap-sm)"><div style="width:40px;height:40px;border-radius:var(--estat-radius-sm);background:var(--estat-sunken);border:1px solid var(--estat-line)"></div><div style="flex:1;height:40px;border-radius:var(--estat-radius);background:var(--estat-card);border:1px solid var(--estat-line);box-shadow:var(--estat-shadow-sm)"></div></div>';
		echo '</div>';

		echo '<div style="flex:1;min-width:280px;border:1px solid var(--estat-line);border-radius:var(--estat-radius);padding:16px;background:var(--estat-card)">';
		echo '<h3 style="margin:0 0 8px">Export CSS</h3>';
		echo '<p class="description">Copy this :root block to your child theme or keep overrides in DB (current method).</p>';
		echo '<textarea id="estat-tokens-export" style="width:100%;height:200px;font-family:monospace;font-size:11px;background:var(--estat-sunken);border:1px solid var(--estat-line);border-radius:8px;padding:8px">' . esc_textarea( $export_css ) . '</textarea>';
		echo '<p><button type="button" class="button" onclick="navigator.clipboard.writeText(document.getElementById(\'estat-tokens-export\').value).then(()=>alert(\'Copied!\'))">Copy CSS</button></p>';
		echo '</div>';
		echo '</div>';

		echo '<form method="post">';
		wp_nonce_field( 'estat_tokens', 'estat_nonce' );

		foreach ( $groups as $group_name => $vars ) {
			echo '<h2>' . esc_html( $group_name ) . '</h2>';
			echo '<table class="form-table"><tbody>';
			foreach ( $vars as $var => $info ) {
				$val = $tokens[ $var ] ?? '';
				$def = $info['default'];
				$type = $info['type'];
				$label = $info['label'];
				// Use raw key for POST to preserve --.
				echo '<tr><th><label><code>' . esc_html( $var ) . '</code><br><small style="font-weight:400;color:#6b7280">' . esc_html( $label ) . '</small></label></th>';
				echo '<td>';
				// Hidden raw key.
				echo '<input type="hidden" name="tokens_raw_keys[]" value="' . esc_attr( $var ) . '">';
				if ( 'color' === $type ) {
					$display_val = $val ?: $def;
					echo '<input type="text" name="tokens[' . esc_attr( sanitize_key( $var ) ) . ']" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $def ) . '" class="regular-text" style="width:200px"> ';
					echo '<input type="color" value="' . esc_attr( self::to_color_input( $display_val ) ) . '" onchange="this.previousElementSibling.value=this.value; this.previousElementSibling.dispatchEvent(new Event(\'input\'))" style="vertical-align:middle"> ';
					echo '<span style="display:inline-block;width:16px;height:16px;border-radius:4px;background:' . esc_attr( $display_val ) . ';border:1px solid #e5e7eb;vertical-align:middle;margin-left:4px"></span>';
				} else {
					echo '<input type="text" name="tokens[' . esc_attr( sanitize_key( $var ) ) . ']" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $def ) . '" class="regular-text">';
				}
				echo '<p class="description">Default: <code>' . esc_html( $def ) . '</code>' . ( $val ? ' · <strong>Overridden: ' . esc_html( $val ) . '</strong>' : '' ) . '</p>';
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}

		// Custom tokens.
		echo '<h2>' . esc_html__( 'Custom tokens', 'estat-os' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Add any extra CSS variable, e.g. --estat-font-family: Inter, sans-serif or --estat-logo-height: 32px', 'estat-os' ) . '</p>';
		echo '<table class="form-table"><tbody>';
		$custom_idx = 0;
		$custom_tokens = array();
		foreach ( $tokens as $k => $v ) {
			$found = false;
			foreach ( $groups as $g ) { if ( isset( $g[ $k ] ) ) { $found = true; break; } }
			if ( ! $found ) {
				$custom_tokens[ $k ] = $v;
			}
		}
		// Show existing custom.
		foreach ( $custom_tokens as $ck => $cv ) {
			echo '<tr><th>Custom</th><td><input type="text" name="tokens_extra_key_' . $custom_idx . '" value="' . esc_attr( $ck ) . '" placeholder="--estat-..." class="regular-text" style="width:200px"> = <input type="text" name="tokens_extra_val_' . $custom_idx . '" value="' . esc_attr( $cv ) . '" placeholder="value" class="regular-text" style="width:200px"></td></tr>';
			$custom_idx++;
		}
		for ( $i = $custom_idx; $i < $custom_idx + 5; $i++ ) {
			echo '<tr><th>' . ( $i === $custom_idx ? 'Add new' : '' ) . '</th><td><input type="text" name="tokens_extra_key_' . $i . '" placeholder="--estat-..." class="regular-text" style="width:200px"> = <input type="text" name="tokens_extra_val_' . $i . '" placeholder="value" class="regular-text" style="width:200px"></td></tr>';
		}
		echo '</tbody></table>';

		echo '<p style="display:flex;gap:8px"><button type="submit" name="estat_save_tokens" value="1" class="button button-primary">' . esc_html__( 'Save tokens', 'estat-os' ) . '</button> <button type="submit" name="estat_reset_tokens" value="1" class="button" onclick="return confirm(\'Reset all tokens to defaults from tokens.css?\')">' . esc_html__( 'Reset to defaults', 'estat-os' ) . '</button></p>';
		echo '</form>';

		echo '<h2>tokens.css source</h2>';
		echo '<p class="description">Single source file — tokens.css is loaded by Office, Pocket (/agent) and public pages. Your overrides above are printed as inline style after it.</p>';
		$css_path = ESTAT_DIR . 'assets/css/tokens.css';
		$css_content = is_readable( $css_path ) ? file_get_contents( $css_path ) : '/* tokens.css not found */';
		echo '<pre style="background:var(--estat-sunken);padding:16px;border-radius:8px;overflow:auto;max-height:300px;font-size:11px">' . esc_html( $css_content ) . '</pre>';

		echo '</div>';
	}

	/**
	 * Convert any CSS color to #hex for color input, fallback.
	 *
	 * @param string $value CSS value.
	 * @return string Hex.
	 */
	private static function to_color_input( string $value ): string {
		$value = trim( $value );
		if ( preg_match( '/^#[0-9a-fA-F]{3,8}$/', $value ) ) {
			// Normalize 3-digit to 6-digit for input.
			if ( 4 === strlen( $value ) ) {
				return '#' . $value[1] . $value[1] . $value[2] . $value[2] . $value[3] . $value[3];
			}
			return substr( $value, 0, 7 );
		}
		// Try rgb().
		if ( preg_match( '/rgb\\s*\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)/i', $value, $m ) ) {
			return sprintf( '#%02x%02x%02x', (int) $m[1], (int) $m[2], (int) $m[3] );
		}
		// Fallback.
		return '#2768e8';
	}
}
