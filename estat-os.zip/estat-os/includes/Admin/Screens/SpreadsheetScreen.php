<?php
/**
 * Import and export — F6: preview+undo + bridge.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Csv\Spreadsheet;

defined( 'ABSPATH' ) || exit;

/**
 * Bring inventory in from a spreadsheet and take it back out again.
 * F6: preview before import, undo after import, bridge from old portals, export preview.
 */
final class SpreadsheetScreen {

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_import_inventory' ) ) {
			wp_die( esc_html__( 'You do not have permission to import or export.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preview_key = isset( $_GET['estat_preview'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_preview']) ? '' : $_GET['estat_preview'] ) ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$export_preview_what = isset( $_GET['estat_export_preview'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['estat_export_preview']) ? '' : $_GET['estat_export_preview'] ) ) ) : '';

		if ( $preview_key ) {
			$data = get_transient( $preview_key );
			if ( $data ) {
				self::render_preview( $preview_key, $data );
				return;
			}
		}

		if ( $export_preview_what ) {
			$transient = 'estat_export_preview_' . $export_preview_what . '_' . get_current_user_id();
			$preview = get_transient( $transient );
			if ( $preview ) {
				self::render_export_preview( $export_preview_what, $preview );
				// Continue to show main screen below as well.
			}
		}

		Partials::card_open( __( 'Bring properties in from a spreadsheet — F6 Preview + Bridge', 'estat-os' ), __( 'Save your sheet as CSV first. Excel and Google Sheets can both do this from File menu. F6: preview mapping, bridge from old portals (99acres, MagicBricks etc), dry-run, then import with undo.', 'estat-os' ) );
		?>
		<form method="post" enctype="multipart/form-data" class="estat-form-admin" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ); ?>">
			<?php wp_nonce_field( 'estat_import_csv', 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="preview_csv" />
			<div class="estat-field-row">
				<label class="estat-field-label" for="estat-csv"><?php esc_html_e( 'Choose your CSV file', 'estat-os' ); ?></label>
				<input type="file" id="estat-csv" name="estat_csv" accept=".csv,text/csv" required />
				<p class="description"><?php esc_html_e( 'Up to 20 MB. Large files are handled a few rows at a time so your website stays fast.', 'estat-os' ); ?></p>
			</div>
			<div class="estat-field-row">
				<label class="estat-field-label"><?php esc_html_e( 'What is in this file?', 'estat-os' ); ?></label>
				<select name="kind">
					<option value="listings"><?php esc_html_e( 'Properties (listings)', 'estat-os' ); ?></option>
					<option value="projects"><?php esc_html_e( 'Societies / Projects', 'estat-os' ); ?></option>
					<option value="agents"><?php esc_html_e( 'Team members', 'estat-os' ); ?></option>
					<option value="leads"><?php esc_html_e( 'Enquiries / Leads', 'estat-os' ); ?></option>
				</select>
			</div>
			<div class="estat-field-row">
				<label class="estat-field-label"><?php esc_html_e( 'Bridge from old system', 'estat-os' ); ?></label>
				<select name="bridge_type">
					<?php foreach ( Spreadsheet::bridge_systems() as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description"><?php esc_html_e( 'If this CSV came from 99acres, MagicBricks, Housing, etc, choose it — we will auto-map columns like Property ID, BHK, Location to our fields.', 'estat-os' ); ?></p>
			</div>
			<div class="estat-form-actions-admin">
				<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Preview & Map columns', 'estat-os' ); ?></button>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=sample_csv' ), 'estat_sample_csv', 'estat_nonce' ) ); ?>"><?php esc_html_e( 'Download a sample file', 'estat-os' ); ?></a>
			</div>
		</form>
		<?php
		Partials::card_close();

		Partials::card_open( __( 'What the columns mean', 'estat-os' ), __( 'Only the first column is required. Leave out any column you do not use. Bridge will auto-map common old headers.', 'estat-os' ) );
		echo '<table class="widefat estat-table"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Column heading', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'What to put in it', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( Spreadsheet::columns( 'listings' ) as $column => $description ) {
			echo '<tr><th scope="row" data-label="' . esc_attr__( 'Column heading', 'estat-os' ) . '"><code>' . esc_html( (string) $column ) . '</code></th>';
			echo '<td data-label="' . esc_attr__( 'What to put in it', 'estat-os' ) . '">' . esc_html( (string) $description ) . '</td></tr>';
		}
		echo '</tbody></table>';
		Partials::card_close();

		Partials::card_open( __( 'Take your information out — F6 Export Preview + Undo', 'estat-os' ), __( 'Everything is exported as CSV you can open in Excel. Preview first 5 rows before download. Your data is always yours.', 'estat-os' ) );
		echo '<p class="estat-quick-actions" style="display:flex;gap:8px;flex-wrap:wrap">';
		foreach ( array(
			'listings' => __( 'Export properties', 'estat-os' ),
			'leads'    => __( 'Export enquiries', 'estat-os' ),
			'visits'   => __( 'Export site visits', 'estat-os' ),
			'projects' => __( 'Export societies', 'estat-os' ),
			'agents'   => __( 'Export the team', 'estat-os' ),
		) as $what => $label ) {
			$url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_csv&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
			$preview_url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_preview&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
			echo '<span style="display:inline-flex;gap:4px"><a class="button" href="' . esc_url( $url ) . '">' . esc_html( (string) $label ) . '</a> <a class="button button-secondary" href="' . esc_url( $preview_url ) . '">Preview</a></span> ';
		}
		echo '</p>';
		Partials::card_close();

		$jobs = Spreadsheet::recent_jobs( 15 );
		if ( $jobs ) {
			Partials::card_open( __( 'Recent imports — F6 Undo', 'estat-os' ), __( 'Each import records created IDs and snapshots. You can undo a finished import — created listings go to trash, updated ones restore previous title/content/meta where snapshot exists.', 'estat-os' ) );
			echo '<table class="widefat estat-table"><thead><tr>';
			echo '<th scope="col">' . esc_html__( 'Job', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Kind / Bridge', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'File', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Progress', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Added', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Updated', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Skipped', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'State', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Actions', 'estat-os' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $jobs as $job ) {
				$total = max( 1, (int) $job['total_rows'] );
				$can_undo = ! empty( $job['created_ids'] ) && 'undone' !== $job['state'] && 'done' === $job['state'];
				$undo_url = $can_undo ? wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=undo_import&job_id=' . (int) $job['id'] ), 'estat_undo_import_' . (int) $job['id'], 'estat_nonce' ) : '';
				echo '<tr>';
				echo '<th scope="row">#' . (int) $job['id'] . '</th>';
				echo '<td>' . esc_html( $job['kind'] ) . ( ! empty( $job['bridge_type'] ) ? '<br><small>bridge: ' . esc_html( $job['bridge_type'] ) . '</small>' : '' ) . '</td>';
				echo '<td>' . esc_html( basename( (string) $job['file_path'] ) ) . '</td>';
				echo '<td>' . esc_html( sprintf( '%d%%', (int) round( ( (int) $job['processed_rows'] / $total ) * 100 ) ) ) . '</td>';
				echo '<td>' . (int) $job['created_count'] . '</td>';
				echo '<td>' . (int) $job['updated_count'] . '</td>';
				echo '<td>' . (int) $job['skipped_count'] . '</td>';
				echo '<td><span style="padding:2px 6px;border-radius:4px;background:' . ( 'done' === $job['state'] ? '#dcfce7' : ( 'undone' === $job['state'] ? '#fee2e2' : '#fef3c7' ) ) . '">' . esc_html( $job['state'] ) . '</span></td>';
				echo '<td>';
				if ( $can_undo ) {
					echo '<a class="button button-small" href="' . esc_url( $undo_url ) . '" onclick="return confirm(\'Undo this import? Created will be trashed.\')">' . esc_html__( 'Undo', 'estat-os' ) . '</a>';
				} else {
					echo '<span style="color:#6b7280">—</span>';
				}
				echo '</td>';
				echo '</tr>';
				if ( ! empty( $job['errors'] ) ) {
					$errs = json_decode( (string) $job['errors'], true );
					if ( is_array( $errs ) && $errs ) {
						echo '<tr><td colspan="9"><details><summary>' . esc_html( sprintf( _n( '%d error', '%d errors', count( $errs ), 'estat-os' ), count( $errs ) ) ) . '</summary><ul>';
						foreach ( array_slice( $errs, 0, 10 ) as $e ) {
							echo '<li>Row ' . (int) ( $e['row'] ?? 0 ) . ': ' . esc_html( (string) ( $e['message'] ?? '' ) ) . '</li>';
						}
						echo '</ul></details></td></tr>';
					}
				}
			}
			echo '</tbody></table>';
			Partials::card_close();
		}
	}

	/**
	 * Render preview screen after upload.
	 *
	 * @param string               $preview_key Transient key.
	 * @param array<string,mixed> $data Preview data.
	 * @return void
	 */
	private static function render_preview( string $preview_key, array $data ): void {
		$headers = $data['headers'] ?? array();
		$rows    = $data['rows'] ?? array();
		$total   = $data['total'] ?? 0;
		$mapping = $data['mapping'] ?? array();
		$kind    = $data['kind'] ?? 'listings';
		$bridge  = $data['bridge'] ?? '';

		Partials::card_open( sprintf( __( 'Preview: %d rows from %s — Map columns', 'estat-os' ), $total, $kind ), sprintf( __( 'Bridge: %s — Check mapping below. Adjust if needed, then confirm import. Dry-run validates without writing.', 'estat-os' ), $bridge ?: 'none' ) );

		echo '<p><strong>' . esc_html__( 'File headers found:', 'estat-os' ) . '</strong> ' . esc_html( implode( ', ', $headers ) ) . '</p>';
		echo '<p><strong>' . esc_html__( 'Total rows:', 'estat-os' ) . '</strong> ' . (int) $total . '</p>';

		if ( $rows ) {
			echo '<h3>' . esc_html__( 'Sample rows (first 5)', 'estat-os' ) . '</h3>';
			echo '<div style="overflow:auto"><table class="widefat"><thead><tr>';
			foreach ( $headers as $h ) { echo '<th>' . esc_html( $h ) . '</th>'; }
			echo '</tr></thead><tbody>';
			foreach ( $rows as $r ) {
				echo '<tr>';
				foreach ( $r as $cell ) { echo '<td>' . esc_html( mb_substr( $cell, 0, 80 ) ) . '</td>'; }
				echo '</tr>';
			}
			echo '</tbody></table></div>';
		}

		echo '<h3 style="margin-top:20px">' . esc_html__( 'Map your columns to our fields', 'estat-os' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'Choose which file header goes to which field. Leave empty to skip a field. external_id is used to avoid duplicates.', 'estat-os' ) . '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">';
		wp_nonce_field( 'estat_confirm_import', 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="confirm_import">';
		echo '<input type="hidden" name="preview_key" value="' . esc_attr( $preview_key ) . '">';

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Our field', 'estat-os' ) . '</th><th>' . esc_html__( 'File header', 'estat-os' ) . '</th><th>' . esc_html__( 'Description', 'estat-os' ) . '</th></tr></thead><tbody>';
		foreach ( Spreadsheet::columns( $kind ) as $col => $desc ) {
			$current = $mapping[ $col ] ?? '';
			echo '<tr>';
			echo '<th><code>' . esc_html( $col ) . '</code></th>';
			echo '<td><select name="mapping[' . esc_attr( $col ) . ']"><option value="">— ' . esc_html__( 'Skip', 'estat-os' ) . ' —</option>';
			foreach ( $headers as $h ) {
				echo '<option value="' . esc_attr( $h ) . '" ' . selected( $current, $h, false ) . '>' . esc_html( $h ) . '</option>';
			}
			echo '</select></td>';
			echo '<td style="font-size:12px;color:#6b7280">' . esc_html( $desc ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<p style="margin-top:16px"><label><input type="checkbox" name="dry_run" value="1"> ' . esc_html__( 'Dry-run only — validate without writing (preview how many would be created/updated)', 'estat-os' ) . '</label></p>';

		echo '<div class="estat-form-actions-admin" style="margin-top:12px">';
		echo '<button type="submit" class="button button-primary button-hero">' . esc_html__( 'Confirm & Import', 'estat-os' ) . '</button> ';
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">' . esc_html__( 'Cancel', 'estat-os' ) . '</a>';
		echo '</div>';
		echo '</form>';

		Partials::card_close();
	}

	/**
	 * Render export preview.
	 *
	 * @param string               $what Kind.
	 * @param array<string,mixed> $preview Preview data.
	 * @return void
	 */
	private static function render_export_preview( string $what, array $preview ): void {
		Partials::card_open( sprintf( __( 'Export preview: %s (first %d rows)', 'estat-os' ), $what, count( $preview['rows'] ?? array() ) ), __( 'This is what your CSV will contain. Click Export to download full file.', 'estat-os' ) );
		$columns = $preview['columns'] ?? array();
		$rows = $preview['rows'] ?? array();
		if ( ! $columns ) {
			echo '<p>' . esc_html__( 'No data to export.', 'estat-os' ) . '</p>';
			Partials::card_close();
			return;
		}
		echo '<div style="overflow:auto"><table class="widefat"><thead><tr>';
		foreach ( $columns as $c ) { echo '<th><code>' . esc_html( $c ) . '</code></th>'; }
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr>';
			foreach ( $columns as $c ) {
				echo '<td>' . esc_html( mb_substr( (string) ( $r[ $c ] ?? '' ), 0, 100 ) ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table></div>';
		$download_url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_csv&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
		echo '<p style="margin-top:12px"><a class="button button-primary" href="' . esc_url( $download_url ) . '">' . esc_html__( 'Download full CSV', 'estat-os' ) . '</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">' . esc_html__( 'Close preview', 'estat-os' ) . '</a></p>';
		Partials::card_close();
	}
}
