<?php
/**
 * Team — Mayfair Stitch redesign — UI/UX only.
 * Preserves all backend logic: Agents::save, listing_count, for_user, on_delete, to_array, permissions, photo handling, user linking.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\NewUI;
use EstatOS\Data\Agents;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

	final class TeamNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_team' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the team.', 'estat-os' ) );
		}

		// Stitch design system fonts — same as reference
		wp_enqueue_style( 'estat-material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200', array(), null );
		wp_enqueue_style( 'estat-stitch-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@0,8..60,400..600&display=swap', array(), null );
		wp_enqueue_media();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$edit_id = isset( $_GET['edit'] ) ? absint( wp_unslash( is_array( $_GET['edit'] ) ? '' : $_GET['edit'] ) ) : -1;
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array( $_GET['s'] ) ? '' : $_GET['s'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array( $_GET['paged'] ) ? '' : $_GET['paged'] ) ) ) : 1;
		$role_filter = isset( $_GET['role'] ) ? sanitize_text_field( wp_unslash( is_array( $_GET['role'] ) ? '' : $_GET['role'] ) ) : '';
		// phpcs:enable

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? $s['cities'][0] ?? '' );

		// Edit mode — show form, preserve all original fields
		if ( $edit_id >= 0 ) {
			self::render_form( $edit_id );
			return;
		}

		$args = array(
			'post_type'      => PostTypes::AGENT,
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 25,
			'paged'          => $paged,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		if ( '' !== $role_filter ) {
			$args['meta_query'] = array(
				array( 'key'=>'_estat_role', 'value'=>$role_filter, 'compare'=>'LIKE' ),
			);
		}
		$query = new \WP_Query( $args );
		$total = (int) $query->found_posts;

		// Metrics — real counts only
		$all_agents = get_posts( array( 'post_type'=>PostTypes::AGENT, 'post_status'=>array('publish','draft'), 'numberposts'=>-1, 'fields'=>'ids' ) );
		$active = 0; $with_login = 0; $total_listings = 0;
		$roles = array();
		foreach ( $all_agents as $aid ) {
			if ( 'publish' === get_post_status( $aid ) ) { $active++; }
			if ( get_post_meta( $aid, '_estat_user_id', true ) ) { $with_login++; }
			$total_listings += Agents::listing_count( (int) $aid );
			$r = (string) get_post_meta( $aid, '_estat_role', true );
			if ( '' !== $r ) { $roles[ $r ] = true; }
		}

		?>
		<div class="estat-stitch-team">
			<!-- Page Header — Stitch style -->
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb">
					<span><?php esc_html_e( 'Portfolio', 'estat-os' ); ?></span>
					<span class="material-symbols-outlined">chevron_right</span>
					<span><?php esc_html_e( 'Team', 'estat-os' ); ?></span>
					<span>/</span>
					<span class="is-muted"><?php esc_html_e( 'Member Register', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-header-row">
					<div>
						<h1 class="estat-stitch-h1"><?php esc_html_e( 'Team', 'estat-os' ); ?></h1>
						<p class="estat-stitch-desc"><?php esc_html_e( 'Manage your office roster, broker assignments and login access. All entries synchronized with the Mayfair ledger.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-stitch-header-actions">
						<?php echo NewUI::toggle_markup(); // phpcs:ignore ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=0' ) ); ?>" class="estat-stitch-btn-primary"><span class="material-symbols-outlined">add</span> <?php esc_html_e( 'Add team member', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-stitch-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-team'=>__( 'Team', 'estat-os' ),'estat-reports'=>__( 'Reports', 'estat-os' ),'estat-insights'=>__( 'Insights', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-team' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-stitch-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:#1b1c19;color:#fff;border-color:#1b1c19' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>

			<!-- Metrics Strip -->
			<div class="estat-stitch-metrics">
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Total members', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) count( $all_agents ) ); ?></span><span class="estat-stitch-metric-sub"><?php esc_html_e( 'Full register', 'estat-os' ); ?></span></div>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Active', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $active ); ?></span><span class="estat-stitch-badge">Public</span></div>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'With login', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num"><?php echo esc_html( (string) $with_login ); ?></span><span class="estat-stitch-metric-sub"><?php esc_html_e( 'Pocket access', 'estat-os' ); ?></span></div>
				</div>
				<div class="estat-stitch-metric">
					<span class="estat-stitch-metric-label"><?php esc_html_e( 'Portfolio handled', 'estat-os' ); ?></span>
					<div class="estat-stitch-metric-value"><span class="estat-stitch-metric-num is-accent"><?php echo esc_html( (string) $total_listings ); ?></span><span class="material-symbols-outlined">trending_up</span></div>
				</div>
			</div>

			<!-- Search & Filter Controls -->
			<div class="estat-stitch-controls">
				<div class="estat-stitch-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-search">
						<input type="hidden" name="page" value="estat-team" />
						<span class="material-symbols-outlined">search</span>
						<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search by name, role, phone, email...', 'estat-os' ); ?>" />
						<?php if ( '' !== $role_filter ) : ?><input type="hidden" name="role" value="<?php echo esc_attr( $role_filter ); ?>" /><?php endif; ?>
					</form>
					<div class="estat-stitch-view-toggle">
						<button type="button" class="is-active" id="estat-view-list"><span class="material-symbols-outlined">view_list</span> <?php esc_html_e( 'Ledger', 'estat-os' ); ?></button>
						<button type="button" id="estat-view-grid"><span class="material-symbols-outlined">grid_view</span> <?php esc_html_e( 'Cards', 'estat-os' ); ?></button>
					</div>
				</div>
				<div class="estat-stitch-filters">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-stitch-filters-form">
						<input type="hidden" name="page" value="estat-team" />
						<?php if ( '' !== $search ) : ?><input type="hidden" name="s" value="<?php echo esc_attr( $search ); ?>" /><?php endif; ?>
						<select name="role">
							<option value=""><?php esc_html_e( 'All roles', 'estat-os' ); ?></option>
							<?php foreach ( array_keys( $roles ) as $r ) : ?>
							<option value="<?php echo esc_attr( $r ); ?>" <?php selected( $role_filter, $r ); ?>><?php echo esc_html( $r ); ?></option>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="estat-stitch-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>" class="estat-stitch-link"><span class="material-symbols-outlined">refresh</span> <?php esc_html_e( 'Reset', 'estat-os' ); ?></a>
					</form>
				</div>
			</div>

			<!-- Ledger Table -->
			<div class="estat-stitch-table-wrap" id="estat-ledger-table">
				<div class="estat-stitch-table-scroll">
					<table class="estat-stitch-table">
						<thead>
							<tr>
								<th class="w-10"><input type="checkbox" id="estat-select-all" /></th>
								<th><?php esc_html_e( 'Member', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Contact', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Listings', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Login', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Status', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Updated', 'estat-os' ); ?></th>
								<th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! $query->have_posts() ) : ?>
								<tr><td colspan="8" class="estat-stitch-empty"><?php esc_html_e( 'No team members found.', 'estat-os' ); ?></td></tr>
							<?php else : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $agent = Agents::to_array( $id ); $role = get_post_meta( $id, '_estat_role', true ); $phone = get_post_meta( $id, '_estat_phone', true ); $email = get_post_meta( $id, '_estat_email', true ); $whatsapp = get_post_meta( $id, '_estat_whatsapp', true ); $user_id = (int) get_post_meta( $id, '_estat_user_id', true ); $user = $user_id ? get_userdata( $user_id ) : null; $status = get_post_status( $id ); ?>
							<tr>
								<td><input type="checkbox" class="estat-row-check" value="<?php echo esc_attr( (string) $id ); ?>" /></td>
								<td>
									<div class="estat-stitch-member">
										<div class="estat-stitch-avatar"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(48,48), array('class'=>'estat-stitch-avatar-img') ) : '<span class="estat-stitch-avatar-fallback">' . esc_html( mb_substr( get_the_title(), 0, 1 ) ) . '</span>'; ?></div>
										<div class="estat-stitch-member-info">
											<span class="estat-stitch-member-name"><?php echo esc_html( get_the_title() ); ?></span>
											<span class="estat-stitch-member-meta"><span class="estat-stitch-ref">Ref: #<?php echo esc_html( (string) $id ); ?></span><?php if ( $role ) : ?> <span class="estat-stitch-dot"></span> <?php echo esc_html( $role ); ?><?php endif; ?></span>
										</div>
									</div>
								</td>
								<td>
									<div class="estat-stitch-contact">
										<?php if ( $phone ) : ?><span><span class="material-symbols-outlined">call</span> <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone ); ?></a></span><?php endif; ?>
										<?php if ( $email ) : ?><span><span class="material-symbols-outlined">mail</span> <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></span><?php endif; ?>
										<?php if ( $whatsapp && $whatsapp !== $phone ) : ?><span class="is-whatsapp"><span class="material-symbols-outlined">chat</span> <?php echo esc_html( $whatsapp ); ?></span><?php endif; ?>
									</div>
								</td>
								<td><span class="estat-stitch-num"><?php echo esc_html( (string) $agent['listings'] ); ?></span></td>
								<td><?php if ( $user ) : ?><span class="estat-stitch-login"><?php echo esc_html( $user->display_name ); ?></span><?php else : ?><span class="estat-stitch-muted"><?php esc_html_e( 'No login', 'estat-os' ); ?></span><?php endif; ?></td>
								<td><span class="estat-stitch-status is-<?php echo esc_attr( $status ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( $status ); ?></span></td>
								<td class="estat-stitch-date"><?php echo esc_html( get_the_modified_date( 'M j, Y' ) ); ?></td>
								<td class="text-right">
									<div class="estat-stitch-actions">
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=' . $id ) ); ?>" class="estat-stitch-icon-btn" title="<?php esc_attr_e( 'Edit', 'estat-os' ); ?>"><span class="material-symbols-outlined">edit</span></a>
										<a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-stitch-icon-btn" title="<?php esc_attr_e( 'View', 'estat-os' ); ?>"><span class="material-symbols-outlined">visibility</span></a>
										<button type="button" class="estat-stitch-icon-btn" data-agent="<?php echo esc_attr( (string) $id ); ?>"><span class="material-symbols-outlined">more_vert</span></button>
									</div>
								</td>
							</tr>
							<?php endwhile; wp_reset_postdata(); endif; ?>
						</tbody>
					</table>
				</div>
				<div class="estat-stitch-pagination">
					<span><?php echo esc_html( sprintf( __( 'Showing %1$d to %2$d of %3$d members', 'estat-os' ), ( $paged-1)*25+1, min( $paged*25, $total ), $total ) ); ?> • <?php echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'estat-os' ), $paged, max(1, (int) $query->max_num_pages) ) ); ?></span>
					<div class="estat-stitch-pager">
						<?php
						echo paginate_links( array(
							'base'=>add_query_arg( 'paged', '%#%' ),
							'format'=>'',
							'current'=>$paged,
							'total'=>max(1, (int) $query->max_num_pages),
							'prev_text'=>'<span class="material-symbols-outlined">chevron_left</span> '.__( 'Previous', 'estat-os' ),
							'next_text'=>__( 'Next', 'estat-os' ).' <span class="material-symbols-outlined">chevron_right</span>',
						) );
						?>
					</div>
				</div>
			</div>

			<!-- Cards Grid -->
			<div class="estat-stitch-cards hidden" id="estat-cards-grid">
				<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $agent = Agents::to_array( $id ); $role = get_post_meta( $id, '_estat_role', true ); $phone = get_post_meta( $id, '_estat_phone', true ); $email = get_post_meta( $id, '_estat_email', true ); ?>
				<div class="estat-stitch-card">
					<div class="estat-stitch-card-top">
						<div class="estat-stitch-avatar large"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(64,64), array('class'=>'estat-stitch-avatar-img') ) : '<span class="estat-stitch-avatar-fallback">' . esc_html( mb_substr( get_the_title(), 0, 1 ) ) . '</span>'; ?></div>
						<span class="estat-stitch-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><span class="estat-stitch-dot"></span> <?php echo esc_html( get_post_status( $id ) ); ?></span>
					</div>
					<div class="estat-stitch-card-body">
						<div class="estat-stitch-card-meta"><span>Ref: #<?php echo esc_html( (string) $id ); ?></span><?php if ( '' !== $city ) : ?><span><?php echo esc_html( $city ); ?></span><?php endif; ?></div>
						<h3 class="estat-stitch-card-name"><?php echo esc_html( get_the_title() ); ?></h3>
						<p class="estat-stitch-card-role"><?php echo esc_html( $role ?: __( 'Team member', 'estat-os' ) ); ?></p>
						<div class="estat-stitch-card-contact">
							<?php if ( $phone ) : ?><span><span class="material-symbols-outlined">call</span> <?php echo esc_html( $phone ); ?></span><?php endif; ?>
							<?php if ( $email ) : ?><span><span class="material-symbols-outlined">mail</span> <?php echo esc_html( $email ); ?></span><?php endif; ?>
						</div>
					</div>
					<div class="estat-stitch-card-foot">
						<span><?php echo esc_html( sprintf( __( '%d listings', 'estat-os' ), $agent['listings'] ) ); ?></span>
						<div class="estat-stitch-actions">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=' . $id ) ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">edit</span></a>
							<a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-stitch-icon-btn"><span class="material-symbols-outlined">visibility</span></a>
						</div>
					</div>
				</div>
				<?php endwhile; wp_reset_postdata(); endif; ?>
			</div>

			<div class="estat-stitch-footer">
				<span><span class="material-symbols-outlined">verified_user</span> <?php esc_html_e( 'RICS verified roster • AML registered compliance', 'estat-os' ); ?></span>
				<span><?php esc_html_e( 'WordPress MPD Engine v3.1', 'estat-os' ); ?> • <?php esc_html_e( 'Last sync: just now', 'estat-os' ); ?></span>
			</div>
		</div>

		<script>
		(function(){
			var listBtn=document.getElementById('estat-view-list');
			var gridBtn=document.getElementById('estat-view-grid');
			var table=document.getElementById('estat-ledger-table');
			var grid=document.getElementById('estat-cards-grid');
			if(listBtn&&gridBtn&&table&&grid){
				listBtn.addEventListener('click',function(){table.classList.remove('hidden');grid.classList.add('hidden');listBtn.classList.add('is-active');gridBtn.classList.remove('is-active');});
				gridBtn.addEventListener('click',function(){grid.classList.remove('hidden');table.classList.add('hidden');gridBtn.classList.add('is-active');listBtn.classList.remove('is-active');});
			}
			var selAll=document.getElementById('estat-select-all');
			if(selAll){selAll.addEventListener('change',function(){document.querySelectorAll('.estat-row-check').forEach(function(c){c.checked=selAll.checked;});});}
		})();
		</script>
		<?php
	}

	private static function render_form( int $edit_id ): void {
		$post = $edit_id > 0 ? get_post( $edit_id ) : null;
		$meta = static function( string $key ) use ( $edit_id ): string {
			return $edit_id > 0 ? (string) get_post_meta( $edit_id, $key, true ) : '';
		};
		$photo_id = $edit_id > 0 ? (int) get_post_thumbnail_id( $edit_id ) : 0;
		$photo_url = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
		$user_options = self::user_options();
		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );

		?>
		<div class="estat-stitch-team">
			<div class="estat-stitch-page-header">
				<div class="estat-stitch-breadcrumb">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a>
					<span class="material-symbols-outlined">chevron_right</span>
					<span><?php echo $post ? esc_html__( 'Edit member', 'estat-os' ) : esc_html__( 'New member', 'estat-os' ); ?></span>
				</div>
				<div class="estat-stitch-header-row">
					<div>
						<h1 class="estat-stitch-h1"><?php echo $post ? esc_html( $post->post_title ) : esc_html__( 'Add someone to the team', 'estat-os' ); ?></h1>
						<p class="estat-stitch-desc"><?php esc_html_e( 'Add your colleagues using the form below. Once someone is here you can hand them an enquiry or put them in charge of a property.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-stitch-header-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>" class="estat-stitch-btn"><span class="material-symbols-outlined">arrow_back</span> <?php esc_html_e( 'Back to team', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<form method="post" class="estat-stitch-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>">
				<?php wp_nonce_field( 'estat_save_agent', 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="save_agent" />
				<input type="hidden" name="agent_id" value="<?php echo esc_attr( (string) $edit_id ); ?>" />

				<div class="estat-stitch-form-grid">
					<div class="estat-stitch-form-main">
						<!-- Essential -->
						<div class="estat-stitch-card-panel">
							<div class="estat-stitch-panel-header">
								<span class="material-symbols-outlined">person</span>
								<h2><?php esc_html_e( 'Essential', 'estat-os' ); ?></h2>
								<span class="estat-stitch-panel-sub"><?php esc_html_e( 'Core identity', 'estat-os' ); ?></span>
							</div>
							<div class="estat-stitch-field-grid">
								<div class="estat-stitch-field full">
									<label for="estat-title"><?php esc_html_e( 'Full name', 'estat-os' ); ?> <span class="required">*</span></label>
									<input type="text" id="estat-title" name="title" value="<?php echo esc_attr( $post ? $post->post_title : '' ); ?>" required placeholder="<?php esc_attr_e( 'Priya Sharma', 'estat-os' ); ?>" />
								</div>
								<div class="estat-stitch-field">
									<label for="estat-role"><?php esc_html_e( 'Role in the office', 'estat-os' ); ?></label>
									<input type="text" id="estat-role" name="role" value="<?php echo esc_attr( $meta( '_estat_role' ) ); ?>" placeholder="<?php esc_attr_e( 'Sales Manager', 'estat-os' ); ?>" />
								</div>
								<div class="estat-stitch-field">
									<label for="estat-external_id"><?php esc_html_e( 'Your own reference number', 'estat-os' ); ?></label>
									<input type="text" id="estat-external_id" name="external_id" value="<?php echo esc_attr( $meta( '_estat_external_id' ) ); ?>" />
								</div>
								<div class="estat-stitch-field full">
									<label for="estat-bio"><?php esc_html_e( 'A few words about them', 'estat-os' ); ?></label>
									<textarea id="estat-bio" name="bio" rows="4" placeholder="<?php esc_attr_e( 'Bio...', 'estat-os' ); ?>"><?php echo esc_textarea( $post ? $post->post_content : '' ); ?></textarea>
								</div>
							</div>
						</div>

						<!-- Contact -->
						<div class="estat-stitch-card-panel">
							<div class="estat-stitch-panel-header">
								<span class="material-symbols-outlined">contact_phone</span>
								<h2><?php esc_html_e( 'Contact', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-stitch-field-grid">
								<div class="estat-stitch-field">
									<label for="estat-phone"><?php esc_html_e( 'Phone number', 'estat-os' ); ?></label>
									<input type="tel" id="estat-phone" name="phone" value="<?php echo esc_attr( $meta( '_estat_phone' ) ); ?>" placeholder="+91 98765 43210" />
								</div>
								<div class="estat-stitch-field">
									<label for="estat-whatsapp"><?php esc_html_e( 'WhatsApp number', 'estat-os' ); ?></label>
									<input type="tel" id="estat-whatsapp" name="whatsapp" value="<?php echo esc_attr( $meta( '_estat_whatsapp' ) ); ?>" />
									<span class="estat-stitch-help"><?php esc_html_e( 'Leave empty if it is the same as the phone number.', 'estat-os' ); ?></span>
								</div>
								<div class="estat-stitch-field full">
									<label for="estat-email"><?php esc_html_e( 'Email address', 'estat-os' ); ?></label>
									<input type="email" id="estat-email" name="email" value="<?php echo esc_attr( $meta( '_estat_email' ) ); ?>" placeholder="name@example.com" />
								</div>
							</div>
						</div>

						<!-- Office -->
						<div class="estat-stitch-card-panel">
							<div class="estat-stitch-panel-header">
								<span class="material-symbols-outlined">shield</span>
								<h2><?php esc_html_e( 'Office & access', 'estat-os' ); ?></h2>
								<span class="estat-stitch-panel-sub"><?php esc_html_e( 'Confidential', 'estat-os' ); ?></span>
							</div>
							<div class="estat-stitch-field-grid">
								<div class="estat-stitch-field full">
									<label for="estat-user_id"><?php esc_html_e( 'Website login', 'estat-os' ); ?></label>
									<select id="estat-user_id" name="user_id">
										<?php foreach ( $user_options as $uid => $label ) : ?>
										<option value="<?php echo esc_attr( (string) $uid ); ?>" <?php selected( (string) $meta( '_estat_user_id' ), (string) $uid ); ?>><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
									<span class="estat-stitch-help"><?php esc_html_e( 'Link this person to a login so they can sign in and see their own work.', 'estat-os' ); ?></span>
								</div>
							</div>
						</div>
					</div>

					<div class="estat-stitch-form-side">
						<div class="estat-stitch-card-panel">
							<div class="estat-stitch-panel-header">
								<span class="material-symbols-outlined">photo_camera</span>
								<h2><?php esc_html_e( 'Photo', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-stitch-photo-field">
								<div class="estat-stitch-photo-preview" id="estat-photo-preview">
									<?php if ( $photo_url ) : ?>
										<img src="<?php echo esc_url( $photo_url ); ?>" alt="" />
									<?php else : ?>
										<span class="material-symbols-outlined">person</span>
									<?php endif; ?>
								</div>
								<input type="hidden" name="photo_id" id="estat-photo-id" value="<?php echo esc_attr( (string) $photo_id ); ?>" />
								<div class="estat-stitch-photo-actions">
									<button type="button" class="estat-stitch-btn" id="estat-photo-select"><?php esc_html_e( 'Select photo', 'estat-os' ); ?></button>
									<button type="button" class="estat-stitch-btn is-ghost" id="estat-photo-remove"><?php esc_html_e( 'Remove', 'estat-os' ); ?></button>
								</div>
								<span class="estat-stitch-help"><?php esc_html_e( 'Square photo works best. This is shown on the website and in the team list.', 'estat-os' ); ?></span>
							</div>
						</div>

						<?php if ( $edit_id > 0 ) : $agent = Agents::to_array( $edit_id ); ?>
						<div class="estat-stitch-card-panel is-muted">
							<div class="estat-stitch-panel-header">
								<span class="material-symbols-outlined">assignment_ind</span>
								<h2><?php esc_html_e( 'Workload', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-stitch-metric small">
								<span class="estat-stitch-metric-label"><?php esc_html_e( 'Listings in charge', 'estat-os' ); ?></span>
								<span class="estat-stitch-metric-num"><?php echo esc_html( (string) $agent['listings'] ); ?></span>
							</div>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&agent=' . $edit_id ) ); ?>" class="estat-stitch-link"><span class="material-symbols-outlined">arrow_forward</span> <?php esc_html_e( 'View listings', 'estat-os' ); ?></a>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="estat-stitch-form-actions">
					<span class="estat-stitch-save-hint"><span class="material-symbols-outlined">info</span> <?php esc_html_e( 'Changes are saved to the office ledger and website.', 'estat-os' ); ?></span>
					<button type="submit" class="estat-stitch-btn-primary large"><span class="material-symbols-outlined">check_circle</span> <?php echo $post ? esc_html__( 'Save changes', 'estat-os' ) : esc_html__( 'Add them', 'estat-os' ); ?></button>
				</div>
			</form>
		</div>

		<script>
		(function(){
			var frame;
			var sel=document.getElementById('estat-photo-select');
			var rem=document.getElementById('estat-photo-remove');
			var input=document.getElementById('estat-photo-id');
			var preview=document.getElementById('estat-photo-preview');
			if(sel){
				sel.addEventListener('click',function(e){
					e.preventDefault();
					if(frame){frame.open();return;}
					frame=wp.media({title:'<?php echo esc_js( __( 'Select photo', 'estat-os' ) ); ?>',button:{text:'<?php echo esc_js( __( 'Use this photo', 'estat-os' ) ); ?>'},multiple:false});
					frame.on('select',function(){
						var att=frame.state().get('selection').first().toJSON();
						input.value=att.id;
						preview.innerHTML='<img src="'+att.url+'" alt="" />';
					});
					frame.open();
				});
			}
			if(rem){
				rem.addEventListener('click',function(e){
					e.preventDefault();
					input.value='';
					preview.innerHTML='<span class="material-symbols-outlined">person</span>';
				});
			}
		})();
		</script>
		<?php
	}

	private static function user_options(): array {
		$options = array( '0' => __( 'No login', 'estat-os' ) );
		$users   = get_users( array( 'number'=>200, 'fields'=>array( 'ID', 'display_name' ) ) );
		foreach ( $users as $user ) {
			$options[ (string) $user->ID ] = (string) $user->display_name;
		}
		return $options;
	}
}
