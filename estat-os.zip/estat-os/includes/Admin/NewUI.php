<?php
/**
 * Per-user new interface switch — Phase 1 Mayfair.
 *
 * Classic screens remain untouched. When user meta estat_use_new_ui = 1,
 * Today, Listings and Add a Home render their new versions behind .estat-new-ui.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin;

defined( 'ABSPATH' ) || exit;

final class NewUI {

	public const META_KEY = 'estat_use_new_ui';

	public static function register(): void {
		add_action( 'show_user_profile', array( __CLASS__, 'profile_field' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_field' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_profile' ) );
		add_action( 'wp_ajax_estat_toggle_new_ui', array( __CLASS__, 'ajax_toggle' ) );
		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
	}

	public static function is_enabled( int $user_id = 0 ): bool {
		if ( 0 === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( 0 === $user_id ) {
			return false;
		}
		return '1' === (string) get_user_meta( $user_id, self::META_KEY, true );
	}

	public static function set_enabled( bool $enabled, int $user_id = 0 ): void {
		if ( 0 === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( $enabled ) {
			update_user_meta( $user_id, self::META_KEY, '1' );
		} else {
			delete_user_meta( $user_id, self::META_KEY );
		}
	}

	public static function body_class( string $classes ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 0 !== strpos( $page, 'estat-' ) ) {
			return $classes;
		}
		if ( self::is_enabled() ) {
			$classes .= ' estat-new-ui';
		}
		return $classes;
	}

	public static function profile_field( $user ): void {
		$enabled = self::is_enabled( (int) $user->ID );
		?>
		<h2><?php esc_html_e( 'Estat.OS interface', 'estat-os' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><label for="estat_use_new_ui"><?php esc_html_e( 'New interface', 'estat-os' ); ?></label></th>
				<td>
					<label>
						<input type="checkbox" name="estat_use_new_ui" id="estat_use_new_ui" value="1" <?php checked( $enabled ); ?> />
						<?php esc_html_e( 'Use the new interface', 'estat-os' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Phase 1: Today, Listings and Add a Home use the Mayfair redesign. Classic screens stay available when unchecked.', 'estat-os' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	public static function save_profile( int $user_id ): void {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$enabled = isset( $_POST['estat_use_new_ui'] ) && '1' === (string) $_POST['estat_use_new_ui'];
		self::set_enabled( $enabled, $user_id );
	}

	public static function ajax_toggle(): void {
		check_ajax_referer( 'estat_toggle_new_ui', 'nonce' );
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$enabled = isset( $_POST['enabled'] ) && '1' === (string) $_POST['enabled'];
		self::set_enabled( $enabled );
		wp_send_json_success( array( 'enabled' => $enabled ) );
	}

	/**
	 * Small inline toggle for topbar — used by new screens.
	 */
	public static function toggle_markup(): string {
		$enabled = self::is_enabled();
		$nonce = wp_create_nonce( 'estat_toggle_new_ui' );
		ob_start();
		?>
		<label class="estat-newui-toggle" style="display:inline-flex;align-items:center;gap:8px;font-size:12px">
			<input type="checkbox" id="estat-newui-switch" <?php checked( $enabled ); ?> data-nonce="<?php echo esc_attr( $nonce ); ?>" />
			<span><?php esc_html_e( 'Use the new interface', 'estat-os' ); ?></span>
		</label>
		<script>
		(function(){
			var cb=document.getElementById('estat-newui-switch');
			if(!cb) return;
			cb.addEventListener('change', function(){
				var fd=new FormData();
				fd.append('action','estat_toggle_new_ui');
				fd.append('nonce', cb.getAttribute('data-nonce'));
				fd.append('enabled', cb.checked ? '1' : '0');
				fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:fd})
				.then(r=>r.json()).then(function(){ location.reload(); });
			});
		})();
		</script>
		<?php
		return (string) ob_get_clean();
	}
}
