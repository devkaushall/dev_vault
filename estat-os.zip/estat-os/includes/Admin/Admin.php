<?php
/**
 * Office admin: menu, assets and screen routing.
 * Stitch Mayfair Atelier — simplified 8-item sidebar when new UI on.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public const MENU = 'estat-today';

	private array $screens = array();

	public function register(): void {
		NewUI::register();

		$this->screens = array(
			'estat-today'         => array( Screens\Today::class, 'render' ),
			'estat-add-home'      => array( Screens\AddHome::class, 'render' ),
			'estat-listings'      => array( Screens\ListingsScreen::class, 'render' ),
			'estat-enquiries'     => array( Screens\Enquiries::class, 'render' ),
			'estat-pipeline'      => array( Screens\PipelineScreen::class, 'render' ),
			'estat-visits'        => array( Screens\VisitsScreen::class, 'render' ),
			'estat-requests'      => array( Screens\RequestsScreen::class, 'render' ),
			'estat-projects'      => array( Screens\ProjectsScreen::class, 'render' ),
			'estat-team'          => array( Screens\TeamScreen::class, 'render' ),
			'estat-forms'         => array( Screens\FormsScreen::class, 'render' ),
			'estat-spreadsheet'   => array( Screens\SpreadsheetScreen::class, 'render' ),
			'estat-reports'       => array( Screens\Reports::class, 'render' ),
			'estat-gallery'       => array( Screens\GalleryScreen::class, 'render' ),
			'estat-insights'      => array( Screens\InsightsScreen::class, 'render' ),
			'estat-search-alerts' => array( Screens\SearchAlertsScreen::class, 'render' ),
			'estat-templates'     => array( Screens\TemplatesScreen::class, 'render' ),
			'estat-design-tokens' => array( Screens\DesignTokensScreen::class, 'render' ),
			'estat-settings'      => array( Screens\SettingsScreen::class, 'render' ),
		);

		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( Actions::class, 'handle' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
		add_action( 'admin_head', array( $this, 'hide_clutter' ) );
		add_action( 'wp_ajax_estat_upload_file', array( __CLASS__, 'ajax_upload' ) );
		add_action( 'wp_ajax_estat_move_pipeline', array( __CLASS__, 'ajax_move_pipeline' ) );
		add_action( 'wp_ajax_estat_test_mail', array( __CLASS__, 'ajax_test_mail' ) );
		add_action( 'wp_ajax_estat_test_webhook', array( __CLASS__, 'ajax_test_webhook' ) );
		add_action( 'wp_ajax_estat_lead_timeline', array( __CLASS__, 'ajax_lead_timeline' ) );
		add_action( 'admin_notices', array( $this, 'setup_nudge' ) );
		add_action( 'admin_init', array( $this, 'maybe_greet' ), 5 );
	}

	public function maybe_greet(): void {
		if ( '1' !== (string) get_option( 'estat_show_setup', '' ) ) { return; }
		delete_option( 'estat_show_setup' );
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
		if ( ! current_user_can( 'estat_manage_settings' ) ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['activate-multi'] ) ) { return; }
		wp_safe_redirect( admin_url( 'admin.php?page=' . Screens\SetupScreen::SLUG ) );
		exit;
	}

	public function setup_nudge(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) || ! Screens\SetupScreen::needed() ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['page']) ? '' : $_GET['page'] ) ) ) : '';
		if ( 0 !== strpos( $page, 'estat-' ) || Screens\SetupScreen::SLUG === $page ) { return; }
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a class="button button-primary" href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Your website is not showing your properties yet.', 'estat-os' ),
			esc_html__( 'Answer four short questions and we will build the pages for you.', 'estat-os' ),
			esc_url( admin_url( 'admin.php?page=' . Screens\SetupScreen::SLUG ) ),
			esc_html__( 'Finish setup', 'estat-os' )
		);
	}

	public function add_menu(): void {
		$cap = 'estat_manage_listings';

		add_menu_page(
			__( 'Office', 'estat-os' ),
			__( 'Office', 'estat-os' ),
			$cap,
			self::MENU,
			array( $this, 'route' ),
			'dashicons-building',
			3
		);

		// Stitch: 8 items when new UI, 16 when classic — solves complicated menu
		if ( NewUI::is_enabled() ) {
			$pages = array(
				array( 'estat-today', __( 'Today', 'estat-os' ), $cap ),
				array( 'estat-add-home', __( 'Add a home', 'estat-os' ), $cap ),
				array( 'estat-listings', __( 'Listings', 'estat-os' ), $cap ),
				array( 'estat-enquiries', __( 'Enquiries', 'estat-os' ), 'estat_manage_leads' ),
				array( 'estat-projects', __( 'Societies / Projects', 'estat-os' ), 'estat_manage_projects' ),
				array( 'estat-team', __( 'Team', 'estat-os' ), 'estat_manage_team' ),
				array( 'estat-spreadsheet', __( 'Spreadsheet', 'estat-os' ), 'estat_import_inventory' ),
				array( 'estat-settings', __( 'Office', 'estat-os' ), 'estat_manage_settings' ),
			);
		} else {
			$pages = array(
				array( 'estat-today', __( 'Today', 'estat-os' ), $cap ),
				array( 'estat-add-home', __( 'Add a Home', 'estat-os' ), $cap ),
				array( 'estat-listings', __( 'Listings', 'estat-os' ), $cap ),
				array( 'estat-enquiries', __( 'Enquiries', 'estat-os' ), 'estat_manage_leads' ),
				array( 'estat-pipeline', __( 'Pipeline', 'estat-os' ), 'estat_manage_leads' ),
				array( 'estat-visits', __( 'Site Visits', 'estat-os' ), 'estat_manage_visits' ),
				array( 'estat-requests', __( 'Change Requests', 'estat-os' ), 'estat_request_listings' ),
				array( 'estat-projects', __( 'Societies & Projects', 'estat-os' ), 'estat_manage_projects' ),
				array( 'estat-team', __( 'Team', 'estat-os' ), 'estat_manage_team' ),
				array( 'estat-forms', __( 'Forms', 'estat-os' ), 'estat_manage_forms' ),
				array( 'estat-spreadsheet', __( 'Spreadsheet', 'estat-os' ), 'estat_import_inventory' ),
				array( 'estat-search-alerts', __( 'Search Alerts', 'estat-os' ), 'estat_manage_leads' ),
				array( 'estat-reports', __( 'Reports', 'estat-os' ), 'estat_view_reports' ),
				array( 'estat-templates', __( 'Templates', 'estat-os' ), 'estat_manage_settings' ),
				array( 'estat-design-tokens', __( 'Design Tokens', 'estat-os' ), 'estat_manage_settings' ),
				array( 'estat-settings', __( 'Office Settings', 'estat-os' ), 'estat_manage_settings' ),
			);
		}

		foreach ( $pages as $page ) {
			list( $slug, $title, $capability ) = $page;
			add_submenu_page(
				self::MENU,
				$title,
				$title,
				$capability,
				$slug,
				array( $this, 'route' )
			);
		}

		global $submenu;
		if ( isset( $submenu[ self::MENU ][0][0] ) ) {
			unset( $submenu[ self::MENU ][0] );
		}

		// Classic grouping only when new UI off
		if ( ! NewUI::is_enabled() && isset( $submenu[ self::MENU ] ) ) {
			$groups = array(
				__( 'Office overview', 'estat-os' ) => array( 'estat-today' ),
				__( 'Listings & workflow', 'estat-os' ) => array( 'estat-add-home', 'estat-listings', 'estat-projects', 'estat-spreadsheet', 'estat-templates', 'estat-gallery' ),
				__( 'Leads & enquiries', 'estat-os' ) => array( 'estat-enquiries', 'estat-pipeline', 'estat-visits', 'estat-requests', 'estat-forms', 'estat-search-alerts' ),
				__( 'Team & reports', 'estat-os' ) => array( 'estat-team', 'estat-reports', 'estat-insights' ),
				__( 'General & advanced', 'estat-os' ) => array( 'estat-design-tokens', 'estat-settings' ),
			);
			$original = $submenu[ self::MENU ];
			$by_slug = array();
			foreach ( $original as $item ) {
				$slug = $item[2] ?? '';
				$by_slug[ $slug ] = $item;
			}
			$new = array();
			foreach ( $groups as $heading => $slugs ) {
				$new[] = array(
					'<span class=\"estat-menu-group-heading\">' . esc_html( $heading ) . '</span>',
					'read',
					'#estat-group-' . sanitize_title( $heading ),
					$heading,
					'estat-menu-group',
				);
				foreach ( $slugs as $s ) {
					if ( isset( $by_slug[ $s ] ) ) {
						$new[] = $by_slug[ $s ];
						unset( $by_slug[ $s ] );
					}
				}
			}
			foreach ( $by_slug as $item ) { $new[] = $item; }
			$submenu[ self::MENU ] = $new;
		}

		// Gallery & Media — always registered, hidden from Stitch 8-item menu, reachable via Office tabs and direct URL
		add_submenu_page(
			'',
			__( 'Gallery & Media', 'estat-os' ),
			__( 'Gallery & Media', 'estat-os' ),
			$cap,
			'estat-gallery',
			array( Screens\GalleryScreen::class, 'render' )
		);

		if ( Screens\SetupScreen::needed() ) {
			add_submenu_page(
				self::MENU,
				__( 'Finish setup', 'estat-os' ),
				__( 'Finish setup', 'estat-os' ),
				'estat_manage_settings',
				Screens\SetupScreen::SLUG,
				array( Screens\SetupScreen::class, 'render' )
			);
		} else {
			add_submenu_page(
				'',
				__( 'Office setup', 'estat-os' ),
				'',
				'estat_manage_settings',
				Screens\SetupScreen::SLUG,
				array( Screens\SetupScreen::class, 'render' )
			);
		}

		add_submenu_page(
			'',
			__( 'Insights', 'estat-os' ),
			__( 'Insights', 'estat-os' ),
			'estat_manage_insights',
			'estat-insights',
			array( Screens\InsightsScreen::class, 'render' )
		);
	}

	public function route(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : self::MENU;

		if ( NewUI::is_enabled() ) {
			$map = array(
				'estat-today' => Screens\TodayNew::class,
				'estat-listings' => Screens\ListingsNew::class,
				'estat-add-home' => Screens\AddHomeNew::class,
				'estat-settings' => Screens\SettingsNew::class,
				'estat-enquiries' => Screens\EnquiriesNew::class,
				'estat-projects' => Screens\ProjectsNew::class,
				'estat-team' => Screens\TeamNew::class,
				'estat-spreadsheet' => Screens\SpreadsheetNew::class,
				'estat-pipeline' => Screens\PipelineNew::class,
				'estat-visits' => Screens\VisitsNew::class,
				'estat-forms' => Screens\FormsNew::class,
				'estat-insights' => Screens\InsightsNew::class,
				'estat-search-alerts' => Screens\SearchAlertsNew::class,
				'estat-reports' => Screens\ReportsNew::class,
				'estat-gallery' => Screens\GalleryNew::class,
				'estat-templates' => Screens\TemplatesScreen::class,
				'estat-design-tokens' => Screens\DesignTokensScreen::class,
				'estat-requests' => Screens\RequestsNew::class,
			);
			if ( isset( $map[ $page ] ) && class_exists( $map[ $page ] ) ) {
				$this->screens[ $page ] = array( $map[ $page ], 'render' );
			}
		}

		$handler = $this->screens[ $page ] ?? $this->screens['estat-today'];
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$editing_form = 'estat-forms' === $page && ! empty( $_GET['edit'] );
		$wrap_class   = $editing_form ? 'wrap estat-admin estat-wrap-wide' : 'wrap estat-admin';

		echo '<div class=\"' . esc_attr( $wrap_class ) . '\">';
		Screens\Partials::header( $page, $editing_form );
		if ( is_callable( $handler ) ) { call_user_func( $handler ); }
		echo '</div>';
	}

	public function assets( string $hook ): void {
		if ( false === strpos( $hook, 'estat-' ) && 'toplevel_page_' . self::MENU !== $hook ) { return; }
		wp_enqueue_style( 'estat-tokens', ESTAT_URL . 'assets/css/tokens.css', array(), ESTAT_VERSION );
		wp_enqueue_style( 'estat-admin', ESTAT_URL . 'assets/css/admin.css', array( 'estat-tokens' ), ESTAT_VERSION );
		if ( NewUI::is_enabled() ) {
			wp_enqueue_style( 'estat-admin-new', ESTAT_URL . 'assets/css/admin-new.css', array( 'estat-admin' ), ESTAT_VERSION );
		}
		wp_enqueue_script( 'estat-admin', ESTAT_URL . 'assets/js/admin.js', array( 'wp-i18n' ), ESTAT_VERSION, true );
		wp_enqueue_media();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 'estat-forms' === $page ) {
			wp_enqueue_style( 'estat-forms', ESTAT_URL . 'assets/css/forms.css', array(), ESTAT_VERSION );
			wp_enqueue_script( 'estat-form-builder', ESTAT_URL . 'assets/js/form-builder.js', array( 'estat-admin' ), ESTAT_VERSION, true );
			wp_localize_script(
				'estat-form-builder',
				'estatBuilder',
				array(
					'fieldTypes' => \EstatOS\Forms\FieldTypes::all(),
					'i18n'       => array(
						'newField'     => __( 'New field', 'estat-os' ),
						'confirmDelete'=> __( 'Remove this field?', 'estat-os' ),
						'label'        => __( 'Label', 'estat-os' ),
						'placeholder'  => __( 'Example text inside the box', 'estat-os' ),
						'help'         => __( 'Short explanation', 'estat-os' ),
						'required'     => __( 'This information is required', 'estat-os' ),
						'width'        => __( 'Width on a computer', 'estat-os' ),
						'widthTablet'  => __( 'Width on a tablet', 'estat-os' ),
						'widthMobile'  => __( 'Width on a phone', 'estat-os' ),
						'options'      => __( 'Choices (one per line)', 'estat-os' ),
						'remove'       => __( 'Remove', 'estat-os' ),
						'addRow'       => __( 'Add a row', 'estat-os' ),
						'addColumn'    => __( 'Add a column', 'estat-os' ),
						'dragHint'     => __( 'Drag to reorder', 'estat-os' ),
						'moveUp'       => __( 'Move up', 'estat-os' ),
						'moveDown'     => __( 'Move down', 'estat-os' ),
						'layout'       => __( 'Columns', 'estat-os' ),
						'gap'          => __( 'Spacing', 'estat-os' ),
						'align'        => __( 'Align', 'estat-os' ),
						'alignStretch' => __( 'Same height', 'estat-os' ),
						'alignStart'   => __( 'Top', 'estat-os' ),
						'alignCenter'  => __( 'Middle', 'estat-os' ),
						'alignEnd'     => __( 'Bottom', 'estat-os' ),
						'rowHeading'   => __( 'Optional heading for this row', 'estat-os' ),
						'columnWidth'  => __( 'Width', 'estat-os' ),
						'removeColumn' => __( 'Remove this column', 'estat-os' ),
						'confirmDeleteRow' => __( 'Remove this row and everything in it?', 'estat-os' ),
						'boxHeight'    => __( 'Box height', 'estat-os' ),
						'boxWidth'     => __( 'Box width', 'estat-os' ),
						'sizeSM'       => __( 'Small', 'estat-os' ),
						'sizeMD'       => __( 'Medium', 'estat-os' ),
						'sizeLG'       => __( 'Large', 'estat-os' ),
						'lines'        => __( 'Lines of space to type in', 'estat-os' ),
						'exactWidths'  => __( 'Exact widths', 'estat-os' ),
						'deviceBar'    => __( 'Show the layout as it appears on', 'estat-os' ),
						'deviceDesktop'=> __( 'Computer', 'estat-os' ),
						'deviceTablet' => __( 'Tablet', 'estat-os' ),
						'deviceMobile' => __( 'Phone', 'estat-os' ),
						'deviceHintDesktop' => __( 'Editing computer widths.', 'estat-os' ),
						'deviceHintTablet'  => __( 'Editing tablet widths only.', 'estat-os' ),
						'deviceHintMobile'  => __( 'Editing phone widths only.', 'estat-os' ),
						'conditionOn'  => __( 'Only shown sometimes', 'estat-os' ),
						'conditionOff' => __( 'Always shown', 'estat-os' ),
						'conditionWhen'=> __( 'Only show this box when', 'estat-os' ),
						'conditionIs'  => __( 'is', 'estat-os' ),
						'conditionAlways' => __( '— always show it —', 'estat-os' ),
						'conditionValue'  => __( 'has this answer', 'estat-os' ),
						'previewEmpty' => __( 'Add a field and it will appear here.', 'estat-os' ),
						'previewSend'  => __( 'Send', 'estat-os' ),
						'previewChoices' => __( 'Choices', 'estat-os' ),
						'previewHidden'  => __( 'Hidden on this device', 'estat-os' ),
					),
				)
			);
		}
		wp_localize_script(
			'estat-admin',
			'estatAdmin',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'estat/v1/' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'uploadNonce' => wp_create_nonce( 'estat_upload' ),
				'urls'          => array(
					'today'      => admin_url( 'admin.php?page=estat-today' ),
					'listings'   => admin_url( 'admin.php?page=estat-listings' ),
					'enquiries'  => admin_url( 'admin.php?page=estat-enquiries' ),
					'addHome'    => admin_url( 'admin.php?page=estat-add-home' ),
				),
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'i18n'     => array(
					'confirmDelete' => __( 'Are you sure? This cannot be undone.', 'estat-os' ),
					'typeDelete'    => __( 'Type DELETE in capital letters to confirm.', 'estat-os' ),
					'chooseImage'   => __( 'Choose an image', 'estat-os' ),
					'useImage'      => __( 'Use this image', 'estat-os' ),
					'tapToChoose'   => __( 'Tap to choose a photo', 'estat-os' ),
					'bulkOne'       => __( '1 ticked', 'estat-os' ),
					'bulkMany'      => __( '%d ticked', 'estat-os' ),
					'bulkConfirmTrash' => __( 'Move %d records to the bin? You can bring them back afterwards.', 'estat-os' ),
					'shortcutsTitle'   => __( 'Keyboard shortcuts', 'estat-os' ),
					'shortcutSearch'   => __( 'Jump to the search box', 'estat-os' ),
					'shortcutNew'      => __( 'Add a Home', 'estat-os' ),
					'shortcutToday'    => __( 'Go to Today', 'estat-os' ),
					'shortcutListings' => __( 'Go to Listings', 'estat-os' ),
					'shortcutEnquiries' => __( 'Go to Enquiries', 'estat-os' ),
					'shortcutSave'     => __( 'Save what you are editing', 'estat-os' ),
					'shortcutHelp'     => __( 'Show this list', 'estat-os' ),
					'shortcutClose'    => __( 'Close this list', 'estat-os' ),
					'shortcutCloseButton' => __( 'Close', 'estat-os' ),
					'saving'        => __( 'Saving…', 'estat-os' ),
					'copied'        => __( 'Copied.', 'estat-os' ),
					'uploading'     => __( 'Adding your files…', 'estat-os' ),
					'uploadDone'    => __( 'Done. Refreshing…', 'estat-os' ),
					'uploadFailed'  => __( 'Could not add this file:', 'estat-os' ),
					'tooBig'        => __( 'This file is too large to upload.', 'estat-os' ),
				),
			)
		);
	}

	public static function ajax_upload(): void {
		check_ajax_referer( 'estat_upload', 'nonce' );
		if ( ! current_user_can( 'estat_manage_listings' ) || ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to add files.', 'estat-os' ) ), 403 );
		}
		if ( empty( $_FILES['file'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file arrived. Please try again.', 'estat-os' ) ), 400 );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_handle_upload( 'file', 0 );
		if ( is_wp_error( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ), 400 );
		}
		$attachment_id = (int) $attachment_id;
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( is_array($_POST['kind']) ? '' : $_POST['kind'] ) ) : '';
		if ( '' !== $kind ) { \EstatOS\Data\Media::set_kind( $attachment_id, $kind ); }
		\EstatOS\Audit\AuditLog::record( 'media.uploaded', 'attachment', $attachment_id, array( 'kind' => $kind ) );
		wp_send_json_success( \EstatOS\Data\Media::to_array( $attachment_id ) );
	}

	public static function ajax_move_pipeline(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$lead_id = isset( $_POST['lead_id'] ) ? absint( wp_unslash( is_array($_POST['lead_id']) ? '' : $_POST['lead_id'] ) ) : 0;
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( is_array($_POST['status']) ? '' : $_POST['status'] ) ) : '';
		$allowed = \EstatOS\Support\Vocabulary::lead_pipeline_order();
		if ( ! in_array( $status, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid status', 'estat-os' ) ), 400 );
		}
		$result = \EstatOS\Leads\Leads::update( $lead_id, array( 'status' => $status ) );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 422 );
		}
		wp_send_json_success( array( 'lead_id' => $lead_id, 'status' => $status ) );
	}

	public static function ajax_test_mail(): void {
		check_ajax_referer( 'estat_test_mail', 'nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$email = Settings::notification_email();
		$sent = wp_mail( $email, __( 'Estat.OS test email — Mayfair Edition', 'estat-os' ), __( 'If you got this, your email settings are working.', 'estat-os' ) );
		if ( $sent ) {
			Settings::update( array( 'test_mail_last_sent' => current_time( 'mysql' ) ) );
			wp_send_json_success( array( 'message' => sprintf( __( 'Test email sent to %s', 'estat-os' ), $email ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Could not send email. Check your hosting mail setup.', 'estat-os' ) ), 500 );
		}
	}

	public static function ajax_test_webhook(): void {
		check_ajax_referer( 'estat_test_webhook', 'nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$res = \EstatOS\Webhooks\Webhooks::test();
		if ( ( $res['ok'] ?? false ) ) {
			wp_send_json_success( array( 'message' => sprintf( __( 'Test webhook sent! HTTP %d to %s', 'estat-os' ), (int) $res['code'], $res['url'] ?? '' ), 'code' => $res['code'] ?? 0, 'url' => $res['url'] ?? '' ) );
		} else {
			wp_send_json_error( array( 'message' => sprintf( __( 'Webhook failed: %s', 'estat-os' ), $res['error'] ?? 'unknown' ), 'code' => $res['code'] ?? 0 ), 500 );
		}
	}

	public static function ajax_lead_timeline(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_leads' ) && ! current_user_can( 'estat_agent' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$lead_id = isset( $_POST['lead_id'] ) ? absint( wp_unslash( is_array($_POST['lead_id']) ? '' : $_POST['lead_id'] ) ) : 0;
		$events = \EstatOS\Leads\LeadEvents::for_lead( $lead_id );
		wp_send_json_success( array( 'events' => $events, 'count' => count( $events ) ) );
	}

	public function body_class( string $classes ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 0 === strpos( $page, 'estat-' ) ) {
			$classes .= ' estat-screen';
			$theme = (string) Settings::get( 'admin_theme' );
			if ( ! in_array( $theme, array( 'light', 'dark', 'auto' ), true ) ) { $theme = 'light'; }
			$classes .= ' estat-theme-' . $theme;
			if ( Settings::get( 'practice_mode' ) ) { $classes .= ' estat-practice'; }
			if ( NewUI::is_enabled() ) { $classes .= ' estat-new-ui'; }
		}
		return $classes;
	}

	public function hide_clutter(): void {
		if ( current_user_can( 'manage_options' ) ) { return; }
		remove_submenu_page( 'edit.php?post_type=' . PostTypes::LISTING, 'edit-tags.php?taxonomy=' . Taxonomies::FEATURE . '&amp;post_type=' . PostTypes::LISTING );
	}
}
