<?php
/**
 * Accessible HTML renderer for plugin forms — F8 multi-step + project attach.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Forms;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Produces semantic, keyboard friendly markup with real labels, described-by
 * help text and inline error containers. No framework required.
 * F8: multi-step wizard with progress dots, Back/Next, project attach handling.
 */
final class Renderer {

	/**
	 * Render a form.
	 *
	 * @param int                 $form_id Form ID.
	 * @param array<string,mixed> $context Context: listing_id, project_id, agent_id, class.
	 * @return string HTML.
	 */
	public static function render( int $form_id, array $context = array() ): string {
		$form = Forms::get( $form_id );
		if ( ! $form || 'active' !== $form['status'] ) {
			return '';
		}

		wp_enqueue_style( 'estat-forms' );
		wp_enqueue_script( 'estat-forms' );

		$settings   = $form['settings'];
		$definition = $form['definition'];
		// B12: auto-fill context from current page if not provided.
		$listing_id = isset( $context['listing_id'] ) ? absint( $context['listing_id'] ) : 0;
		$project_id = isset( $context['project_id'] ) ? absint( $context['project_id'] ) : 0;
		$agent_id   = isset( $context['agent_id'] ) ? absint( $context['agent_id'] ) : 0;

		if ( 0 === $listing_id && is_singular( PostTypes::LISTING ) ) {
			$listing_id = (int) get_queried_object_id();
		}
		if ( 0 === $project_id && is_singular( PostTypes::PROJECT ) ) {
			$project_id = (int) get_queried_object_id();
		}
		if ( 0 === $listing_id ) {
			$maybe = get_the_ID();
			if ( $maybe && PostTypes::LISTING === get_post_type( $maybe ) ) {
				$listing_id = (int) $maybe;
			}
		}
		if ( 0 === $project_id ) {
			$maybe = get_the_ID();
			if ( $maybe && PostTypes::PROJECT === get_post_type( $maybe ) ) {
				$project_id = (int) $maybe;
			}
		}

		$dom_id     = 'estat-form-' . $form_id . '-' . wp_rand( 1000, 9999 );
		$extra      = isset( $context['class'] ) ? sanitize_html_class( (string) $context['class'] ) : '';

		$steps = Forms::get_steps( $definition );
		$is_multi = count( $steps ) > 1 || ! empty( $settings['multi_step'] );
		$show_progress = ! empty( $settings['show_progress'] );

		ob_start();
		?>
		<?php $style_css = Style::to_css( (array) ( $settings['style'] ?? array() ) ); ?>
		<div class="estat-form-wrap <?php echo esc_attr( $extra ); ?> <?php echo $is_multi ? 'is-multi-step' : ''; ?>">
			<form class="estat-form" id="<?php echo esc_attr( $dom_id ); ?>" method="post" novalidate enctype="multipart/form-data"
				style="<?php echo esc_attr( $style_css ); ?>"
				data-form-id="<?php echo esc_attr( (string) $form_id ); ?>"
				data-endpoint="<?php echo esc_url( rest_url( 'estat/v1/forms/' . $form_id . '/submit' ) ); ?>"
				data-multi-step="<?php echo $is_multi ? '1' : '0'; ?>">
				<?php wp_nonce_field( 'estat_form_submit_' . $form_id, 'estat_nonce' ); ?>
				<input type="hidden" name="listing_id" value="<?php echo esc_attr( (string) $listing_id ); ?>" />
				<input type="hidden" name="project_id" value="<?php echo esc_attr( (string) $project_id ); ?>" />
				<input type="hidden" name="agent_id" value="<?php echo esc_attr( (string) $agent_id ); ?>" />
				<input type="hidden" name="source_url" value="<?php echo esc_url( self::current_url() ); ?>" />
				<input type="hidden" name="idempotency_key" value="<?php echo esc_attr( wp_generate_uuid4() ); ?>" />
				<input type="hidden" name="page_url" value="<?php echo esc_url( self::current_url() ); ?>" />
				<div class="estat-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden">
					<label for="estat-hp-field" class="screen-reader-text"><?php esc_html_e( 'Leave this field empty', 'estat-os' ); ?></label>
					<input type="text" id="estat-hp-field" name="estat_website" tabindex="-1" autocomplete="off" value="" />
				</div>
				<input type="hidden" name="estat_ts" value="<?php echo esc_attr( (string) time() ); ?>" />

				<div class="estat-form-messages" role="status" aria-live="polite"></div>

				<?php if ( $is_multi && $show_progress ) : ?>
				<div class="estat-form-progress" style="display:flex;gap:8px;align-items:center;margin:8px 0 16px">
					<?php foreach ( $steps as $s_idx => $step ) : ?>
						<span class="estat-form-dot" data-step="<?php echo (int) $s_idx + 1; ?>" style="width:28px;height:28px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;background:#e5e7eb;color:#111"><?php echo (int) $s_idx + 1; ?></span>
						<span style="font-size:12px;color:#6b7280"><?php echo esc_html( $step['label'] ?? '' ); ?></span>
						<?php if ( $s_idx < count( $steps ) - 1 ) : ?><span style="flex:1;height:1px;background:#e5e7eb"></span><?php endif; ?>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>

				<?php foreach ( $steps as $step_idx => $step ) : ?>
				<div class="estat-form-step" data-fstep="<?php echo (int) $step_idx + 1; ?>" style="<?php echo $step_idx > 0 && $is_multi ? 'display:none' : ''; ?>">
					<?php if ( $is_multi ) : ?>
						<h3 class="estat-form-step-title" style="margin:0 0 12px;font-size:16px"><?php echo esc_html( $step['label'] ?? sprintf( __( 'Step %d', 'estat-os' ), $step_idx + 1 ) ); ?></h3>
					<?php endif; ?>
					<?php foreach ( (array) ( $step['rows'] ?? array() ) as $row ) : ?>
						<?php if ( ! empty( $row['heading'] ) ) : ?>
							<h3 class="estat-form-section"><?php echo esc_html( (string) $row['heading'] ); ?></h3>
						<?php endif; ?>
						<?php
						$row_gap    = isset( $row['gap'] ) ? (int) $row['gap'] : 16;
						$row_gap_m  = isset( $row['gap_mobile'] ) ? (int) $row['gap_mobile'] : 12;
						$row_align  = isset( $row['align'] ) ? (string) $row['align'] : 'stretch';
						$row_styles = sprintf( '--gap:%dpx;--gap-m:%dpx', $row_gap, $row_gap_m );
						?>
						<div class="estat-row is-align-<?php echo esc_attr( $row_align ); ?>" style="<?php echo esc_attr( $row_styles ); ?>">
							<?php foreach ( (array) $row['columns'] as $column ) : ?>
								<div class="estat-col" style="--w:<?php echo esc_attr( (string) (int) $column['width'] ); ?>%;--wt:<?php echo esc_attr( (string) (int) $column['width_tablet'] ); ?>%;--wm:<?php echo esc_attr( (string) (int) $column['width_mobile'] ); ?>%">
									<?php
									foreach ( (array) $column['fields'] as $field ) {
										echo self::field( $field, $dom_id, $settings, $project_id, $listing_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									}
									?>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php endforeach; ?>

				<?php if ( ! empty( $settings['require_consent'] ) ) : ?>
					<div class="estat-field estat-field-consent">
						<label for="<?php echo esc_attr( $dom_id ); ?>-consent">
							<input type="checkbox" id="<?php echo esc_attr( $dom_id ); ?>-consent" name="consent" value="1" required />
							<span><?php esc_html_e( 'I agree to be contacted about this enquiry.', 'estat-os' ); ?></span>
						</label>
					</div>
				<?php endif; ?>

				<?php
				$btn_style = (array) ( $settings['style'] ?? array() );
				$btn_align = in_array( (string) ( $btn_style['button_align'] ?? 'left' ), array( 'left', 'center', 'right' ), true ) ? (string) $btn_style['button_align'] : 'left';
				$btn_width = 'full' === ( $btn_style['button_width'] ?? 'auto' ) ? ' is-full' : '';
				$next_label = $settings['next_label'] ?? __( 'Next', 'estat-os' );
				$prev_label = $settings['prev_label'] ?? __( 'Back', 'estat-os' );
				?>
				<div class="estat-form-actions is-<?php echo esc_attr( $btn_align ); ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">
					<?php if ( $is_multi ) : ?>
						<button type="button" class="estat-btn estat-form-prev" style="display:none"><?php echo esc_html( $prev_label ); ?></button>
						<button type="button" class="estat-btn estat-btn-primary estat-form-next"><?php echo esc_html( $next_label ); ?></button>
					<?php endif; ?>
					<button type="submit" class="estat-btn estat-btn-primary<?php echo esc_attr( $btn_width ); ?>" style="<?php echo $is_multi ? 'display:none' : ''; ?>"><?php echo esc_html( (string) $settings['submit_label'] ); ?></button>
					<span class="estat-form-spinner" hidden aria-hidden="true"></span>
				</div>
			</form>
		</div>
		<?php if ( $is_multi ) : ?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const form = document.getElementById('<?php echo esc_js( $dom_id ); ?>');
			if(!form) return;
			let step = 1;
			const max = <?php echo (int) count( $steps ); ?>;
			const dots = form.querySelectorAll('.estat-form-dot');
			const prev = form.querySelector('.estat-form-prev');
			const next = form.querySelector('.estat-form-next');
			const submit = form.querySelector('button[type=submit]');
			function show(s){
				step = s;
				form.querySelectorAll('.estat-form-step').forEach(d=>{
					d.style.display = parseInt(d.getAttribute('data-fstep'))===step ? 'block' : 'none';
				});
				dots.forEach(d=>{
					const ds = parseInt(d.getAttribute('data-step'));
					d.style.background = ds===step ? '#111' : (ds<step ? '#10b981' : '#e5e7eb');
					d.style.color = ds===step || ds<step ? '#fff' : '#111';
				});
				if(prev) prev.style.display = step>1 ? 'inline-flex' : 'none';
				if(next) next.style.display = step<max ? 'inline-flex' : 'none';
				if(submit) submit.style.display = step===max ? 'inline-flex' : 'none';
			}
			function validateStep(){
				const cur = form.querySelector('.estat-form-step[data-fstep="'+step+'"]');
				if(!cur) return true;
				const required = cur.querySelectorAll('[required]');
				for(let el of required){
					if(!el.value || (el.type==='checkbox' && !el.checked)){
						el.reportValidity && el.reportValidity();
						return false;
					}
				}
				return true;
			}
			if(next) next.addEventListener('click', function(){ if(validateStep() && step<max){ show(step+1); } });
			if(prev) prev.addEventListener('click', function(){ if(step>1){ show(step-1); } });
			show(1);
		});
		</script>
		<?php endif; ?>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Render one field — 3.0.7 root fix for "F mty6e0d14" labels.
	 *
	 * Root cause: form-builder.js generates field.id via uid('f') => f_<base36><counter> e.g. f_mty6e0d14.
	 * Previous code treated label === FieldTypes label (e.g. "Locality" === "Locality") as generic placeholder
	 * and replaced it with humanized id => "F mty6e0d14". Form 9 had configured labels (locality, budget)
	 * which were being overwritten. Fix: never overwrite a non-empty configured label that doesn't itself look
	 * like an auto-id. Only fallback when label empty or itself is auto-id pattern.
	 *
	 * @param array<string,mixed> $field  Field definition.
	 * @param string              $dom_id Form DOM id prefix.
	 * @param array<string,mixed> $settings Form settings.
	 * @param int                 $project_id Current project ID.
	 * @param int                 $listing_id Current listing ID.
	 * @return string HTML.
	 */
	private static function field( array $field, string $dom_id, array $settings = array(), int $project_id = 0, int $listing_id = 0 ): string {
		$type = (string) $field['type'];
		$id   = $dom_id . '-' . sanitize_html_class( (string) $field['id'] );
		$name = 'fields[' . (string) $field['id'] . ']';
		$def  = FieldTypes::get( $type );

		// 3.0.7 root fix: detect auto-generated ids/labels.
		$raw_label = trim( (string) ( $field['label'] ?? '' ) );
		$raw_id    = (string) ( $field['id'] ?? '' );

		$is_auto_label = '' === $raw_label
			|| (bool) preg_match( '/^F\s+[a-z0-9]+$/i', $raw_label )
			|| (bool) preg_match( '/^f_[a-z0-9]+$/i', $raw_label )
			|| (bool) preg_match( '/^F_[a-z0-9]+$/i', $raw_label );

		$is_auto_id = (bool) preg_match( '/^F\s+[a-z0-9]+$/i', trim( $raw_id ) )
			|| (bool) preg_match( '/^f_[a-z0-9]+$/i', $raw_id )
			|| (bool) preg_match( '/^F_[a-z0-9]+$/i', $raw_id );

		if ( $is_auto_id ) {
			// Generate safe stable id for HTML, keep mapping via hash so submission still works.
			$field['id'] = 'field_' . substr( md5( $raw_id ), 0, 8 );
			$id = $dom_id . '-' . sanitize_html_class( (string) $field['id'] );
			$name = 'fields[' . (string) $field['id'] . ']';
		}

		if ( $is_auto_label ) {
			// Prefer placeholder, then meaningful type label (not generic "Dropdown").
			$fallback = '';
			if ( '' !== (string) ( $field['placeholder'] ?? '' ) ) {
				$fallback = (string) $field['placeholder'];
			} elseif ( ! empty( $def['label'] ) ) {
				$generic_map = array(
					'Short text'      => __( 'Your name', 'estat-os' ),
					'Long text'       => __( 'Your message', 'estat-os' ),
					'Dropdown'        => __( 'Please select', 'estat-os' ),
					'Choose one'      => __( 'Please select', 'estat-os' ),
					'Single tick box' => __( 'I agree', 'estat-os' ),
					'Choose many'     => __( 'Select options', 'estat-os' ),
				);
				$type_label = (string) $def['label'];
				$fallback = $generic_map[ $type_label ] ?? $type_label;
			}
			$field['label'] = '' !== $fallback ? $fallback : __( 'Your enquiry', 'estat-os' );
		}
		// IMPORTANT: do NOT overwrite label when it equals $def['label'] (e.g. "Locality", "Budget")
		// because those ARE the configured labels Form 9 uses. Previous logic turned them into "F mty6e0d14".

		if ( 'consent' === $type ) {
			$consent_text = \EstatOS\Settings\Settings::get( 'consent_text', '' );
			if ( '' !== $consent_text ) {
				$field['label'] = $consent_text;
			}
		}

		// Final guard: if label still looks like auto-id, replace.
		$final_label = trim( (string) $field['label'] );
		if ( preg_match( '/^F\s+[a-z0-9]+$/i', $final_label ) || preg_match( '/^f_[a-z0-9]+$/i', $final_label ) || preg_match( '/^F_[a-z0-9]+$/i', $final_label ) ) {
			$field['label'] = __( 'Your enquiry', 'estat-os' );
		}

		if ( 'heading' === $type ) {
			return '<h4 class="estat-form-heading">' . esc_html( (string) $field['label'] ) . '</h4>';
		}
		if ( 'paragraph' === $type ) {
			return '<p class="estat-form-paragraph">' . esc_html( (string) $field['content'] ) . '</p>';
		}
		if ( 'submit' === $type ) {
			return '';
		}
		if ( 'hidden' === $type ) {
			return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $field['default'] ) . '" />';
		}

		// F8: project attach handling.
		if ( 'project' === $type ) {
			$attach_mode = $settings['project_attach'] ?? 'auto';
			if ( 'auto' === $attach_mode && $project_id > 0 ) {
				return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $project_id ) . '" />';
			}
			if ( 'hidden' === $attach_mode && $project_id > 0 ) {
				return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $project_id ) . '" />';
			}
			if ( 'dropdown' === $attach_mode || 0 === $project_id ) {
				$projects = get_posts( array( 'post_type' => \EstatOS\Data\PostTypes::PROJECT, 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids' ) );
				$options_html = '<option value="">' . esc_html__( 'Select a project', 'estat-os' ) . '</option>';
				foreach ( $projects as $pid ) {
					$selected = (int) $pid === $project_id ? ' selected' : '';
					$options_html .= '<option value="' . esc_attr( (string) $pid ) . '"' . $selected . '>' . esc_html( get_the_title( $pid ) ) . '</option>';
				}
				$required  = ! empty( $field['required'] );
				$help_id   = $id . '-help';
				$error_id  = $id . '-error';
				ob_start();
				echo '<div class="estat-field estat-field-project" style="--fw:' . esc_attr( (string) (int) $field['width'] ) . '%">';
				if ( '' !== (string) $field['label'] ) {
					echo '<label class="estat-label" for="' . esc_attr( $id ) . '">' . esc_html( (string) $field['label'] );
					echo $required ? ' <span class="estat-req">*</span>' : '';
					echo '</label>';
				}
				echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="estat-input" style="width:100%"' . ( $required ? ' required' : '' ) . '>' . $options_html . '</select>';
				if ( '' !== (string) $field['help'] ) {
					echo '<p class="estat-help" id="' . esc_attr( $help_id ) . '">' . esc_html( (string) $field['help'] ) . '</p>';
				}
				echo '<p class="estat-error" id="' . esc_attr( $error_id ) . '" role="alert"></p>';
				echo '</div>';
				return (string) ob_get_clean();
			}
		}

		if ( 'property' === $type ) {
			if ( $listing_id > 0 ) {
				return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $listing_id ) . '" />';
			}
		}

		$required  = ! empty( $field['required'] );
		$help_id   = $id . '-help';
		$error_id  = $id . '-error';
		$described = array();
		if ( '' !== (string) $field['help'] ) {
			$described[] = $help_id;
		}
		$described[] = $error_id;

		$size    = in_array( (string) ( $field['size'] ?? 'md' ), array( 'sm', 'md', 'lg' ), true ) ? (string) $field['size'] : 'md';
		$classes = array( 'estat-field', 'estat-field-' . sanitize_html_class( $type ), 'estat-size-' . $size );
		foreach ( array( 'desktop', 'tablet', 'mobile' ) as $device ) {
			if ( empty( $field['visible'][ $device ] ) ) {
				$classes[] = 'estat-hide-' . $device;
			}
		}

		$condition = '';
		if ( ! empty( $field['condition']['field'] ) ) {
			$condition = ' data-condition="' . esc_attr( (string) wp_json_encode( $field['condition'] ) ) . '"';
		}

		$attrs = array(
			'id'          => $id,
			'name'        => $name,
			'class'       => 'estat-input',
			'placeholder' => (string) $field['placeholder'],
			'style'       => 'width:100%',
		);
		if ( $required ) {
			$attrs['required']      = 'required';
			$attrs['aria-required'] = 'true';
		}
		$attrs['aria-describedby'] = implode( ' ', $described );

		ob_start();
		echo '<div class="' . esc_attr( implode( ' ', $classes ) ) . '" style="--fw:' . esc_attr( (string) (int) $field['width'] ) . '%"' . $condition . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'checkbox' !== $def['input'] && '' !== (string) $field['label'] ) {
			echo '<label class="estat-label" for="' . esc_attr( $id ) . '">' . esc_html( (string) $field['label'] );
			echo $required ? ' <span class="estat-req" aria-hidden="true">*</span><span class="screen-reader-text">' . esc_html__( '(required)', 'estat-os' ) . '</span>' : ' <span class="estat-opt">' . esc_html__( '(optional)', 'estat-os' ) . '</span>';
			echo '</label>';
		}

		$default = (string) $field['default'];

		switch ( $def['input'] ) {
			case 'textarea':
				echo '<textarea';
				foreach ( $attrs as $k => $v ) {
					if ( 'placeholder' === $k ) { echo ' placeholder="' . esc_attr( $v ) . '"'; continue; }
					echo ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
				}
				echo ' rows="' . esc_attr( (string) (int) $field['rows'] ) . '">';
				echo esc_textarea( $default );
				echo '</textarea>';
				break;

			case 'select':
				echo '<select';
				foreach ( $attrs as $k => $v ) {
					if ( in_array( $k, array( 'placeholder' ), true ) ) { continue; }
					echo ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
				}
				echo '>';
				if ( '' !== (string) $field['placeholder'] ) {
					echo '<option value="" disabled selected hidden>' . esc_html( (string) $field['placeholder'] ) . '</option>';
				}
				$source = $def['source'] ?? '';
				if ( 'property_type' === $type || 'property_type' === $source ) {
					foreach ( Vocabulary::property_types() as $val => $label ) {
						echo '<option value="' . esc_attr( $val ) . '"' . selected( $default, $val, false ) . '>' . esc_html( $label ) . '</option>';
					}
				} elseif ( 'locality' === $type || 'locality' === $source ) {
					$terms = get_terms( array( 'taxonomy' => Taxonomies::LOCALITY, 'hide_empty' => false, 'number' => 100 ) );
					if ( ! is_wp_error( $terms ) ) {
						foreach ( $terms as $term ) {
							echo '<option value="' . esc_attr( $term->slug ) . '">' . esc_html( $term->name ) . '</option>';
						}
					}
				} elseif ( 'listing' === $source ) {
					$posts = get_posts( array( 'post_type' => PostTypes::LISTING, 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids' ) );
					foreach ( $posts as $pid ) {
						echo '<option value="' . esc_attr( (string) $pid ) . '">' . esc_html( get_the_title( $pid ) ) . '</option>';
					}
				} elseif ( 'project' === $source ) {
					$posts = get_posts( array( 'post_type' => PostTypes::PROJECT, 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids' ) );
					foreach ( $posts as $pid ) {
						echo '<option value="' . esc_attr( (string) $pid ) . '">' . esc_html( get_the_title( $pid ) ) . '</option>';
					}
				} elseif ( 'agent' === $source ) {
					$posts = get_posts( array( 'post_type' => PostTypes::AGENT, 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids' ) );
					foreach ( $posts as $pid ) {
						echo '<option value="' . esc_attr( (string) $pid ) . '">' . esc_html( get_the_title( $pid ) ) . '</option>';
					}
				} else {
					foreach ( (array) $field['options'] as $opt ) {
						$val = (string) $opt['value'];
						$lab = (string) $opt['label'];
						echo '<option value="' . esc_attr( $val ) . '"' . selected( $default, $val, false ) . '>' . esc_html( $lab ) . '</option>';
					}
				}
				echo '</select>';
				break;

			case 'radio':
				foreach ( (array) $field['options'] as $opt ) {
					$val = (string) $opt['value'];
					$lab = (string) $opt['label'];
					$rid = $id . '-' . sanitize_html_class( $val );
					echo '<label class="estat-radio" for="' . esc_attr( $rid ) . '"><input type="radio" id="' . esc_attr( $rid ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"' . ( $required ? ' required' : '' ) . '> ' . esc_html( $lab ) . '</label>';
				}
				break;

			case 'checkbox':
				if ( 'consent' === $type ) {
					echo '<label class="estat-check" for="' . esc_attr( $id ) . '"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1"' . ( $required ? ' required' : '' ) . '> ' . esc_html( (string) $field['label'] ) . '</label>';
				} else {
					echo '<label class="estat-check" for="' . esc_attr( $id ) . '"><input type="checkbox"';
					foreach ( $attrs as $k => $v ) {
						if ( in_array( $k, array( 'placeholder', 'class', 'style' ), true ) ) { continue; }
						echo ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
					}
					echo '> ' . esc_html( (string) $field['label'] ) . '</label>';
				}
				break;

			case 'checklist':
				foreach ( (array) $field['options'] as $opt ) {
					$val = (string) $opt['value'];
					$lab = (string) $opt['label'];
					$rid = $id . '-' . sanitize_html_class( $val );
					echo '<label class="estat-check" for="' . esc_attr( $rid ) . '"><input type="checkbox" id="' . esc_attr( $rid ) . '" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $val ) . '"> ' . esc_html( $lab ) . '</label>';
				}
				break;

			default:
				echo '<input';
				$input_type = (string) $def['input'];
				echo ' type="' . esc_attr( $input_type ) . '"';
				foreach ( $attrs as $k => $v ) {
					echo ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
				}
				echo ' value="' . esc_attr( $default ) . '"';
				echo ' />';
				break;
		}

		if ( '' !== (string) $field['help'] && 'checkbox' !== $def['input'] ) {
			echo '<p class="estat-help" id="' . esc_attr( $help_id ) . '">' . esc_html( (string) $field['help'] ) . '</p>';
		}
		echo '<p class="estat-error" id="' . esc_attr( $error_id ) . '" role="alert"></p>';
		echo '</div>';

		return (string) ob_get_clean();
	}

	/**
	 * Current URL.
	 *
	 * @return string
	 */
	private static function current_url(): string {
		$scheme = is_ssl() ? 'https://' : 'http://';
		$host   = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( '' === $host ) {
			return home_url( '/' );
		}
		return $scheme . $host . $uri;
	}
}
