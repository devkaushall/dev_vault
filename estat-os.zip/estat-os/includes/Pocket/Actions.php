<?php
/**
 * Every write the pocket can perform. One action per button, each one a thin
 * wrapper around the class that already owns that job in wp-admin — the
 * pocket never keeps a second copy of a rule, because second copies are how
 * the phone and the office start disagreeing about what a person may do.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Pocket;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Static dispatcher; see the cases for the grammar of each button.
 */
final class Actions {

	/**
	 * Actions a signed-in pocket user may reach for. Capability gates are
	 * inside each case, because "who may press this" is part of the job, not
	 * a coat of paint at the door.
	 *
	 * @var string[]
	 */
	public const ACTIONS = array(
		'save_draft',
		'send',
		'request',
		'pause',
		'resume',
		'trash_draft',
		'log_visit',
		'lead_update',
		'request_approve',
		'request_decline',
		'listing_approve',
		'listing_decline',
	);

	/**
	 * Verify once, then route.
	 *
	 * @param string $view The screen that posted.
	 * @param int    $id   The record in the URL, when the view has one.
	 * @return void
	 */
	public static function run( string $view, int $id ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$nonce  = isset( $_POST['_estat_pocket'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['_estat_pocket']) ? '' : $_POST['_estat_pocket'] ) ) ) : '';
		$action = isset( $_POST['estat_pocket_action'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_pocket_action']) ? '' : $_POST['estat_pocket_action'] ) ) ) : '';
		// phpcs:enable

		if ( ! is_user_logged_in() || ! wp_verify_nonce( $nonce, 'estat_pocket' ) ) {
			Pocket::fail_to_today( 'bad' );
		}
		if ( ! Pocket::can_use() ) {
			Pocket::fail_to_today( 'nope' );
		}
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			Pocket::fail_to_today( 'bad' );
		}

		self::$view = $view;
		self::$id   = $id;

		switch ( $action ) {
			case 'save_draft':
				self::save_draft();
				break;
			case 'send':
				self::propose();
				break;
			case 'request':
				self::request_change();
				break;
			case 'pause':
			case 'resume':
				self::visibility( 'pause' === $action ? 'private' : 'publish' );
				break;
			case 'trash_draft':
				self::remove_draft();
				break;
			case 'log_visit':
				self::log_visit();
				break;
			case 'lead_update':
				self::lead_update();
				break;
			case 'request_approve':
			case 'request_decline':
				self::settle_request( 'request_approve' === $action ? 'approve' : 'decline' );
				break;
			case 'listing_approve':
			case 'listing_decline':
				self::settle_proposal( 'listing_approve' === $action ? 'publish' : 'draft' );
				break;
		}

		// Every case redirects; falling here means a case forgot to.
		Pocket::fail_to_today( 'bad' );
	}

	/**
	 * Where to bounce back to after the action; set by the dispatcher.
	 *
	 * @var string
	 */
	private static string $view = '';

	/**
	 * The record the posted form was about; set by the dispatcher.
	 *
	 * @var int
	 */
	private static int $id = 0;

	/**
	 * A safe back-view for the current flow.
	 *
	 * @param string $fallback View slug when the action was not on a record.
	 * @return string
	 */
	private static function back( string $fallback = 'listings' ): string {
		return self::$id > 0 && '' === self::$view ? 'listing' : ( '' !== self::$view ? self::$view : $fallback );
	}

	/**
	 * One int from POST.
	 *
	 * @param string $key Field name.
	 * @return int
	 */
	private static function int_post( string $key ): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? absint( wp_unslash( is_array($_POST[ $key ]) ? '' : $_POST[ $key ] ) ) : 0;
	}

	/* ---------------------------------------------------------------------
	 * Listings: draft, propose, request, visibility, removal
	 * ------------------------------------------------------------------ */

	/**
	 * Create or re-save an agent draft, then optionally walk it into the
	 * office's queue. Photos are handled here, not in a separate tab —
	 * whoever photographed the flat on the way out is the person who should
	 * be able to finish the listing in the same five minutes.
	 *
	 * @return void
	 */
	private static function save_draft(): void {
		$record_id = self::int_post( 'record_id' );

		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$post = $record_id > 0 ? get_post( $record_id ) : null;
		if ( $record_id > 0 && ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( $post && ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail( self::back(), $record_id, __( 'That listing belongs to someone else. From the phone, you can ask the office to change it.', 'estat-os' ) );
		}
		if ( $post && ! in_array( $post->post_status, array( 'draft', 'pending' ), true ) ) {
			// Live records move only through a request. This is the phone's
			// rule, and the pocket enforces it at the door instead of hoping
			// the screen hid the right buttons.
			Pocket::fail( self::back(), $record_id, __( 'That listing is out of draft, so it has to go through the office queue.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$input = array(
			'title'           => isset( $_POST['title'] ) ? wp_unslash( (string) ( is_array($_POST['title']) ? '' : $_POST['title'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'property_type'   => isset( $_POST['property_type'] ) ? wp_unslash( (string) ( is_array($_POST['property_type']) ? '' : $_POST['property_type'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'offer'           => isset( $_POST['offer'] ) ? wp_unslash( (string) ( is_array($_POST['offer']) ? '' : $_POST['offer'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'price'           => isset( $_POST['price'] ) ? wp_unslash( (string) ( is_array($_POST['price']) ? '' : $_POST['price'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'rent'            => isset( $_POST['rent'] ) ? wp_unslash( (string) ( is_array($_POST['rent']) ? '' : $_POST['rent'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'address'         => isset( $_POST['address'] ) ? wp_unslash( (string) ( is_array($_POST['address']) ? '' : $_POST['address'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'bedrooms'        => isset( $_POST['bedrooms'] ) ? wp_unslash( (string) ( is_array($_POST['bedrooms']) ? '' : $_POST['bedrooms'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'bathrooms'       => isset( $_POST['bathrooms'] ) ? wp_unslash( (string) ( is_array($_POST['bathrooms']) ? '' : $_POST['bathrooms'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'description'     => isset( $_POST['body'] ) ? wp_unslash( (string) ( is_array($_POST['body']) ? '' : $_POST['body'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'status'          => 'draft',
		);
		$next = isset( $_POST['estat_pocket_next'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_pocket_next']) ? '' : $_POST['estat_pocket_next'] ) ) ) : 'draft';
		// phpcs:enable

		foreach ( array( 'price', 'rent', 'bedrooms', 'bathrooms' ) as $number_key ) {
			if ( '' === trim( (string) $input[ $number_key ] ) ) {
				unset( $input[ $number_key ] ); // Blank means "leave it", not "erase the office's number".
			}
		}

		$result = Listings::save( $input, $record_id );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'new', $record_id, (string) $result->get_error_message() );
		}
		$listening = (int) $result;

		$photos = self::handle_photos( $listening );

		// A brand-new listing belongs to the person who typed it; assign it
		// here because Listings::save only takes what the admin form passes,
		// and the pocket knows who is holding the phone.
		if ( 0 === $record_id ) {
			update_post_meta( $listening, '_estat_assigned_user', get_current_user_id() );
			$agent = Pocket::agent_id();
			if ( $agent > 0 ) {
				update_post_meta( $listening, '_estat_agent_id', $agent );
			}
		}

		if ( 'send' === $next ) {
			self::move_status( $listening, 'pending', 'listing.submitted', __( 'Sent for approval from the pocket.', 'estat-os' ) );
			Pocket::redirect( 'listing', $listening, 'sent' );
		}

		Pocket::redirect( 'listing', $listening, $photos > 0 ? 'photos' : 'saved' );
	}

	/**
	 * Save from the detail page: same draft rules, fewer fields to change.
	 * (Kept separate so the "send" button on a detail row can never create
	 * a half-listing.)
	 *
	 * @return void
	 */
	private static function propose(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || ! ( 'draft' === $post->post_status && ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) ) {
			Pocket::fail( 'listing', $record_id, __( 'Only your own drafts can be sent from here.', 'estat-os' ) );
		}
		if ( '' === trim( (string) $post->post_title ) ) {
			Pocket::fail( 'listing', $record_id, __( 'A title is the one thing a listing cannot be sent without.', 'estat-os' ) );
		}
		self::move_status( $record_id, 'pending', 'listing.submitted', __( 'Sent for approval from the pocket.', 'estat-os' ) );
		Pocket::redirect( 'listing', $record_id, 'sent' );
	}

	/**
	 * File a change request. The same five inputs the office reviews on
	 * their screen, because the same class writes the row.
	 *
	 * @return void
	 */
	private static function request_change(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || ! Pocket::can_see( $post ) ) {
			Pocket::fail_to_today( 'gone' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$changes = isset( $_POST['changes'] ) ? (array) wp_unslash( is_array($_POST['changes']) ? '' : $_POST['changes'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$message = isset( $_POST['message'] ) ? Sanitize::textarea( wp_unslash( (string) ( is_array($_POST['message']) ? '' : $_POST['message'] ) ) ) : '';
		// phpcs:enable

		if ( '' === $message ) {
			Pocket::fail( 'change', $record_id, __( 'Add one line about how you know, so the office can decide without calling you.', 'estat-os' ) );
		}

		$changes['note'] = $message;

		$result = Requests::create(
			array(
				'record_id' => $record_id,
				'changes'   => $changes,
				'message'   => $message,
			)
		);
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'change', $record_id, $result->get_error_message() );
		}

		Pocket::redirect( 'listing', $record_id, 'requested' );
	}

	/**
	 * Pause and resume. Both are allowed straight from a phone because they
	 * only ever take the website down, never put anything up — the direction
	 * of travel is the safety argument, and it is written here so the next
	 * person who "improves" this file reads it first.
	 *
	 * @param string $status Target post_status.
	 * @return void
	 */
	private static function visibility( string $status ): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post || ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$from = 'private' === $status ? 'publish' : 'private';
		if ( $post->post_status !== $from ) {
			Pocket::fail( 'listing', $record_id, __( 'That listing is not in a state this button can act on. Refresh the page.', 'estat-os' ) );
		}

		self::move_status(
			$record_id,
			$status,
			'private' === $status ? 'listing.paused' : 'listing.resumed',
			'private' === $status ? __( 'Paused from the pocket.', 'estat-os' ) : __( 'Put back live from the pocket.', 'estat-os' )
		);

		Pocket::redirect( 'listing', $record_id, 'private' === $status ? 'paused' : 'resumed' );
	}

	/**
	 * Delete, with the phone's limits: own drafts only, and never anything
	 * published. Removal from the live site is an office act.
	 *
	 * @return void
	 */
	private static function remove_draft(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( 'publish' === $post->post_status ) {
			Pocket::fail( 'listing', $record_id, __( 'A live listing is not deleted from a phone — pause it, and the office can finish it off from the dashboard.' ) );
		}
		if ( ! ( in_array( $post->post_status, array( 'draft', 'pending' ), true ) && ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) ) {
			Pocket::fail( 'listing', $record_id, __( 'That is not your draft to remove.', 'estat-os' ) );
		}
		if ( ! current_user_can( 'delete_post', $record_id ) ) {
			Pocket::fail( 'listing', $record_id, __( 'Your account cannot remove records. The office can.', 'estat-os' ) );
		}

		wp_trash_post( $record_id );
		AuditLog::record( 'listing.trashed', $post->post_type, $record_id, array( 'channel' => 'pocket', 'reason' => 'own draft removed from phone' ) );

		Pocket::redirect( 'listings', 0, 'trashed' );
	}

	/* ---------------------------------------------------------------------
	 * Enquiries
	 * ------------------------------------------------------------------ */

	/**
	 * Book the visit the agent just agreed on the phone call.
	 *
	 * @return void
	 */
	private static function log_visit(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::must_see_lead( $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$lead = Leads::get( $lead_id );
		// phpcs:enable

		$result = Visits::schedule(
			array(
				'lead_id'      => $lead_id,
				'listing_id'   => $lead ? (int) $lead['listing_id'] : 0,
				'agent_id'     => Pocket::agent_id(),
				'scheduled_at' => isset( $_POST['scheduled_at'] ) ? Sanitize::text( wp_unslash( (string) ( is_array($_POST['scheduled_at']) ? '' : $_POST['scheduled_at'] ) ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			)
		);

		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'enquiry', $lead_id, $result->get_error_message() );
		}

		Pocket::redirect( 'enquiry', $lead_id, 'visit' );
	}

	/**
	 * Move a lead's status and add a note, together, because the office
	 * reads notes with statuses in mind.
	 *
	 * @return void
	 */
	private static function lead_update(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::must_see_lead( $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['status']) ? '' : $_POST['status'] ) ) ) : '';
		$notes  = isset( $_POST['notes'] ) ? wp_unslash( (string) ( is_array($_POST['notes']) ? '' : $_POST['notes'] ) ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$intent = isset( $_POST['intent'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['intent']) ? '' : $_POST['intent'] ) ) ) : '';
		$lost_reason = isset( $_POST['lost_reason'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['lost_reason']) ? '' : $_POST['lost_reason'] ) ) ) : '';
		$followup_at = isset( $_POST['followup_at'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['followup_at']) ? '' : $_POST['followup_at'] ) ) ) : '';
		// phpcs:enable

		$allowed = array_keys( Vocabulary::lead_statuses() );
		$input   = array();
		if ( in_array( $status, $allowed, true ) ) {
			$input['status'] = $status;
		}
		if ( is_string( $notes ) ) {
			$input['notes'] = $notes;
		}
		if ( '' !== $intent && in_array( $intent, array_keys( Vocabulary::lead_intents() ), true ) ) {
			$input['intent'] = $intent;
		}
		if ( '' !== $lost_reason && in_array( $lost_reason, array_keys( Vocabulary::lead_lost_reasons() ), true ) ) {
			$input['lost_reason'] = $lost_reason;
		}
		if ( '' !== $followup_at ) {
			$input['followup_at'] = $followup_at;
		}
		if ( ! $input ) {
			Pocket::fail( 'enquiry', $lead_id, __( 'Nothing to save there.', 'estat-os' ) );
		}

		$result = Leads::update( $lead_id, $input );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'enquiry', $lead_id, $result->get_error_message() );
		}

		Pocket::redirect( 'enquiry', $lead_id, 'note' );
	}

	/**
	 * Leads are personal data; the pocket shares them exactly the way the
	 * office's screens do — mine, or all of them for the office.
	 *
	 * @param int $lead_id Lead row ID.
	 * @return void
	 */
	private static function must_see_lead( int $lead_id ): void {
		$lead = $lead_id > 0 ? Leads::get( $lead_id ) : null;
		if ( ! $lead ) {
			Pocket::fail_to_today( 'gone' );
		}
		$agent_id = Pocket::agent_id();
		$ok = Pocket::is_office()
			|| (int) $lead['agent_id'] === $agent_id
			|| ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent_id )
			|| ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
		if ( ! $ok ) {
			Pocket::fail_to_today( 'nope' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Office side
	 * ------------------------------------------------------------------ */

	/**
	 * Approve or turn down a change request — through the same
	 * Requests::approve() the admin screen uses, so applying a change from a
	 * phone writes the audit row, the undo snapshot and the index update.
	 *
	 * @param string $verb approve|decline.
	 * @return void
	 */
	private static function settle_request( string $verb ): void {
		if ( ! Pocket::is_office() ) {
			Pocket::fail_to_today( 'nope' );
		}
		$request_id = self::int_post( 'request_id' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason = isset( $_POST['reason'] ) ? Sanitize::textarea( wp_unslash( (string) ( is_array($_POST['reason']) ? '' : $_POST['reason'] ) ) ) : '';
		// phpcs:enable

		$result = 'approve' === $verb ? Requests::approve( $request_id ) : Requests::decline( $request_id, $reason );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'approvals', 0, $result->get_error_message() );
		}
		Pocket::redirect( 'approvals', 0, 'approve' === $verb ? 'approved' : 'declined' );
	}

	/**
	 * Publish or return a proposed listing. Publish needs the same
	 * capability the admin screen asks for; there is no phone version of
	 * that permission, deliberately.
	 *
	 * @param string $status publish|draft.
	 * @return void
	 */
	private static function settle_proposal( string $status ): void {
		if ( ! current_user_can( 'estat_publish_listings' ) && ! current_user_can( 'estat_manage_settings' ) ) {
			Pocket::fail_to_today( 'nope' );
		}
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || 'pending' !== $post->post_status ) {
			Pocket::fail( 'approvals', 0, __( 'That proposal is not waiting any more. Refresh the list.', 'estat-os' ) );
		}

		self::move_status(
			$record_id,
			$status,
			'publish' === $status ? 'listing.published' : 'listing.returned',
			'publish' === $status ? __( 'Approved and published from the pocket.', 'estat-os' ) : __( 'Sent back to the agent as a draft, from the pocket.', 'estat-os' )
		);

		Pocket::redirect( 'approvals', 0, 'publish' === $status ? 'listed' : 'listed_back' );
	}

	/* ---------------------------------------------------------------------
	 * Shared moves
	 * ------------------------------------------------------------------ */

	/**
	 * One status move, one audit line, the saving class doing the writing.
	 *
	 * @param int    $record_id Post ID.
	 * @param string $status    Target post_status.
	 * @param string $action    Audit action word.
	 * @param string $note      Short human sentence for the audit row.
	 * @return void
	 */
	private static function move_status( int $record_id, string $status, string $action, string $note ): void {
		$post = get_post( $record_id );
		if ( ! $post ) {
			return;
		}
		wp_update_post(
			array(
				'ID'          => $record_id,
				'post_status' => $status,
			)
		);
		AuditLog::record( $action, $post->post_type, $record_id, array( 'channel' => 'pocket', 'note' => $note ) );
	}

	/**
	 * Pull photographs off the posted form and onto the listing.
	 *
	 * @param int $listing_id Post ID.
	 * @return int How many were taken.
	 */
	private static function handle_photos( int $listing_id ): int {
		if ( empty( $_FILES['estat_pocket_photos'] ) || ! is_array( $_FILES['estat_pocket_photos']['name'] ) ) {
			return 0;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$files = $_FILES['estat_pocket_photos']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- re-indexed by shape below, each piece validated.
		$added = array();

		foreach ( array_keys( (array) $files['name'] ) as $i ) {
			if ( 0 !== (int) $files['error'][ $i ] || '' === (string) $files['name'][ $i ] ) {
				continue;
			}
			if ( 0 !== strpos((string) $files['type'][ $i ], 'image/') || (int) $files['size'][ $i ] > 8 * 1024 * 1024 ) {
				continue; // Images under eight megabytes; anything else is not a photo.
			}

			$_FILES['estat_pocket_photo'] = array(
				'name'     => (string) $files['name'][ $i ],
				'type'     => (string) $files['type'][ $i ],
				'tmp_name' => (string) $files['tmp_name'][ $i ],
				'error'    => (int) $files['error'][ $i ],
				'size'     => (int) $files['size'][ $i ],
			);
			$attachment = media_handle_upload( 'estat_pocket_photo', $listing_id );
			unset( $_FILES['estat_pocket_photo'] );

			if ( ! is_wp_error( $attachment ) ) {
				$added[] = (int) $attachment;
			}
		}

		if ( ! $added ) {
			return 0;
		}

		$gallery = array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, '_estat_gallery', true ) ) );
		$gallery = array_slice( array_merge( $gallery, $added ), 0, 40 );
		update_post_meta( $listing_id, '_estat_gallery', array_values( $gallery ) );

		if ( ! has_post_thumbnail( $listing_id ) ) {
			Listings::set_cover( $listing_id, $added[0] );
		}

		return count( $added );
	}
}
