<?php
/**
 * Every screen of the pocket, rendered server-side from the plugin's own
 * data classes. No JavaScript is required for anything on these pages; the
 * phone browser only draws what the office already knows how to do.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Pocket;

use EstatOS\Data\Meta;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Rendering only. Every write goes through Actions.
 */
final class Screens {

	/**
	 * Entry point from the router.
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID for the two-record views.
	 * @return void
	 */
	public static function render( string $view, int $id = 0 ): void {
		if ( ! is_user_logged_in() ) {
			self::shell( __( 'Agent pocket', 'estat-os' ), self::login(), '', true );
			return;
		}

		if ( 'login' === $view ) {
			Pocket::redirect( '' );
		}

		if ( ! Pocket::can_use() ) {
			self::shell(
				__( 'Agent pocket', 'estat-os' ),
				'<div class="estat-pocket-notice">' .
				esc_html__( 'You are signed in, but this account is not part of an office yet. Ask your office owner for a role, then open this link again.', 'estat-os' ) .
				'</div>',
				'',
				true
			);
			return;
		}

		$body = '';
		switch ( $view ) {
			case 'listings':
				$body = self::listings();
				break;
			case 'new':
				// /agent/new/{id} is the edit half of the same form.
				$body = self::form( $id );
				break;
			case 'listing':
				$body = self::listing( $id );
				break;
			case 'change':
				$body = self::change( $id );
				break;
			case 'inbox':
				$body = self::inbox();
				break;
			case 'enquiry':
				$body = self::enquiry( $id );
				break;
			case 'approvals':
				$body = Pocket::is_office() ? self::approvals() : Pocket::fail_to_today( 'nope' );
				break;
			default:
				$body = self::today();
				break;
		}

		self::shell( self::title_for( $view ), $body, $view );
	}

	/**
	 * The heading each view carries.
	 *
	 * @param string $view View slug.
	 * @return string
	 */
	private static function title_for( string $view ): string {
		$titles = array(
			''          => __( 'Today', 'estat-os' ),
			'listings'  => __( 'My listings', 'estat-os' ),
			'new'       => __( 'New listing', 'estat-os' ),
			'listing'   => __( 'Listing', 'estat-os' ),
			'change'    => __( 'Ask for a change', 'estat-os' ),
			'inbox'     => __( 'Enquiries & visits', 'estat-os' ),
			'enquiry'   => __( 'Enquiry', 'estat-os' ),
			'approvals' => __( 'Approvals', 'estat-os' ),
		);
		return $titles[ $view ] ?? __( 'Today', 'estat-os' );
	}

	/* ---------------------------------------------------------------------
	 * Shell, login
	 * ------------------------------------------------------------------ */

	/**
	 * The page furniture: head, flash, tabs, sign-out.
	 *
	 * @param string $title  Page title.
	 * @param string $body   Already-escaped HTML.
	 * @param string $active Tab slug.
	 * @param bool   $bare   Hide the tab bar (login and refusal).
	 * @return void
	 */
	private static function shell( string $title, string $body, string $active = '', bool $bare = false ): void {
		$flash = Pocket::flash();
		$out   = '<!DOCTYPE html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="utf-8">';
		$out  .= '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';
		$out  .= '<meta name="theme-color" content="#f4f6f9" media="(prefers-color-scheme: light)">';
		$out  .= '<meta name="theme-color" content="#0f151d" media="(prefers-color-scheme: dark)">';
		$out  .= '<meta name="robots" content="noindex, follow">';
		$out  .= '<title>' . esc_html( $title ) . ' · ' . esc_html( get_bloginfo( 'name' ) ) . '</title>';
		foreach ( array( 'tokens.css', 'pocket.css' ) as $sheet ) {
			$css_ver = file_exists( ESTAT_DIR . 'assets/css/' . $sheet )
				? (string) filemtime( ESTAT_DIR . 'assets/css/' . $sheet )
				: ESTAT_VERSION;
			$out .= '<link rel="stylesheet" href="' . esc_url( ESTAT_URL . 'assets/css/' . $sheet . '?ver=' . $css_ver ) . '">';
		}
		$tokens_css = apply_filters( 'estat_pocket_inline_tokens', '' );
		if ( '' !== $tokens_css ) {
			$out .= '<style id="estat-design-tokens-overrides">' . $tokens_css . '</style>';
		}
		$out .= '</head><body class="estat-pocket">';
		// Responsive app shell: sidebar for PC, bottom tabs for mobile
		$out .= '<div class="estat-pocket-app">';

		if ( ! $bare ) {
			// Desktop sidebar
			$out .= '<aside class="estat-pocket-sidebar" aria-label="' . esc_attr__( 'Navigation', 'estat-os' ) . '">';
			$out .= '<a class="estat-pocket-sidebar-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
			$out .= '<nav class="estat-pocket-sidebar-nav" aria-label="' . esc_attr__( 'Sections', 'estat-os' ) . '">';
			$out .= self::sidebar_tabs( $active );
			$out .= '</nav>';
			$out .= '<div class="estat-pocket-sidebar-foot">';
			$out .= '<div class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="desktop">' . esc_html__( 'PC • Desktop', 'estat-os' ) . '</div>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . esc_html__( 'Sign out', 'estat-os' ) . '</a>';
			$out .= '<div class="estat-pocket-hint" style="margin:0">/agent • ' . esc_html( wp_get_current_user()->display_name ) . '</div>';
			$out .= '</div>';
			$out .= '</aside>';
		}

		$out .= '<main class="estat-pocket-main">';
		$out .= '<div class="estat-pocket-screen">';

		if ( ! $bare ) {
			$out .= '<header class="estat-pocket-head">';
			$out .= '<a class="estat-pocket-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
			$out .= '<div style="display:flex;gap:8px;align-items:center">';
			$out .= '<span class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="desktop">' . esc_html__( 'PC', 'estat-os' ) . '</span>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . esc_html__( 'Sign out', 'estat-os' ) . '</a>';
			$out .= '</div>';
			$out .= '</header>';
		}

		if ( '' !== $flash ) {
			$out .= '<div class="estat-pocket-flash">' . esc_html( $flash ) . '</div>';
		}

		$out .= $body;
		$out .= '</div>'; // .estat-pocket-screen
		$out .= '</main>'; // .estat-pocket-main
		$out .= '</div>'; // .estat-pocket-app

		if ( ! $bare ) {
			$out .= self::tabs( $active );
		}

		// Tiny JS to keep device mark in sync + improve UX stability
		$out .= '<script>document.addEventListener("DOMContentLoaded",function(){'
			. 'var w=window.innerWidth;var d=w<768?"mobile":w<1024?"tablet":"desktop";'
			. 'document.querySelectorAll(".estat-pocket-device").forEach(function(el){el.setAttribute("data-device",el.getAttribute("data-device"));});'
			. 'function onResize(){var nw=window.innerWidth;var nd=nw<768?"mobile":nw<1024?"tablet":"desktop";'
			. 'document.body.setAttribute("data-device",nd);}'
			. 'onResize();window.addEventListener("resize",onResize);'
			. '});</script>';

		$out .= '</body></html>';
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every piece escaped as it was built.
	}

	/**
	 * Bottom bar for mobile + reused for sidebar.
	 */
	private static function tabs( string $active ): string {
		$all = array(
			''          => array( 'home', __( 'Today', 'estat-os' ) ),
			'listings'  => array( 'list-checks', __( 'Listings', 'estat-os' ) ),
			'new'       => array( 'form', __( 'Add', 'estat-os' ) ),
			'inbox'     => array( 'inbox', __( 'Inbox', 'estat-os' ) ),
			'approvals' => array( 'check-circle', __( 'Approve', 'estat-os' ) ),
		);
		$out = '<nav class="estat-pocket-tabs" aria-label="' . esc_attr__( 'Sections', 'estat-os' ) . '">';
		foreach ( $all as $slug => $tab ) {
			if ( 'approvals' === $slug && ! Pocket::is_office() ) { continue; }
			$on = in_array( $slug, array( $active, 'listing' === $active ? 'listings' : '', 'change' === $active ? 'listings' : '', 'enquiry' === $active ? 'inbox' : '' ), true );
			$out .= sprintf(
				'<a class="estat-pocket-tab%1$s" href="%2$s" aria-current="%3$s">%4$s<span>%5$s</span></a>',
				$on ? ' is-on' : '',
				esc_url( Pocket::url( $slug ) ),
				$on ? 'page' : 'false',
				Pocket::icon( $tab[0], 20 ),
				esc_html( $tab[1] )
			);
		}
		return $out . '</nav>';
	}

	private static function sidebar_tabs( string $active ): string {
		$all = array(
			''          => array( 'home', __( 'Today', 'estat-os' ) ),
			'listings'  => array( 'list-checks', __( 'My Listings', 'estat-os' ) ),
			'new'       => array( 'form', __( 'Add New', 'estat-os' ) ),
			'inbox'     => array( 'inbox', __( 'Inbox — Enquiries', 'estat-os' ) ),
			'approvals' => array( 'check-circle', __( 'Approvals', 'estat-os' ) ),
		);
		$out = '';
		foreach ( $all as $slug => $tab ) {
			if ( 'approvals' === $slug && ! Pocket::is_office() ) { continue; }
			$on = in_array( $slug, array( $active, 'listing' === $active ? 'listings' : '', 'change' === $active ? 'listings' : '', 'enquiry' === $active ? 'inbox' : '' ), true );
			$out .= sprintf(
				'<a class="estat-pocket-tab%1$s" href="%2$s" aria-current="%3$s">%4$s<span>%5$s</span></a>',
				$on ? ' is-on' : '',
				esc_url( Pocket::url( $slug ) ),
				$on ? 'page' : 'false',
				Pocket::icon( $tab[0], 20 ),
				esc_html( $tab[1] )
			);
		}
		return $out;
	}

	/**
	 * Sign-in, aimed at the WordPress account the person already has.
	 *
	 * @return string
	 */
	private static function login(): string {
		$action = esc_url( wp_login_url( Pocket::url() ) );
		return sprintf(
			'<div class="estat-pocket-login"><div class="estat-pocket-login-mark">%1$s</div>' .
			'<h1 class="estat-pocket-login-title">%2$s</h1>' .
			'<p class="estat-pocket-lead">%3$s</p>' .
			'<form class="estat-pocket-card estat-pocket-login-card" method="post" action="%4$s">' .
			'<input type="hidden" name="redirect_to" value="%5$s">' .
			'<label class="estat-pocket-label" for="estat-p-log">%6$s</label>' .
			'<input class="estat-pocket-input" id="estat-p-log" name="log" type="text" autocomplete="username" required>' .
			'<label class="estat-pocket-label" for="estat-p-pwd">%7$s</label>' .
			'<input class="estat-pocket-input" id="estat-p-pwd" name="pwd" type="password" autocomplete="current-password" required>' .
			'<label class="estat-pocket-check"><input type="checkbox" name="rememberme" value="forever"> %8$s</label>' .
			'%9$s' .
			'<button class="estat-pocket-btn is-go" type="submit">%10$s</button>' .
			'</form>' .
			'<p class="estat-pocket-hint">%11$s</p></div>',
			Pocket::icon( 'key', 24 ),
			esc_html__( 'Agent pocket', 'estat-os' ),
			esc_html__( 'Add and update listings from anywhere. Everything you send is checked by the office before it reaches the website.', 'estat-os' ),
			$action,
			esc_attr( Pocket::url() ),
			esc_html__( 'Username, email or phone (Upendra/Hemchand can use phone)', 'estat-os' ),
			esc_html__( 'Password', 'estat-os' ),
			esc_html__( 'Remember me', 'estat-os' ),
			wp_nonce_field( 'logged_in', '_wpnonce', true, false ),
			esc_html__( 'Sign in', 'estat-os' ),
			esc_html__( 'This is your office WordPress account — the same one that opens the dashboard. Forgotten passwords are reset there, by your office owner.', 'estat-os' )
		);
	}

	/* ---------------------------------------------------------------------
	 * Today
	 * ------------------------------------------------------------------ */

	/**
	 * Four rows that answer "what needs me right now", plus visits ahead.
	 *
	 * @return string
	 */
	private static function today(): string {
		$me    = get_current_user_id();
		$agent = Pocket::agent_id();
		$off   = Pocket::is_office();

		$leads_scope = self::leads_scope();
		$new_count   = 0;
		$due         = array();

		$fresh = Leads::query( array_merge( $leads_scope, array( 'status' => 'new', 'per_page' => 100 ) ) );
		foreach ( $fresh['items'] as $lead ) {
			if ( $off || (int) $lead['agent_id'] === $agent || ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent ) ) {
				++$new_count;
			}
		}

		$follow = Leads::query( array_merge( $leads_scope, array( 'due_followup' => true, 'per_page' => 3 ) ) );
		$due    = $follow['items'];

		$live = count(
			array_filter(
				Pocket::my_records(),
				static function ( $p ) {
					return 'publish' === $p->post_status && PostTypes::LISTING === $p->post_type;
				}
			)
		);

		$waiting = Requests::query( array_merge( array( 'status' => 'pending', 'per_page' => 100 ), $off ? array() : array( 'requested_by' => $me ) ) );
		$mine_waiting = 0;
		foreach ( $waiting['items'] as $req ) {
			if ( $off || (int) $req['requested_by'] === $me ) {
				++$mine_waiting;
			}
		}

		$tomorrow   = current_time( 'timestamp', true ) + DAY_IN_SECONDS;
		$visits_out = Visits::query(
			array_merge(
				$off ? array() : array( 'agent_id' => $agent ),
				array(
					'from'     => gmdate( 'Y-m-d H:i:s', $off ? $tomorrow - 2 * DAY_IN_SECONDS : time() ),
					'per_page' => 5,
				)
			)
		);

		$out = '<p class="estat-pocket-greet">' .
			esc_html(
				sprintf(
					/* translators: %s first name */
					__( 'Good day, %s.', 'estat-os' ),
					wp_get_current_user()->display_name
				)
			) . ' ' . esc_html( Format::date( current_time( 'mysql' ) ) ) . '</p>';

		$out .= '<a class="estat-pocket-row" href="' . esc_url( Pocket::url( 'inbox' ) ) . '">' .
			'<span class="estat-pocket-well is-warn">' . Pocket::icon( 'inbox', 18 ) . '</span>' .
			'<span class="estat-pocket-rowmain"><b>' .
			esc_html( sprintf( _n( '%d new enquiry', '%d new enquiries', $new_count, 'estat-os' ), $new_count ) ) .
			'</b></span>' . Pocket::icon( 'chevron-right', 16 ) . '</a>';

		$out .= '<a class="estat-pocket-row" href="' . esc_url( Pocket::url( 'inbox' ) ) . '">' .
			'<span class="estat-pocket-well">' . Pocket::icon( 'calendar', 18 ) . '</span>' .
			'<span class="estat-pocket-rowmain"><b>' .
			esc_html( sprintf( _n( '%d visit ahead', '%d visits ahead', (int) $visits_out['total'], 'estat-os' ), (int) $visits_out['total'] ) ) .
			'</b><i>' . esc_html( self::next_visit_line( $visits_out ) ) . '</i></span>' .
			Pocket::icon( 'chevron-right', 16 ) . '</a>';

		$out .= '<a class="estat-pocket-row" href="' . esc_url( Pocket::url( 'listings' ) ) . '">' .
			'<span class="estat-pocket-well is-accent">' . Pocket::icon( 'list-checks', 18 ) . '</span>' .
			'<span class="estat-pocket-rowmain"><b>' .
			esc_html( sprintf( _n( '%d change waiting for the office', '%d changes waiting for the office', $mine_waiting, 'estat-os' ), $mine_waiting ) ) .
			'</b></span>' . Pocket::icon( 'chevron-right', 16 ) . '</a>';

		$out .= '<a class="estat-pocket-row" href="' . esc_url( Pocket::url( 'listings' ) ) . '">' .
			'<span class="estat-pocket-well is-good">' . Pocket::icon( 'eye', 18 ) . '</span>' .
			'<span class="estat-pocket-rowmain"><b>' .
			esc_html( sprintf( _n( '%d of your listings are live', '%d of your listings are live', $live, 'estat-os' ), $live ) ) .
			'</b></span>' . Pocket::icon( 'chevron-right', 16 ) . '</a>';

		if ( $due ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Need a callback', 'estat-os' ) . '</h2>';
			foreach ( $due as $lead ) {
				$out .= sprintf(
					'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-well">%2$s</span>' .
					'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s</i></span>%5$s</a>',
					esc_url( Pocket::url( 'enquiry', (int) $lead['id'] ) ),
					Pocket::icon( 'phone', 18 ),
					esc_html( (string) $lead['name'] ),
					esc_html( (string) $lead['phone'] ),
					Pocket::icon( 'chevron-right', 16 )
				);
			}
		}

		return $out;
	}

	/**
	 * Leads scope: the office sees all, an agent sees only leads carried by
	 * their agent record. An agent whose record does not exist yet sees
	 * nothing — unassigned enquiries are the office's pile, not a free-for-
	 * all for whoever signs in first.
	 *
	 * @return array<string,int>
	 */
	public static function leads_scope(): array {
		if ( Pocket::is_office() ) {
			return array();
		}
		$agent = Pocket::agent_id();
		return array( 'agent_id' => $agent > 0 ? $agent : -1 );
	}

	/**
	 * One line about the nearest visit, or a calm "nothing booked".
	 *
	 * @param array{items:array<int,array<string,mixed>>,total:int} $visits Query result.
	 * @return string
	 */
	private static function next_visit_line( array $visits ): string {
		if ( ! $visits['items'] ) {
			return __( 'Nothing booked ahead.', 'estat-os' );
		}
		$next = $visits['items'][0];
		$at   = Format::date( (string) $next['scheduled_at'] ) . ' · ' . Format::time( (string) $next['scheduled_at'] );
		$where = '';
		if ( ! empty( $next['listing_id'] ) ) {
			$title = get_the_title( (int) $next['listing_id'] );
			if ( $title ) {
				$where = ' · ' . $title;
			}
		}
		return $at . $where;
	}

	/* ---------------------------------------------------------------------
	 * Listings
	 * ------------------------------------------------------------------ */

	/**
	 * The list, with search. Rows carry the status pill and nothing else —
	 * the actions live on the detail page, where there is room to explain.
	 *
	 * @return string
	 */
	private static function listings(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['q']) ? '' : $_GET['q'] ) ) ) : '';
		$rows = Pocket::my_records( $q );

		$out  = '<form method="get" action="' . esc_url( Pocket::url( 'listings' ) ) . '" class="estat-pocket-search">' .
			'<input class="estat-pocket-input" type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="' .
			esc_attr__( 'Search title or locality', 'estat-os' ) . '"><button class="estat-pocket-btn" type="submit">' .
			Pocket::icon( 'search', 16 ) . '</button></form>';

		if ( ! $rows ) {
			$out .= '<div class="estat-pocket-empty"><span class="estat-pocket-empty-mark">' . Pocket::icon( 'form', 22 ) . '</span>' .
				'<p>' . esc_html__( 'No listings here yet. The Add tab starts the first one.', 'estat-os' ) . '</p>' .
				'<a class="estat-pocket-btn is-go" href="' . esc_url( Pocket::url( 'new' ) ) . '">' . esc_html__( 'Add a listing', 'estat-os' ) . '</a></div>';
			return $out;
		}

		foreach ( $rows as $post ) {
			if ( ! Pocket::can_see( $post ) ) {
				continue; // however the query was shaped, the door is one rule.
			}
			$out .= self::record_row( (int) $post->ID );
		}
		return $out;
	}

	/**
	 * One listing row, reused by the office approvals list.
	 *
	 * @param int $record_id Post ID.
	 * @return string
	 */
	public static function record_row( int $record_id ): string {
		$post = get_post( $record_id );
		if ( ! $post ) {
			return '';
		}
		list( $label, $tone ) = Pocket::status_of( $post );

		$price    = trim( (string) get_post_meta( $record_id, '_estat_price', true ) );
		$rent     = trim( (string) get_post_meta( $record_id, '_estat_rent', true ) );
		$offer    = (string) get_post_meta( $record_id, '_estat_offer', true );
		$price_in = '' !== $rent && ( '' === $price || 'rent' === $offer || 'lease' === $offer ) ? $rent : $price;
		$money    = '' !== $price_in ? Format::money( (float) $price_in ) : '';

		$thumb = get_the_post_thumbnail( $record_id, 'thumbnail', array( 'class' => 'estat-pocket-thumb' ) );
		$thumb = $thumb ? $thumb : '<span class="estat-pocket-thumb is-empty">' . Pocket::icon( 'image', 18 ) . '</span>';

		return sprintf(
			'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-thumbwrap">%2$s</span>' .
			'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s%5$s</i></span>' .
			( '' !== $label ? '<span class="estat-pocket-pill %6$s">%7$s</span>' : '' ) . '</a>',
			esc_url( Pocket::url( 'listing', $record_id ) ),
			$thumb,
			esc_html( get_the_title( $record_id ) ),
			esc_html( $money ),
			'' !== $money ? '' : esc_html__( 'Price not set yet', 'estat-os' ),
			'' !== $tone ? 'is-' . $tone : '',
			esc_html( $label )
		);
	}

	/* ---------------------------------------------------------------------
	 * Listing detail and forms
	 * ------------------------------------------------------------------ */

	/**
	 * One record, everything the phone needs to know about it, and exactly
	 * the actions this person is allowed for it. No hidden buttons: if the
	 * server would refuse it, the pocket does not offer it.
	 *
	 * @param int $record_id Post ID.
	 * @return string|false
	 */
	private static function listing( int $record_id ) {
		$post = get_post( $record_id );
		if ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) || ! Pocket::can_see( $post ) ) {
			return Pocket::fail_to_today( 'gone' );
		}

		list( $label, $tone ) = Pocket::status_of( $post );
		$mine = Pocket::owns( $record_id ) || Pocket::is_office();
		$meta = Meta::listing_schema();

		$out = '<h1 class="estat-pocket-title">' . esc_html( get_the_title( $record_id ) ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' .
			( '' !== $label ? '<span class="estat-pocket-pill ' . ( '' !== $tone ? 'is-' . $tone : '' ) . '">' . esc_html( $label ) . '</span> ' : '' ) .
			esc_html__( 'Last touched', 'estat-os' ) . ' ' . esc_html( Format::date( (string) $post->post_modified ) ) .
			'</p>';

		if ( 'publish' === $post->post_status ) {
			$url = Pocket::public_url( $record_id );
			if ( '' !== $url ) {
				$out .= '<a class="estat-pocket-row" href="' . esc_url( $url ) . '"><span class="estat-pocket-well">' .
					Pocket::icon( 'eye', 18 ) . '</span><span class="estat-pocket-rowmain"><b>' .
					esc_html__( 'See it on the website', 'estat-os' ) . '</b></span>' . Pocket::icon( 'external', 16 ) . '</a>';
			}
		}

		// The facts, in the order they are typed, not in the order of the
		// schema — this is the phone, not the settings room.
		$facts = array(
			'_estat_offer'    => __( 'Offer', 'estat-os' ),
			'_estat_property_type' => __( 'Type', 'estat-os' ),
			'_estat_price'    => __( 'Price', 'estat-os' ),
			'_estat_rent'     => __( 'Rent', 'estat-os' ),
			'_estat_bedrooms' => __( 'Bedrooms', 'estat-os' ),
			'_estat_bathrooms'=> __( 'Bathrooms', 'estat-os' ),
			'_estat_address'  => __( 'Address', 'estat-os' ),
			'_estat_availability' => __( 'Availability', 'estat-os' ),
		);
		$rows  = '';
		foreach ( $facts as $key => $word ) {
			$raw = (string) get_post_meta( $record_id, $key, true );
			if ( '' === $raw ) {
				continue;
			}
			$nice = $raw;
			if ( in_array( $key, array( '_estat_price', '_estat_rent' ), true ) ) {
				$nice = Format::money( (float) $raw );
			} elseif ( isset( $meta[ $key ] ) ) {
				$nice = self::nicely( $key, $raw );
			}
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html( $word ) . '</i><b>' . esc_html( $nice ) . '</b></div>';
		}
		if ( '' !== trim( (string) $post->post_content ) ) {
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html__( 'Description', 'estat-os' ) . '</i><b>' .
				esc_html( self::excerpt( (string) $post->post_content ) ) . '</b></div>';
		}
		if ( '' !== $rows ) {
			$out .= '<div class="estat-pocket-card">' . $rows . '</div>';
		}

		// Photos already attached, then the actions.
		$pics = (array) get_post_meta( $record_id, '_estat_gallery', true );
		if ( $pics ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( sprintf( _n( '%d photo', '%d photos', count( $pics ), 'estat-os' ), count( $pics ) ) ) . '</h2>';
			$out .= '<div class="estat-pocket-photos">';
			foreach ( array_slice( $pics, 0, 8 ) as $pic ) {
				$src = wp_get_attachment_image_url( (int) $pic, 'thumbnail' );
				if ( $src ) {
					$out .= '<img src="' . esc_url( $src ) . '" alt="" class="estat-pocket-photo">';
				}
			}
			$out .= '</div>';
		}

		$pending_here = array();
		foreach ( Requests::query( array( 'record_id' => $record_id, 'status' => 'pending', 'per_page' => 10 ) )['items'] as $req ) {
			$pending_here[] = self::request_line( $req );
		}
		if ( $pending_here ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'With the office', 'estat-os' ) . '</h2><div class="estat-pocket-card">' .
				implode( '', $pending_here ) . '</div>';
		}

		// Actions, allowed-by-server only.
		$actions = '';
		if ( 'draft' === $post->post_status && $mine ) {
			$actions .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'new', $record_id ) ) . '">' . esc_html__( 'Edit draft', 'estat-os' ) . '</a>';
			$actions .= self::button( 'send', $record_id, __( 'Send for approval', 'estat-os' ), true );
		}
		if ( 'publish' === $post->post_status && $mine ) {
			$actions .= self::button( 'pause', $record_id, __( 'Pause — hide from site', 'estat-os' ) );
		}
		if ( 'private' === $post->post_status && $mine ) {
			$actions .= self::button( 'resume', $record_id, __( 'Make live again', 'estat-os' ), true );
		}
		if ( in_array( $post->post_status, array( 'publish', 'private' ), true ) ) {
			$actions .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'change', $record_id ) ) . '">' .
				esc_html__( 'Ask the office to change', 'estat-os' ) . '</a>';
		}
		if ( in_array( $post->post_status, array( 'draft', 'pending' ), true ) && $mine ) {
			$actions .= self::button( 'trash_draft', $record_id, __( 'Remove this draft', 'estat-os' ) );
		}
		if ( '' !== $actions ) {
			$out .= '<div class="estat-pocket-actions">' . $actions . '</div>';
		}

		if ( 'publish' === $post->post_status ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'This listing is live, so your edits go to the office first. Nothing on the website moves until they say yes.', 'estat-os' ) . '</p>';
		}

		return $out;
	}

	/**
	 * A calm trim: the detail page shows four lines of story, not all of it.
	 *
	 * @param string $text Raw content.
	 * @return string
	 */
	private static function excerpt( string $text ): string {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
		if ( mb_strlen( $text ) <= 160 ) {
			return $text;
		}
		return mb_substr( $text, 0, 159 ) . '…';
	}

	/**
	 * Map a stored meta value back to the words the selects show.
	 *
	 * @param string $key   Meta key.
	 * @param string $value Raw value.
	 * @return string
	 */
	private static function nicely( string $key, string $value ): string {
		$vocabs = array(
			'_estat_offer'        => 'offers',
			'_estat_property_type' => 'property_types',
			'_estat_availability' => 'availability',
		);
		if ( isset( $vocabs[ $key ] ) ) {
			$words = call_user_func( array( Vocabulary::class, $vocabs[ $key ] ) );
			if ( isset( $words[ $value ] ) ) {
				return (string) $words[ $value ];
			}
		}
		return $value;
	}

	/**
	 * A post form for one action, with the nonce.
	 *
	 * @param string $action Action slug.
	 * @param int    $id     Record ID.
	 * @param string $label  Button text.
	 * @param bool   $go     Primary style.
	 * @return string
	 */
	private static function button( string $action, int $id, string $label, bool $go = false ): string {
		return sprintf(
			'<form method="post" action="%1$s" class="estat-pocket-inlineform"><input type="hidden" name="_estat_pocket" value="%2$s">' .
			'<input type="hidden" name="estat_pocket_action" value="%3$s"><input type="hidden" name="record_id" value="%4$d">' .
			'<button class="estat-pocket-btn%5$s" type="submit">%6$s</button></form>',
			esc_url( Pocket::url( 'listing', $id ) ),
			esc_attr( wp_create_nonce( 'estat_pocket' ) ),
			sanitize_key( $action ),
			(int) $id,
			$go ? ' is-go' : '',
			esc_html( $label )
		);
	}

	/**
	 * A pending request, one line, old value struck where we have it.
	 *
	 * @param array<string,mixed> $req Row from the requests table.
	 * @return string
	 */
	private static function request_line( array $req ): string {
		$changes = json_decode( (string) $req['changes'], true );
		$fields  = is_array( $changes ) ? array_diff_key( $changes, array( 'note' => true ) ) : array();
		$defs    = Requests::editable_fields();

		$bits = array();
		foreach ( $fields as $key => $value ) {
			$word  = isset( $defs[ $key ] ) ? (string) $defs[ $key ]['label'] : ucfirst( (string) $key );
			$bits[] = $word . ': ' . $value;
		}

		$name = $bits ? implode( ' · ', $bits ) : __( 'A note for the office', 'estat-os' );

		return '<div class="estat-pocket-fact"><i>' .
			esc_html( Format::date( (string) $req['created_at'] ) ) . '</i><b>' . esc_html( $name ) .
			' <em>' . esc_html__( 'waiting', 'estat-os' ) . '</em></b></div>';
	}

	/**
	 * Add-new, and edit of an agent's own draft. One form, two jobs.
	 *
	 * @param int $record_id 0 for a new record.
	 * @return string|false
	 */
	private static function form( int $record_id ) {
		$post = $record_id > 0 ? get_post( $record_id ) : null;
		if ( $record_id > 0 && ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) ) {
			return Pocket::fail_to_today( 'gone' );
		}
		if ( $post && ! ( ( 'draft' === $post->post_status || 'pending' === $post->post_status ) && ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) ) {
			return Pocket::fail_to_today( 'nope' );
		}

		$vals = array(
			'title'       => $post ? (string) $post->post_title : '',
			'summary'     => $post ? (string) $post->post_excerpt : '',
			'body'        => $post ? (string) $post->post_content : '',
			'offer'       => $post ? (string) get_post_meta( $record_id, '_estat_offer', true ) : 'sale',
			'price'       => $post ? (string) get_post_meta( $record_id, '_estat_price', true ) : '',
			'rent'        => $post ? (string) get_post_meta( $record_id, '_estat_rent', true ) : '',
			'address'     => $post ? (string) get_post_meta( $record_id, '_estat_address', true ) : '',
			'bedrooms'    => $post ? (string) get_post_meta( $record_id, '_estat_bedrooms', true ) : '',
			'bathrooms'   => $post ? (string) get_post_meta( $record_id, '_estat_bathrooms', true ) : '',
			'property_type' => $post ? (string) get_post_meta( $record_id, '_estat_property_type', true ) : '',
			'locality'    => $post ? (string) get_post_meta( $record_id, '_estat_locality', true ) : '',
		);

		$action = esc_url( Pocket::url( 'new', $record_id ) );
		$out    = '<p class="estat-pocket-lead">' . esc_html__( 'Fill what you know; the rest can come from the office later. A new listing starts as a draft and only the office can put it on the website.', 'estat-os' ) . '</p>';
		$out   .= '<p class="estat-pocket-hint">' . esc_html__( 'F3: Upendra/Hemchand phone login + 4-step wizard — phone se bhi listing banao, apne leads dekho.', 'estat-os' ) . '</p>';

		$out   .= '<form class="estat-pocket-card" method="post" action="' . $action . '" enctype="multipart/form-data" id="estat-wizard-form">';
		$out   .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out   .= '<input type="hidden" name="estat_pocket_action" value="save_draft">';
		$out   .= '<input type="hidden" name="record_id" value="' . (int) $record_id . '">';

		// Responsive wizard header — PC/Tablet/Mobile distinct
		$out .= '<div id="estat-wizard-progress" class="estat-pocket-card" style="display:flex;gap:10px;margin:0 0 16px;align-items:center;flex-wrap:wrap">';
		$out .= '<div style="display:flex;gap:8px;align-items:center">';
		for ( $i = 1; $i <= 4; $i++ ) {
			$out .= '<button type="button" class="estat-w-dot" data-step="' . $i . '" aria-label="Step ' . $i . '">' . $i . '</button>';
		}
		$out .= '</div>';
		$out .= '<span id="estat-w-label" class="estat-pocket-hint" style="margin:0">Step 1 of 4 • Mobile • 4-step wizard</span>';
		$out .= '<span id="estat-w-error" class="estat-pocket-pill is-warn" style="display:none;margin-left:auto"></span>';
		$out .= '</div>';

		$out .= '<div class="estat-w-step" data-wstep="1">';
		$out .= '<h3 style="margin:0 0 12px;font-size:15px;font-weight:700">' . esc_html__( 'Step 1 — What & Where (Mobile: big tap targets, PC: 2 columns)', 'estat-os' ) . '</h3>';
		$out .= self::field( __( 'What is it? *', 'estat-os' ), 'title', 'text', $vals['title'], __( 'Flat 4B, Sunrise Apartments', 'estat-os' ), true );
		$out .= '<div class="estat-pocket-pair">';
		$out .= self::select_field( __( 'Offer *', 'estat-os' ), 'offer', Vocabulary::offers(), $vals['offer'] );
		$out .= self::select_field( __( 'Type', 'estat-os' ), 'property_type', Vocabulary::property_types(), $vals['property_type'], __( 'Choose a type', 'estat-os' ) );
		$out .= '</div>';
		$out .= self::field( __( 'Locality / address *', 'estat-os' ), 'address', 'text', $vals['address'], __( 'Sector 48, Sohna Road, Gurugram', 'estat-os' ), true );
		$out .= '</div>';

		$out .= '<div class="estat-w-step" data-wstep="2" style="display:none">';
		$out .= '<h3 style="margin:0 0 12px;font-size:15px;font-weight:700">' . esc_html__( 'Step 2 — Price & Size', 'estat-os' ) . '</h3>';
		$out .= '<div class="estat-pocket-pair">' .
			self::field( __( 'Price (₹)', 'estat-os' ), 'price', 'text', $vals['price'], '8500000', false ) .
			self::field( __( 'Monthly rent (₹)', 'estat-os' ), 'rent', 'text', $vals['rent'], '55000', false ) .
			'</div>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'PC: side-by-side, Mobile: stacked. Numbers only. One of price/rent is enough.', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-pair">' .
			self::field( __( 'Bedrooms', 'estat-os' ), 'bedrooms', 'number', $vals['bedrooms'], '3', false ) .
			self::field( __( 'Bathrooms', 'estat-os' ), 'bathrooms', 'number', $vals['bathrooms'], '2', false ) .
			'</div>';
		$out .= '</div>';

		$out .= '<div class="estat-w-step" data-wstep="3" style="display:none">';
		$out .= '<h3 style="margin:0 0 12px;font-size:15px;font-weight:700">' . esc_html__( 'Step 3 — Photos & Details', 'estat-os' ) . '</h3>';
		$out .= self::area_field( __( 'One line about it', 'estat-os' ), 'body', $vals['body'], __( 'Sea-facing, freshly painted, lift + covered parking. Owner meeting tomorrow.', 'estat-os' ) );
		$out .= '<label class="estat-pocket-label">' . esc_html__( 'Photographs — tap to add from camera', 'estat-os' ) . '</label>' .
			'<input class="estat-pocket-input" type="file" name="estat_pocket_photos[]" accept="image/*" multiple capture="environment">' .
			'<p class="estat-pocket-hint">' . esc_html__( 'Mobile: camera opens directly. PC: drag & drop. First photo = cover. Max 8, auto-compressed.', 'estat-os' ) . '</p>';
		$out .= '<div id="estat-photo-preview" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"></div>';
		$out .= '</div>';

		$out .= '<div class="estat-w-step" data-wstep="4" style="display:none">';
		$out .= '<h3 style="margin:0 0 12px;font-size:15px;font-weight:700">' . esc_html__( 'Step 4 — Review & Send', 'estat-os' ) . '</h3>';
		$out .= '<div id="estat-w-review" class="estat-pocket-card" style="font-size:13px;line-height:1.6;background:var(--estat-sunken);border-style:dashed"></div>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Check once. Save draft = only you see. Send for approval = office verifies and adds "humne khud dekha" tick if inspected.', 'estat-os' ) . '</p>';
		$out .= '</div>';

		$out .= '<div class="estat-pocket-actions" style="position:sticky;bottom:84px;z-index:5;background:color-mix(in srgb, var(--estat-bg) 90%, transparent);backdrop-filter:blur(8px);padding:10px 0;margin-top:16px;border-top:1px solid var(--estat-line)">';
		$out .= '<button class="estat-pocket-btn" type="button" id="estat-w-back" style="display:none">← ' . esc_html__( 'Back', 'estat-os' ) . '</button>';
		$out .= '<button class="estat-pocket-btn is-go" type="button" id="estat-w-next">' . esc_html__( 'Next', 'estat-os' ) . ' →</button>';
		$out .= '<button class="estat-pocket-btn" type="submit" name="estat_pocket_next" value="draft" id="estat-w-save" style="display:none">' . esc_html__( 'Save draft', 'estat-os' ) . '</button>';
		$out .= '<button class="estat-pocket-btn is-go" type="submit" name="estat_pocket_next" value="send" id="estat-w-send" style="display:none">' . esc_html__( 'Send for approval', 'estat-os' ) . ' ✓</button>';
		$out .= '</div>';
		$out .= '</form>';

		$out .= '<script>
document.addEventListener("DOMContentLoaded", function(){
  const form = document.getElementById("estat-wizard-form");
  if(!form) return;
  let step = 1;
  const max = 4;
  const dots = form.querySelectorAll(".estat-w-dot");
  const label = document.getElementById("estat-w-label");
  const errEl = document.getElementById("estat-w-error");
  const back = document.getElementById("estat-w-back");
  const next = document.getElementById("estat-w-next");
  const save = document.getElementById("estat-w-save");
  const send = document.getElementById("estat-w-send");
  const review = document.getElementById("estat-w-review");
  const photoInput = form.querySelector("input[type=file]");
  const photoPrev = document.getElementById("estat-photo-preview");

  function isMobile(){ return window.innerWidth < 768; }
  function isTablet(){ return window.innerWidth >= 768 && window.innerWidth < 1024; }
  function device(){ return isMobile() ? "Mobile" : isTablet() ? "Tablet" : "PC"; }

  function validate(s){
    if(s===1){
      const t = form.querySelector("[name=title]");
      const a = form.querySelector("[name=address]");
      if(!t || !t.value.trim()){ return "Title needed"; }
      if(!a || !a.value.trim()){ return "Locality / address needed"; }
    }
    if(s===2){
      const price = form.querySelector("[name=price]");
      const rent = form.querySelector("[name=rent]");
      const pv = price ? price.value.trim() : "";
      const rv = rent ? rent.value.trim() : "";
      if(!pv && !rv){ return "Price or rent — one needed"; }
    }
    return "";
  }

  function show(s){
    const vError = validate(step);
    if(s>step && vError){
      if(errEl){ errEl.textContent = vError; errEl.style.display="inline-flex"; setTimeout(()=>{errEl.style.display="none"}, 3000); }
      // shake
      const cur = form.querySelector(".estat-w-step[data-wstep=\""+step+"\"]");
      if(cur){ cur.animate([{transform:"translateX(-4px)"},{transform:"translateX(4px)"},{transform:"translateX(0)"}], {duration:200}); }
      return;
    }
    step = s;
    form.querySelectorAll(".estat-w-step").forEach(d=>{
      d.style.display = parseInt(d.getAttribute("data-wstep"))===step ? "block" : "none";
    });
    dots.forEach(d=>{
      const ds = parseInt(d.getAttribute("data-step"));
      const isDone = ds < step;
      const isCur = ds === step;
      d.style.background = isCur ? "var(--estat-accent)" : (isDone ? "var(--estat-good)" : "var(--estat-sunken)");
      d.style.color = isCur || isDone ? "var(--estat-on-accent)" : "var(--estat-muted)";
      d.style.borderColor = isCur ? "var(--estat-accent)" : (isDone ? "var(--estat-good)" : "var(--estat-line)");
      d.disabled = false;
    });
    if(label){ label.textContent = "Step "+step+" of "+max+" • "+device()+" • "+(step===1?"What & Where":step===2?"Price & Size":step===3?"Photos":"Review"); }
    if(back) back.style.display = step>1 ? "inline-flex" : "none";
    if(next) next.style.display = step<max ? "inline-flex" : "none";
    if(save) save.style.display = step===max ? "inline-flex" : "none";
    if(send) send.style.display = step===max ? "inline-flex" : "none";
    if(step===max && review){
      const get = n=>{ const el=form.querySelector("[name="+n+"]"); return el ? el.value : ""; };
      review.innerHTML = "<div style=\"display:grid;gap:8px\">"
        + "<div><b>Title:</b> "+(get("title")||"-")+"</div>"
        + "<div style=\"display:flex;gap:12px;flex-wrap:wrap\"><span><b>Offer:</b> "+get("offer")+"</span><span><b>Type:</b> "+get("property_type")+"</span></div>"
        + "<div><b>Address:</b> "+(get("address")||"-")+"</div>"
        + "<div style=\"display:flex;gap:12px\"><span><b>Price:</b> ₹"+(get("price")||"-")+"</span><span><b>Rent:</b> ₹"+(get("rent")||"-")+"</span></div>"
        + "<div style=\"display:flex;gap:12px\"><span><b>Bed:</b> "+(get("bedrooms")||"-")+"</span><span><b>Bath:</b> "+(get("bathrooms")||"-")+"</span></div>"
        + "<div><b>Note:</b> "+(get("body")||"-").substring(0,180)+"</div>"
        + "</div>";
    }
    // Save draft to localStorage for stability (if browser crashes)
    try{
      const data={};
      form.querySelectorAll("input, select, textarea").forEach(el=>{ if(el.name) data[el.name]=el.value; });
      localStorage.setItem("estat_draft_"+(form.querySelector("[name=record_id]")?.value||"new"), JSON.stringify(data));
    }catch(e){}
    window.scrollTo({top:0, behavior:"smooth"});
  }

  // Photo preview
  if(photoInput && photoPrev){
    photoInput.addEventListener("change", function(){
      photoPrev.innerHTML="";
      const files = this.files;
      if(!files) return;
      for(let i=0;i<Math.min(files.length,8);i++){
        const url = URL.createObjectURL(files[i]);
        const img = document.createElement("img");
        img.src=url; img.style.width="64px"; img.style.height="64px"; img.style.objectFit="cover"; img.style.borderRadius="10px"; img.style.border="1px solid var(--estat-line)";
        photoPrev.appendChild(img);
      }
    });
  }

  dots.forEach(d=>{
    d.addEventListener("click", function(){
      const target = parseInt(this.getAttribute("data-step"));
      if(target < step || target === step+1){ show(target); }
    });
  });
  if(next) next.addEventListener("click", function(){ if(step<max){ show(step+1); } });
  if(back) back.addEventListener("click", function(){ if(step>1){ show(step-1); } });

  // Restore draft if exists
  try{
    const key="estat_draft_"+(form.querySelector("[name=record_id]")?.value||"new");
    const saved = localStorage.getItem(key);
    if(saved){
      const data=JSON.parse(saved);
      Object.keys(data).forEach(k=>{
        const el=form.querySelector("[name=\""+k+"\"]");
        if(el && !el.value) el.value=data[k];
      });
    }
  }catch(e){}

  show(1);
  window.addEventListener("resize", function(){ if(label) label.textContent = "Step "+step+" of "+max+" • "+device()+" • "+(step===1?"What & Where":step===2?"Price & Size":step===3?"Photos":"Review"); });
});
</script>';

		return $out;
	}

	/**
	 * One labelled input.

	/**
	 * One labelled input.
	 *
	 * @param string $label  Text.
	 * @param string $name   Field name.
	 * @param string $type   Input type.
	 * @param string $value  Current value.
	 * @param string $ph     Placeholder.
	 * @param bool   $req    Required.
	 * @return string
	 */
	private static function field( string $label, string $name, string $type, string $value, string $ph = '', bool $req = false ): string {
		return sprintf(
			'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label>' .
			'<input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="%3$s" value="%4$s" placeholder="%5$s"%6$s>',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( $type ),
			esc_attr( $value ),
			esc_attr( $ph ),
			$req ? ' required' : ''
		);
	}

	/**
	 * One labelled select.
	 *
	 * @param string $label     Text.
	 * @param string $name      Field name.
	 * @param array<string,string> $options Choices.
	 * @param string $current   Selected key.
	 * @param string $blank     Placeholder option label.
	 * @return string
	 */
	private static function select_field( string $label, string $name, array $options, string $current, string $blank = '' ): string {
		$out = '<label class="estat-pocket-label" for="estat-pf-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label>';
		$out .= '<select class="estat-pocket-input" id="estat-pf-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '">';
		if ( '' !== $blank ) {
			$out .= '<option value="">' . esc_html( $blank ) . '</option>';
		}
		foreach ( $options as $key => $word ) {
			$out .= '<option value="' . esc_attr( $key ) . '"' . ( (string) $key === $current ? ' selected' : '' ) . '>' . esc_html( $word ) . '</option>';
		}
		return $out . '</select>';
	}

	/**
	 * A multiline box.
	 *
	 * @param string $label Text.
	 * @param string $name  Field name.
	 * @param string $value Content.
	 * @param string $ph    Placeholder.
	 * @return string
	 */
	private static function area_field( string $label, string $name, string $value, string $ph = '' ): string {
		return sprintf(
			'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label>' .
			'<textarea class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" rows="3" placeholder="%3$s">%4$s</textarea>',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( $ph ),
			esc_textarea( $value )
		);
	}

	/* ---------------------------------------------------------------------
	 * The change sheet
	 * ------------------------------------------------------------------ */

	/**
	 * The four fields a person on the ground can confirm, plus the compulsory
	 * "how do you know". Same request shape the admin queue reviews.
	 *
	 * @param int $record_id Post ID.
	 * @return string|false
	 */
	private static function change( int $record_id ) {
		$post = get_post( $record_id );
		if ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) || ! Pocket::can_see( $post ) ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$cur = Requests::current_values( $record_id );

		$out  = '<h1 class="estat-pocket-title">' . esc_html( get_the_title( $record_id ) ) . '</h1>';
		$out .= '<div class="estat-pocket-banner">' . Pocket::icon( 'lock', 14 ) .
			'<div>' . esc_html__( 'This listing belongs to the office records. Your edit goes to them first, and the website only moves when they say yes.', 'estat-os' ) . '</div></div>';

		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'change', $record_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="request">';
		$out .= '<input type="hidden" name="record_id" value="' . (int) $record_id . '">';

		$cur_price = isset( $cur['price'] ) ? (string) $cur['price'] : '';
		$cur_rent  = isset( $cur['rent'] ) ? (string) $cur['rent'] : '';
		$out .= self::field(
			__( 'Price — today ', 'estat-os' ) . ( '' !== $cur_price ? Format::money( (float) $cur_price ) : __( 'not set', 'estat-os' ) ),
			'changes[price]',
			'text',
			'',
			'' !== $cur_price ? $cur_price : __( 'new number', 'estat-os' )
		);
		$out .= self::field(
			__( 'Monthly rent — today ', 'estat-os' ) . ( '' !== $cur_rent ? Format::money( (float) $cur_rent ) : __( 'not set', 'estat-os' ) ),
			'changes[rent]',
			'text',
			'',
			'' !== $cur_rent ? $cur_rent : __( 'new number', 'estat-os' )
		);
		$out .= self::select_field(
			__( 'Is it still available?', 'estat-os' ),
			'changes[availability]',
			Vocabulary::availability(),
			isset( $cur['availability'] ) ? (string) $cur['availability'] : '',
			__( 'Leave as it is', 'estat-os' )
		);
		$out .= self::area_field(
			__( 'New description', 'estat-os' ),
			'changes[description]',
			'',
			__( 'Only if the words on the site are wrong.', 'estat-os' )
		);
		$out .= self::area_field(
			__( 'How do you know? (one line)', 'estat-os' ),
			'message',
			'',
			__( 'Owner agreed on call today.', 'estat-os' )
		);
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'The one line is not optional — it is what the office decides with.', 'estat-os' ) . '</p>';

		$out .= '<div class="estat-pocket-actions">' .
			'<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'listing', $record_id ) ) . '">' . esc_html__( 'Cancel', 'estat-os' ) . '</a>' .
			'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Send to office', 'estat-os' ) . '</button></div>';
		$out .= '</form>';

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Inbox
	 * ------------------------------------------------------------------ */

	/**
	 * Enquiries and booked visits, newest first. The agent sees their own;
	 * the office sees all of it.
	 *
	 * @return string
	 */
	private static function inbox(): string {
		$agent = Pocket::agent_id();
		$off   = Pocket::is_office();
		$scope = self::leads_scope();

		$leads  = Leads::query( array_merge( $scope, array( 'per_page' => 30 ) ) );
		$visits = Visits::query( array_merge( $scope, array( 'per_page' => 12 ) ) );

		$out = '<h2 class="estat-pocket-h2">' . esc_html__( 'Enquiries', 'estat-os' ) . '</h2>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'F1+F3: Your own leads only. Office sees all. Tap to call, WhatsApp, update status, book visit.', 'estat-os' ) . '</p>';
		if ( ! $leads['items'] ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Nothing new. When a form arrives from the website, it lands here.', 'estat-os' ) . '</p>';
		}
		foreach ( $leads['items'] as $lead ) {
			$ini = mb_strtoupper( mb_substr( (string) $lead['name'], 0, 1 ) );
			$st  = Vocabulary::lead_statuses();
			$intent = ! empty( $lead['intent'] ) ? (string) $lead['intent'] : '';
			$locality = ! empty( $lead['locality'] ) ? (string) $lead['locality'] : ( ! empty( $lead['area_label'] ) ? (string) $lead['area_label'] : '' );
			$budget = '';
			if ( ! empty( $lead['budget_min'] ) || ! empty( $lead['budget_max'] ) ) {
				$budget = Format::money( (int) ( $lead['budget_min'] ?? 0 ) ) . ' - ' . Format::money( (int) ( $lead['budget_max'] ?? 0 ) );
			}
			$lost = ! empty( $lead['lost_reason'] ) ? (string) $lead['lost_reason'] : '';
			$spam = ! empty( $lead['is_spam'] ) ? ' 🚩spam' : '';
			$sub = esc_html( (string) $lead['phone'] . ' · ' . Format::date( (string) $lead['created_at'] ) );
			if ( $intent ) { $sub .= ' · ' . esc_html( $intent ); }
			if ( $locality ) { $sub .= ' · ' . esc_html( $locality ); }
			if ( $budget ) { $sub .= ' · ' . $budget; }
			if ( $lost ) { $sub .= ' · lost: ' . esc_html( $lost ); }
			$sub .= $spam;
			$out .= sprintf(
				'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-well is-initial">%2$s</span>' .
				'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s</i></span>' .
				'<span class="estat-pocket-pill %5$s">%6$s</span></a>',
				esc_url( Pocket::url( 'enquiry', (int) $lead['id'] ) ),
				esc_html( $ini ),
				esc_html( (string) $lead['name'] ),
				$sub,
				'new' === $lead['status'] ? 'is-accent' : '',
				esc_html( $st[ $lead['status'] ] ?? (string) $lead['status'] )
			);
		}

		if ( $visits['items'] ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Visits', 'estat-os' ) . '</h2>';
			foreach ( $visits['items'] as $visit ) {
				$lead_name = '';
				if ( ! empty( $visit['lead_id'] ) ) {
					$one = Leads::get( (int) $visit['lead_id'] );
					if ( $one ) {
						$lead_name = (string) $one['name'];
					}
				}
				$ics_url = esc_url( Pocket::url( 'enquiry', (int) ( $visit['lead_id'] ?? 0 ) ) . '&estat_ics=' . (int) $visit['id'] );
				$out .= '<div class="estat-pocket-row is-flat"><span class="estat-pocket-well">' . Pocket::icon( 'calendar', 18 ) . '</span>' .
					'<span class="estat-pocket-rowmain"><b>' .
					esc_html( Format::date( (string) $visit['scheduled_at'] ) . ' · ' . Format::time( (string) $visit['scheduled_at'] ) ) .
					'</b><i>' . esc_html( $lead_name ) . ' · <a href="' . $ics_url . '">.ics</a></i></span></div>';
			}
		}

		return $out;
	}

	/**
	 * One enquiry: how to reach them, what was asked, and the small actions.
	 *
	 * @param int $lead_id Lead row ID.
	 * @return string|false
	 */
	private static function enquiry( int $lead_id ) {
		// .ics download?
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['estat_ics'] ) ) {
			$vid = absint( wp_unslash( (string) ( is_array($_GET['estat_ics']) ? '' : $_GET['estat_ics'] ) ) );
			if ( $vid > 0 ) {
				$visit = \EstatOS\Leads\Visits::get( $vid );
				if ( $visit && (int) $visit['lead_id'] === $lead_id ) {
					$lead = Leads::get( $lead_id );
					if ( $lead ) {
						$off   = Pocket::is_office();
						$agent = Pocket::agent_id();
						$mine  = $off || (int) $lead['agent_id'] === $agent || ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
						if ( $mine ) {
							$dt = (string) $visit['scheduled_at'];
							$ts = strtotime( $dt );
							if ( $ts ) {
								$start = gmdate( 'Ymd\THis\Z', $ts );
								$end   = gmdate( 'Ymd\THis\Z', $ts + 3600 );
								$summary = 'Visit: ' . (string) $lead['name'];
								$desc = 'Lead #' . $lead_id . ' ' . (string) $lead['phone'];
								header( 'Content-Type: text/calendar; charset=utf-8' );
								header( 'Content-Disposition: attachment; filename=visit-' . $vid . '.ics' );
								echo "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//EstatOS//Visit//EN\r\n";
								echo "BEGIN:VEVENT\r\nUID:visit-{$vid}@estatos\r\nDTSTAMP:" . gmdate('Ymd\THis\Z') . "\r\n";
								echo "DTSTART:{$start}\r\nDTEND:{$end}\r\nSUMMARY:" . str_replace(array("\r","\n"), " ", $summary) . "\r\nDESCRIPTION:" . str_replace(array("\r","\n"), " ", $desc) . "\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n";
								exit;
							}
						}
					}
				}
			}
		}

		$lead = Leads::get( $lead_id );
		if ( ! $lead ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$off   = Pocket::is_office();
		$agent = Pocket::agent_id();
		$mine  = $off || (int) $lead['agent_id'] === $agent || ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent ) || ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
		if ( ! $mine ) {
			return Pocket::fail_to_today( 'nope' );
		}

		$out = '<h1 class="estat-pocket-title">' . esc_html( (string) $lead['name'] ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' .
			esc_html( sprintf( __( 'Enquiry #%d', 'estat-os' ), (int) $lead['id'] ) ) . ' · ' .
			esc_html( Format::date( (string) $lead['created_at'] ) ) . ' ' . esc_html( Format::time( (string) $lead['created_at'] ) ) .
			'</p>';

		if ( ! empty( $lead['message'] ) ) {
			$out .= '<div class="estat-pocket-card"><div class="estat-pocket-quote">' . esc_html( (string) $lead['message'] ) . '</div></div>';
		}

		// Meta strip
		$meta_bits = array();
		if ( ! empty( $lead['intent'] ) ) { $meta_bits[] = esc_html( (string) $lead['intent'] ); }
		if ( ! empty( $lead['locality'] ) ) { $meta_bits[] = esc_html( (string) $lead['locality'] ); }
		if ( ! empty( $lead['budget_min'] ) || ! empty( $lead['budget_max'] ) ) {
			$meta_bits[] = Format::money( (int) ( $lead['budget_min'] ?? 0 ) ) . ' - ' . Format::money( (int) ( $lead['budget_max'] ?? 0 ) );
		}
		if ( ! empty( $lead['source'] ) ) { $meta_bits[] = esc_html( (string) $lead['source'] ); }
		if ( ! empty( $lead['lost_reason'] ) ) { $meta_bits[] = 'lost: ' . esc_html( (string) $lead['lost_reason'] ); }
		if ( ! empty( $lead['is_spam'] ) ) { $meta_bits[] = '🚩spam'; }
		if ( $meta_bits ) {
			$out .= '<p class="estat-pocket-hint">' . implode( ' · ', $meta_bits ) . '</p>';
		}

		$phone   = preg_replace( '/[^0-9+]/', '', (string) $lead['phone'] );
		$wa_raw  = preg_replace( '/\D/', '', (string) $lead['phone'] );
		$wa      = '';
		if ( '' !== $wa_raw ) {
			$wa = '0' === substr( $wa_raw, 0, 1 ) ? substr( $wa_raw, 1 ) : $wa_raw;
			if ( 10 === strlen( $wa ) ) {
				$wa = '91' . $wa;
			}
			if ( strlen( $wa ) < 10 ) {
				$wa = '';
			}
		}

		$out .= '<div class="estat-pocket-actions">';
		if ( '' !== $phone ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'tel:' . $phone ) . '">' . Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call', 'estat-os' ) . '</a>';
		}
		if ( '' !== $wa ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'https://wa.me/' . $wa ) . '">' . Pocket::icon( 'whatsapp', 14 ) . ' WhatsApp</a>';
		}
		if ( ! empty( $lead['email'] ) ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'mailto:' . sanitize_email( (string) $lead['email'] ) ) . '">' . esc_html__( 'Email', 'estat-os' ) . '</a>';
		}
		$out .= '</div>';

		if ( ! empty( $lead['listing_id'] ) ) {
			$out .= self::record_row( (int) $lead['listing_id'] );
		}

		// Log a visit.
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'enquiry', $lead_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="log_visit">';
		$out .= '<input type="hidden" name="lead_id" value="' . (int) $lead_id . '">';
		$out .= '<label class="estat-pocket-label">' . esc_html__( 'Booked a visit? Write when.', 'estat-os' ) . '</label>';
		$out .= '<input class="estat-pocket-input" type="datetime-local" name="scheduled_at" required>';
		$out .= '<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Log a visit', 'estat-os' ) . '</button>';
		$out .= '</form>';

		// Status + note + followup + lost_reason — one form.
		$st = Vocabulary::lead_statuses();
		$lost_reasons = Vocabulary::lead_lost_reasons();
		$intents = Vocabulary::lead_intents();
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'enquiry', $lead_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="lead_update">';
		$out .= '<input type="hidden" name="lead_id" value="' . (int) $lead_id . '">';
		$out .= self::select_field( __( 'Status', 'estat-os' ), 'status', $st, (string) $lead['status'] );
		$out .= self::select_field( __( 'Intent', 'estat-os' ), 'intent', $intents, (string) ( $lead['intent'] ?? '' ), __( 'Keep intent', 'estat-os' ) );
		$out .= self::select_field( __( 'Lost reason (if lost)', 'estat-os' ), 'lost_reason', $lost_reasons, (string) ( $lead['lost_reason'] ?? '' ), __( 'Not lost', 'estat-os' ) );
		$out .= self::field( __( 'Next follow-up', 'estat-os' ), 'followup_at', 'datetime-local', ! empty( $lead['followup_at'] ) ? substr( (string) $lead['followup_at'], 0, 16 ) : '', '', false );
		$out .= self::area_field( __( 'Your note', 'estat-os' ), 'notes', (string) $lead['notes'], __( 'Called back. Wants the 2BHK on the 8th.', 'estat-os' ) );
		$out .= '<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		$out .= '</form>';

		// Timeline
		$events = \EstatOS\Leads\LeadEvents::for_lead( $lead_id );
		if ( $events ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Timeline', 'estat-os' ) . '</h2>';
			foreach ( array_slice( $events, 0, 20 ) as $ev ) {
				$out .= '<div class="estat-pocket-row is-flat"><span class="estat-pocket-well">' . Pocket::icon( 'clock', 14 ) . '</span><span class="estat-pocket-rowmain"><b>' . esc_html( (string) $ev['event'] ) . '</b><i>' . esc_html( Format::date( (string) $ev['created_at'] ) . ' ' . Format::time( (string) $ev['created_at'] ) ) . '</i></span></div>';
			}
		}

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Approvals (office only)
	 * ------------------------------------------------------------------ */

	/**
	 * The queue from the phone: change requests and newly proposed listings,
	 * settled through the same paths wp-admin uses.
	 *
	 * @return string
	 */


	/* ---------------------------------------------------------------------
	 * Approvals (office only)
	 * ------------------------------------------------------------------ */

	/**
	 * The queue from the phone: change requests and newly proposed listings,
	 * settled through the same paths wp-admin uses.
	 *
	 * @return string
	 */
	private static function approvals(): string {
		$out = '<h2 class="estat-pocket-h2">' . esc_html__( 'Change requests', 'estat-os' ) . '</h2>';

		$pending = Requests::query( array( 'status' => 'pending', 'per_page' => 30 ) );
		if ( ! $pending['items'] ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'No change is waiting. The office queue is empty.', 'estat-os' ) . '</p>';
		}

		foreach ( $pending['items'] as $req ) {
			$record = get_post( (int) $req['record_id'] );
			$who    = get_userdata( (int) $req['requested_by'] );
			$out   .= '<div class="estat-pocket-card">';
			$out   .= '<div class="estat-pocket-kv"><i>' . esc_html__( 'From', 'estat-os' ) . '</i><b>' .
				esc_html( $who ? $who->display_name : __( 'someone who left', 'estat-os' ) ) . ' · ' .
				esc_html( Format::date( (string) $req['created_at'] ) ) . '</b></div>';
			$out   .= '<div class="estat-pocket-kv"><i>' . esc_html__( 'Property', 'estat-os' ) . '</i><b>' .
				esc_html( $record ? get_the_title( $record ) : '#' . (int) $req['record_id'] ) . '</b></div>';
			$changes = json_decode( (string) $req['changes'], true );
			$defs    = Requests::editable_fields();
			if ( is_array( $changes ) ) {
				foreach ( $changes as $key => $value ) {
					if ( 'note' === $key ) {
						continue;
					}
					$word  = $defs[ $key ]['label'] ?? ucfirst( (string) $key );
					$now   = Requests::current_value( (int) $req['record_id'], (string) $key );
					$out  .= '<div class="estat-pocket-kv"><i>' . esc_html( (string) $word ) . '</i><b>' .
						( '' !== $now ? '<s>' . esc_html( (string) $now ) . '</s> ' : '' ) .
						esc_html( Requests::describe( (string) $key, (string) $value ) ) . '</b></div>';
				}
				if ( ! empty( $changes['note'] ) ) {
					$out .= '<div class="estat-pocket-quote">' . esc_html( (string) $changes['note'] ) . '</div>';
				}
			}

			$rid = (int) $req['id'];
			$out .= '<div class="estat-pocket-actions">' .
				'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
				'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
				'<input type="hidden" name="estat_pocket_action" value="request_approve">' .
				'<input type="hidden" name="request_id" value="' . (int) $rid . '">' .
				'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Yes, change it', 'estat-os' ) . '</button></form>' .
				'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
				'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
				'<input type="hidden" name="estat_pocket_action" value="request_decline">' .
				'<input type="hidden" name="request_id" value="' . (int) $rid . '">' .
				'<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Not now', 'estat-os' ) . '</button></form>' .
				'</div>';
			$out .= '</div>';
		}

		// Proposed new listings.
		$proposed = get_posts(
			array(
				'post_type'   => array( PostTypes::LISTING, PostTypes::PROJECT ),
				'post_status' => 'pending',
				'numberposts' => 20,
			)
		);
		if ( $proposed ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'New listings waiting', 'estat-os' ) . '</h2>';
			foreach ( $proposed as $post ) {
				$out .= self::record_row( (int) $post->ID );
				$pid  = (int) $post->ID;
				$out .= '<div class="estat-pocket-actions" style="margin-top:-2px;">' .
					'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
					'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
					'<input type="hidden" name="estat_pocket_action" value="listing_approve">' .
					'<input type="hidden" name="record_id" value="' . (int) $pid . '">' .
					'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Put it live', 'estat-os' ) . '</button></form>' .
					'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
					'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
					'<input type="hidden" name="estat_pocket_action" value="listing_decline">' .
					'<input type="hidden" name="record_id" value="' . (int) $pid . '">' .
					'<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Back to draft', 'estat-os' ) . '</button></form>' .
					'</div>';
			}
		}

		return $out;
	}
}
