<?php
/**
 * Canonical business vocabularies (status models, types, units).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Single source of truth for every controlled list in the system.
 *
 * Keys are stable data-contract values and must not be renamed.
 * Labels are translated at call time, never stored.
 */
final class Vocabulary {

	/**
	 * Property types.
	 *
	 * @return array<string,string>
	 */
	public static function property_types(): array {
		return array(
			'apartment'         => __( 'Apartment', 'estat-os' ),
			'flat'              => __( 'Flat', 'estat-os' ),
			'villa'             => __( 'Villa', 'estat-os' ),
			'independent_house' => __( 'Independent House', 'estat-os' ),
			'builder_floor'     => __( 'Builder Floor', 'estat-os' ),
			'plot'              => __( 'Plot', 'estat-os' ),
			'commercial_shop'   => __( 'Commercial Shop', 'estat-os' ),
			'office'            => __( 'Office', 'estat-os' ),
			'warehouse'         => __( 'Warehouse', 'estat-os' ),
			'industrial'        => __( 'Industrial Property', 'estat-os' ),
			'farm_land'         => __( 'Farm Land', 'estat-os' ),
			'studio'            => __( 'Studio', 'estat-os' ),
			'penthouse'         => __( 'Penthouse', 'estat-os' ),
			'other'             => __( 'Other', 'estat-os' ),
		);
	}

	/**
	 * Offer types (what the office is doing with the property).
	 *
	 * @return array<string,string>
	 */
	public static function offers(): array {
		return array(
			'sale'  => __( 'For Sale', 'estat-os' ),
			'rent'  => __( 'For Rent', 'estat-os' ),
			'lease' => __( 'For Lease', 'estat-os' ),
		);
	}

	/**
	 * Availability states.
	 *
	 * @return array<string,string>
	 */
	public static function availability(): array {
		return array(
			'available' => __( 'Available', 'estat-os' ),
			'on_hold'   => __( 'On Hold / Under Offer', 'estat-os' ),
			'sold'      => __( 'Sold', 'estat-os' ),
			'rented'    => __( 'Rented', 'estat-os' ),
		);
	}

	/**
	 * Construction states.
	 *
	 * @return array<string,string>
	 */
	public static function construction(): array {
		return array(
			'ready'        => __( 'Ready to Move', 'estat-os' ),
			'construction' => __( 'Under Construction', 'estat-os' ),
			'new_launch'   => __( 'New Launch', 'estat-os' ),
		);
	}

	/**
	 * Verification states.
	 *
	 * @return array<string,string>
	 */
	public static function verification(): array {
		return array(
			'unverified'      => __( 'Not checked yet', 'estat-os' ),
			'self_verified'   => __( 'Checked by the owner/agent', 'estat-os' ),
			'office_verified' => __( 'Verified by our office', 'estat-os' ),
		);
	}

	/**
	 * Price types.
	 *
	 * @return array<string,string>
	 */
	public static function price_types(): array {
		return array(
			'fixed'         => __( 'Fixed price', 'estat-os' ),
			'negotiable'    => __( 'Negotiable', 'estat-os' ),
			'starting_from' => __( 'Starting from', 'estat-os' ),
			'on_request'    => __( 'Price on request', 'estat-os' ),
		);
	}

	/**
	 * Area measurement types.
	 *
	 * @return array<string,string>
	 */
	public static function area_types(): array {
		return array(
			'carpet'  => __( 'Carpet area', 'estat-os' ),
			'builtup' => __( 'Built-up area', 'estat-os' ),
			'super'   => __( 'Super built-up area', 'estat-os' ),
			'plot'    => __( 'Plot area', 'estat-os' ),
		);
	}

	/**
	 * Area units.
	 *
	 * @return array<string,string>
	 */
	public static function area_units(): array {
		return array(
			'sqft' => __( 'Square feet', 'estat-os' ),
			'sqyd' => __( 'Square yards', 'estat-os' ),
			'sqm'  => __( 'Square metres', 'estat-os' ),
		);
	}

	/**
	 * Furnishing options.
	 *
	 * @return array<string,string>
	 */
	public static function furnishing(): array {
		return array(
			''             => __( 'Not specified', 'estat-os' ),
			'unfurnished'  => __( 'Unfurnished', 'estat-os' ),
			'semi'         => __( 'Semi furnished', 'estat-os' ),
			'furnished'    => __( 'Fully furnished', 'estat-os' ),
		);
	}

	/**
	 * Facing directions.
	 *
	 * @return array<string,string>
	 */
	public static function facing(): array {
		return array(
			''           => __( 'Not specified', 'estat-os' ),
			'north'      => __( 'North', 'estat-os' ),
			'south'      => __( 'South', 'estat-os' ),
			'east'       => __( 'East', 'estat-os' ),
			'west'       => __( 'West', 'estat-os' ),
			'north_east' => __( 'North East', 'estat-os' ),
			'north_west' => __( 'North West', 'estat-os' ),
			'south_east' => __( 'South East', 'estat-os' ),
			'south_west' => __( 'South West', 'estat-os' ),
		);
	}

	/**
	 * Lead statuses — Mayfair pipeline: New → Contacted → Scheduled → Won / Lost / Spam.
	 * Legacy keys kept for backward compatibility.
	 *
	 * @return array<string,string>
	 */
	public static function lead_statuses(): array {
		return array(
			'new'             => __( 'New', 'estat-os' ),
			'contacted'       => __( 'Contacted', 'estat-os' ),
			'scheduled'       => __( 'Scheduled', 'estat-os' ),
			'won'             => __( 'Won', 'estat-os' ),
			'lost'            => __( 'Lost', 'estat-os' ),
			'spam'            => __( 'Spam', 'estat-os' ),
			// Legacy aliases — old data may still carry these.
			'qualified'       => __( 'Qualified', 'estat-os' ),
			'visit_scheduled' => __( 'Visit scheduled', 'estat-os' ),
			'converted'       => __( 'Converted', 'estat-os' ),
		);
	}

	/**
	 * Canonical pipeline order for Kanban.
	 *
	 * @return string[]
	 */
	public static function lead_pipeline_order(): array {
		return array( 'new', 'contacted', 'scheduled', 'won', 'lost', 'spam' );
	}

	/**
	 * Lost reasons required when status=lost.
	 *
	 * @return array<string,string>
	 */
	public static function lead_lost_reasons(): array {
		return array(
			'budget'          => __( 'Budget', 'estat-os' ),
			'location'        => __( 'Location', 'estat-os' ),
			'bought_elsewhere'=> __( 'Bought elsewhere', 'estat-os' ),
			'no_response'     => __( 'No response', 'estat-os' ),
			'other'           => __( 'Other', 'estat-os' ),
		);
	}

	/**
	 * Lead intents.
	 *
	 * @return array<string,string>
	 */
	public static function lead_intents(): array {
		return array(
			'buy'     => __( 'Buy', 'estat-os' ),
			'rent'    => __( 'Rent', 'estat-os' ),
			'sell'    => __( 'Sell', 'estat-os' ),
			'invest'  => __( 'Invest', 'estat-os' ),
			'consult' => __( 'Consult', 'estat-os' ),
		);
	}

	/**
	 * Map legacy statuses to new pipeline.
	 *
	 * @param string $status Old status.
	 * @return string
	 */
	public static function normalize_lead_status( string $status ): string {
		$map = array(
			'qualified'       => 'contacted',
			'visit_scheduled' => 'scheduled',
			'converted'       => 'won',
		);
		return $map[ $status ] ?? $status;
	}

	/**
	 * Visit outcomes.
	 *
	 * @return array<string,string>
	 */
	public static function visit_outcomes(): array {
		return array(
			'pending'   => __( 'Pending', 'estat-os' ),
			'done'      => __( 'Done', 'estat-os' ),
			'no_show'   => __( 'No-show', 'estat-os' ),
			'cancelled' => __( 'Cancelled', 'estat-os' ),
		);
	}

	/**
	 * Project statuses — Mayfair stages.
	 *
	 * @return array<string,string>
	 */
	public static function project_statuses(): array {
		return array(
			'planning'     => __( 'Planning', 'estat-os' ),
			'new_launch'   => __( 'New Launch', 'estat-os' ),
			'construction' => __( 'Under Construction', 'estat-os' ),
			'ready'        => __( 'Ready to Move', 'estat-os' ),
			'completed'    => __( 'Completed', 'estat-os' ),
		);
	}

	/**
	 * Ordered stages for timeline — Planning → UC → Ready.
	 *
	 * @return string[]
	 */
	public static function project_stage_order(): array {
		return array( 'planning', 'new_launch', 'construction', 'ready', 'completed' );
	}

	/**
	 * Progress percentage for each stage (for timeline bar).
	 *
	 * @return array<string,int>
	 */
	public static function project_stage_progress(): array {
		return array(
			'planning'     => 10,
			'new_launch'   => 25,
			'construction' => 60,
			'ready'        => 90,
			'completed'    => 100,
		);
	}

	/**
	 * Label for stage with emoji for frontend.
	 *
	 * @param string $stage Stage key.
	 * @return string
	 */
	public static function project_stage_label( string $stage ): string {
		$map = array(
			'planning'     => __( '📝 Planning', 'estat-os' ),
			'new_launch'   => __( '🚀 New Launch', 'estat-os' ),
			'construction' => __('Under Construction', 'estat-os'),
			'ready'        => __('Ready to Move', 'estat-os'),
			'completed'    => __( '✅ Completed', 'estat-os' ),
		);
		return $map[ $stage ] ?? $stage;
	}

	/**
	 * Possession timeline.
	 *
	 * @return array<string,string>
	 */
	public static function possession_timeline(): array {
		return array(
			''           => __( 'Any time', 'estat-os' ),
			'immediate'  => __( 'Immediate', 'estat-os' ),
			'3_months'   => __( 'Within 3 months', 'estat-os' ),
			'6_months'   => __( 'Within 6 months', 'estat-os' ),
			'1_year'     => __( 'Within 1 year', 'estat-os' ),
			'2_years'    => __( 'Within 2 years', 'estat-os' ),
		);
	}

	/**
	 * All 23 searchable filters for Mayfair — toggleable in settings.
	 *
	 * @return array<string,array{label:string,group:string}>
	 */
	public static function all_filters(): array {
		return array(
			'locality'       => array( 'label' => __( 'Locality', 'estat-os' ), 'group' => 'location' ),
			'property_type'  => array( 'label' => __( 'Property Type', 'estat-os' ), 'group' => 'basic' ),
			'offer'          => array( 'label' => __( 'For Sale / Rent', 'estat-os' ), 'group' => 'basic' ),
			'bedrooms'       => array( 'label' => __( 'Bedrooms', 'estat-os' ), 'group' => 'basic' ),
			'bathrooms'      => array( 'label' => __( 'Bathrooms', 'estat-os' ), 'group' => 'basic' ),
			'price'          => array( 'label' => __( 'Price / Budget', 'estat-os' ), 'group' => 'basic' ),
			'area'           => array( 'label' => __( 'Area (sqft)', 'estat-os' ), 'group' => 'basic' ),
			'furnishing'     => array( 'label' => __( 'Furnishing', 'estat-os' ), 'group' => 'details' ),
			'facing'         => array( 'label' => __( 'Facing', 'estat-os' ), 'group' => 'details' ),
			'floor'          => array( 'label' => __( 'Floor', 'estat-os' ), 'group' => 'details' ),
			'total_floors'   => array( 'label' => __( 'Total Floors', 'estat-os' ), 'group' => 'details' ),
			'construction'   => array( 'label' => __( 'Construction Stage', 'estat-os' ), 'group' => 'details' ),
			'availability'   => array( 'label' => __( 'Availability', 'estat-os' ), 'group' => 'details' ),
			'possession'     => array( 'label' => __( 'Possession Date', 'estat-os' ), 'group' => 'details' ),
			'age'            => array( 'label' => __( 'Property Age', 'estat-os' ), 'group' => 'details' ),
			'parking'        => array( 'label' => __( 'Parking', 'estat-os' ), 'group' => 'amenities' ),
			'balconies'      => array( 'label' => __( 'Balconies', 'estat-os' ), 'group' => 'amenities' ),
			'amenities'      => array( 'label' => __( 'Amenities', 'estat-os' ), 'group' => 'amenities' ),
			'features'       => array( 'label' => __( 'Features / Highlights', 'estat-os' ), 'group' => 'amenities' ),
			'verified'       => array( 'label' => __( 'Verified Only', 'estat-os' ), 'group' => 'trust' ),
			'featured'       => array( 'label' => __( 'Featured', 'estat-os' ), 'group' => 'trust' ),
			'project'        => array( 'label' => __( 'Society / Project', 'estat-os' ), 'group' => 'location' ),
			'investment'     => array( 'label' => __( 'Investment', 'estat-os' ), 'group' => 'trust' ),
		);
	}

	/**
	 * Share channels.
	 *
	 * @return array<string,string>
	 */
	public static function share_channels(): array {
		return array(
			'whatsapp' => __( 'WhatsApp', 'estat-os' ),
			'copy'     => __( 'Copy Link', 'estat-os' ),
			'email'    => __( 'Email', 'estat-os' ),
			'facebook' => __( 'Facebook', 'estat-os' ),
			'twitter'  => __( 'X (Twitter)', 'estat-os' ),
		);
	}

	/**
	 * Helper: the keys of a vocabulary.
	 *
	 * @param string $name Vocabulary method name.
	 * @return string[]
	 */
	public static function keys( string $name ): array {
		if ( ! method_exists( __CLASS__, $name ) ) {
			return array();
		}
		/** @var array<string,string> $list */
		$list = call_user_func( array( __CLASS__, $name ) );
		return array_map( 'strval', array_keys( $list ) );
	}

	/**
	 * Helper: label for a key.
	 *
	 * @param string $name Vocabulary method name.
	 * @param string $key  Key.
	 * @return string
	 */
	public static function label( string $name, string $key ): string {
		if ( ! method_exists( __CLASS__, $name ) ) {
			return $key;
		}
		/** @var array<string,string> $list */
		$list = call_user_func( array( __CLASS__, $name ) );
		return isset( $list[ $key ] ) ? (string) $list[ $key ] : $key;
	}
}
