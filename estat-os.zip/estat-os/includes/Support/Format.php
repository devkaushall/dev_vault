<?php
/**
 * Money, area and date formatting helpers.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Pure formatting helpers. Storage is always numeric; formatting is display only.
 */
final class Format {

	/**
	 * Area conversion factors to square feet.
	 *
	 * @var array<string,float>
	 */
	public const AREA_FACTORS = array(
		'sqft' => 1.0,
		'sqyd' => 9.0,
		'sqm'  => 10.7639,
	);

	/**
	 * Convert an area value to square feet.
	 *
	 * @param float  $value Area value.
	 * @param string $unit  Unit key.
	 * @return float Square feet, rounded to 2 decimals.
	 */
	public static function to_sqft( float $value, string $unit ): float {
		$factor = self::AREA_FACTORS[ $unit ] ?? 1.0;
		return round( $value * $factor, 2 );
	}

	/**
	 * Convert square feet into another unit.
	 *
	 * @param float  $sqft Square feet.
	 * @param string $unit Target unit.
	 * @return float
	 */
	public static function from_sqft( float $sqft, string $unit ): float {
		$factor = self::AREA_FACTORS[ $unit ] ?? 1.0;
		return round( $sqft / $factor, 2 );
	}

	/**
	 * Human readable area string.
	 *
	 * @param float  $value Value.
	 * @param string $unit  Unit key.
	 * @return string
	 */
	public static function area( float $value, string $unit = 'sqft' ): string {
		$labels = array(
			'sqft' => __( 'sq ft', 'estat-os' ),
			'sqyd' => __( 'sq yd', 'estat-os' ),
			'sqm'  => __( 'sq m', 'estat-os' ),
		);
		$label  = $labels[ $unit ] ?? $labels['sqft'];
		return number_format_i18n( $value, ( floor( $value ) === $value ) ? 0 : 2 ) . ' ' . $label;
	}

	/**
	 * Indian number grouping: 12,34,567.
	 *
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function number_indian( float $amount ): string {
		$amount = round( $amount );
		$negative = $amount < 0;
		$amount = abs( $amount );
		$s = (string) (int) $amount;
		$len = strlen( $s );
		if ( $len <= 3 ) {
			$out = $s;
		} else {
			$last3 = substr( $s, -3 );
			$rest = substr( $s, 0, -3 );
			// Group rest in 2s from right.
			$parts = array();
			while ( strlen( $rest ) > 2 ) {
				$parts[] = substr( $rest, -2 );
				$rest = substr( $rest, 0, -2 );
			}
			if ( '' !== $rest ) {
				$parts[] = $rest;
			}
			$parts = array_reverse( $parts );
			$out = implode( ',', $parts ) . ',' . $last3;
		}
		return $negative ? '-' . $out : $out;
	}

	/**
	 * Format a single price value for F0 display rules.
	 *
	 * @param float  $value Value.
	 * @param string $offer Offer type sale/rent/lease.
	 * @return string
	 */
	public static function price_single( float $value, string $offer = 'sale' ): string {
		if ( $value <= 0 ) {
			return '';
		}
		$symbol = '₹';
		$is_rent = in_array( $offer, array( 'rent', 'lease' ), true );
		if ( $is_rent ) {
			return $symbol . self::number_indian( $value );
		}
		// Sale: L / Cr logic.
		if ( $value >= 10000000 ) {
			// Cr.
			$cr = $value / 10000000;
			return $symbol . self::trim_number( $cr ) . ' Cr';
		}
		if ( $value >= 100000 ) {
			$lakh = $value / 100000;
			// Keep 1 decimal for values like 1.1 Cr / 85 L handling already.
			return $symbol . self::trim_number( $lakh ) . ' L';
		}
		// Below 1L sale: show Indian grouped full number.
		return $symbol . self::number_indian( $value );
	}

	/**
	 * F0 price range display: ₹2.9 – 3.1 Cr, ₹85 L – 1.1 Cr, ₹72,000 – 75,000 per month.
	 *
	 * @param float|null $min        Min price.
	 * @param float|null $max        Max price.
	 * @param string     $offer      sale/rent/lease.
	 * @param bool       $on_request Whether price on request.
	 * @return string
	 */
	public static function price_range( $min, $max, string $offer = 'sale', bool $on_request = false ): string {
		if ( $on_request ) {
			return __( 'Price on request', 'estat-os' );
		}
		$min = null !== $min ? (float) $min : 0;
		$max = null !== $max ? (float) $max : 0;

		// Legacy fallback: if only one of them is 0, use the other.
		if ( $min <= 0 && $max <= 0 ) {
			return __( 'Price on request', 'estat-os' );
		}
		if ( $min <= 0 ) {
			$min = $max;
		}
		if ( $max <= 0 ) {
			$max = $min;
		}

		$is_rent = in_array( $offer, array( 'rent', 'lease' ), true );

		if ( abs( $min - $max ) < 0.01 ) {
			$single = self::price_single( $min, $offer );
			if ( '' === $single ) {
				return __( 'Price on request', 'estat-os' );
			}
			return $single . ( $is_rent ? ' ' . __( 'per month', 'estat-os' ) : '' );
		}

		// Different min/max: format each.
		$low = $min;
		$high = $max;
		if ( $low > $high ) {
			$tmp = $low;
			$low = $high;
			$high = $tmp;
		}

		$low_str = self::price_single( $low, $offer );
		$high_str = self::price_single( $high, $offer );

		if ( '' === $low_str || '' === $high_str ) {
			return __( 'Price on request', 'estat-os' );
		}

		// If both have same unit suffix (e.g. both Cr), keep both full for clarity as per brief: ₹2.9 – 3.1 Cr (second has unit, first may need unit? Brief shows both with unit? Actually "₹2.9 – 3.1 Cr" — first without unit, second with. But simpler: if same unit, show "₹2.9 – 3.1 Cr". If different units, show both units "₹85 L – 1.1 Cr". Implement: if units same, strip unit from low and keep on high.
		$low_unit = '';
		$high_unit = '';
		if ( preg_match( '/\s(Cr|L)$/', $low_str, $m ) ) {
			$low_unit = $m[1];
		}
		if ( preg_match( '/\s(Cr|L)$/', $high_str, $m ) ) {
			$high_unit = $m[1];
		}

		// Both same unit: ₹2.9 – 3.1 Cr => strip unit from low, keep full high.
		if ( $low_unit && $high_unit && $low_unit === $high_unit ) {
			$low_num = trim( str_replace( array( '₹', $low_unit ), '', $low_str ) );
			$high_full = trim( $high_str );
			// high_full already has ₹ + number + unit, we want "₹low – high" where high includes unit but low's ₹ stays.
			// Extract high number+unit without leading ₹.
			$high_without_rupee = ltrim( $high_full, '₹' );
			$high_without_rupee = trim( $high_without_rupee );
			$combined = '₹' . $low_num . ' – ' . $high_without_rupee;
		} else {
			// Different units: ₹85 L – 1.1 Cr or rent: ₹72,000 – 75,000
			$high_without_rupee = ltrim( $high_str, '₹' );
			$high_without_rupee = trim( $high_without_rupee );
			$combined = $low_str . ' – ' . $high_without_rupee;
		}

		// Ensure starts with ₹.
		if ( 0 !== strpos( $combined, '₹' ) ) {
			$combined = '₹' . ltrim( $combined, '₹ ' );
		}

		if ( $is_rent ) {
			$combined .= ' ' . __( 'per month', 'estat-os' );
		}

		return $combined;
	}

	/**
	 * Format a monetary amount for display.
	 *
	 * @param float       $amount   Numeric amount in the office currency.
	 * @param string|null $symbol   Currency symbol override.
	 * @param string|null $style    'indian' or 'international'.
	 * @return string
	 */
	public static function money( float $amount, ?string $symbol = null, ?string $style = null ): string {
		$settings = Settings::all();
		$symbol   = null !== $symbol ? $symbol : (string) $settings['currency_symbol'];
		$style    = null !== $style ? $style : (string) $settings['price_format'];

		if ( $amount < 0 ) {
			return $symbol . '0';
		}

		if ( 'indian' === $style ) {
			if ( $amount >= 10000000 ) {
				return $symbol . self::trim_number( $amount / 10000000 ) . ' ' . __( 'Cr', 'estat-os' );
			}
			if ( $amount >= 100000 ) {
				return $symbol . self::trim_number( $amount / 100000 ) . ' ' . __( 'Lakh', 'estat-os' );
			}
			if ( $amount >= 1000 ) {
				return $symbol . self::trim_number( $amount / 1000 ) . ' ' . __( 'K', 'estat-os' );
			}
			return $symbol . number_format_i18n( $amount, 0 );
		}

		if ( $amount >= 1000000 ) {
			return $symbol . self::trim_number( $amount / 1000000 ) . 'M';
		}
		if ( $amount >= 1000 ) {
			return $symbol . self::trim_number( $amount / 1000 ) . 'K';
		}
		return $symbol . number_format_i18n( $amount, 0 );
	}

	/**
	 * Trim trailing zeros from a short decimal.
	 *
	 * @param float $number Number.
	 * @return string
	 */
	private static function trim_number( float $number ): string {
		$rounded = round( $number, 2 );
		if ( floor( $rounded ) === $rounded ) {
			return (string) (int) $rounded;
		}
		return rtrim( rtrim( number_format( $rounded, 2, '.', '' ), '0' ), '.' );
	}

	/**
	 * Format a stored Y-m-d date for humans.
	 *
	 * @param string $date Date string.
	 * @return string
	 */
	public static function date( string $date ): string {
		$time = strtotime( $date );
		if ( ! $time ) {
			return '';
		}
		return date_i18n( (string) get_option( 'date_format', 'Y-m-d' ), $time );
	}

	/**
	 * A time of day, in whatever format the site prefers.
	 *
	 * @param string $date Date string.
	 * @return string
	 */
	public static function time( string $date ): string {
		$time = strtotime( $date );
		if ( ! $time ) {
			return '';
		}
		return date_i18n( (string) get_option( 'time_format', 'H:i' ), $time );
	}
}
