<?php
/**
 * Design Tokens inline CSS output — F7.
 *
 * Reads Settings::get('design_tokens') and prints :root overrides after tokens.css.
 * Applies to Office, Pocket, Frontend, Dashboard — all surfaces.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class DesignTokens {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_head', array( __CLASS__, 'print_inline' ), 20 );
		add_action( 'admin_head', array( __CLASS__, 'print_inline' ), 20 );
		// Pocket prints its own <style> in Screens::shell(), but also gets wp_head? No, pocket is standalone template_redirect exit.
		// So we also hook into pocket shell via filter.
		add_filter( 'estat_pocket_inline_tokens', array( __CLASS__, 'inline_css' ) );
		add_filter( 'estat_dashboard_inline_tokens', array( __CLASS__, 'inline_css' ) );
	}

	/**
	 * Build inline CSS :root overrides.
	 *
	 * @return string CSS
	 */
	public static function inline_css(): string {
		$tokens = Settings::get( 'design_tokens', array() );
		if ( ! $tokens || ! is_array( $tokens ) ) {
			return '';
		}
		$css = ":root {\n";
		foreach ( $tokens as $k => $v ) {
			$k = trim( (string) $k );
			$v = trim( (string) $v );
			if ( '' === $k || '' === $v ) { continue; }
			if ( 0 !== strpos($k, '--') ) {
				$k = '--' . ltrim( $k, '-' );
			}
			// Basic sanitization: allow only safe chars in value.
			// We already sanitized via sanitize_text_field, but double-check.
			$css .= "  " . esc_html( $k ) . ": " . esc_html( $v ) . ";\n";
		}
		$css .= "}\n";
		return $css;
	}

	/**
	 * Print <style> tag in head if tokens exist.
	 *
	 * @return void
	 */
	public static function print_inline(): void {
		$css = self::inline_css();
		if ( '' === $css ) { return; }
		echo "<style id=\"estat-design-tokens-overrides\">\n" . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
