<?php
/**
 * Office notifications.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Notifications;

use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Plain, short emails. Every notification can be switched off in settings and
 * the office is never emailed twice for the same event.
 */
final class Notifier {

	/**
	 * Enquiry IDs already announced this request, so an enquiry is never
	 * emailed twice.
	 *
	 * @var array<int,bool>
	 */
	private static $announced = array();


	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'estat_lead_created', array( __CLASS__, 'on_lead_created' ), 10, 1 );
		add_action( 'estat_lead_status_changed', array( __CLASS__, 'lead_status_changed' ), 10, 3 );
		add_action( 'estat_lead_assigned', array( __CLASS__, 'lead_assigned' ), 10, 2 );
		add_action( 'estat_visit_scheduled', array( __CLASS__, 'new_visit' ), 10, 1 );
		add_action( 'estat_visit_completed', array( __CLASS__, 'visit_completed' ), 10, 1 );
		add_action( 'estat_request_created', array( __CLASS__, 'new_request' ), 10, 2 );
		add_action( 'estat_listing_published', array( __CLASS__, 'listing_published' ), 10, 2 );
		add_action( 'estat_listing_verified', array( __CLASS__, 'listing_verified' ), 10, 1 );
		add_action( 'estat_project_stage_changed', array( __CLASS__, 'project_stage_changed' ), 10, 3 );
		add_action( 'estat_form_submitted', array( __CLASS__, 'form_submitted' ), 10, 4 );
		add_action( 'estat_alert_created', array( __CLASS__, 'alert_created' ), 10, 2 );
		add_action( 'estat_share_logged', array( __CLASS__, 'share_logged' ), 10, 2 );
	}

	/**
	 * Announce an enquiry that arrived from anywhere: the REST API, an import,
	 * the admin screens or another plugin.
	 *
	 * Form submissions call new_lead() directly so they can honour the
	 * per-form recipient, so this guards against sending the same enquiry
	 * twice.
	 *
	 * @param int $lead_id Lead ID.
	 * @return void
	 */
	public static function on_lead_created( int $lead_id ): void {
		if ( isset( self::$announced[ $lead_id ] ) ) {
			return;
		}
		self::new_lead( $lead_id );
	}

	/**
	 * Send the mail with a consistent from-name and plain text body.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    Body.
	 * @return bool
	 */
	private static function send( string $to, string $subject, string $body ): bool {
		if ( ! is_email( $to ) ) {
			return false;
		}
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		return (bool) wp_mail( $to, wp_specialchars_decode( $subject ), $body, $headers );
	}

	/**
	 * Notify the office about a new enquiry.
	 *
	 * @param int    $lead_id  Lead ID.
	 * @param int    $form_id  Form ID.
	 * @param string $override Optional recipient override.
	 * @return void
	 */
	public static function new_lead( int $lead_id, int $form_id = 0, string $override = '' ): void {
		if ( isset( self::$announced[ $lead_id ] ) ) {
			return;
		}
		self::$announced[ $lead_id ] = true;

		if ( ! Settings::get( 'notify_new_lead' ) ) {
			return;
		}
		$lead = $lead_id > 0 ? Leads::get( $lead_id ) : null;
		// F1: don't email for spam.
		if ( $lead && 'spam' === $lead['status'] ) {
			return;
		}
		$to   = is_email( $override ) ? $override : Settings::notification_email();

		$lines   = array();
		$lines[] = __( 'A new enquiry has arrived.', 'estat-os' );
		$lines[] = '';
		if ( $lead ) {
			$lines[] = __( 'Name:', 'estat-os' ) . ' ' . $lead['name'];
			if ( '' !== (string) $lead['phone'] ) {
				$lines[] = __( 'Phone:', 'estat-os' ) . ' ' . $lead['phone'];
			}
			if ( '' !== (string) $lead['email'] ) {
				$lines[] = __( 'Email:', 'estat-os' ) . ' ' . $lead['email'];
			}
			if ( (int) $lead['listing_id'] > 0 ) {
				$lines[] = __( 'Property:', 'estat-os' ) . ' ' . get_the_title( (int) $lead['listing_id'] );
			}
			if ( '' !== (string) $lead['message'] ) {
				$lines[] = '';
				$lines[] = __( 'Message:', 'estat-os' );
				$lines[] = (string) $lead['message'];
			}
		}
		$lines[] = '';
		$lines[] = __( 'Open your office dashboard to reply:', 'estat-os' );
		$lines[] = admin_url( 'admin.php?page=estat-enquiries' );

		self::send( $to, sprintf( /* translators: %s: office name */ __( '[%s] New enquiry', 'estat-os' ), Settings::office_name() ), implode( "\n", $lines ) );
	}

	/**
	 * Notify about a newly scheduled visit.
	 *
	 * @param int $visit_id Visit ID.
	 * @return void
	 */
	public static function new_visit( int $visit_id ): void {
		if ( ! Settings::get( 'notify_new_visit' ) ) {
			return;
		}
		$visit = \EstatOS\Leads\Visits::get( $visit_id );
		if ( ! $visit ) {
			return;
		}
		$ics_url = admin_url( 'admin.php?estat_action=download_ics&visit_id=' . (int) $visit['id'] . '&estat_nonce=' . wp_create_nonce( 'estat_download_ics_' . (int) $visit['id'] ) );
		$body = implode(
			"\n",
			array(
				__( 'A site visit has been scheduled.', 'estat-os' ),
				'',
				__( 'When:', 'estat-os' ) . ' ' . get_date_from_gmt( (string) $visit['scheduled_at'] ),
				__( 'Property:', 'estat-os' ) . ' ' . ( (int) $visit['listing_id'] > 0 ? get_the_title( (int) $visit['listing_id'] ) : __( 'Not set', 'estat-os' ) ),
				__( 'Add to calendar (.ics):', 'estat-os' ) . ' ' . $ics_url,
				'',
				admin_url( 'admin.php?page=estat-visits' ),
			)
		);
		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] Site visit scheduled', 'estat-os' ), Settings::office_name() ), $body );
	}

	/**
	 * Tell the office somebody on the ground found something the website has
	 * wrong.
	 *
	 * Deliberately short, and no more than that: the detail belongs on the
	 * screen where it gets decided, and a mail that tries to be the screen ends
	 * up being answered badly from a phone.
	 *
	 * @param int $request_id Request ID.
	 * @param int $record_id  The property concerned.
	 * @return void
	 */
	public static function new_request( int $request_id, int $record_id = 0 ): void {
		if ( ! Settings::get( 'notify_change_request' ) ) {
			return;
		}
		$request = \EstatOS\Field\Requests::get( $request_id );
		if ( ! $request ) {
			return;
		}

		$lines = array();

		foreach ( Requests::editable_fields() as $field => $meta ) {
			if ( 'note' === $field || ! isset( $request['changes'][ $field ] ) ) {
				continue;
			}
			$lines[] = esc_html( (string) $meta['label'] ) . ': ' . Requests::describe( (string) $field, (string) $request['changes'][ $field ] );
		}

		$agent = get_userdata( (int) $request['requested_by'] );
		$name  = is_object( $agent ) && isset( $agent->display_name ) ? (string) $agent->display_name : '';

		$body = implode(
			"\n",
			array_merge(
				array(
					__( 'A change has been proposed to a property:', 'estat-os' ),
					'',
					__( 'Property:', 'estat-os' ) . ' ' . (string) get_the_title( (int) $request['record_id'] ),
					__( 'From:', 'estat-os' ) . ' ' . ( '' !== $name ? $name : __( 'someone on your team', 'estat-os' ) ),
				),
				$lines,
				array(
					'',
					admin_url( 'admin.php?page=estat-requests' ),
				)
			)
		);

		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] A property needs a decision', 'estat-os' ), Settings::office_name() ), $body );
	}

	/**
	 * Daily follow-up digest.
	 *
	 * @param int $count Number of follow-ups due.
	 * @return void
	 */
	public static function followups_due( int $count ): void {
		if ( ! Settings::get( 'notify_followup' ) || $count <= 0 ) {
			return;
		}
		$body = sprintf(
			/* translators: %d: number of follow-ups */
			_n( '%d enquiry needs a follow-up today.', '%d enquiries need a follow-up today.', $count, 'estat-os' ),
			$count
		) . "\n\n" . admin_url( 'admin.php?page=estat-enquiries&filter=followup' );
		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] Follow-ups due today', 'estat-os' ), Settings::office_name() ), $body );
	}

	/**
	 * Listing expiry notice.
	 *
	 * @param int $count Number expired.
	 * @return void
	 */
	public static function listings_expired( int $count ): void {
		if ( ! Settings::get( 'notify_expiry' ) || $count <= 0 ) {
			return;
		}
		$body = sprintf(
			/* translators: %d: number of listings */
			_n( '%d listing was taken off the website because it reached its removal date.', '%d listings were taken off the website because they reached their removal date.', $count, 'estat-os' ),
			$count
		);
		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] Listings taken offline', 'estat-os' ), Settings::office_name() ), $body );
	}

	/**
	 * Import finished notice.
	 *
	 * @param array<string,int> $summary Summary counts.
	 * @return void
	 */
	public static function import_finished( array $summary ): void {
		if ( ! Settings::get( 'notify_import' ) ) {
			return;
		}
		$body = implode(
			"\n",
			array(
				__( 'Your spreadsheet import has finished.', 'estat-os' ),
				'',
				__( 'Added:', 'estat-os' ) . ' ' . (int) ( $summary['created'] ?? 0 ),
				__( 'Updated:', 'estat-os' ) . ' ' . (int) ( $summary['updated'] ?? 0 ),
				__( 'Skipped:', 'estat-os' ) . ' ' . (int) ( $summary['skipped'] ?? 0 ),
			)
		);
		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] Import finished', 'estat-os' ), Settings::office_name() ), $body );
	}

	/**
	 * Lead status changed — F11.
	 */
	public static function lead_status_changed( int $lead_id, string $old_status, string $new_status ): void {
		if ( ! Settings::get( 'notify_lead_status' ) ) { return; }
		$lead = Leads::get( $lead_id );
		if ( ! $lead ) { return; }
		$body = sprintf( "Enquiry #%d status changed: %s → %s\nName: %s\n%s\n\n%s", $lead_id, $old_status, $new_status, $lead['name'] ?? '', $lead['phone'] ?? '', admin_url( 'admin.php?page=estat-enquiries' ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Enquiry status: %s → %s', Settings::office_name(), $old_status, $new_status ), $body );
	}

	public static function lead_assigned( int $lead_id, int $agent_id ): void {
		if ( ! Settings::get( 'notify_lead_assigned' ) ) { return; }
		$lead = Leads::get( $lead_id );
		$agent_name = $agent_id ? get_the_title( $agent_id ) : 'Unassigned';
		$body = sprintf( "Enquiry #%d assigned to %s\nName: %s\n%s", $lead_id, $agent_name, $lead['name'] ?? '', admin_url( 'admin.php?page=estat-enquiries' ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Enquiry assigned to %s', Settings::office_name(), $agent_name ), $body );
	}

	public static function visit_completed( int $visit_id ): void {
		if ( ! Settings::get( 'notify_visit_completed' ) ) { return; }
		$visit = \EstatOS\Leads\Visits::get( $visit_id );
		if ( ! $visit ) { return; }
		$body = sprintf( "Visit #%d completed — outcome: %s\nLead #%d\n%s", $visit_id, $visit['outcome'] ?? 'done', $visit['lead_id'] ?? 0, admin_url( 'admin.php?page=estat-visits' ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Visit completed', Settings::office_name() ), $body );
	}

	public static function listing_published( int $listing_id, array $data = array() ): void {
		if ( ! Settings::get( 'notify_listing_published' ) ) { return; }
		$body = sprintf( "Property published: %s\n%s\n%s", get_the_title( $listing_id ), get_permalink( $listing_id ), admin_url( 'post.php?post=' . $listing_id . '&action=edit' ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Property live: %s', Settings::office_name(), get_the_title( $listing_id ) ), $body );
	}

	public static function listing_verified( int $listing_id ): void {
		if ( ! Settings::get( 'notify_listing_verified' ) ) { return; }
		$body = sprintf( "Property verified — humne khud dekha tick: %s\n%s", get_the_title( $listing_id ), get_permalink( $listing_id ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Verified: %s', Settings::office_name(), get_the_title( $listing_id ) ), $body );
	}

	public static function project_stage_changed( int $project_id, string $old_stage, string $new_stage ): void {
		if ( ! Settings::get( 'notify_project_stage' ) ) { return; }
		$body = sprintf( "Project %s stage: %s → %s\n%s", get_the_title( $project_id ), $old_stage, $new_stage, get_permalink( $project_id ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Project stage: %s → %s', Settings::office_name(), $old_stage, $new_stage ), $body );
	}

	public static function form_submitted( int $form_id, int $lead_id, array $values, int $submission_id ): void {
		if ( ! Settings::get( 'notify_form_submitted' ) ) { return; }
		$body = sprintf( "Form #%d submitted — lead #%d, submission #%d\nKeys: %s\n%s", $form_id, $lead_id, $submission_id, implode( ', ', array_keys( $values ) ), admin_url( 'admin.php?page=estat-forms&view=submissions&edit=' . $form_id ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Form submitted #%d', Settings::office_name(), $form_id ), $body );
	}

	public static function alert_created( int $alert_id, array $data = array() ): void {
		if ( ! Settings::get( 'notify_alert_created' ) ) { return; }
		$body = sprintf( "Search alert #%d created by %s (%s)\nFilters: %s", $alert_id, $data['email'] ?? '', $data['name'] ?? '', wp_json_encode( $data['filters'] ?? array() ) );
		self::send( Settings::notification_email(), sprintf( '[%s] New search alert', Settings::office_name() ), $body );
	}

	public static function share_logged( int $listing_id, string $channel ): void {
		if ( ! Settings::get( 'notify_share' ) ) { return; }
		$body = sprintf( "Property %s shared via %s\n%s", get_the_title( $listing_id ), $channel, get_permalink( $listing_id ) );
		self::send( Settings::notification_email(), sprintf( '[%s] Shared via %s', Settings::office_name(), $channel ), $body );
	}

	/**
	 * Webhook failure notice.
	 *
	 * @param string $event Event name.
	 * @param string $error Error text.
	 * @return void
	 */
	public static function webhook_failed( string $event, string $error ): void {
		if ( ! Settings::get( 'notify_webhook_fail' ) ) {
			return;
		}
		$body = __( 'A connection to your other system did not work.', 'estat-os' ) . "\n\n"
			. __( 'Event:', 'estat-os' ) . ' ' . $event . "\n"
			. __( 'Details:', 'estat-os' ) . ' ' . $error;
		self::send( Settings::notification_email(), sprintf( /* translators: %s: office name */ __( '[%s] Connection problem', 'estat-os' ), Settings::office_name() ), $body );
	}
}
