<?php
/**
 * Versioned, idempotent, non-destructive upgrades.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Install;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Taxonomies;
use EstatOS\Cron\Scheduler;
use EstatOS\Security\Roles;

defined( 'ABSPATH' ) || exit;

/**
 * Migrations only ever add. Stored data never silently changes meaning; if a
 * value must change shape, a new key is introduced alongside the old one.
 */
final class Migrator {

	/**
	 * Run any pending upgrade steps.
	 *
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$stored_db = (string) get_option( 'estat_db_version', '0' );
		$stored_pl = (string) get_option( 'estat_version', '0' );

		if ( $stored_db === ESTAT_DB_VERSION && $stored_pl === ESTAT_VERSION ) {
			return;
		}

		// Tables and roles are always re-synced; both operations are safe repeats.
		Schema::install();
		Roles::install();
		Scheduler::schedule();

		if ( version_compare( $stored_db, ESTAT_DB_VERSION, '<' ) ) {
			self::run_steps( $stored_db );
			update_option( 'estat_db_version', ESTAT_DB_VERSION, false );
		}

		if ( $stored_pl !== ESTAT_VERSION ) {
			update_option( 'estat_version', ESTAT_VERSION, false );
			AuditLog::record( 'plugin.upgraded', 'plugin', 0, array( 'from' => $stored_pl, 'to' => ESTAT_VERSION ) );
		}
	}

	/**
	 * Run numbered migration steps newer than the stored version.
	 *
	 * @param string $from Stored database version.
	 * @return void
	 */
	private static function run_steps( string $from ): void {
		$steps = array(
			'2' => array( __CLASS__, 'step_2' ),
			'3' => array( __CLASS__, 'step_3' ),
			'4' => array( __CLASS__, 'step_4' ),
			'5' => array( __CLASS__, 'step_5' ),
			'6' => array( __CLASS__, 'step_6' ),
			'7' => array( __CLASS__, 'step_7' ),
			'8' => array( __CLASS__, 'step_8' ),
		);
		foreach ( $steps as $version => $callback ) {
			if ( version_compare( $from, (string) $version, '<' ) && is_callable( $callback ) ) {
				call_user_func( $callback );
			}
		}
	}

	/**
	 * Version 2: the office can now publish blogs, articles and insights,
	 * which needs a new permission and its starter categories. Nothing is
	 * removed or rewritten, so this is safe to repeat.
	 *
	 * @return void
	 */
	private static function step_3(): void {
		// Version 3 fixes a permission fault that made most of the Office menu
		// disappear. Roles::install() has already run and adds the corrected
		// permissions; the stored menu positions just need refreshing so the
		// entries come back without the site owner doing anything.
		delete_option( 'estat_index_repair_offset' );

		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
	}

	/**
	 * Version 4: the change-request table.
	 *
	 * Agents working from a phone can propose changes to properties that are
	 * not theirs, and those wait here for the office. An existing site has no
	 * such table, so it has to be created on upgrade rather than only on a
	 * fresh install.
	 *
	 * @return void
	 */
	private static function step_4(): void {
		// install() is written to be safe to run again: dbDelta creates what
		// is missing and leaves what is already correct alone.
		Schema::install();
	}

	/**
	 * Version 2: the office can now publish blogs, articles and insights.
	 *
	 * @return void
	 */
	private static function step_2(): void {
		// 3.0.7: no auto-create taxonomy terms on upgrade
		// Seed is available via Tools if needed
	}

	/**
	 * Version 5: placeholder for v2.9.
	 *
	 * @return void
	 */
	private static function step_5(): void {
		Schema::install();
	}

	/**
	 * Version 6: Mayfair Edition — new tables, F0 price ranges, lead status normalization.
	 * Idempotent: safe to run multiple times, never resets cover/gallery/price/agent/featured.
	 *
	 * @return void
	 */
	private static function step_6(): void {
		Schema::install();
		global $wpdb;

		// F0: migrate legacy _estat_price -> _estat_price_min/max, and _estat_rent -> min/max for rent.
		// Only where min/max empty, to keep idempotency and not overwrite manual ranges.
		$listings = get_posts(
			array(
				'post_type'      => \EstatOS\Data\PostTypes::LISTING,
				'post_status'    => array( 'any' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $listings as $lid ) {
			$price = get_post_meta( $lid, '_estat_price', true );
			$rent  = get_post_meta( $lid, '_estat_rent', true );
			$min   = get_post_meta( $lid, '_estat_price_min', true );
			$max   = get_post_meta( $lid, '_estat_price_max', true );

			if ( '' === $min && '' === $max ) {
				if ( '' !== $price && (float) $price > 0 ) {
					update_post_meta( $lid, '_estat_price_min', $price );
					update_post_meta( $lid, '_estat_price_max', $price );
				} elseif ( '' !== $rent && (float) $rent > 0 ) {
					update_post_meta( $lid, '_estat_price_min', $rent );
					update_post_meta( $lid, '_estat_price_max', $rent );
				}
			}
			// Re-index for price_sort.
			if ( class_exists( \EstatOS\Search\SearchIndex::class ) ) {
				\EstatOS\Search\SearchIndex::index_listing( (int) $lid );
			}
		}

		// Normalize old lead statuses to new pipeline (F1).
		$table = Schema::table( 'estat_leads' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "UPDATE {$table} SET status = 'contacted' WHERE status = 'qualified'" );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "UPDATE {$table} SET status = 'scheduled' WHERE status = 'visit_scheduled'" );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "UPDATE {$table} SET status = 'won' WHERE status = 'converted'" );
		}

		// Seed default template if not exists — idempotent.
		if ( class_exists( \EstatOS\Data\Templates::class ) ) {
			$existing = \EstatOS\Data\Templates::get_blocks( 'listing' );
			if ( empty( $existing ) ) {
				\EstatOS\Data\Templates::save_blocks( \EstatOS\Data\Templates::default_blocks(), 'listing' );
			}
		}

		// Ensure cover photos not reset: we never touch _thumbnail_id or _estat_gallery here.
	}

	/**
	 * Version 7: F9 — 23 filters full support, amenities/features index columns.
	 *
	 * @return void
	 */
	private static function step_7(): void {
		Schema::install();
		// Re-index all listings to populate new amenities_ids / features_ids.
		if ( class_exists( \EstatOS\Search\SearchIndex::class ) ) {
			$ids = get_posts( array( 'post_type' => \EstatOS\Data\PostTypes::LISTING, 'post_status' => array( 'publish', 'draft', 'pending', 'private' ), 'posts_per_page' => 500, 'fields' => 'ids', 'no_found_rows' => true ) );
			foreach ( $ids as $id ) {
				\EstatOS\Search\SearchIndex::index_listing( (int) $id );
			}
		}
	}

	/**
	 * Version 8: F10 — locality/amenity pages, EMI defaults, project timeline.
	 *
	 * @return void
	 */
	private static function step_8(): void {
		Schema::install();
		// 3.0.7: no auto-seed of taxonomy terms on upgrade
	}
}
