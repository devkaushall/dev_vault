<?php
/**
 * One-click repair for data broken by 3.0.6 comma split and auto-published pages.
 *
 * - Locality terms "Sohna Road (Sector 49" and "Uppal Southend)" merged into "Sohna Road (Sector 49, Uppal Southend)".
 * - Any locality term with unbalanced brackets (e.g. "Foo (Bar" or "Baz)") merged/fixed.
 * - 13 helper pages IDs 8193-8205 (search, projects, team, localities, amenities, favorites, compare, emi, alerts, office)
 *   that were auto-published in 3.0.6 are set back to draft.
 *
 * Safe, idempotent, no deletions — only merges and drafts.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Install;

use EstatOS\Data\Taxonomies;

defined( 'ABSPATH' ) || exit;

final class RepairData {

	/**
	 * Run all repairs.
	 *
	 * @return array<string,mixed> Summary.
	 */
	public static function run(): array {
		$locality = self::repair_localities();
		$pages    = self::repair_pages();

		return array(
			'locality_fixed' => $locality['fixed'],
			'locality_merged' => $locality['merged'],
			'locality_details' => $locality['details'],
			'pages_drafted' => $pages['drafted'],
			'pages_details' => $pages['details'],
		);
	}

	/**
	 * Repair locality terms broken by comma split.
	 *
	 * @return array<string,mixed>
	 */
	private static function repair_localities(): array {
		$fixed = 0;
		$merged = 0;
		$details = array();

		$terms = get_terms( array(
			'taxonomy'   => Taxonomies::LOCALITY,
			'hide_empty' => false,
			'number'     => 500,
		) );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array( 'fixed' => 0, 'merged' => 0, 'details' => array( 'No locality terms found' ) );
		}

		// Index by name for quick lookup.
		$by_name = array();
		foreach ( $terms as $t ) {
			$by_name[ $t->name ] = $t;
		}

		// Known broken pair from audit: "Sohna Road (Sector 49" + "Uppal Southend)"
		$pair_a = 'Sohna Road (Sector 49';
		$pair_b = 'Uppal Southend)';
		$correct = 'Sohna Road (Sector 49, Uppal Southend)';

		if ( isset( $by_name[ $pair_a ] ) && isset( $by_name[ $pair_b ] ) ) {
			$term_a = $by_name[ $pair_a ];
			$term_b = $by_name[ $pair_b ];

			// Check if correct already exists.
			$existing_correct = get_term_by( 'name', $correct, Taxonomies::LOCALITY );
			if ( ! $existing_correct ) {
				$existing_correct = get_term_by( 'slug', sanitize_title( $correct ), Taxonomies::LOCALITY );
			}

			if ( $existing_correct && ! is_wp_error( $existing_correct ) ) {
				$target_id = (int) $existing_correct->term_id;
				$details[] = "Target {$correct} already exists (ID {$target_id}), merging broken pair into it";
			} else {
				// Rename first term to correct name.
				$res = wp_update_term( (int) $term_a->term_id, Taxonomies::LOCALITY, array( 'name' => $correct, 'slug' => sanitize_title( $correct ) ) );
				if ( ! is_wp_error( $res ) ) {
					$target_id = (int) $term_a->term_id;
					$fixed++;
					$details[] = "Renamed '{$pair_a}' (ID {$term_a->term_id}) to '{$correct}' (ID {$target_id})";
				} else {
					$target_id = (int) $term_a->term_id;
					$details[] = "Failed to rename {$pair_a}: " . $res->get_error_message();
				}
			}

			// Merge second term into target: reassign posts, then delete.
			if ( isset( $target_id ) ) {
				$posts_a = get_objects_in_term( (int) $term_b->term_id, Taxonomies::LOCALITY );
				if ( ! is_wp_error( $posts_a ) && ! empty( $posts_a ) ) {
					foreach ( $posts_a as $post_id ) {
						// Get current terms for post.
						$current = wp_get_object_terms( (int) $post_id, Taxonomies::LOCALITY, array( 'fields' => 'ids' ) );
						if ( is_wp_error( $current ) ) {
							continue;
						}
						// Replace broken id with target id.
						$new = array();
						foreach ( $current as $cid ) {
							if ( (int) $cid === (int) $term_b->term_id ) {
								$new[] = $target_id;
							} else {
								$new[] = (int) $cid;
							}
						}
						$new = array_unique( array_map( 'intval', $new ) );
						wp_set_object_terms( (int) $post_id, $new, Taxonomies::LOCALITY, false );
					}
					$details[] = "Reassigned " . count( $posts_a ) . " posts from '{$pair_b}' to '{$correct}'";
				}
				// Delete broken second term.
				$del = wp_delete_term( (int) $term_b->term_id, Taxonomies::LOCALITY );
				if ( ! is_wp_error( $del ) ) {
					$merged++;
					$details[] = "Deleted broken term '{$pair_b}' (ID {$term_b->term_id}) after merge";
				} else {
					$details[] = "Failed to delete {$pair_b}: " . $del->get_error_message();
				}
			}
		}

		// Generic fix: any locality with unbalanced brackets — try to auto-fix or report.
		// We do not auto-delete, only report and attempt safe rename if obvious.
		foreach ( $terms as $t ) {
			$name = $t->name;
			// Skip already handled.
			if ( $name === $pair_a || $name === $pair_b || $name === $correct ) {
				continue;
			}
			$open = substr_count( $name, '(' );
			$close = substr_count( $name, ')' );
			if ( $open !== $close ) {
				// Check if it ends with ) but no ( , or starts with ( but no )
				// For safety, we only fix if it matches pattern like "Something (" or "Something )"
				// Here we just log for admin to review, but also attempt to balance by removing stray bracket if it's at end/start.
				$fixed_name = $name;
				// If name ends with ")" and open < close, maybe it's the second part of a comma split — try to find partner?
				// For now, we flag.
				$details[] = "Unbalanced brackets found: '{$name}' (ID {$t->term_id}) open={$open} close={$close} — please review manually. Auto-fix not applied for safety.";
			}
		}

		return array( 'fixed' => $fixed, 'merged' => $merged, 'details' => $details );
	}

	/**
	 * Draft the 13 helper pages that were auto-published in 3.0.6.
	 * IDs from sitemap: 8193-8205 inclusive, plus any page with slug matching helper list that is published.
	 *
	 * @return array<string,mixed>
	 */
	private static function repair_pages(): array {
		$drafted = 0;
		$details = array();

		// Exact IDs from audit.
		$target_ids = range( 8193, 8205 );

		// Also include slugs that are known helper pages.
		$helper_slugs = array(
			'search', 'projects', 'team', 'localities', 'amenities',
			'favorites', 'compare', 'emi', 'alerts', 'office',
			'properties', 'insights', 'agents',
		);

		// First, handle exact IDs.
		foreach ( $target_ids as $pid ) {
			$post = get_post( $pid );
			if ( ! $post ) {
				continue;
			}
			if ( 'page' !== $post->post_type ) {
				continue;
			}
			if ( 'publish' === $post->post_status ) {
				$res = wp_update_post( array( 'ID' => $pid, 'post_status' => 'draft' ), true );
				if ( ! is_wp_error( $res ) ) {
					$drafted++;
					$details[] = "Drafted page ID {$pid} '{$post->post_title}' (slug {$post->post_name}) — was published";
				} else {
					$details[] = "Failed to draft ID {$pid}: " . $res->get_error_message();
				}
			} else {
				$details[] = "Page ID {$pid} '{$post->post_title}' already {$post->post_status}, no action";
			}
		}

		// Second, find any published pages with helper slugs that are not in above range (safety).
		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'numberposts'    => 100,
			'post_name__in'  => $helper_slugs,
		) );

		foreach ( $pages as $p ) {
			// Skip if already handled.
			if ( in_array( (int) $p->ID, $target_ids, true ) ) {
				continue;
			}
			// Only draft if it looks like auto-generated helper (contains estat shortcode or is in our list)
			$content = (string) $p->post_content;
			if ( false !== strpos( $content, '[estat_' ) || in_array( $p->post_name, $helper_slugs, true ) ) {
				// Check if it was created by plugin: look for our marker or recent.
				// For safety, only draft if title matches helper pattern or content has estat shortcode.
				if ( false !== strpos( $content, '[estat_' ) ) {
					$res = wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ), true );
					if ( ! is_wp_error( $res ) ) {
						$drafted++;
						$details[] = "Drafted helper page by slug '{$p->post_name}' ID {$p->ID} '{$p->post_title}'";
					}
				}
			}
		}

		if ( 0 === $drafted ) {
			$details[] = 'No published helper pages needed drafting (already draft or not found)';
		}

		return array( 'drafted' => $drafted, 'details' => $details );
	}
}
