<?php
/**
 * Lead timeline events — F1.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Leads;

use EstatOS\Install\Schema;
use EstatOS\Support\Sanitize;

defined( 'ABSPATH' ) || exit;

/**
 * Every change to a lead is an event, so nothing is lost.
 */
final class LeadEvents {

	/**
	 * Create an event.
	 *
	 * @param int    $lead_id  Lead ID.
	 * @param string $type     Event type.
	 * @param array  $payload  Payload data.
	 * @param int    $actor_id Actor user ID, 0 for system/visitor.
	 * @return int Event ID.
	 */
	public static function add( int $lead_id, string $type, array $payload = array(), int $actor_id = 0 ): int {
		global $wpdb;
		if ( ! Schema::healthy() || $lead_id <= 0 ) {
			return 0;
		}
		$table = Schema::table( 'estat_lead_events' );
		$now = current_time( 'mysql', true );
		if ( 0 === $actor_id && is_user_logged_in() ) {
			$actor_id = (int) get_current_user_id();
		}
		$row = array(
			'lead_id'    => $lead_id,
			'created_at' => $now,
			'actor_id'   => $actor_id,
			'type'       => Sanitize::choice( $type, array( 'created', 'status', 'note', 'call', 'visit_booked', 'visit_done', 'assigned', 'email_sent', 'merged' ), 'created' ),
			'payload'    => wp_json_encode( $payload ),
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert( $table, $row );
		return (int) $wpdb->insert_id;
	}

	/**
	 * List events for a lead.
	 *
	 * @param int $lead_id Lead ID.
	 * @return array<int,array<string,mixed>>
	 */
	public static function for_lead( int $lead_id ): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array();
		}
		$table = Schema::table( 'estat_lead_events' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE lead_id = %d ORDER BY id ASC", $lead_id ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Count events for badge "2 enquiries".
	 *
	 * @param int $lead_id Lead ID.
	 * @return int
	 */
	public static function count( int $lead_id ): int {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return 0;
		}
		$table = Schema::table( 'estat_lead_events' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE lead_id = %d", $lead_id ) );
	}
}
