<?php
/**
 * Global helpers for templates — backwards compatible.
 *
 * @package EstatOS
 */

use EstatOS\Support\Format;

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'MINUTE_IN_SECONDS' ) ) {
	define( 'MINUTE_IN_SECONDS', 60 );
}
if ( ! defined( 'HOUR_IN_SECONDS' ) ) {
	define( 'HOUR_IN_SECONDS', 3600 );
}
if ( ! defined( 'DAY_IN_SECONDS' ) ) {
	define( 'DAY_IN_SECONDS', 86400 );
}
if ( ! defined( 'WEEK_IN_SECONDS' ) ) {
	define( 'WEEK_IN_SECONDS', 604800 );
}
if ( ! defined( 'MONTH_IN_SECONDS' ) ) {
	define( 'MONTH_IN_SECONDS', 2592000 );
}
if ( ! defined( 'YEAR_IN_SECONDS' ) ) {
	define( 'YEAR_IN_SECONDS', 31536000 );
}


if ( ! function_exists( 'mb_substr' ) ) {
	function mb_substr( $str, $start, $length = null, $encoding = null ) {
		return null === $length ? substr( $str, $start ) : substr( $str, $start, $length );
	}
}
if ( ! function_exists( 'mb_strlen' ) ) {
	function mb_strlen( $str, $encoding = null ) {
		return strlen( $str );
	}
}
if ( ! function_exists( 'mb_strpos' ) ) {
	function mb_strpos( $haystack, $needle, $offset = 0, $encoding = null ) {
		return strpos( $haystack, $needle, $offset );
	}
}
if ( ! function_exists( 'mb_strtoupper' ) ) {
	function mb_strtoupper( $str, $encoding = null ) {
		return strtoupper( $str );
	}
}
if ( ! function_exists( 'mb_strtolower' ) ) {
	function mb_strtolower( $str, $encoding = null ) {
		return strtolower( $str );
	}
}


if ( ! function_exists( 'wp_generate_uuid4' ) ) {
	function wp_generate_uuid4() {
		return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0x0fff ) | 0x4000, mt_rand( 0, 0x3fff ) | 0x8000, mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ) );
	}
}

if ( ! function_exists( 'estat_format_price' ) ) {
	/**
	 * F0 display helper used everywhere: card, single, REST, emails, share text.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string Formatted price range.
	 */
	function estat_format_price( int $listing_id ): string {
		$min = get_post_meta( $listing_id, '_estat_price_min', true );
		$max = get_post_meta( $listing_id, '_estat_price_max', true );
		$offer = (string) get_post_meta( $listing_id, '_estat_offer', true );
		$price_type = (string) get_post_meta( $listing_id, '_estat_price_type', true );
		$on_request = 'on_request' === $price_type;

		// Legacy fallback: _estat_price and _estat_rent.
		if ( '' === $min && '' === $max ) {
			$legacy_price = get_post_meta( $listing_id, '_estat_price', true );
			$legacy_rent  = get_post_meta( $listing_id, '_estat_rent', true );
			if ( '' !== $legacy_rent && in_array( $offer, array( 'rent', 'lease' ), true ) ) {
				$min = $legacy_rent;
				$max = $legacy_rent;
			} elseif ( '' !== $legacy_price ) {
				$min = $legacy_price;
				$max = $legacy_price;
			}
		}

		$min_f = '' !== $min ? (float) $min : 0;
		$max_f = '' !== $max ? (float) $max : 0;

		return Format::price_range( $min_f, $max_f, $offer ?: 'sale', $on_request );
	}
}

if ( ! function_exists( 'estat_price_min' ) ) {
	/**
	 * Get min price raw.
	 *
	 * @param int $listing_id Listing ID.
	 * @return float
	 */
	function estat_price_min( int $listing_id ): float {
		$min = get_post_meta( $listing_id, '_estat_price_min', true );
		if ( '' !== $min ) {
			return (float) $min;
		}
		$legacy = get_post_meta( $listing_id, '_estat_price', true );
		if ( '' !== $legacy ) {
			return (float) $legacy;
		}
		$rent = get_post_meta( $listing_id, '_estat_rent', true );
		return (float) $rent;
	}
}

if ( ! function_exists( 'estat_price_max' ) ) {
	/**
	 * Get max price raw.
	 *
	 * @param int $listing_id Listing ID.
	 * @return float
	 */
	function estat_price_max( int $listing_id ): float {
		$max = get_post_meta( $listing_id, '_estat_price_max', true );
		if ( '' !== $max ) {
			return (float) $max;
		}
		$legacy = get_post_meta( $listing_id, '_estat_price', true );
		if ( '' !== $legacy ) {
			return (float) $legacy;
		}
		$rent = get_post_meta( $listing_id, '_estat_rent', true );
		return (float) $rent;
	}
}
