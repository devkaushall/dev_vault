<?php
/**
 * The dashboard's screens: Today and Approvals.
 *
 * These print a standalone document — head, links, body — the same way the
 * pocket does, because the whole page is ours: no theme footer, no admin
 * bar. What changes with size is only behaviour: sidebar on a laptop, icon
 * strip on a tablet, bottom tabs on a phone; the CSS in dashboard.css owns
 * that, at WordPress's own two breakpoints.
 *
 * Every number on screen is fetched live from the managers the rest of the
 * plugin uses. Nothing here decides anything: it shows the queue, and the
 * two buttons forward to Requests::approve()/decline() through
 * Dashboard::post().
 *
 * @package EstatOS
 */

namespace EstatOS\Office;

use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Pocket\Pocket;
use EstatOS\Support\Format;
use EstatOS\Support\Icon;

defined( 'ABSPATH' ) || exit;

/**
 * Rendering.
 */
class Screens {

	/**
	 * The one entry point.
	 *
	 * @param string $view View slug ('' is Today).
	 * @param int    $id   Unused here, kept so the signature matches the pocket.
	 * @return void
	 */
	public static function render( string $view, int $id = 0 ): void {
		$gate = Dashboard::gate();
		if ( '' !== $gate ) {
			// 'login' should never reach a render — handle() redirects first.
			// Reaching here means someone bypassed the router; refuse loudly.
			echo self::shell( __( 'Dashboard', 'estat-os' ), '', self::door( $gate ) );
			return;
		}

		if ( 'requests' === $view ) {
			echo self::shell( __( 'Approvals', 'estat-os' ), 'requests', self::requests() );
			return;
		}
		if ( 'listings' === $view ) {
			echo self::shell( __( 'Listings', 'estat-os' ), 'listings', self::listings() );
			return;
		}
		echo self::shell( __( 'Today', 'estat-os' ), '', self::today() );
	}

	/* ---------------------------------------------------------------------
	 * The shell.
	 * ------------------------------------------------------------------ */

	/**
	 * Head, body open, nav, content, tabs, closing tags.
	 *
	 * The stylesheet links are written straight into the head on purpose:
	 * template_redirect exits long before wp_enqueue_scripts gets a turn,
	 * and live sites learned that the hard way with the pocket. The version
	 * rides each file's own mtime, so a phone or a laptop never sees a stale
	 * sheet after an update. tokens.css comes first: it is the one place a
	 * colour is defined, and the office, the phone and this dashboard all
	 * read that same file.
	 *
	 * @param string $title  Document title.
	 * @param string $active Active view slug.
	 * @param string $body   Pre-rendered main column.
	 * @return string
	 */
	private static function shell( string $title, string $active, string $body ): string {
		$out  = '<!DOCTYPE html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="utf-8">';
		$out .= '<meta name="viewport" content="width=device-width, initial-scale=1">';
		$out .= '<title>' . esc_html( $title ) . ' · ' . esc_html( get_bloginfo( 'name' ) ) . '</title>';
		foreach ( array( 'tokens.css', 'dashboard.css' ) as $sheet ) {
			$ver = file_exists( ESTAT_DIR . 'assets/css/' . $sheet )
				? (string) filemtime( ESTAT_DIR . 'assets/css/' . $sheet )
				: ESTAT_VERSION;
			$out .= '<link rel="stylesheet" href="' . esc_url( ESTAT_URL . 'assets/css/' . $sheet . '?ver=' . $ver ) . '">';
		}
		$out .= '</head><body class="estat-dash">';

		// A synchronous line before anything paints: the theme choice lives
		// in this browser's localStorage, so the class is applied from there,
		// defaulting to 'auto' — the device's own light or dark. No cookie,
		// no server round-trip, and the phone picks the same answer for free
		// (its CSS follows the system by design).
		$out .= '<script>document.body.className="estat-dash estat-theme-"+(function(){try{return localStorage.getItem("estat-dash-theme")||"auto"}catch(e){return "auto"}})();</script>';

		$user = wp_get_current_user();
		$name = $user && '' !== $user->display_name ? $user->display_name : __( 'There', 'estat-os' );

		$out .= '<header class="dash-top"><a class="dash-brand" href="' . esc_url( Dashboard::url() ) . '">' .
			'<span class="dash-mark">' . Icon::render( 'office', 16, 'dash-ico' ) . '</span>' .
			'<span class="dash-bname"><b>' . esc_html( get_bloginfo( 'name' ) ) . '</b><i>' . esc_html__( 'Office dashboard', 'estat-os' ) . '</i></span></a>' .
			'<span class="dash-spacer"></span>' .
			self::theme_switch() .
			'<a class="dash-avatar" href="' . esc_url( self::admin_url() ) . '" title="' . esc_attr__( 'Open wp-admin', 'estat-os' ) . '">' .
			esc_html( self::initials( $name ) ) . '</a></header>';

		$out .= '<div class="dash-grid"><aside class="dash-side"><nav class="dnav">' .
			self::nav_item( '', 'home', __( 'Today', 'estat-os' ), $active, 0 ) .
			self::nav_item( 'listings', 'list-checks', __( 'Listings', 'estat-os' ), $active, 0 ) .
			self::nav_item( 'requests', 'check-circle', __( 'Approvals', 'estat-os' ), $active, self::pending_badge() ) .
			'</nav><div class="dside-foot"><b>' . esc_html( $name ) . '</b><i>' .
			esc_html__( 'Signed in — same account as wp-admin and the phone', 'estat-os' ) .
			'</i></div></aside>';

		$out .= '<main class="dash-main">';
		$flash = Dashboard::flash();
		if ( '' !== $flash ) {
			$out .= '<p class="dnotice">' . esc_html( $flash ) . '</p>';
		}
		$out .= $body;
		$out .= '</main></div>';

		$out .= '<nav class="dash-tabs">' .
			self::nav_item( '', 'home', __( 'Today', 'estat-os' ), $active, 0 ) .
			self::nav_item( 'listings', 'list-checks', __( 'Listings', 'estat-os' ), $active, 0 ) .
			self::nav_item( 'requests', 'check-circle', __( 'Approvals', 'estat-os' ), $active, self::pending_badge() ) .
			'</nav>';

		$out .= self::theme_script();
		$out .= '</body></html>';
		return $out;
	}

	/**
	 * One nav link, shared by the sidebar and the phone tabs.
	 *
	 * @param string $slug   View slug.
	 * @param string $icon   Icon name.
	 * @param string $label  Words.
	 * @param string $active Current view.
	 * @param int    $badge  Pending count, 0 hides the pill.
	 * @return string
	 */
	private static function nav_item( string $slug, string $icon, string $label, string $active, int $badge ): string {
		$on   = $slug === $active ? ' class="on"' : '';
		$pill = $badge > 0 ? '<span class="dbadge">' . ( $badge > 99 ? '99+' : $badge ) . '</span>' : '';
		return '<a' . $on . ' href="' . esc_url( Dashboard::url( $slug ) ) . '">' .
			Icon::render( $icon, 18, 'dash-ico' ) . '<span class="dlbl">' . esc_html( $label ) . '</span>' . $pill . '</a>';
	}

	/**
	 * The three-way theme choice. Buttons, not a menu: one press, no
	 * dropdown to miss. The script under shell() carries it to localStorage.
	 *
	 * @return string
	 */
	private static function theme_switch(): string {
		return '<span class="dtheme" role="group" aria-label="' . esc_attr__( 'Appearance', 'estat-os' ) . '">' .
			'<button type="button" data-theme="light">' . esc_html__( 'Light', 'estat-os' ) . '</button>' .
			'<button type="button" data-theme="dark">' . esc_html__( 'Dark', 'estat-os' ) . '</button>' .
			'<button type="button" data-theme="auto">' . esc_html__( 'Auto', 'estat-os' ) . '</button></span>';
	}

	/**
	 * Mark the chosen button and save future clicks. Five lines, no
	 * framework: the class goes on the body, the value into localStorage.
	 *
	 * @return string
	 */
	private static function theme_script(): string {
		return '<script>(function(){function k(){var m;try{m=localStorage.getItem("estat-dash-theme")||"auto"}catch(e){m="auto"}' .
			'document.body.className="estat-dash estat-theme-"+m;' .
			'var b=document.querySelectorAll(".dtheme button");for(var i=0;i<b.length;i++){b[i].className=b[i].getAttribute("data-theme")===m?"on":""}}' .
			'document.addEventListener("click",function(ev){var t=ev.target;while(t&&t!==document&&t.tagName!=="BUTTON"){t=t.parentNode}' .
			'if(t&&t.tagName==="BUTTON"&&t.hasAttribute("data-theme")){try{localStorage.setItem("estat-dash-theme",t.getAttribute("data-theme"))}catch(e){}k()}});k()})();</script>';
	}

	/* ---------------------------------------------------------------------
	 * Today.
	 * ------------------------------------------------------------------ */

	/**
	 * The work queue, in one honest list. Rows, not cards with big numbers:
	 * an office person scans "what needs me", not dashboards.
	 *
	 * @return string
	 */
	private static function today(): string {
		$user  = wp_get_current_user();
		$name  = $user && '' !== $user->display_name ? explode( ' ', $user->display_name )[0] : __( 'there', 'estat-os' );
		$hour  = (int) current_time( 'G' );
		$hello = $hour < 12 ? __( 'Good morning', 'estat-os' ) : ( $hour < 17 ? __( 'Good afternoon', 'estat-os' ) : __( 'Good evening', 'estat-os' ) );

		$out = '<h1 class="dash-h1">' . esc_html( $hello ) . ', ' . esc_html( $name ) . '</h1>';
		$out .= '<p class="dash-sub">' . esc_html( Format::date( (string) current_time( 'mysql' ) ) ) . ' · ' . esc_html__( 'what is waiting for the office', 'estat-os' ) . '</p>';
		$out .= '<h2 class="dash-h2">' . esc_html__( 'Needs you', 'estat-os' ) . '</h2>';

		$rows   = array();
		$wait   = Requests::pending_count();
		$rows[] = array(
			'warn', 'check-circle',
			$wait > 0
				? /* translators: %d: count. */ sprintf( _n( '%d change request waiting', '%d change requests waiting', $wait, 'estat-os' ), $wait )
				: __( 'No change is waiting. The approvals queue is empty.', 'estat-os' ),
			$wait > 0 ? __( 'Prices, photos, corrections from the agents', 'estat-os' ) : '',
			Dashboard::url( 'requests' ),
		);

		$leads = Leads::counts();
		$rows[] = array(
			'plain', 'inbox',
			$leads['new'] > 0
				? /* translators: %d: count. */ sprintf( _n( '%d enquiry to answer', '%d enquiries to answer', $leads['new'], 'estat-os' ), $leads['new'] )
				: __( 'No enquiry is sitting unanswered', 'estat-os' ),
			$leads['due'] > 0
				? /* translators: %d: count. */ sprintf( _n( '%d follow-up due', '%d follow-ups due', $leads['due'], 'estat-os' ), $leads['due'] )
				: '',
			self::admin_url( 'admin.php?page=estat-leads' ),
		);

		$visits = Visits::counts();
		$rows[] = array(
			'plain', 'calendar',
			$visits['today'] > 0
				? /* translators: %d: count. */ sprintf( _n( '%d site visit today', '%d site visits today', $visits['today'], 'estat-os' ), $visits['today'] )
				: ( $visits['upcoming'] > 0
					? /* translators: %d: count. */ sprintf( _n( '%d visit scheduled ahead', '%d visits scheduled ahead', $visits['upcoming'], 'estat-os' ), $visits['upcoming'] )
					: __( 'Nothing on the visit calendar', 'estat-os' ) ),
			$visits['pending'] > $visits['today'] ? __( 'Reminders go out a day before', 'estat-os' ) : '',
			self::admin_url( 'admin.php?page=estat-visits' ),
		);

		$held = 0;
		if ( function_exists( 'wp_count_posts' ) ) {
			$pending = wp_count_posts( PostTypes::LISTING );
			$held    = isset( $pending->pending ) ? (int) $pending->pending : 0;
		} else {
			$held = (new \WP_Query( array( 'post_type' => PostTypes::LISTING, 'post_status' => 'pending', 'posts_per_page' => 1, 'fields' => 'ids' ) ))->found_posts;
		}
		$rows[] = array(
			'good', 'upload',
			$held > 0
				? /* translators: %d: count. */ sprintf( _n( '%d listing sent for approval', '%d listings sent for approval', $held, 'estat-os' ), $held )
				: __( 'Nothing is waiting to go live', 'estat-os' ),
			$held > 0 ? __( 'You publish them — agents never do', 'estat-os' ) : '',
			Dashboard::url( 'listings' ) . '?f=waiting',
		);

		foreach ( $rows as $r ) {
			$tone  = 'plain' === $r[0] ? '' : ' ' . $r[0];
			$href  = $r[4];
			$inner = '<span class="dwell' . $tone . '">' . Icon::render( $r[1], 17, 'dash-ico' ) . '</span>' .
				'<span class="dmain"><b>' . esc_html( $r[2] ) . '</b>' .
				( '' !== $r[3] ? '<i>' . esc_html( $r[3] ) . '</i>' : '' ) . '</span>' .
				Icon::render( 'chevron-right', 15, 'dash-ico dim' );
			$out  .= '' !== $href
				? '<a class="drow" href="' . esc_url( $href ) . '">' . $inner . '</a>'
				: '<div class="drow quiet">' . $inner . '</div>';
		}

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Approvals.
	 * ------------------------------------------------------------------ */

	/**
	 * The pending change-request queue, with the old value struck through
	 * and the new one beside it — the same reading the phone gives, because
	 * it is the same data.
	 *
	 * @return string
	 */
	private static function requests(): string {
		$pending = Requests::query( array( 'status' => 'pending', 'per_page' => 30 ) );

		$out = '<h1 class="dash-h1">' . esc_html__( 'Approvals', 'estat-os' ) . '</h1>';
		$out .= '<p class="dash-sub">' . esc_html__( 'Agents suggest; the office decides. Nothing here happens by itself.', 'estat-os' ) . '</p>';
		$out .= '<h2 class="dash-h2">' . esc_html__( 'Change requests', 'estat-os' ) . ' <span class="dcount">' . (int) $pending['total'] . '</span></h2>';

		if ( ! $pending['items'] ) {
			$out .= '<p class="dash-hint">' . esc_html__( 'The queue is empty.', 'estat-os' ) . '</p>';
			return $out;
		}

		$defs = Requests::editable_fields();
		foreach ( $pending['items'] as $req ) {
			$rid = (int) $req['id'];
			$out .= '<div class="dcard">';
			$who  = get_userdata( (int) $req['requested_by'] );
			$out .= '<div class="dhead"><b>' . esc_html( '' !== $req['record_title'] ? $req['record_title'] : '#' . (int) $req['record_id'] ) . '</b>' .
				'<i>' . esc_html( ( $who ? $who->display_name : __( 'someone who left', 'estat-os' ) ) . ' · ' . Format::date( (string) $req['created_at'] ) ) . '</i></div>';

			if ( is_array( $req['changes'] ) && $req['changes'] ) {
				$out .= '<div class="ddiff">';
				foreach ( $req['changes'] as $key => $value ) {
					if ( 'note' === $key ) {
						continue;
					}
					$word = $defs[ $key ]['label'] ?? ucfirst( (string) $key );
					$now  = Requests::current_value( (int) $req['record_id'], (string) $key );
					$out .= '<div class="dkv"><i>' . esc_html( (string) $word ) . '</i><b>' .
						( '' !== $now ? '<s>' . esc_html( (string) $now ) . '</s> ' : '' ) .
						esc_html( Requests::describe( (string) $key, (string) $value ) ) . '</b></div>';
				}
				$out .= '</div>';
				if ( ! empty( $req['changes']['note'] ) ) {
					$out .= '<div class="dquote">' . esc_html( (string) $req['changes']['note'] ) . '</div>';
				}
			}

			$out .= '<div class="dacts">' .
				self::settle_form( $rid, 'request_approve', __( 'Yes, change it', 'estat-os' ), true ) .
				self::settle_form( $rid, 'request_decline', __( 'Not now', 'estat-os' ), false ) .
				'</div>';
			$out .= '</div>';
		}

		return $out;
	}

	/**
	 * One decision button. Decline also gets a small "why" field — the
	 * agent reads that line on their phone, so the office types it here.
	 *
	 * @param int    $rid    Request ID.
	 * @param string $action Action key.
	 * @param string $label  Button words.
	 * @param bool   $go     Primary styling.
	 * @return string
	 */
	private static function settle_form( int $rid, string $action, string $label, bool $go ): string {
		$form = '<form method="post" action="' . esc_url( Dashboard::url( 'requests' ) ) . '" class="dform">';
		$form .= '<input type="hidden" name="_estat_office" value="' . esc_attr( wp_create_nonce( Dashboard::NONCE ) ) . '">';
		$form .= '<input type="hidden" name="estat_office_action" value="' . esc_attr( $action ) . '">';
		$form .= '<input type="hidden" name="request_id" value="' . (int) $rid . '">';
		if ( ! $go ) {
			$form .= '<input class="dinput" type="text" name="reason" maxlength="300" placeholder="' . esc_attr__( 'Why (the agent sees this)', 'estat-os' ) . '">';
		}
		$form .= '<button class="dbtn' . ( $go ? ' go' : '' ) . '" type="submit">' . esc_html( $label ) . '</button>';
		$form .= '</form>';
		return $form;
	}

	/* ---------------------------------------------------------------------
	 * Listings.
	 * ------------------------------------------------------------------ */

	/**
	 * The whole inventory in one table, newest touched first. Filters are
	 * the four states that exist. The screen itself decides nothing beyond
	 * the two office moves below; editing lives in wp-admin, right where
	 * the photos and the map are.
	 *
	 * @return string
	 */
	private static function listings(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$f = isset( $_GET['f'] ) ? sanitize_key( wp_unslash( (string) $_GET['f'] ) ) : 'live';
		$filters = array(
			'live'    => array( __( 'Live', 'estat-os' ), 'publish' ),
			'waiting' => array( __( 'Waiting for office', 'estat-os' ), 'pending' ),
			'draft'   => array( __( 'Drafts', 'estat-os' ), 'draft' ),
			'paused'  => array( __( 'Paused', 'estat-os' ), 'private' ),
			'all'     => array( __( 'All', 'estat-os' ), array( 'publish', 'pending', 'draft', 'private' ) ),
		);
		if ( ! isset( $filters[ $f ] ) ) {
			$f = 'live';
		}

		$out = '<div class="dpagehead"><div><h1 class="dash-h1">' . esc_html__( 'Listings', 'estat-os' ) . '</h1>' .
			'<p class="dash-sub">' . esc_html__( 'Newest touched first. Editing opens wp-admin; the row buttons are the only decisions this screen makes.', 'estat-os' ) . '</p></div>' .
			'<a class="dbtn go slim" href="' . esc_url( self::admin_url( 'post-new.php?post_type=' . PostTypes::LISTING ) ) . '">' .
			Icon::render( 'upload', 14, 'dash-ico' ) . esc_html__( 'Add a listing', 'estat-os' ) . '</a></div>';

		$out .= '<div class="dfilters">';
		foreach ( $filters as $key => $filter ) {
			$count = self::count_for( $filter[1] );
			$out  .= '<a' . ( $key === $f ? ' class="on"' : '' ) . ' href="' . esc_url( Dashboard::url( 'listings' ) . ( 'live' === $key ? '' : '?f=' . $key ) ) . '">' .
				esc_html( $filter[0] ) . ' <b>' . (int) $count . '</b></a>';
		}
		$out .= '</div>';

		$query = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => $filters[ $f ][1],
				'posts_per_page' => 40,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		if ( ! $query->posts ) {
			$out .= '<p class="dash-hint">' . esc_html__( 'Nothing sits in this state right now.', 'estat-os' ) . '</p>';
			return $out;
		}

		$out .= '<div class="dtbl-wrap"><table class="dtbl"><thead><tr>' .
			'<th>' . esc_html__( 'Property', 'estat-os' ) . '</th>' .
			'<th class="dnum">' . esc_html__( 'Price', 'estat-os' ) . '</th>' .
			'<th>' . esc_html__( 'Status', 'estat-os' ) . '</th>' .
			'<th class="dact">' . esc_html__( 'Action', 'estat-os' ) . '</th></tr></thead><tbody>';

		foreach ( $query->posts as $post ) {
			$pid   = (int) $post->ID;
			$state = self::state_of( (string) $post->post_status );

			$price = trim( (string) get_post_meta( $pid, '_estat_price', true ) );
			$rent  = trim( (string) get_post_meta( $pid, '_estat_rent', true ) );
			$offer = (string) get_post_meta( $pid, '_estat_offer', true );
			$shown = '' !== $rent && ( '' === $price || 'rent' === $offer || 'lease' === $offer ) ? $rent : $price;
			$money = '' !== $shown ? Format::money( (float) $shown ) : '';

			$acts = '<a class="dmini" href="' . esc_url( self::admin_url( 'post.php?post=' . $pid . '&action=edit' ) ) . '">' . esc_html__( 'Edit', 'estat-os' ) . '</a>';
			if ( 'pending' === $post->post_status ) {
				$acts = self::move_form( $pid, 'listing_publish', __( 'Put it live', 'estat-os' ) ) .
					self::move_form( $pid, 'listing_return', __( 'Send back', 'estat-os' ) ) . $acts;
			} elseif ( 'publish' === $post->post_status ) {
				$acts = self::move_form( $pid, 'listing_pause', __( 'Pause', 'estat-os' ) ) . $acts;
			} elseif ( 'private' === $post->post_status ) {
				$acts = self::move_form( $pid, 'listing_resume', __( 'Make live', 'estat-os' ) ) . $acts;
			}

			$mod   = (string) $post->post_modified;
			$when  = strlen( $mod ) >= 4 && (int) substr( $mod, 0, 4 ) > 1970 ? Format::date( $mod ) : '';
			$out .= '<tr><td class="dtitle"><a href="' . esc_url( self::admin_url( 'post.php?post=' . $pid . '&action=edit' ) ) . '"><b>' . esc_html( get_the_title( $post ) ) . '</b></a>' .
				( '' !== $when ? '<i>' . esc_html( $when ) . '</i>' : '' ) . '</td>' .
				'<td class="dnum">' . ( '' !== $money ? esc_html( $money ) : '<span class="dnone">—</span>' ) . '</td>' .
				'<td><span class="dpill ' . esc_attr( $state[1] ) . '">' . esc_html( $state[0] ) . '</span></td>' .
				'<td class="dact">' . $acts . '</td></tr>';
		}
		$out .= '</tbody></table></div>';

		$total = (int) $query->found_posts;
		if ( $total > 40 ) {
			$out .= '<p class="dash-hint">' . /* translators: %d: total. */ esc_html( sprintf( __( 'Showing the 40 most recent of %d — wp-admin holds the rest.', 'estat-os' ), $total ) ) . '</p>';
		}

		return $out;
	}

	/**
	 * A quick move button on a row: the same door as everything else here —
	 * nonce in, capability checked server-side, wp_update_post plus one
	 * audit line doing the writing.
	 *
	 * @param int    $pid    Post ID.
	 * @param string $action Action key.
	 * @param string $label  Button words.
	 * @return string
	 */
	private static function move_form( int $pid, string $action, string $label ): string {
		return '<form method="post" action="' . esc_url( Dashboard::url( 'listings' ) ) . '" class="dform inline">' .
			'<input type="hidden" name="_estat_office" value="' . esc_attr( wp_create_nonce( Dashboard::NONCE ) ) . '">' .
			'<input type="hidden" name="estat_office_action" value="' . esc_attr( $action ) . '">' .
			'<input type="hidden" name="record_id" value="' . (int) $pid . '">' .
			'<button class="dmini go-btn" type="submit">' . esc_html( $label ) . '</button></form>';
	}

	/**
	 * How many change requests wait — asked once per page. The sidebar and
	 * the phone tabs show the same badge; two identical queries would just
	 * be politeness to nobody.
	 *
	 * @return int
	 */
	private static function pending_badge(): int {
		static $n = null;
		if ( null === $n ) {
			$n = Requests::pending_count();
		}
		return $n;
	}

	/**
	 * Count for one filter, through whichever tool WordPress offers. The
	 * five filter pills share one wp_count_posts per page for the same
	 * reason: five full-table counts for one table is four too many.
	 *
	 * @param string|string[] $status Post status or list.
	 * @return int
	 */
	private static function count_for( $status ): int {
		static $memo = array();
		$statuses = (array) $status;
		$key      = implode( ',', $statuses );
		if ( isset( $memo[ $key ] ) ) {
			return $memo[ $key ];
		}
		if ( function_exists( 'wp_count_posts' ) ) {
			$counts = wp_count_posts( PostTypes::LISTING );
			$n      = 0;
			foreach ( $statuses as $st ) {
				$n += isset( $counts->$st ) ? (int) $counts->$st : 0;
			}
			$memo[ $key ] = $n;
			return $n;
		}
		$q = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => $status,
				'posts_per_page' => 1,
			)
		);
		$memo[ $key ] = (int) $q->found_posts;
		return $memo[ $key ];
	}

	/**
	 * The four states in office words — same meanings the phone uses.
	 *
	 * @param string $post_status Raw status.
	 * @return array{0:string,1:string} [label, pill class]
	 */
	private static function state_of( string $post_status ): array {
		switch ( $post_status ) {
			case 'publish':
				return array( __( 'Live', 'estat-os' ), 'good' );
			case 'pending':
				return array( __( 'Waiting for office', 'estat-os' ), 'accent' );
			case 'private':
				return array( __( 'Paused', 'estat-os' ), 'warn' );
			default:
				return array( __( 'Draft', 'estat-os' ), 'plain' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Small shared pieces.
	 * ------------------------------------------------------------------ */

	/**
	 * The refusal page for a logged-in person who is not office: agents
	 * belong at the pocket, and this says so kindly, with a way there.
	 *
	 * @param string $reason Gate reason.
	 * @return string
	 */
	private static function door( string $reason ): string {
		if ( 'login' === $reason ) {
			return '<div class="dcard"><h1 class="dash-h1">' . esc_html__( 'Sign in to open the office', 'estat-os' ) . '</h1>' .
				'<p class="dash-sub">' . esc_html__( 'It is your WordPress account — the same one as wp-admin and the phone.', 'estat-os' ) . '</p>' .
				'<p><a class="dbtn go" href="' . esc_url( wp_login_url( Dashboard::url() ) ) . '">' . esc_html__( 'Sign in', 'estat-os' ) . '</a></p></div>';
		}
		return '<div class="dcard"><h1 class="dash-h1">' . esc_html__( 'This is the office side', 'estat-os' ) . '</h1>' .
			'<p class="dash-sub">' . esc_html__( 'Your desk is the pocket — listings, enquiries and sending changes for approval all live there.', 'estat-os' ) . '</p>' .
			'<p><a class="dbtn go" href="' . esc_url( Pocket::url() ) . '">' . esc_html__( 'Open my pocket', 'estat-os' ) . '</a></p></div>';
	}

	/**
	 * wp-admin on this site, for the links that stay there (yet).
	 *
	 * @param string $query Optional admin query.
	 * @return string
	 */
	private static function admin_url( string $query = '' ): string {
		return admin_url( '' !== $query ? $query : '' );
	}

	/**
	 * Two letters for the avatar.
	 *
	 * @param string $name Display name.
	 * @return string
	 */
	private static function initials( string $name ): string {
		$parts = preg_split( '/\s+/', trim( $name ) ) ?: array();
		$i     = '';
		foreach ( array_slice( $parts, 0, 2 ) as $p ) {
			$i .= mb_strtoupper( mb_substr( $p, 0, 1 ) );
		}
		return '' !== $i ? $i : '?';
	}
}
