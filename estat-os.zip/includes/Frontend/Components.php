<?php
/**
 * Reusable public HTML components shared by shortcodes and Elementor widgets.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Agents;
use EstatOS\Data\Highlights;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Data\Taxonomies;
use EstatOS\Forms\Forms;
use EstatOS\Forms\Renderer;
use EstatOS\Search\Query;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;
use EstatOS\Support\Icon;

defined( 'ABSPATH' ) || exit;

/**
 * One implementation of every visible component. Elementor widgets and
 * shortcodes both call these, so the two can never drift apart.
 */
final class Components {

	/**
	 * A property card.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function card( int $listing_id ): string {
		$data = Listings::to_array( $listing_id, false );
		if ( ! $data ) {
			return '';
		}
		if ( 'publish' !== (string) $data['status'] && ! current_user_can( 'estat_manage_listings' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$locality = ! empty( $data['locality'] ) ? (string) $data['locality'][0] : '';
		$beds     = (int) $data['bedrooms'];
		$baths    = (int) $data['bathrooms'];
		$area_sqft = (float) ( $data['area_sqft'] ?? $data['area'] ?? 0 );
		$ptype    = (string) $data['property_type'];

		// Build facts: "4 BHK · 4 bath · 2,555 sq ft · Flat"
		$facts = array();
		if ( $beds > 0 ) {
			$facts[] = sprintf( _n( '%d BHK', '%d BHK', $beds, 'estat-os' ), $beds );
		}
		if ( $baths > 0 ) {
			$facts[] = sprintf( _n( '%d bath', '%d bath', $baths, 'estat-os' ), $baths );
		}
		if ( $area_sqft > 0 ) {
			$facts[] = sprintf( __( '%s sq ft', 'estat-os' ), number_format_i18n( (int) $area_sqft ) );
		} elseif ( (float) $data['area'] > 0 ) {
			$unit = $data['area_unit'] ?: 'sqft';
			$facts[] = sprintf( '%s %s', number_format_i18n( (float) $data['area'] ), $unit );
		}
		if ( '' !== $ptype ) {
			$facts[] = Vocabulary::label( 'property_types', $ptype );
		}
		$facts_str = implode( ' · ', $facts );

		// Price per month fix
		$price_display = (string) $data['price_display'];
		$offer = (string) $data['offer'];
		if ( in_array( $offer, array( 'rent', 'lease' ), true ) && '' !== $price_display && false === strpos( $price_display, 'per month' ) ) {
			$price_display .= ' ' . __( 'per month', 'estat-os' );
		}

		ob_start();
		?>
		<article class="estat-card" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>">
			<a class="estat-card-media" href="<?php echo esc_url( (string) $data['url'] ); ?>">
				<?php
				$cover_id = (int) get_post_thumbnail_id( $listing_id );
				if ( $cover_id > 0 ) {
					echo wp_get_attachment_image(
						$cover_id,
						'large',
						false,
						array(
							'alt' => esc_attr( (string) $data['title'] ),
							'loading' => 'lazy',
							'decoding' => 'async',
							'class' => 'estat-card-img',
							'sizes' => '(max-width: 600px) 100vw, 400px',
						)
					);
				} elseif ( '' !== (string) $data['cover'] ) {
					$card_w = (int) ( $data['cover_width'] ?? 0 );
					$card_h = (int) ( $data['cover_height'] ?? 0 );
					?>
					<img
						src="<?php echo esc_url( (string) $data['cover'] ); ?>"
						alt="<?php echo esc_attr( (string) $data['title'] ); ?>"
						<?php if ( $card_w > 0 && $card_h > 0 ) : ?>
							width="<?php echo esc_attr( (string) $card_w ); ?>"
							height="<?php echo esc_attr( (string) $card_h ); ?>"
						<?php endif; ?>
						loading="lazy"
						decoding="async"
						srcset="<?php echo esc_attr( (string) $data['cover'] ); ?> 400w"
						sizes="(max-width: 600px) 100vw, 400px"
					/>
				<?php } else { ?>
					<span class="estat-card-noimage" aria-hidden="true"></span>
				<?php } ?>
				<?php if ( ! empty( $data['featured'] ) ) : ?>
					<span class="estat-badge estat-badge-featured"><?php esc_html_e( 'Featured', 'estat-os' ); ?></span>
				<?php endif; ?>
				<span class="estat-badge estat-badge-offer"><?php echo esc_html( Vocabulary::label( 'offers', $offer ) ); ?></span>
				<?php if ( 'office_verified' === (string) $data['verification'] ) : ?>
					<span class="estat-badge estat-badge-verified" title="<?php esc_attr_e( 'Verified listing', 'estat-os' ); ?>">
						<?php echo Icon::render( 'verified', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Verified', 'estat-os' ); ?>
					</span>
				<?php endif; ?>
			</a>
			<div class="estat-card-body">
				<h3 class="estat-card-title"><a href="<?php echo esc_url( (string) $data['url'] ); ?>"><?php echo esc_html( (string) $data['title'] ); ?></a></h3>
				<?php if ( '' !== $locality ) : ?>
					<p class="estat-card-locality"><?php echo esc_html( $locality ); ?></p>
				<?php endif; ?>
				<p class="estat-card-price"><?php echo esc_html( $price_display ); ?></p>
				<?php
				$just_days = 7;
				$setting_days = (int) Settings::get( 'just_listed_days', 7 );
				if ( $setting_days > 0 && $setting_days < 7 ) { $just_days = $setting_days; }
				if ( $just_days > 7 ) { $just_days = 7; }
				if ( 'publish' === (string) $data['status'] && (int) ( $data['days_listed'] ?? 0 ) <= $just_days && (int) ( $data['days_listed'] ?? 0 ) >= 0 ) :
					?>
					<p class="estat-card-fresh"><?php esc_html_e( 'Just listed', 'estat-os' ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $facts_str ) : ?>
				<ul class="estat-card-facts"><li><?php echo esc_html( $facts_str ); ?></li></ul>
				<?php endif; ?>
				<?php
				$chips = Highlights::for_card( $listing_id );
				if ( $chips ) :
					?>
					<ul class="estat-chips">
						<?php foreach ( $chips as $chip ) : ?>
							<li class="estat-chip">
								<?php if ( '' !== (string) $chip['icon'] ) : ?>
									<span class="estat-chip-icon"><?php echo Icon::render( (string) $chip['icon'], 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php endif; ?>
								<span class="estat-chip-text"><?php echo esc_html( (string) $chip['label'] ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<div class="estat-card-actions">
					<?php if ( Settings::get( 'enable_favorites' ) ) : ?>
						<button type="button" class="estat-fav" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<span class="screen-reader-text"><?php esc_html_e( 'Save this property', 'estat-os' ); ?></span>
							<span class="estat-fav-icon"><?php echo Icon::render( 'heart', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						</button>
					<?php endif; ?>
					<?php if ( Settings::get( 'enable_compare' ) ) : ?>
						<button type="button" class="estat-compare" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<?php esc_html_e( 'Compare', 'estat-os' ); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>
		</article>
		<?php
		return (string) ob_get_clean();
	}


	/**
	 * A property directory with pagination — 3.0.7 fixed wrapper + H1 + count + sort.
	 *
	 * @param array<string,mixed> $args Search filters.
	 * @return string
	 */
	public static function directory( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		$results = Query::search( $args );

		if ( empty( $results['ids'] ) && ! self::has_filters( $args ) && 0 === self::published_count() ) {
			if ( ! current_user_can( 'estat_manage_listings' ) ) {
				return '';
			}
			return '<main class="estat-archive"><div class="estat-container"><p class="estat-empty">' . esc_html__( 'Nothing is live yet. Publish a listing and it appears in this directory.', 'estat-os' ) . '</p></div></main>';
		}

			$no_wrapper = isset( $args['wrapper'] ) && false === $args['wrapper'];
		ob_start();
		// Wrapper required by acceptance: main.estat-archive > div.estat-container
		//
		// The heading is an H2, not an H1. The widget is meant to be dropped
		// into somebody else's page, and a page has exactly one H1: the one
		// its own title prints. Two were being counted on Home and on the
		// agent pages because the theme printed an H1 and this widget printed
		// a second one; on the plugin's own generated pages the H1 now comes
		// from the page body itself. Either way, this one is a section
		// heading.
		if ( ! $no_wrapper ) {
			echo '<main class="estat-archive"><div class="estat-container">';
			// 4.2.1: the office can ask for a different level — [estat_properties
			// heading_tag="h1"] on a page the theme prints no title for — and a
			// theme may answer through the filter. h1–h4 only.
			$tag = strtolower( (string) ( $args['heading_tag'] ?? 'h2' ) );
			$tag = (string) apply_filters( 'estat_archive_heading_tag', $tag, $args );
			if ( ! in_array( $tag, array( 'h1', 'h2', 'h3', 'h4' ), true ) ) {
				$tag = 'h2';
			}
			$label = (string) apply_filters( 'estat_archive_heading_text', __( 'Properties', 'estat-os' ), $args );
			echo '<header class="estat-archive-header"><' . $tag . '>' . esc_html( $label ) . '</' . $tag . '></header>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// Result count + sort
		$total = (int) ( $results['total'] ?? count( $results['ids'] ) );
		if ( $total > 0 ) {
			echo '<div class="estat-directory-meta">';
			echo '<p class="estat-result-count">' . esc_html( sprintf( _n( '%d property', '%d properties', $total, 'estat-os' ), $total ) ) . '</p>';
			// Sort dropdown
			$current_order = $args['orderby'] ?? 'recent';
			echo '<form method="get" class="estat-sort"><label for="estat-orderby" class="estat-sr">' . esc_html__( 'Sort by', 'estat-os' ) . '</label><select id="estat-orderby" name="orderby" onchange="this.form.submit()">';
			$orders = array( 'recent' => __( 'Newest', 'estat-os' ), 'price_asc' => __( 'Price: low to high', 'estat-os' ), 'price_desc' => __( 'Price: high to low', 'estat-os' ), 'area_desc' => __( 'Area: large to small', 'estat-os' ) );
			foreach ( $orders as $val => $label ) {
				echo '<option value="' . esc_attr( $val ) . '" ' . selected( $current_order, $val, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select>';
			// Preserve current filters as hidden inputs
			foreach ( $_GET as $k => $v ) {
				if ( 'orderby' === $k || 'estat_page' === $k ) continue;
				$k = sanitize_key( $k );
				if ( is_array( $v ) ) {
					foreach ( $v as $vv ) {
						echo '<input type="hidden" name="' . esc_attr( $k ) . '[]" value="' . esc_attr( sanitize_text_field( $vv ) ) . '">';
					}
				} else {
					echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( sanitize_text_field( wp_unslash( $v ) ) ) . '">';
				}
			}
			echo '</form></div>';
		}

		echo '<div class="estat-directory">';
		if ( empty( $results['ids'] ) ) {
			echo '<p class="estat-empty">' . esc_html__( 'No properties match what you are looking for. Try widening your search.', 'estat-os' ) . '</p>';
		} else {
			/*
			 * A light filter over the properties already on the page. The
			 * counts are worked out here, from the cards that were actually
			 * drawn, so the row can never promise six available properties
			 * and then show two. A group with nothing in it is not offered,
			 * and without JavaScript every property simply stays visible.
			 */
			$cards  = array();
			$by_availability = array();
			$by_offer        = array();

			foreach ( $results['ids'] as $id ) {
				$card = self::card( (int) $id );
				if ( '' === $card ) {
					continue;
				}

				$availability = (string) get_post_meta( (int) $id, '_estat_availability', true );
				$offer        = (string) get_post_meta( (int) $id, '_estat_offer', true );
				$groups       = array( 'all' );

				if ( isset( self::availability_labels()[ $availability ] ) ) {
					$groups[] = $availability;
					$by_availability[ $availability ] = ( $by_availability[ $availability ] ?? 0 ) + 1;
				}
				if ( isset( self::offer_labels()[ $offer ] ) ) {
					$groups[] = 'offer:' . $offer;
					$by_offer[ $offer ] = ( $by_offer[ $offer ] ?? 0 ) + 1;
				}

				$cards[ (int) $id ] = array(
					'html'   => $card,
					'groups' => implode( ' ', $groups ),
				);
			}

			$total_cards = count( $cards );

			$buttons = array(
				array(
					'value' => 'all',
					'label' => __( 'All', 'estat-os' ),
					'count' => $total_cards,
				),
			);
			$labels = self::availability_labels();
			foreach ( $by_availability as $key => $count ) {
				$buttons[] = array(
					'value' => (string) $key,
					'label' => (string) $labels[ $key ],
					'count' => (int) $count,
				);
			}
			if ( count( $by_offer ) > 1 ) {
				$offer_labels = self::offer_labels();
				foreach ( $by_offer as $key => $count ) {
					$buttons[] = array(
						'value' => 'offer:' . $key,
						'label' => (string) $offer_labels[ $key ],
						'count' => (int) $count,
					);
				}
			}

			$scope = 'estat-directory-scope-' . md5( wp_json_encode( array_keys( $cards ) ) ?: '' );

			if ( $total_cards > 1 && count( $buttons ) > 1 ) {
				echo self::filter_bar( $buttons, $scope, __( 'Filter the properties', 'estat-os' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			echo '<div class="estat-grid"' . ( count( $buttons ) > 1 ? ' id="' . esc_attr( $scope ) . '"' : '' ) . '>';
			foreach ( $cards as $card ) {
				echo '<div class="estat-grid-cell" data-estat-filter-item="' . esc_attr( $card['groups'] ) . '">' . $card['html'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
			echo self::pagination( (int) $results['page'], (int) $results['pages'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
		if ( ! $no_wrapper ) {
			echo '</div></main>';
		}
		return (string) ob_get_clean();
	}

	/**
	 * The words used for availability states, as an array.
	 *
	 * @return array<string,string>
	 */
	private static function availability_labels(): array {
		return method_exists( \EstatOS\Support\Vocabulary::class, 'availability' )
			? (array) \EstatOS\Support\Vocabulary::availability()
			: array();
	}

	/**
	 * The words used for sale and rent, as an array.
	 *
	 * @return array<string,string>
	 */
	private static function offer_labels(): array {
		return method_exists( \EstatOS\Support\Vocabulary::class, 'offers' )
			? (array) \EstatOS\Support\Vocabulary::offers()
			: array();
	}

	/**
	 * Does this call carry a real filter (anything a visitor could have
	 * narrowed with, beyond paging)?
	 *
	 * @param array<string,mixed> $args Directory arguments.
	 * @return bool
	 */
	private static function has_filters( array $args ): bool {
		foreach ( $args as $key => $value ) {
			if ( in_array( $key, array( 'page', 'per_page', 'status', 'heading_tag', 'wrapper' ), true ) ) {
				continue;
			}
			if ( null !== $value && '' !== $value && array() !== $value && 0 !== $value && '0' !== $value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Published listings on the whole site — the difference between "no
	 * matches" and "no shop yet".
	 *
	 * @return int
	 */
	private static function published_count(): int {
		if ( function_exists( 'wp_count_posts' ) ) {
			$counts = wp_count_posts( \EstatOS\Data\PostTypes::LISTING );
			return isset( $counts->publish ) ? (int) $counts->publish : 0;
		}
		$q     = new \WP_Query(
			array(
				'post_type'      => \EstatOS\Data\PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
			)
		);
		return (int) $q->found_posts;
	}

	/**
	 * Pagination links.
	 *
	 * @param int $page  Current page.
	 * @param int $pages Total pages.
	 * @return string
	 */
	public static function pagination( int $page, int $pages ): string {
		if ( $pages < 2 ) {
			return '';
		}
		$links = paginate_links(
			array(
				'base'      => add_query_arg( 'estat_page', '%#%' ),
				'format'    => '',
				'current'   => max( 1, $page ),
				'total'     => $pages,
				'type'      => 'array',
				'prev_text' => __( 'Previous', 'estat-os' ),
				'next_text' => __( 'Next', 'estat-os' ),
			)
		);
		if ( ! is_array( $links ) ) {
			return '';
		}
		$out = '<nav class="estat-pagination" aria-label="' . esc_attr__( 'Property pages', 'estat-os' ) . '"><ul>';
		foreach ( $links as $link ) {
			$out .= '<li>' . wp_kses_post( $link ) . '</li>';
		}
		return $out . '</ul></nav>';
	}

	/**
	 * The search form — 3.0.7 fixed: 6 default, details closed, ids/for, SVG, no overflow.
	 *
	 * @param array<string,mixed> $args Options: action.
	 * @return string
	 */
		public static function search_form( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-share' );
		$action = isset( $args['action'] ) ? esc_url( (string) $args['action'] ) : esc_url( (string) get_post_type_archive_link( PostTypes::LISTING ) );

		$enabled = Query::enabled_filters();
		$ordered_all = Query::ordered_filters();

		$localities = get_transient( 'estat_terms_locality' );
		if ( false === $localities ) {
			$localities = get_terms( array( 'taxonomy' => Taxonomies::LOCALITY, 'hide_empty' => true, 'number' => 200 ) );
			$localities = is_wp_error( $localities ) ? array() : $localities;
			set_transient( 'estat_terms_locality', $localities, HOUR_IN_SECONDS );
		}

		$amenities_terms = get_transient( 'estat_terms_amenity' );
		if ( false === $amenities_terms ) {
			$amenities_terms = get_terms( array( 'taxonomy' => Taxonomies::AMENITY, 'hide_empty' => true, 'number' => 100 ) );
			$amenities_terms = is_wp_error( $amenities_terms ) ? array() : $amenities_terms;
			set_transient( 'estat_terms_amenity', $amenities_terms, HOUR_IN_SECONDS );
		}

		$features_terms = get_transient( 'estat_terms_feature' );
		if ( false === $features_terms ) {
			$features_terms = get_terms( array( 'taxonomy' => Taxonomies::FEATURE, 'hide_empty' => true, 'number' => 100 ) );
			$features_terms = is_wp_error( $features_terms ) ? array() : $features_terms;
			set_transient( 'estat_terms_feature', $features_terms, HOUR_IN_SECONDS );
		}

		$projects = get_transient( 'estat_projects_ids' );
		if ( false === $projects ) {
			$projects = get_posts( array( 'post_type' => PostTypes::PROJECT, 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids', 'no_found_rows' => true ) );
			set_transient( 'estat_projects_ids', $projects, HOUR_IN_SECONDS );
		}

		$get = static function ( string $key ): string {
			if ( ! isset( $_GET[ $key ] ) ) {
				return '';
			}
			$raw = $_GET[ $key ];
			if ( is_array( $raw ) ) {
				$raw = reset( $raw );
				if ( is_array( $raw ) ) {
					$raw = '';
				}
			}
			return sanitize_text_field( wp_unslash( (string) $raw ) );
		};
		$get_arr = static function ( string $key ): array {
			$raw = $_GET[ $key ] ?? array();
			if ( is_string( $raw ) ) { $raw = array( $raw ); }
			return array_map( 'sanitize_text_field', (array) $raw );
		};

		// Render helpers with proper ids/for and SVG icons (no emoji)
		$renderers = array(
			'offer' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-offer"><?php esc_html_e( 'Buy or rent', 'estat-os' ); ?></label><select id="estat-offer" name="offer"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::offers() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'offer' ), $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'property_type' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-type"><?php esc_html_e( 'Property type', 'estat-os' ); ?></label><select id="estat-type" name="property_type"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::property_types() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'property_type' ), $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'locality' => function() use ( $get, $localities ) {
				if ( ! $localities ) { return ''; }
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-locality"><?php esc_html_e( 'Locality', 'estat-os' ); ?></label><select id="estat-locality" name="locality"><option value=""><?php esc_html_e( 'Anywhere', 'estat-os' ); ?></option><?php foreach ( $localities as $term ) : ?><option value="<?php echo esc_attr( (string) $term->slug ); ?>" <?php selected( $get( 'locality' ), (string) $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'bedrooms' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-beds"><?php esc_html_e( 'Bedrooms (min)', 'estat-os' ); ?></label><input type="number" id="estat-beds" name="bedrooms_min" min="0" max="20" value="<?php echo esc_attr( $get( 'bedrooms_min' ) ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'bathrooms' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-baths"><?php esc_html_e( 'Bathrooms (min)', 'estat-os' ); ?></label><input type="number" id="estat-baths" name="bathrooms_min" min="0" max="20" value="<?php echo esc_attr( $get( 'bathrooms_min' ) ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'price' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-price-max"><?php esc_html_e( 'Budget up to', 'estat-os' ); ?></label><input type="number" id="estat-price-max" name="price_max" min="0" step="1000" value="<?php echo esc_attr( $get( 'price_max' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 9000000', 'estat-os' ); ?>" /></div>
				<?php return ob_get_clean();
			},
			'area' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-area-min"><?php esc_html_e( 'Area min (sqft)', 'estat-os' ); ?></label><input type="number" id="estat-area-min" name="area_min" value="<?php echo esc_attr( $get( 'area_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'furnishing' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-furnishing"><?php esc_html_e( 'Furnishing', 'estat-os' ); ?></label><select id="estat-furnishing" name="furnishing"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::furnishing() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'furnishing' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'facing' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-facing"><?php esc_html_e( 'Facing', 'estat-os' ); ?></label><select id="estat-facing" name="facing"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::facing() as $v=>$l ) : if(''===$v) continue; ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'facing' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'floor' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-floor-min"><?php esc_html_e( 'Floor min', 'estat-os' ); ?></label><input type="number" id="estat-floor-min" name="floor_min" value="<?php echo esc_attr( $get( 'floor_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'total_floors' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-total-floors-min"><?php esc_html_e( 'Total floors min', 'estat-os' ); ?></label><input type="number" id="estat-total-floors-min" name="total_floors_min" value="<?php echo esc_attr( $get( 'total_floors_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'construction' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-construction"><?php esc_html_e( 'Construction', 'estat-os' ); ?></label><select id="estat-construction" name="construction"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::construction() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'construction' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'availability' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-availability"><?php esc_html_e( 'Availability', 'estat-os' ); ?></label><select id="estat-availability" name="availability"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::availability() as $v=>$l ) : ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'availability' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'possession' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-possession"><?php esc_html_e( 'Possession', 'estat-os' ); ?></label><select id="estat-possession" name="possession"><option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option><?php foreach ( Vocabulary::possession_timeline() as $v=>$l ) : if(''===$v) continue; ?><option value="<?php echo esc_attr( $v ); ?>" <?php selected( $get( 'possession' ), $v ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'parking' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-parking-min"><?php esc_html_e( 'Parking min', 'estat-os' ); ?></label><input type="number" id="estat-parking-min" name="parking_min" value="<?php echo esc_attr( $get( 'parking_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'balconies' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-balconies-min"><?php esc_html_e( 'Balconies min', 'estat-os' ); ?></label><input type="number" id="estat-balconies-min" name="balconies_min" value="<?php echo esc_attr( $get( 'balconies_min' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'age' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-age-max"><?php esc_html_e( 'Max age (years)', 'estat-os' ); ?></label><input type="number" id="estat-age-max" name="age_max" value="<?php echo esc_attr( $get( 'age_max' ) ); ?>"></div>
				<?php return ob_get_clean();
			},
			'project' => function() use ( $get, $projects ) {
				if ( ! $projects ) { return ''; }
				ob_start(); ?>
				<div class="estat-field estat-search-field"><label for="estat-project-id"><?php esc_html_e( 'Project', 'estat-os' ); ?></label><select id="estat-project-id" name="project_id"><option value=""><?php esc_html_e( 'Any project', 'estat-os' ); ?></option><?php foreach ( $projects as $pid ) : ?><option value="<?php echo esc_attr( $pid ); ?>" <?php selected( $get( 'project_id' ), (string) $pid ); ?>><?php echo esc_html( get_the_title( $pid ) ); ?></option><?php endforeach; ?></select></div>
				<?php return ob_get_clean();
			},
			'verified' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field estat-search-field--check"><input type="checkbox" id="estat-verified" name="verified" value="1" <?php checked( $get( 'verified' ), '1' ); ?>><label for="estat-verified"><?php esc_html_e( 'Verified only', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'featured' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field estat-search-field--check"><input type="checkbox" id="estat-featured" name="featured" value="1" <?php checked( $get( 'featured' ), '1' ); ?>><label for="estat-featured"><?php esc_html_e( 'Featured only', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'investment' => function() use ( $get ) {
				ob_start(); ?>
				<div class="estat-field estat-search-field estat-search-field--check"><input type="checkbox" id="estat-investment" name="investment" value="1" <?php checked( $get( 'investment' ), '1' ); ?>><label for="estat-investment"><?php esc_html_e( 'Investment', 'estat-os' ); ?></label></div>
				<?php return ob_get_clean();
			},
			'amenities' => function() use ( $get_arr, $amenities_terms ) {
				if ( ! $amenities_terms ) { return ''; }
				$selected = $get_arr( 'amenities' );
				ob_start(); ?>
				<fieldset class="estat-field estat-search-field"><legend><?php esc_html_e( 'Amenities', 'estat-os' ); ?></legend><div class="estat-search-scroll"><?php foreach ( $amenities_terms as $term ) : $cid = 'estat-amenity-' . $term->term_id; ?><div><input type="checkbox" id="<?php echo esc_attr( $cid ); ?>" name="amenities[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php echo in_array( (string) $term->term_id, $selected, true ) ? 'checked' : ''; ?>><label for="<?php echo esc_attr( $cid ); ?>"><?php echo esc_html( $term->name ); ?></label></div><?php endforeach; ?></div></fieldset>
				<?php return ob_get_clean();
			},
			'features' => function() use ( $get_arr, $features_terms ) {
				if ( ! $features_terms ) { return ''; }
				$selected = $get_arr( 'features' );
				ob_start(); ?>
				<fieldset class="estat-field estat-search-field"><legend><?php esc_html_e( 'Features / Highlights', 'estat-os' ); ?></legend><div class="estat-search-scroll"><?php foreach ( $features_terms as $term ) : $cid = 'estat-feature-' . $term->term_id; ?><div><input type="checkbox" id="<?php echo esc_attr( $cid ); ?>" name="features[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php echo in_array( (string) $term->term_id, $selected, true ) ? 'checked' : ''; ?>><label for="<?php echo esc_attr( $cid ); ?>"><?php echo esc_html( $term->name ); ?></label></div><?php endforeach; ?></div></fieldset>
				<?php return ob_get_clean();
			},
		);

		ob_start();
		?>
		<form class="estat-search estat-search-v3" method="get" action="<?php echo esc_url( $action ); ?>" role="search">
			<div class="estat-search-row">
				<div class="estat-field estat-search-field">
					<label for="estat-q"><?php esc_html_e( 'What are you looking for?', 'estat-os' ); ?></label>
					<input type="search" id="estat-q" name="keyword" value="<?php echo esc_attr( $get( 'keyword' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 3 BHK near the metro', 'estat-os' ); ?>" />
				</div>
				<?php
				$count = 0;
				$remaining = array();
				foreach ( $enabled as $key ) {
					if ( ! isset( $renderers[ $key ] ) ) { continue; }
					if ( $count < 5 ) {
						echo $renderers[ $key ]();
						$count++;
					} else {
						$remaining[] = $key;
					}
				}
				?>
			</div>

			<details class="estat-search-more">
				<summary class="estat-search-more-summary"><?php echo \EstatOS\Support\Icon::render( 'filter', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'More filters', 'estat-os' ); ?></summary>
				<div class="estat-search-row">
					<?php
					foreach ( $remaining as $key ) {
						if ( isset( $renderers[ $key ] ) ) {
							echo $renderers[ $key ]();
						}
					}
					?>
				</div>
			</details>

			<div class="estat-search-actions">
				<button type="submit" class="estat-btn estat-btn-primary"><?php esc_html_e( 'Search properties', 'estat-os' ); ?></button>
				<?php if ( Settings::get( 'search_alerts_enabled' ) ) : ?>
				<button type="button" class="estat-btn" onclick="document.getElementById('estat-alerts-inline').hidden=false"><?php esc_html_e( 'Watch this search', 'estat-os' ); ?></button>
				<?php endif; ?>
				<a href="<?php echo esc_url( strtok( $action, '?' ) ); ?>" class="estat-btn"><?php esc_html_e( 'Clear', 'estat-os' ); ?></a>
			</div>

			<?php if ( Settings::get( 'search_alerts_enabled' ) ) : ?>
			<div id="estat-alerts-inline" class="estat-alert-panel" hidden>
				<h4 class="estat-alert-panel-title"><?php esc_html_e( 'Get email when match goes live', 'estat-os' ); ?></h4>
				<p class="estat-alert-panel-note"><?php esc_html_e( 'Watch this search — get email when a matching home goes live.', 'estat-os' ); ?></p>
				<div class="estat-alert-form">
					<input type="text" name="alert_name" placeholder="<?php esc_attr_e( 'Your name', 'estat-os' ); ?>">
					<input type="email" name="alert_email" placeholder="<?php esc_attr_e( 'Your email', 'estat-os' ); ?>" required>
					<input type="tel" name="alert_phone" placeholder="<?php esc_attr_e( 'Phone (optional)', 'estat-os' ); ?>">
					<select name="alert_frequency" class="estat-alert-frequency"><option value="instant"><?php esc_html_e( 'Instant', 'estat-os' ); ?></option><option value="daily"><?php esc_html_e( 'Daily digest', 'estat-os' ); ?></option></select>
					<button type="button" class="button button-primary estat-alert-save"><?php esc_html_e( 'Save alert', 'estat-os' ); ?></button>
				</div>
				<p class="estat-alert-msg" role="status" aria-live="polite"></p>
			</div>
			<script>
			document.addEventListener('DOMContentLoaded', function(){
				const btn = document.querySelector('.estat-alert-save');
				if(!btn) return;
				btn.addEventListener('click', function(){
					const name = document.querySelector('input[name=alert_name]')?.value || '';
					const email = document.querySelector('input[name=alert_email]')?.value || '';
					const phone = document.querySelector('input[name=alert_phone]')?.value || '';
					const frequency = document.querySelector('select[name=alert_frequency]')?.value || 'instant';
					if(!email){ alert('Email needed'); return; }
					const params = new URLSearchParams(window.location.search);
					const filters = {};
					for(const [k,v] of params.entries()){ filters[k]=v; }
					btn.disabled=true; btn.textContent='Saving...';
					fetch((window.estatPublic?.restUrl || '/wp-json/estat/v1/') + 'alerts', {
						method:'POST',
						headers:{'Content-Type':'application/json'},
						body: JSON.stringify({name:name, email:email, phone:phone, frequency:frequency, filters:filters, query:filters, source_url: window.location.href})
					}).then(r=>r.json()).then(j=>{
						const msg = document.querySelector('.estat-alert-msg');
						if(j.id || j.success){ if(msg) msg.textContent='Alert saved! Check email to confirm.'; }
						else { if(msg) msg.textContent=j.message||'Failed'; }
						btn.disabled=false; btn.textContent='Save alert';
					}).catch(e=>{ const msg=document.querySelector('.estat-alert-msg'); if(msg) msg.textContent='Network error'; btn.disabled=false; });
				});
			});
			</script>
			<?php endif; ?>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A monthly repayment estimate.

	 *
	 * Research on Indian property portals is consistent that this is the most
	 * used tool on a listing page: a buyer who works out that a flat is
	 * affordable is far likelier to enquire than one left guessing. It is also
	 * a reason to come back, which a static listing never is.
	 *
	 * The arithmetic runs entirely in the browser. Nothing is sent anywhere,
	 * nothing is stored, and no bank or API is involved - so this works whether
	 * or not the office has any integration, and a visitor playing with the
	 * numbers is not quietly generating a lead.
	 *
	 * The standard formula every Indian lender publishes:
	 *
	 *     EMI = P x R x (1+R)^N / ((1+R)^N - 1)
	 *
	 * where R is the monthly rate and N the number of months.
	 *
	 * @param float $price Property price, used as the starting figure.
	 * @return string
	 */
	/**
	 * The enquiry form shown under a property.
	 *
	 * Uses whichever form the office has switched on. If no form exists yet it
	 * falls back to a short call/WhatsApp/email strip built from Settings, so a
	 * property page never ends in an empty space.
	 *
	 * @param int $listing_id Property being viewed.
	 * @return string HTML.
	 */
	public static function enquiry_form( int $listing_id = 0 ): string {
		$form_id = self::enquiry_form_id();
		if ( $form_id > 0 ) {
			return Renderer::render(
				$form_id,
				array(
					'listing_id' => absint( $listing_id ),
					'class'      => 'estat-property-enquiry',
				)
			);
		}
		return self::contact_strip();
	}

	/**
	 * Which form a property page should use: the standard "Property enquiry" one
	 * if it is still switched on, otherwise the first form the office has.
	 *
	 * @return int Form ID, or 0 when the office has no form yet.
	 */
	private static function enquiry_form_id(): int {
		$forms = Forms::all( 50 );
		foreach ( $forms as $form ) {
			if ( 'active' === ( $form['status'] ?? '' ) && 'property-enquiry' === ( $form['slug'] ?? '' ) ) {
				return (int) $form['id'];
			}
		}
		foreach ( $forms as $form ) {
			if ( 'active' === ( $form['status'] ?? '' ) ) {
				return (int) $form['id'];
			}
		}
		return 0;
	}

	/**
	 * No form yet? Give the visitor the office phone, WhatsApp and email instead.
	 *
	 * @return string HTML.
	 */
	private static function contact_strip(): string {
		$phone = trim( (string) Settings::get( 'phone', '' ) );
		$wa    = trim( (string) Settings::get( 'whatsapp', '' ) );
		$email = trim( (string) Settings::get( 'email', '' ) );

		if ( '' === $phone && '' === $wa && '' === $email ) {
			return '';
		}

		$out  = '<aside class="estat-panel estat-contact-strip">';
		$out .= '<p class="estat-contact-strip-title">' . esc_html__( 'Interested in this property?', 'estat-os' ) . '</p>';
		$out .= '<p class="estat-contact-strip-note">' . esc_html__( 'Call or message us and we will get back to you the same day.', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-contact-strip-actions">';

		if ( '' !== $phone ) {
			$out .= '<a class="estat-btn" href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) . '">' . esc_html__( 'Call the office', 'estat-os' ) . '</a>';
		}
		if ( '' !== $wa ) {
			$digits = (string) preg_replace( '/\D/', '', $wa );
			if ( '' !== $digits ) {
				$out .= '<a class="estat-btn" href="' . esc_url( 'https://wa.me/' . $digits ) . '" target="_blank" rel="noopener">' . esc_html__( 'WhatsApp', 'estat-os' ) . '</a>';
			}
		}
		if ( '' !== $email ) {
			$out .= '<a class="estat-btn" href="mailto:' . esc_attr( $email ) . '">' . esc_html__( 'Email the office', 'estat-os' ) . '</a>';
		}

		$out .= '</div></aside>';
		return $out;
	}

	public static function emi( float $price ): string {
		if ( $price <= 0 ) {
			return '';
		}

		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$currency = (string) Settings::get( 'currency_symbol' );
		if ( '' === $currency ) {
			$currency = '&#8377;';
		}

		// Enhanced EMI — down %, processing fee, amortization, chart.
		$default_down_pct = 20;
		$deposit = round( $price * $default_down_pct / 100 );
		$loan    = max( 0, $price - $deposit );
		$default_rate = (float) Settings::get( 'emi_default_rate', 8.5 );
		if ( $default_rate <= 0 ) { $default_rate = 8.5; }
		$default_years = (int) Settings::get( 'emi_default_years', 20 );
		if ( $default_years <= 0 ) { $default_years = 20; }

		ob_start();
		?>
		<section
			class="estat-emi estat-emi-v2"
			aria-label="<?php esc_attr_e( 'Work out the monthly payment', 'estat-os' ); ?>"
			data-price="<?php echo esc_attr( (string) (int) $price ); ?>"

		>
			<h2 class="estat-emi-title"><?php esc_html_e( 'What would this cost a month?', 'estat-os' ); ?></h2>

			<div class="estat-emi-controls">
				<p class="estat-emi-field">
					<label for="estat-emi-price"><?php esc_html_e( 'Property price', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><span class="estat-emi-currency" aria-hidden="true"><?php echo esc_html( $currency ); ?></span><input type="number" id="estat-emi-price" class="estat-emi-price" value="<?php echo esc_attr( (string) (int) $price ); ?>" min="0" step="10000" inputmode="numeric" /></span>
				</p>
				<p class="estat-emi-field">
					<label for="estat-emi-downpct"><?php esc_html_e( 'Down payment %', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><input type="number" id="estat-emi-downpct" class="estat-emi-downpct" value="<?php echo esc_attr( (string) $default_down_pct ); ?>" min="0" max="90" step="1" /><span>%</span></span>
					<span class="estat-emi-note"><?php printf( esc_html__( 'Deposit %s — editable', 'estat-os' ), esc_html( Format::money( (float) $deposit ) ) ); ?></span>
				</p>
				<p class="estat-emi-field">
					<label for="estat-emi-loan"><?php esc_html_e( 'Loan amount', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><span class="estat-emi-currency"><?php echo esc_html( $currency ); ?></span><input type="number" id="estat-emi-loan" class="estat-emi-loan" value="<?php echo esc_attr( (string) (int) $loan ); ?>" min="0" step="10000" inputmode="numeric" /></span>
				</p>
				<p class="estat-emi-field">
					<label for="estat-emi-rate"><?php esc_html_e( 'Interest rate', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><input type="number" id="estat-emi-rate" class="estat-emi-rate" value="<?php echo esc_attr( (string) $default_rate ); ?>" min="1" max="20" step="0.05" inputmode="decimal" /><span>%</span></span>
					<span class="estat-emi-note"><?php esc_html_e( 'Per year. Ask your bank.', 'estat-os' ); ?></span>
				</p>
				<p class="estat-emi-field">
					<label for="estat-emi-years"><?php esc_html_e( 'Over how many years', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><input type="number" id="estat-emi-years" class="estat-emi-years" value="<?php echo esc_attr( (string) $default_years ); ?>" min="1" max="30" step="1" inputmode="numeric" /></span>
				</p>
				<p class="estat-emi-field">
					<label for="estat-emi-fee"><?php esc_html_e( 'Processing fee %', 'estat-os' ); ?></label>
					<span class="estat-emi-input"><input type="number" id="estat-emi-fee" class="estat-emi-fee" value="1" min="0" max="10" step="0.1" /><span>%</span></span>
				</p>
			</div>

			<div class="estat-emi-result" role="status" aria-live="polite">
				<p class="estat-emi-amount"><span class="estat-emi-value">&mdash;</span> <span class="estat-emi-per"><?php esc_html_e( 'a month', 'estat-os' ); ?></span></p>
				<p class="estat-emi-breakdown"><span class="estat-emi-total"></span><br><span class="estat-emi-interest"></span><br><span class="estat-emi-feeout"></span></p>
				<div class="estat-emi-bar"><div class="estat-emi-bar-principal"></div><div class="estat-emi-bar-interest"></div></div>
				<div><span><?php esc_html_e( 'Principal', 'estat-os' ); ?></span><span><?php esc_html_e( 'Interest', 'estat-os' ); ?></span></div>
			</div>

			<details class="estat-emi-schedule"><summary><?php esc_html_e( 'Show year-wise amortization', 'estat-os' ); ?></summary><div class="estat-emi-table"></div></details>

			<p class="estat-emi-caveat"><?php esc_html_e( 'This is an estimate to help you plan, not an offer. Your bank decides the real figure.', 'estat-os' ); ?></p>

			<script>
			document.addEventListener('DOMContentLoaded', function(){
				const sec = document.currentScript ? document.currentScript.closest('.estat-emi') : document.querySelector('.estat-emi-v2');
				// Fallback: find last emi
				const root = document.querySelectorAll('.estat-emi-v2');
				const el = root[root.length-1];
				if(!el) return;
				const priceInput = el.querySelector('.estat-emi-price');
				const downPctInput = el.querySelector('.estat-emi-downpct');
				const loanInput = el.querySelector('.estat-emi-loan');
				const rateInput = el.querySelector('.estat-emi-rate');
				const yearsInput = el.querySelector('.estat-emi-years');
				const feeInput = el.querySelector('.estat-emi-fee');
				const valueOut = el.querySelector('.estat-emi-value');
				const totalOut = el.querySelector('.estat-emi-total');
				const interestOut = el.querySelector('.estat-emi-interest');
				const feeOut = el.querySelector('.estat-emi-feeout');
				const barP = el.querySelector('.estat-emi-bar-principal');
				const barI = el.querySelector('.estat-emi-bar-interest');
				const tableOut = el.querySelector('.estat-emi-table');
				function fmt(n){ try{ return new Intl.NumberFormat('en-IN').format(Math.round(n)); }catch(e){ return Math.round(n).toString(); } }
				function calc(){
					let price = parseFloat(priceInput.value)||0;
					let downPct = parseFloat(downPctInput.value)||0;
					let loan = parseFloat(loanInput.value)||0;
					let rate = parseFloat(rateInput.value)||0;
					let years = parseFloat(yearsInput.value)||0;
					let feePct = parseFloat(feeInput.value)||0;
					// If price or down% changed, recalc loan
					if(document.activeElement===priceInput || document.activeElement===downPctInput){
						let dep = price*downPct/100;
						loan = Math.max(0, price-dep);
						loanInput.value = Math.round(loan);
					}
					if(loan<=0 || rate<=0 || years<=0){ valueOut.textContent='—'; return; }
					let r = rate/12/100;
					let n = years*12;
					let emi = loan*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
					let total = emi*n;
					let interest = total-loan;
					let fee = loan*feePct/100;
					valueOut.textContent = '₹' + fmt(emi);
					totalOut.textContent = 'Total repaid: ₹' + fmt(total) + ' (Principal ₹' + fmt(loan) + ' + Interest ₹' + fmt(interest) + ')';
					interestOut.textContent = 'Total interest: ₹' + fmt(interest);
					feeOut.textContent = fee>0 ? 'Processing fee ('+feePct+'%): ₹' + fmt(fee) : '';
					let pPct = loan/total*100;
					let iPct = interest/total*100;
					if(barP) barP.style.width = pPct+'%';
					if(barI) barI.style.width = iPct+'%';
					// Amortization year-wise
					if(tableOut){
						let bal = loan;
						let html = '<table class="estat-emi-schedule-table"><tr><th class="is-left">'+<?php echo wp_json_encode( __( 'Year', 'estat-os' ), JSON_HEX_TAG | JSON_HEX_AMP ); ?>+'</th><th>'+<?php echo wp_json_encode( __( 'Principal paid', 'estat-os' ), JSON_HEX_TAG | JSON_HEX_AMP ); ?>+'</th><th>'+<?php echo wp_json_encode( __( 'Interest paid', 'estat-os' ), JSON_HEX_TAG | JSON_HEX_AMP ); ?>+'</th><th>'+<?php echo wp_json_encode( __( 'Balance', 'estat-os' ), JSON_HEX_TAG | JSON_HEX_AMP ); ?>+'</th></tr>';
						let cumP=0,cumI=0;
						for(let y=1;y<=years;y++){
							let yP=0,yI=0;
							for(let m=1;m<=12;m++){
								if(bal<=0) break;
								let i = bal*r;
								let pmt = Math.min(emi, bal+i);
								let princ = pmt - i;
								if(princ<0) princ=0;
								bal -= princ;
								if(bal<0.01) bal=0;
								yP+=princ; yI+=i; cumP+=princ; cumI+=i;
							}
							html += '<tr><td class="is-left">'+y+'</td><td>'+fmt(yP)+'</td><td>'+fmt(yI)+'</td><td>'+fmt(bal)+'</td></tr>';
							if(bal<=0) break;
						}
						html+='</table>';
						tableOut.innerHTML = html;
					}
				}
				['input','change'].forEach(ev=>{
					priceInput.addEventListener(ev, calc);
					downPctInput.addEventListener(ev, calc);
					loanInput.addEventListener(ev, calc);
					rateInput.addEventListener(ev, calc);
					yearsInput.addEventListener(ev, calc);
					feeInput.addEventListener(ev, calc);
				});
				calc();
			});
			</script>
		</section>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Project stage timeline — Planning / Under Construction / Ready.
	 *
	 * @param string $current_stage Current stage key.
	 * @return string
	 */
	public static function project_timeline( string $current_stage ): string {
		$stages = \EstatOS\Support\Vocabulary::project_stage_order();
		$progress_map = \EstatOS\Support\Vocabulary::project_stage_progress();
		$current_progress = $progress_map[ $current_stage ] ?? 0;
		ob_start();
		?>
		<div class="estat-project-timeline">
			<h3 class="estat-project-timeline-title"><?php esc_html_e( 'Project Timeline', 'estat-os' ); ?></h3>
			<ol class="estat-project-timeline-steps">
				<?php foreach ( $stages as $idx => $st ) :
					$is_current = $st === $current_stage;
					$is_past = array_search( $st, $stages ) < array_search( $current_stage, $stages );
					$bg = $is_current ? 'var(--estat-ink)' : ( $is_past ? 'var(--estat-positive)' : 'var(--estat-line)' );
					$color = $is_current || $is_past ? 'var(--estat-surface)' : 'var(--estat-ink)';
				?>
					<li class="estat-timeline-step<?php echo $is_current ? ' is-current' : ( $is_past ? ' is-past' : '' ); ?>">
						<span class="estat-timeline-dot"><?php echo (int) $idx + 1; ?></span>
						<span class="estat-timeline-label"><?php echo esc_html( \EstatOS\Support\Vocabulary::project_stage_label( $st ) ); ?></span>
					</li>
					<?php if ( $idx < count( $stages ) - 1 ) : ?><li class="estat-timeline-bar" aria-hidden="true"></li><?php endif; ?>
				<?php endforeach; ?>
			</ol>
			<div class="estat-timeline-track"><div class="estat-timeline-fill" style="width:<?php echo (int) $current_progress; ?>%"></div></div>
			<p class="estat-timeline-progress"><?php echo (int) $current_progress; ?>% <?php esc_html_e( 'complete', 'estat-os' ); ?></p>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Locality card.
	 *
	 * @param \WP_Term $term Term.
	 * @return string
	 */
	public static function locality_card( $term ): string {
		if ( ! $term || is_wp_error( $term ) ) { return ''; }
		$count = (int) $term->count;
		ob_start();
		?>
		<a class="estat-locality-card" href="<?php echo esc_url( get_term_link( $term ) ); ?>">
			<span class="estat-locality-card-name"><?php echo esc_html( $term->name ); ?></span>
			<span class="estat-locality-card-count"><?php echo esc_html( sprintf( _n( '%d property', '%d properties', $count, 'estat-os' ), $count ) ); ?></span>
		</a>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A map, using OpenStreetMap by default so no paid key is needed.
	 *
	 * @param float  $lat   Latitude.
	 * @param float  $lng   Longitude.
	 * @param string $label Marker label.
	 * @return string
	 */
	public static function map( float $lat, float $lng, string $label = '' ): string {
		$provider = (string) Settings::get( 'map_provider', 'osm' );
		if ( 'none' === $provider ) {
			return '';
		}

		/*
		 * A property does not always carry its own pin. Rather than showing
		 * nothing, the map falls back to the office's own centre — the
		 * latitude, longitude and zoom the office set under Settings →
		 * Integrations — so a buyer still sees roughly where the property
		 * is, and the page is never a blank hole.
		 */
		if ( 0.0 === $lat && 0.0 === $lng ) {
			$lat = (float) Settings::get( 'map_default_lat', 0.0 );
			$lng = (float) Settings::get( 'map_default_lng', 0.0 );
		}

		if ( 0.0 === $lat && 0.0 === $lng ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );

		if ( 'google' === $provider && '' !== (string) Settings::get( 'google_maps_key' ) ) {
			$src = add_query_arg(
				array(
					'key' => rawurlencode( (string) Settings::get( 'google_maps_key' ) ),
					'q'   => rawurlencode( $lat . ',' . $lng ),
				),
				'https://www.google.com/maps/embed/v1/place'
			);
		} else {
			$delta = 0.01;
			$bbox  = ( $lng - $delta ) . ',' . ( $lat - $delta ) . ',' . ( $lng + $delta ) . ',' . ( $lat + $delta );
			$src   = add_query_arg(
				array( 'bbox' => $bbox, 'layer' => 'mapnik', 'marker' => $lat . ',' . $lng ),
				'https://www.openstreetmap.org/export/embed.html'
			);
		}

		return '<div class="estat-map"><iframe title="' . esc_attr( '' !== $label ? $label : __( 'Map', 'estat-os' ) ) . '" src="' . esc_url( $src ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>';
	}

	/**
	 * The team directory.
	 *
	 * @param int $limit Maximum team members.
	 * @return string
	 */
	public static function agents( int $limit = 12 ): string {
		wp_enqueue_style( 'estat-public' );
		$ids = get_posts(
			array(
				'post_type'      => PostTypes::AGENT,
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, min( 100, $limit ) ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		if ( ! $ids ) {
			return '<p class="estat-empty">' . esc_html__( 'No team members have been added yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-grid estat-team">';
		foreach ( $ids as $id ) {
			$agent = Agents::to_array( (int) $id );
			?>
			<article class="estat-agent">
				<?php if ( '' !== (string) $agent['photo'] ) : ?>
					<?php
					// The stylesheet renders this at a fixed 88px circle, so
					// the size is known here without asking the database.
					?>
					<img
						class="estat-agent-photo"
						src="<?php echo esc_url( (string) $agent['photo'] ); ?>"
						alt="<?php echo esc_attr( (string) $agent['name'] ); ?>"
						width="88"
						height="88"
						loading="lazy"
						decoding="async"
					/>
				<?php endif; ?>
				<h3><a href="<?php echo esc_url( (string) $agent['url'] ); ?>"><?php echo esc_html( (string) $agent['name'] ); ?></a></h3>
				<?php if ( '' !== (string) $agent['role'] ) : ?>
					<p class="estat-agent-role"><?php echo esc_html( (string) $agent['role'] ); ?></p>
				<?php endif; ?>
				<p class="estat-agent-contact">
					<?php if ( '' !== (string) $agent['phone'] ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $agent['phone'] ) ); ?>"><?php esc_html_e( 'Call', 'estat-os' ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== (string) $agent['whatsapp'] ) : ?>
						<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', (string) $agent['whatsapp'] ) ); ?>" rel="nofollow noopener"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
					<?php endif; ?>
				</p>
			</article>
			<?php
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * The comparison tray.
	 *
	 * @return string
	 */
	public static function compare(): string {
		if ( ! Settings::get( 'enable_compare' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		/*
		 * The table is filled by the browser, because the choices live on the
		 * visitor's own device. What is written here is the frame and the two
		 * things that must exist even before anything is picked: somewhere to
		 * say how many are in, and the way to hand the list to the office.
		 */
		return '<section class="estat-compare-panel" id="estat-compare-panel" aria-live="polite">'
			. '<h2>' . esc_html__( 'Compare properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-empty">' . esc_html__( 'Choose "Compare" on a few properties and they will appear here side by side.', 'estat-os' ) . '</p>'
			. '<p class="estat-compare-note" role="status"></p>'
			. '<div class="estat-compare-table"></div>'
			. '<div class="estat-compare-send" hidden>'
			. '<h3>' . esc_html__( 'Want these sent to you?', 'estat-os' ) . '</h3>'
			. '<p class="estat-muted">' . esc_html__( 'Leave a name and a number. The office gets the list and calls you back, and the same list opens in WhatsApp so you keep a copy.', 'estat-os' ) . '</p>'
			. '<form class="estat-shortlist-form">'
			. '<p><label>' . esc_html__( 'Your name', 'estat-os' ) . '<br>'
			. '<input type="text" name="name" autocomplete="name" required></label></p>'
			. '<p><label>' . esc_html__( 'Phone', 'estat-os' ) . '<br>'
			. '<input type="tel" name="phone" autocomplete="tel" required></label></p>'
			. '<p><label>' . esc_html__( 'Email (optional)', 'estat-os' ) . '<br>'
			. '<input type="email" name="email" autocomplete="email"></label></p>'
			/* The honeypot: hidden from people, irresistible to bots. */
			. '<p class="estat-hp" aria-hidden="true"><label>' . esc_html__( 'Website', 'estat-os' ) . '<br>'
			. '<input type="text" name="estat_website" tabindex="-1" autocomplete="off"></label></p>'
			. '<p><button type="submit" class="estat-btn estat-btn--primary">'
			. esc_html__( 'Send this list on WhatsApp', 'estat-os' ) . '</button></p>'
			. '<p class="estat-shortlist-said" role="status"></p>'
			. '</form></div></section>';
	}

	/**
	 * The saved-properties list.
	 *
	 * @return string
	 */
	public static function favorites(): string {
		if ( ! Settings::get( 'enable_favorites' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		return '<section class="estat-favorites" id="estat-favorites" aria-live="polite">'
			. '<h2>' . esc_html__( 'Your saved properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-favorites-count" role="status"></p>'
			. '<p class="estat-empty">' . esc_html__( 'Nothing saved yet. Tap the heart on any property to keep it here.', 'estat-os' ) . '</p>'
			. '<div class="estat-grid estat-fav-grid"></div></section>';
	}

	/* ======================================================================
	 * Shared public pieces
	 * ----------------------------------------------------------------------
	 * Five templates used to hand-roll the same <article class="estat-card">,
	 * so a change to the card meant finding all five. These are the pieces
	 * every public page shares, drawn once and used by the project page, the
	 * project directory, the archives and the taxonomy pages alike.
	 * ====================================================================== */

	/**
	 * A section heading with an optional trailing note.
	 *
	 * @param string $title Title.
	 * @param string $note  Optional right-hand note.
	 * @param string $level Heading level: h2|h3.
	 * @return string
	 */
	public static function section_head( string $title, string $note = '', string $level = 'h2' ): string {
		if ( '' === trim( $title ) ) {
			return '';
		}
		$level = in_array( $level, array( 'h2', 'h3', 'h4' ), true ) ? $level : 'h2';
		$out   = '<div class="estat-section-head"><' . $level . '>' . esc_html( $title ) . '</' . $level . '>';
		if ( '' !== trim( $note ) ) {
			$out .= '<span class="estat-label">' . esc_html( $note ) . '</span>';
		}
		return $out . '</div>';
	}

	/**
	 * A designed empty state.
	 *
	 * A page with nothing to show used to print a bare <p>. An empty state is
	 * still a state of the page, not the absence of one.
	 *
	 * @param string $title   Short heading.
	 * @param string $body    One supporting line.
	 * @param string $icon    Optional icon name.
	 * @param string $action  Optional HTML for a button row.
	 * @return string
	 */
	public static function empty_state( string $title, string $body = '', string $icon = 'search', string $action = '' ): string {
		$out = '<div class="estat-empty">';
		$out .= '<span class="estat-empty-art" aria-hidden="true">' . Icon::render( $icon, 28 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$out .= '<h3>' . esc_html( $title ) . '</h3>';
		if ( '' !== trim( $body ) ) {
			$out .= '<p>' . esc_html( $body ) . '</p>';
		}
		if ( '' !== trim( $action ) ) {
			$out .= '<div class="estat-empty-actions">' . $action . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		return $out . '</div>';
	}

	/**
	 * Breadcrumbs.
	 *
	 * The property page has had these for a while; nothing else did. They are
	 * built from real terms only — a breadcrumb that invents a step is worse
	 * than a breadcrumb with a step missing.
	 *
	 * @param array<int,array{label:string,url:string}> $trail Ordered trail, last item is the current page.
	 * @return string
	 */
	public static function breadcrumbs( array $trail ): string {
		$trail = array_values( array_filter( $trail ) );
		if ( ! $trail ) {
			return '';
		}

		$out = '<nav class="estat-crumbs" aria-label="' . esc_attr__( 'Where you are', 'estat-os' ) . '"><ol>';
		$last = count( $trail ) - 1;
		foreach ( $trail as $i => $step ) {
			$label = (string) ( $step['label'] ?? '' );
			if ( '' === $label ) {
				continue;
			}
			$url   = (string) ( $step['url'] ?? '' );
			$out  .= '<li>';
			if ( $i === $last || '' === $url ) {
				$out .= '<span aria-current="page">' . esc_html( $label ) . '</span>';
			} else {
				$out .= '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
				$out .= '<span class="estat-crumb-sep" aria-hidden="true">/</span>';
			}
			$out .= '</li>';
		}
		return $out . '</ol></nav>';
	}

	/**
	 * A gallery: one large frame, a strip of thumbnails, and a lightbox.
	 *
	 * The swap-the-large-photo behaviour was already here and is kept: it
	 * works with no script at all, because each thumbnail is a real control
	 * carrying the address of the picture it shows. What is added is the
	 * lightbox — and it is added the same way, by giving each control the
	 * address of the full-size picture. ui.js builds the dialog the first
	 * time somebody opens it and not before, so a project with forty
	 * photographs costs nothing until they are looked at.
	 *
	 * Only a handful of thumbnails are in the document at full weight; the
	 * rest are reached through "View all N photographs", which opens the
	 * lightbox on the first one.
	 *
	 * @param array<int,array{id:int,url:string}> $photos Photos.
	 * @param string                              $alt    Alt text base.
	 * @param bool                                $eager  Load the first image eagerly.
	 * @param int                                 $thumbs How many thumbnails to show.
	 * @return string
	 */
	public static function gallery( array $photos, string $alt = '', bool $eager = false, int $thumbs = 6 ): string {
		$photos = array_values( array_filter( $photos ) );
		if ( ! $photos ) {
			return '';
		}

		wp_enqueue_script( 'estat-public' );
		self::interact();

		$thumbs = max( 1, (int) $thumbs );
		$total  = count( $photos );

		/**
		 * The URL of the largest version of a photograph.
		 *
		 * @param array<string,mixed> $photo Photo.
		 * @return string
		 */
		$full = static function ( array $photo ): string {
			$id = (int) ( $photo['id'] ?? 0 );
			return $id > 0 ? (string) wp_get_attachment_image_url( $id, 'full' ) : (string) ( $photo['url'] ?? '' );
		};

		/**
		 * The URL of the size worth showing in a frame.
		 *
		 * @param array<string,mixed> $photo Photo.
		 * @return string
		 */
		$shown = static function ( array $photo ): string {
			$id = (int) ( $photo['id'] ?? 0 );
			return $id > 0 ? (string) wp_get_attachment_image_url( $id, 'large' ) : (string) ( $photo['url'] ?? '' );
		};

		$first = $photos[0];

		$out = '<div class="estat-gallery" data-estat-gallery data-estat-lightbox>';

		// The large frame. It is a control, so a press opens the lightbox.
		$out .= '<div class="estat-gallery-main">'
			. '<button type="button" class="estat-gallery-open" data-estat-lightbox-item'
			. ' data-full="' . esc_url( $full( $first ) ) . '"'
			. ' data-caption="' . esc_attr( $alt ) . '"'
			. ' aria-label="' . esc_attr(
				sprintf(
					/* translators: %d: how many photographs there are. */
					_n( 'Open %d photograph', 'Open %d photographs', $total, 'estat-os' ),
					$total
				)
			) . '">';

		if ( (int) ( $first['id'] ?? 0 ) > 0 ) {
			$out .= wp_get_attachment_image(
				(int) $first['id'],
				'large',
				false,
				array(
					'class'    => 'estat-gallery-img',
					'alt'      => $alt,
					'loading'  => $eager ? 'eager' : 'lazy',
					'decoding' => 'async',
				)
			);
		} else {
			$out .= '<img class="estat-gallery-img" src="' . esc_url( (string) ( $first['url'] ?? '' ) ) . '" alt="' . esc_attr( $alt ) . '" loading="' . ( $eager ? 'eager' : 'lazy' ) . '" decoding="async" />';
		}

		$out .= '<span class="estat-gallery-zoom" aria-hidden="true">' . Icon::render( 'camera', 18 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$out .= '</button></div>';

		if ( $total > 1 ) {
			$out .= '<div class="estat-gallery-strip">';
			foreach ( array_slice( $photos, 0, $thumbs ) as $i => $photo ) {
				$pid   = (int) ( $photo['id'] ?? 0 );
				$thumb = $pid > 0
					? wp_get_attachment_image( $pid, 'thumbnail', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) )
					: '<img src="' . esc_url( (string) ( $photo['url'] ?? '' ) ) . '" alt="" loading="lazy" decoding="async" />';

				$out .= '<button type="button" class="estat-gallery-thumb' . ( 0 === $i ? ' is-current' : '' ) . '"'
					. ' data-estat-photo="' . esc_url( $shown( $photo ) ) . '"'
					. ' data-estat-lightbox-item'
					. ' data-full="' . esc_url( $full( $photo ) ) . '"'
					. ' data-caption="' . esc_attr( $alt ) . '"'
					. ' aria-label="' . esc_attr(
						sprintf(
							/* translators: %d: which photograph this is. */
							__( 'Photo %d', 'estat-os' ),
							$i + 1
						)
					) . '">'
					. $thumb . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			$out .= '</div>';

			if ( $total > $thumbs ) {
				$out .= '<button type="button" class="estat-gallery-all" data-estat-lightbox-item'
					. ' data-full="' . esc_url( $full( $first ) ) . '"'
					. ' data-caption="' . esc_attr( $alt ) . '">'
					. Icon::render( 'camera', 16 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. esc_html(
						sprintf(
							/* translators: %d: how many photographs there are. */
							__( 'View all %d photographs', 'estat-os' ),
							$total
						)
					)
					. '</button>';
			}
		}

		/*
		 * Every photograph is listed for the lightbox, including the ones not
		 * drawn as thumbnails, but nothing heavier than a URL is written for
		 * them — no <img>, no request, until one is opened.
		 */
		if ( count( $photos ) > $thumbs ) {
			$out .= '<div class="estat-sr" data-estat-lightbox hidden>';
			foreach ( array_slice( $photos, $thumbs ) as $photo ) {
				$out .= '<span data-estat-lightbox-item data-full="' . esc_url( $full( $photo ) ) . '" data-caption="' . esc_attr( $alt ) . '"></span>';
			}
			$out .= '</div>';
		}

		return $out . '</div>';
	}

	/**
	 * The hero media: one large photograph and a compact row beside it.
	 *
	 * This is what turns the cover from a picture into somewhere to start
	 * looking. Every part of it opens the lightbox, and when there is no
	 * photograph at all it falls back to the editorial plate rather than a
	 * broken frame.
	 *
	 * @param int                                 $post_id Post ID.
	 * @param array<int,array{id:int,url:string}> $photos  Photos, cover first when there is a cover.
	 * @param string                              $alt     Alt text.
	 * @return string
	 */
	public static function hero_media( int $post_id, array $photos, string $alt = '' ): string {
		$photos = array_values( array_filter( $photos ) );
		$cover  = (int) get_post_thumbnail_id( $post_id );

		if ( ! $photos ) {
			// No photographs — the same plate the cover used, never a broken frame.
			return '<figure class="estat-hero-media is-empty">'
				. '<span class="estat-hero-plate" aria-hidden="true">' . Icon::render( 'buildings', 34 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<figcaption class="estat-label">' . esc_html( $alt ) . '</figcaption>'
				. '</figure>';
		}

		self::interact();

		/**
		 * Full-size URL.
		 *
		 * @param array<string,mixed> $photo Photo.
		 * @return string
		 */
		$full = static function ( array $photo ): string {
			$id = (int) ( $photo['id'] ?? 0 );
			return $id > 0 ? (string) wp_get_attachment_image_url( $id, 'full' ) : (string) ( $photo['url'] ?? '' );
		};

		$total = count( $photos );
		$first = $photos[0];
		$rest  = array_slice( $photos, 1, 4 );

		$out = '<figure class="estat-hero-media" data-estat-lightbox>';

		$out .= '<button type="button" class="estat-hero-lead" data-estat-lightbox-item'
			. ' data-full="' . esc_url( $full( $first ) ) . '" data-caption="' . esc_attr( $alt ) . '"'
			. ' aria-label="' . esc_attr(
				sprintf(
					/* translators: %d: how many photographs there are. */
					_n( 'Open %d photograph', 'Open %d photographs', $total, 'estat-os' ),
					$total
				)
			) . '">';

		if ( (int) ( $first['id'] ?? 0 ) > 0 ) {
			$out .= wp_get_attachment_image(
				(int) $first['id'],
				'large',
				false,
				array(
					'class'         => 'estat-hero-img',
					'alt'           => $alt,
					'loading'       => 'eager',
					'fetchpriority' => 'high',
					'decoding'      => 'async',
					'sizes'         => '(max-width: 768px) 100vw, (max-width: 1280px) 68vw, 820px',
				)
			);
		} else {
			$out .= '<img class="estat-hero-img" src="' . esc_url( (string) ( $first['url'] ?? '' ) ) . '" alt="' . esc_attr( $alt ) . '" loading="eager" fetchpriority="high" decoding="async" />';
		}
		$out .= '<span class="estat-hero-zoom" aria-hidden="true">' . Icon::render( 'camera', 18 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$out .= '</button>';

		if ( 1 === $total && $cover > 0 ) {
			// A single cover photograph: no strip, no count, nothing to open into.
			$out .= '</figure>';
			return $out;
		}

		$out .= '<div class="estat-hero-rail">';
		foreach ( $rest as $i => $photo ) {
			$pid   = (int) ( $photo['id'] ?? 0 );
			$thumb = $pid > 0
				? wp_get_attachment_image( $pid, 'medium', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) )
				: '<img src="' . esc_url( (string) ( $photo['url'] ?? '' ) ) . '" alt="" loading="lazy" decoding="async" />';

			$last = ( $i === count( $rest ) - 1 ) && $total > 5;

			$out .= '<button type="button" class="estat-hero-thumb' . ( $last ? ' is-more' : '' ) . '"'
				. ' data-estat-lightbox-item'
				. ' data-full="' . esc_url( $full( $photo ) ) . '"'
				. ' data-caption="' . esc_attr( $alt ) . '"'
				. ' aria-label="' . esc_attr(
					sprintf(
						/* translators: %d: which photograph this is. */
						__( 'Photo %d', 'estat-os' ),
						$i + 2
					)
				) . '">'
				. $thumb
				. ( $last ? '<span class="estat-hero-more">+' . ( $total - 5 ) . '</span>' : '' )
				. '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$out .= '</div>';

		// Anything past the rail is listed for the lightbox as URLs only.
		if ( $total > 5 ) {
			$out .= '<div class="estat-sr" hidden>';
			foreach ( array_slice( $photos, 5 ) as $photo ) {
				$out .= '<span data-estat-lightbox-item data-full="' . esc_url( $full( $photo ) ) . '" data-caption="' . esc_attr( $alt ) . '"></span>';
			}
			$out .= '</div>';
		}

		return $out . '</figure>';
	}

	/**
	 * A download list — floor plans and brochures.
	 *
	 * @param array<int,array{id:int,title:string,url:string}> $files Files.
	 * @param string                                           $empty Message when there is nothing.
	 * @return string
	 */
	public static function documents( array $files, string $empty = '' ): string {
		$files = array_values( array_filter( $files ) );
		if ( ! $files ) {
			return '' === $empty ? '' : '<p class="estat-muted">' . esc_html( $empty ) . '</p>';
		}

		$out = '<ul class="estat-docs">';
		foreach ( $files as $file ) {
			$url   = (string) ( $file['url'] ?? '' );
			$title = (string) ( $file['title'] ?? '' );
			if ( '' === $url ) {
				continue;
			}
			if ( '' === $title ) {
				$title = basename( wp_parse_url( $url, PHP_URL_PATH ) ?: '' );
			}
			$out .= '<li><a class="estat-doc" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">'
				. '<span class="estat-doc-icon" aria-hidden="true">' . Icon::render( 'document', 18 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span class="estat-doc-name">' . esc_html( $title ) . '</span>'
				. '<span class="estat-doc-meta">' . esc_html__( 'Download', 'estat-os' ) . '</span>'
				. '</a></li>';
		}
		return $out . '</ul>';
	}

	/**
	 * A scannable tick grid — amenities, features, highlights.
	 *
	 * @param array<int,string> $items Items.
	 * @param string            $icon  Icon name.
	 * @return string
	 */
	public static function checkgrid( array $items, string $icon = 'check' ): string {
		$items = array_values( array_unique( array_filter( array_map( 'trim', $items ) ) ) );
		if ( ! $items ) {
			return '';
		}

		$out = '<ul class="estat-checkgrid">';
		foreach ( $items as $item ) {
			$out .= '<li class="estat-checkgrid-item">'
				. '<span class="estat-checkgrid-icon" aria-hidden="true">' . Icon::render( $icon, 15 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span>' . esc_html( (string) $item ) . '</span></li>';
		}
		return $out . '</ul>';
	}

	/* ======================================================================
	 * Projects
	 * ====================================================================== */

	/**
	 * One project card.
	 *
	 * The archives used to join developer, locality and price into a single
	 * string, which meant a card could not be styled, could not be reordered
	 * and silently lost whichever of the three was missing. Each fact is its
	 * own element here, printed only when the record holds it — a project
	 * with no price shows no price, not a dash.
	 *
	 * @param int   $project_id   Project ID.
	 * @param array<string,mixed> $args Optional: listing_count, eager, show_developer.
	 * @return string
	 */
	public static function project_card( int $project_id, array $args = array() ): string {
		$project = Projects::to_array( $project_id );
		if ( ! $project ) {
			return '';
		}
		if ( 'publish' !== (string) ( $project['status'] ?? '' ) && ! current_user_can( 'estat_manage_listings' ) ) {
			return '';
		}

		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$url        = (string) ( $project['url'] ?? '' );
		$title      = (string) ( $project['title'] ?? '' );
		$developer  = (string) ( $project['developer'] ?? '' );
		$stage      = (string) ( $project['stage_label'] ?? '' );
		$category   = (string) ( $project['category_label'] ?? '' );
		$price      = (string) ( $project['price_display'] ?? '' );
		$localities = array_values( array_filter( (array) ( $project['locality'] ?? array() ) ) );
		$locality   = $localities ? (string) $localities[0] : '';
		$cover_id   = (int) get_post_thumbnail_id( $project_id );
		$eager      = ! empty( $args['eager'] );
		$count      = isset( $args['listing_count'] ) ? (int) $args['listing_count'] : -1;

		ob_start();
		?>
		<article class="estat-card estat-project-card">
			<a class="estat-card-media is-project" href="<?php echo esc_url( $url ); ?>" tabindex="-1" aria-hidden="true">
				<?php if ( $cover_id > 0 ) : ?>
					<?php
					echo wp_get_attachment_image(
						$cover_id,
						'large',
						false,
						array(
							'class'    => 'estat-card-img',
							'alt'      => '',
							'loading'  => $eager ? 'eager' : 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 600px) 100vw, (max-width: 1024px) 50vw, 380px',
						)
					);
					?>
				<?php else : ?>
					<span class="estat-card-noimage estat-project-noimage" aria-hidden="true">
						<?php echo Icon::render( 'buildings', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</span>
				<?php endif; ?>
			</a>
			<?php if ( '' !== $stage ) : ?>
				<span class="estat-card-badge<?php echo 'ready' === (string) ( $project['stage'] ?? '' ) ? ' is-accent' : ''; ?>"><?php echo esc_html( $stage ); ?></span>
			<?php endif; ?>
			<div class="estat-card-body">
				<?php if ( '' !== $category ) : ?>
					<p class="estat-card-eyebrow"><?php echo esc_html( $category ); ?></p>
				<?php endif; ?>
				<h2 class="estat-card-title"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h2>
				<?php if ( '' !== $locality ) : ?>
					<p class="estat-card-locality">
						<?php echo Icon::render( 'map-pin', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( $locality ); ?></span>
					</p>
				<?php endif; ?>
				<?php if ( '' !== $developer ) : ?>
					<p class="estat-card-developer"><?php echo esc_html( $developer ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $price ) : ?>
					<p class="estat-card-price"><?php echo esc_html( $price ); ?></p>
				<?php endif; ?>
				<div class="estat-card-foot">
					<?php if ( $count > 0 ) : ?>
						<span class="estat-card-count">
							<?php
							printf(
								/* translators: %d: number of properties listed in this project. */
								esc_html( _n( '%d property', '%d properties', $count, 'estat-os' ) ),
								(int) $count
							);
							?>
						</span>
					<?php endif; ?>
					<span class="estat-card-link">
						<?php esc_html_e( 'View project', 'estat-os' ); ?>
						<?php echo Icon::render( 'arrow-right', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</span>
				</div>
			</div>
		</article>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A grid of project cards.
	 *
	 * Listing counts are asked for once for the whole page rather than once
	 * per card, which is the difference between one query and sixty.
	 *
	 * @param array<int,int> $project_ids Project IDs.
	 * @return string
	 */
	public static function project_grid( array $project_ids ): string {
		$project_ids = array_values( array_unique( array_filter( array_map( 'absint', $project_ids ) ) ) );
		if ( ! $project_ids ) {
			return '';
		}

		wp_enqueue_style( 'estat-public' );
		$counts = Projects::listing_counts( $project_ids );

		$out = '<div class="estat-grid estat-grid-projects">';
		foreach ( $project_ids as $i => $pid ) {
			$out .= self::project_card(
				$pid,
				array(
					'listing_count' => (int) ( $counts[ $pid ] ?? 0 ),
					'eager'         => $i < 3,
				)
			);
		}
		return $out . '</div>';
	}

	/**
	 * The project directory filter bar.
	 *
	 * Only filters the project records can actually answer are drawn: a
	 * dropdown that would return nothing on every project is a lie about the
	 * data, so it is not offered.
	 *
	 * @param string $action Form action URL.
	 * @return string
	 */
	public static function project_filters( string $action = '' ): string {
		$localities = get_terms(
			array(
				'taxonomy'               => Taxonomies::LOCALITY,
				'hide_empty'             => true,
				'number'                 => 200,
				'update_term_meta_cache' => false,
			)
		);
		$localities = ( ! is_wp_error( $localities ) && $localities ) ? $localities : array();

		$stages    = Vocabulary::project_statuses();
		$used      = self::project_stages_in_use();
		$stages    = array_intersect_key( $stages, array_flip( $used ) );

		$categories = Vocabulary::project_categories();
		$used_cats  = self::project_categories_in_use();
		$categories = array_intersect_key( $categories, array_flip( $used_cats ) );

		$developers = self::project_developers_in_use();
		$prices     = self::project_price_bands();

		// Nothing to narrow by — a filter bar of empty dropdowns is noise.
		if ( ! $localities && ! $stages && ! $categories && ! $developers && ! $prices ) {
			return '';
		}

		if ( '' === $action ) {
			$action = (string) get_post_type_archive_link( PostTypes::PROJECT );
		}

		$get = static function ( string $key ): string {
			if ( ! isset( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				return '';
			}
			$raw = wp_unslash( $_GET[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return sanitize_text_field( is_array( $raw ) ? (string) reset( $raw ) : (string) $raw );
		};

		ob_start();
		?>
		<form class="estat-filters" method="get" action="<?php echo esc_url( $action ); ?>" role="search">
			<div class="estat-filters-row">
				<?php if ( $localities ) : ?>
					<div class="estat-field">
						<label for="estat-p-locality"><?php esc_html_e( 'Locality', 'estat-os' ); ?></label>
						<select id="estat-p-locality" name="locality">
							<option value=""><?php esc_html_e( 'Anywhere', 'estat-os' ); ?></option>
							<?php foreach ( $localities as $term ) : ?>
								<option value="<?php echo esc_attr( (string) $term->slug ); ?>" <?php selected( $get( 'locality' ), (string) $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<?php if ( $developers ) : ?>
					<div class="estat-field">
						<label for="estat-p-developer"><?php esc_html_e( 'Developer', 'estat-os' ); ?></label>
						<select id="estat-p-developer" name="developer">
							<option value=""><?php esc_html_e( 'Any developer', 'estat-os' ); ?></option>
							<?php foreach ( $developers as $developer ) : ?>
								<option value="<?php echo esc_attr( $developer ); ?>" <?php selected( $get( 'developer' ), $developer ); ?>><?php echo esc_html( $developer ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<?php if ( $stages ) : ?>
					<div class="estat-field">
						<label for="estat-p-stage"><?php esc_html_e( 'Stage', 'estat-os' ); ?></label>
						<select id="estat-p-stage" name="stage">
							<option value=""><?php esc_html_e( 'Any stage', 'estat-os' ); ?></option>
							<?php foreach ( $stages as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'stage' ), $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<?php if ( $categories ) : ?>
					<div class="estat-field">
						<label for="estat-p-category"><?php esc_html_e( 'Type', 'estat-os' ); ?></label>
						<select id="estat-p-category" name="category">
							<option value=""><?php esc_html_e( 'Any type', 'estat-os' ); ?></option>
							<?php foreach ( $categories as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'category' ), $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<?php if ( $prices ) : ?>
					<div class="estat-field">
						<label for="estat-p-price"><?php esc_html_e( 'Budget', 'estat-os' ); ?></label>
						<select id="estat-p-price" name="price_band">
							<option value=""><?php esc_html_e( 'Any budget', 'estat-os' ); ?></option>
							<?php foreach ( $prices as $band ) : ?>
								<option value="<?php echo esc_attr( $band['key'] ); ?>" <?php selected( $get( 'price_band' ), $band['key'] ); ?>><?php echo esc_html( $band['label'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<div class="estat-filters-actions">
					<button type="submit" class="estat-btn is-accent"><?php esc_html_e( 'Apply', 'estat-os' ); ?></button>
					<?php if ( $get( 'locality' ) || $get( 'developer' ) || $get( 'stage' ) || $get( 'category' ) || $get( 'price_band' ) ) : ?>
						<a class="estat-btn is-ghost" href="<?php echo esc_url( $action ); ?>"><?php esc_html_e( 'Clear', 'estat-os' ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A complete project directory: filters, grid, pagination, empty state.
	 *
	 * @param array<string,mixed> $args Optional: per_page, filters, wrapper.
	 * @return string
	 */
	public static function projects_directory( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		/*
		 * There is no project page-size setting of its own yet, so the
		 * directory follows the property page size the office already sets,
		 * and a hook lets a site override it without a new screen.
		 */
		$per_page = (int) ( $args['per_page'] ?? 0 );
		if ( $per_page < 1 ) {
			$per_page = (int) Settings::get( 'listings_per_page', 12 );
		}

		/** Filter how many projects a directory page shows. */
		$per_page = (int) apply_filters( 'estat_projects_per_page', $per_page );

		if ( $per_page < 1 ) {
			$per_page = 12;
		}
		if ( $per_page > 60 ) {
			$per_page = 60;
		}

		$result = self::project_query( $args, $per_page );
		$ids    = $result['ids'];
		$total  = (int) $result['total'];

		$no_wrapper = isset( $args['wrapper'] ) && false === $args['wrapper'];

		ob_start();
		if ( ! $no_wrapper ) {
			echo '<div class="estat-directory estat-project-directory">';
		}

		if ( ! empty( $args['filters'] ) ) {
			echo self::project_filters( isset( $args['action'] ) ? (string) $args['action'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( ! $ids ) {
			$filtered = self::project_has_filters();
			echo self::empty_state(
				$filtered ? __( 'No projects match what you are looking for', 'estat-os' ) : __( 'No projects yet', 'estat-os' ),
				$filtered
					? __( 'Try widening your search, or clear the filters to see every project.', 'estat-os' )
					: __( 'Publish a project and it appears in this directory.', 'estat-os' ),
				'buildings',
				$filtered ? '<a class="estat-btn is-ghost" href="' . esc_url( (string) get_post_type_archive_link( PostTypes::PROJECT ) ) . '">' . esc_html__( 'Clear the filters', 'estat-os' ) . '</a>' : ''
			);
		} else {
			echo '<p class="estat-result-count">' . esc_html(
				sprintf(
					/* translators: %d: number of projects. */
					_n( '%d project', '%d projects', $total, 'estat-os' ),
					$total
				)
			) . '</p>';
			echo self::project_grid( $ids ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::pagination( (int) $result['page'], (int) $result['pages'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( ! $no_wrapper ) {
			echo '</div>';
		}
		return (string) ob_get_clean();
	}

	/**
	 * Run a project query honouring the directory filters.
	 *
	 * @param array<string,mixed> $args     Caller arguments.
	 * @param int                 $per_page Page size.
	 * @return array{ids:array<int,int>,total:int,page:int,pages:int}
	 */
	public static function project_query( array $args = array(), int $per_page = 12 ): array {
		$page = isset( $_GET['estat_page'] ) ? max( 1, (int) $_GET['estat_page'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$query_args = array(
			'post_type'           => PostTypes::PROJECT,
			'post_status'         => 'publish',
			'posts_per_page'      => $per_page,
			'paged'               => $page,
			'fields'              => 'ids',
			'no_found_rows'       => false,
			'ignore_sticky_posts' => true,
		);

		if ( ! empty( $args['stage'] ) ) {
			$query_args['meta_query'][] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				'key'     => '_estat_project_status',
				'value'   => sanitize_key( (string) $args['stage'] ),
				'compare' => '=',
			);
		}

		$meta_query = array( 'relation' => 'AND' );

		if ( ! empty( $args['developer'] ) ) {
			$meta_query[] = array(
				'key'     => '_estat_developer',
				'value'   => sanitize_text_field( (string) $args['developer'] ),
				'compare' => '=',
			);
		}

		$band = (string) ( $args['price_band'] ?? '' );
		if ( '' !== $band ) {
			foreach ( self::project_price_bands() as $candidate ) {
				if ( $candidate['key'] === $band ) {
					$meta_query[] = array(
						'key'     => '_estat_price_min',
						'value'   => array( $candidate['min'], $candidate['max'] ),
						'type'    => 'NUMERIC',
						'compare' => 'BETWEEN',
					);
					break;
				}
			}
		}

		if ( count( $meta_query ) > 1 ) {
			$query_args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		if ( ! empty( $args['category'] ) ) {
			$query_args['meta_query'][] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				'key'     => '_estat_category',
				'value'   => sanitize_key( (string) $args['category'] ),
				'compare' => '=',
			);
		}

		$tax_query = array();
		if ( ! empty( $args['locality'] ) ) {
			$tax_query[] = array(
				'taxonomy' => Taxonomies::LOCALITY,
				'field'    => 'slug',
				'terms'    => sanitize_title( (string) $args['locality'] ),
			);
		}
		if ( $tax_query ) {
			$query_args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		$q     = new \WP_Query( $query_args );
		$pages = max( 1, (int) $q->max_num_pages );

		return array(
			'ids'   => array_map( 'intval', (array) $q->posts ),
			'total' => (int) $q->found_posts,
			'page'  => $page,
			'pages' => $pages,
		);
	}

	/**
	 * Has the visitor narrowed the project directory at all?
	 *
	 * @return bool
	 */
	private static function project_has_filters(): bool {
		foreach ( array( 'locality', 'developer', 'stage', 'category', 'price_band' ) as $key ) {
			if ( ! empty( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				return true;
			}
		}
		return false;
	}

	/**
	 * Read the project directory filters out of the current request.
	 *
	 * One sanitised reader, so the archive template, the shortcode and any
	 * Elementor widget all narrow by the same keys with the same cleaning.
	 *
	 * @return array<string,string>
	 */
	public static function project_filters_from_request(): array {
		$keys = array(
			'locality'   => 'sanitize_title',
			'developer'  => 'sanitize_text_field',
			'stage'      => 'sanitize_key',
			'category'   => 'sanitize_key',
			'price_band' => 'sanitize_key',
		);

		$out = array();
		foreach ( $keys as $key => $cleaner ) {
			if ( empty( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a public filter, not a form submission.
				continue;
			}
			$raw = wp_unslash( $_GET[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( is_array( $raw ) ) {
				$raw = reset( $raw );
			}
			$value = call_user_func( $cleaner, (string) $raw );
			if ( '' !== $value ) {
				$out[ $key ] = $value;
			}
		}

		return $out;
	}

	/**
	 * Project stages that at least one published project is actually in.
	 *
	 * @return array<int,string>
	 */
	private static function project_stages_in_use(): array {
		$stages = get_transient( 'estat_project_stages' );
		if ( is_array( $stages ) ) {
			return $stages;
		}

		$stages = self::distinct_meta( '_estat_project_status' );
		set_transient( 'estat_project_stages', $stages, HOUR_IN_SECONDS );
		return $stages;
	}

	/**
	 * Project categories that at least one published project is actually in.
	 *
	 * @return array<int,string>
	 */
	private static function project_categories_in_use(): array {
		$categories = get_transient( 'estat_project_categories' );
		if ( is_array( $categories ) ) {
			return $categories;
		}

		$categories = self::distinct_meta( '_estat_category' );
		set_transient( 'estat_project_categories', $categories, HOUR_IN_SECONDS );
		return $categories;
	}

	/**
	 * Developers that at least one published project actually has.
	 *
	 * @return array<int,string>
	 */
	private static function project_developers_in_use(): array {
		$developers = get_transient( 'estat_project_developers' );
		if ( is_array( $developers ) ) {
			return $developers;
		}

		$developers = self::distinct_meta( '_estat_developer' );
		sort( $developers, SORT_NATURAL | SORT_FLAG_CASE );
		set_transient( 'estat_project_developers', $developers, HOUR_IN_SECONDS );
		return $developers;
	}

	/**
	 * The distinct non-empty values of a project meta key.
	 *
	 * One grouped query instead of loading every project to look at a field.
	 *
	 * @param string $meta_key Meta key.
	 * @return array<int,string>
	 */
	private static function distinct_meta( string $meta_key ): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DISTINCT pm.meta_value
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s
				   AND pm.meta_value <> ''
				   AND p.post_type = %s
				   AND p.post_status = 'publish'
				 ORDER BY pm.meta_value ASC
				 LIMIT 200",
				$meta_key,
				PostTypes::PROJECT
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$value = trim( (string) $row['meta_value'] );
			if ( '' !== $value ) {
				$out[] = $value;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Price bands for the project directory, in rupees.
	 *
	 * Bands are offered only when at least one published project falls inside
	 * them, so a dropdown is never a promise the data cannot keep.
	 *
	 * @return array<int,array{key:string,label:string,min:float,max:float}>
	 */
	public static function project_price_bands(): array {
		$bands = get_transient( 'estat_project_price_bands' );
		if ( is_array( $bands ) ) {
			return $bands;
		}

		$edges = array(
			array( 'under-50l', __( 'Under ₹50 Lakh', 'estat-os' ), 0, 5000000 ),
			array( '50l-1cr', __( '₹50 Lakh – ₹1 Crore', 'estat-os' ), 5000000, 10000000 ),
			array( '1cr-2cr', __( '₹1 – 2 Crore', 'estat-os' ), 10000000, 20000000 ),
			array( '2cr-5cr', __( '₹2 – 5 Crore', 'estat-os' ), 20000000, 50000000 ),
			array( '5cr-10cr', __( '₹5 – 10 Crore', 'estat-os' ), 50000000, 100000000 ),
			array( 'above-10cr', __( 'Above ₹10 Crore', 'estat-os' ), 100000000, 100000000000 ),
		);

		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_value AS price
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s
				   AND pm.meta_value > 0
				   AND p.post_type = %s
				   AND p.post_status = 'publish'",
				'_estat_price_min',
				PostTypes::PROJECT
			),
			ARRAY_A
		);
		// phpcs:enable

		$values = array();
		foreach ( (array) $rows as $row ) {
			$values[] = (float) $row['price'];
		}

		$bands = array();
		foreach ( $edges as $edge ) {
			list( $key, $label, $min, $max ) = $edge;
			foreach ( $values as $value ) {
				if ( $value >= $min && $value < $max ) {
					$bands[] = array(
						'key'   => $key,
						'label' => $label,
						'min'   => $min,
						'max'   => $max,
					);
					break;
				}
			}
		}

		set_transient( 'estat_project_price_bands', $bands, HOUR_IN_SECONDS );
		return $bands;
	}

	/* ======================================================================
	 * Interaction components
	 * ----------------------------------------------------------------------
	 * Each of these writes markup that is complete and usable on its own — a
	 * real link, a real button, real content in the document — and then hands
	 * the behaviour to assets/js/ui.js through data attributes. Nothing here
	 * needs JavaScript to make sense, and nothing here invents anything: a
	 * component with no data returns an empty string and its section is never
	 * drawn at all.
	 * ====================================================================== */

	/**
	 * Load the interaction layer.
	 *
	 * Called by a component only when that component is actually being drawn,
	 * so the script is never loaded "just in case".
	 *
	 * @return void
	 */
	private static function interact(): void {
		wp_enqueue_script( 'estat-ui' );
	}

	/**
	 * A jump list for the sections of a long page.
	 *
	 * The links are ordinary anchors, so with no script at all they still take
	 * the visitor where they say. ui.js adds smooth scrolling and marks the
	 * section currently under the reader's eye.
	 *
	 * @param array<int,array{id:string,label:string}> $sections Sections.
	 * @param string                                   $label    Accessible name.
	 * @return string
	 */
	public static function section_nav( array $sections, string $label = '' ): string {
		$sections = array_values( array_filter( $sections ) );
		if ( count( $sections ) < 2 ) {
			// One section is not a navigation; it is a heading.
			return '';
		}

		self::interact();

		if ( '' === $label ) {
			$label = __( 'On this page', 'estat-os' );
		}

		$out = '<nav class="estat-sectionnav" data-estat-section-nav aria-label="' . esc_attr( $label ) . '">';
		$out .= '<div class="estat-sectionnav-track">';
		foreach ( $sections as $i => $section ) {
			$id = (string) ( $section['id'] ?? '' );
			if ( '' === $id ) {
				continue;
			}
			$out .= '<a class="estat-sectionnav-link' . ( 0 === $i ? ' is-current' : '' ) . '" href="#' . esc_attr( $id ) . '"'
				. ( 0 === $i ? ' aria-current="true"' : '' ) . '>'
				. esc_html( (string) ( $section['label'] ?? '' ) ) . '</a>';
		}
		$out .= '</div></nav>';

		return $out;
	}

	/**
	 * A reading-progress line for a long page.
	 *
	 * Deliberately a hairline, not a dashboard. It tells the reader how far
	 * through the project they are and nothing else.
	 *
	 * @param string $track_id Element the progress is measured against.
	 * @return string
	 */
	public static function progress( string $track_id ): string {
		self::interact();
		return '<div class="estat-progress" data-estat-progress="' . esc_attr( $track_id ) . '" aria-hidden="true"><span></span></div>';
	}

	/**
	 * Long writing, shortened on screen but never in the document.
	 *
	 * The whole text is printed and stays in the HTML — this only limits how
	 * much is *visible* until the reader asks for the rest, so a search
	 * engine and a screen reader both still receive every word.
	 *
	 * @param string $html      The complete content.
	 * @param string $panel_id  Id for the panel, needed by aria-controls.
	 * @param int    $collapsed Visible height in pixels.
	 * @return string
	 */
	public static function read_more( string $html, string $panel_id, int $collapsed = 240 ): string {
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return '';
		}

		self::interact();

		$more = __( 'Read more', 'estat-os' );
		$less = __( 'Show less', 'estat-os' );

		return '<div class="estat-readmore" data-estat-readmore data-estat-readmore-height="' . (int) $collapsed . '">'
			. '<div class="estat-readmore-panel" id="' . esc_attr( $panel_id ) . '" data-estat-readmore-panel>' . $html . '</div>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<button type="button" class="estat-readmore-toggle" data-estat-readmore-toggle'
			. ' aria-expanded="false" aria-controls="' . esc_attr( $panel_id ) . '"'
			. ' data-label-more="' . esc_attr( $more ) . '" data-label-less="' . esc_attr( $less ) . '" hidden>'
			. '<span class="estat-readmore-label">' . esc_html( $more ) . '</span>'
			. Icon::render( 'chevron-down', 15 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '</button>'
			. '</div>';
	}

	/**
	 * A filter row, with the counts worked out beforehand.
	 *
	 * Every count is written here, on the server, from the real data — so the
	 * filter never promises six sports amenities and then shows two, and the
	 * browser never has to recount to say "All 18".
	 *
	 * @param array<int,array{value:string,label:string,count:int}> $groups  Groups.
	 * @param string                                                $scope_id Id of the element holding the items.
	 * @param string                                                $label    Accessible name.
	 * @return string
	 */
	public static function filter_bar( array $groups, string $scope_id, string $label = '' ): string {
		$groups = array_values( array_filter( $groups ) );
		if ( count( $groups ) < 2 ) {
			// One group is not a filter, it is a heading.
			return '';
		}

		self::interact();

		if ( '' === $label ) {
			$label = __( 'Filter', 'estat-os' );
		}

		$out = '<div class="estat-filterbar" data-estat-filter-bar data-estat-filter-scope="' . esc_attr( $scope_id ) . '" role="group" aria-label="' . esc_attr( $label ) . '">';
		foreach ( $groups as $i => $group ) {
			$value = (string) ( $group['value'] ?? '' );
			if ( '' === $value ) {
				continue;
			}
			$count = (int) ( $group['count'] ?? 0 );
			$out  .= '<button type="button" class="estat-filterbtn' . ( 0 === $i ? ' is-on' : '' ) . '"'
				. ' data-estat-filter="' . esc_attr( $value ) . '"'
				. ' aria-pressed="' . ( 0 === $i ? 'true' : 'false' ) . '">'
				. '<span>' . esc_html( (string) ( $group['label'] ?? '' ) ) . '</span>'
				. '<span class="estat-filterbtn-count">' . (int) $count . '</span>'
				. '</button>';
		}
		return $out . '</div>';
	}

	/**
	 * The three share actions people actually use.
	 *
	 * Share uses the browser's own share sheet where there is one and copies
	 * the link where there is not, so the row is never a wall of social
	 * buttons that nobody presses.
	 *
	 * @param string $url   Link to share.
	 * @param string $title Title to share.
	 * @return string
	 */
	public static function share_actions( string $url, string $title = '' ): string {
		if ( '' === $url ) {
			return '';
		}

		self::interact();

		if ( '' === $title ) {
			$title = (string) get_the_title();
		}

		$wa = '';
		$number = (string) preg_replace( '/\D+/', '', (string) Settings::get( 'whatsapp', '' ) );
		if ( '' !== $number ) {
			$wa = '<a class="estat-sharebtn is-wa" href="' . esc_url( 'https://wa.me/' . $number . '?text=' . rawurlencode( $title . ' — ' . $url ) ) . '"'
				. ' target="_blank" rel="noopener">'
				. Icon::render( 'whatsapp', 16 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span>' . esc_html__( 'WhatsApp', 'estat-os' ) . '</span></a>';
		}

		return '<div class="estat-sharebar">'
			. $wa
			. '<button type="button" class="estat-sharebtn" data-estat-copy="' . esc_attr( $url ) . '"'
			. ' data-label="' . esc_attr__( 'Copy link', 'estat-os' ) . '">'
			. Icon::render( 'share', 16 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<span class="estat-copy-label">' . esc_html__( 'Copy link', 'estat-os' ) . '</span></button>'
			. '<button type="button" class="estat-sharebtn" data-estat-share="' . esc_attr( $url ) . '"'
			. ' data-share-title="' . esc_attr( $title ) . '"'
			. ' data-label="' . esc_attr__( 'Copy link', 'estat-os' ) . '">'
			. Icon::render( 'external', 16 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<span class="estat-copy-label">' . esc_html__( 'Share', 'estat-os' ) . '</span></button>'
			. '</div>';
	}

	/**
	 * Media cards — a video, a tour, a brochure, a set of floor plans.
	 *
	 * A card is drawn for a thing the record actually holds. An empty card is
	 * worse than no card, so nothing here is drawn on the strength of hope.
	 *
	 * @param array<int,array{kind:string,label:string,url:string,note:string,icon:string}> $cards Cards.
	 * @return string
	 */
	public static function media_cards( array $cards ): string {
		$cards = array_values( array_filter( $cards ) );
		if ( ! $cards ) {
			return '';
		}

		self::interact();

		$out = '<ul class="estat-mediacards">';
		foreach ( $cards as $card ) {
			$url = (string) ( $card['url'] ?? '' );
			if ( '' === $url ) {
				continue;
			}
			$kind  = (string) ( $card['kind'] ?? 'link' );
			$label = (string) ( $card['label'] ?? '' );
			$note  = (string) ( $card['note'] ?? '' );
			$icon  = (string) ( $card['icon'] ?? ( 'video' === $kind ? 'play' : 'document' ) );

			/*
			 * A video or a tour is opened in place rather than sent away to
			 * another site; a document is a download and says so.
			 */
			$internal = in_array( $kind, array( 'video', 'tour' ), true );

			$tag  = $internal ? 'button' : 'a';
			$attr = $internal
				? ' type="button" data-estat-media="' . esc_attr( $kind ) . '" data-media-url="' . esc_attr( $url ) . '"'
				: ' href="' . esc_url( $url ) . '" target="_blank" rel="noopener"';

			$out .= '<li class="estat-mediacard is-' . esc_attr( $kind ) . '">'
				. '<' . $tag . ' class="estat-mediacard-btn"' . $attr . '>'
				. '<span class="estat-mediacard-icon" aria-hidden="true">' . Icon::render( $icon, 20 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span class="estat-mediacard-text"><span class="estat-mediacard-label">' . esc_html( $label ) . '</span>'
				. ( '' !== $note ? '<span class="estat-mediacard-note">' . esc_html( $note ) . '</span>' : '' )
				. '</span>'
				. Icon::render( 'arrow-right', 15 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '</' . $tag . '></li>';
		}
		return $out . '</ul>';
	}

	/**
	 * The facts grid, with room for a second line and an optional extra.
	 *
	 * A fact that needs explaining can carry a note, and the note is opened by
	 * a real button — not hidden behind a hover tooltip that a phone cannot
	 * reach and a keyboard cannot open.
	 *
	 * @param array<int,array{label:string,value:string,note:string}> $facts Facts.
	 * @return string
	 */
	public static function fact_grid( array $facts ): string {
		$facts = array_values( array_filter( $facts ) );
		if ( ! $facts ) {
			return '';
		}

		$out = '<div class="estat-facts estat-facts-grid">';
		$n   = 0;
		foreach ( $facts as $fact ) {
			$label = (string) ( $fact['label'] ?? '' );
			$value = (string) ( $fact['value'] ?? '' );
			if ( '' === $value ) {
				continue;
			}
			$note = (string) ( $fact['note'] ?? '' );
			$out .= '<div class="estat-fact">';
			$out .= '<div class="estat-fact-label">' . esc_html( $label ) . '</div>';
			$out .= '<div class="estat-fact-value is-normal">' . esc_html( $value ) . '</div>';
			if ( '' !== $note ) {
				++$n;
				$panel_id = 'estat-fact-note-' . $n;
				$btn_id   = 'estat-fact-btn-' . $n;
				$out     .= '<button type="button" class="estat-fact-more" data-estat-accordion'
					. ' id="' . esc_attr( $btn_id ) . '" aria-expanded="false" aria-controls="' . esc_attr( $panel_id ) . '">'
					. esc_html__( 'What this means', 'estat-os' )
					. Icon::render( 'chevron-down', 13 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. '</button>';
				$out     .= '<p class="estat-fact-note" id="' . esc_attr( $panel_id ) . '">' . esc_html( $note ) . '</p>';
			}
			$out .= '</div>';
		}
		return $out . '</div>';
	}

	/**
	 * Highlights as items a reader can scan and open.
	 *
	 * A highlight is one line the office wrote. Where the line reads as a
	 * heading with a detail after it, it is shown as both; where it is a
	 * single statement, it stays one. No wording is invented — the icon is
	 * chosen from the words the office actually used.
	 *
	 * @param array<int,string> $lines Highlight lines.
	 * @return string
	 */
	public static function highlight_grid( array $lines ): string {
		$lines = array_values( array_unique( array_filter( array_map( 'trim', $lines ) ) ) );
		if ( ! $lines ) {
			return '';
		}

		$out = '<ul class="estat-highlights">';
		foreach ( $lines as $line ) {
			$title = $line;
			$detail = '';

			// "Clubhouse with a swimming pool — seats 200" splits cleanly.
			foreach ( array( ' — ', ' – ', ' – ' ) as $sep ) {
				if ( false !== strpos( $line, $sep ) ) {
					$parts = explode( $sep, $line, 2 );
					$title = trim( $parts[0] );
					$detail = trim( $parts[1] );
					break;
				}
			}

			$out .= '<li class="estat-highlight">'
				. '<span class="estat-highlight-icon" aria-hidden="true">' . Icon::render( self::icon_for( $title ), 17 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span class="estat-highlight-text">'
				. '<span class="estat-highlight-title">' . esc_html( $title ) . '</span>'
				. ( '' !== $detail ? '<span class="estat-highlight-detail">' . esc_html( $detail ) . '</span>' : '' )
				. '</span></li>';
		}
		return $out . '</ul>';
	}

	/**
	 * Which icon belongs to a line the office wrote.
	 *
	 * Matched on the office's own words. Anything unmatched falls back to a
	 * plain check, which is honest: it says "this is a point" and no more.
	 *
	 * @param string $text Highlight text.
	 * @return string
	 */
	public static function icon_for( string $text ): string {
		$map = array(
			'pool'        => array( 'pool', 'swimming' ),
			'gym'         => array( 'gym', 'fitness' ),
			'cctv'        => array( 'cctv', 'camera', 'surveillance' ),
			'guard'       => array( 'security', 'gated', 'guard' ),
			'lift'        => array( 'lift', 'elevator' ),
			'parking'     => array( 'parking', 'car park' ),
			'tree'        => array( 'garden', 'green', 'park', 'landscap', 'tree' ),
			'road'        => array( 'road', 'highway', 'expressway', 'metro', 'connectivity' ),
			'drop'        => array( 'water', 'sewage', 'drainage', 'rain' ),
			'wifi'        => array( 'wi-fi', 'wifi', 'internet' ),
			'school'      => array( 'school' ),
			'hospital'    => array( 'hospital', 'clinic' ),
			'shop'        => array( 'shop', 'retail', 'market', 'commercial' ),
			'office'      => array( 'office', 'business', 'workspace' ),
			'sparkle'     => array( 'club', 'clubhouse', 'amphitheatre', 'hall' ),
			'lotus'       => array( 'yoga', 'meditation', 'spa' ),
			'sun'         => array( 'solar', 'sustainab' ),
			'team'        => array( 'community', 'society' ),
			'play'        => array( 'play', 'kids', 'children' ),
			'shield'      => array( 'fire', 'safety' ),
			'home'        => array( 'flat', 'apartment', 'villa', 'plot', 'floor' ),
			'certificate' => array( 'rera', 'licens', 'approved', 'registered' ),
			'bank'        => array( 'loan', 'bank' ),
		);

		$lower = strtolower( $text );
		foreach ( $map as $icon => $words ) {
			foreach ( $words as $word ) {
				if ( false !== strpos( $lower, $word ) ) {
					return (string) $icon;
				}
			}
		}

		/** Filter the icon chosen for a highlight line. */
		return (string) apply_filters( 'estat_highlight_icon', 'check-circle', $text );
	}

	/**
	 * Amenities of a project, grouped and counted.
	 *
	 * The amenity terms come from the project record. The *group* is decided
	 * here from the words of the term, which is a way of arranging data the
	 * office already entered — not a way of inventing any. A group with
	 * nothing in it is never offered, and the map is filterable.
	 *
	 * @param int $project_id Project ID.
	 * @return array{terms:array<int,object>,groups:array<string,array<int,string>>,labels:array<string,string>}
	 */
	public static function amenity_groups( int $project_id ): array {
		$terms = wp_get_object_terms( $project_id, Taxonomies::AMENITY );
		$terms = ( ! is_wp_error( $terms ) && $terms ) ? (array) $terms : array();

		$labels = array(
			'all'           => __( 'All', 'estat-os' ),
			'lifestyle'     => __( 'Lifestyle', 'estat-os' ),
			'sports'        => __( 'Sports', 'estat-os' ),
			'security'      => __( 'Security', 'estat-os' ),
			'infrastructure'=> __( 'Infrastructure', 'estat-os' ),
			'business'      => __( 'Business', 'estat-os' ),
			'outdoor'       => __( 'Outdoor', 'estat-os' ),
			'other'         => __( 'Other', 'estat-os' ),
		);

		$map = array(
			'pool'        => 'lifestyle',
			'gym'         => 'lifestyle',
			'spa'         => 'lifestyle',
			'club'        => 'lifestyle',
			'clubhouse'   => 'lifestyle',
			'yoga'        => 'lifestyle',
			'banquet'     => 'lifestyle',
			'library'     => 'lifestyle',
			'lounge'      => 'lifestyle',

			'badminton'   => 'sports',
			'tennis'      => 'sports',
			'basketball'  => 'sports',
			'cricket'     => 'sports',
			'football'    => 'sports',
			'squash'      => 'sports',
			'jogging'     => 'sports',
			'track'       => 'sports',
			'sports'      => 'sports',
			'playground'  => 'sports',

			'security'    => 'security',
			'cctv'        => 'security',
			'gated'       => 'security',
			'guard'       => 'security',
			'intercom'    => 'security',
			'fire'        => 'security',

			'power'       => 'infrastructure',
			'backup'      => 'infrastructure',
			'water'       => 'infrastructure',
			'sewage'      => 'infrastructure',
			'drainage'    => 'infrastructure',
			'lift'        => 'infrastructure',
			'elevator'    => 'infrastructure',
			'parking'     => 'infrastructure',
			'internet'    => 'infrastructure',
			'wi-fi'       => 'infrastructure',
			'solar'       => 'infrastructure',

			'office'      => 'business',
			'business'    => 'business',
			'conference'  => 'business',
			'meeting'     => 'business',
			'retail'      => 'business',
			'shop'        => 'business',

			'garden'      => 'outdoor',
			'park'        => 'outdoor',
			'lawn'        => 'outdoor',
			'terrace'     => 'outdoor',
			'balcony'     => 'outdoor',
			'green'       => 'outdoor',
			'plaza'       => 'outdoor',
		);

		/** Filter the amenity group a word belongs to. */
		$map = (array) apply_filters( 'estat_amenity_group_map', $map );
		/** Filter the group labels. */
		$labels = (array) apply_filters( 'estat_amenity_group_labels', $labels );

		$groups = array();
		foreach ( $terms as $term ) {
			$name  = (string) $term->name;
			$slug  = strtolower( (string) $term->slug );
			$group = 'other';

			foreach ( $map as $word => $bucket ) {
				if ( false !== strpos( $slug, (string) $word ) || false !== strpos( strtolower( $name ), (string) $word ) ) {
					$group = (string) $bucket;
					break;
				}
			}

			$groups[ $group ][] = $name;
		}

		/*
		 * The order the buttons appear in. "All" first and "Other" last —
		 * a category nobody chose is not the second thing a visitor should
		 * be offered. Everything else keeps the order the terms arrived in.
		 */
		$order  = array_keys( $labels );
		$order  = array_values( array_diff( $order, array( 'all', 'other' ) ) );
		$groups = array_merge(
			array_flip( $order ),
			$groups
		);
		$groups = array_filter( $groups, 'is_array' );
		if ( isset( $groups['other'] ) ) {
			$other = $groups['other'];
			unset( $groups['other'] );
			$groups['other'] = $other;
		}

		return array(
			'terms'  => $terms,
			'groups' => $groups,
			'labels' => $labels,
		);
	}

	/**
	 * A compact bar of actions that follows a phone screen.
	 *
	 * Only ever shown below the tablet width, and it stops before the bottom
	 * safe area so it never sits on top of a form field or the home gesture.
	 *
	 * @param array<int,array{kind:string,label:string,url:string}> $actions Actions.
	 * @return string
	 */
	public static function mobile_actions( array $actions ): string {
		$actions = array_values( array_filter( $actions ) );
		if ( ! $actions ) {
			return '';
		}

		$out = '<div class="estat-mobilebar" role="group" aria-label="' . esc_attr__( 'Enquire', 'estat-os' ) . '">';
		foreach ( $actions as $action ) {
			$url = (string) ( $action['url'] ?? '' );
			if ( '' === $url ) {
				continue;
			}
			$out .= '<a class="estat-mobilebar-btn is-' . esc_attr( (string) ( $action['kind'] ?? 'link' ) ) . '" href="' . esc_url( $url ) . '"'
				. ( 'wa' === (string) ( $action['kind'] ?? '' ) ? ' target="_blank" rel="noopener"' : '' ) . '>'
				. esc_html( (string) ( $action['label'] ?? '' ) )
				. '</a>';
		}
		return $out . '</div>';
	}
}
