<?php
/**
 * The agent pocket: the office, in a phone browser.
 *
 * The promise of this feature is one sentence — a person on site can add and
 * correct listings from their phone, and nothing reaches the website without
 * the office saying yes. Every assertion below is one way that sentence could
 * quietly stop being true: a guard someone forgot on a new route, a draft
 * that publishes itself, a pause that turns into a delete, an approval that
 * forgets the audit line, a stranger's inbox that isn't a stranger's.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Pocket\Actions;
use EstatOS\Pocket\Pocket;
use EstatOS\Pocket\Screens;

const IT32_AGENT = 21;   // Has office-lite caps; owns nothing at first.
const IT32_OTHER = 22;   // Another agent, with a private draft.

/**
 * The capability set a normal field agent carries (mirrors Roles::agent_caps()).
 *
 * @return string[]
 */
function estat_it32_agent_caps(): array {
	return array(
		'estat_manage_listings',
		'delete_post',
		'estat_request_listings',
		'estat_manage_leads',
		'estat_manage_visits',
		'estat_manage_insights',
		'estat_view_submissions',
		'estat_export_inventory',
	);
}

/**
 * Post a pocket form and report what happened.
 *
 * @param array<string,mixed> $fields Fields, estat_pocket_action included.
 * @param string              $view   The view the button sat on.
 * @param int                 $id     The record in the URL.
 * @return string The flash key from the redirect, 'err:<message>', or 'no-redirect'.
 */
function estat_it32_post( array $fields, string $view = '', int $id = 0 ): string {
	$fields['_estat_pocket'] = wp_create_nonce( 'estat_pocket' );

	$_POST    = $fields;
	$_REQUEST = $fields;
	$_GET     = array();

	try {
		Actions::run( $view, $id );
		return 'no-redirect';
	} catch ( Estat_Redirect_Exception $e ) {
		$loc = $e->getMessage();
		if ( preg_match( '/[?&]flash=([a-z_]+)/', $loc, $m ) ) {
			return $m[1];
		}
		if ( preg_match( '/[?&]err=([^&]+)/', $loc, $m ) ) {
			return 'err:' . rawurldecode( str_replace( '+', ' ', $m[1] ) );
		}
		return 'redirect:' . $loc;
	}
}

/**
 * Render a pocket screen to a string.
 *
 * @param string $view View slug.
 * @param int    $id   Record ID.
 * @return string
 */
function estat_it32_render( string $view, int $id = 0 ): string {
	$_GET = array();
	ob_start();
	try {
		Screens::render( $view, $id );
		return (string) ob_get_clean();
	} catch ( Estat_Redirect_Exception $e ) {
		ob_end_clean();
		return 'REDIRECT:' . $e->getMessage();
	}
}

/**
 * A listing by the current user, published, at a known price.
 *
 * @param string $status Post status.
 * @return int
 */
function estat_it32_mine( string $status = 'publish' ): int {
	$id = Listings::save(
		array(
			'title'       => 'Pocket test flat',
			'description' => 'Sea-facing.',
			'price'       => '7800000',
			'status'      => $status,
		)
	);
	return (int) $id;
}

estat_reset_world();
estat_login_owner();

// The agent record IT32_AGENT signs the pocket with. Leads and visits are
// carried by the agent post, not the user, so the world needs one.
$it32_agent_post = (int) wp_insert_post(
	array(
		'post_type'   => PostTypes::AGENT,
		'post_title'  => 'Rohan (pocket test)',
		'post_status' => 'publish',
	)
);
update_post_meta( $it32_agent_post, '_estat_user_id', IT32_AGENT );

$mine_pub = 0;

EstatTests::group( 'The door: no account, no data' );

estat_login_with( 0, array() );
$GLOBALS['estat_logged_in'] = false;

$html = estat_it32_render( '' );
EstatTests::ok( false !== strpos( $html, 'Agent pocket' ), 'the logged-out home is the sign-in page' );
EstatTests::ok(
false !== strpos( $html, 'assets/css/tokens.css?ver=' )
		&& false !== strpos( $html, 'assets/css/pocket.css?ver=' )
		&& strpos( $html, 'tokens.css' ) < strpos( $html, 'pocket.css' )
		&& strpos( $html, '<link' ) < strpos( $html, '</head>' ),
'both the shared tokens and the pocket sheet link in the head, tokens first every screen — live once came out unstyled because the queue never ran'
);
EstatTests::ok( false !== strpos( $html, 'wp-login.php' ), 'sign-in posts to WordPress itself — same accounts, no side door' );
EstatTests::ok( false !== strpos( $html, 'redirect_to' ), 'the redirect back to /agent is carried by the form' );
EstatTests::ok( false === strpos( $html, 'Pocket test flat' ), 'nothing about the office leaks onto the sign-in page' );

$html = estat_it32_render( 'listings' );
EstatTests::ok( false !== strpos( $html, 'wp-login.php' ), 'walking straight to /agent/listings logged out still shows only the sign-in' );

// A logged-in stranger with no office caps.
$GLOBALS['estat_logged_in'] = true;
estat_login_with( 9, array( 'read' ) );
$html = estat_it32_render( 'today' );
EstatTests::ok( false !== strpos( $html, 'not part of an office' ), 'a subscriber without office roles is told so, politely' );
EstatTests::ok( false === strpos( $html, 'estat-pocket-tabs' ), 'and is not given the tab bar either' );

EstatTests::group( 'An agent: sees, adds, and nothing escapes to the site' );

estat_login_with( IT32_AGENT, estat_it32_agent_caps() );

$html = estat_it32_render( '' );
EstatTests::ok( false !== strpos( $html, 'Good day' ), 'today greets an agent with caps' );

// Write an unreadable draft and see it refused with a sentence.
$flash = estat_it32_post(
	array(
		'estat_pocket_action' => 'save_draft',
		'record_id'           => 0,
		'title'               => '',
		'price'               => 'seven million',
		'estat_pocket_next'   => 'draft',
	)
);
EstatTests::ok( str_starts_with( $flash, 'err:' ), 'a draft with no title is refused, and the redirect carries the reason: ' . $flash );

// A real draft.
$flash = estat_it32_post(
	array(
		'estat_pocket_action' => 'save_draft',
		'record_id'           => 0,
		'title'               => 'Pocket studio, added from site',
		'offer'               => 'rent',
		'rent'                => '55000',
		'address'             => 'Worli',
		'bedrooms'            => '1',
		'bathrooms'           => '1',
		'body'                => 'Bright studio near the metro.',
		'estat_pocket_next'   => 'draft',
	)
);
EstatTests::ok( 'saved' === $flash, 'saving a draft works and says saved' );

$draft_id = 0;
$found    = get_posts(
	array(
		'post_type'   => PostTypes::LISTING,
		'post_status' => 'draft',
		'title'       => 'Pocket studio, added from site',
		'numberposts' => 1,
	)
);
if ( $found ) {
	$draft_id = (int) $found[0]->ID;
}
EstatTests::ok( $draft_id > 0, 'the draft exists in exactly the place wp-admin would create it' );
EstatTests::is( 'draft', (string) get_post_status( $draft_id ), 'it is a draft — the pocket never publishes' );
EstatTests::is( IT32_AGENT, (int) get_post_meta( $draft_id, '_estat_assigned_user', true ), 'the draft carries who typed it' );

// Send it for approval: still not on the site, now in the queue.
$flash = estat_it32_post(
	array( 'estat_pocket_action' => 'send', 'record_id' => $draft_id ),
	'listing',
	$draft_id
);
EstatTests::is( 'sent', $flash, 'the detail page can send a draft for approval' );
EstatTests::is( 'pending', (string) get_post_status( $draft_id ), 'pending is the queue state; publish belongs to the office' );

// Someone else's draft stays invisible and untouchable.
estat_login_with( IT32_OTHER, estat_it32_agent_caps() );
$their_draft = Listings::save( array( 'title' => 'Their draft', 'status' => 'draft' ) );
$their_draft = (int) $their_draft;
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );

$flash = estat_it32_post(
	array( 'estat_pocket_action' => 'save_draft', 'record_id' => $their_draft, 'title' => 'Hijacked', 'estat_pocket_next' => 'draft' ),
	'new',
	$their_draft
);
EstatTests::ok( str_starts_with( $flash, 'err' ) && false !== stripos( $flash, 'belongs to someone else' ), 'saving somebody else\'s draft is refused, by name: ' . $flash );
EstatTests::is( 'Their draft', (string) get_the_title( $their_draft ), 'and the title is still exactly what it was' );

$flash = estat_it32_post(
	array( 'estat_pocket_action' => 'trash_draft', 'record_id' => $their_draft ),
	'listing',
	$their_draft
);
EstatTests::ok( 'nope' === $flash || str_starts_with( $flash, 'err' ), 'removing another agent\'s draft is refused: ' . $flash );
EstatTests::ok( 'trash' !== (string) get_post_status( $their_draft ), 'it is still not in the bin' );

$html = estat_it32_render( 'listings' );
EstatTests::ok( false !== strpos( $html, 'Pocket studio, added from site' ), 'my own draft rows show in my listings' );
EstatTests::ok( false === strpos( $html, 'Their draft' ), 'another agent\'s private draft does not' );

EstatTests::group( 'Live records move only through a request' );

// The office publishes it; the pocket could never have. Then it is handed to
// the agent, and only from then on does the agent hold a live record.
estat_login_owner();
$mine_pub = estat_it32_mine( 'publish' );
update_post_meta( $mine_pub, '_estat_assigned_user', IT32_AGENT );
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
EstatTests::is( 'publish', (string) get_post_status( $mine_pub ), 'an agent cannot push a record to publish on their own — the office did this one' );

$html = estat_it32_render( 'listing', $mine_pub );
EstatTests::ok( false !== strpos( $html, 'Ask the office to change' ), 'my own live listing offers the request sheet' );
EstatTests::ok( false === strpos( $html, 'value="save_draft"' ), 'and not a direct editor for a live record' );
EstatTests::ok( false !== strpos( $html, 'go to the office first' ), 'the page explains why, on the detail itself' );

// Editing the draft of my live record must be refused even with the form.
$flash = estat_it32_post(
	array(
		'estat_pocket_action' => 'save_draft',
		'record_id'           => $mine_pub,
		'title'               => 'Sneaky title',
		'estat_pocket_next'   => 'draft',
	),
	'new',
	$mine_pub
);
EstatTests::ok( str_starts_with( $flash, 'err' ), 'the door says what the screen implied: live means queue: ' . $flash );
EstatTests::is( 'Pocket test flat', (string) get_the_title( $mine_pub ), 'the live title did not move' );

// A change request from the pocket, then the office settles it.
$flash = estat_it32_post(
	array(
		'estat_pocket_action' => 'request',
		'record_id'           => $mine_pub,
		'changes'             => array( 'price' => '7450000' ),
		'message'             => 'Owner agreed on call today.',
	),
	'change',
	$mine_pub
);
EstatTests::is( 'requested', $flash, 'the ask is filed' );

$queue = Requests::query( array( 'record_id' => $mine_pub, 'status' => 'pending', 'per_page' => 5 ) );
EstatTests::is( 1, count( $queue['items'] ), 'one pending request, exactly' );

$flash = estat_it32_post(
	array(
		'estat_pocket_action' => 'request',
		'record_id'           => $mine_pub,
		'changes'             => array( 'price' => '1000' ),
		'message'             => '',
	),
	'change',
	$mine_pub
);
EstatTests::ok( str_starts_with( $flash, 'err' ), 'a change without the one-line "how do you know" is sent back: ' . $flash );

// The office approves it from the pocket.
estat_login_owner();
$rid = (int) $queue['items'][0]['id'];
$flash = estat_it32_post( array( 'estat_pocket_action' => 'request_approve', 'request_id' => $rid ), 'approvals' );
EstatTests::is( 'approved', $flash, 'the office says yes from a phone' );
EstatTests::is( 7450000.0, (float) get_post_meta( $mine_pub, '_estat_price', true ), 'approved means written through, not just marked' );
EstatTests::is( 'publish', (string) get_post_status( $mine_pub ), 'and an approval never un-publishes the listing it approved a change on' );

// Decline path.
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
estat_it32_post(
	array(
		'estat_pocket_action' => 'request',
		'record_id'           => $mine_pub,
		'changes'             => array( 'rent' => '40000' ),
		'message'             => 'Landlord floated it.',
	),
	'change',
	$mine_pub
);
$queue = Requests::query( array( 'record_id' => $mine_pub, 'status' => 'pending', 'per_page' => 5 ) );
estat_login_owner();
$rid2 = (int) $queue['items'][0]['id'];
$flash = estat_it32_post(
	array( 'estat_pocket_action' => 'request_decline', 'request_id' => $rid2, 'reason' => 'Not yet.' ),
	'approvals'
);
EstatTests::is( 'declined', $flash, 'the office can say not-yet with a word' );
EstatTests::is( '', trim( (string) get_post_meta( $mine_pub, '_estat_rent', true ) ), 'a declined request changed nothing' );

// A non-office user cannot settle at all.
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$flash = estat_it32_post( array( 'estat_pocket_action' => 'request_approve', 'request_id' => $rid2 ), 'approvals' );
EstatTests::is( 'nope', $flash, 'an agent approving their own request: refused at the door' );

$html = estat_it32_render( 'approvals' );
EstatTests::ok( str_starts_with( $html, 'REDIRECT:' ) && false !== strpos( $html, 'flash=nope' ), 'a direct walk to /agent/approvals as an agent bounces, refused' );
$html = estat_it32_render( '' );
EstatTests::ok( false === strpos( $html, '>Approve<' ), 'the tab bar hides Approve from agents' );
estat_login_owner();
$html = estat_it32_render( '' );
EstatTests::ok( false !== strpos( $html, '>Approve<' ), 'and shows it to the office' );
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );

EstatTests::group( 'Pause is the only thing a phone may do to a live listing' );

estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$flash = estat_it32_post( array( 'estat_pocket_action' => 'pause', 'record_id' => $mine_pub ), 'listing', $mine_pub );
EstatTests::is( 'paused', $flash, 'pause, own listing, from a phone' );
EstatTests::is( 'private', (string) get_post_status( $mine_pub ), 'hidden from the site, not deleted' );

$flash = estat_it32_post( array( 'estat_pocket_action' => 'resume', 'record_id' => $mine_pub ), 'listing', $mine_pub );
EstatTests::is( 'resumed', $flash, 'and it comes back' );
EstatTests::is( 'publish', (string) get_post_status( $mine_pub ), 'live again' );

$flash = estat_it32_post( array( 'estat_pocket_action' => 'pause', 'record_id' => $their_draft ), 'listing', $their_draft );
EstatTests::ok( 'nope' === $flash || str_starts_with( $flash, 'err' ), 'pausing someone else\'s listing: refused' );

$flash = estat_it32_post( array( 'estat_pocket_action' => 'trash_draft', 'record_id' => $mine_pub ), 'listing', $mine_pub );
EstatTests::ok( str_starts_with( $flash, 'err' ), 'deleting a live listing from the phone: refused outright: ' . $flash );
EstatTests::ok( false !== stripos( $flash, 'pause' ), 'the refusal names the safe path' );

// The agent's own draft may die. (The real agent role carries
// delete_estat_listing; the harness resolves the primitive name, so the
// capability list spells it.)
$doomed = (int) Listings::save( array( 'title' => 'Doomed draft', 'status' => 'draft' ) );
update_post_meta( $doomed, '_estat_assigned_user', IT32_AGENT );
$flash = estat_it32_post( array( 'estat_pocket_action' => 'trash_draft', 'record_id' => $doomed ), 'listing', $doomed );
EstatTests::is( 'trashed', $flash, 'own draft, own bin' );
EstatTests::is( 'trash', (string) get_post_status( $doomed ), 'in the bin, recoverable for thirty days' );

EstatTests::group( 'Inbox: mine, or all of it, never theirs' );

estat_login_owner();
$listing_for_lead = (int) Listings::save( array( 'title' => 'Lead flat', 'status' => 'draft' ) ); // publish would need photographs; this record only holds the lead.
$lead = Leads::create(
	array(
		'name'       => 'Meera Test',
		'phone'      => '9800000000',
		'email'      => 'meera@example.test',
		'message'    => 'Balcony?',
		'listing_id' => $listing_for_lead,
	)
);
EstatTests::ok( ! is_wp_error( $lead ), 'a lead exists to test with' . ( is_wp_error( $lead ) ? ': ' . $lead->get_error_message() : '' ) );
$lead = (int) $lead;

// It is unassigned and on the office's listing: an agent may not roam it.
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$html = estat_it32_render( 'inbox' );
EstatTests::ok( false === strpos( $html, 'Meera Test' ), 'an agent cannot see the office\'s unassigned enquiries' );

$flash = estat_it32_post( array( 'estat_pocket_action' => 'lead_update', 'lead_id' => $lead, 'status' => 'contacted' ), 'enquiry', $lead );
EstatTests::is( 'nope', $flash, 'and cannot touch them either' );

// Give it to the agent: now it appears and the actions work.
estat_login_owner();
global $wpdb;
$table = EstatOS\Install\Schema::table( 'estat_leads' );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->update( $table, array( 'agent_id' => $it32_agent_post ), array( 'id' => $lead ) );

estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$html = estat_it32_render( 'inbox' );
EstatTests::ok( false !== strpos( $html, 'Meera Test' ), 'a lead carried by my agent record shows in my inbox' );
$html = estat_it32_render( 'enquiry', $lead );
EstatTests::ok( false !== strpos( $html, 'Meera Test' ) && false !== strpos( $html, 'tel:' ), 'its enquiry page opens with the call link' );

estat_login_with( IT32_OTHER, estat_it32_agent_caps() );
$html = estat_it32_render( 'inbox' );
EstatTests::ok( false === strpos( $html, 'Meera Test' ), 'and to no other agent' );

estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$flash = estat_it32_post( array( 'estat_pocket_action' => 'lead_update', 'lead_id' => $lead, 'status' => 'contacted', 'notes' => 'Called back.' ), 'enquiry', $lead );
EstatTests::is( 'note', $flash, 'status and note save together' );
$after = Leads::get( $lead );
EstatTests::is( 'contacted', (string) $after['status'], 'the status moved' );

// Nonce discipline.
$_POST = array(
	'estat_pocket_action' => 'pause',
	'record_id'           => $mine_pub,
	'_estat_pocket'       => 'not-a-nonce',
);
$_REQUEST = $_POST;
try {
	Actions::run( 'listing', $mine_pub );
	EstatTests::ok( false, 'a forged nonce must throw its refusal redirect' );
} catch ( Estat_Redirect_Exception $e ) {
	EstatTests::ok( false !== strpos( $e->getMessage(), 'flash=nope' ) || false !== strpos( $e->getMessage(), 'flash=bad' ), 'a forged nonce is refused' );
}
EstatTests::is( 'publish', (string) get_post_status( $mine_pub ), 'and nothing happened' );

EstatTests::group( 'The pocket obeys the design law too' );

$pocket_css = (string) file_get_contents( dirname( __DIR__, 2 ) . '/assets/css/pocket.css' );
$tokens_px  = (string) file_get_contents( dirname( __DIR__, 2 ) . '/assets/css/tokens.css' );

// Contrast: light block, all ink colours, all surfaces — the same floor.
$light_px = substr( $tokens_px, 0, strpos( $tokens_px, 'prefers-color-scheme: dark' ) );
$dark_px  = substr( $tokens_px, strpos( $tokens_px, 'prefers-color-scheme: dark' ) );

foreach ( array( 'light' => $light_px, 'dark' => $dark_px ) as $name => $block ) {
	$worst = 99.0;
	$worst_pair = '';
	foreach ( array( 'ink', 'ink-soft', 'muted', 'good', 'warn', 'danger', 'accent-ink' ) as $ink ) {
		$a = estat_it23_token( $block, $ink );
		if ( '' === $a ) {
			EstatTests::ok( false, 'pocket ' . $name . ' defines --estat-' . $ink );
			continue;
		}
		foreach ( array( 'bg', 'card', 'card-alt', 'sunken', 'accent-soft', 'good-soft', 'warn-soft', 'danger-soft' ) as $surf ) {
			$b = estat_it23_token( $block, $surf );
			if ( '' === $b ) {
				continue;
			}
			$r = estat_it23_contrast( $a, $b );
			if ( $r < $worst ) {
				$worst = $r;
				$worst_pair = $ink . ' on ' . $surf;
			}
		}
	}
	EstatTests::ok( $worst >= 4.5, 'pocket ' . $name . ': every text-on-surface pair clears 4.5:1 (loosest ' . $worst_pair . ' at ' . round( $worst, 2 ) . ')' );

	$on   = estat_it23_token( $block, 'on-accent' );
	$acc  = estat_it23_token( $block, 'accent' );
	EstatTests::ok(
	estat_it23_contrast( $on, $acc ) >= 4.5,
	'pocket ' . $name . ': the button label clears 4.5:1 on the accent (' . round( estat_it23_contrast( $on, $acc ), 2 ) . ')'
	);
}

// One design language used to mean "value for value in two files". Since
// Part 1 that is too weak: there is one file now, so the office sheet must
// not restate a single palette value. If someone pastes a colour back into
// admin.css to "fix" one screen, this fails - and it should.
$admin_css = (string) file_get_contents( dirname( __DIR__, 2 ) . '/assets/css/admin.css' );
$drift     = array();
foreach ( array( 'ink', 'ink-soft', 'muted', 'faint', 'bg', 'card', 'card-alt', 'sunken', 'line', 'line-strong', 'accent', 'accent-soft', 'accent-ink', 'on-accent', 'good', 'good-soft', 'warn', 'warn-soft', 'danger', 'danger-soft' ) as $tok ) {
	if ( preg_match( '/--estat-' . $tok . '\s*:/', $admin_css ) ) {
		$drift[] = $tok;
	}
}
EstatTests::is( array(), $drift, 'no palette value survives in admin.css - the one token home is tokens.css (restated: ' . implode( ', ', $drift ) . ')' );

// No raw colour outside the pocket's own token blocks.
$lines     = explode( "\n", $pocket_css );
$blocks    = array();
// The sheet owns no blocks any more; every line is fair game for the
// leak scan below, which is exactly the point.
foreach ( array() as $anchor ) {
	$start = array_search( $anchor, array_map( 'trim', $lines ), true );
	if ( false === $start ) {
		continue;
	}
	$depth = 0;
	for ( $i = $start; $i < count( $lines ); $i++ ) {
		$depth += substr_count( $lines[ $i], '{' ) - substr_count( $lines[ $i], '}' );
		if ( 0 === $depth && $i > $start ) {
			$blocks[] = array( $start, $i );
			break;
		}
	}
}
$leaks = array();
foreach ( $lines as $i => $l ) {
	if ( ! preg_match( '/#[0-9a-fA-F]{3,8}\b/', $l ) ) {
		continue;
	}
	foreach ( $blocks as $b ) {
		if ( $i >= $b[0] && $i <= $b[1] ) {
			continue 2;
		}
	}
	$leaks[] = ( $i + 1 );
}
EstatTests::ok( empty( $leaks ), 'pocket.css keeps no colour outside a token block — and owns no token block (leak lines: ' . implode( ', ', $leaks ) . ')' );
EstatTests::is(
	0,
	preg_match_all( '/--estat-[a-z-]+\s*:/', $pocket_css ),
	'pocket.css defines no token of its own - it borrows the shared home'
);
EstatTests::ok(
	(bool) preg_match( '/\.estat-dash,\s*\.estat-pocket \{/', $tokens_px ),
	'the shared token block lists .estat-pocket beside .estat-screen - one home, verified'
);

// The type scale is the same seven steps, so the pocket cannot invent sizes.
preg_match_all( '/--estat-text[a-z0-9-]*:\s*(\d+)px/', $tokens_px, $steps );
$scale = array_map( 'intval', $steps[1] );
EstatTests::ok( count( $scale ) <= 8 && count( $scale ) >= 7, 'the pocket carries a real scale, ' . count( $scale ) . ' steps' );
EstatTests::is( count( $scale ), count( array_unique( $scale ) ), 'no duplicated scale step' );

// No emoji anywhere near the pocket, and every icon it names exists.
$php_files = glob( dirname( __DIR__, 2 ) . '/includes/Pocket/*.php' );
$emoji     = 0;
foreach ( $php_files as $f ) {
	$emoji += preg_match_all( '/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', (string) file_get_contents( $f ) );
}
EstatTests::is( 0, $emoji, 'no emoji in the pocket code' );

foreach ( array( 'home', 'list-checks', 'form', 'inbox', 'check-circle', 'chevron-right', 'external', 'eye', 'image', 'key', 'lock', 'phone', 'whatsapp', 'calendar', 'search' ) as $n ) {
	EstatTests::ok( EstatOS\Support\Icon::has( $n ), 'the pocket only asks for icons that exist: ' . $n );
}

EstatTests::group( 'The office side of the pocket: approvals that behave' );

estat_login_owner();

// Approving a proposal puts it live through the normal path — the audit row
// must exist, because approvals from a phone still have to leave a paper
// trail an office can read.
$proposed = (int) Listings::save( array( 'title' => 'Agent proposal', 'status' => 'pending' ) );
$flash    = estat_it32_post( array( 'estat_pocket_action' => 'listing_approve', 'record_id' => $proposed ), 'approvals' );
EstatTests::is( 'listed', $flash, 'approve from the pocket' );
EstatTests::is( 'publish', (string) get_post_status( $proposed ), 'and it is on the website' );

$audit = AuditLog::query( array( 'action' => 'listing.published', 'per_page' => 20 ) );
$saw   = false;
foreach ( $audit['items'] as $row ) {
	if ( (int) $row['object_id'] === $proposed ) {
		$saw = true;
	}
}
EstatTests::ok( $saw, 'the audit trail records the pocket approval like any other' );

// An agent cannot wave their own proposal through.
estat_login_with( IT32_AGENT, estat_it32_agent_caps() );
$another = (int) Listings::save( array( 'title' => 'Another proposal', 'status' => 'pending' ) );
$flash   = estat_it32_post( array( 'estat_pocket_action' => 'listing_approve', 'record_id' => $another ), 'approvals' );
EstatTests::is( 'nope', $flash, 'agents cannot self-publish from the pocket' );
EstatTests::is( 'pending', (string) get_post_status( $another ), 'still queued' );

// The route vocabulary is closed: only known views render.
EstatTests::ok( ! isset( Pocket::views()['secrets'] ), 'there is no /agent/secrets' );
EstatTests::ok( isset( Pocket::views()['approvals'] ), 'approvals is a real view' );
EstatTests::ok( in_array( 'listing_approve', Actions::ACTIONS, true ), 'the action list is the whole action list' );
EstatTests::ok( ! in_array( 'delete_live_listing', Actions::ACTIONS, true ), 'no such button exists anywhere' );
