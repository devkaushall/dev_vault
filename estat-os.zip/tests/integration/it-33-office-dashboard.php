<?php
/**
 * The office dashboard — Part 2 of the board: Today and Approvals.
 *
 * The pocket proved the standalone-print pattern on phones; the dashboard
 * is the same trick at desk size. What this file guards is the promise
 * behind the pretty: the dashboard decides nothing on its own. Approving
 * here is approving in the queue — the same Requests::approve(), the same
 * audit, the same undo. And the design law is not optional at this size
 * either: one token home, real breakpoints, no emoji, no raw colours.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Office\Dashboard;
use EstatOS\Office\Screens;
use EstatOS\Support\Icon;

estat_reset_world();

const IT33_AGENT = 31; // A normal agent: pocket yes, office no.

/**
 * Caps that do not make someone office: no publish, no review, no settings.
 *
 * @return string[]
 */
function estat_it33_agent_caps(): array {
	return array(
		'estat_manage_listings',
		'delete_post',
		'estat_request_listings',
		'estat_manage_leads',
		'estat_manage_visits',
	);
}

/**
 * Render a dashboard view in-process, reporting redirects like the pocket
 * tests do.
 *
 * @param string $view View slug.
 * @return string
 */
function estat_it33_render( string $view = '' ): string {
	$_GET = array();
	ob_start();
	try {
		Screens::render( $view, 0 );
		return (string) ob_get_clean();
	} catch ( Estat_Redirect_Exception $e ) {
		ob_end_clean();
		return 'REDIRECT:' . $e->getMessage();
	}
}

/**
 * Press a dashboard button in-process.
 *
 * @param array<string,mixed> $fields Form fields (request_id etc; the
 *                                    nonce is added here).
 * @return string The flash key from the redirect, or 'no-redirect'.
 */
function estat_it33_post( array $fields ): string {
	$fields['_estat_office'] = wp_create_nonce( Dashboard::NONCE );

	$_POST    = $fields;
	$_REQUEST = $fields;
	$_GET     = array();

	try {
		Dashboard::post();
		return 'no-redirect';
	} catch ( Estat_Redirect_Exception $e ) {
		$loc = $e->getMessage();
		if ( preg_match( '/[?&]flash=([a-z_]+)/', $loc, $m ) ) {
			return $m[1];
		}
		return 'redirect:' . $loc;
	}
}

/**
 * A live listing owned by the office, at a known price, with the three
 * photos validation wants on the way to publish.
 *
 * @return int
 */
function estat_it33_listing(): int {
	$id = Listings::save(
		array(
			'title'       => 'Dashboard test flat',
			'description' => 'Sea-facing, bright, honest price.',
			'price'       => '7800000',
			'status'      => 'publish',
		)
	);
	return (int) $id;
}

/* ---------------------------------------------------------------------- */

EstatTests::group( 'A door that knows its visitors' );

estat_login_with( 0, array() );
EstatTests::is( 'login', Dashboard::gate(), 'a stranger at /dashboard reads as a login case' );

$logged_out = estat_it33_render( '' );
EstatTests::ok( false !== strpos( $logged_out, 'Sign in to open the office' ), 'the stranger gets a plain sign-in page, not a crash' );
EstatTests::ok( false !== strpos( $logged_out, 'wp-login.php' ), 'and it points at the real WordPress login' );

estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
EstatTests::is( 'office-only', Dashboard::gate(), 'an agent is refused the office, politely' );
$agent_page = estat_it33_render( '' );
EstatTests::ok( false !== strpos( $agent_page, 'This is the office side' ), 'the refusal explains itself' );
EstatTests::ok( false !== strpos( $agent_page, 'agent' ), 'and hands the agent to the pocket' );
EstatTests::ok( false === strpos( $agent_page, 'Yes, change it' ), 'no queue leaks past the door' );

estat_login_owner();
EstatTests::is( '', Dashboard::gate(), 'the office walks straight in' );

EstatTests::group( 'Today is a work list, not a mural' );

$today = estat_it33_render( '' );
EstatTests::ok( false !== strpos( $today, 'Needs you' ), 'the queue heading is literally what it is for' );
EstatTests::ok( false !== strpos( $today, 'approvals queue is empty' ), 'with nothing waiting, today says so' );
EstatTests::ok( false !== strpos( $today, 'No enquiry is sitting unanswered' ), 'and the enquiries row tells the truth too' );
EstatTests::ok( false !== strpos( $today, 'Nothing is waiting to go live' ), 'and the publish row as well' );
EstatTests::ok( false === strpos( $today, 'KPI' ) && substr_count( $today, 'class="dstat' ) === 0, 'no number-mural cards anywhere' );

EstatTests::group( 'The queue shows what the office can settle' );

$listing = estat_it33_listing();

// Requests are the agents' door — the office edits directly, so a request
// must be filed as one (it-31 pinned that rule; it applies to the fixtures
// here just as much).
estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
$rid = (int) Requests::create(
	array(
		'record_id' => $listing,
		'changes'   => array(
			'price' => 8200000,
			'note'  => 'Owner agreed on the call.',
		),
		'message'   => 'Owner agreed on the call.',
	)
);
EstatTests::ok( $rid > 0, 'a change request exists to be seen' );
estat_login_owner();

$queue = estat_it33_render( 'requests' );
EstatTests::ok( false !== strpos( $queue, 'Dashboard test flat' ), 'the card names the property' );
EstatTests::ok( false !== strpos( $queue, '<s>' ), 'the old price is struck through' );
EstatTests::ok( (bool) preg_match( '/<s>[^<]*78/', $queue ), 'the struck-through figure carries the old price' );
EstatTests::ok( (bool) preg_match( '/82[.,\d]*/', $queue ), 'and a figure with the new price appears' );
EstatTests::ok( false !== strpos( $queue, 'Yes, change it' ), 'and the two buttons are there' );
EstatTests::ok( false !== strpos( $queue, '_estat_office' ), 'each form carries its own nonce field' );
EstatTests::ok( false !== strpos( $queue, 'request_decline' ) && false !== strpos( $queue, 'name="reason"' ), 'decline carries a reason field for the agent' );
EstatTests::ok( false !== strpos( $queue, 'Owner agreed on the call.' ), 'the agent\'s note rides along' );

$today2 = estat_it33_render( '' );
EstatTests::ok( false !== strpos( $today2, '1 change request' ), 'today counts the queue honestly' );
EstatTests::ok( false !== strpos( $today2, '/dashboard/requests/' ), 'and links to it' );

EstatTests::group( 'Buttons that actually decide' );

$flash = estat_it33_post(
	array(
		'estat_office_action' => 'request_approve',
		'request_id'          => $rid,
	)
);
EstatTests::is( 'approved', $flash, 'approve answers with a flash key' );
$after = Requests::get( $rid );
EstatTests::is( 'approved', $after['status'] ?? '', 'the queue row closed' );
EstatTests::ok(
	false !== strpos( estat_it33_render( 'requests' ), 'The queue is empty.' ),
	'and the dashboard reflects the truth it reads'
);
$live = get_post( $listing );
EstatTests::is( 'publish', $live->post_status ?? '', 'a live listing stays live through approval' );

estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
$rid2 = (int) Requests::create(
	array(
		'record_id' => $listing,
		'changes'   => array( 'price' => 9900000 ),
	)
);
estat_login_owner();
$flash2 = estat_it33_post(
	array(
		'estat_office_action' => 'request_decline',
		'request_id'          => $rid2,
		'reason'              => 'Photographs are too blurry.',
	)
);
EstatTests::is( 'declined', $flash2, 'decline answers too' );
$dec = Requests::get( $rid2 );
EstatTests::is( 'declined', $dec['status'] ?? '', 'the row closed as declined' );
EstatTests::is( 'Photographs are too blurry.', $dec['reason'] ?? '', 'and the reason was kept' );
$meta = (string) get_post_meta( $listing, '_estat_price', true );
EstatTests::ok(
	false === strpos( $meta, '9900000' ) && 0 === strpos( $meta, '8200000' ),
	'the approved price stands and the declined one never touched the listing (price: ' . $meta . ')'
);

EstatTests::group( 'Bad clicks are refused' );

estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
$rid3 = (int) Requests::create( array( 'record_id' => $listing, 'changes' => array( 'price' => 5000000 ) ) );
estat_login_owner();
$_POST  = array(
	'_estat_office'       => 'not-a-nonce',
	'estat_office_action' => 'request_approve',
	'request_id'          => $rid3,
);
$_GET  = array();
$badgy = 'no-redirect';
try {
	Dashboard::post();
} catch ( Estat_Redirect_Exception $e ) {
	$badgy = false !== strpos( $e->getMessage(), 'nope' ) ? 'nope' : 'redirect:' . $e->getMessage();
}
EstatTests::is( 'nope', $badgy, 'a stale form bounces with a plain refusal' );
EstatTests::is( 'pending', Requests::get( $rid3 )['status'] ?? '', 'and nothing moved' );

estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
$agent_flash = estat_it33_post(
	array(
		'estat_office_action' => 'request_approve',
		'request_id'          => $rid3,
	)
);
EstatTests::is( 'nope', $agent_flash, 'an agent with a forged click still gets nothing' );
EstatTests::is( 'pending', Requests::get( $rid3 )['status'] ?? '', 'the request is still there for the office' );

estat_login_owner();
EstatTests::is( 'approved', estat_it33_post( array( 'estat_office_action' => 'request_approve', 'request_id' => $rid3 ) ), 'the same click as office lands' );

EstatTests::group( 'Routing plays by WordPress rules' );

EstatTests::is( array( '', 'listings', 'requests' ), array_keys( Dashboard::views() ), 'three views: Today, Listings, Approvals' );
Dashboard::add_rewrites();
EstatTests::ok( true, 'the rewrite step survives a CLI context without exploding' );
$vars = Dashboard::query_vars( array( 'post' ) );
EstatTests::ok( in_array( 'estat_office_view', $vars, true ) && in_array( 'estat_office_id', $vars, true ), 'its query vars are registered' );
EstatTests::is( false, Dashboard::serving(), 'and it claims nothing outside its own URLs' );
EstatTests::ok( str_ends_with( Dashboard::url( 'requests' ), '/dashboard/requests/' ), 'URLs read like the routes' );

EstatTests::group( 'Part 3: the listings desk, same rules in a wider shape' );

$pending_id = (int) Listings::save(
	array(
		'title'       => 'Sunrise Arcade shop',
		'description' => 'Corner shop, high footfall, honest rent.',
		'offer'       => 'rent',
		'rent'        => 55000,
		'status'      => 'pending',
	)
);
EstatTests::ok( $pending_id > 0, 'a listing waits for the office' );

$live = estat_it33_render( 'listings' );
EstatTests::ok( false !== strpos( $live, 'Dashboard test flat' ), 'the live filter shows the live flat' );
EstatTests::ok( false === strpos( $live, 'Sunrise Arcade shop' ), 'and keeps the waiting one out of sight' );
EstatTests::ok( false !== strpos( $live, 'post-new.php?post_type=estat_listing' ), 'Add-a-listing opens the real editor, not a fake form' );
EstatTests::ok( false !== strpos( $live, '?f=waiting' ), 'the filter row links to the states that exist' );

$_GET = array( 'f' => 'waiting' );
ob_start();
Screens::render( 'listings', 0 );
$waiting = (string) ob_get_clean();
$_GET   = array();
EstatTests::ok( false !== strpos( $waiting, 'Sunrise Arcade shop' ), 'the waiting filter finds it' );
EstatTests::ok( false !== strpos( $waiting, 'listing_publish' ), 'with a button that can publish' );
EstatTests::ok( false !== strpos( $waiting, 'listing_return' ), 'and one that can send it back' );
EstatTests::ok( false !== strpos( $waiting, '_estat_office' ), 'each carrying the shared nonce' );
$money_expect = \EstatOS\Support\Format::money( 55000.0 );
EstatTests::ok( false !== strpos( $waiting, $money_expect ), 'the rent is shown in the money column (' . $money_expect . ')' );

EstatTests::is( 'listed', estat_it33_post( array( 'estat_office_action' => 'listing_publish', 'record_id' => $pending_id ) ), 'publish lands with a plain word' );
$after_publish = get_post( $pending_id );
EstatTests::is( 'publish', $after_publish->post_status, 'and the listing is really live' );

$audit = AuditLog::query( array( 'action' => 'listing.published', 'per_page' => 20 ) );
$seen  = false;
foreach ( $audit['items'] ?? $audit as $row ) {
	if ( false !== strpos( print_r( $row, true ), (string) $pending_id ) && false !== strpos( print_r( $row, true ), 'dashboard' ) ) {
		$seen = true;
	}
}
EstatTests::ok( $seen, 'the audit trail knows this publish came from the dashboard' );

EstatTests::is( 'stale', estat_it33_post( array( 'estat_office_action' => 'listing_publish', 'record_id' => $pending_id ) ), 'pressing publish twice answers honestly the second time' );
EstatTests::is( 'paused', estat_it33_post( array( 'estat_office_action' => 'listing_pause', 'record_id' => $pending_id ) ), 'pause works on a live one' );
EstatTests::is( 'private', get_post( $pending_id )->post_status, 'and the listing comes down without being deleted' );
EstatTests::is( 'resumed', estat_it33_post( array( 'estat_office_action' => 'listing_resume', 'record_id' => $pending_id ) ), 'make live puts it back' );
EstatTests::is( 'publish', get_post( $pending_id )->post_status, 'at the same status it had' );

$back_id = (int) Listings::save( array( 'title' => 'Return me flat', 'description' => 'Needs photographs.', 'price' => 4000000, 'status' => 'pending' ) );
EstatTests::is( 'listed_back', estat_it33_post( array( 'estat_office_action' => 'listing_return', 'record_id' => $back_id ) ), 'send-back returns a proposal to its agent' );
EstatTests::is( 'draft', get_post( $back_id )->post_status, 'as a draft, exactly like the approvals tab does' );

EstatTests::group( 'The publish key stays in fewer pockets than the door' );

estat_login_with( 42, array( 'estat_review_listings', 'read' ) );
EstatTests::is( '', Dashboard::gate(), 'a reviewer may open the dashboard' );
$rev = estat_it33_post( array( 'estat_office_action' => 'listing_publish', 'record_id' => $pending_id ) );
EstatTests::ok( 'nope' === $rev || 'stale' === $rev, 'but publishing answers the reviewer with a refusal' );
estat_login_with( IT33_AGENT, estat_it33_agent_caps() );
$agent_list = estat_it33_render( 'listings' );
EstatTests::ok( false !== strpos( $agent_list, 'This is the office side' ), 'an agent who types the URL gets the polite door' );
EstatTests::ok( false === strpos( $agent_list, 'Put it live' ), 'and no part of the table' );
estat_login_owner();

EstatTests::group( 'The dashboard obeys the design law too' );

$dash_css = (string) file_get_contents( dirname( __DIR__, 2 ) . '/assets/css/dashboard.css' );

$leaks = preg_match_all( '/#[0-9a-fA-F]{3,8}\b/', implode( "\n", array_filter( explode( "\n", $dash_css ), static function ( string $l ): bool {
	$t = trim( $l );
	return 0 !== strpos( $t, '*' ) && 0 !== strpos( $t, '/*' );
} ) ) );
EstatTests::is( 0, $leaks, 'dashboard.css borrows colours and never defines one (raw hex: ' . $leaks . ')' );
EstatTests::is( 0, preg_match_all( '/--estat-[a-z-]+\s*:/', $dash_css ), 'dashboard.css defines no token either' );
EstatTests::ok( false !== strpos( $dash_css, 'prefers-reduced-motion' ), 'movement can be turned off here too' );
EstatTests::ok( false !== strpos( $dash_css, 'touch-action: manipulation' ), 'buttons do not double-tap-zoom' );
EstatTests::ok( false !== strpos( $dash_css, '-webkit-tap-highlight-color' ), 'no grey flash on taps' );
EstatTests::ok( false !== strpos( $dash_css, 'font-size: 16px' ), 'the one input keeps phones from zooming' );
EstatTests::ok( false !== strpos( $dash_css, ':focus-visible' ), 'keys show a ring, mice do not' );
EstatTests::ok( false !== strpos( $dash_css, '@media ( max-width: 1100px )' ) && false !== strpos( $dash_css, '@media ( max-width: 782px )' ), 'the fold points are the two WordPress itself uses' );
EstatTests::ok( false !== strpos( $dash_css, 'env( safe-area-inset-bottom' ), 'the phone tab bar steps around the home bar' );

$html = estat_it33_render( '' );
EstatTests::ok(
	false !== strpos( $html, 'assets/css/tokens.css?ver=' )
		&& false !== strpos( $html, 'assets/css/dashboard.css?ver=' )
		&& strpos( $html, 'tokens.css' ) < strpos( $html, 'dashboard.css' )
		&& strpos( $html, 'dashboard.css' ) < strpos( $html, '</head>' ),
	'both stylesheets link in the head, tokens first, same rule the pocket learned the hard way'
);
EstatTests::ok( false !== strpos( $html, 'estat-dash-theme' ), 'the theme choice rides localStorage, not a cookie' );
EstatTests::ok( false !== strpos( $html, 'data-theme="auto"' ), 'and Auto is a first-class button' );
EstatTests::ok( false !== strpos( $html, 'estat-theme-' ), 'the body class is set before anything paints' );

$php_files = glob( dirname( __DIR__, 2 ) . '/includes/Office/*.php' );
$emoji     = 0;
foreach ( $php_files as $f ) {
	$emoji += preg_match_all( '/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', (string) file_get_contents( $f ) );
}
EstatTests::is( 0, $emoji, 'no emoji in the dashboard code' );

$paths = Icon::paths();
foreach ( $php_files as $f ) {
	preg_match_all( "/Icon::render\\(\\s*'([a-z-]+)'/", (string) file_get_contents( $f ), $names );
	foreach ( array_unique( $names[1] ) as $n ) {
		EstatTests::ok( isset( $paths[ $n ] ), 'the dashboard names a real icon: ' . $n );
	}
}
