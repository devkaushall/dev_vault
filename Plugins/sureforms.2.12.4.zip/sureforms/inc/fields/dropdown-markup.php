<?php
/**
 * Sureforms Dropdown Markup Class file.
 *
 * @package sureforms.
 * @since 0.0.1
 */

namespace SRFM\Inc\Fields;

require SRFM_DIR . 'modules/gutenberg/classes/class-spec-gb-helper.php';

use Spec_Gb_Helper;
use SRFM\Inc\Compatibility\Multilingual\String_Translator;
use SRFM\Inc\Helper;
use SRFM\Inc\Smart_Tags;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Sureforms Dropdown Markup Class.
 *
 * @since 0.0.1
 */
class Dropdown_Markup extends Base {
	/**
	 * Unique instance identifier for this dropdown.
	 *
	 * @var string
	 * @since 1.10.0
	 */
	protected $unique_slug;

	/**
	 * Stores the multi select attribute value.
	 *
	 * @var string
	 * @since 0.0.7
	 */
	protected $multi_select_attr;

	/**
	 * Stores the search attribute value.
	 *
	 * @var string
	 * @since 0.0.7
	 */
	protected $search_attr;

	/**
	 * Flag indicating if the value should be shown.
	 *
	 * @var bool
	 * @since 1.5.0
	 */
	protected $show_values;

	/**
	 * Array of preselected option indices.
	 *
	 * @var array
	 * @since 2.3.0
	 */
	protected $preselected_options;

	/**
	 * Static counter for generating unique dropdown instances.
	 *
	 * @var int
	 * @since 1.10.0
	 */
	private static $instance_counter = 0;

	/**
	 * Initialize the properties based on block attributes.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @since 0.0.2
	 */
	public function __construct( $attributes ) {
		$this->slug = 'dropdown';
		$this->set_properties( $attributes );
		$this->set_input_label( __( 'Dropdown', 'sureforms' ) );
		$this->set_error_msg( $attributes, 'srfm_dropdown_block_required_text' );
		$this->multi_select_attr   = ! empty( $attributes['multiSelect'] ) ? 'true' : 'false';
		$this->search_attr         = ! empty( $attributes['searchable'] ) ? 'true' : 'false';
		$this->preselected_options = $attributes['preselectedOptions'] ?? [];
		$this->resolve_dynamic_default( $attributes );
		$this->set_markup_properties();
		$this->set_aria_described_by();

		// Store the original placeholder before set_label_as_placeholder modifies placeholder_attr.
		$original_placeholder = $this->placeholder;
		$this->set_label_as_placeholder( $this->input_label );

		// For dropdowns, use the appropriate placeholder text:
		// 1. If label is being used as placeholder (label_markup is empty), use the label.
		// 2. Otherwise, use the block's placeholder value.
		if ( empty( $this->label_markup ) ) {
			$this->placeholder = $this->label;
		} elseif ( ! empty( $original_placeholder ) ) {
			$this->placeholder = $original_placeholder;
		}

		// Translate the default placeholder text for frontend display. Routed through
		// the multilingual provider (not just the textdomain) so it is translated on
		// WPML/Polylang sites too — the default placeholder is not serialized into
		// block markup, so it never reaches the per-form string package.
		if ( 'Select an option' === $this->placeholder ) {
			$this->placeholder = String_Translator::get_instance()->translate_validation_message( 'srfm_dropdown_placeholder', __( 'Select an option', 'sureforms' ) );
		}

		$this->show_values = apply_filters( 'srfm_show_options_values', false, $attributes['showValues'] ?? false );

		// Generate unique instance identifier.
		self::$instance_counter++;
		$this->unique_slug = $this->slug . '-' . self::$instance_counter;
	}

	/**
	 * Render the sureforms dropdown classic styling
	 *
	 * @since 0.0.2
	 * @return string|bool
	 */
	public function markup() {
		$this->class_name = $this->get_field_classes();

		ob_start(); ?>
			<div data-block-id="<?php echo esc_attr( $this->block_id ); ?>" class="<?php echo esc_attr( $this->class_name ); ?>">
				<fieldset>
					<input class="srfm-input-<?php echo esc_attr( $this->slug ); ?>-hidden" data-required="<?php echo esc_attr( $this->data_require_attr ); ?>" aria-required="<?php echo esc_attr( $this->data_require_attr ); ?>" <?php echo wp_kses_post( $this->data_attribute_markup() ); ?> name="srfm-<?php echo esc_attr( $this->unique_slug ); ?>-<?php echo esc_attr( $this->block_id ); ?><?php echo esc_attr( $this->field_name ); ?>" type="hidden" value=""/>
					<legend class="srfm-block-legend">
						<?php echo wp_kses_post( $this->label_markup ); ?>
					</legend>
					<?php echo wp_kses_post( $this->help_markup ); ?>
					<div class="srfm-block-wrap srfm-dropdown-common-wrap">
					<?php
					if ( is_array( $this->options ) ) {
						?>
					<select
						class="srfm-dropdown-common srfm-<?php echo esc_attr( $this->slug ); ?>-input"
						<?php echo ! empty( $this->aria_described_by ) ? "aria-describedby='" . esc_attr( trim( $this->aria_described_by ) ) . "'" : ''; ?>
				data-required="<?php echo esc_attr( $this->data_require_attr ); ?>" aria-required="<?php echo esc_attr( $this->data_require_attr ); ?>" <?php echo wp_kses_post( $this->data_attribute_markup() ); ?> name="srfm-<?php echo esc_attr( $this->unique_slug ); ?>-<?php echo esc_attr( $this->block_id ); ?><?php echo esc_attr( $this->field_name ); ?>" data-multiple="<?php echo esc_attr( $this->multi_select_attr ); ?>" data-searchable="<?php echo esc_attr( $this->search_attr ); ?>"
						<?php
						if ( ! empty( $this->preselected_options ) ) {
							$preselected_labels = array_map(
								function( $i ) {
									$option = $this->options[ $i ] ?? [];
									return is_array( $option ) ? ( $option['label'] ?? '' ) : '';
								},
								$this->preselected_options
							);
							$json_encoded       = wp_json_encode( $preselected_labels );
							echo 'data-preselected="' . esc_attr( false !== $json_encoded ? $json_encoded : '' ) . '"';
						}
						?>
						tabindex="0" aria-hidden="true">
					<option class="srfm-dropdown-placeholder" value="" disabled <?php echo empty( $this->preselected_options ) ? 'selected' : ''; ?>><?php echo esc_html( $this->placeholder ); ?></option>
						<?php foreach ( $this->options as $i => $option ) { ?>
							<?php
								$icon_svg         = Spec_Gb_Helper::render_svg_html( $option['icon'] ?? '', true );
								$escaped_icon_svg = htmlspecialchars( Helper::get_string_value( $icon_svg ), ENT_QUOTES, 'UTF-8' );
								$is_preselected   = is_array( $this->preselected_options ) && in_array( $i, $this->preselected_options, true );
							?>
								<option value="<?php echo isset( $option['label'] ) ? esc_html( $option['label'] ) : ''; ?>" data-icon="<?php echo ! empty( $escaped_icon_svg ) ? esc_attr( $escaped_icon_svg ) : ''; ?>" <?php echo $this->show_values && isset( $option['value'] ) ? 'option-value="' . esc_attr( $option['value'] ) . '"' : ''; ?> <?php echo $is_preselected ? 'selected' : ''; ?>><?php echo isset( $option['label'] ) ? esc_html( $option['label'] ) : ''; ?></option>
								<?php
						}
						?>
					</select>
					<?php } ?>
					</div>
					<div class="srfm-error-wrap">
						<?php echo wp_kses_post( $this->error_msg_markup ); ?>
					</div>
				</fieldset>
			</div>
		<?php
		$markup = ob_get_clean();

		return apply_filters(
			'srfm_block_field_markup',
			$markup,
			[
				'slug'       => $this->slug,
				'field_name' => $this->field_name,
				'is_editing' => $this->is_editing,
				'attributes' => $this->attributes,
			]
		);
	}

	/**
	 * Resolve dynamic default value from smart tags and override preselected options.
	 *
	 * Single-select dropdowns match the resolved value as a single trimmed
	 * string, so labels that legitimately contain delimiter characters
	 * (commas, pipes, etc.) still match.
	 *
	 * Multi-select dropdowns split the resolved value on the pipe character
	 * (`|`) and match every segment (for example "{get_input:a}|{get_input:b}"
	 * resolving to "Red|Blue", or a single `{get_input:colors}` smart tag with
	 * URL `?colors=Red|Blue`). The same pipe split applies to multi-character
	 * resolved values from `{get_input:...}` and `{get_cookie:...}`, so cookie
	 * payloads that contain pipes are treated as multi-value in multi-select
	 * mode.
	 *
	 * When the `Add Numeric Values to Options` (showValues) setting is on,
	 * each segment is also compared against the option's `value`.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @since 2.8.1
	 * @since 2.10.0 Added multi-select (pipe-delimited) value matching.
	 * @return void
	 */
	protected function resolve_dynamic_default( $attributes ) {
		// Coalesce first so blocks saved before this attribute existed (pre-2.10.0)
		// don't trigger an "Undefined array key" warning on every frontend render.
		$raw_default     = $attributes['dynamicDefaultValue'] ?? '';
		$dynamic_default = is_string( $raw_default ) ? $raw_default : '';
		if ( empty( $dynamic_default ) ) {
			return;
		}

		$smart_tags = new Smart_Tags();
		$resolved   = $smart_tags->process_smart_tags( $dynamic_default );

		if ( empty( $resolved ) || ! is_string( $resolved ) || ! is_array( $this->options ) ) {
			return;
		}

		// START: multi-value dynamic default resolution.
		$is_multi_select = ! empty( $attributes['multiSelect'] );

		if ( $is_multi_select ) {
			$segments = array_filter(
				array_map( 'trim', explode( '|', $resolved ) ),
				static function ( $segment ) {
					return '' !== $segment;
				}
			);
			// Cap segments to avoid pathological URLs (e.g. ?colors=|||||...) producing thousands of comparisons.
			$segments = array_slice( $segments, 0, 50 );
		} else {
			$trimmed  = trim( $resolved );
			$segments = '' === $trimmed ? [] : [ $trimmed ];
		}

		if ( empty( $segments ) ) {
			return;
		}

		$match_value_too  = ! empty( $attributes['showValues'] );
		$matching_indices = [];

		foreach ( $segments as $segment ) {
			foreach ( $this->options as $i => $option ) {
				if ( ! is_array( $option ) || in_array( $i, $matching_indices, true ) ) {
					continue;
				}

				$option_label = isset( $option['label'] ) && is_scalar( $option['label'] ) ? (string) $option['label'] : '';
				$raw_value    = $option['value'] ?? '';
				$option_value = $match_value_too && is_scalar( $raw_value ) ? (string) $raw_value : '';

				$is_match = ( '' !== $option_label && strcasecmp( $option_label, $segment ) === 0 )
					|| ( $match_value_too && '' !== $option_value && strcasecmp( $option_value, $segment ) === 0 );

				if ( $is_match ) {
					$matching_indices[] = $i;
					if ( ! $is_multi_select ) {
						break 2;
					}
					break;
				}
			}
		}

		if ( ! empty( $matching_indices ) ) {
			$this->preselected_options = $is_multi_select ? $matching_indices : [ $matching_indices[0] ];
		}
		// END: multi-value dynamic default resolution.
	}

	/**
	 * Data attribute markup for min and max value
	 *
	 * @since 0.0.13
	 * @return string
	 */
	protected function data_attribute_markup() {
		$data_attr = '';
		if ( 'false' === $this->multi_select_attr ) {
			return '';
		}

		if ( $this->min_selection ) {
			$data_attr .= 'data-min-selection="' . esc_attr( $this->min_selection ) . '"';
		}
		if ( $this->max_selection ) {
			$data_attr .= 'data-max-selection="' . esc_attr( $this->max_selection ) . '"';
		}

		return $data_attr;
	}
}
