# DEV KAUSHAL
**WordPress Website Support & Operations Executive**  
Gurugram, Haryana | Phone: +91 8923162439 | Email: Devkaushal8923@gmail.com  
Immediate Joiner

---

## PROFILE
Fresher / Entry-Level WordPress Executive with practical experience in setting up and managing business websites using WordPress and Elementor. Familiar with website setup, content uploads, theme customization, basic on-page SEO, and Canva banner design. Looking for an entry-level website management or WordPress support role in Delhi NCR.

---

## WHAT I CAN DO (HANDS-ON SKILLS)
* **Website Setup:** WordPress installation, Elementor page building, Astra theme setup, contact forms, WhatsApp button integration.
* **Site Updates & Maintenance:** Regular page updates, image resizing, blog posting, basic website speed checks via PageSpeed Insights.
* **Basic SEO:** Adding meta titles, meta descriptions, image alt tags, heading tags (H1, H2).
* **Graphic Support:** Basic banners, offer posters, and social posts using Canva.
* **AI Tools:** Using ChatGPT / AI for basic content ideas and drafting text.

---

## WORK & PROJECTS

### Freelance WordPress Projects (Real Estate Sites)
*Feb 2026 – June 2026*
* **Rathi Properties:** Created website pages using Elementor, added property listing details, and set up the contact form.
* **Homes N Heights:** Set up website layout, organized page menus, and ensured the site opens properly on mobile phones.
* **Migrate Homes:** Added basic service pages, updated property images, and filled meta descriptions for SEO.

### Digital Marketing & Office Intern | SkillUp Graded Institute
*Dec 2025 – May 2026*
* Uploaded daily content and images on WordPress.
* Created simple promotional creatives on Canva.
* Updated meta titles and descriptions on website pages.
* Handled basic day-to-day website tasks given by the team.

---

## EDUCATION & COURSES
* **B.Com (Pursuing):** CSJM University, Kanpur
* **Certifications:** 
  * Google Fundamentals of Digital Marketing
  * HubSpot Social Media Certification
