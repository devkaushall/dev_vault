/**
 * PLAYER PROFILE
 * ---------------------------------------------------------------------------
 * The identity block used by the command centre header, hero, HQ and footer.
 * All copy here is self-reported. Nothing in this file should claim verified
 * results, awards or client relationships that cannot be evidenced.
 */

export const profile = {
  // Personal mark shown top-left and in the hero.
  mark: { primary: 'DEV', separator: '.', secondary: 'K' },

  name: 'Dev Kaushal',

  role: 'DIGITAL MARKETER + DESIGNER',

  location: 'BASED IN INDIA',

  // Availability is a status, not a claim. `state` drives colour + the label's
  // accessible text: 'open' | 'limited' | 'closed'.
  availability: {
    state: 'open',
    label: 'AVAILABLE',
    note: 'Open to freelance work, collaborations and learning opportunities.'
  },

  // The single "what am I doing right now" state shown on every screen.
  currentMode: {
    label: 'CURRENT MODE',
    value: 'GROWING',
    note: 'Learning in public, taking on small practical projects, sharpening the fundamentals.'
  },

  // Hero statement — two stacked lines, as in the reference design.
  tagline: ['CREATIVE MIND.', 'GROWING SKILLS.'],

  // The positioning line. Preserved from the reference build.
  intro:
    'No superhero origin story—just steady learning, creative experiments and a growing sense of direction.',

  // Longer, human version of the intro used on Story Mode and HQ.
  summary:
    'I help brands communicate clearly through social media, content, design and thoughtful WordPress experiences. I am early in that journey, and I would rather show the work in progress than pretend otherwise.',

  // Quote block shown in Story Mode.
  mindset:
    'I’m not here to pretend I know everything. I’m here to keep learning—and make useful things along the way.',

  // Small, personal note from the reference build. Kept as a note, not a slogan.
  companionNote: 'Curious, creative, and ready to help brands grow.',

  // Personality tags — descriptive, not performance claims.
  traits: ['CREATIVE', 'CURIOUS', 'STORY-DRIVEN', 'FRIENDLY'],

  // Areas of interest / where the work is heading.
  interests: [
    'Brand voice and positioning for small teams',
    'Search fundamentals: structure, intent, clarity',
    'Content systems that survive a busy week',
    'Design that explains instead of decorates',
    'WordPress builds that a non-developer can maintain'
  ],

  // Capabilities are phrased as work types, with an honest confidence label so
  // nothing reads as a mastery claim. Level wording matches the skill tree.
  capabilities: [
    {
      title: 'Social media & content',
      detail: 'Content calendars, captions, formats and page management for small brands.',
      level: 'PRACTISING'
    },
    {
      title: 'Design & visual assets',
      detail: 'Social creatives, simple brand systems, layout and typography decisions.',
      level: 'PRACTISING'
    },
    {
      title: 'Search foundations',
      detail: 'Keyword intent, on-page structure, titles, metadata and crawl basics.',
      level: 'LEARNING'
    },
    {
      title: 'WordPress & web pages',
      detail: 'Block and Elementor builds, page structure, performance-friendly handover.',
      level: 'WORKING KNOWLEDGE'
    },
    {
      title: 'Writing & storytelling',
      detail: 'Turning a rough idea into a short, useful, plainly written piece.',
      level: 'PRACTISING'
    },
    {
      title: 'Reporting & analytics',
      detail: 'Reading GA4 and Search Console to answer one question at a time.',
      level: 'LEARNING'
    }
  ],

  // Resume/CV. Drop a PDF into assets/files/ and point this at it to activate
  // the download buttons. Left null, the UI shows a designed empty state.
  resume: {
    url: null,
    label: 'Download CV (PDF)',
    meta: 'Not uploaded yet'
  }

  // Portrait / identity image used by the companion module on the command
  // centre. Leave `src` null to render the built-in abstract identity visual.
  // To insert a real photo:
  //   1. Save the file as assets/img/profile/portrait.jpg (or .webp/.svg)
  //   2. Set src below, plus a descriptive alt and the real pixel dimensions.
  // The module keeps the same aspect ratio (4:5) and object-fit: cover, so no
  // layout changes are needed.
  ,
  portrait: {
    src: null,
    webp: null,
    alt: '',
    width: 800,
    height: 1000,
    caption: 'IDENTITY VISUAL — PLACEHOLDER',
    note: 'Slot ready for a portrait, logo or generated artwork (4:5).'
  }
};

export default profile;
