/**
 * CURRENT FOCUS
 * ---------------------------------------------------------------------------
 * Three focus areas, carried over from the reference build. Each one exposes
 * a label, a one-line description and a *checklist-based* progress signal.
 *
 * Progress is never a made-up percentage: it is simply the number of completed
 * steps out of the steps listed. Tick a step (`done: true`) and the meter,
 * counter and stage label all update on the next build.
 *
 * Useful vocabulary for `stage`: LEARNING | PRACTISING | WORKING KNOWLEDGE
 * (the same four-level ladder used by the skill tree).
 */

export const focusAreas = [
  {
    id: 'personal-branding',
    index: 'F-01',
    label: 'PERSONAL BRANDING',
    tagline: 'Building a voice people remember',
    summary:
      'Deciding what to be known for, saying it the same way twice, and showing the work instead of describing it.',
    stage: 'PRACTISING',
    accent: 'signal',
    updated: '2026-09',
    selfReported: true,
    steps: [
      { label: 'Define the message', done: true },
      { label: 'Show the work publicly', done: true },
      { label: 'Publish on a rhythm', done: false },
      { label: 'Build a returning audience', done: false }
    ],
    next: 'Keep a weekly publishing slot and hold it for a month.',
    links: [
      { label: 'Story Mode', file: 'story-mode.html' },
      { label: 'Case Files', file: 'case-files.html' }
    ]
  },
  {
    id: 'seo',
    index: 'F-02',
    label: 'SEO',
    tagline: 'Learning search foundations',
    summary:
      'Search intent before keywords, clean page structure, honest metadata, and learning to read what Search Console is actually saying.',
    stage: 'LEARNING',
    accent: 'moss',
    updated: '2026-10',
    selfReported: true,
    steps: [
      { label: 'Search fundamentals', done: true },
      { label: 'On-page structure & metadata', done: true },
      { label: 'Technical basics (indexing, speed)', done: false },
      { label: 'Content and links strategy', done: false }
    ],
    next: 'Audit this site first: titles, descriptions, internal links, crawlability.',
    links: [
      { label: 'Learning Lab', file: 'learning-lab.html' },
      { label: 'Learning Log', file: 'learning-log.html' }
    ]
  },
  {
    id: 'content-strategy',
    index: 'F-03',
    label: 'CONTENT STRATEGY',
    tagline: 'Turning ideas into useful stories',
    summary:
      'Capturing ideas reliably, choosing the format that fits, and writing things people can act on rather than admire.',
    stage: 'PRACTISING',
    accent: 'sand',
    updated: '2026-09',
    selfReported: true,
    steps: [
      { label: 'Capture ideas consistently', done: true },
      { label: 'Match idea to format', done: true },
      { label: 'Repurpose across channels', done: false },
      { label: 'Distribute with intent', done: false }
    ],
    next: 'Turn three logged ideas into one long piece and three short ones.',
    links: [
      { label: 'Missions', file: 'missions.html' },
      { label: 'Learning Lab', file: 'learning-lab.html' }
    ]
  }
];

export default focusAreas;
