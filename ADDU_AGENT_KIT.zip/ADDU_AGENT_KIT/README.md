# ADDU — agent integration kit (v1)

## What this is

The approved original PARTY ADDA mascot, extracted from its review playground into reusable web assets. Terracotta `#C85F4B`, paper belly `#F7F1E7`, cocoa details `#392B27`, speech-bubble tail. Keep this identity and silhouette; do not substitute emoji faces, stock art or another mascot.

Contains **66 working expression/pose states**: 16 emotion families × 3 intensity levels (48), 6 dances, 6 social gestures, 6 gameplay poses. These share a layered SVG rig and reusable CSS motions. This is a first working animation library, **not 66 separately hand-polished bespoke animation films**. Production integration and live multiplayer E2E are the receiving agent's work.

## Files

| File | Purpose | Ship in the app? |
|---|---|---|
| `addu.svg` | Original editable neutral SVG, separate body, belly, face, eye, mouth, arm, hand and effect layers. Also includes dormant expression geometry and named slots used by the controller. | Yes |
| `addu.css` | Mascot-only scoped rules, prefixed keyframes, motion states and reduced-motion support. No global page/button/form styling. | Yes |
| `addu-expressions.js` | Read-only data for all 66 states: ID, key, family, intensity, name, description and pose/motion/effect mapping. | Yes |
| `addu.js` | ES-module controller: loads/caches the SVG, mounts independent instances, switches face/hand/effect layers, plays/resets/pauses/destroys. | Yes |
| `demo.html` | Integration check using the actual four assets, 66 selectable states, search, auto tour and an independent second mascot. | Optional; review only |
| `README.md` | This handoff and implementation contract. | No runtime requirement |

No dependency install, compilation, API key, external font, raster asset or external animation library is needed. The controller loads `addu.svg` from its own directory with one cached same-origin fetch. This kit does not import Firebase or make reaction-network writes.

## Task for the implementation agent

1. Start from the user's **latest local/repository version**, not an old deployment ZIP. Preserve uncommitted work. Do not replace the app's `index.html` with a demo.
2. Copy the four production files together into `assets/addu/` (keep their sibling relationship).
3. Link `assets/addu/addu.css` from the app's HTML. Import `createAddu` from `assets/addu/addu.js` inside the existing module entry point.
4. Add dedicated, explicitly sized mount containers to appropriate screens. Mount once per container; do not rebuild the SVG on every Firebase snapshot/timer tick.
5. Connect actual game transitions to the API, with event-ID deduplication. Apply contextual local reactions first; player-to-player reactions are a separate networking feature.
6. Keep questions, answers, timer, navigation and scores primary. Effects must not cover game inputs. Use a small curated reaction tray, not all 66 buttons in gameplay.
7. Preserve Firebase room flow, all three games, scoring, timers, multilingual content, presence, host migration and five-round champion logic.
8. Preserve current Netlify functions/config and optional AI-round endpoint. Mascot integration does not require changes to them or new server-side secrets.
9. If replacing existing avatar/emoji UI, use ADDU variants/badges while retaining readable player names/identifiers. Support existing room data without destructive migration. Do not write SVG/HTML into player records.
10. Ship only the four required assets plus deliberate changes to existing app files. Do not copy the demo's controls/layout into production.

## Minimal mounting example

In the existing `index.html`:

```html
<link rel="stylesheet" href="./assets/addu/addu.css">
<!-- A dedicated container, not a parent holding game controls. -->
<div id="lobby-addu" class="lobby-addu"></div>
```

In existing app CSS (choose size for your layout):

```css
.lobby-addu { width: clamp(112px, 20vw, 200px); aspect-ratio: 1; }
/* Use decorative treatment only when an adjacent text label conveys the state. */
```

In existing `app.js` (ES module):

```js
import { createAddu } from './assets/addu/addu.js';

let lobbyAddu;
// A missing mascot asset must not prevent the game/Firebase from starting.
createAddu(document.getElementById('lobby-addu'))
  .then(instance => { lobbyAddu = instance; instance.gesture('welcome'); })
  .catch(error => console.warn('Mascot unavailable; game can continue.', error));

// Call from an actual state transition, not from every render/tick:
function onNewPlayerJoined() {
  lobbyAddu?.gesture('welcome');
}
```

Each `createAddu` returns a promise. Load CSS once. Size the container externally. SVG markup is a trusted project asset; never pass user-controlled SVG/HTML through `options.svgMarkup`.

The raw SVG can also be used as a static `<img src=".../addu.svg" alt="ADDU">`, but reactions require the controller's inline SVG mount.

## Controller API

```js
const addu = await createAddu(container, {
  reducedMotion: false,     // forced static mode; OS preference still wins
  pauseOffscreen: true,    // default: pause when the container is out of view
  durationMs: 3400,         // optional default finite reaction duration
  // svgMarkup: trustedSvgString, // optional alternative to fetching the sibling SVG
  onStateChange(state) {
    // state: {key, expression, reducedMotion, paused}
  }
});

addu.react('happy', { level: 1 });
addu.react('happy', { level: 3 });
addu.react('sad', { level: 2 });
addu.play('mischief-3');       // egg prank
addu.play(39);                // IDs 1–66 also work
addu.dance('bhangra');
addu.gesture('high-five');
addu.gesture('hug');
addu.play('thinking-1', { hold: true }); // loops until reset/change
addu.play('game-4', { durationMs: 2200 });
addu.reset();                 // neutral idle
addu.pause(); addu.resume();  // manual pause; hidden/offscreen reasons also apply
addu.setReducedMotion(true);  // holds static expression, no auto-reset
addu.getState();
addu.getElement();            // instance-specific inline SVG
addu.destroy();              // remove SVG, timers/listeners/observer
```

- `play`, `react`, `dance`, `gesture` return `false` for invalid requests or after destruction; a successful play returns `true`.
- Valid levelled families: `happy`, `laugh`, `sad`, `angry`, `surprise`, `nervous`, `confident`, `proud`, `love`, `shy`, `confused`, `thinking`, `mischief`, `applause`, `relief`, `sleepy`.
- Levels: **1 = subtle**, **2 = expressive**, **3 = full Adda**. `react()` only accepts these 16 families and integer levels 1–3. Dance/social/game states use `play()` or the convenience APIs.
- Dance names: `groove`, `shimmy`, `bhangra`, `disco`, `jelly`, `spin` (or 1–6).
- Gesture aliases: `welcome`, `beckon`, `high-five`, `good-game`, `sorry`, `bye`, `hug`.
- Default animated duration is 3400 ms; egg defaults to 2900 ms. `hold:true` repeats body motion until reset/change; egg choreography is a one-shot even when held.
- Replaying the same state restarts it. A new play replaces the previous one; there is no built-in queue/cooldown.
- In forced or OS reduced-motion mode, animation is disabled and the selected expression remains until reset/change. OS preference cannot be overridden to force motion. An explicit reset restores static neutral.
- Hidden-document and offscreen animation/timers pause. Manual resume does not bypass the other pause reasons.
- Multiple instances are supported. SVG IDs and ARIA references are namespaced per instance. Mounting again in the same container disposes its old instance. Destroy instances on screen/component teardown.
- Styles are confined to `.addu-mascot`; keyframes use `addu-` names. Do not depend on global element IDs. Internal parts are addressed by `data-addu-part` attributes.
- No window globals are installed by the production module. `window.adduDemo` is used by `demo.html` only.

## Event mapping (recommended, not already implemented in the game)

| Game event | Suggested call |
|---|---|
| Welcome / newly joined player | `gesture('welcome')` |
| Waiting lobby | Neutral idle or `play('thinking-1')` |
| Shared countdown begins | `play('game-1')` |
| Answer confirmed saved | `play('game-2')` |
| Low time, once per round | `play('game-3')` |
| Correct answer AFTER reveal | `play('game-4')` |
| Wrong/no answer AFTER reveal | `play('game-5')` |
| Round appreciation | `react('applause', {level: 2})` |
| Champion | `react('proud', {level: 3})` or `dance('spin')` |
| User selects egg reaction | `play('mischief-3')` |

Never leak answer correctness through an early mascot reaction. Do not automatically mock losing players or egg-splat their answers.

Use existing round IDs/timestamps to prevent replay on every render:

```js
const mascotEvents = new Set();
function reactOnce(eventId, perform) {
  if (!lobbyAddu || mascotEvents.has(eventId)) return;
  mascotEvents.add(eventId);
  perform(lobbyAddu);
  // Clear/bound this set on room exit or when old rounds are no longer needed.
}
// Example INSIDE your existing reveal transition:
// reactOnce(`${roundId}:reveal:${myPlayerId}`, a => a.play(isCorrect ? 'game-4' : 'game-5'));
```

## Optional synchronized reactions — not included

If reactions must be seen by other players, implement a small Firebase event channel in the app. Send only an allowlisted expression key, unique event ID, sender ID and server timestamp; never animation frames or user HTML. Validate room membership and payloads in database rules, add per-player cooldown/rate limits, reject expired events, and deduplicate. Reconnect must not replay stale eggs. Clean up event data/listeners on room exit. Do not claim this kit already provides authenticated/rate-limited multiplayer reactions.

## Preview and verification

From the extracted kit directory:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080/demo.html`. Use a local HTTP server or your app's dev server, not a `file://` double-click: this kit uses ES modules and a local SVG fetch. Keep all four production assets reachable; a route fallback must not return app HTML for `addu.svg`.

Receiving-agent acceptance checklist:

- All 66 keys render; emotion levels remain distinguishable without motion.
- Main and small demo instances remain independent with unique IDs.
- Same-reaction replay, finite auto-reset, hold, pause/resume and destroy work.
- Reduced-motion and mobile layout work; no hidden/offscreen continuous animation.
- No question/answer/timer is covered; 8-player avatar use stays lightweight.
- Screen rerenders do not recreate active mascots or spam reactions.
- Failed asset loading does not stop gameplay.
- Existing three games, host migration, joins/reconnects and champion flow still pass a two-device live test.

The kit is plain browser ES modules and static assets. In a zero-build Netlify setup publishing the repository root, `assets/addu/` is published automatically. Framework users should keep the files in the served static/public directory or adapt their asset handling; call `destroy()` on unmount and guard async initialization if the component can unmount before `createAddu()` resolves.

## Full state catalogue

| ID | Key | Level | Expression |
|---|---|---|---|
| 1 | `happy-1` | 1 | Little smile |
| 2 | `happy-2` | 2 | So happy! |
| 3 | `happy-3` | 3 | Pure joy |
| 4 | `laugh-1` | 1 | Hehe, giggle |
| 5 | `laugh-2` | 2 | Belly laugh |
| 6 | `laugh-3` | 3 | Absolutely lost it |
| 7 | `sad-1` | 1 | A little down |
| 8 | `sad-2` | 2 | Feeling blue |
| 9 | `sad-3` | 3 | Big feelings |
| 10 | `angry-1` | 1 | Hmph. |
| 11 | `angry-2` | 2 | Not amused |
| 12 | `angry-3` | 3 | Tiny steam mode |
| 13 | `surprise-1` | 1 | Oh? |
| 14 | `surprise-2` | 2 | Arre wah! |
| 15 | `surprise-3` | 3 | Mind. Blown. |
| 16 | `nervous-1` | 1 | Not quite sure |
| 17 | `nervous-2` | 2 | Getting nervous |
| 18 | `nervous-3` | 3 | Last-second panic |
| 19 | `confident-1` | 1 | I am ready |
| 20 | `confident-2` | 2 | Bring it on |
| 21 | `confident-3` | 3 | Champion energy |
| 22 | `proud-1` | 1 | I did that |
| 23 | `proud-2` | 2 | Look at me! |
| 24 | `proud-3` | 3 | Take a bow |
| 25 | `love-1` | 1 | Warm little heart |
| 26 | `love-2` | 2 | Sending love |
| 27 | `love-3` | 3 | Big virtual hug |
| 28 | `shy-1` | 1 | Shy smile |
| 29 | `shy-2` | 2 | You are too kind |
| 30 | `shy-3` | 3 | Hide and peek |
| 31 | `confused-1` | 1 | Hmm? |
| 32 | `confused-2` | 2 | Wait, what? |
| 33 | `confused-3` | 3 | Completely puzzled |
| 34 | `thinking-1` | 1 | Let me think |
| 35 | `thinking-2` | 2 | Deep thought |
| 36 | `thinking-3` | 3 | Got an idea! |
| 37 | `mischief-1` | 1 | Cheeky wink |
| 38 | `mischief-2` | 2 | Plotting something |
| 39 | `mischief-3` | 3 | Egg prank |
| 40 | `applause-1` | 1 | Nice one |
| 41 | `applause-2` | 2 | Wah bhai! |
| 42 | `applause-3` | 3 | Full ovation |
| 43 | `relief-1` | 1 | Phew |
| 44 | `relief-2` | 2 | That was close |
| 45 | `relief-3` | 3 | We survived! |
| 46 | `sleepy-1` | 1 | Lazy blink |
| 47 | `sleepy-2` | 2 | Big yawn |
| 48 | `sleepy-3` | 3 | Dozed off |
| 49 | `dance-1` | — | Tiny groove |
| 50 | `dance-2` | — | Shoulder shimmy |
| 51 | `dance-3` | — | Bhangra bounce |
| 52 | `dance-4` | — | Disco point |
| 53 | `dance-5` | — | Squishy jelly |
| 54 | `dance-6` | — | Victory spin |
| 55 | `social-1` | — | Hello, dost! |
| 56 | `social-2` | — | Come join us |
| 57 | `social-3` | — | High five! |
| 58 | `social-4` | — | Good game |
| 59 | `social-5` | — | My bad |
| 60 | `social-6` | — | See you soon |
| 61 | `game-1` | — | Ready, set… |
| 62 | `game-2` | — | Answer locked |
| 63 | `game-3` | — | Time almost up |
| 64 | `game-4` | — | Correct! |
| 65 | `game-5` | — | Oops, try again |
| 66 | `game-6` | — | Comeback time |

## Checks performed on this export

Validated the exported kit (not only the earlier standalone playground) in Chromium:

- All 66 state keys rendered non-empty face/hand layers and resolved CSS keyframes.
- Independent instances had unique SVG IDs and did not change each other's state.
- CSS did not animate a separate, unrelated `.rig` element on the page.
- Family/level, dance and gesture APIs, invalid-key handling and destroy passed.
- Finite auto-reset, pause/resume with timer retention, and static hold passed.
- OS reduced-motion disabled the rig animation.
- Demo had no horizontal overflow at a 390px viewport; final browser console had no errors.

These checks do not replace visual polish review, performance profiling on the user's actual devices, or a two-device test after integration into PARTY ADDA.
