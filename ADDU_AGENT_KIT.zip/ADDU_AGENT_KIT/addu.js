/**
 * ADDU v1 — framework-free SVG mascot controller.
 * Required sibling files: addu.svg, addu.css, addu-expressions.js.
 * API example: const addu = await createAddu(mount); addu.react('happy', {level: 3});
 * No Firebase, network reactions, gameplay logic or global window API is installed.
 */
import { ADDU_EXPRESSIONS } from './addu-expressions.js';
export { ADDU_EXPRESSIONS, ADDU_FAMILIES } from './addu-expressions.js';
const instances = new WeakMap();
let nextInstance = 0;
let svgRequest;
async function getSvgMarkup() {
  if (!svgRequest) {
    svgRequest = fetch(new URL('./addu.svg', import.meta.url))
      .then(response => { if (!response.ok) throw new Error(`ADDU SVG load failed (${response.status}).`); return response.text(); })
      .catch(error => { svgRequest = undefined; throw error; });
  }
  return svgRequest;
}
const eyes={
soft:'<ellipse cx="169" cy="188" rx="6.5" ry="9"/><ellipse cx="231" cy="188" rx="6.5" ry="9"/>',
joy:'<path d="M159 190q10-15 20 0m42 0q10-15 20 0"/>',
squeeze:'<path d="m157 190 12-9 12 9m38 0 12-9 12 9"/>',
sad:'<path d="m157 178 21-5m44 0 21 5"/><ellipse cx="169" cy="192" rx="6" ry="8"/><ellipse cx="231" cy="192" rx="6" ry="8"/>',
cry:'<path d="M157 192q12-10 24 0m38 0q12-10 24 0m-59-18-17 5m49-5 17 5"/>',
side:'<path d="M155 182h25m40 0h25m-89-9 23 2"/><ellipse cx="173" cy="191" rx="5" ry="7"/><ellipse cx="235" cy="191" rx="5" ry="7"/>',
angry:'<path d="m156 175 24 8m40 0 24-8"/><ellipse cx="171" cy="194" rx="5" ry="7"/><ellipse cx="229" cy="194" rx="5" ry="7"/>',
curious:'<path d="m156 174 24-3m40 7 24 4"/><ellipse cx="169" cy="191" rx="6" ry="8"/><ellipse cx="231" cy="188" rx="7" ry="10"/>',
wide:'<ellipse cx="169" cy="188" rx="10" ry="13"/><ellipse cx="231" cy="188" rx="10" ry="13"/><path d="M158 168q11-8 22 0m40 0q11-8 22 0"/>',
worried:'<path d="m155 180 24-9m42 0 24 9"/><ellipse cx="169" cy="192" rx="6" ry="9"/><ellipse cx="231" cy="192" rx="6" ry="9"/>',
focus:'<path d="m156 177 23 5m42 0 23-5"/><ellipse cx="169" cy="193" rx="5" ry="7"/><ellipse cx="231" cy="193" rx="5" ry="7"/>',
closed:'<path d="M158 187q11 11 22 0m40 0q11 11 22 0"/>',
down:'<path d="M158 190q11 9 22 0m40 0q11 9 22 0"/><ellipse cx="171" cy="195" rx="4" ry="4"/><ellipse cx="233" cy="195" rx="4" ry="4"/>',
peek:'<path d="M158 187q11 11 22 0"/><ellipse cx="231" cy="190" rx="6" ry="9"/>',
up:'<ellipse cx="169" cy="185" rx="6" ry="9"/><ellipse cx="231" cy="185" rx="6" ry="9"/><path d="m157 172 22-3m42 0 22 3"/>',
wink:'<ellipse cx="169" cy="188" rx="6" ry="9"/><path d="m221 187 11 5 11-6"/>',
sleepy:'<path d="M157 186h24m38 0h24"/><ellipse cx="169" cy="191" rx="5" ry="4"/><ellipse cx="231" cy="191" rx="5" ry="4"/>'};
const mouths={smile:'<path d="M189 211q11 13 22 0"/>',grin:'<path d="M180 208q20 6 40 0c-2 23-37 23-40 0Z" fill="#392b27"/><path d="M186 212q14 3 28 0" stroke="#f7f1e7" stroke-width="5"/>',laugh:'<path d="M180 207q20 5 40 0c-1 31-38 31-40 0Z" fill="#392b27"/><path d="M189 227q11-10 22 0" stroke="#e7a18d" stroke-width="6"/>',frown:'<path d="M189 220q11-12 22 0"/>',sob:'<path d="M184 221q16-23 32 0Z" fill="#392b27"/>',pout:'<path d="M193 216h14"/>','small-o':'<ellipse cx="200" cy="216" rx="5" ry="6" fill="#392b27"/>',o:'<ellipse cx="200" cy="217" rx="10" ry="13" fill="#392b27"/>',awkward:'<path d="m186 215 9-3 10 5 10-4"/>',smirk:'<path d="M187 216q19 5 29-9"/>'};
// Cubic hand paths attach to the same two shoulder pivots in every expression.
const handPoses={
low:['M129 224q-24 25-13 35 14 10 24-20','M271 224q24 25 13 35-14 10-24-20'],
heart:['M129 224q16-9 58 13c13 8 7 22-5 17l-39-14','M271 224q-22 28-56 18c-12-4-9-18 3-17l34 1'],
excited:['M129 224q3 10 25-6c12-9 24 5 11 16l-25 12','M271 224q-3 10-25-6c-12-9-24 5-11 16l25 12'],
up:['M129 225q-28-32-11-55c9-11 21-3 16 9l11 38','M271 225q28-32 11-55c-9-11-21-3-16 9l-11 38'],
cover:['M129 224q16-26 56-21c15 2 13 20-2 19l-39 18','M271 224q24 25 13 35-14 10-24-20'],
belly:['M129 224q5 34 41 45c16 7 26-9 11-17l-32-20','M271 224q-5 34-41 45c-16 7-26-9-11-17l32-20'],
together:['M129 224q23 43 63 40c14-1 13-16 1-18l-48-19','M271 224q-23 43-63 40c-14-1-13-16-1-18l48-19'],
cheeks:['M129 224q-3-34 16-37c16-3 23 12 10 20l-12 28','M271 224q3-34-16-37c-16-3-23 12-10 20l12 28'],
hips:['M129 224q-28 2-22 27 4 18 28 7l6-15-15 1 9-14','M271 224q28 2 22 27-4 18-28 7l-6-15 15 1-9-14'],
open:['M129 224q-24 15-41 0c-13-12-22 2-10 15 16 17 39 15 60 1','M271 224q24 15 41 0c13-12 22 2 10 15-16 17-39 15-60 1'],
head:['M129 224q-18-35 5-61c11-13 23-1 14 10l-7 49','M271 224q18-35-5-61c-11-13-23-1-14 10l7 49'],
hero:['M129 224q-25 0-30 19c-2 13 11 19 20 6l20-9','M271 224q25 0 30 19c2 13-11 19-20 6l-20-9'],
self:['M129 224q10 28 44 29c12 0 15-15 3-18l-31-8','M271 224q24 25 13 35-14 10-24-20'],
'heart-shape':['M129 224q20-10 49 0l20 16-4 13-23-17-30 4','M271 224q-20-10-49 0l-20 16 4 13 23-17 30 4'],
hug:['M129 224q13-5 74 18c14 5 8 22-5 18l-60-19','M271 224q-13-5-74 29c-13 7-5 22 8 16l57-27'],
hide:['M129 224q3-38 39-44c16-2 19 14 5 21l-30 35','M271 224q-3-38-39-44c-16-2-19 14-5 21l30 35'],
scratch:['M129 224q-24 25-13 35 14 10 24-20','M271 224q24-44-7-63c-12-8-22 6-10 14l2 47'],
shrug:['M129 224q-28 1-38-16c-8-13-22-6-16 7 8 24 35 34 62 24','M271 224q28 1 38-16c8-13 22-6 16 7-8 24-35 34-62 24'],
chin:['M129 224q-24 25-13 35 14 10 24-20','M271 224q-26 26-60 6c-14-8-6-22 7-16l35 8'],
point:['M129 224q-24 25-13 35 14 10 24-20','M271 224q15-22 14-44v-14c0-10 13-10 14 0l6 21q10 41-35 51'],
rub:['M129 224q28 23 62 11c14-5 20 11 7 17l-58-10','M271 224q-25 10-61 0c-15-4-20 11-6 17l57-1'],
clap:['M132 224q10 23 51 29c11 2 16-7 11-17l-7-12c-5-8-14-2-9 8l-34-10','M268 224q-10 23-51 29c-11 2-16-7-11-17l7-12c5-8 14-2 9 8l34-10'],
cheer:['M129 224q-28-21-7-43c11-10 23 2 14 12l10 30','M271 224q28-21 7-43c-11-10-23 2-14 12l-10 30'],
wipe:['M129 224q-24 25-13 35 14 10 24-20','M271 224q10-34-22-54c-13-8-22 7-9 15l14 39'],
thumb:['M129 224q-24 25-13 35 14 10 24-20','M271 224q19-20 25-19l1-18c1-12 13-10 13 0v17q19-2 18 15c-2 17-30 24-57 19'],
groove:['M129 224q-20 19-34 6c-11-10-23 3-13 13 16 16 38 12 57-3','M271 224q10-23 23-21c15 4 13 18 2 18l-26 17'],
bhangra:['M129 224q-30-24-25-56c3-16 20-13 18 2l24 47','M271 224q30-24 25-56c-3-16-20-13-18 2l-24 47'],
disco:['M129 224q-24 25-13 35 14 10 24-20','M271 224q4-36 38-64l9-11c8-9 17 1 9 9l-3 15q-12 46-54 64'],
wave:['M129 224q-24 25-13 35 14 10 24-20','M271 224q24-21 10-48c-7-14 8-23 16-10 21 35 16 55-24 72'],
beckon:['M129 224q-24 25-13 35 14 10 24-20','M271 224q24-16 30-27c8-14 22-4 15 8-13 22-27 31-47 33'],
five:['M129 224q-24 25-13 35 14 10 24-20','M271 224q17-17 11-38l-6-14c-3-9 6-15 11-7l4 8-3-17c-1-10 10-10 12-1l3 14 2-12c2-8 12-5 11 3l-2 18q16 9 8 24c-10 21-24 34-52 36'],
sorry:['M129 224q-24 25-13 35 14 10 24-20','M271 224q24-11 18-25c-7-14 7-22 14-9 16 26 0 39-31 48'],
ready:['M129 224q-22 13-13 29c8 12 22 5 22-8l6-12','M271 224q22 13 13 29c-8 12-22 5-22-8l-6-12'],
lock:['M129 224q21 31 58 24c13-3 9-18-3-16l-40-9','M271 224q-15 25-47 19c-13-3-9-18 3-16l28-3'],
watch:['M129 224q12 32 47 32c14 0 16-16 2-18l-36-10','M271 224q-24 28-67 22c-15-2-13-18 1-16l50-6'],
pump:['M129 224q-24 25-13 35 14 10 24-20','M271 224q21-11 18-31c-2-14-20-14-20 0l-14 27'],
encourage:['M129 224q-24 25-13 35 14 10 24-20','M271 224q31 7 37-7c6-14 21-7 16 6-10 23-31 25-56 16']};
function faceMarkup(e){return '<g fill="#392b27" stroke="#392b27" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><g class="expression-eyes">'+eyes[e.face]+'</g><g fill="none">'+mouths[e.mouth]+'</g></g>';}
function handsMarkup(e){const p=handPoses[e.hands]||handPoses.low;let h='<g class="hand-fill"><path class="hand-l" d="'+p[0]+'"/>'+(e.hands==='throw'?'':'<path class="hand-r" d="'+p[1]+'"/>')+'</g>';if(e.hands==='watch')h+='<circle cx="174" cy="246" r="8" fill="#f7f1e7" stroke="#9c493a" stroke-width="2"/><path d="m174 241v5l3 2" class="hand-detail"/>';return h;}
const star=(x,y,s=1)=>'<path transform="translate('+x+' '+y+') scale('+s+')" d="M0-10 3-3 10 0 3 3 0 10-3 3-10 0-3-3Z" fill="#d6ac58"/>';
const heart=(x,y,s=1)=>'<path transform="translate('+x+' '+y+') scale('+s+')" d="M0 5C-24-10-10-24 0-13 10-24 24-10 0 5Z" fill="#c85f4b"/>';
const tear=(x,y)=>'<path class="new-effect tear" d="M'+x+' '+y+'q-9 12 0 15 9-3 0-15Z" fill="#88afb1"/>';
function effectsMarkup(e){const f=e.effect;let h='';
if(['spark','burst','confetti','clap','idea'].includes(f))h=star(99,166,.8)+star(305,160,.65);
if(f==='burst'||f==='confetti')h+='<path d="m103 126-9-9m216 20 10-10m-4 77 12 2m-241-1-11 2" class="effect-line"/>';
if(f==='confetti')h+='<g fill="#c85f4b"><path d="m134 96 8-3 4 11-8 3Zm140 7 8 4-5 10-7-3Z"/></g><g fill="#d6ac58"><path d="m186 76 7-2 3 10-7 2Zm134 105 8 3-3 9-8-3Z"/></g>';
if(f==='laugh'||f==='laugh-tears')h+='<path d="m94 182-12-8m13 24H81m225-16 12-8m-13 24h14" fill="none" stroke="#c85f4b" stroke-width="4" stroke-linecap="round"/>';
if(f==='tear'||f==='laugh-tears')h+=tear(152,203);
if(f==='tears'||f==='laugh-tears')h+=tear(248,203)+(f==='tears'?tear(152,203):'');
if(f==='sweat')h+='<path d="M267 163q-13 21 0 24 13-3 0-24Z" fill="#88afb1"/>';
if(f==='puff')h+='<g fill="#df8a76" stroke="#a44c3b" stroke-width="2"><ellipse cx="143" cy="211" rx="17" ry="12"/><ellipse cx="257" cy="211" rx="17" ry="12"/></g>';
if(f==='smoke')h+='<g fill="#c4b6a6"><path class="new-effect steam" d="M151 115c-17 0-17-17-6-19-6-12 8-20 15-11 12-8 22 8 12 15 6 12-9 20-15 13Z"/><path class="new-effect steam" style="animation-delay:.4s" d="M231 115c-17 0-17-17-6-19-6-12 8-20 15-11 12-8 22 8 12 15 6 12-9 20-15 13Z"/></g>';
if(f==='heart'||f==='hearts')h+=heart(300,166,.7)+(f==='hearts'?heart(100,177,.55)+heart(251,96,.45):'');
if(f==='blush')h+='<g fill="#e7a18d"><ellipse cx="146" cy="211" rx="14" ry="8"/><ellipse cx="254" cy="211" rx="14" ry="8"/></g>';
if(f==='question'||f==='questions')h+='<g fill="#a66b51" font-family="system-ui" font-size="33" font-weight="700"><text x="285" y="157">?</text>'+(f==='questions'?'<text x="91" y="161" font-size="26">?</text>':'')+'</g>';
if(f==='dots')h+='<g fill="#a66b51"><circle cx="274" cy="141" r="3"/><circle cx="287" cy="135" r="4"/><circle cx="302" cy="130" r="5"/></g>';
if(f==='idea')h+='<g stroke="#d6ac58" stroke-width="3" fill="#f3dda1"><path d="M288 111c-17-16 13-30 18-12 2 7-6 11-5 16h-12Z"/><path d="M290 120h10"/></g>';
if(f==='crown')h+='<path d="m169 110-7-28 20 12 18-23 17 23 21-12-7 28Z" fill="#d6ac58" stroke="#b28c42" stroke-width="2"/>';
if(f==='exhale')h+='<path d="M230 221q20-10 24 0m-17 6q22 0 21 10" fill="none" stroke="#baac9b" stroke-width="3" stroke-linecap="round"/>';
if(f==='sleep')h+='<g fill="#a38c7b" font-family="system-ui" font-weight="700"><text x="271" y="161" font-size="20">z</text><text x="290" y="137" font-size="26">z</text></g>';
if(f==='notes')h+='<g stroke="#a66b51" fill="#a66b51" stroke-width="3"><path d="M94 170v-24l14-4v20m188-27v-21l13 4v19" fill="none"/><ellipse cx="89" cy="171" rx="6" ry="4"/><ellipse cx="103" cy="164" rx="6" ry="4"/><ellipse cx="291" cy="137" rx="6" ry="4"/></g>';
if(f==='check')h+='<circle cx="302" cy="159" r="17" fill="#839a76"/><path d="m294 159 5 5 10-11" fill="none" stroke="#fffaf2" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>';
if(f==='clock')h+='<circle cx="300" cy="159" r="17" fill="#f7f1e7" stroke="#b98e65" stroke-width="2.5"/><path d="M300 147v12l8 4" fill="none" stroke="#9c493a" stroke-width="3" stroke-linecap="round"/>';
// Tears and steam animate independently. Other effects move as one light vector group.
return '<g class="'+(['tears','tear','smoke','laugh-tears','puff','blush'].includes(f)?'':'new-effect')+'">'+h+'</g>';}

const tempo={breathe:3.2,bounce:.8,jump:1.1,giggle:.45,laugh:.48,roll:1.15,droop:2.5,sigh:2,sob:.6,tilt:2,tap:1.1,stomp:.7,recoil:1.6,surprise:1.1,stretch:1.6,sway:1.6,tremble:.18,shuffle:.3,nod:1.2,proud:1.8,hero:1.5,bow:2.3,hug:1.7,peek:2,scratch:.8,confused:1.6,think:2.4,idea:2.7,plot:.85,'clap-soft':1.2,clap:.65,ovation:.8,wipe:1.7,flop:2.8,sleep:3.4,yawn:2.8,doze:3,groove:1,shimmy:.35,bhangra:.9,disco:1.1,jelly:.75,spin:2.7,wave:1.3,beckon:1.1,five:1.4,sorry:2,bye:1.7,anticipate:1.1,lock:1.4,watch:1.6,pump:1,encourage:2,comeback:2.8};
const byKey = new Map(ADDU_EXPRESSIONS.map(entry => [entry.key, entry]));
const danceAliases = {groove:1, shimmy:2, bhangra:3, disco:4, jelly:5, spin:6};
const gestures = {welcome:'social-1', beckon:'social-2', 'high-five':'social-3', 'good-game':'social-4', sorry:'social-5', bye:'social-6', hug:'love-3'};
const neutralDescription = 'An original terracotta creature with a cream belly, two little feet and a distinctive speech-bubble tail.';

/**
 * Mount one independent ADDU instance. Load addu.css separately in your page.
 * options.svgMarkup: optional trusted, locally supplied SVG string (avoids fetch).
 * options.reducedMotion: static mode; OS reduced-motion always wins.
 * options.pauseOffscreen: defaults true.
 * options.durationMs: defaults 3400 (egg defaults 2900).
 * options.onStateChange: optional callback({key, expression, reducedMotion, paused}).
 */
export async function createAddu(container, options = {}) {
  if (!container || container.nodeType !== 1) throw new TypeError('createAddu requires a dedicated DOM element.');
  const markup = options.svgMarkup ?? await getSvgMarkup();
  const parsed = new DOMParser().parseFromString(markup, 'image/svg+xml');
  if (parsed.querySelector('parsererror') || parsed.documentElement.localName !== 'svg') throw new Error('Invalid ADDU SVG asset.');
  const svg = document.importNode(parsed.documentElement, true);
  // SVG markup is a trusted project asset, not remote/user-submitted input.
  // Namespace IDs, accessibility references and internal fragment links per instance.
  const prefix = `addu-${++nextInstance}-`;
  const idMap = new Map([...svg.querySelectorAll('[id]'), svg].filter(el => el.id).map(el => [el.id, prefix + el.id]));
  [svg, ...svg.querySelectorAll('*')].forEach(el => {
    if (el.id) el.id = idMap.get(el.id);
    for (const attr of ['aria-labelledby', 'aria-describedby']) {
      if (el.hasAttribute(attr)) el.setAttribute(attr, el.getAttribute(attr).split(/\s+/).map(id => idMap.get(id) || id).join(' '));
    }
    for (const attr of [...el.attributes]) {
      let value = attr.value.replace(/url\(#([^)]+)\)/g, (_, id) => `url(#${idMap.get(id) || id})`);
      if (['href', 'xlink:href'].includes(attr.name) && value.startsWith('#')) value = '#' + (idMap.get(value.slice(1)) || value.slice(1));
      if (value !== attr.value) el.setAttribute(attr.name, value);
    }
  });
  instances.get(container)?.destroy();
  container.replaceChildren(svg);
  const part = name => svg.querySelector(`[data-addu-part="${name}"]`);
  const parts = {};
  for (const name of ['expression-face','expression-hands','expression-effects','expression-attire','addu-title','addu-desc']) {
    parts[name] = part(name);
    if (!parts[name]) { svg.remove(); throw new Error(`ADDU SVG is missing its ${name} layer.`); }
  }
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  let forcedStatic = Boolean(options.reducedMotion), current = null, destroyed = false;
  let timer = null, remaining = null, startedAt = null, observer = null;
  const pauses = new Set();
  if (document.hidden) pauses.add('document');
  const reduced = () => forcedStatic || media.matches;
  const clearTimer = () => { if (timer !== null) clearTimeout(timer); timer = null; startedAt = null; };
  const state = () => ({key:current?.key || 'idle', expression:current, reducedMotion:reduced(), paused:pauses.size > 0});
  function emit() {
    if (typeof options.onStateChange === 'function') {
      try { options.onStateChange(state()); } catch (error) { console.error('ADDU state callback failed:', error); }
    }
  }
  function applyRootState() {
    svg.setAttribute('class', 'addu-mascot ' + (current ? `expanded level-${current.level || 2}` : 'is-idle') +
      (reduced() ? ' addu-reduced-motion' : '') + (pauses.size ? ' addu-paused' : ''));
  }
  function schedule() {
    if (destroyed || pauses.size || reduced() || remaining === null) return;
    startedAt = performance.now();
    timer = setTimeout(() => reset(), Math.max(0, remaining));
  }
  function reset() {
    if (destroyed) return false;
    clearTimer(); remaining = null; current = null;
    for (const name of ['expression-face','expression-hands','expression-effects','expression-attire']) parts[name].replaceChildren();
    svg.removeAttribute('data-hands'); svg.removeAttribute('data-motion');
    svg.style.removeProperty('--addu-choreo'); svg.style.removeProperty('--addu-tempo');
    parts['addu-title'].textContent = 'ADDU — neutral idle'; parts['addu-desc'].textContent = neutralDescription;
    applyRootState(); emit(); return true;
  }
  function play(key, playOptions = {}) {
    if (destroyed) return false;
    const entry = typeof key === 'number' ? ADDU_EXPRESSIONS.find(e => e.id === key) : byKey.get(key);
    if (!entry) return false;
    clearTimer();
    // Drop the current state for one style flush to allow same-reaction replay.
    svg.setAttribute('class', 'addu-mascot is-idle' + (reduced() ? ' addu-reduced-motion' : '') + (pauses.size ? ' addu-paused' : ''));
    void svg.getBoundingClientRect();
    current = entry;
    svg.dataset.hands = entry.hands; svg.dataset.motion = entry.motion;
    svg.style.setProperty('--addu-choreo', 'addu-' + entry.motion);
    svg.style.setProperty('--addu-tempo', (tempo[entry.motion] || 1.5) + 's');
    parts['expression-face'].innerHTML = faceMarkup(entry);
    parts['expression-hands'].innerHTML = handsMarkup(entry);
    parts['expression-effects'].innerHTML = effectsMarkup(entry);
    parts['addu-title'].textContent = 'ADDU — ' + entry.name;
    parts['addu-desc'].textContent = entry.desc;
    const requestedDuration = playOptions.durationMs ?? options.durationMs ?? (entry.motion === 'egg' ? 2900 : 3400);
    remaining = playOptions.hold || reduced() ? null : (Number.isFinite(requestedDuration) ? Math.max(100, requestedDuration) : 3400);
    applyRootState(); schedule(); emit(); return true;
  }
  function react(family, {level = 1, ...playOptions} = {}) {
    if (!Number.isInteger(level) || level < 1 || level > 3) return false;
    const entry = byKey.get(`${family}-${level}`);
    return entry?.level ? play(entry.key, playOptions) : false;
  }
  function dance(name, playOptions) {
    const index = danceAliases[name] ?? name;
    return play(`dance-${index}`, playOptions);
  }
  function gesture(name, playOptions) { return gestures[name] ? play(gestures[name], playOptions) : false; }
  function changePause(reason, value) {
    if (destroyed) return;
    const wasPaused = pauses.size > 0;
    if (value) pauses.add(reason); else pauses.delete(reason);
    const nowPaused = pauses.size > 0;
    if (!wasPaused && nowPaused) {
      if (timer !== null && remaining !== null && startedAt !== null) remaining = Math.max(0, remaining - (performance.now() - startedAt));
      clearTimer();
    }
    applyRootState();
    if (wasPaused && !nowPaused) schedule();
  }
  function onVisibility() { changePause('document', document.hidden); }
  function onMotionChange() {
    if (destroyed) return;
    // A static expression holds. Switching back restarts its normal finite motion.
    if (current) play(current.key); else applyRootState();
  }
  function setReducedMotion(value) { if (destroyed) return false; forcedStatic = Boolean(value); onMotionChange(); return true; }
  function destroy() {
    if (destroyed) return;
    clearTimer(); observer?.disconnect(); document.removeEventListener('visibilitychange', onVisibility);
    if (media.removeEventListener) media.removeEventListener('change', onMotionChange); else media.removeListener(onMotionChange);
    svg.remove(); destroyed = true; current = null;
    if (instances.get(container) === api) instances.delete(container);
  }
  document.addEventListener('visibilitychange', onVisibility);
  if (media.addEventListener) media.addEventListener('change', onMotionChange); else media.addListener(onMotionChange);
  if (options.pauseOffscreen !== false && typeof IntersectionObserver !== 'undefined') {
    observer = new IntersectionObserver(entries => changePause('offscreen', !entries[0].isIntersecting));
    observer.observe(container);
  }
  const api = Object.freeze({play, react, dance, gesture, reset, setReducedMotion,
    pause:() => changePause('manual', true), resume:() => changePause('manual', false),
    getState:state, getElement:() => svg, destroy});
  instances.set(container, api); applyRootState(); emit(); return api;
}
