<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! function_exists('wp_all_import_template_notifications') )
{
	function wp_all_import_template_notifications( $post, $type = 'warning')
	{
		$notifications = array();		
		// import template was generated via WP All Export
		if ( ! empty($post['required_add_ons']) )
		{
			foreach ($post['required_add_ons'] as $key => $addon) 
			{
				if (class_exists($key)) continue;

				if ($addon['paid']) {
					/* translators: 1: add-on name, 2: add-on URL, 3: add-on name */
					$template = __('The import template you are using requires the %1$s. If you continue without it your data may import incorrectly.<br/><br/><a href="%2$s" target="_blank">Purchase the %3$s</a>.', 'wp-all-import');
				} else {
					/* translators: 1: add-on name, 2: add-on URL, 3: add-on name */
					$template = __('The import template you are using requires the %1$s. If you continue without it your data may import incorrectly.<br/><br/><a href="%2$s" target="_blank">Download the %3$s</a>.', 'wp-all-import');
				}
				$notifications[] = sprintf($template, esc_attr($addon['name']), esc_url($addon['url']), esc_attr($addon['name']));
			}
		}				
		else // Custom Import Template
		{
			if ( ! function_exists( 'is_plugin_active' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';

			if ( $post['custom_type'] == 'import_users' && ! class_exists('PMUI_Plugin') )
			{
				$notifications[] = __('The import template you are using requires the User Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839963&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169&utm_source=import-plugin-free&utm_medium=upgrade-notice&utm_campaign=import-users-template" target="_blank">Purchase the User Add-On</a>.', 'wp-all-import');						
			}

			if ( $post['custom_type'] == 'shop_customer' && ! class_exists('PMUI_Plugin') )
			{
				$notifications[] = __('The import template you are using requires the User Add-On. If you continue without having this add-on active, your data may import incorrectly.<br/><br/><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839963&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169&utm_source=import-plugin-free&utm_medium=upgrade-notice&utm_campaign=import-users-template" target="_blank">Purchase the User Add-On</a>.', 'wp-all-import');
			}


			elseif ( $post['custom_type'] == 'product' && ! class_exists('PMWI_Plugin') && class_exists( 'Woocommerce' ))
			{
				$notifications[] = __('The import template you are using requires the WooCommerce Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839961&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169&utm_source=import-plugin-free&utm_medium=upgrade-notice&utm_campaign=import-wooco-template" target="_blank">Purchase the WooCommerce Add-On</a>.', 'wp-all-import');				
			}			
			// Realia Add-On
			elseif ( ! empty($post['realia_addon']) and ! is_plugin_active('realia-xml-csv-property-listings-import/realia-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the Realia Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/realia-xml-csv-property-listings-import/" target="_blank">Download the Realia Add-On</a>.', 'wp-all-import');
			}
			// WP Residence Add-On
			elseif ( ! empty($post['realhomes_addon']) 
					and isset($post['realhomes_addon']['property_price']) 
						and ! is_plugin_active('wp-residence-add-on-for-wp-all-import/wp-residence-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the WP Residence Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/wp-residence-add-on-for-wp-all-import/" target="_blank">Download the WP Residence Add-On</a>.', 'wp-all-import');
			}			
			// RealHomes Add-On
			elseif ( ! empty($post['realhomes_addon']) 
					and isset($post['realhomes_addon']['REAL_HOMES_property_price']) 
						and ! is_plugin_active('realhomes-xml-csv-property-listings-import/realhomes-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the RealHomes Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/realhomes-xml-csv-property-listings-import/" target="_blank">Download the RealHomes Add-On</a>.', 'wp-all-import');
			}
			// Jobify Add-On
			elseif ( ! empty($post['jobify_addon']) 					
					and ! is_plugin_active('jobify-xml-csv-listings-import/jobify-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the Jobify Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/jobify-xml-csv-listings-import/" target="_blank">Download the Jobify Add-On</a>.', 'wp-all-import');
			}
			// Listify Add-On
			elseif ( ! empty($post['listify_addon']) 					
					and ! is_plugin_active('listify-xml-csv-listings-import/listify-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the Listify Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/listify-xml-csv-listings-import/" target="_blank">Download the Listify Add-On</a>.', 'wp-all-import');
			}
			// Reales WP Add-On
			elseif ( ! empty($post['reales_addon']) 					
					and ! is_plugin_active('reales-wp-xml-csv-property-listings-import/reales-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the Reales WP Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/reales-wp-xml-csv-property-listings-import/" target="_blank">Download the Reales WP Add-On</a>.', 'wp-all-import');
			}
			// WP Job Manager Add-On
			elseif ( ! empty($post['wpjm_addon']) 					
					and ! is_plugin_active('wp-job-manager-xml-csv-listings-import/wp-job-manager-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the WP Job Manager Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/wp-job-manager-xml-csv-listings-import/" target="_blank">Download the WP Job Manager Add-On</a>.', 'wp-all-import');
			}
			// Yoast SEO Add-On
			elseif ( ! empty($post['yoast_addon']) 					
					and ! is_plugin_active('yoast-seo-settings-xml-csv-import/yoast-addon.php') )
			{
				$notifications[] = __('The import template you are using requires the Yoast SEO Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/yoast-seo-settings-xml-csv-import/" target="_blank">Download the Yoast SEO Add-On</a>.', 'wp-all-import');
			}
			// Listable SEO Add-On
			elseif ( ! empty($post['listable_addon'])
				and ! is_plugin_active('import-xml-csv-listings-to-listable-theme/listable-add-on.php') )
			{
				$notifications[] = __('The import template you are using requires the Listable Add-On. If you continue without it your data may import incorrectly.<br/><br/><a href="https://wordpress.org/plugins/import-xml-csv-listings-to-listable-theme/" target="_blank">Download the Listable Add-On</a>.', 'wp-all-import');
			}
			// 3rd party Add-On
			elseif( ! empty($post['rapid_addon']) and ! is_plugin_active($post['rapid_addon']) )
			{
				$notification[] = __('The import template you are using requires an Add-On for WP All Import. If you continue without using this Add-On your data may import incorrectly.', 'wp-all-import');
			}
		}	

		if ( ! empty($notifications))
		{
			foreach ($notifications as $notification) 
			{
				if ($type == 'warning')
				{
					?>
					<div class="error inline">
						<p><strong><?php esc_html_e('Warning:', 'wp-all-import'); ?></strong> <?php echo wp_kses_post($notification); ?></p>
					</div>
					<?php
				}
				else
				{
					?>
					<div class="wpallimport-free-edition-notice" style="text-align:center; margin-top:0; margin-bottom: 20px;">
						<p class="upgrade_link"><?php echo wp_kses_post($notification);?></p>
					</div>
					<?php
				}
			}
		}
	}
}	