<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Introduce special type for controllers which render pages inside admin area
 *
 * @author Maksym Tsypliakov <maksym.tsypliakov@gmail.com>
 */
abstract class PMXI_Controller_Admin extends PMXI_Controller {
	/**
	 * Admin page base url (request url without all get parameters but `page`)
	 * @var string
	 */
	public $baseUrl;
	/**
	 * Parameters which is left when baseUrl is detected
	 * @var array
	 */
	public $baseUrlParamNames = array('page', 'pagenum', 'order', 'order_by', 'type', 's', 'f');
	/**
	 * Whether controller is rendered inside wordpress page
	 * @var bool
	 */
	public $isInline = false;
	/**
	 * Constructor
	 */
	public function __construct() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$remove = array_diff(array_keys($_GET), $this->baseUrlParamNames);

		$p_url = wp_parse_url( site_url() );

		$url = $p_url['scheme'] . '://' . $p_url['host'];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if (!empty($_POST['is_settings_submitted'])) { // save settings form
			$input = new PMXI_Input();
			$post = $input->post(array(
				'port' => ''
			));
			PMXI_Plugin::getInstance()->updateOption($post);
		}
		
		$port = PMXI_Plugin::getInstance()->getOption('port');

		if ( ! empty($port) and is_numeric($port) ){
            $url .= ':' . $port;
        }
        else{
            $url = ( ! empty($p_url['port']) && ! in_array( $p_url['port'], array( 80, 443 ) ) ) ? $url . ':' . $p_url['port'] : $url;
        }

		if ($remove) {
			$this->baseUrl = $url . remove_query_arg($remove);
		} else {
			$this->baseUrl = $url . esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'] ?? ''));
		}
		
		parent::__construct();

		// enqueue required sripts and styles
		global $wp_styles;
		if ( ! is_a($wp_styles, 'WP_Styles'))
			$wp_styles = new WP_Styles();
		
		wp_enqueue_style('jquery-ui', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/css/redmond/jquery-ui.css', array(), PMXI_VERSION);
		wp_enqueue_style('jquery-tipsy', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/css/smoothness/jquery.tipsy.css', array(), PMXI_VERSION);
		wp_enqueue_style('pmxi-admin-style', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin.css', array(), PMXI_VERSION);
		wp_enqueue_style('pmxi-admin-style-ie', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin-ie.css', array(), PMXI_VERSION);
		wp_enqueue_style('jquery-select2', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/css/select2/select2.css', array(), PMXI_VERSION);
		wp_enqueue_style('jquery-select2-ddslick-compat', WP_ALL_IMPORT_ROOT_URL . '/static/css/select2-v4-ddslick-compat.css', array('jquery-select2'), PMXI_VERSION);
        wp_enqueue_style('jquery-chosen', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/css/chosen/chosen.css', array(), PMXI_VERSION);
		add_editor_style( WP_ALL_IMPORT_ROOT_URL . '/static/css/custom-editor-style.css' );

        wp_enqueue_style('jquery-timepicker', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/css/timepicker/jquery.timepicker.css', array(), PMXI_VERSION);

		wp_enqueue_style('wp-pointer');			
		
		if ( version_compare(get_bloginfo('version'), '3.8-RC1') >= 0 ){
			wp_enqueue_style('pmxi-admin-style-wp-3.8', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin-wp-3.8.css', array(), PMXI_VERSION);
		}
		if ( version_compare(get_bloginfo('version'), '4.0-beta3') >= 0 ){
			wp_enqueue_style('pmxi-admin-style-wp-4.0', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin-wp-4.0.css', array(), PMXI_VERSION);
		}
		if ( version_compare(get_bloginfo('version'), '4.4') >= 0 ){
			wp_enqueue_style('pmxi-admin-style-wp-4.4', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin-wp-4.4.css', array(), PMXI_VERSION);
		}

		$scheme_color = get_user_option('admin_color') and is_file(PMXI_Plugin::ROOT_DIR . '/static/css/admin-colors-' . $scheme_color . '.css') or $scheme_color = 'fresh';
		if (is_file(PMXI_Plugin::ROOT_DIR . '/static/css/admin-colors-' . $scheme_color . '.css')) {
			wp_enqueue_style('pmxi-admin-style-color', WP_ALL_IMPORT_ROOT_URL . '/static/css/admin-colors-' . $scheme_color . '.css', array(), PMXI_VERSION);
		}
	
		wp_enqueue_script('jquery-ui-datepicker', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/ui.datepicker.js', array('jquery-ui-core'), PMXI_VERSION, true);
		//wp_enqueue_script('wp-all-import-autocomplete', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/ui.autocomplete.js', array('jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-position'));
		wp_enqueue_script('tipsy', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/jquery.tipsy.js', array('jquery'), PMXI_VERSION, true);
		wp_enqueue_script('jquery-nestable', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/jquery.mjs.nestedSortable.js', array('jquery', 'jquery-ui-dialog', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-tabs', 'jquery-ui-progressbar'), PMXI_VERSION, true);
		wp_enqueue_script('jquery-select2', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/select2.min.js', array('jquery'), PMXI_VERSION, true);
        wp_enqueue_script('jquery-chosen', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/chosen.jquery.min.js', array('jquery'), PMXI_VERSION, true);
		// ddslick has been replaced with select2
		wp_enqueue_script('jquery-contextmenu', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/jquery.ui-contextmenu.min.js', array('jquery', 'jquery-ui-menu'), PMXI_VERSION, true);

        add_action("admin_enqueue_scripts", [$this, 'add_admin_scripts']);

        wp_enqueue_script('jquery-timepicker', WP_ALL_IMPORT_ROOT_URL . '/static/js/jquery/jquery.timepicker.js', array('jquery'), PMXI_VERSION, true);

		wp_enqueue_script('wp-pointer');

		/* load plupload scripts */
		wp_deregister_script('swfupload-all');
		wp_deregister_script('swfupload-handlers');
		wp_enqueue_script('swfupload-handlers', site_url() . "/wp-includes/js/swfupload/handlers.js", array('jquery'), '2201-20100523', true);

		wp_enqueue_script('jquery-plupload', WP_ALL_IMPORT_ROOT_URL . '/static/js/plupload/wplupload.js', array('plupload', 'jquery'), PMXI_VERSION, true);

		wp_enqueue_script('pmxi-admin-script', WP_ALL_IMPORT_ROOT_URL . '/static/js/admin.js', array('jquery', 'jquery-ui-dialog', 'jquery-ui-datepicker', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-position', 'jquery-ui-autocomplete', 'wp-theme-plugin-editor'), PMXI_VERSION, true);
							
	}

	public function add_admin_scripts() {
        $cm_settings['codeEditor'] = wp_enqueue_code_editor(['type' => 'php']);

        // Use our modified function if user has disabled the syntax editor.
        if(false === $cm_settings['codeEditor']){
        	$cm_settings['codeEditor'] = wpai_wp_enqueue_code_editor(['type' => 'php']);
        }
        wp_localize_script('pmxi-admin-script', 'wpai_cm_settings', $cm_settings);
    }
	
	/**
	 * @see Controller::render()
	 */
	protected function render($viewPath = NULL) {
		// assume template file name depending on calling function
		if (is_null($viewPath)) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
			$trace = debug_backtrace();
			$viewPath = str_replace('_', '/', preg_replace('%^' . preg_quote(PMXI_Plugin::PREFIX, '%') . '%', '', strtolower($trace[1]['class']))) . '/' . $trace[1]['function'];
		}
		parent::render($viewPath);
	}
	
}