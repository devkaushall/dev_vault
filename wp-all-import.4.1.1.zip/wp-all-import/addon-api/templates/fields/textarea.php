<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<textarea data-test="input" class="text widefat rad4" name="<?php echo esc_attr($html_name); ?>" placeholder="<?php echo esc_attr($html_placeholder); ?>"><?php echo esc_attr($field_value); ?></textarea>
