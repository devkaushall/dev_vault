<?php if ( ! defined( 'ABSPATH' ) ) exit; // phpcs:disable WordPress.NamingConventions.PrefixAllGlobals ?>
<?php if ( ! $this->isWizard  or ! empty(PMXI_Plugin::$session->deligate) and PMXI_Plugin::$session->deligate == 'wpallexport' or $this->isWizard and "new" != $post['wizard_type']): ?>
<h4><?php esc_html_e('When WP All Import finds new or changed data...', 'wp-all-import'); ?></h4>
<?php else: ?>
<h4><?php esc_html_e('If this import is run again and WP All Import finds new or changed data...', 'wp-all-import'); ?></h4>
<?php endif; ?>
<?php

	if (!empty($post['custom_type'])){
		$custom_type = get_post_type_object( $post['custom_type'] );
		$cpt_name = ( ! empty($custom_type)) ? strtolower($custom_type->label) : '';
	}
	else{
		$cpt_name = '';
	}

	$hidden_data_to_update_options = apply_filters('pmxi_hidden_data_to_update_options', [], $post['custom_type']);

?>
<div class="input">
	<input type="hidden" name="create_new_records" value="0" />
	<input type="checkbox" id="create_new_records" name="create_new_records" value="1" <?php echo $post['create_new_records'] ? 'checked="checked"' : '' ?> />
	<label for="create_new_records"><?php printf(
		/* translators: %s: custom post type name (lowercased) */
		esc_html__('Create new %s from records newly present in your file', 'wp-all-import'),
		esc_html($cpt_name)
	) ?></label>
	<?php if ( ! empty(PMXI_Plugin::$session->deligate) and PMXI_Plugin::$session->deligate == 'wpallexport' ): ?>
	<a href="#help" class="wpallimport-help" title="<?php esc_html_e('New posts will only be created when ID column is present and value in ID column is unique.', 'wp-all-import') ?>" style="top: -1px;">?</a>
	<?php endif; ?>
</div>
<div class="input">
	<input type="hidden" id="is_keep_former_posts" name="is_keep_former_posts" value="yes" />
	<input type="checkbox" id="is_not_keep_former_posts" name="is_keep_former_posts" value="no" <?php echo "yes" != $post['is_keep_former_posts'] ? 'checked="checked"': '' ?> class="switcher" />
	<label for="is_not_keep_former_posts"><?php printf(
		/* translators: %s: custom post type name (lowercased) */
		esc_html__('Update existing %s with changed data in your file', 'wp-all-import'),
		esc_html($cpt_name)
	) ?></label>
	<?php if ( $this->isWizard and "new" == $post['wizard_type'] and empty(PMXI_Plugin::$session->deligate)): ?>
	<a href="#help" class="wpallimport-help" style="position: relative; top: -2px;" title="<?php echo esc_attr( sprintf(
		/* translators: 1: custom post type name, 2: custom post type name */
		__('These options will only be used if you run this import again later. All data is imported the first time you run an import.<br/><br/>Note that WP All Import will only update/remove %1$s created by this import. If you want to match to %2$s that already exist on this site, use Existing Items in Step 1.', 'wp-all-import'),
		$cpt_name,
		$cpt_name
	) ) ?>">?</a>
	<?php endif; ?>
	<div class="switcher-target-is_not_keep_former_posts" style="padding-left:17px;">

        <div class="input" style="margin-left: 4px;">
            <input type="hidden" name="is_selective_hashing" value="0" />
            <input type="checkbox" id="is_selective_hashing" name="is_selective_hashing" value="1" <?php echo $post['is_selective_hashing'] ? 'checked="checked"': '' ?> class="switcher"/>
            <label for="is_selective_hashing"><?php printf(
                /* translators: %s: custom post type name (lowercased) */
                esc_html__('Skip %s if their data in your file has not changed', 'wp-all-import'),
                esc_html(strtolower($custom_type->labels->name))
            ); ?></label>
            <a href="#help" class="wpallimport-help" style="position: relative; top: -2px;" title="<?php esc_html_e('When enabled, WP All Import will keep track of every post\'s data as it is imported. When the import is run again, posts will be skipped if their data in the import file has not changed since the last run.<br/><br/>Posts will not be skipped if the import template or settings change, or if you make changes to the custom code in the Function Editor.', 'wp-all-import') ?>">?</a>
            <div class="switcher-target-is_selective_hashing" style="padding-left:17px;">
                <div class="wpallimport-free-edition-notice" style="margin: 0 0 30px 7px;">
                    <a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&amp;download_id=5839966&amp;edd_options%5Bprice_id%5D=1&amp;utm_source=import-plugin-free&amp;utm_medium=upgrade-notice&amp;utm_campaign=download-from-url" target="_blank" class="upgrade_link"><?php esc_html_e('Upgrade to the Pro edition of WP All Import to use this option', 'wp-all-import'); ?></a>
                    <p style="margin-top:16px;"><?php esc_html_e('If you already own it, remove the free edition and install the Pro edition.', 'wp-all-import'); ?></p>
                </div>
            </div>
        </div>

		<input type="radio" id="update_all_data" class="switcher" name="update_all_data" value="yes" <?php echo 'no' != $post['update_all_data'] ? 'checked="checked"': '' ?>/>
		<label for="update_all_data"><?php esc_html_e('Update all data', 'wp-all-import' )?></label><br>

		<input type="radio" id="update_choosen_data" class="switcher" name="update_all_data" value="no" <?php echo 'no' == $post['update_all_data'] ? 'checked="checked"': '' ?>/>
		<label for="update_choosen_data"><?php esc_html_e('Choose which data to update', 'wp-all-import' )?></label><br>
		<div class="switcher-target-update_choosen_data"  style="padding-left:27px;">
			<div class="input">
				<h4 class="wpallimport-trigger-options wpallimport-select-all" rel="<?php esc_html_e("Unselect All", "wp-all-import"); ?>"><?php esc_html_e("Select All", "wp-all-import"); ?></h4>
			</div>
			<?php if ( !in_array('is_update_status', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_status" value="0" />
				<input type="checkbox" id="is_update_status" name="is_update_status" value="1" <?php echo $post['is_update_status'] ? 'checked="checked"': '' ?> />
				<label for="is_update_status"><?php esc_html_e('Post status', 'wp-all-import') ?></label>
				<a href="#help" class="wpallimport-help" style="position: relative; top: -2px;" title="<?php esc_html_e('Hint: uncheck this box to keep trashed posts in the trash.', 'wp-all-import') ?>">?</a>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_title', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_title" value="0" />
				<input type="checkbox" id="is_update_title" name="is_update_title" value="1" <?php echo $post['is_update_title'] ? 'checked="checked"': '' ?> />
				<label for="is_update_title"><?php esc_html_e('Title', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_author', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_author" value="0" />
				<input type="checkbox" id="is_update_author" name="is_update_author" value="1" <?php echo $post['is_update_author'] ? 'checked="checked"': '' ?> />
				<label for="is_update_author"><?php esc_html_e('Author', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_slug', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_slug" value="0" />
				<input type="checkbox" id="is_update_slug" name="is_update_slug" value="1" <?php echo $post['is_update_slug'] ? 'checked="checked"': '' ?> />
				<label for="is_update_slug"><?php esc_html_e('Slug', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_content', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_content" value="0" />
				<input type="checkbox" id="is_update_content" name="is_update_content" value="1" <?php echo $post['is_update_content'] ? 'checked="checked"': '' ?> />
				<label for="is_update_content"><?php esc_html_e('Content', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_excerpt', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_excerpt" value="0" />
				<input type="checkbox" id="is_update_excerpt" name="is_update_excerpt" value="1" <?php echo $post['is_update_excerpt'] ? 'checked="checked"': '' ?> />
				<label for="is_update_excerpt"><?php esc_html_e('Excerpt/Short Description', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_dates', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_dates" value="0" />
				<input type="checkbox" id="is_update_dates" name="is_update_dates" value="1" <?php echo $post['is_update_dates'] ? 'checked="checked"': '' ?> />
				<label for="is_update_dates"><?php esc_html_e('Dates', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_menu_order', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_menu_order" value="0" />
				<input type="checkbox" id="is_update_menu_order" name="is_update_menu_order" value="1" <?php echo $post['is_update_menu_order'] ? 'checked="checked"': '' ?> />
				<label for="is_update_menu_order"><?php esc_html_e('Menu order', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_parent', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_parent" value="0" />
				<input type="checkbox" id="is_update_parent" name="is_update_parent" value="1" <?php echo $post['is_update_parent'] ? 'checked="checked"': '' ?> />
				<label for="is_update_parent"><?php esc_html_e('Parent post', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_post_type', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_post_type" value="0" />
				<input type="checkbox" id="is_update_post_type" name="is_update_post_type" value="1" <?php echo $post['is_update_post_type'] ? 'checked="checked"': '' ?> />
				<label for="is_update_post_type"><?php esc_html_e('Post type', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_post_format', $hidden_data_to_update_options) ): ?>
			<?php if ( current_theme_supports( 'post-formats' ) && post_type_supports( $post_type, 'post-formats' ) ): ?>
            <div class="input">
                <input type="hidden" name="is_update_post_format" value="0" />
                <input type="checkbox" id="is_update_post_format" name="is_update_post_format" value="1" <?php echo $post['is_update_post_format'] ? 'checked="checked"': '' ?> />
                <label for="is_update_post_format"><?php esc_html_e('Post format', 'wp-all-import') ?></label>
            </div>
            <?php endif; ?>
			<?php endif; ?>
			<?php if ( !in_array('is_update_comment_status', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_comment_status" value="0" />
				<input type="checkbox" id="is_update_comment_status" name="is_update_comment_status" value="1" <?php echo $post['is_update_comment_status'] ? 'checked="checked"': '' ?> />
				<?php if ($post_type == 'product' and class_exists('PMWI_Plugin')): ?>
					<label for="is_update_comment_status"><?php esc_html_e('Enable review setting', 'wp-all-import') ?></label>
				<?php else: ?>
					<label for="is_update_comment_status"><?php esc_html_e('Comment status', 'wp-all-import') ?></label>
				<?php endif;?>
			</div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_ping_status', $hidden_data_to_update_options) ): ?>
            <div class="input">
                <input type="hidden" name="is_update_ping_status" value="0" />
                <input type="checkbox" id="is_update_ping_status" name="is_update_ping_status" value="1" <?php echo $post['is_update_ping_status'] ? 'checked="checked"': '' ?> />
                <label for="is_update_ping_status"><?php esc_html_e('Trackbacks and pingbacks', 'wp-all-import') ?></label>
            </div>
			<?php endif; ?>
			<?php if ( !in_array('is_update_attachments', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_attachments" value="0" />
				<input type="checkbox" id="is_update_attachments" name="is_update_attachments" value="1" <?php echo $post['is_update_attachments'] ? 'checked="checked"': '' ?> />
				<label for="is_update_attachments"><?php esc_html_e('Attachments', 'wp-all-import') ?></label>
			</div>
			<?php endif; ?>

			<?php

				// add-ons re-import options
				do_action('pmxi_reimport', $post_type, $post);

			?>

			<?php if ( !in_array('is_update_images', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="is_update_images" value="0" />
				<input type="checkbox" id="is_update_images" name="is_update_images" value="1" <?php echo $post['is_update_images'] ? 'checked="checked"': '' ?> class="switcher" />
				<label for="is_update_images"><?php esc_html_e('Images', 'wp-all-import') ?></label>
				<!--a href="#help" class="wpallimport-help" title="<?php esc_html_e('This will keep the featured image if it exists, so you could modify the post image manually, and then do a reimport, and it would not overwrite the manually modified post image.', 'wp-all-import') ?>">?</a-->
				<div class="switcher-target-is_update_images" style="padding-left:17px;">
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_images_logic_full_update" name="update_images_logic" value="full_update" <?php echo ( "full_update" == $post['update_images_logic'] ) ? 'checked="checked"': '' ?> />
						<label for="update_images_logic_full_update"><?php esc_html_e('Update all images', 'wp-all-import') ?></label>
					</div>
					<?php $is_show_add_new_images = apply_filters('wp_all_import_is_show_add_new_images', true, $post_type); ?>
					<?php if ($is_show_add_new_images): ?>
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_images_logic_add_new" name="update_images_logic" value="add_new" <?php echo ( "add_new" == $post['update_images_logic'] ) ? 'checked="checked"': '' ?> />
						<label for="update_images_logic_add_new"><?php esc_html_e('Don\'t touch existing images, append new images', 'wp-all-import') ?></label>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>

			<?php if ( !in_array('is_update_custom_fields', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="custom_fields_list" value="0" />
				<input type="hidden" name="is_update_custom_fields" value="0" />
				<input type="checkbox" id="is_update_custom_fields" name="is_update_custom_fields" value="1" <?php echo $post['is_update_custom_fields'] ? 'checked="checked"': '' ?>  class="switcher"/>
				<label for="is_update_custom_fields"><?php esc_html_e('Custom Fields', 'wp-all-import') ?></label>
				<!--a href="#help" class="wpallimport-help" title="<?php esc_html_e('If Keep Custom Fields box is checked, it will keep all Custom Fields, and add any new Custom Fields specified in Custom Fields section, as long as they do not overwrite existing fields. If \'Only keep this Custom Fields\' is specified, it will only keep the specified fields.', 'wp-all-import') ?>">?</a-->
				<div class="switcher-target-is_update_custom_fields" style="padding-left:17px;">
					<div class="input">
						<input type="radio" id="update_custom_fields_logic_full_update" name="update_custom_fields_logic" value="full_update" <?php echo ( "full_update" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_custom_fields_logic_full_update"><?php esc_html_e('Update all Custom Fields', 'wp-all-import') ?></label>
					</div>
					<div class="input">
						<input type="radio" id="update_custom_fields_logic_only" name="update_custom_fields_logic" value="only" <?php echo ( "only" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_custom_fields_logic_only"><?php esc_html_e('Update only these Custom Fields, leave the rest alone', 'wp-all-import') ?></label>
						<div class="switcher-target-update_custom_fields_logic_only pmxi_choosen" style="padding-left:17px;">
							<span class="hidden choosen_values"><?php if (!empty($existing_meta_keys)) echo esc_html(implode(',', $existing_meta_keys));?></span>
							<input class="choosen_input" value="<?php if (!empty($post['custom_fields_list']) and "only" == $post['update_custom_fields_logic']) echo esc_html(implode(',', $post['custom_fields_list'])); ?>" type="hidden" name="custom_fields_only_list"/>
						</div>
					</div>
					<div class="input">
						<input type="radio" id="update_custom_fields_logic_all_except" name="update_custom_fields_logic" value="all_except" <?php echo ( "all_except" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_custom_fields_logic_all_except"><?php esc_html_e('Leave these fields alone, update all other Custom Fields', 'wp-all-import') ?></label>
						<div class="switcher-target-update_custom_fields_logic_all_except pmxi_choosen" style="padding-left:17px;">
							<span class="hidden choosen_values"><?php if (!empty($existing_meta_keys)) echo esc_html(implode(',', $existing_meta_keys));?></span>
							<input class="choosen_input" value="<?php if (!empty($post['custom_fields_list']) and "all_except" == $post['update_custom_fields_logic']) echo esc_html(implode(',', $post['custom_fields_list'])); ?>" type="hidden" name="custom_fields_except_list"/>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>

			<?php if ( !in_array('is_update_taxonomies', $hidden_data_to_update_options) ): ?>
			<div class="input">
				<input type="hidden" name="taxonomies_list" value="0" />
				<input type="hidden" name="is_update_categories" value="0" />
				<input type="checkbox" id="is_update_categories" name="is_update_categories" value="1" class="switcher" <?php echo $post['is_update_categories'] ? 'checked="checked"': '' ?> />
				<label for="is_update_categories"><?php esc_html_e('Taxonomies (incl. Categories and Tags)', 'wp-all-import') ?></label>
				<div class="switcher-target-is_update_categories" style="padding-left:17px;">
					<?php
					$existing_taxonomies = array();
					$hide_taxonomies = (class_exists('PMWI_Plugin')) ? array('product_type', 'product_visibility') : array();
					$post_taxonomies = array_diff_key(get_taxonomies_by_object_type($post['is_override_post_type'] ? array_keys(get_post_types( '', 'names' )) : array($post_type), 'object'), array_flip($hide_taxonomies));
					if (!empty($post_taxonomies)):
						foreach ($post_taxonomies as $ctx):  if ("" == $ctx->labels->name or (class_exists('PMWI_Plugin') and $post_type == "product" and strpos($ctx->name, "pa_") === 0)) continue;
							$existing_taxonomies[] = $ctx->name;
						endforeach;
					endif;
					?>
                    <div class="switcher-target-is_update_categories" style="padding-left:17px;">
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_categories_logic_all_except" name="update_categories_logic" value="all_except" <?php echo ( "all_except" == $post['update_categories_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_categories_logic_all_except"><?php esc_html_e('Leave these taxonomies alone, update all others', 'wp-all-import') ?></label>
						<div class="switcher-target-update_categories_logic_all_except pmxi_choosen" style="padding-left:17px;">
							<span class="hidden choosen_values"><?php if (!empty($existing_taxonomies)) echo esc_html(implode(',', $existing_taxonomies));?></span>
							<input class="choosen_input" value="<?php if (!empty($post['taxonomies_list']) and "all_except" == $post['update_categories_logic']) echo esc_html(implode(',', $post['taxonomies_list'])); ?>" type="hidden" name="taxonomies_except_list"/>
						</div>
					</div>
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_categories_logic_only" name="update_categories_logic" value="only" <?php echo ( "only" == $post['update_categories_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_categories_logic_only"><?php esc_html_e('Update only these taxonomies, leave the rest alone', 'wp-all-import') ?></label>
						<div class="switcher-target-update_categories_logic_only pmxi_choosen" style="padding-left:17px;">
							<span class="hidden choosen_values"><?php if (!empty($existing_taxonomies)) echo esc_html(implode(',', $existing_taxonomies));?></span>
							<input class="choosen_input" value="<?php if (!empty($post['taxonomies_list']) and "only" == $post['update_categories_logic']) echo esc_html(implode(',', $post['taxonomies_list'])); ?>" type="hidden" name="taxonomies_only_list"/>
						</div>
					</div>
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_categories_logic_full_update" name="update_categories_logic" value="full_update" <?php echo ( "full_update" == $post['update_categories_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_categories_logic_full_update"><?php esc_html_e('Remove existing taxonomies, add new taxonomies', 'wp-all-import') ?></label>
					</div>
					<div class="input" style="margin-bottom:3px;">
						<input type="radio" id="update_categories_logic_add_new" name="update_categories_logic" value="add_new" <?php echo ( "add_new" == $post['update_categories_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
						<label for="update_categories_logic_add_new"><?php esc_html_e('Only add new', 'wp-all-import') ?></label>
					</div>
				</div>
			</div>
			<?php
				// add-ons re-import options
				do_action('pmxi_reimport_options_after_taxonomies', $post_type, $post);
			?>
			<?php endif; ?>
		</div>
	</div>
</div>
<div class="switcher-target-auto_matching">
    <?php include( '_delete_missing_options.php' ); ?>
</div>
