# Internal implementation map

**Audit date:** 2026-10-06  
**Release status:** **NOT READY**. The source tree is an established React/TypeScript application; preserve it and its verified behavior. This map is a dependency-ordered view of existing work and remaining acceptance, not a new phase plan. Requirements remain defined by `Chess_Game_Master_Product_Technical_Spec_v1.0_HI.md`, `Chess_Game_Master_Research_HI.md`, and `Chess_Game_Master_Chess_Atlas_HI.md`.

## Existing architecture and ownership

- **Application shell and routes — `src/app/`**: React screens, navigation, local-store context, mode policy, persisted display/time-control preferences, Settings, and Practice resume/review routing. `src/components/ChessWorkspace.tsx` is the shared board workspace. Keep engine-mode decisions behind `src/app/modePolicy.ts` and the fail-closed engine gate.
- **Chess domain — `src/domain/chess/`**: `chess.js`-backed legal moves, canonical legal SAN/UCI history, repetition/draw state, FEN/PGN adapters, immutable game transitions, and conservative terminal classification. The domain owns rules; the UI must not create a second legality/adjudication implementation.
- **Clock domain — `src/domain/clock/`**: monotonic Fischer clock, revisions, increment and paused snapshots. Practice UI starts only after explicit user action; timed records recover paused. Any unresolved flag result stays locked rather than receiving an invented result.
- **Knowledge and review — `src/knowledge/`**: provenance-bearing local opening data, bounded strategy/pawn/tactic/attack/defence/endgame recognition, shared evidence aggregation, move classification, key moments, evidence-bound explanations and candidate learning insights. Recognition is not engine evaluation or human-intent inference.
- **Learning and local state — `src/learning/`, `src/storage/LocalChessStore.ts`**: lesson/puzzle/opening progress, IndexedDB schema-v2 validation/migration, analysis sidecars, row quarantine/recovery, backup export/restore and deletion.
- **Engine boundary — `src/engine/`**: generic UCI adapter and test-only transport fake; `engineGate.ts` refuses creation while approval/assets/runtime are unavailable. There is no Stockfish binary, NNUE, real Worker, substitute bot, LLM analysis or human multiplayer.
- **PWA, static assets and release metadata — `src/pwa/`, `public/`, `index.html`, `SBOM.cdx.json`**: v4 service-worker shell/cache and explicit update prompt, bundled CC0 opening index, notices, manifest, CSP meta, `_headers`, and CycloneDX SBOM. `public/_headers` requires a compatible deploy host; Vite preview does not apply it as response headers.
- **Verification**: Vitest suites live beside source as `*.test.ts(x)`. Current final evidence is summarized in `IMPLEMENTATION_STATUS.md` and the product contract remains unchanged.

## Verified integrated workflows

- Settings persists board coordinates/orientation, reduced-motion choice, and the next Practice clock preset; those values affect a newly opened/timed board.
- A timed local Practice board starts, accepts and saves legal moves, pauses on browser lifecycle changes, can be stopped without assigning a chess result, and remains recoverable from local storage.
- A standard, untouched scratch board does not create a history row; its first legal move makes it durable. Timed/custom-FEN and previously saved records remain durable.
- Local backup downloads and validated restore cover games/clocks, progress, analysis, recovery copies and app preferences; a production-browser JSON download contained both a result-free aborted game and a paused timed Practice game. Import merges and does not overwrite matching IDs.
- After an online preload, a production-browser v3-cache predecessor simulation upgraded to the real v4 `/sw.js`; the v3 cache was removed, and offline reload resumed a saved timed Practice game and accepted/saved `e7-e5`. The predecessor worker was simulated from current source with its cache label reverted; this is not a historical deployed-worker test.
- PGN file import is now tested end-to-end through file selection → textarea population → explicit validation → self-review, with separate tests for the 500 KB size limit and file-read failure.
- Settings labels/messages/accessible names are partially in Hindi; other screens remain mostly English.
- Final suite: 37 test files / 300 tests; typecheck, production build and both npm audits pass. Production Chromium and the responsive/accessibility checks are detailed in `IMPLEMENTATION_STATUS.md`.

## Agreed work split: three development parts, then final practical test

This is a grouping of the existing requirements—not a new phase plan and not permission to remove any V1 requirement. A part only passes its exit check when its required tests pass and no known blocker is being described as resolved. If an external approval or asset is missing, mark the part **BLOCKED** and do not carry it forward as if complete.

### Part 1 — Fix correctness, safety, and reliability problems

**Goal:** make the existing app’s chess outcomes, saved data, clocks, imports, and offline behavior dependable without rebuilding working features.

- Finish FIDE dead-position and timeout adjudication (including the “can mate by any legal sequence” rule); preserve checkmate precedence and distinct draw/resignation/timeout/abort results. The current `adjudication-pending` fallback is safer than a guessed result but means this part is not passed.
- Audit clock start/pause/flag/recovery, legal move/history replay, draw claims and result transitions; keep the existing chess.js rules boundary.
- Close remaining data-reliability edges: IndexedDB write/quota failures, migration and multi-tab races, recovery/export behavior, and malformed/hostile PGN/FEN/storage input. PGN file load/size/read coverage is now tested.
- Retain and recheck the v4 service-worker update/offline path and previously working save/resume/backup behavior.
- **End-of-part check:** targeted rules/storage/clock/import/PWA tests; full test suite, typecheck, production build and audits; Chromium critical-flow checks. Do not pass Part 1 while a known false-result/data-loss defect or the required FIDE adjudication gap remains.
- **Part 1 research started:** [CHA-Solver 3.0.0](https://github.com/miguel-ambrona/chasolver) ([crate](https://crates.io/crates/chasolver)) is an MIT-licensed helpmate/unwinnability solver, not a playing/evaluation engine. Its upstream native test suite passed (8 unit, 2 integration, 1 doc test); the two upstream integration datasets took about 20 minutes in this debug run. A temporary Rust→WASM proof of concept compiled to 984 KB (about 96 KB gzip) and matched the upstream Article 6.9 example: it proved Black unwinnable and returned a White helpmate. Nothing from the prototype has been added to the app. Before considering integration, audit draw counters/history (the crate's Board has no move-counter history), validate every returned line with chess.js, keep `None` as pending, test timeout/runtime limits in a Worker, and check all transitive licenses. Upstream says some searches can return unknown and does not claim a proof of completeness for every theoretical legal position; this is a candidate, not acceptance.
- **Current state: IN PROGRESS.** The existing 37-file/300-test app suite and earlier browser checks passed, but the FIDE gap and untested storage-failure/race cases remain open. The candidate solver is not integrated or used to close any app requirement.

### Part 2 — Complete the required user-facing features

**Goal:** close the original product requirements while preserving local-first use and fair-play rules.

- Complete Hindi-first text across screens; add the missing learning progression/levels and broaden lessons, puzzles, opening coverage and reviewed chess knowledge against the original specification/Atlas.
- Complete Review within the approved scope: progressive explanation depth and supporting workflow, while retaining original-game immutability and clearly separating verified facts from candidates. Preserve explicit PGN limitations unless a safe, tested variation/comment implementation is added.
- **Engine is an external gate, not an assumed task:** before any Stockfish work, obtain written GPL-3.0-or-later distribution approval and owner-approved Stockfish 19 source/build, NNUE, notices and distribution plan. Until then, keep engine modes unavailable; do not add a substitute, fake evaluation, hidden fallback, LLM analysis or competitive-human assistance. Part 2 cannot pass the V1 engine requirement without these artifacts.
- **End-of-part check:** requirement-by-requirement crosswalk; tests for every completed screen and mode; verify privacy, uncertainty wording, original Review history and Challenge fair-play policy; full tests/typecheck/build again. Anything gated by missing approval stays explicitly BLOCKED.

### Part 3 — Make the accepted app ready for release

**Goal:** produce a reproducible, secure, accessible web release and prepare the later Android/Play Store route—without publishing yet.

- Verify production CSP/security headers on the chosen real static host; confirm HTTPS, service-worker scope/update behavior, icon/data provenance, dependency notices and synchronized SBOM.
- Complete manual WCAG 2.2 AA/screen-reader, keyboard/touch, zoom/forced-colors, real-browser/device and named-hardware performance checks; close storage quota, offline eviction and worker-failure checks that apply to the accepted features.
- Prepare the web production build. For the user-requested Play Store follow-on, choose Trusted Web Activity or Capacitor, confirm the permanent Android app ID, create/sign an Android App Bundle, test it on real Android devices, and prepare Play Console privacy/data-safety/store details. Play Console account and owner-controlled signing credentials are required; do not put secrets in the repository.
- **End-of-part check:** repeat all automated gates; verify the built artifacts and real-host headers; review every legal/security/accessibility item. A build alone is not release approval.

### Part 4 — Final practical-use acceptance

This is the user’s real-world acceptance check after Parts 1–3 pass, not another development backlog bucket. Play realistic games and learning/review flows on target desktop and Android devices; test online and offline use after caching, app update, save/resume, backup/restore/delete, accessibility controls, and the signed store build. Record failures, fix them in the relevant earlier part, and rerun that part’s exit checks. Only after these practical checks and all external gates pass may the release status change from **NOT READY**.

## Scope protections

- Do not restart or replace the working React/TypeScript app, reimplement validated chess.js rules, or remove Phase 1–7 behavior to make the matrix look smaller.
- Phase 8 remains **BLOCKED** until the licensing gate is actually met. Do not use a different engine, fake evaluation, hidden fallback, LLM analysis, or live competitive-human assistance.
- Keep the app local-first; preserve original Review history, existing fair-play policy, uncertainty labels and recovery data.
- Do not treat FEN as repetition history, candidates as forced plans, engine scores as human intent, or automated scans as complete legal/accessibility sign-off.
- Historical numbered phase notes remain in the status document for traceability; this map adds no numbered phase structure and does not silently remove any original requirement.