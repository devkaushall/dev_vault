import { useEffect, useState, type ChangeEvent } from 'react';
import { applyReducedMotionPreference, isAppPreferences, readAppPreferences, replaceAppPreferences, TIME_CONTROL_PRESETS, updateAppPreferences, type AppPreferences } from '../preferences';
import { STOCKFISH_LICENSING_GATE } from '../../engine/engineGate';
import { useLocalStore } from '../StoreContext';

export function SettingsScreen() {
  const store = useLocalStore();
  const [online, setOnline] = useState(navigator.onLine);
  const [serviceWorker, setServiceWorker] = useState('ऑफ़लाइन सुविधा जाँची जा रही है…');
  const [message, setMessage] = useState('');
  const [preferenceMessage, setPreferenceMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [preferences, setPreferences] = useState<AppPreferences>(() => readAppPreferences());

  const savePreference = (patch: Partial<AppPreferences>) => {
    const result = updateAppPreferences(patch);
    setPreferences(result.preferences);
    if (patch.reducedMotion) applyReducedMotionPreference(patch.reducedMotion);
    setPreferenceMessage(result.persisted ? 'पसंद इस ब्राउज़र में सहेजी गई।' : 'पसंद इस स्क्रीन के लिए बदली, लेकिन ब्राउज़र में सहेज नहीं सके।');
  };

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
  }, []);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) {
      setServiceWorker('यह ब्राउज़र ऑफ़लाइन सुविधा का समर्थन नहीं करता।');
      return;
    }
    void navigator.serviceWorker.getRegistration('/').then((registration) => {
      setServiceWorker(registration ? 'ऑफ़लाइन ऐप तैयार है।' : 'ऑफ़लाइन सुविधा तैयार करने के लिए ऐप को एक बार इंटरनेट के साथ खोलें।');
    }).catch(() => setServiceWorker('ऑफ़लाइन सुविधा की स्थिति जाँची नहीं जा सकी।'));
  }, []);

  const exportAllData = async () => {
    setBusy(true);
    try {
      const backup = JSON.parse(await store.exportBackup()) as Record<string, unknown>;
      backup.appPreferences = readAppPreferences();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      if (blob.size > 25_000_000) throw new Error('स्थानीय बैकअप डाउनलोड की 25 MB सीमा से बड़ा है।');
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `chess-game-master-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      setMessage('स्थानीय बैकअप डाउनलोड हो गया। यह एन्क्रिप्टेड नहीं है—फ़ाइल किसी सुरक्षित जगह रखें।');
    } catch (error) {
      setMessage(`बैकअप नहीं बना: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण में समस्या'}`);
    } finally {
      setBusy(false);
    }
  };

  const importAllData = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (file.size > 25_000_000) {
      setMessage('बैकअप फ़ाइल 25 MB की सुरक्षा सीमा से बड़ी है।');
      return;
    }
    if (!window.confirm('क्या इस बैकअप को इस ब्राउज़र के डेटा में जोड़ें? एक जैसी ID वाले मौजूदा रिकॉर्ड नहीं बदले जाएँगे। बैकअप की पसंद मौजूदा पसंद की जगह लेगी।')) return;
    setBusy(true);
    try {
      const json = await file.text();
      let decoded: unknown;
      try { decoded = JSON.parse(json); }
      catch { throw new Error('बैकअप फ़ाइल सही JSON नहीं है।'); }
      if (!decoded || typeof decoded !== 'object' || Array.isArray(decoded) || !isAppPreferences((decoded as Record<string, unknown>).appPreferences)) {
        throw new Error('बैकअप में ऐप की सही पसंद नहीं मिली। डिवाइस का कोई डेटा नहीं बदला।');
      }
      const importedPreferences = (decoded as Record<string, unknown>).appPreferences as AppPreferences;
      const summary = await store.restoreBackup(json);
      const preferenceSaved = replaceAppPreferences(importedPreferences);
      setPreferences(importedPreferences);
      if (!preferenceSaved) applyReducedMotionPreference(importedPreferences.reducedMotion);
      const count = (values: typeof summary.added) => Object.values(values).reduce((total, value) => total + value, 0);
      const added = count(summary.added);
      const skipped = count(summary.skipped);
      setMessage(`बैकअप बहाल हुआ: ${added} नए रिकॉर्ड जोड़े, ${skipped} पहले से मौजूद रिकॉर्ड छोड़े गए।${preferenceSaved ? '' : ' बैकअप की पसंद ब्राउज़र में सहेजी नहीं जा सकी।'}`);
    } catch (error) {
      setMessage(`बैकअप बहाल नहीं हुआ: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण में समस्या'}`);
    } finally {
      setBusy(false);
    }
  };

  const eraseAll = async () => {
    if (!window.confirm('क्या इस ब्राउज़र से सभी खेल, समीक्षा, पाठ के प्रयास, पहेली प्रगति और ओपनिंग अभ्यास हमेशा के लिए मिटाएँ?')) return;
    setBusy(true);
    try {
      await store.clearAllData();
      setMessage('डिवाइस पर सहेजा खेल और सीखने का डेटा मिटा दिया गया।');
    } catch (error) {
      setMessage(`डेटा नहीं मिटा: ${error instanceof Error ? error.message : 'स्थानीय संग्रहण में समस्या'}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="screen-content settings-screen">
      <header className="screen-heading"><div><p className="eyebrow">पसंद · इसी डिवाइस पर संग्रहण</p><h1>सेटिंग और गोपनीयता</h1><p className="screen-description">आपके खेल और प्रगति इसी ब्राउज़र में रहती है। यह स्थानीय संग्रहण है—न एन्क्रिप्टेड तिजोरी, न क्लाउड बैकअप।</p></div><span className={`online-pill ${online ? 'online' : 'offline'}`}><i />{online ? 'ऑनलाइन' : 'ऑफ़लाइन'}</span></header>
      <div className="settings-grid">
        <section className="settings-card"><p className="eyebrow">भाषा और दिखावट</p><h2>इंटरफ़ेस की पसंद</h2>
          <div className="setting-row"><div><strong>इंटरफ़ेस की भाषा</strong><small>हिंदी मुख्य भाषा है, लेकिन कुछ स्क्रीन अभी अंग्रेज़ी में हैं। पूरा अनुवाद होने तक भाषा बदलने का विकल्प नहीं दिया गया है।</small></div><span className="setting-value">हिंदी · मुख्य</span></div>
          <label className="setting-row setting-control-row"><span><strong>बोर्ड के निर्देशांक</strong><small>बोर्ड पर पंक्ति और खाने के अक्षर दिखाएँ या छिपाएँ।</small></span><input type="checkbox" aria-label="बोर्ड के निर्देशांक दिखाएँ" checked={preferences.coordinates} onChange={(event) => savePreference({ coordinates: event.target.checked })} /></label>
          <label className="setting-row setting-control-row"><span><strong>बोर्ड की दिशा</strong><small>नया बोर्ड खुलने पर कौन-सा रंग नीचे होगा। अभ्यास में दिशा फिर भी पलट सकते हैं।</small></span><select aria-label="बोर्ड की शुरुआती दिशा" value={preferences.boardOrientation} onChange={(event) => savePreference({ boardOrientation: event.target.value as AppPreferences['boardOrientation'] })}><option value="w">सफ़ेद नीचे</option><option value="b">काला नीचे</option></select></label>
          <label className="setting-row setting-control-row"><span><strong>स्क्रीन के चलने वाले प्रभाव</strong><small>सिस्टम की पसंद मानें या स्क्रीन पर चलने वाले प्रभाव कम/ज़्यादा करें।</small></span><select aria-label="गति प्रभाव की पसंद" value={preferences.reducedMotion} onChange={(event) => savePreference({ reducedMotion: event.target.value as AppPreferences['reducedMotion'] })}><option value="system">सिस्टम के अनुसार</option><option value="reduce">गति कम रखें</option><option value="full">सभी प्रभाव चलाएँ</option></select></label>
          <label className="setting-row setting-control-row"><span><strong>अगले अभ्यास का समय</strong><small>यह समय नए बोर्ड या नए FEN पर लागू होगा। चालू खेल नहीं बदलेगा।</small></span><select aria-label="अगले अभ्यास का समय नियंत्रण" value={preferences.timeControlPresetId} onChange={(event) => savePreference({ timeControlPresetId: event.target.value as AppPreferences['timeControlPresetId'] })}>{TIME_CONTROL_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label}</option>)}</select></label>
          <div className="setting-row"><div><strong>चाल की लिखावट और ध्वनि</strong><small>मानक SAN/PGN लिखावट जारी है। इस संस्करण में आवाज़ के संकेत और अतिरिक्त मोहरों के रूप नहीं हैं।</small></div><span className="setting-value">SAN · ध्वनि बंद</span></div>
          {preferenceMessage && <p className="settings-message" role="status" aria-live="polite">{preferenceMessage}</p>}
        </section>
        <section className="settings-card"><p className="eyebrow">ऑफ़लाइन सुविधा</p><h2>इंटरनेट के बिना उपलब्धता</h2>
          <div className="setting-row"><div><strong>ऐप</strong><small>{serviceWorker}</small></div><span className={`status-dot ${serviceWorker.includes('तैयार') ? 'status-good' : 'status-warn'}`} /></div>
          <div className="setting-row"><div><strong>ओपनिंग सूची</strong><small>ऐप के साथ आती है; पहली बार सफलतापूर्वक खुलने पर सेव होती है।</small></div><span className="setting-value">डिवाइस पर</span></div>
          <div className="setting-row"><div><strong>खेल और प्रगति</strong><small>केवल इसी डिवाइस के ब्राउज़र में सहेजे जाते हैं।</small></div><span className="setting-value">खाते की ज़रूरत नहीं</span></div>
        </section>
        <section className="settings-card license-card"><p className="eyebrow">लाइसेंस और इंजन</p><h2>सॉफ़्टवेयर लाइसेंस सूचना</h2>
          <ul className="license-list">
            <li><span className="license-mark">✓</span><div><strong>chess.js 1.4.0</strong><small>BSD-2-Clause · वैध चालें और चाल की लिखावट</small></div></li>
            <li><span className="license-mark">✓</span><div><strong>Lichess ओपनिंग नाम</strong><small>CC0-1.0 · संस्करण { '5a13018164f6' }</small></div></li>
            <li className="license-pending"><span className="license-mark">!</span><div><strong>{STOCKFISH_LICENSING_GATE.engine}</strong><small>GPL-3.0-or-later की लिखित मंज़ूरी बाकी · शामिल नहीं · इंजन सुविधाएँ बंद</small></div></li>
          </ul>
          <p className="small-note">कोई दूसरा या छिपा हुआ इंजन लोड नहीं होता।</p>
          <p className="small-note"><a className="button-link" href="/THIRD_PARTY_NOTICES.txt">अन्य सॉफ़्टवेयर की लाइसेंस सूचना</a> · <a className="button-link" href="/sbom.cdx.json">CycloneDX सॉफ़्टवेयर सूची</a></p>
        </section>
        <section className="settings-card privacy-card"><p className="eyebrow">अपना डेटा</p><h2>बैकअप लें, बहाल करें या मिटाएँ</h2>
          <p>खेलों, घड़ियों, सीखने की प्रगति, विश्लेषण, ठीक की जा सकने वाली फ़ाइलों और ऐप की पसंद का JSON बैकअप डाउनलोड करें। बैकअप एन्क्रिप्टेड नहीं है; ब्राउज़र डेटा मिटा सकता है और इसकी कोई ऑनलाइन कॉपी नहीं रहती।</p>
          <div className="backup-actions"><button className="button-secondary" type="button" onClick={() => void exportAllData()} disabled={busy}>{busy ? 'काम जारी है…' : 'डिवाइस का पूरा डेटा डाउनलोड करें'}</button><label className="backup-file-control"><span className="button-secondary">बैकअप फ़ाइल चुनें…</span><input type="file" accept="application/json,.json" aria-label="बहाल करने के लिए स्थानीय बैकअप चुनें" onChange={(event) => void importAllData(event)} disabled={busy} /></label></div>
          <p className="small-note">बहाल करने से पहले पूरी फ़ाइल जाँची जाती है। डेटा एक साथ जोड़ा जाता है; एक जैसी ID वाले रिकॉर्ड नहीं बदले जाते और बैकअप की पसंद लागू होती है। अधिकतम फ़ाइल आकार: 25 MB।</p>
          <button className="button-danger" type="button" onClick={() => void eraseAll()} disabled={busy}>{busy ? 'काम जारी है…' : 'डिवाइस के सभी खेल और प्रगति मिटाएँ'}</button>
          {message && <p className="settings-message" role="status" aria-live="polite">{message}</p>}
        </section>
      </div>
      <p className="settings-footnote">Chess Game Master V1 · मानक शतरंज · रेटिंग, सार्वजनिक रैंकिंग और लाइव मानवीय मुकाबला नहीं</p>
    </section>
  );
}
