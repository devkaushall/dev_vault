import { describe, expect, it } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { StoreProvider } from '../StoreContext';
import { LocalChessStore } from '../../storage/LocalChessStore';
import { ReviewScreen } from './ReviewScreen';
import { applyMove, createGame } from '../../domain/chess/session';
import { analyzeReviewRecord } from '../../knowledge/reviewAnalysis';
import { deriveLearningInsights } from '../../knowledge/learningInsights';

let counter = 0;
function makeStore() {
  return new LocalChessStore(indexedDB, `review-screen-test-${++counter}`);
}

function historyFingerprint(record: ReturnType<typeof createGame>): string {
  const canonical = `${record.initialPosition.fen}|${record.moveHistory.map((move) => move.uci).join(' ')}`;
  let hash = 0x811c9dc5;
  for (let index = 0; index < canonical.length; index += 1) {
    hash ^= canonical.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return `history_${(hash >>> 0).toString(36).padStart(7, '0')}`;
}

describe('PGN review screen', () => { 
  it('creates a separate retry branch from the selected ply and preserves the reviewed line', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen /></StoreProvider>);
    const payload = '[Event "Retry test"]\n[White "Learner"]\n[Black "Archive"]\n[Result "*"]\n\n1. e4 e5 *';
    fireEvent.change(screen.getByLabelText('PGN text'), { target: { value: payload } });
    await user.click(screen.getByRole('button', { name: 'Validate PGN' }));
    await user.click(screen.getByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByRole('heading', { name: 'Replay & reflect' })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'चाल 1 पर जाएँ, e4' }));
    await user.click(screen.getByRole('button', { name: 'इस स्थिति पर अभ्यास करें' }));
    expect(await screen.findByRole('heading', { name: 'इस स्थिति पर अभ्यास' })).toBeInTheDocument();
    await user.click(screen.getByRole('gridcell', { name: 'e7 पर काले प्यादा' }));
    await user.click(screen.getByRole('gridcell', { name: 'खाली चौखाना e5, वैध गंतव्य' }));

    await waitFor(async () => expect(await store.listGames()).toHaveLength(2));
    const games = await store.listGames();
    const reviewed = games.find((game) => game.mode === 'Review');
    const retry = games.find((game) => game.mode === 'Practice');
    expect(reviewed?.moveHistory.map((move) => move.uci)).toEqual(['e2e4', 'e7e5']);
    expect(reviewed?.cursorPly).toBe(1);
    expect(retry?.initialPosition.fen).toBe('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1');
    expect(retry?.moveHistory.map((move) => move.uci)).toEqual(['e7e5']);
    expect(retry?.notes).toMatch(/original review history is unchanged/i);

    unmount();
    await store.close();
  });

  it('shows the self-review prompt before replay when opened from a saved game', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    let source = createGame({ id: 'original-review-source' });
    source = applyMove(source, 'e2e4').record;
    const originalHistory = source.moveHistory.map((move) => move.uci);
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen initialRecord={source} /></StoreProvider>);

    expect(await screen.findByLabelText(/what do you want to understand/i)).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Replay & reflect' })).not.toBeInTheDocument();
    await user.type(screen.getByLabelText(/what do you want to understand/i), 'Check the opening choice');
    await user.click(screen.getByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByRole('heading', { name: 'Replay & reflect' })).toBeInTheDocument();
    await waitFor(async () => expect(await store.listGames()).toHaveLength(1));
    expect(source.moveHistory.map((move) => move.uci)).toEqual(originalHistory);
    expect((await store.listGames())[0].id).not.toBe(source.id);

    unmount();
    await store.close();
  });

  it('shows evidence-based moments in Review and stores analysis separately without mutating the source history', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    let source = createGame({ id: 'phase7-review-source' });
    source = applyMove(source, 'e2e4').record;
    source = applyMove(source, 'e7e5').record;
    const original = structuredClone(source);
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen initialRecord={source} /></StoreProvider>);
    await user.click(await screen.findByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByRole('heading', { name: 'Evidence-based review' })).toBeInTheDocument();
    expect(await screen.findByText(/Analysis ready/, {}, { timeout: 20000 })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Key moments' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'What the evidence says' })).toBeInTheDocument();
    expect(source).toEqual(original);

    await waitFor(async () => expect((await store.listGames()).some((game) => game.mode === 'Review')).toBe(true));
    const reviewCopy = (await store.listGames()).find((game) => game.mode === 'Review');
    expect(reviewCopy?.moveHistory.map((move) => move.uci)).toEqual(['e2e4', 'e7e5']);
    const analyses = reviewCopy ? await store.listAnalysis(reviewCopy.id) : [];
    const persistedAnalysis = analyses.find((analysis) => analysis.payload.analysisKind === 'phase7-review');
    expect(persistedAnalysis?.payload).toMatchObject({ analysisKind: 'phase7-review', schemaVersion: 1, totalPlies: 2 });
    expect(Array.isArray(persistedAnalysis?.payload.evidence)).toBe(true);
    const persistedEvidence = persistedAnalysis?.payload.evidence as Array<{ status?: string; engine?: unknown }> | undefined;
    expect(persistedEvidence?.length).toBeGreaterThan(0);
    expect(persistedEvidence?.every((item) => ['confirmed', 'candidate', 'deferred'].includes(item.status ?? ''))).toBe(true);
    expect(persistedEvidence?.every((item) => item.engine === undefined)).toBe(true);
    expect(source).toEqual(original);

    unmount();
    await store.close();
  }, 30000);

  it('derives recurring study themes from distinct saved local review sidecars', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const initialFen = 'k3r3/8/8/8/8/8/4R3/4Q2K w - - 0 1';
    const priorRecords: ReturnType<typeof createGame>[] = [];
    const priorLearningSets: Parameters<typeof deriveLearningInsights>[0][number][] = [];
    for (const [index, reply] of ['e8e7', 'a8b8'].entries()) {
      let prior = createGame({ id: `prior-review-${index}`, initialFen });
      prior = applyMove(prior, 'e2f2', { committedAt: `2026-10-05T00:00:0${index + 1}.000Z` }).record;
      prior = applyMove(prior, reply, { committedAt: `2026-10-05T00:00:0${index + 3}.000Z` }).record;
      priorRecords.push(prior);
    }

    for (const [index, prior] of priorRecords.entries()) {
      const report = await analyzeReviewRecord(prior, { maxAnalyzedPositions: 8 });
      expect(report.classification.moves[0].categories.some((item) => item.category === 'candidate-tactical-mistake')).toBe(true);
      const fingerprint = historyFingerprint(prior);
      priorLearningSets.push({ gameKey: fingerprint, totalPlies: report.totalPlies, analyzedPositionCount: report.aggregationPlies.length, evidence: report.evidence });
      await store.saveGame(prior);
      await store.saveAnalysis({
        id: `phase7-review-v1:${fingerprint}`,
        gameId: prior.id,
        updatedAt: `2026-10-05T00:00:0${index + 1}.000Z`,
        payload: {
          analysisKind: 'phase7-review', schemaVersion: 1, historyFingerprint: fingerprint,
          totalPlies: report.totalPlies, analyzedPositionCount: report.aggregationPlies.length, evidence: report.evidence,
        },
      });
    }

    let current = createGame({ id: 'current-review-for-learning', initialFen });
    current = applyMove(current, 'e2f2', { committedAt: '2026-10-05T00:00:10.000Z' }).record;
    const currentReport = await analyzeReviewRecord(current, { maxAnalyzedPositions: 8 });
    const manualInsights = deriveLearningInsights([
      ...priorLearningSets,
      { gameKey: historyFingerprint(current), totalPlies: currentReport.totalPlies, analyzedPositionCount: currentReport.aggregationPlies.length, evidence: currentReport.evidence },
    ]);
    expect(manualInsights.insights.some((insight) => insight.patternId === 'candidate-tactical-vulnerability')).toBe(true);
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen initialRecord={current} /></StoreProvider>);
    await user.click(await screen.findByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByText(/Analysis ready/, {}, { timeout: 20000 })).toBeInTheDocument();
    expect(await screen.findByText('Candidate tactical vulnerability cues')).toBeInTheDocument();
    expect((await screen.findAllByText(/3 occurrences · 3 games/)).length).toBeGreaterThan(0);

    unmount();
    await store.close();
  }, 30000);

  it('loads a selected .pgn file into the validator and starts self-review only after validation', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen /></StoreProvider>);
    const payload = '[Event "Uploaded file"]\n[White "Learner"]\n[Black "Archive"]\n[Result "*"]\n\n1. e4 e5 *';
    const file = new File([payload], 'uploaded-game.pgn', { type: 'application/x-chess-pgn' });
    fireEvent.change(screen.getByLabelText('Choose .pgn file'), { target: { files: [file] } });

    expect(await screen.findByText('Selected file: uploaded-game.pgn')).toBeInTheDocument();
    expect(screen.getByLabelText('PGN text')).toHaveValue(payload);
    expect(screen.queryByRole('heading', { name: 'Uploaded file' })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Validate PGN' }));
    expect(await screen.findByRole('heading', { name: 'Uploaded file' })).toBeInTheDocument();
    expect(screen.getByText('Learner vs Archive · 2 half-moves · unfinished')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByRole('heading', { name: 'Replay & reflect' })).toBeInTheDocument();

    unmount();
    await store.close();
  });

  it('rejects oversized PGN files before reading or parsing them', async () => {
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen /></StoreProvider>);
    const file = new File(['x'.repeat(500_001)], 'oversized.pgn', { type: 'application/x-chess-pgn' });
    fireEvent.change(screen.getByLabelText('Choose .pgn file'), { target: { files: [file] } });

    expect(await screen.findByRole('alert')).toHaveTextContent('PGN file is too large (maximum 500 KB).');
    expect(screen.queryByRole('heading', { name: 'Game ready to review' })).not.toBeInTheDocument();

    unmount();
    await store.close();
  });

  it('reports a selected PGN file that cannot be read', async () => {
    const store = makeStore();
    const { unmount } = render(<StoreProvider store={store}><ReviewScreen /></StoreProvider>);
    const file = new File(['unreadable'], 'unreadable.pgn', { type: 'application/x-chess-pgn' });
    Object.defineProperty(file, 'text', { value: async () => { throw new Error('simulated file-read failure'); } });
    fireEvent.change(screen.getByLabelText('Choose .pgn file'), { target: { files: [file] } });

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not read the selected file.');

    unmount();
    await store.close();
  });

  it('validates PGN, renders imported header text safely, and starts a local self-review', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const { container, unmount } = render(<StoreProvider store={store}><ReviewScreen /></StoreProvider>);
    const payload = '[Event "<img src=x onerror=alert(1)>"]\n[White "Learner"]\n[Black "Archive"]\n[Result "*"]\n\n1. e4 e5 *';
    fireEvent.change(screen.getByLabelText('PGN text'), { target: { value: payload } });
    await user.click(screen.getByRole('button', { name: 'Validate PGN' }));

    expect(await screen.findByText('<img src=x onerror=alert(1)>')).toBeInTheDocument();
    expect(container.querySelector('img')).toBeNull();
    expect(screen.getByText(/marked unfinished/)).toBeInTheDocument();
    await user.type(screen.getByLabelText(/what do you want to understand/i), 'Look at king safety');
    await user.click(screen.getByRole('button', { name: 'Start self-review' }));
    expect(await screen.findByRole('heading', { name: 'Replay & reflect' })).toBeInTheDocument();
    await waitFor(async () => expect((await store.listGames()).length).toBeGreaterThan(0), { timeout: 10000 });

    unmount();
    await store.close();
  });
});
