import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SettingsScreen } from './SettingsScreen';
import { StoreProvider } from '../StoreContext';
import { readAppPreferences } from '../preferences';
import { createGame } from '../../domain/chess/session';
import { LocalChessStore } from '../../storage/LocalChessStore';

let storeNumber = 0;
function makeStore() {
  return new LocalChessStore(indexedDB, `settings-screen-${++storeNumber}`);
}
function renderSettings(store: LocalChessStore) {
  return render(<StoreProvider store={store}><SettingsScreen /></StoreProvider>);
}

beforeEach(() => localStorage.clear());
afterEach(() => vi.unstubAllGlobals());

describe('Settings screen', () => {
  it('persists board, orientation, reduced-motion, and next-game time-control preferences', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    renderSettings(store);
    expect(screen.getByRole('heading', { name: 'सेटिंग और गोपनीयता' })).toBeInTheDocument();

    await user.click(screen.getByRole('checkbox', { name: 'बोर्ड के निर्देशांक दिखाएँ' }));
    await user.selectOptions(screen.getByRole('combobox', { name: 'बोर्ड की शुरुआती दिशा' }), 'b');
    await user.selectOptions(screen.getByRole('combobox', { name: 'गति प्रभाव की पसंद' }), 'reduce');
    await user.selectOptions(screen.getByRole('combobox', { name: 'अगले अभ्यास का समय नियंत्रण' }), '180+2');

    expect(readAppPreferences()).toEqual({ coordinates: false, boardOrientation: 'b', reducedMotion: 'reduce', timeControlPresetId: '180+2' });
    expect(document.documentElement.dataset.motion).toBe('reduce');
    expect(screen.getByRole('status')).toHaveTextContent('पसंद इस ब्राउज़र में सहेजी गई।');
    await store.close();
  });

  it('downloads one complete local backup including preferences', async () => {
    const user = userEvent.setup();
    const store = makeStore();
    const game = createGame({ id: 'settings-export-game', now: '2026-10-05T00:00:00.000Z' });
    await store.saveGame(game);
    const preferences = { coordinates: false, boardOrientation: 'b' as const, reducedMotion: 'reduce' as const, timeControlPresetId: '180+2' as const };
    localStorage.setItem('chess-game-master.preferences.v1', JSON.stringify(preferences));
    let downloaded: Blob | undefined;
    const createObjectURL = vi.fn((blob: Blob) => { downloaded = blob; return 'blob:local-backup'; });
    const revokeObjectURL = vi.fn();
    vi.stubGlobal('URL', { createObjectURL, revokeObjectURL });
    vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined);
    renderSettings(store);

    await user.click(screen.getByRole('button', { name: 'डिवाइस का पूरा डेटा डाउनलोड करें' }));
    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent(/स्थानीय बैकअप डाउनलोड हो गया/));
    expect(createObjectURL).toHaveBeenCalledOnce();
    expect(downloaded).toBeInstanceOf(Blob);
    const packageData = JSON.parse(await downloaded!.text()) as { games: Array<{ id: string }>; appPreferences: unknown };
    expect(packageData.games).toMatchObject([{ id: game.id }]);
    expect(packageData.appPreferences).toEqual(preferences);
    await new Promise<void>((resolve) => window.setTimeout(resolve, 1_050));
    expect(revokeObjectURL).toHaveBeenCalledWith('blob:local-backup');
    await store.close();
  });

  it('restores a validated JSON backup from Settings and applies its preferences', async () => {
    const store = makeStore();
    const game = createGame({ id: 'settings-restore-game', now: '2026-10-05T00:00:00.000Z' });
    const backup = {
      format: 'chess-game-master-local-backup',
      schemaVersion: 1,
      exportedAt: '2026-10-05T00:00:00.000Z',
      games: [game],
      progress: [],
      analysis: [],
      recovery: [],
      appPreferences: { coordinates: false, boardOrientation: 'b', reducedMotion: 'reduce', timeControlPresetId: '300+0' },
    };
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    renderSettings(store);
    const input = screen.getByLabelText('बहाल करने के लिए स्थानीय बैकअप चुनें') as HTMLInputElement;
    const file = new File([JSON.stringify(backup)], 'device-backup.json', { type: 'application/json' });
    fireEvent.change(input, { target: { files: [file] } });

    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent('बैकअप बहाल हुआ: 1 नए रिकॉर्ड जोड़े, 0 पहले से मौजूद रिकॉर्ड छोड़े गए।'));
    expect(await store.getGame(game.id)).toEqual(game);
    expect(readAppPreferences()).toEqual(backup.appPreferences);
    expect(document.documentElement.dataset.motion).toBe('reduce');
    await store.close();
  });
});
