# Chess Game Master — Project Handover

**Handover prepared:** 2026-10-06 (Asia/Calcutta)  
**Product/release status:** **NOT READY — do not publish as the finished V1.**  
**Project status source of truth:** `IMPLEMENTATION_STATUS.md` (evidence/status) and `IMPLEMENTATION_MAP.md` (remaining work and the agreed parts).

This file is written so a new agent can continue from this source snapshot without first reconstructing the previous conversation. The project is an existing React/TypeScript chess app; preserve its working behavior and build on it rather than replacing it.

## 1. Short summary

Chess Game Master is a local-first, browser-based chess learning and review app. It uses React, TypeScript, Vite, `chess.js`, IndexedDB, a service worker and bundled opening data. It has no app server, account system, or cloud sync. Games and progress stay in the current browser unless the user exports a JSON backup (the backup is **not encrypted**).

The most recent verified app gates were:

- `npm test -- --reporter=dot`: **37 test files / 300 tests passed**.
- `npm run typecheck`: **PASS**.
- `npm run build`: **PASS** (Vite 8.3.2).
- `npm audit --audit-level=moderate`: **0 vulnerabilities**.
- `npm audit --omit=dev --audit-level=moderate`: **0 vulnerabilities**.
- `node --check public/sw.js`: **PASS**.
- Production-preview URL smoke checks: `/`, `/sw.js`, `/manifest.webmanifest`, `/THIRD_PARTY_NOTICES.txt`, `/sbom.cdx.json`, and `/_headers` returned HTTP 200. Serving `/_headers` as a file is **not** proof that a real host enforces those response headers.
- Build main JS was 395.43 kB (107.54 kB gzip); CSS 57.68 kB (13.12 kB gzip). Source maps were disabled and none were found in `dist`.

The app is still not release-ready. The largest correctness gap is full FIDE dead-position and timeout adjudication. A separate research prototype is **not** integrated. Stockfish is blocked by the project’s licensing rule. Other product, accessibility, deployment and Android/Play Store work remains.

## 2. Agreed work order

The user asked for **three development parts followed by Part 4 for real-world acceptance**. Treat these as Parts, not new numbered development phases. A part must pass its exit checks before calling it complete. Do not carry a known unresolved blocker into the next part as if it were fixed.

### Part 1 — Correctness, safety and reliability (currently IN PROGRESS)

Focus first on behavior that can give the wrong chess result, lose data, break save/resume, mishandle clocks/imports, or fail offline.

Open work includes:

1. Full FIDE dead-position (Article 5.2.2) and timeout mating-possibility (Article 6.9) handling. Current code intentionally recognizes only some cases; other timeouts become `adjudication-pending` instead of receiving a guessed result.
2. Storage write/quota failure behavior and multi-tab/schema migration races.
3. More boundary/fuzz/property tests for FEN, PGN and hostile storage records.
4. Recheck clock/terminal-result precedence, result distinctions, recovery, backup/restore and the v4 offline/update path while fixing only demonstrated defects.

**Part 1 exit check:** targeted rules, clock, storage, import and PWA tests; full suite, typecheck, production build, both audits; browser tests for critical local workflows; no unresolved known data-loss or false-result defect. Part 1 is **not passed** while the FIDE gap remains.

### Part 2 — Complete required user-facing features

Close the original product requirements, including full Hindi-first localization (Settings is only partly localized; most other screens remain English), learning levels/progression, broader lesson/puzzle/opening content, and the remaining Review workflow. Review currently has a bounded evidence-based explanation view, but not selectable simple/detailed/advanced depth; engine analysis, annotations and preserved PGN comments/variations are also absent or limited as documented in the status matrix.

**Engine gate:** no written GPL-3.0-or-later distribution approval or owner-approved Stockfish 19 source/build, NNUE assets and distribution plan were present in the workspace. Do not fetch, bundle, enable or replace Stockfish until these are supplied and approved. Do not add a fake engine, hidden fallback, LLM analysis or competitive-human assistance. Challenge/Coached Practice must remain unavailable while blocked. A generic UCI adapter or a test fake is not a real engine.

**Part 2 exit check:** map every original requirement to implementation and tests; recheck local-first privacy, original Review immutability, fair-play separation and uncertainty wording; rerun all quality gates. Keep missing external approvals explicitly **BLOCKED**.

### Part 3 — Release preparation (web and later Play Store)

Prepare a reproducible production web build and a later Android distribution route, without publishing early. Verify the actual host’s HTTPS/security headers, icon provenance, SBOM/notices, service-worker behavior, manual WCAG/screen-reader use, real browser/device coverage, performance on named hardware, offline/cache failure and storage errors.

The user additionally wants a Google Play release after the app is complete. The current project is **web/PWA only**: there is no Android project, APK/AAB, permanent app ID, signing key or Play Console listing. After Parts 1–2 pass, choose a route (Trusted Web Activity or Capacitor), confirm the permanent app ID with the owner, make/sign the Android App Bundle, test on real Android devices, and complete Play Console/privacy/data-safety/store-listing work. Do not commit passwords or signing secrets to the ZIP/repository.

**Part 3 exit check:** production artifacts/build provenance, deployed response headers, security/legal/accessibility/device checks and Android packaging are verified. A successful build alone is not release approval.

### Part 4 — Final practical-use test

After Parts 1–3 pass, the owner/user plays through realistic chess, learning, review and backup flows on the target desktop and Android devices. Test online/offline use after initial caching, save/resume, game update, backup/restore/delete, accessibility controls and the signed Android package. Fix any failure in its earlier part and rerun that part’s exit checks. Only after this acceptance may status move from **NOT READY**.

## 3. What is already implemented and verified

### Chess and Practice

- Legal move generation/validation is delegated to `chess.js`; the UI derives legal destinations rather than implementing chess legality itself.
- Canonical move history, FEN checkpoints, SAN/UCI, repetition identity, PGN/FEN adapters, promotion, castling and en-passant handling are covered by tests.
- Practice supports legal click/tap/keyboard moves, move navigation, takeback/redo/branch safeguards, FEN load/copy and PGN export.
- Local Practice supports Fischer clocks, explicit start/pause/resume, persistence of paused clock state, lifecycle pause/save, and a confirmed abort that stores `status: aborted` **without inventing a chess result**.
- An untouched untimed standard scratch board does not create a phantom History row; the first actual move makes it durable. Timed/custom-FEN/existing records remain durable.
- Threefold/fifty-move claims, fivefold/75-move automatic draws, mate precedence, and conservative timeout behavior have tests. **Full dead-position/timeout adjudication is still missing.**

### Local storage and privacy

- IndexedDB schema v2 validates records, migrates v1 paths, quarantines corrupt rows and keeps valid records available.
- Full local JSON export/import covers games, clocks, progress, analysis, recovery records and app preferences. Restore validates and merges without overwriting existing matching IDs. Clear-all and recovery controls exist.
- User data is browser-local. JSON backup is explicitly unencrypted. There is no account/cloud data copy.
- Known unverified reliability areas: quota/write failure injection, multi-tab migration/update races, and broad hostile-input fuzzing.

### Review/intelligence/learning

- Review copies source games rather than editing the original line. Local Phase 7 evidence is stored in a separate analysis sidecar; explanations are evidence-bound and candidate/deferred wording is preserved.
- Repeated study insights use saved local review evidence and remain candidate themes, not ratings, permanent player traits or intent claims.
- PGN file import tests now cover `.pgn` selection, loading into the text field, explicit validation/self-review, the 500 KB limit and read errors. PGN comments/variations/NAGs are not preserved, with warnings/limitations as documented.
- Learning has five rule-focused lessons; puzzle set is small (three mate-in-one positions); opening recognition/training and curated knowledge remain selective.

### PWA and browser checks

- `public/sw.js` uses the v4 shell cache, caches the local shell/current hashed assets/opening data and requires explicit update activation.
- Chromium simulated a v3-cache predecessor (a test-only copy of the production worker with the cache label reverted) upgrading to the real `/sw.js` v4 worker. v3 cache was removed and offline Home reload worked. This was **not** an upgrade from a historic user-installed v3 binary/profile.
- In a separate production-preview test, an active timed Practice game resumed offline and `e7-e5` was accepted and saved. A separate browser workflow exercised Settings preferences, a timed move, a result-free abort, a second paused timed game and a real JSON backup containing two games.
- Responsive Chromium checks passed for recorded states at widths 320, 375, 390, 414, 768, 1024 and 1440 px without document/body horizontal overflow. A populated History table was separately checked as internally scrollable at 320 px.
- Axe scans reported zero WCAG-tagged violations on recorded states, but `color-contrast` remained incomplete for manual review. No manual WCAG 2.2 AA/screen-reader or physical-device audit has been done.

### Settings/localization

- Settings preferences persist board coordinates, orientation, reduced-motion choice and next Practice time control.
- Settings labels/messages/accessibility names are partly Hindi; the interface as a whole is not fully localized and most screens remain English. There is no language selector.

## 4. Important decisions and guardrails

1. Preserve existing working behavior; do not rebuild the app or remove features to make the status table smaller.
2. **Stockfish stays BLOCKED** until written distribution approval and approved engine files/NNUE/notices exist. No replacement/fake engine or hidden fallback.
3. No LLM analysis, no human competitive assistance/multiplayer, no live engine help in human competition.
4. Do not invent a game result, evaluation, best move, player intent or rating. When adjudication cannot be proven, retain an explicit pending state rather than guessing.
5. Keep the app local-first and preserve the original Review move history. Treat exported JSON backups as unencrypted.
6. FEN is only a position snapshot; it does not restore earlier repetition/game history. The UI already communicates this.
7. Keep evidence status distinctions: confirmed facts versus candidate/deferred ideas. No engine result is available from the current app.
8. Do not publish or change release status to READY until the actual acceptance gates pass.

## 5. FIDE adjudicator research lead — NOT integrated

During Part 1 research, a separate Rust crate, **CHA-Solver 3.0.0**, was checked as a possible Article 6.9/5.2.2 rules helper: [repository](https://github.com/miguel-ambrona/chasolver), [crates.io](https://crates.io/crates/chasolver). It is an MIT-licensed helpmate/unwinnability solver, not an engine that plays or evaluates chess. Its declared API returns `Winnable`, `Unwinnable` or `None` when its node limit prevents a conclusion.

- The upstream native suite passed: 8 unit tests, 2 integration tests, 1 doc test. The two integration datasets took about 20 minutes in the debug test run; performance on low-end/mobile browsers still needs investigation.
- A temporary Rust→WASM proof of concept compiled to 984 KB (about 96 KB gzip) and matched the upstream timeout example: Black was reported unwinnable and a White helpmate line was returned.
- **Nothing from this prototype is integrated or included in this ZIP.** The temporary source/build was in an excluded cache folder and is intentionally not represented as app code.
- Before adoption: audit the crate and all transitive licenses; its `Board` does not carry half-move/repetition history; verify the handling of FIDE automatic 75-move/fivefold draws; replay every returned helpmate through app `chess.js` and the current repetition history; keep unknown/timeout as pending; run it in a Worker and bound runtime; update CSP, precache, SBOM and license notices. The upstream project documents that some searches return unknown and does not claim a theoretical proof for every possible legal position. Treat this as a candidate, not a completed FIDE solution.
- This rules helper is separate from Stockfish and must **not** be used to bypass the Stockfish licensing gate or provide engine assistance.

## 6. Project structure and key files

```text
.
├── Chess_Game_Master_Product_Technical_Spec_v1.0_HI.md  # original product acceptance contract
├── Chess_Game_Master_Research_HI.md                      # product/rules research
├── Chess_Game_Master_Chess_Atlas_HI.md                   # chess knowledge source
├── IMPLEMENTATION_STATUS.md                              # evidence matrix, final NOT READY decision
├── IMPLEMENTATION_MAP.md                                 # agreed Parts 1–4 and open backlog
├── HANDOVER.md                                            # this transfer guide
├── SBOM.cdx.json                                          # CycloneDX 1.5 dependency inventory
├── index.html                                             # shell, Hindi document language, CSP meta
├── package.json / package-lock.json                       # scripts and pinned JS dependency graph
├── vite.config.ts / vitest.config.ts / tsconfig.json      # build/test/type configuration
├── public/
│   ├── _headers                                           # static-host response-header rules (not applied by Vite preview)
│   ├── sw.js                                              # v4 service worker
│   ├── manifest.webmanifest, icon*.png, icon.svg          # PWA metadata/icons; icon provenance still needs owner confirmation
│   ├── THIRD_PARTY_NOTICES.txt, sbom.cdx.json              # notices and served SBOM
│   └── data/openings/                                     # Lichess CC0 opening index, manifest and source README
└── src/
    ├── app/                                               # routes, mode policy, preferences, screens and tests
    ├── components/                                        # chess workspace/board and evidence-based Review panel
    ├── domain/chess/                                      # canonical game transitions, rules adapter, PGN/FEN and tests
    ├── domain/clock/                                      # Fischer clock and tests
    ├── engine/                                            # fail-closed Stockfish gate and generic UCI protocol adapter
    ├── knowledge/                                         # opening/strategy/tactic/attack/defence/endgame evidence
    ├── learning/                                          # lessons/puzzles and local progress logic
    ├── pwa/                                               # worker lifecycle tests
    ├── storage/LocalChessStore.ts                         # IndexedDB, migration, recovery, backup/restore
    ├── styles/global.css                                  # responsive application styles
    └── testing/setup.ts                                   # Vitest setup
```

### Quick file map

- `src/domain/chess/session.ts`: game lifecycle, legal move commits, draw/abort/resignation/timeout results.
- `src/domain/chess/position.ts`: legal position reconstruction, FEN/repetition keys, draw state, narrow recognized-dead-position adapter.
- `src/domain/chess/pgn.ts`: bounded PGN/FEN import/export.
- `src/domain/clock/ChessClock.ts`: monotonic Fischer clock and saved paused snapshots.
- `src/storage/LocalChessStore.ts`: local database, schema checks, quarantine/recovery, JSON backup/restore.
- `src/components/ChessWorkspace.tsx`: Practice/Review workspace, clock and lifecycle persistence, move/FEN/PGN controls.
- `src/app/modePolicy.ts` and `src/engine/engineGate.ts`: mandatory fail-closed mode/engine gates.
- `src/knowledge/reviewAnalysis.ts` and `src/components/ReviewIntelligencePanel.tsx`: local evidence pipeline and bounded Review UI.
- `src/pwa/serviceWorker.test.ts`: cache naming, update and bypass/offline policy tests.
- `public/data/openings/manifest.json` plus `README.md`: opening data source and pinned Lichess commit `5a13018164f6bd88f48b3dc31a8e2a39f31a060a`, CC0-1.0.

## 7. How to resume work

1. Extract the ZIP into a clean working directory. This is a **source snapshot**; there is no `.git` history/branch metadata and no `node_modules` or `dist` folder in the package.
2. Use Node 20.20.2/npm 10.8.2 or a compatible modern Node release (Vite 8 requires a recent Node 20/22 release).
3. Run:

```bash
npm ci
npm test -- --reporter=dot
npm run typecheck
npm run build
npm audit --audit-level=moderate
npm audit --omit=dev --audit-level=moderate
node --check public/sw.js
```

4. Check the implementation/status files before editing. Keep Part 1 **IN PROGRESS** and start with FIDE result correctness plus data-failure/race cases. Any new dependency requires a license review and synchronized root/public SBOM plus notice updates.
5. For browser work after the product code changes, build and run `npm run preview -- --host 0.0.0.0 --port 4173`; test through Chromium/real browsers. Vite preview does not enforce `public/_headers` as response headers.
6. Do not install/use the unintegrated CHA-Solver proof of concept from this document; there is no product package for it. Re-evaluate from its pinned upstream version and reproduce the audit if adopting it.
7. Do not create an Android app ID, signing key, publish a site, upload to Play Store or change release status without owner approval and the relevant Part exit gates.

## 8. What this ZIP contains

The archive contains the complete current source snapshot, public images/opening data/PWA assets, original specification/research/atlas documents, package lock/configuration, SBOM/notices and this handover. It intentionally excludes generated/downloaded folders such as `node_modules`, `dist`, browser profiles, `.cache`, Rust Cargo caches/build products, and the unintegrated CHA-Solver prototype. This keeps the handoff reproducible and prevents a research prototype from being mistaken for product code.
