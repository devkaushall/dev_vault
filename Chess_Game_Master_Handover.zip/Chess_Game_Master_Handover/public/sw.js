const CACHE_PREFIX = 'chess-game-master-';
const CACHE_NAME = `${CACHE_PREFIX}v4-shell`;
const CORE_URLS = [
  '/',
  '/manifest.webmanifest',
  '/icon.svg',
  '/icon-192.png',
  '/icon-512.png',
  '/data/openings/manifest.json',
  '/data/openings/a.tsv',
  '/data/openings/b.tsv',
  '/data/openings/c.tsv',
  '/data/openings/d.tsv',
  '/data/openings/e.tsv',
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(CORE_URLS);
    const documentResponse = await cache.match('/');
    if (documentResponse) {
      const html = await documentResponse.text();
      const assetUrls = [...html.matchAll(/(?:src|href)="([^"]+)"/g)]
        .map((match) => match[1])
        .filter((url) => url.startsWith('/assets/'));
      await Promise.all(assetUrls.map(async (url) => {
        try { await cache.add(url); } catch { /* a failed optional chunk is retried at runtime */ }
      }));
    }
    // Do not interrupt an active game automatically. The app offers an explicit
    // update action; otherwise this worker waits until the current clients close.
  })());
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'ACTIVATE_UPDATE') {
    event.waitUntil(self.skipWaiting());
  }
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const fresh = await fetch(request);
        if (fresh.ok) await cache.put('/', fresh.clone());
        return fresh;
      } catch {
        return (await cache.match('/')) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    // Same-origin static responses are safe to reuse regardless of Vary: Origin.
    // Cache seeding runs from the worker without a page Origin header, whereas
    // module requests commonly include one; strict Vary matching breaks offline.
    const cached = await cache.match(request, { ignoreVary: true });
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok) await cache.put(request, response.clone());
      return response;
    } catch {
      return Response.error();
    }
  })());
});
