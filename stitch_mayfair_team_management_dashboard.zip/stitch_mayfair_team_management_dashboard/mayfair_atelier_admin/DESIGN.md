---
name: Mayfair Atelier Admin
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#444748'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#725b2f'
  on-secondary: '#ffffff'
  secondary-container: '#fbdba4'
  on-secondary-container: '#775f33'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1c16'
  on-tertiary-container: '#87847c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#fedea7'
  secondary-fixed-dim: '#e1c28d'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#58431a'
  tertiary-fixed: '#e7e2d9'
  tertiary-fixed-dim: '#cac6be'
  on-tertiary-fixed: '#1d1c16'
  on-tertiary-fixed-variant: '#494740'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  headline-xl:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Source Serif 4
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  tabular-nums:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style
The design system delivers an architectural, grounded, and intensely functional internal workspace tailored for premier property managers, deal brokers, and development partners. The emotional tone is authoritative, understated, and unhurried—evoking the tactile permanence of archival property ledgers, stone masonry, and high-end editorial portfolios rather than transient software chrome.

Rooted in an elevated architectural minimalism, the interface merges the utility of a dense administrative dashboard with the bespoke restraint of an estate atelier. Visual distraction is systematically eliminated: there are no decorative gradients, artificial blurs, or gratuitous elevation layers. Distinction is achieved through exact typographic tension between an authoritative editorial serif and a crisp utilitarian sans-serif, anchored by hairline boundaries, measured proportions, and an archival warm-neutral palette. Every element prioritizes operational clarity, transactional confidence, and long-session visual comfort.

## Colors
The palette relies on a tonal structure of warm minerals, archival paper, and deep charcoal ink. 

- **Background (`#F9F7F2`)**: Canvas base providing reduced glare during sustained analytical use. Used for page viewports and secondary workspace wells.
- **Surface / Card (`#FFFFFF`)**: Pure white reserved for focal work panels, active ledger cards, modal sheets, and data tables.
- **Secondary Neutral (`#F2EDE4`)**: A grounded stone tint used for table headers, active navigation rails, segmented control wells, and tag backgrounds.
- **Borders (`#E6E2D9`)**: Precise 1px hairline delimiters that define spatial rhythm without visually segmenting the interface into heavy boxes.
- **Primary / Dark (`#1A1A1A`)**: Deep charcoal replacing pure pitch black to preserve legibility without harsh ocular fatigue. Applied to primary metrics, body text, and active icon states.
- **Muted Gold Accent (`#725B2F`)**: Selective burnished brass accent. Used exclusively for committed actions, verified escrow/deed badges, key navigation indicators, and primary callouts. It must never be applied decoratively over broad surface areas.
- **Functional Semantics**: System alerts use desaturated variants: `#3F5E4D` (cleared/active title), `#8A3B2C` (legal hold/delinquent), and `#8A6D2C` (pending review), paired with `#F2EDE4` backgrounds.

## Typography
Typographic discipline is non-negotiable: all text across titles, subheadings, labels, inputs, and buttons must be set strictly in sentence case. Title case and all-caps styling are prohibited, except for single-word system tags or standardized unit indicators.

- **Source Serif 4**: Used for property titles, portfolio values, executive summaries, and sheet headings. It anchors the workspace with classical permanence. Weights are limited to 400 (Regular) and 600 (Semibold).
- **Inter**: Governs all operational mechanics: data tables, dense ledger listings, filter panels, metadata attributes, and system controls. Numerical property values, square footage, commissions, and transaction timestamps must utilize tabular figures (`font-variant-numeric: tabular-nums`) to ensure alignment across dense administrative columns.

## Layout & Spacing
The layout follows a modular administrative grid designed for high-density document workflows and portfolio management:

- **Desktop (1280px+)**: A persistent 240px utility sidebar with an optional collapsible 320px inspection drawer. The primary canvas uses a 12-column grid with a `1.5rem` (`24px`) gutter and a fixed outer margin of `2rem` (`32px`).
- **Tablet (768px - 1279px)**: Sidebar shifts to a slim icon-and-label 72px rail. Grid collapses to 8 columns with `1rem` (`16px`) gutters and `1.5rem` (`24px`) margins.
- **Mobile (< 768px)**: Single column with edge-to-edge modular cards, utilizing `1rem` (`16px`) gutters and margins. Utility drawers convert to bottom-up sliding sheets.

The vertical rhythm adheres to strict multiples of `0.25rem` (`4px`). Interior form control layouts avoid gratuitous whitespace; high information density is preserved through balanced cell padding (`0.5rem` by `0.75rem`), maintaining immediate access to critical portfolio figures.

## Elevation & Depth
Depth is created through low-contrast outlines, spatial borders, and tonal layering rather than drop shadows.

- **Hairline Outlines**: Interfaces are bounded by crisp `1px solid #E6E2D9` edges. When cards overlap the `#F9F7F2` background, the boundary is articulated strictly through color value changes (`#FFFFFF` against `#F9F7F2`) and borders.
- **Zero Heavy Shadows**: Diffuse blur effects, ambient glows, and heavy drop shadows are forbidden.
- **Floating Overlays**: For detached dropdowns, date pickers, and modal dossiers, depth is signaled using a subtle architectural offset: a hairline border (`#E6E2D9`) accompanied by a minimal, crisp contact shadow: `box-shadow: 0 1px 3px rgba(26, 26, 26, 0.04), 0 4px 12px rgba(26, 26, 26, 0.03)`.
- **Tonal Inset**: Search wells, embedded table headers, and disabled panel sections sit receded into the canvas via `#F2EDE4`.

## Shapes
The structural geometry is restrained and architectural. Component rounding follows level `1` (Soft):

- **Inputs, Buttons, and Micro-Controls**: Bounded with a precise `2px` to `4px` corner radius (`0.125rem` to `0.25rem`). This provides tactile delineation without looking round or casual.
- **Cards, Modals, and Flyout Panels**: Bound to a maximum corner radius of `4px` (`0.25rem`). 
- **Pills and Rounded Tags**: Rounded pill structures (e.g., 9999px) are excluded from this system. Status badges, stage chips, and taxonomy tags use rectilinear or subtly clipped `2px` corners, reinforcing the feel of precision ledger tabs.

## Components

### Buttons & Trigger Controls
- **Primary Action**: Background `#1A1A1A`, text `#FFFFFF`, border `1px solid #1A1A1A`, radius `2px`. Hover state shifts to `#725B2F` with border `#725B2F`.
- **Secondary / Standard**: Background `#FFFFFF`, text `#1A1A1A`, border `1px solid #E6E2D9`, radius `2px`. Hover shifts background to `#F2EDE4` and border to `#D5CFC3`.
- **Accent Action**: Background `#725B2F`, text `#FFFFFF`, border `1px solid #725B2F`, radius `2px`. Hover shifts background to `#5E4B27`.
- **Sizing & Text**: Compact padding (`8px 14px`), font `Inter 13px weight 500`, sentence case only.

### Input Fields & Selectors
- **Form Controls**: Background `#FFFFFF`, border `1px solid #E6E2D9`, radius `2px`, height `36px`, padding `0 10px`. 
- **Focus State**: Border shifts directly to `1px solid #725B2F` with an outline of `2px solid rgba(114, 91, 47, 0.15)`. No blue or vibrant rings.
- **Search Wells**: Recessed background `#F2EDE4`, border `1px solid #E6E2D9`, shifting to `#FFFFFF` on active input focus.

### Status Badges & Chips
- **Geometry**: Height `22px`, padding `0 8px`, border-radius `2px`, typography `Inter 11px weight 600`, sentence case.
- **Tonal Scheme**:
  - *Under offer / Active*: Background `#F2EDE4`, text `#725B2F`, border `1px solid #D5CFC3`.
  - *Settled / Complete*: Background `#EBF0ED`, text `#2A4535`, border `1px solid #C4D4CB`.
  - *Contract draft / Review*: Background `#F7F4EE`, text `#6E5D3B`, border `1px solid #E2D9C5`.
  - *Archived / Expired*: Background `#EDEAE2`, text `#666158`, border `1px solid #DDD8CD`.

### Data Ledgers & Lists
- **Header Row**: Background `#F2EDE4`, text `#1A1A1A`, typography `Inter 12px weight 600`, height `38px`, border-bottom `1px solid #E6E2D9`.
- **Data Rows**: Background `#FFFFFF`, height `48px`, border-bottom `1px solid #E6E2D9`, hover state `#FDFCF9`. Numbers, valuations, and commissions set in `Inter 13px tabular-nums`.

### Cards & Dossier Sheets
- **Structure**: Background `#FFFFFF`, border `1px solid #E6E2D9`, radius `4px`, padding `20px`.
- **Card Headers**: Integrated title in `Source Serif 4 16px weight 500`, delimited by a subtle interior baseline border `1px solid #F2EDE4` when separating structured fields.

### Checkboxes & Selection Mechanics
- **Checkboxes**: Square `16px x 16px`, radius `2px`, border `1px solid #C4BEB1`, background `#FFFFFF`. Selected state fills `#1A1A1A` with a `#FFFFFF` checkmark.
- **Radio Buttons**: Circle `16px x 16px`, border `1px solid #C4BEB1`, background `#FFFFFF`. Selected state contains an inner dot of `#725B2F` (`6px`).