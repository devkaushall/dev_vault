<?php
	// @codingStandardsIgnoreStart
	/**
	 * Administration API: AIOWPSecurity_Ajax_Data_Table class
	 *
	 * This class handles the Ajax data table specific to the AIOS data format.
	 * It is responsible for managing, displaying, and manipulating the data
	 * collected by the AIOS plugin via Ajax requests.
	 *
	 * Copied from:
	 * @package WordPress
	 * @subpackage List_Table
	 * @since 3.1.0
	 *
	 * @package All In One Security
	 * @version 1.0.0
	 *
	 * @category Security
	 * @author All In One Security
	 * @copyright 2024
	 */
	// @codingStandardsIgnoreEnd

	/**
	 * Base class for displaying a list of items in an ajaxified HTML table.
	 *
	 * @since 3.1.0
	 * @access private
	 */
	if (!defined('ABSPATH')) {
	exit;//Exit if accessed directly
	}

class AIOWPSecurity_Ajax_Data_Table {

	/**
	 * The current list of items.
	 *
	 * @since 3.1.0
	 * @var array
	 */
	public $items;

	/**
	 * Various information about the current table.
	 *
	 * @since 3.1.0
	 * @var array
	 */
	protected $_args;

	/**
	 * Various information needed for displaying the pagination.
	 *
	 * @since 3.1.0
	 * @var array
	 */
	protected $_pagination_args = array();

	/**
	 * The current screen.
	 *
	 * @since 3.1.0
	 * @var object
	 */
	protected $screen;

	/**
	 * Cached bulk actions.
	 *
	 * @since 3.1.0
	 * @var array
	 */
	private $_actions;

	/**
	 * Cached pagination output.
	 *
	 * @since 3.1.0
	 * @var string
	 */
	private $_pagination;

	/**
	 * The view switcher modes.
	 *
	 * @since 4.1.0
	 * @var array
	 */
	protected $modes = array();

	/**
	 * Stores the value returned by ->get_column_info().
	 *
	 * @since 4.1.0
	 * @var array
	 */
	protected $_column_headers;

	/**
	 * {@internal Missing Summary}
	 *
	 * @var array
	 */
	protected $compat_fields = array('_args', '_pagination_args', 'screen', '_actions', '_pagination');

	/**
	 * {@internal Missing Summary}
	 *
	 * @var array
	 */
	protected $compat_methods = array(
		'set_pagination_args',
		'get_views',
		'get_bulk_actions',
		'bulk_actions',
		'row_actions',
		'months_dropdown',
		'view_switcher',
		'comments_bubble',
		'get_items_per_page',
		'pagination',
		'get_sortable_columns',
		'get_column_info',
		'get_table_classes',
		'display_tablenav',
		'extra_tablenav',
		'single_row_columns',
	);
	
	/**
	 * Allowed HTML tags and attributes used when rendering pagination & header markup.
	 *
	 * @var array
	 */
	protected $allowed_html = array(
		'a' => array(
			'class' => true,
			'id'    => true,
			'href'  => true,
		),
		'div' => array(
			'class' => true,
			'id'    => true,
		),
		'span' => array(
			'class'       => true,
			'id'          => true,
			'aria-hidden' => true,
		),
		'label' => array(
			'class' => true,
			'for'   => true,
		),
		'input' => array(
			'class'            => true,
			'id'               => true,
			'name'             => true,
			'type'             => true,
			'value'            => true,
			'size'             => true,
			'aria-describedby' => true,
		),
	);

	/**
	 * Constructor.
	 *
	 * The child class should call this constructor from its own constructor to override
	 * the default $args.
	 *
	 * @since 3.1.0
	 *
	 * @param array|string $args {
	 *							 Array or string of arguments.
	 *
	 * @type string $plural			Plural value used for labels and the objects being listed.
	 *								This affects things such as CSS class-names and nonces used
	 *								in the list table, e.g. 'posts'. Default empty.
	 * @type string $singular		Singular label for an object being listed, e.g. 'post'.
	 *								Default empty
	 * @type bool	$ajax			Whether the list table supports Ajax. This includes loading
	 *								and sorting data, for example. If true, the class will call
	 *								the js_vars() method in the footer to provide variables
	 *								to any scripts handling Ajax events. Default false.
	 * @type string $screen			String containing the hook name used to determine the current
	 *								screen. If left null, the current screen will be automatically set.
	 *								Default null.
	 * 	}
	 */
	public function __construct($args = array()) {
		$args = wp_parse_args(
			$args,
			array(
				'plural'   => '',
				'singular' => '',
				'ajax'     => false,
				'screen'   => null,
			)
		);

		// Workaround for WordPress bug that was fixed in 6.1: https://core.trac.wordpress.org/ticket/49089
		if (empty($GLOBALS['hook_suffix'])) {
			$GLOBALS['hook_suffix'] = '';
		}

		$this->screen = convert_to_screen($args['screen']);

		add_filter("manage_{$this->screen->id}_columns", array($this, 'get_columns'), 0);

		if (!$args['plural']) {
			$args['plural'] = $this->screen->base;
		}

		$args['plural'] = sanitize_key($args['plural']);
		$args['singular'] = sanitize_key($args['singular']);

		$this->_args = $args;

		if ($args['ajax']) {
			// wp_enqueue_script('list-table');
			add_action('admin_footer', array($this, 'js_vars'));
		}

		if (empty($this->modes)) {
			$this->modes = array(
				'list'    => esc_html__('List view', 'all-in-one-wp-security-and-firewall'),
				'excerpt' => esc_html__('Excerpt view', 'all-in-one-wp-security-and-firewall'),
			);
		}
	}

	/**
	 * Make private properties readable for backward compatibility.
	 *
	 * @since 4.0.0
	 *
	 * @param string $name - Property to get.
	 * @return mixed Property.
	 */
	public function __get($name) {
		if (in_array($name, $this->compat_fields)) {
			return $this->$name;
		}
	}

	/**
	 * Make private properties settable for backward compatibility.
	 *
	 * @since 4.0.0
	 *
	 * @param string $name  - Property to check if set.
	 * @param mixed  $value - Property value.
	 * @return mixed Newly-set property.
	 */
	public function __set($name, $value) {
		if (in_array($name, $this->compat_fields)) {
			return $this->$name = $value;
		}
	}

	/**
	 * Make private properties checkable for backward compatibility.
	 *
	 * @since 4.0.0
	 *
	 * @param string $name - Property to check if set.
	 * @return bool Whether the property is set.
	 */
	public function __isset($name) {
		if (in_array($name, $this->compat_fields)) {
			return isset($this->$name);
		}
	}

	/**
	 * Make private properties un-settable for backward compatibility.
	 *
	 * @since 4.0.0
	 *
	 * @param string $name - Property to unset.
	 */
	public function __unset($name) {
		if (in_array($name, $this->compat_fields)) {
			unset($this->$name);
		}
	}

	/**
	 * Make private/protected methods readable for backward compatibility.
	 *
	 * @since 4.0.0
	 *
	 * @param string $name      - Method to call.
	 * @param array  $arguments - Arguments to pass when calling.
	 * @return mixed|bool Return value of the callback, false otherwise.
	 */
	public function __call($name, $arguments) {
		if (in_array($name, $this->compat_methods)) {
			return call_user_func_array(array($this, $name), $arguments);
		}
		return false;
	}

	/**
	 * Checks the current user's permissions
	 *
	 * @since 3.1.0
	 * @abstract
	 */
	public function ajax_user_can() {
		die('function AIOWPSecurity_List_Table::ajax_user_can() must be over-ridden in a sub-class.');
	}

	/**
	 * Prepares the list of items for displaying.
	 *
	 * @uses AIOWPSecurity_List_Table::set_pagination_args()
	 *
	 * @since 3.1.0
	 * @abstract
	 */
	public function prepare_items() {
		die('function AIOWPSecurity_List_Table::prepare_items() must be over-ridden in a sub-class.');
	}

	/**
	 * An internal method that sets all the necessary pagination arguments
	 *
	 * @since 3.1.0
	 *
	 * @param array|string $args - Array or string of arguments with information about the pagination.
	 */
	protected function set_pagination_args($args) {
		$args = wp_parse_args(
			$args,
			array(
				'total_items' => 0,
				'total_pages' => 0,
				'per_page'    => 0,
			)
		);

		if (!$args['total_pages'] && $args['per_page'] > 0) {
			$args['total_pages'] = ceil($args['total_items'] / $args['per_page']);
		}

		// Redirect if page number is invalid and headers are not already sent.
		if (!headers_sent() && !wp_doing_ajax() && $args['total_pages'] > 0 && $this->get_pagenum() > $args['total_pages']) {
			wp_redirect(add_query_arg('paged', $args['total_pages']));
			exit;
		}

		$this->_pagination_args = $args;
	}

	/**
	 * Access the pagination args.
	 *
	 * @since 3.1.0
	 *
	 * @param string $key - Pagination argument to retrieve. Common values include 'total_items',
	 *                    'total_pages', 'per_page', or 'infinite_scroll'.
	 * @return int Number of items that correspond to the given pagination argument.
	 */
	public function get_pagination_arg($key) {
		if ('page' === $key) {
			return $this->get_pagenum();
		}

		if (isset($this->_pagination_args[$key])) {
			return $this->_pagination_args[$key];
		}
	}

	/**
	 * Whether the table has items to display or not
	 *
	 * @since 3.1.0
	 *
	 * @return bool
	 */
	public function has_items() {
		return !empty($this->items);
	}

	/**
	 * Message to be displayed when there are no items
	 *
	 * @since 3.1.0
	 */
	public function no_items() {
		esc_html_e('No items found.', 'all-in-one-wp-security-and-firewall');
	}

	/**
	 * Displays the search box.
	 *
	 * @since 3.1.0
	 *
	 * @param string $text     - The 'submit' button label.
	 * @param string $input_id - ID attribute value for the search input field.
	 */
	public function search_box($text, $input_id) {
		if (empty($this->_args['data']['s']) && !$this->has_items()) {
			return;
		}

		$input_id = $input_id . '-search-input';

		if (!empty($this->_args['data']['orderby'])) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr($this->_args['data']['orderby']) . '" />';
		}
		if (!empty($this->_args['data']['order'])) {
			echo '<input type="hidden" name="order" value="' . esc_attr($this->_args['data']['order']) . '" />';
		}
		if (!empty($this->_args['data']['post_mime_type'])) {
			echo '<input type="hidden" name="post_mime_type" value="' . esc_attr($this->_args['data']['post_mime_type']) . '" />';
		}
		if (!empty($this->_args['data']['detached'])) {
			echo '<input type="hidden" name="detached" value="' . esc_attr($this->_args['data']['detached']) . '" />';
		}
		?>
<p class="search-box">
	<label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($text); ?>:</label>
	<input type="search" id="<?php echo esc_attr($input_id); ?>" name="s" value="<?php _admin_search_query(); ?>" />
		<?php submit_button($text, '', '', false, array('id' => 'search-submit')); ?>
</p>
		<?php
	}

	/**
	 * Get an associative array (id => link) with the list
	 * of views available on this table.
	 *
	 * @since 3.1.0
	 *
	 * @return array
	 */
	protected function get_views() {
		return array();
	}

	/**
	 * Display the list of views available on this table.
	 *
	 * @since 3.1.0
	 */
	public function views() {
		$views = $this->get_views();
		/**
		 * Filters the list of available list table views.
		 *
		 * The dynamic portion of the hook name, `$this->screen->id`, refers
		 * to the ID of the current screen, usually a string.
		 *
		 * @since 3.5.0
		 *
		 * @param string[]     - $views An array of available list table views.
		 */
		$views = apply_filters("views_{$this->screen->id}", $views);

		if (empty($views)) {
			return;
		}

		$this->screen->render_screen_reader_content('heading_views');

		echo "<ul class='subsubsub'>\n";
		foreach ($views as $class => $view) {
			$views[$class] = "\t<li class='$class'>$view";
		}
		echo implode(" |</li>\n", esc_html($views)) . "</li>\n";
		echo '</ul>';
	}

	/**
	 * Get an associative array (option_name => option_title) with the list
	 * of bulk actions available on this table.
	 *
	 * @since 3.1.0
	 *
	 * @return array
	 */
	protected function get_bulk_actions() {
		return array();
	}

	/**
	 * Display the bulk actions dropdown.
	 *
	 * @since 3.1.0
	 *
	 * @param string $which - The location of the bulk actions: 'top' or 'bottom'.
	 *						This is designated as optional for backward compatibility.
	 */
	protected function bulk_actions($which = '') {
		if (is_null($this->_actions)) {
			$this->_actions = $this->get_bulk_actions();
			/**
			 * Filters the list table Bulk Actions drop-down.
			 *
			 * The dynamic portion of the hook name, `$this->screen->id`, refers
			 * to the ID of the current screen, usually a string.
			 *
			 * This filter can currently only be used to remove bulk actions.
			 *
			 * @since 3.5.0
			 *
			 * @param string[] $actions     - An array of the available bulk actions.
			 */
			$this->_actions = apply_filters("bulk_actions-{$this->screen->id}", $this->_actions);
			$two            = '';
		} else {
			$two = '2';
		}

		if (empty($this->_actions)) {
			return;
		}

		echo '<label for="bulk-action-selector-' . esc_attr($which) . '" class="screen-reader-text">' . esc_html__('Select bulk action', 'all-in-one-wp-security-and-firewall') . '</label>';
		echo '<select name="action' . esc_attr($two) . '" id="bulk-action-selector-' . esc_attr($which) . "\">\n";
		echo '<option value="-1">' . esc_html__('Bulk actions', 'all-in-one-wp-security-and-firewall') . "</option>\n";

		foreach ($this->_actions as $name => $title) {
			$class = 'edit' === $name ? 'hide-if-no-js' : '';
			echo "\t" . '<option value="' . esc_attr($name) . '" class="' . esc_attr($class) . '">' . esc_html($title) . "</option>\n";
		}

		echo "</select>\n";

		$submit_attributes = array('id' => "doaction$two");

		if ('top' == $which) {
			$submit_attributes['onclick'] = "return confirm('".esc_js(__('Are you sure you want to perform this bulk action?', 'all-in-one-wp-security-and-firewall'))."')";
		}

		submit_button(esc_html__('Apply', 'all-in-one-wp-security-and-firewall'), 'action', '', false, $submit_attributes);
		echo "\n";
	}

	/**
	 * Get the current action selected from the bulk actions dropdown.
	 *
	 * @since 3.1.0
	 *
	 * @return string|false The action name or False if no action was selected
	 */
	public function current_action() {
		if (isset($this->_args['data']['filter_action']) && !empty($this->_args['data']['filter_action'])) {
			return false;
		}

		if (isset($this->_args['data']['action']) && -1 != $this->_args['data']['action']) {
			return $this->_args['data']['action'];
		}

		if (isset($this->_args['data']['action2']) && -1 != $this->_args['data']['action2']) {
			return $this->_args['data']['action2'];
		}

		return false;
	}

	/**
	 * Generate row actions div
	 *
	 * @since 3.1.0
	 *
	 * @param array[] $actions - An array of action properties to make into a link.
	 */
	protected function row_actions($actions) {
		$action_count = count($actions);
		$i            = 0;
		
		if (empty($action_count)) {
			return;
		}
		
		echo '<div class="row-actions">';
		
		foreach ($actions as $action => $data) {
			++$i;
			
			if (!isset($data['attributes']['href'])) {
				$data['attributes']['href'] = '#';
			}
			
			echo '<span class="'.esc_attr($action).'">';
				echo '<a';
				foreach ($data['attributes'] as $attribute => $value) {
					if ('href' === $attribute) {
						echo ' href="'.esc_url($value).'"';
					} else {
						echo ' '.esc_attr($attribute).'="'.esc_attr($value).'"';
					}
				}
				$sep = ($i === $action_count) ? '' : ' | ';
				echo '>'.esc_html($data['text']).'</a>'.esc_html($sep);
			echo '</span>';
		}
			
		echo '</div>';
		echo '<button type="button" class="toggle-row"><span class="screen-reader-text">'.esc_html__('Show more details', 'all-in-one-wp-security-and-firewall').'</span></button>';
	}

	/**
	 * Display a monthly dropdown for filtering items
	 *
	 * @since 3.1.0
	 *
	 * @global wpdb      $wpdb
	 * @global WP_Locale $wp_locale
	 *
	 * @param string $post_type
	 */
	protected function months_dropdown($post_type) {
		global $wpdb, $wp_locale;

		/**
		 * Filters whether to remove the 'Months' drop-down from the post list table.
		 *
		 * @since 4.2.0
		 *
		 * @param bool   $disable     - Whether to disable the drop-down. Default false.
		 * @param string $post_type   - The post type.
		 */
		if (apply_filters('disable_months_dropdown', false, $post_type)) {
			return;
		}

		$extra_checks = "AND post_status != 'auto-draft'";
		if (!isset($this->_args['data']['post_status']) || 'trash' !== $this->_args['data']['post_status']) {
			$extra_checks .= " AND post_status != 'trash'";
		} elseif (isset($this->_args['data']['post_status'])) {
			$extra_checks = $wpdb->prepare(' AND post_status = %s', $this->_args['data']['post_status']);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- The $extra_checks variable, although prepared above, cannot be added to the prepare args in this statement.
		$months = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month FROM $wpdb->posts WHERE post_type = %s $extra_checks ORDER BY post_date DESC", $post_type));

		/**
		 * Filters the 'Months' drop-down results.
		 *
		 * @since 3.7.0
		 *
		 * @param object $months    The months drop-down query results.
		 * @param string $post_type The post type.
		 */
		$months = apply_filters('months_dropdown_results', $months, $post_type);

		$month_count = count($months);

		if (!$month_count || (1 == $month_count && 0 == $months[0]->month)) {
			return;
		}

		$m = isset($this->_args['data']['m']) ? (int) $this->_args['data']['m'] : 0;
		?>
		<label for="filter-by-date" class="screen-reader-text"><?php esc_html_e('Filter by date', 'all-in-one-wp-security-and-firewall'); ?></label>
		<select name="m" id="filter-by-date">
			<option<?php selected($m, 0); ?> value="0"><?php esc_html_e('All dates', 'all-in-one-wp-security-and-firewall'); ?></option>
		<?php
		foreach ($months as $arc_row) {
			if (0 == $arc_row->year) {
				continue;
			}

			$month = zeroise($arc_row->month, 2);
			$year  = $arc_row->year;

			printf("<option %s value='%s'>%s</option>\n",
				selected($m, $year . $month, false),
				esc_attr($arc_row->year . $month),
				/* translators: 1: month name, 2: 4-digit year */
				sprintf(esc_html__('%1$s %2$d', 'all-in-one-wp-security-and-firewall'), esc_html($wp_locale->get_month($month)), esc_html($year))
			);
		}
		?>
		</select>
		<?php
	}

	/**
	 * Display a view switcher
	 *
	 * @since 3.1.0
	 *
	 * @param string $current_mode
	 */
	protected function view_switcher($current_mode) {
		?>
		<input type="hidden" name="mode" value="<?php echo esc_attr($current_mode); ?>" />
		<div class="view-switch">
		<?php
		foreach ($this->modes as $mode => $title) {
			$classes = array('view-' . $mode);
			if ($current_mode === $mode) {
				$classes[] = 'current';
			}
			printf("<a href='%s' class='%s' id='view-switch-" . esc_attr($mode) . "'><span class='screen-reader-text'>%s</span></a>\n",
				esc_url(add_query_arg('mode', $mode)),
				implode(' ', array_map('esc_attr', $classes)),
				esc_html($title)
			);
		}
		?>
		</div>
		<?php
	}

	/**
	 * Display a comment count bubble
	 *
	 * @since 3.1.0
	 *
	 * @param int $post_id          The post ID.
	 * @param int $pending_comments Number of pending comments.
	 */
	protected function comments_bubble($post_id, $pending_comments) {
		$approved_comments = get_comments_number();

		$approved_comments_number = number_format_i18n($approved_comments);
		$pending_comments_number  = number_format_i18n($pending_comments);

		/* translators: %s: Approved comments */
		$approved_only_phrase = sprintf(_n('%s comment', '%s comments', $approved_comments, 'all-in-one-wp-security-and-firewall'), $approved_comments_number);
		/* translators: %s: Approved comments */
		$approved_phrase = sprintf(_n('%s approved comment', '%s approved comments', $approved_comments, 'all-in-one-wp-security-and-firewall'), $approved_comments_number);
		/* translators: %s: Pending comments */
		$pending_phrase = sprintf(_n('%s pending comment', '%s pending comments', $pending_comments, 'all-in-one-wp-security-and-firewall'), $pending_comments_number);

		// No comments at all.
		if (!$approved_comments && !$pending_comments) {
			printf('<span aria-hidden="true">&#8212;</span><span class="screen-reader-text">%s</span>', esc_html__('No comments', 'all-in-one-wp-security-and-firewall'));
			// Approved comments have different display depending on some conditions.
		} elseif ($approved_comments) {
			printf('<a href="%s" class="post-com-count post-com-count-approved"><span class="comment-count-approved" aria-hidden="true">%s</span><span class="screen-reader-text">%s</span></a>',
				esc_url(
					add_query_arg(
						array(
							'p'              => $post_id,
							'comment_status' => 'approved',
						),
						admin_url('edit-comments.php')
					)
				),
				esc_html($approved_comments_number),
				$pending_comments ? esc_html($approved_phrase) : esc_html($approved_only_phrase)
			);
		} else {
			printf(
				'<span class="post-com-count post-com-count-no-comments"><span class="comment-count comment-count-no-comments" aria-hidden="true">%s</span><span class="screen-reader-text">%s</span></span>',
				esc_html($approved_comments_number),
				$pending_comments ? esc_html__('No approved comments', 'all-in-one-wp-security-and-firewall') : esc_html__('No comments', 'all-in-one-wp-security-and-firewall')
			);
		}

		if ($pending_comments) {
			printf(
				'<a href="%s" class="post-com-count post-com-count-pending"><span class="comment-count-pending" aria-hidden="true">%s</span><span class="screen-reader-text">%s</span></a>',
				esc_url(
					add_query_arg(
						array(
							'p'              => $post_id,
							'comment_status' => 'moderated',
						),
						admin_url('edit-comments.php')
					)
				),
				esc_html($pending_comments_number),
				esc_html($pending_phrase)
			);
		} else {
			printf(
				'<span class="post-com-count post-com-count-pending post-com-count-no-pending"><span class="comment-count comment-count-no-pending" aria-hidden="true">%s</span><span class="screen-reader-text">%s</span></span>',
				esc_html($pending_comments_number),
				$approved_comments ? esc_html__('No pending comments', 'all-in-one-wp-security-and-firewall') : esc_html__('No comments', 'all-in-one-wp-security-and-firewall')
			);
		}
	}

	/**
	 * Get the current page number
	 *
	 * @since 3.1.0
	 *
	 * @return int
	 */
	public function get_pagenum() {
		$pagenum = isset($this->_args['data']['paged']) ? absint($this->_args['data']['paged']) : 0;

		if (isset($this->_pagination_args['total_pages']) && $pagenum > $this->_pagination_args['total_pages']) {
			$pagenum = $this->_pagination_args['total_pages'];
		}

		return max(1, $pagenum);
	}

	/**
	 * Get number of items to display on a single page
	 *
	 * @since 3.1.0
	 *
	 * @param string $option
	 * @param int    $default
	 * @return int
	 */
	protected function get_items_per_page($option, $default = 20) {
		$per_page = (int) get_user_option($option);
		if (empty($per_page) || $per_page < 1) {
			$per_page = $default;
		}

		/**
		 * Filters the number of items to be displayed on each page of the list table.
		 *
		 * The dynamic hook name, $option, refers to the `per_page` option depending
		 * on the type of list table in use. Possible values include: 'edit_comments_per_page',
		 * 'sites_network_per_page', 'site_themes_network_per_page', 'themes_network_per_page',
		 * 'users_network_per_page', 'edit_post_per_page', 'edit_page_per_page',
		 * 'edit_{$post_type}_per_page', etc.
		 *
		 * @since 2.9.0
		 *
		 * @param int $per_page     - Number of items to be displayed. Default 20.
		 */
		return (int) apply_filters("{$option}", $per_page);
	}



	/**
	 * Display the pagination.
	 *
	 * @since 3.1.0
	 *
	 * @param string $which
	 */
	protected function pagination($which) {
		if (empty($this->_pagination_args)) {
			return;
		}

		$total_items     = $this->_pagination_args['total_items'];
		$total_pages     = $this->_pagination_args['total_pages'];
		$infinite_scroll = false;
		if (isset($this->_pagination_args['infinite_scroll'])) {
			$infinite_scroll = $this->_pagination_args['infinite_scroll'];
		}

		if ('top' === $which && $total_pages > 1) {
			$this->screen->render_screen_reader_content('heading_pagination');
		}

		/* translators: %s: Total items */
		$output = '<span class="displaying-num">' . sprintf(_n('%s item', '%s items', esc_html($total_items), 'all-in-one-wp-security-and-firewall'), number_format_i18n($total_items)) . '</span>';

		$current = $this->get_pagenum();

		$removable_query_args = wp_removable_query_args();

		$host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';
		$request = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
		$current_url = set_url_scheme('http://' . $host . $request);

		$current_url = remove_query_arg($removable_query_args, $current_url);

		$page_links = array();

		$total_pages_before = '<span class="paging-input">';
		$total_pages_after  = '</span></span>';

		$disable_first = $disable_last = $disable_prev = $disable_next = false;

		if (1 == $current) {
			$disable_first = true;
			$disable_prev  = true;
		}
		if (2 == $current) {
			$disable_first = true;
		}
		if ($current == $total_pages) {
			$disable_last = true;
			$disable_next = true;
		}
		if ($current == $total_pages - 1) {
			$disable_last = true;
		}

		if ($disable_first) {
			$page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&laquo;</span>';
		} else {
			$page_links[] = sprintf(
				"<a class='first-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
				esc_url(remove_query_arg('paged', $current_url)),
				esc_html__('First page', 'all-in-one-wp-security-and-firewall'),
				'&laquo;'
			);
		}

		if ($disable_prev) {
			$page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&lsaquo;</span>';
		} else {
			$page_links[] = sprintf(
				"<a class='prev-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
				esc_url(add_query_arg('paged', max(1, $current - 1), $current_url)),
				esc_html__('Previous page', 'all-in-one-wp-security-and-firewall'),
				'&lsaquo;'
			);
		}

		if ('bottom' === $which) {
			$html_current_page  = $current;
			$total_pages_before = '<span class="screen-reader-text">' . esc_html__('Current page', 'all-in-one-wp-security-and-firewall') . '</span><span id="table-paging" class="paging-input"><span class="tablenav-paging-text">';
		} else {
			$html_current_page = sprintf(
				"%s<input class='current-page' id='current-page-selector' type='text' name='paged' value='%s' size='%d' aria-describedby='table-paging' /><span class='tablenav-paging-text'>",
				'<label for="current-page-selector" class="screen-reader-text">' . esc_html__('Current page', 'all-in-one-wp-security-and-firewall') . '</label>',
				$current,
				strlen($total_pages)
			);
		}
		$html_total_pages = sprintf("<span class='total-pages'>%s</span>", number_format_i18n($total_pages));
		/* translators: 1: Current page, 2: Total pages */
		$page_links[] = $total_pages_before . sprintf(esc_html_x('%1$s of %2$s', 'paging', 'all-in-one-wp-security-and-firewall'), $html_current_page, $html_total_pages) . $total_pages_after;

		if ($disable_next) {
			$page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&rsaquo;</span>';
		} else {
			$page_links[] = sprintf(
				"<a class='next-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
				esc_url(add_query_arg('paged', min($total_pages, $current + 1), $current_url)),
				esc_html__('Next page', 'all-in-one-wp-security-and-firewall'),
				'&rsaquo;'
			);
		}

		if ($disable_last) {
			$page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&raquo;</span>';
		} else {
			$page_links[] = sprintf(
				"<a class='last-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
				esc_url(add_query_arg('paged', $total_pages, $current_url)),
				esc_html__('Last page', 'all-in-one-wp-security-and-firewall'),
				'&raquo;'
			);
		}

		$pagination_links_class = 'pagination-links';
		if (!empty($infinite_scroll)) {
			$pagination_links_class .= ' hide-if-js';
		}
		$output .= "\n<span class='" . $pagination_links_class . "'>" . join("\n", $page_links) . '</span>';

		if ($total_pages) {
			$page_class = $total_pages < 2 ? ' one-page' : '';
		} else {
			$page_class = ' no-pages';
		}
		$this->_pagination = "<div class='tablenav-pages" . $page_class . "'>" . $output . "</div>";

		echo wp_kses($this->_pagination, $this->allowed_html);
	}

	/**
	 * Get a list of columns. The format is:
	 * 'internal-name' => 'Title'
	 *
	 * @since 3.1.0
	 * @abstract
	 *
	 * @return array
	 */
	public function get_columns() {
		die('function AIOWPSecurity_List_Table::get_columns() must be over-ridden in a sub-class.');
	}

	/**
	 * Get a list of sortable columns. The format is:
	 * 'internal-name' => 'orderby'
	 * or
	 * 'internal-name' => array('orderby', true)
	 *
	 * The second format will make the initial sorting order be descending
	 *
	 * @since 3.1.0
	 *
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array();
	}

	/**
	 * Gets the name of the default primary column.
	 *
	 * @since 4.3.0
	 *
	 * @return string Name of the default primary column, in this case, an empty string.
	 */
	protected function get_default_primary_column_name() {
		$columns = $this->get_columns();
		$column  = '';

		if (empty($columns)) {
			return $column;
		}

		// We need a primary defined so responsive views show something,
		// so let's fall back to the first non-checkbox column.
		foreach ($columns as $col => $column_name) {
			if ('cb' === $col) {
				continue;
			}

			$column = $col;
			break;
		}

		return $column;
	}

	/**
	 * Public wrapper for AIOWPSecurity_List_Table::get_default_primary_column_name().
	 *
	 * @since 4.4.0
	 *
	 * @return string Name of the default primary column.
	 */
	public function get_primary_column() {
		return $this->get_primary_column_name();
	}

	/**
	 * Gets the name of the primary column.
	 *
	 * @since 4.3.0
	 *
	 * @return string The name of the primary column.
	 */
	protected function get_primary_column_name() {
		$columns = get_column_headers($this->screen);
		$default = $this->get_default_primary_column_name();

		// If the primary column doesn't exist fall back to the
		// first non-checkbox column.
		if (!isset($columns[$default])) {
			$default = AIOWPSecurity_Ajax_Data_Table::get_default_primary_column_name();
		}

		/**
		 * Filters the name of the primary column for the current list table.
		 *
		 * @since 4.3.0
		 *
		 * @param string $default Column name default for the specific list table, e.g. 'name'.
		 * @param string $context Screen ID for specific list table, e.g. 'plugins'.
		 */
		$column = apply_filters('list_table_primary_column', $default, $this->screen->id);

		if (empty($column) || !isset($columns[$column])) {
			$column = $default;
		}

		return $column;
	}

	/**
	 * Get a list of all, hidden and sortable columns, with filter applied
	 *
	 * @since 3.1.0
	 *
	 * @return array
	 */
	protected function get_column_info() {
		// $_column_headers is already set / cached
		if (isset($this->_column_headers) && is_array($this->_column_headers)) {
			// Back-compat for list tables that have been manually setting $_column_headers for horse reasons.
			// In 4.3, we added a fourth argument for primary column.
			$column_headers = array(array(), array(), array(), $this->get_primary_column_name());
			foreach ($this->_column_headers as $key => $value) {
				$column_headers[$key] = $value;
			}

			return $column_headers;
		}

		$columns = get_column_headers($this->screen);
		$hidden  = get_hidden_columns($this->screen);

		$sortable_columns = $this->get_sortable_columns();
		/**
		 * Filters the list table sortable columns for a specific screen.
		 *
		 * The dynamic portion of the hook name, `$this->screen->id`, refers
		 * to the ID of the current screen, usually a string.
		 *
		 * @since 3.5.0
		 *
		 * @param array $sortable_columns     - An array of sortable columns.
		 */
		$_sortable = apply_filters("manage_{$this->screen->id}_sortable_columns", $sortable_columns);

		$sortable = array();
		foreach ($_sortable as $id => $data) {
			if (empty($data)) {
				continue;
			}

			$data = (array) $data;
			if (!isset($data[1])) {
				$data[1] = false;
			}

			$sortable[$id] = $data;
		}

		$primary               = $this->get_primary_column_name();
		$this->_column_headers = array($columns, $hidden, $sortable, $primary);

		return $this->_column_headers;
	}

	/**
	 * Return number of visible columns
	 *
	 * @since 3.1.0
	 *
	 * @return int
	 */
	public function get_column_count() {
		list ($columns, $hidden) = $this->get_column_info();
		$hidden                    = array_intersect(array_keys($columns), array_filter($hidden));
		return count($columns) - count($hidden);
	}

	/**
	 * Print column headers, accounting for hidden and sortable columns.
	 *
	 * @since 3.1.0
	 *
	 * @staticvar int $cb_counter
	 *
	 * @param bool $with_id - Whether to set the id attribute or not
	 */
	public function print_column_headers($with_id = true) {
		global $wp_version;
		
		list($columns, $hidden, $sortable, $primary) = $this->get_column_info();

		$host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';
		$request = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
		$current_url = set_url_scheme('http://' . $host . $request);
		$current_url = remove_query_arg('paged', $current_url);

		if (isset($this->_args['data']['orderby'])) {
			$current_orderby = $this->_args['data']['orderby'];
		} else {
			$current_orderby = '';
		}

		if (isset($this->_args['data']['order']) && 'desc' === $this->_args['data']['order']) {
			$current_order = 'desc';
		} else {
			$current_order = 'asc';
		}

		if (!empty($columns['cb'])) {
			static $cb_counter = 1;
			$columns['cb']     = '<label class="screen-reader-text" for="cb-select-all-' . $cb_counter . '">' . esc_html__('Select all', 'all-in-one-wp-security-and-firewall') . '</label>'
				. '<input id="cb-select-all-' . $cb_counter . '" type="checkbox" />';
			$cb_counter++;
		}

		foreach ($columns as $column_key => $column_display_name) {
			$class = array('manage-column', "column-$column_key");

			if (in_array($column_key, $hidden)) {
				$class[] = 'hidden';
			}

			if ('cb' === $column_key) {
				$class[] = 'check-column';
			} elseif (in_array($column_key, array('posts', 'comments', 'links'))) {
				$class[] = 'num';
			}

			if ($column_key === $primary) {
				$class[] = 'column-primary';
			}

			if (isset($sortable[$column_key])) {
				list($orderby, $desc_first) = $sortable[$column_key];

				if ($current_orderby === $orderby) {
					$order   = 'asc' === $current_order ? 'desc' : 'asc';
					$class[] = 'sorted';
					$class[] = $current_order;
				} else {
					$order   = $desc_first ? 'desc' : 'asc';
					$class[] = 'sortable';
					$class[] = $desc_first ? 'asc' : 'desc';
				}
				
				$sorting_indicators_html = "<span class='sorting-indicator'></span>";
				
				if (version_compare($wp_version, '6.3', '>=')) {
					$sorting_indicators_html = '<span class="sorting-indicators">'
						.     '<span class="sorting-indicator asc" aria-hidden="true"></span>'
						.     '<span class="sorting-indicator desc" aria-hidden="true"></span>'
						. '</span>';
				}
				
				$column_display_name = '<a href="' . esc_url(add_query_arg(compact('orderby', 'order'), $current_url)) . '">'
					. '<span>' . $column_display_name . '</span>'
					. $sorting_indicators_html
					. '</a>';
			}
			
			$tag = ('cb' === $column_key) ? 'td' : 'th';
						
			printf(
				'<%1$s %2$s %3$s class="%4$s">%5$s</%1$s>',
				tag_escape($tag),
				('th' === $tag) ? 'scope="col"' : '',
				$with_id ? 'id="'.esc_attr($column_key).'"' : '',
				esc_attr(join(' ', $class)),
				wp_kses($column_display_name, $this->allowed_html)
			);
		}
	}

	/**
	 * Display the table
	 *
	 * @since 3.1.0
	 */
	public function display() {
		$singular = $this->_args['singular'];

		$this->display_tablenav('top');

		$this->screen->render_screen_reader_content('heading_list');
		?>
<table class="wp-list-table <?php echo implode(' ', array_map('esc_attr', $this->get_table_classes())); ?>">
	<thead>
	<tr>
		<?php $this->print_column_headers(); ?>
	</tr>
	</thead>

	<tbody id="the-list"
		<?php
		if ($singular) {
			echo " data-wp-lists='list:" . esc_attr($singular) . "'";
		}
		?>
		>
		<?php $this->display_rows_or_placeholder(); ?>
	</tbody>

	<tfoot>
	<tr>
		<?php $this->print_column_headers(false); ?>
	</tr>
	</tfoot>

</table>
		<?php
		$this->display_tablenav('bottom');
	}

	/**
	 * Get a list of CSS classes for the AIOWPSecurity_List_Table table tag.
	 *
	 * @since 3.1.0
	 *
	 * @return array List of CSS classes for the table tag.
	 */
	protected function get_table_classes() {
		return array('widefat', 'fixed', 'striped', $this->_args['plural']);
	}

	/**
	 * Generate the table navigation above or below the table
	 *
	 * @since 3.1.0
	 * @param string $which
	 */
	protected function display_tablenav($which) {
		if ('top' === $which) {
			wp_nonce_field('bulk-' . $this->_args['plural']);
		}
		?>
	<div class="tablenav <?php echo esc_attr($which); ?>">

		<?php if ($this->has_items()) : ?>
		<div class="alignleft actions bulkactions">
			<?php $this->bulk_actions($which); ?>
		</div>
			<?php
		endif;
		$this->extra_tablenav($which);
		$this->pagination($which);
		?>

		<br class="clear" />
	</div>
		<?php
	}

	/**
	 * Extra controls to be displayed between bulk actions and pagination
	 *
	 * @since 3.1.0
	 *
	 * @param string $which
	 */
	protected function extra_tablenav($which) {} // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable, Squiz.WhiteSpace.ScopeClosingBrace.ContentBefore, PEAR.WhiteSpace.ScopeClosingBrace.Line -- this is a protected function

	/**
	 * Generate the tbody element for the list table.
	 *
	 * @since 3.1.0
	 */
	public function display_rows_or_placeholder() {
		if ($this->has_items()) {
			$this->display_rows();
		} else {
			echo '<tr class="no-items"><td class="colspanchange" colspan="' . esc_attr($this->get_column_count()) . '">';
			$this->no_items();
			echo '</td></tr>';
		}
	}

	/**
	 * Generate the table rows
	 *
	 * @since 3.1.0
	 */
	public function display_rows() {
		foreach ($this->items as $item) {
			$this->single_row($item);
		}
	}

	/**
	 * Generates content for a single row of the table
	 *
	 * @since 3.1.0
	 *
	 * @param object $item The current item
	 */
	public function single_row($item) {
		echo '<tr>';
		$this->single_row_columns($item);
		echo '</tr>';
	}

	/**
	 * This function renders a default column item
	 *
	 * @param array  $item        - Item object
	 * @param string $column_name - Column name to be rendered from item object
	 */
	protected function column_default($item, $column_name) {
		echo esc_html($item[$column_name]);
	}
	
	/**
	 * This function renders the checkbox column
	 *
	 * @param array $item - item object
	 */
	protected function column_cb($item) {
		printf(
			'<input type="checkbox" name="%1$s[]" value="%2$s" />',
			esc_attr($this->_args['singular']),  //Let's simply repurpose the table's singular label
			esc_attr($item['id'])                //The value of the checkbox should be the record's id
		);
	}

	/**
	 * Generates the columns for a single row of the table
	 *
	 * @since 3.1.0
	 *
	 * @param object $item - The current item
	 *
	 *					   removed $sortable as it was unused from list() call
	 */
	protected function single_row_columns($item) {
		list($columns, $hidden, $sortable, $primary) = $this->get_column_info(); // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- Unused parameters are for future use.

		foreach ($columns as $column_name => $column_display_name) {
			$classes = "$column_name column-$column_name";
			if ($primary === $column_name) {
				$classes .= ' has-row-actions column-primary';
			}

			if (in_array($column_name, $hidden)) {
				$classes .= ' hidden';
			}

			// Comments column uses HTML in the display name with screen reader text.
			// Instead of using esc_attr(), we strip tags to get closer to a user-friendly string.
			$data_colname = wp_strip_all_tags($column_display_name);

			if ('cb' === $column_name) {
				echo '<th scope="row" class="check-column">';
				$this->column_cb($item);
				echo '</th>';
			} elseif (method_exists($this, 'column_' . $column_name)) {
				echo '<td class="'.esc_attr($classes).'" data-colname="'.esc_attr($data_colname).'">';
				call_user_func(array($this, 'column_' . $column_name), $item);
				echo '</td>';
			} else {
				echo '<td class="'.esc_attr($classes).'" data-colname="'.esc_attr($data_colname).'">';
				$this->column_default($item, $column_name);
				echo '</td>';
			}
		}
	}


	/**
	 * Handle an incoming ajax request (called from admin-ajax.php)
	 *
	 * @param bool $return_instead_of_echo - Whether to return data or die() with data.
	 *
	 * @since 3.1.0
	 */
	public function ajax_response($return_instead_of_echo = false) {
		$this->prepare_items(false);

		ob_start();
		if (!empty($this->_args['data']['no_placeholder'])) {
			$this->display_rows();
		} else {
			$this->display_rows_or_placeholder();
		}

		$rows = ob_get_clean();

		ob_start();
		$this->print_column_headers(true);
		$headers = ob_get_clean();

		ob_start();
		$this->pagination('top');
		$pagination_top = ob_get_clean();

		ob_start();
		$this->pagination('bottom');
		$pagination_bottom = ob_get_clean();

		$response = array(
			'rows' => $rows,
			'pagination' => array(
				'top' => $pagination_top,
				'bottom' => $pagination_bottom,
			),
			'column_headers' => $headers,
		);

		if (isset($this->_pagination_args['total_items'])) {
			$response['total_items_i18n'] = sprintf(
				/* translators: %s: Total items */
				_n('%s item', '%s items', $this->_pagination_args['total_items'], 'all-in-one-wp-security-and-firewall'),
				number_format_i18n($this->_pagination_args['total_items'])
			);
		}
		if (isset($this->_pagination_args['total_pages'])) {
			$response['total_pages']      = $this->_pagination_args['total_pages'];
			$response['total_pages_i18n'] = number_format_i18n($this->_pagination_args['total_pages']);
		}

		// Get the message from the helper
		$list_message = AIOS_Helper::get_message('aios_list_message');
		if ($list_message) {
			$response['message'] = $list_message['message'];
			$response['status'] = $list_message['type'];
		}

		if ($return_instead_of_echo) {
			return $response;
		}

		die(wp_json_encode($response));
	}

	/**
	 * Send required variables to JavaScript land
	 */
	public function js_vars() {
		$args = array(
			'class'  => get_class($this),
			'screen' => array(
				'id'   => $this->screen->id,
				'base' => $this->screen->base,
			),
		);

		printf("<script>list_args = %s;</script>\n", wp_json_encode($args));
	}

	/**
	 * Retrieves and returns current WP general settings date time format.
	 *
	 * @return String
	 */
	protected function get_wp_date_time_format() {
		static $wp_date_time_format;

		if (!isset($wp_date_time_format)) {
			$wp_date_time_format = get_option('date_format').' '.get_option('time_format');
		}

		return $wp_date_time_format;
	}
}