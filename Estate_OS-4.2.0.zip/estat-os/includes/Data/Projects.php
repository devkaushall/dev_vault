<?php
/**
 * Society / project repository.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Audit\AuditLog;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\PublicText;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Projects are first class records that can act as a parent for listings.
 */
final class Projects {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete' ) );
	}

	/**
	 * Create or update a project.
	 *
	 * @param array<string,mixed> $input   Raw input.
	 * @param int                 $post_id Existing ID or 0.
	 * @return int|WP_Error
	 */
	public static function save( array $input, int $post_id = 0 ) {
		$title = Sanitize::title( $input['title'] ?? '' );
		if ( 0 === $post_id && '' === $title ) {
			return new WP_Error( 'estat_invalid_title', __( 'Please enter the name of the society or project.', 'estat-os' ) );
		}

		$postarr = array(
			'post_type'   => PostTypes::PROJECT,
			'post_title'  => $title,
			'post_status' => Sanitize::choice( $input['status'] ?? 'publish', array( 'draft', 'publish' ), 'publish' ),
		);

		/*
		 * A master sheet carries the web address of every project already. That
		 * address is what the site has been telling Google for years, so when
		 * the sheet gives one it is used as it is, not rebuilt from the name.
		 */
		if ( isset( $input['slug'] ) && '' !== trim( (string) $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $input['slug'] );
		}
		if ( isset( $input['description'] ) ) {
			$postarr['post_content'] = Sanitize::html( $input['description'] );
		}
		if ( $post_id > 0 ) {
			$postarr['ID'] = $post_id;

			// Snapshot what is there now, before any of it is overwritten.
			Undo::capture( $post_id );
			$result        = wp_update_post( $postarr, true );
		} else {
			$result = wp_insert_post( $postarr, true );
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$project_id = (int) $result;

		foreach ( Meta::project_schema() as $key => $field ) {
			if ( ! empty( $field['computed'] ) ) {
				continue;
			}
			$short = substr( $key, strlen( '_estat_' ) );
			if ( array_key_exists( $key, $input ) ) {
				$raw = $input[ $key ];
			} elseif ( array_key_exists( $short, $input ) ) {
				$raw = $input[ $short ];
			} else {
				/*
				 * The question was never asked — an import row with no column
				 * for it, or a quick add from the phone. Rather than leaving the
				 * record with a blank where the office expects a word, the
				 * schema's own default is written once, on a record that has
				 * nothing stored yet. A value the office chose (including the
				 * screen's "not said yet") always arrives as an input, so it is
				 * never overwritten by this.
				 */
				$default = (string) ( $field['default'] ?? '' );
				if ( '' !== $default && '' === (string) get_post_meta( $project_id, $key, true ) ) {
					update_post_meta( $project_id, $key, $default );
				}
				continue;
			}
			$value = Meta::sanitize_value( $raw, $field );
			if ( '' === $value || array() === $value ) {
				delete_post_meta( $project_id, $key );
			} else {
				update_post_meta( $project_id, $key, $value );
			}
		}

		if ( isset( $input['locality'] ) ) {
			$locality = is_array( $input['locality'] ) ? $input['locality'] : array( $input['locality'] );
			$ids      = array();
			foreach ( $locality as $item ) {
				if ( is_numeric( $item ) ) {
					$ids[] = (int) $item;
					continue;
				}
				$name = Sanitize::text( $item );
				if ( '' === $name ) {
					continue;
				}
				$term = term_exists( $name, Taxonomies::LOCALITY );
				if ( ! is_array( $term ) ) {
					$term = wp_insert_term( $name, Taxonomies::LOCALITY );
				}
				if ( ! is_wp_error( $term ) ) {
					$ids[] = (int) $term['term_id'];
				}
			}
			wp_set_object_terms( $project_id, $ids, Taxonomies::LOCALITY, false );
		}

		// Detect stage change for F11 webhooks/emails.
		$old_stage = $post_id > 0 ? (string) get_post_meta( $post_id, '_estat_project_status', true ) : '';
		$new_stage = '';
		if ( isset( $input['_estat_project_status'] ) ) { $new_stage = (string) $input['_estat_project_status']; }
		elseif ( isset( $input['project_status'] ) ) { $new_stage = (string) $input['project_status']; }
		elseif ( isset( $input['stage'] ) ) { $new_stage = (string) $input['stage']; }

		if ( isset( $input['cover_id'] ) ) {
			$cover = Sanitize::int( $input['cover_id'] );
			if ( $cover ) {
				set_post_thumbnail( $project_id, $cover );
			}
		}

		AuditLog::record( $post_id > 0 ? 'project.updated' : 'project.created', 'project', $project_id, array( 'old_stage' => $old_stage, 'new_stage' => $new_stage ) );

		if ( $post_id > 0 && '' !== $new_stage && $new_stage !== $old_stage ) {
			do_action( 'estat_project_stage_changed', $project_id, $old_stage, $new_stage );
		}

		return $project_id;
	}

	/**
	 * Read an attachment-ID list out of project meta.
	 *
	 * The importer writes these as a comma string, an array or a single id
	 * depending on where the row came from, and a template should not have
	 * to care which.
	 *
	 * @param int    $project_id Project ID.
	 * @param string $meta_key   Meta key.
	 * @return array<int,int>
	 */
	private static function ids( int $project_id, string $meta_key ): array {
		$raw = get_post_meta( $project_id, $meta_key, true );
		if ( '' === $raw || null === $raw ) {
			return array();
		}
		$raw  = is_array( $raw ) ? $raw : explode( ',', (string) $raw );
		$ids  = array_values( array_unique( array_filter( array_map( 'absint', (array) $raw ) ) ) );

		return array_values(
			array_filter(
				$ids,
				static function ( $id ) {
					return $id > 0 && 'attachment' === get_post_type( $id );
				}
			)
		);
	}

	/**
	 * How many published listings belong to this one project.
	 *
	 * Kept separate from to_array() because it costs a query, and a card grid
	 * asks for hundreds of projects at once — those callers use
	 * listing_counts() instead, which asks once for all of them.
	 *
	 * @param int $project_id Project ID.
	 * @return int
	 */
	public static function listing_count( int $project_id ): int {
		$counts = self::listing_counts( array( $project_id ) );
		return (int) ( $counts[ $project_id ] ?? 0 );
	}

	/**
	 * How many published listings belong to each of these projects.
	 *
	 * The Projects screen used to call stats() once per row, which is one
	 * database query per project on every page load. This asks once.
	 *
	 * @param array<int> $project_ids Project IDs.
	 * @return array<int,int> Project ID => number of published listings.
	 */
	public static function listing_counts( array $project_ids ): array {
		$project_ids = array_values( array_unique( array_filter( array_map( 'absint', $project_ids ) ) ) );

		if ( ! $project_ids ) {
			return array();
		}

		global $wpdb;
		$table = $wpdb->prefix . 'estat_index';

		// Integers only, and built from absint above, so this is safe to inline.
		$placeholders = implode( ',', array_fill( 0, count( $project_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT project_id, COUNT(*) AS total
				 FROM {$table}
				 WHERE project_id IN ({$placeholders}) AND post_status = 'publish'
				 GROUP BY project_id",
				...$project_ids
			),
			ARRAY_A
		);
		// phpcs:enable

		$counts = array_fill_keys( $project_ids, 0 );

		foreach ( (array) $rows as $row ) {
			$counts[ (int) $row['project_id'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * One project as a plain array.
	 *
	 * Listings and Agents both had this; Projects did not, so seven fields the
	 * editor collects - the builder, the price range, unit counts, possession
	 * date, unit types and the registration number - reached nobody. The
	 * template read only the stage and two figures from stats().
	 *
	 * @param int $project_id Project ID.
	 * @return array<string,mixed> Empty when the ID is not a project.
	 */
	public static function to_array( int $project_id ): array {
		$post = get_post( $project_id );

		if ( ! $post || PostTypes::PROJECT !== $post->post_type ) {
			return array();
		}

		/**
		 * A price range of 0 means "not stated", not "free". Callers need to
		 * be able to tell those apart, so the raw numbers are given as well
		 * as the formatted strings.
		 */
		$price_min = (float) get_post_meta( $project_id, '_estat_price_min', true );
		$price_max = (float) get_post_meta( $project_id, '_estat_price_max', true );

		$data = array(
			'id'                => $project_id,
			'title'             => $post->post_title,
			'description'       => $post->post_content,
			'url'               => get_permalink( $project_id ),
			'status'            => $post->post_status,
			'stage'             => (string) get_post_meta( $project_id, '_estat_project_status', true ),
			'developer'         => (string) get_post_meta( $project_id, '_estat_developer', true ),
			'project_type'      => (string) get_post_meta( $project_id, '_estat_project_type', true ),
			'category'          => (string) get_post_meta( $project_id, '_estat_category', true ),
			'address'           => (string) get_post_meta( $project_id, '_estat_address', true ),
			'possession_date'   => (string) get_post_meta( $project_id, '_estat_possession_date', true ),
			'price_min'         => $price_min,
			'price_max'         => $price_max,
			'price_min_display' => $price_min > 0 ? Format::money( $price_min ) : '',
			'price_max_display' => $price_max > 0 ? Format::money( $price_max ) : '',
			'price_display'     => ( $price_min > 0 || $price_max > 0 ) ? Format::price_range( $price_min, $price_max ) : '',
			'total_units'       => (int) get_post_meta( $project_id, '_estat_total_units', true ),
			'available_units'   => (int) get_post_meta( $project_id, '_estat_available_units', true ),
			'unit_types'        => (string) get_post_meta( $project_id, '_estat_unit_types', true ),
			'highlights'        => (string) get_post_meta( $project_id, '_estat_highlights', true ),
			'locality'          => ( static function() use ( $project_id ) { $t = wp_get_object_terms( $project_id, Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); return is_wp_error($t) ? array() : (array) $t; } )(),
			'cover'             => get_the_post_thumbnail_url( $project_id, 'large' ) ?: '',
			'latitude'          => (string) get_post_meta( $project_id, '_estat_latitude', true ),
			'longitude'         => (string) get_post_meta( $project_id, '_estat_longitude', true ),

			/*
			 * The record has held a gallery, floor plans and brochures since
			 * the schema was written, but to_array() never carried them, so
			 * no public template could draw them and every imported project
			 * page was a page with one photograph. They are read here as
			 * attachment IDs — the same shape Listings::to_array() already
			 * returns for a property — so one gallery component draws both.
			 */
			'gallery'           => self::ids( $project_id, '_estat_gallery' ),
			'floor_plans'       => self::ids( $project_id, '_estat_floor_plans' ),
			'brochures'         => self::ids( $project_id, '_estat_brochures' ),

			/*
			 * A society can be given a film or a walkthrough exactly the way
			 * a property can. The project screen does not ask for them yet,
			 * so most records hold nothing here — which is fine: a card is
			 * drawn for a link that exists, and no card at all for one that
			 * does not.
			 */
			'video_url'         => esc_url_raw( (string) get_post_meta( $project_id, '_estat_video_url', true ) ),
			'tour_url'          => esc_url_raw( (string) get_post_meta( $project_id, '_estat_tour_url', true ) ),

			/*
			 * Stored stage and category are keys ("new_launch"). Every caller
			 * was turning them into words by hand, and two of them got it
			 * wrong. They are translated here, once.
			 */
			'stage_label'       => Vocabulary::label( 'project_statuses', (string) get_post_meta( $project_id, '_estat_project_status', true ) ),
			'category_label'    => Vocabulary::label( 'project_categories', (string) get_post_meta( $project_id, '_estat_category', true ) ),

			/*
			 * Unit types are stored as one comma separated line. The card and
			 * the facts grid both want them as separate items.
			 */
			'unit_type_list'    => array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $project_id, '_estat_unit_types', true ) ) ) ) ),

			/*
			 * The public wording of the highlights. The stored value is
			 * written by the office, by the importer and by whoever researched
			 * the project, so it goes through the public/internal firewall
			 * rather than being printed as it stands.
			 */
			'highlight_lines'   => PublicText::lines( (string) get_post_meta( $project_id, '_estat_highlights', true ) ),

			/*
			 * A locality name alone cannot build a link. The terms travel
			 * with the names so a template can point at the locality page
			 * without another lookup per project.
			 */
			'locality_terms'    => ( static function() use ( $project_id ) { $t = wp_get_object_terms( $project_id, Taxonomies::LOCALITY ); return is_wp_error($t) ? array() : (array) $t; } )(),
		);

		// Same rule as a listing: shown only when the office has turned
		// registration numbers on.
		if ( Settings::get( 'show_regulatory' ) ) {
			$data['regulatory_id'] = (string) get_post_meta( $project_id, '_estat_regulatory_id', true );
		}

		/**
		 * Filter the project representation.
		 *
		 * @param array<string,mixed> $data       Project data.
		 * @param int                 $project_id Project ID.
		 */
		return (array) apply_filters( 'estat_project_array', $data, $project_id );
	}

	/**
	 * Statistics for one project.
	 *
	 * @param int $project_id Project ID.
	 * @return array<string,mixed>
	 */
	public static function stats( int $project_id ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'estat_index';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total,
					SUM(CASE WHEN availability = 'available' THEN 1 ELSE 0 END) AS available,
					MIN(CASE WHEN price > 0 THEN price END) AS price_min,
					MAX(price) AS price_max
				 FROM {$table} WHERE project_id = %d AND post_status = 'publish'",
				$project_id
			),
			ARRAY_A
		);
		// phpcs:enable

		return array(
			'project_id' => $project_id,
			'listings'   => isset( $row['total'] ) ? (int) $row['total'] : 0,
			'available'  => isset( $row['available'] ) ? (int) $row['available'] : 0,
			'price_min'  => isset( $row['price_min'] ) ? (float) $row['price_min'] : 0.0,
			'price_max'  => isset( $row['price_max'] ) ? (float) $row['price_max'] : 0.0,
		);
	}

	/**
	 * Detach listings from a deleted project so relationships never break.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_delete( int $post_id ): void {
		if ( PostTypes::PROJECT !== get_post_type( $post_id ) ) {
			return;
		}
		$listings = get_posts(
			array(
				'post_type'   => PostTypes::LISTING,
				'post_status' => 'any',
				'numberposts' => 500,
				'fields'      => 'ids',
				'meta_key'    => '_estat_project_id',
				'meta_value'  => $post_id,
			)
		);
		foreach ( $listings as $listing_id ) {
			delete_post_meta( (int) $listing_id, '_estat_project_id' );
			Listings::refresh_derived( (int) $listing_id );
		}
		AuditLog::record( 'project.deleted', 'project', $post_id, array( 'detached' => count( $listings ) ) );
	}

	/**
	 * Find a project by reference number.
	 *
	 * @param string $external_id Reference.
	 * @return int
	 */
	public static function find_by_external_id( string $external_id ): int {
		$external_id = Sanitize::text( $external_id );
		if ( '' === $external_id ) {
			return 0;
		}
		$found = get_posts(
			array(
				'post_type'     => PostTypes::PROJECT,
				'post_status'   => 'any',
				'numberposts'   => 1,
				'fields'        => 'ids',
				'meta_key'      => '_estat_external_id',
				'meta_value'    => $external_id,
				'no_found_rows' => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}
}
