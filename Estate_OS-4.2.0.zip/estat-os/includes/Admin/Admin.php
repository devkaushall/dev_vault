<?php
/**
 * Office admin: menu, assets and screen routing.
 * The single sidebar and screen list.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public const MENU = 'estat-today';

	/**
	 * The settings screen.
	 *
	 * It is one line in the Office menu like everything else — not a menu of
	 * its own, because the left side of the screen belongs to WordPress and
	 * the plugin adds one menu to it, not two.
	 */
	public const SETTINGS_MENU = 'estat-settings';

	public function register(): void {

		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( Actions::class, 'handle' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
		add_action( 'admin_head', array( $this, 'hide_clutter' ) );
		add_action( 'wp_ajax_estat_move_pipeline', array( __CLASS__, 'ajax_move_pipeline' ) );
		add_action( 'wp_ajax_estat_test_mail', array( __CLASS__, 'ajax_test_mail' ) );
		add_action( 'wp_ajax_estat_test_webhook', array( __CLASS__, 'ajax_test_webhook' ) );
		add_action( 'admin_notices', array( $this, 'setup_nudge' ) );
		add_action( 'admin_notices', array( $this, 'missing_tables_nudge' ) );
		add_action( 'admin_init', array( $this, 'maybe_greet' ), 5 );
		( new Os\Ajax() )->register();
	}

	public function maybe_greet(): void {
		if ( '1' !== (string) get_option( 'estat_show_setup', '' ) ) { return; }
		delete_option( 'estat_show_setup' );
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
		if ( ! current_user_can( 'estat_manage_settings' ) ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['activate-multi'] ) ) { return; }
		wp_safe_redirect( admin_url( 'admin.php?page=' . Os\Screens\SetupScreen::SLUG ) );
		exit;
	}

	/**
	 * Say plainly when the office is missing one of its own tables.
	 *
	 * "The office database is not ready yet" is what every screen says when a
	 * table is absent, and it told nobody which one or what to do about it.
	 * This is a host problem — file permissions, a database that refuses the
	 * statement, a half-finished update — so the office is told the truth and
	 * given the one thing that can help.
	 */
	public function missing_tables_nudge(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			return;
		}
		$missing = \EstatOS\Install\Schema::missing_tables();
		if ( ! $missing ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['page'] ) ? '' : $_GET['page'] ) ) ) : '';
		$in_here = 0 === strpos( $page, 'estat-' );
		if ( ! $in_here ) {
			return;
		}
		$names = array();
		foreach ( $missing as $name ) {
			$names[] = '<code>' . esc_html( (string) $name ) . '</code>';
		}
		printf(
			'<div class="notice notice-error"><p><strong>%1$s</strong> %2$s</p><p>%3$s %4$s</p></div>',
			esc_html__( 'Part of the office could not be set up.', 'estat-os' ),
			esc_html__( 'Some of the plugin\'s own tables are not in the database, so those screens cannot save anything yet.', 'estat-os' ),
			esc_html__( 'Missing:', 'estat-os' ),
			implode( ', ', $names ) . ' — ' . esc_html__( 'stop and start the plugin once (Plugins screen), and if it comes back, send this line to your host.', 'estat-os' )
		);
	}

	public function setup_nudge(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) || ! Os\Screens\SetupScreen::needed() ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['page']) ? '' : $_GET['page'] ) ) ) : '';
		if ( 0 !== strpos( $page, 'estat-' ) || Os\Screens\SetupScreen::SLUG === $page ) { return; }
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a class="button button-primary" href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Your website is not showing your properties yet.', 'estat-os' ),
			esc_html__( 'Answer four short questions and we will build the pages for you.', 'estat-os' ),
			esc_url( admin_url( 'admin.php?page=' . Os\Screens\SetupScreen::SLUG ) ),
			esc_html__( 'Finish setup', 'estat-os' )
		);
	}

	/**
	 * Every screen the office has, written down once.
	 *
	 * The sidebar, the routing table and the page heading all read from this
	 * one list. Adding a screen means adding one entry here and nothing else,
	 * so a screen can never again be routed but not registered — which is how
	 * eight of them became unreachable in 3.0.7.
	 *
	 * 'menu'   => false keeps a screen out of the sidebar while still
	 *             registering it, so links inside other screens work.
	 * 'wide' => a screen that needs the whole window and not the 1240px
	 *          reading width the office pages normally keep. A screen with a
	 *          two-column form and a six-column table wants the room; a
	 *          narrow form stretched down the left of a wide monitor does not.
	 * 'design' => which of the two looks the screen is drawn in. 'new' screens
	 *             draw their own heading; 'classic' ones use Partials::header().
	 *
	 * @return array<string,array<string,mixed>>
	 */
	/**
	 * Every screen in the office, and who may open it.
	 *
	 * Each line is one place in the interface. The order is the order the
	 * sidebar shows them in, which is also roughly the order a day takes:
	 * what needs doing, the homes, the societies, the people, then the
	 * paperwork and the settings.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function pages(): array {
		$listings = 'estat_manage_listings';

		return array(
			'estat-today'         => array(
				'title' => __( 'Today', 'estat-os' ),
				'cap'   => $listings,
				'menu'  => true,
				'class' => Os\Screens\TodayScreen::class,
			),
			'estat-add-home'      => array(
				'title' => __( 'Add a home', 'estat-os' ),
				'cap'   => $listings,
				'menu'  => true,
				'class' => Os\Screens\AddHomeScreen::class,
			),
			'estat-listings'      => array(
				'title' => __( 'Properties', 'estat-os' ),
				'cap'   => $listings,
				'menu'  => true,
				'class' => Os\Screens\PropertiesScreen::class,
			),
			'estat-projects'      => array(
				'title' => __( 'Societies & projects', 'estat-os' ),
				'cap'   => 'estat_manage_projects',
				'menu'  => true,
				'class' => Os\Screens\ProjectsScreen::class,
			),
			'estat-enquiries'     => array(
				'title' => __( 'Enquiries', 'estat-os' ),
				'cap'   => 'estat_manage_leads',
				'menu'  => true,
				'class' => Os\Screens\EnquiriesScreen::class,
			),
			'estat-pipeline'      => array(
				'title' => __( 'Pipeline', 'estat-os' ),
				'cap'   => 'estat_manage_leads',
				'menu'  => true,
				'class' => Os\Screens\PipelineScreen::class,
			),
			'estat-visits'        => array(
				'title' => __( 'Site visits', 'estat-os' ),
				'cap'   => 'estat_manage_visits',
				'menu'  => true,
				'class' => Os\Screens\VisitsScreen::class,
			),
			'estat-team'          => array(
				'title' => __( 'Team', 'estat-os' ),
				'cap'   => 'estat_manage_team',
				'menu'  => true,
				'class' => Os\Screens\TeamScreen::class,
			),
			'estat-requests'      => array(
				'title' => __( 'Change requests', 'estat-os' ),
				'cap'   => 'estat_request_listings',
				'menu'  => true,
				'class' => Os\Screens\RequestsScreen::class,
			),
			'estat-gallery'       => array(
				'title' => __( 'Gallery & media', 'estat-os' ),
				'cap'   => $listings,
				'menu'  => true,
				'class' => Os\Screens\GalleryScreen::class,
			),
			'estat-duplicates'    => array(
				'title' => __( 'Duplicates', 'estat-os' ),
				'cap'   => $listings,
				'menu'  => true,
				'class' => Os\Screens\DuplicatesScreen::class,
			),
			/*
			 * The bin is its own screen, not a filter on the working list.
			 * Bringing something back and ending it for good are different
			 * decisions from anything done to a live property, and mixing the
			 * two lists is how an office loses something it meant to restore.
			 */
			'estat-bin'           => array(
				'title' => __( 'Bin', 'estat-os' ),
				'cap'   => 'estat_bin_listings',
				'menu'  => true,
				'class' => Os\Screens\BinScreen::class,
			),
			'estat-reports'       => array(
				'title' => __( 'Reports', 'estat-os' ),
				'cap'   => 'estat_view_reports',
				'menu'  => true,
				'class' => Os\Screens\ReportsScreen::class,
			),
			'estat-spreadsheet'   => array(
				'title' => __( 'Import & export', 'estat-os' ),
				'cap'   => 'estat_import_inventory',
				'menu'  => true,
				'class' => Os\Screens\ImportScreen::class,
			),
			'estat-forms'         => array(
				'title' => __( 'Website forms', 'estat-os' ),
				'cap'   => 'estat_manage_forms',
				'menu'  => true,
				'class' => Os\Screens\FormsScreen::class,
			),
			'estat-settings'      => array(
				'title' => __( 'Settings', 'estat-os' ),
				'cap'   => 'estat_manage_settings',
				'menu'  => true,
				'class' => Os\Screens\SettingsScreen::class,
			),
			'estat-templates'     => array(
				'title' => __( 'Page blocks', 'estat-os' ),
				'cap'   => 'estat_manage_settings',
				'menu'  => false,
				'class' => Os\Screens\SettingsScreen::class,
			),
			'estat-design-tokens' => array(
				'title' => __( 'Design tokens', 'estat-os' ),
				'cap'   => 'estat_manage_settings',
				'menu'  => false,
				'class' => Os\Screens\SettingsScreen::class,
			),
			'estat-search-alerts' => array(
				'title' => __( 'Search alerts', 'estat-os' ),
				'cap'   => 'estat_manage_leads',
				'menu'  => false,
				'class' => Os\Screens\AlertsScreen::class,
			),
			// Shown in the sidebar only until setup has been finished once.
			Os\Screens\SetupScreen::SLUG => array(
				'title' => __( 'Finish setup', 'estat-os' ),
				'cap'   => 'estat_manage_settings',
				'menu'  => Os\Screens\SetupScreen::needed(),
				'class' => Os\Screens\SetupScreen::class,
			),
		);
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'Office', 'estat-os' ),
			__( 'Office', 'estat-os' ),
			'estat_manage_listings',
			self::MENU,
			array( $this, 'route' ),
			'dashicons-building',
			3
		);

		/*
		 * One menu, and it is WordPress's own.
		 *
		 * The office used to draw a sidebar of its own and push the
		 * WordPress menu out of the way. That made the plugin feel like a
		 * separate program bolted onto the site. From here on every module
		 * is an ordinary line in the WordPress menu, so the left side of
		 * the screen belongs to WordPress and everything to its right is
		 * ours.
		 */
		foreach ( self::pages() as $slug => $page ) {
			add_submenu_page(
				empty( $page['menu'] ) ? '' : ( $page['parent'] ?? self::MENU ),
				$page['title'],
				$page['title'],
				$page['cap'],
				$slug,
				array( $this, 'route' )
			);
		}

		/*
		 * A page registered with no parent gets no title of its own: WordPress
		 * looks for it in the menus, does not find it, and leaves the document
		 * title empty — "‹ Site — WordPress", a blank heading, and a PHP
		 * deprecation on every load of Page blocks, Design tokens and Search
		 * alerts. The screen's own title rides along on the page hook.
		 */
		foreach ( self::pages() as $slug => $page ) {
			add_action(
				'load-' . get_plugin_page_hook( $slug, self::MENU ),
				static function () use ( $page ): void {
					$GLOBALS['title'] = (string) $page['title'];
				}
			);
		}

		/*
		 * How much is in each list, on the line that opens it.
		 *
		 * "Properties 128" and "Bin 7" answer the two questions the sidebar
		 * is asked all day — how much have we got, and has anything gone
		 * missing — without opening a screen. The numbers are permission
		 * aware: an agent sees what they may see, and a bin with nothing in
		 * it says 0 rather than nothing at all.
		 */
		if ( ! empty( $submenu[ self::MENU ] ) && is_array( $submenu[ self::MENU ] ) ) {
			$items = $submenu[ self::MENU ];

			/*
			 * Every count comes from one cached read, so adding these to the
			 * menu costs one transient and not a query per line.
			 */
			$counts = \EstatOS\Admin\Os\Shell::counts();

			$shown = array(
				'estat-listings'  => current_user_can( 'estat_manage_listings' ) ? (int) ( $counts['listings'] ?? 0 ) : null,
				'estat-projects'  => current_user_can( 'estat_manage_projects' ) ? (int) ( $counts['projects'] ?? 0 ) : null,
				'estat-enquiries' => current_user_can( 'estat_manage_leads' ) ? (int) ( $counts['enquiries'] ?? 0 ) : null,
				'estat-visits'    => current_user_can( 'estat_manage_visits' ) ? (int) ( $counts['visits'] ?? 0 ) : null,
				'estat-requests'  => current_user_can( 'estat_request_listings' ) ? (int) ( $counts['requests'] ?? 0 ) : null,
				'estat-duplicates' => current_user_can( 'estat_manage_listings' ) ? (int) ( $counts['duplicates'] ?? 0 ) : null,
				'estat-team'      => current_user_can( 'estat_manage_team' ) ? (int) ( $counts['team'] ?? 0 ) : null,
				'estat-bin'       => current_user_can( 'estat_bin_listings' ) ? (int) ( $counts['bin'] ?? 0 ) : null,
			);

			$words = array(
				'estat-listings'   => __( 'Properties', 'estat-os' ),
				'estat-projects'   => __( 'Societies & projects', 'estat-os' ),
				'estat-enquiries'  => __( 'Enquiries', 'estat-os' ),
				'estat-visits'     => __( 'Site visits', 'estat-os' ),
				'estat-requests'   => __( 'Change requests', 'estat-os' ),
				'estat-duplicates' => __( 'Duplicates', 'estat-os' ),
				'estat-team'       => __( 'Team', 'estat-os' ),
				'estat-bin'        => __( 'Bin', 'estat-os' ),
			);

			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) || empty( $item[2] ) ) {
					continue;
				}
				$slug = (string) $item[2];
				if ( ! array_key_exists( $slug, $shown ) || null === $shown[ $slug ] ) {
					continue;
				}

				$items[ $index ][0] = sprintf(
					'%1$s <span class="estat-menu-count%3$s">%2$s</span>',
					esc_html( $words[ $slug ] ),
					esc_html( number_format_i18n( $shown[ $slug ] ) ),
					0 === $shown[ $slug ] ? ' is-empty' : ''
				);
			}

			$submenu[ self::MENU ] = array_values( $items );
		}

		// WordPress puts its own copy of the parent item first in the submenu,
		// using the menu title ("Office") for it. That copy is the duplicate we
		// do not want — but on WordPress 6.5+ that copy is sometimes missing, so
		// removing whatever sits at position 0 would delete the real "Today"
		// entry and the screen would vanish from the sidebar (it did).
		// So: keep exactly one entry that points at this menu's own page, and
		// make sure it is the one titled "Today", sitting at the top.
		if ( ! empty( $submenu[ self::MENU ] ) && is_array( $submenu[ self::MENU ] ) ) {
			$items = $submenu[ self::MENU ];
			$keep  = null;

			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) || self::MENU !== ( $item[2] ?? '' ) ) {
					continue;
				}
				if ( null === $keep ) {
					$keep = $item; // Pehli hi asli "Today" hai — use rakho.
				}
				unset( $items[ $index ] );
			}

			if ( null !== $keep ) {
				// Hamesha ek hi entry, sabse upar, aur uska naam "Today".
				$keep[0] = __( 'Today', 'estat-os' );
				array_unshift( $items, $keep );
				$submenu[ self::MENU ] = array_values( $items );
			}
		}
	}

	/**
	 * Draw whatever the address asked for.
	 *
	 * Every screen in the office now draws its own frame, its own heading
	 * and its own buttons, so there is nothing here to add around it apart
	 * from the notices WordPress wants to show.
	 */
	/**
	 * The answer to whatever was just pressed.
	 *
	 * Every save and every refusal in the office ends in
	 * `redirect( $url, 'saved'|'published'|'error', $detail )`, and the words
	 * travel in the address as `estat_notice` and `estat_detail`. Nothing ever
	 * read them: the only notices this screen prints come from
	 * `get_settings_errors( 'estat_notices' )`, and no code in the plugin ever
	 * calls `add_settings_error()` for that group. So the block below has
	 * always been empty.
	 *
	 * What that looked like from the office: press Save, the page comes back,
	 * and nothing is said. A property that saved and a property refused with
	 * "give this property a short headline first" were the same screen — no
	 * message, no colour, no difference at all. Sixty-three of those messages
	 * were written and thrown away.
	 *
	 * @return void
	 */
	private static function flash_notice(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- a message from the last page, not data.
		$notice = isset( $_GET['estat_notice'] ) && is_scalar( $_GET['estat_notice'] )
			? sanitize_key( wp_unslash( (string) $_GET['estat_notice'] ) )
			: '';
		$detail = isset( $_GET['estat_detail'] ) && is_scalar( $_GET['estat_detail'] )
			? sanitize_text_field( rawurldecode( wp_unslash( (string) $_GET['estat_detail'] ) ) )
			: '';
		// phpcs:enable
		if ( '' === $notice ) {
			return;
		}

		$words = array(
			'saved'     => __( 'Saved.', 'estat-os' ),
			'published' => __( 'Published — it is on the website now.', 'estat-os' ),
			'draft'     => __( 'Kept as a draft. Nothing is on the website yet.', 'estat-os' ),
			'deleted'   => __( 'Removed.', 'estat-os' ),
			'restored'  => __( 'Put back.', 'estat-os' ),
			'imported'  => __( 'Brought in.', 'estat-os' ),
			'forbidden' => __( 'You do not have permission to do that.', 'estat-os' ),
			'error'     => __( 'That did not work.', 'estat-os' ),
		);

		$bad   = in_array( $notice, array( 'error', 'forbidden' ), true );
		$words_used = (string) ( $words[ $notice ] ?? ucfirst( str_replace( '_', ' ', $notice ) ) );
		$text  = '' !== $detail ? trim( $words_used . ' ' . $detail ) : $words_used;

		printf(
			'<div class="estat-os-notices"><div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div></div>',
			esc_attr( $bad ? 'error' : 'success' ),
			esc_html( $text )
		);
	}

	public function route(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$requested = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array( $_GET['page'] ) ? '' : $_GET['page'] ) ) : self::MENU;

		$pages = self::pages();
		$page  = $requested;
		$entry = $pages[ $page ] ?? null;

		if ( null === $entry || ! class_exists( $entry['class'] ) ) {
			$page  = self::MENU;
			$entry = $pages[ self::MENU ];
		}

		if ( ! current_user_can( $entry['cap'] ) ) {
			wp_die( esc_html__( 'You do not have permission to open this page.', 'estat-os' ) );
		}

		echo '<div class="estat-os-page">';

		self::flash_notice();

		// Anything WordPress or the plugin wants to say while saving.
		$notices = get_settings_errors( 'estat_notices' );
		if ( $notices ) {
			echo '<div class="estat-os-notices">';
			foreach ( $notices as $notice ) {
				printf(
					'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
					esc_attr( 'updated' === $notice['type'] ? 'success' : (string) $notice['type'] ),
					esc_html( (string) $notice['message'] )
				);
			}
			echo '</div>';
		}

		$handler = array( $entry['class'], 'render' );
		if ( is_callable( $handler ) ) {
			call_user_func( $handler );
		}

		echo '</div>';
	}

	/**
	 * Load the interface.
	 *
	 * One stylesheet and one script for the whole office, both scoped to
	 * our own pages so nothing else in wp-admin is disturbed.
	 */
	public function assets( string $hook ): void {
		if ( false === strpos( $hook, 'estat-' )
			&& 'toplevel_page_' . self::MENU !== $hook
			&& 'toplevel_page_' . self::SETTINGS_MENU !== $hook ) {
			return;
		}

		wp_enqueue_style( 'estat-tokens', ESTAT_URL . 'assets/css/tokens.css', array(), ESTAT_VERSION );
		wp_enqueue_style( 'estat-os', ESTAT_URL . 'assets/css/admin-os.css', array( 'estat-tokens' ), ESTAT_VERSION );

		wp_enqueue_script( 'estat-os', ESTAT_URL . 'assets/js/admin-os.js', array(), ESTAT_VERSION, true );
		wp_localize_script(
			'estat-os',
			'estatOs',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				'page'  => isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array( $_GET['page'] ) ? '' : $_GET['page'] ) ) : self::MENU,
				'home'  => admin_url( 'admin.php?page=' . self::MENU ),
				// The menus the interface draws for itself: the rail, the
				// quick-add button, the bell and the command palette.
				'modules' => Os\Shell::modules(),
				'quick'   => Os\Shell::quick_add(),
				'notes'   => Os\Shell::notifications(),
				'palette' => Os\Shell::palette(),
				'i18n'  => array(
					'saved'        => __( 'Saved', 'estat-os' ),
					'deleted'      => __( 'Removed', 'estat-os' ),
					'moved'        => __( 'Moved', 'estat-os' ),
					'restored'     => __( 'Put back', 'estat-os' ),
					'approved'     => __( 'Approved', 'estat-os' ),
					'declined'     => __( 'Declined', 'estat-os' ),
					'copied'       => __( 'Copied', 'estat-os' ),
					'undo'         => __( 'Undo', 'estat-os' ),
					'working'      => __( 'Working…', 'estat-os' ),
					'failed'       => __( 'That did not work. Try again.', 'estat-os' ),
					'loading'      => __( 'Loading…', 'estat-os' ),
					'noResults'    => __( 'Nothing matched', 'estat-os' ),
					'selected'     => __( 'selected', 'estat-os' ),
					'uploading'    => __( 'Sending…', 'estat-os' ),
					'uploaded'     => __( 'Added', 'estat-os' ),
					'confirm'      => __( 'Are you sure?', 'estat-os' ),
					// Asked for by admin-os.js; missing here, so the screen
					// quietly fell back to English on every other language.
					'need_title'   => __( 'Give the society or project a name first.', 'estat-os' ),
					// The heading the palette puts over the records it
					// found: properties, people and enquiries live in one
					// list, so they need one word that covers them.
					'records'      => __( 'Properties, people and enquiries', 'estat-os' ),
				),
			)
		);

		wp_enqueue_media();
	}

	public static function ajax_move_pipeline(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$lead_id = isset( $_POST['lead_id'] ) ? absint( wp_unslash( is_array($_POST['lead_id']) ? '' : $_POST['lead_id'] ) ) : 0;
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( is_array($_POST['status']) ? '' : $_POST['status'] ) ) : '';
		$allowed = \EstatOS\Support\Vocabulary::lead_pipeline_order();
		if ( ! in_array( $status, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid status', 'estat-os' ) ), 400 );
		}
		$result = \EstatOS\Leads\Leads::update( $lead_id, array( 'status' => $status ) );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 422 );
		}
		wp_send_json_success( array( 'lead_id' => $lead_id, 'status' => $status ) );
	}

	public static function ajax_test_mail(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$email = Settings::notification_email();
		$sent = wp_mail( $email, __( 'Test email from your property website', 'estat-os' ), __( 'If you got this, your email settings are working.', 'estat-os' ) );
		if ( $sent ) {
			Settings::update( array( 'test_mail_last_sent' => current_time( 'mysql' ) ) );
			wp_send_json_success( array( 'message' => sprintf( __( 'Test email sent to %s', 'estat-os' ), $email ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Could not send email. Check your hosting mail setup.', 'estat-os' ) ), 500 );
		}
	}

	public static function ajax_test_webhook(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$res = \EstatOS\Webhooks\Webhooks::test();
		if ( ( $res['ok'] ?? false ) ) {
			wp_send_json_success( array( 'message' => sprintf( __( 'Test message sent. The other program answered %1$d at %2$s.', 'estat-os' ), (int) $res['code'], $res['url'] ?? '' ), 'code' => $res['code'] ?? 0, 'url' => $res['url'] ?? '' ) );
		} else {
			wp_send_json_error( array( 'message' => sprintf( __( 'The test did not go through: %s', 'estat-os' ), $res['error'] ?? __( 'no reply', 'estat-os' ) ), 'code' => $res['code'] ?? 0 ), 500 );
		}
	}

	public function body_class( string $classes ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 0 === strpos( $page, 'estat-' ) ) {
			$classes .= ' estat-screen estat-os-screen';
			$theme = (string) Settings::get( 'admin_theme' );
			if ( ! in_array( $theme, array( 'light', 'dark', 'auto' ), true ) ) { $theme = 'light'; }
			$classes .= ' estat-theme-' . $theme . ' estat-new-ui';
			if ( Settings::get( 'practice_mode' ) ) { $classes .= ' estat-practice'; }
		}
		return $classes;
	}

	public function hide_clutter(): void {
		if ( current_user_can( 'manage_options' ) ) { return; }
		remove_submenu_page( 'edit.php?post_type=' . PostTypes::LISTING, 'edit-tags.php?taxonomy=' . Taxonomies::FEATURE . '&post_type=' . PostTypes::LISTING );
	}
}
