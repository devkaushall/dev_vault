<?php
/**
 * Handles every form submission and action link in the office screens.
 *
 * One entry point, one nonce per action, one capability check per action,
 * and always a redirect afterwards so a refresh never repeats the work.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin;

use EstatOS\Audit\AuditLog;
use EstatOS\Csv\Spreadsheet;
use EstatOS\Cron\Scheduler;
use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Field\Requests;
use EstatOS\Forms\Forms;
use EstatOS\Forms\Templates;
use EstatOS\Admin\Os\Screens\SetupScreen;
use EstatOS\Install\Pages;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;
use EstatOS\Support\PracticeMode;
use EstatOS\Support\Sanitize;
use WP_Error;
use EstatOS\Data\Bin;
use EstatOS\Data\Duplicate;
use EstatOS\Data\Undo;

defined( 'ABSPATH' ) || exit;

/**
 * Admin action router.
 */
final class Actions {

	/**
	 * Which capability each action needs.
	 *
	 * @var array<string,string>
	 */
	/**
	 * The most records one bulk action may touch.
	 */
	public const BULK_LIMIT = 100;

	private const CAPS = array(
		'add_home'         => 'estat_manage_listings',
		'delete_file'      => 'estat_delete_listings',
		'save_listing'     => 'estat_manage_listings',
		'bin_records'      => 'estat_manage_listings',   // per-record permission is decided inside, by Bin.
		'sweep_records'    => 'estat_bin_listings',    // one press over a whole set; each record is still checked inside Bin.
		'restore_records'  => 'estat_manage_listings',
		'delete_forever'   => 'estat_delete_listings',
		'empty_bin'        => 'estat_empty_bin',
		'undo_bin'         => 'estat_bin_listings',
		'propose_listing'    => 'estat_request_listings',
		'approve_request'  => 'estat_review_listings',
		'decline_request'  => 'estat_review_listings',
		// The real permission depends on what kind of record it is, so these
		// three are checked again, per kind, inside record_target().
		// Bulk acts on many records at once; each one is checked individually
		// against its own kind inside bulk_records().
		'bulk_records'     => 'read',
		// Undo is an edit, so it is checked per kind like the others.
		'undo_record'      => 'read',
		'trash_record'     => 'read',
		'restore_record'   => 'read',
		'delete_record'    => 'read',
		'update_lead'      => 'estat_manage_leads',
		'schedule_visit'   => 'estat_manage_visits',
		'update_visit'     => 'estat_manage_visits',
		'erase_lead'       => 'estat_erase_leads',
		'save_project'     => 'estat_manage_projects',
		'save_agent'       => 'estat_manage_team',
		'create_form'      => 'estat_manage_forms',
		'save_form'        => 'estat_manage_forms',
		'duplicate_form'   => 'estat_manage_forms',
		'delete_form'      => 'estat_manage_forms',
		'import_csv'       => 'estat_import_inventory',
		'export_csv'       => 'estat_export_inventory',
		'sample_csv'       => 'estat_import_inventory',
		'save_settings'    => 'estat_manage_settings',
		'run_setup'        => 'estat_manage_settings',
		'skip_setup'       => 'estat_manage_settings',
		'rebuild_index'    => 'estat_run_maintenance',
		'repair_tables'    => 'estat_run_maintenance',
		'clear_cache'      => 'estat_run_maintenance',
		'purge_caches'     => 'estat_run_maintenance',
		'tidy_public_pages' => 'estat_run_maintenance',
		'run_housekeeping' => 'estat_run_maintenance',
		'seed_practice'    => 'estat_run_maintenance',
		'clear_practice'   => 'estat_run_maintenance',
		'repair_broken_data' => 'estat_run_maintenance',
		// Later additions.
		'save_tokens'      => 'estat_manage_settings',
		'save_templates'   => 'estat_manage_settings',
		'toggle_filters'   => 'estat_manage_settings',
		'test_mail'        => 'estat_manage_settings',
		'clear_alerts'     => 'estat_manage_leads',
		'health_csv'       => 'estat_manage_listings',
		'merge_terms'      => 'estat_manage_listings',
		'download_ics'     => 'estat_manage_visits',
		'export_leads_csv' => 'estat_export_inventory',
		'preview_csv'      => 'estat_import_inventory',
		'switch_kind'      => 'estat_import_inventory',
		'confirm_import'   => 'estat_import_inventory',
		'undo_import'      => 'estat_import_inventory',
		'export_preview'   => 'estat_export_inventory',
		// F2 Approvals + Verified.
		'listing_approve'  => 'estat_publish_listings',
		'listing_decline'  => 'estat_publish_listings',
		'verify_listing'   => 'estat_verify_listings',
		// F12 public pages without Elementor.
		'create_public_pages' => 'estat_manage_settings',
	);

	/**
	 * Module bootstrap. Registration happens in Admin.
	 *
	 * @return void
	 */
	public function register(): void {}

	/**
	 * Route one request.
	 *
	 * @return void
	 */
	public static function handle(): void {
		$action = self::requested_action();
		if ( '' === $action || ! isset( self::CAPS[ $action ] ) ) {
			return;
		}
		if ( ! current_user_can( self::CAPS[ $action ] ) ) {
			self::redirect( self::back(), 'forbidden' );
		}

		switch ( $action ) {
			case 'delete_file':
				self::delete_file();
				break;

			case 'run_setup':
				self::run_setup();
				break;
			case 'skip_setup':
				self::skip_setup();
				break;

			case 'undo_record':
				self::undo_record();
				break;
			case 'bulk_records':
				self::bulk_records();
				break;
			case 'bin_records':
				self::bin_records();
				break;
			case 'sweep_records':
				self::sweep_records();
				break;
			case 'restore_records':
				self::restore_records();
				break;
			case 'delete_forever':
				self::delete_forever();
				break;
			case 'empty_bin':
				self::empty_bin();
				break;
			case 'undo_bin':
				self::undo_bin();
				break;
			case 'trash_record':
				self::trash_record();
				break;
			case 'restore_record':
				self::restore_record();
				break;
			case 'delete_record':
				self::delete_record();
				break;

			case 'add_home':
				self::add_home();
				break;
			case 'save_listing':
				self::save_listing();
				break;
			case 'update_lead':
				self::update_lead();
				break;
			case 'schedule_visit':
				self::schedule_visit();
				break;
			case 'update_visit':
				self::update_visit();
				break;
			case 'erase_lead':
				self::erase_lead();
				break;
			case 'save_project':
				self::save_project();
				break;
			case 'save_agent':
				self::save_agent();
				break;

			/*
			 * Each of these has a method of its own further down this file.
			 * All four used to be routed to save_agent(), which verified a
			 * team-member nonce against a duplicates-screen press: the real
			 * handlers below were unreachable, and anyone who posted one of
			 * these actions was sent to the "that link has expired" page.
			 */
			case 'duplicate_keep':
				self::duplicate_keep();
				break;
			case 'duplicate_bin':
				self::duplicate_bin();
				break;
			case 'duplicate_rescan':
				self::duplicate_rescan();
				break;
			case 'duplicate_scan':
				self::duplicate_scan();
				break;
			case 'create_form':
			case 'save_form':
			case 'duplicate_form':
			case 'delete_form':
				self::form_action( $action );
				break;
			case 'import_csv':
				self::import_csv();
				break;
			case 'preview_csv':
				self::preview_csv();
				break;
			case 'switch_kind':
				self::switch_kind();
				break;
			case 'confirm_import':
				self::confirm_import();
				break;
			case 'undo_import':
				self::undo_import();
				break;
			case 'export_csv':
				self::export_csv();
				break;
			case 'export_preview':
				self::export_preview();
				break;
			case 'export_leads_csv':
				self::export_leads_csv();
				break;
			case 'download_ics':
				self::download_ics();
				break;
			case 'sample_csv':
				self::sample_csv();
				break;
			case 'health_csv':
				self::health_csv();
				break;
			case 'merge_terms':
				self::merge_terms();
				break;
			case 'save_settings':
				self::save_settings();
				break;
			case 'propose_listing':
				self::propose_listing();
				break;
			case 'approve_request':
				self::settle_request( 'approve' );
				break;
			case 'decline_request':
				self::settle_request( 'decline' );
				break;
			case 'listing_approve':
				self::settle_listing( 'publish' );
				break;
			case 'listing_decline':
				self::settle_listing( 'draft' );
				break;
			case 'verify_listing':
				self::verify_listing();
				break;
			default:
				self::tool( $action );
		}
	}

	/* --------------------------------------------------------------------- *
	 * Changes proposed from the field
	 * --------------------------------------------------------------------- */

	/**
	 * An agent asks the office to change somebody else's property.
	 *
	 * The agent's own records go through save_listing() and are edited
	 * directly; this is only the route for a record they cannot touch. Which
	 * of the two applies is decided by Requests::may_edit_directly(), so the
	 * screen and this handler cannot disagree.
	 *
	 * @return void
	 */
	private static function propose_listing(): void {
		$record_id = self::int_post( 'listing_id' );
		self::verify( 'estat_propose_request_' . $record_id );

		// Gone between opening the page and pressing the button.
		if ( ! get_post( $record_id ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'error', __( 'That property could not be found. It may already have been removed.', 'estat-os' ) );
		}

		if ( Requests::may_edit_directly( $record_id ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings&edit=' . $record_id ), 'error', __( 'You can change that property yourself, so there is nothing to ask for.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		// The office side of a change request: each box arrives under its own
		// name (changes[price], changes[bedrooms]…), so this is a list by
		// design. It used to be flattened to an empty string, which made every
		// change request arrive with nothing written in it.
		$changes = isset( $_POST['changes'] ) && is_array( $_POST['changes'] ) ? (array) wp_unslash( $_POST['changes'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Requests::clean_changes() saaf karta hai.
		$message = isset( $_POST['message'] ) ? Sanitize::textarea( wp_unslash( is_array($_POST['message']) ? '' : $_POST['message'] ) ) : '';
		// phpcs:enable

		if ( '' === $message ) {
			self::redirect(
				admin_url( 'admin.php?page=estat-listings&edit=' . $record_id ),
				'error',
				__( 'Add one line about how you know, so the office can decide without calling you.', 'estat-os' )
			);
		}

		// The note is a message to the office, not a field on the record.
		$changes['note'] = $message;

		$result = Requests::create(
			array(
				'record_id' => $record_id,
				'changes'   => $changes,
				'message'   => $message,
			)
		);

		if ( is_wp_error( $result ) ) {
			self::redirect(
				admin_url( 'admin.php?page=estat-listings&edit=' . $record_id ),
				'error',
				self::first_message( $result )
			);
		}

		self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'requested' );
	}

	/**
	 * Settle one request: apply it, or turn it down with a word of explanation.
	 *
	 * Approval writes through Listings::save(), so validation, the search
	 * index, the audit trail and the undo snapshot all behave exactly as if the
	 * office had typed the change in themselves.
	 *
	 * @param string $verb 'approve' or 'decline', naming both the action and
	 *                     the nonce the screen printed. One word, so the two
	 *                     can never drift apart.
	 * @return void
	 */
	private static function settle_request( string $verb ): void {
		$request_id = self::int_post( 'request_id' );
		self::verify( 'estat_' . $verb . '_request_' . $request_id );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason = isset( $_POST['reason'] ) ? Sanitize::textarea( wp_unslash( is_array($_POST['reason']) ? '' : $_POST['reason'] ) ) : '';
		// phpcs:enable

		$result = 'approve' === $verb
			? Requests::approve( $request_id )
			: Requests::decline( $request_id, $reason );

		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-requests' ), 'error', self::first_message( $result ) );
		}

		self::redirect( admin_url( 'admin.php?page=estat-requests' ), 'request_' . ( 'approve' === $verb ? 'approved' : 'declined' ) );
	}

	/**
	 * F2: Approve/decline a pending listing (office approve before live).
	 *
	 * @param string $target_status publish|draft.
	 * @return void
	 */
	private static function settle_listing( string $target_status ): void {
		$listing_id = self::int_post( 'listing_id' );
		self::verify( 'estat_' . ( 'publish' === $target_status ? 'approve' : 'decline' ) . '_listing_' . $listing_id );
		$post = get_post( $listing_id );
		if ( ! $post || \EstatOS\Data\PostTypes::LISTING !== $post->post_type ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'error', __( 'That property could not be found.', 'estat-os' ) );
		}
		if ( 'pending' !== $post->post_status && 'draft' !== $post->post_status ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'error', __( 'That listing is not waiting for approval.', 'estat-os' ) );
		}
		$result = wp_update_post( array( 'ID' => $listing_id, 'post_status' => $target_status ), true );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-add-home&edit=' . $listing_id ), 'error', self::first_message( $result ) );
		}
		if ( 'publish' === $target_status ) {
			// F2: approve → auto verified "humne khud dekha"
			update_post_meta( $listing_id, '_estat_verification', 'office_verified' );
			if ( class_exists( \EstatOS\Search\SearchIndex::class ) ) {
				\EstatOS\Search\SearchIndex::index_listing( $listing_id );
			}
			do_action( 'estat_listing_verified', $listing_id );
		}
		AuditLog::record( 'publish' === $target_status ? 'listing.approved' : 'listing.declined', 'listing', $listing_id, array( 'by' => get_current_user_id() ) );
		self::redirect( admin_url( 'admin.php?page=estat-requests' ), 'publish' === $target_status ? 'published' : 'saved' );
	}

	/**
	 * F2: Mark listing as office verified — "humne khud dekha" tick.
	 *
	 * @return void
	 */
	private static function verify_listing(): void {
		$listing_id = self::int_post( 'listing_id' );
		self::verify( 'estat_verify_listing_' . $listing_id );
		$post = get_post( $listing_id );
		if ( ! $post ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'error', __( 'That property could not be found.', 'estat-os' ) );
		}
		// Only office can verify, cap already checked, but double.
		if ( ! current_user_can( 'estat_verify_listings' ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings' ), 'forbidden' );
		}
		$mode = isset( $_POST['verification'] ) ? sanitize_key( wp_unslash( is_array($_POST['verification']) ? '' : $_POST['verification'] ) ) : 'office_verified'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$allowed = array_keys( \EstatOS\Support\Vocabulary::verification() );
		if ( ! in_array( $mode, $allowed, true ) ) {
			$mode = 'office_verified';
		}
		update_post_meta( $listing_id, '_estat_verification', $mode );
		// Re-index.
		if ( class_exists( \EstatOS\Search\SearchIndex::class ) ) {
			\EstatOS\Search\SearchIndex::index_listing( $listing_id );
		}
		AuditLog::record( 'listing.verified', 'listing', $listing_id, array( 'verification' => $mode, 'by' => get_current_user_id() ) );
		do_action( 'estat_listing_verified', $listing_id );
		self::redirect( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ), 'saved', __( 'Verified — humne khud dekha tick added.', 'estat-os' ) );
	}

	/* --------------------------------------------------------------------- *
	 * Listings
	 * --------------------------------------------------------------------- */

	/**
	 * The nine-question quick add.
	 *
	 * @return void
	 */
	private static function delete_file(): void {
		$file_id = isset( $_GET['file_id'] ) ? absint( wp_unslash( is_array($_GET['file_id']) ? '' : $_GET['file_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::verify( 'estat_delete_file_' . $file_id, 'GET' );

		$back = admin_url( 'admin.php?page=estat-gallery' );

		// Only ever remove a media file, never a property or any other record.
		if ( $file_id <= 0 || 'attachment' !== get_post_type( $file_id ) ) {
			self::redirect( $back, 'error', __( 'That file could not be found.', 'estat-os' ) );
		}

		$title = get_the_title( $file_id );

		if ( ! wp_delete_attachment( $file_id, true ) ) {
			self::redirect( $back, 'error', __( 'The file could not be removed. Please try again.', 'estat-os' ) );
		}

		AuditLog::record( 'media.deleted', 'attachment', $file_id, array( 'title' => $title ) );

		self::redirect( $back, 'deleted' );
	}

	/**
	 * First-run setup: save the few answers, then build the office's pages.
	 *
	 * @return void
	 */
	private static function run_setup(): void {
		self::verify( 'estat_run_setup' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cities = isset( $_POST['cities'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['cities']) ? '' : $_POST['cities'] ) ) ) : '';
		$values = array(
			'office_name'       => isset( $_POST['office_name'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['office_name']) ? '' : $_POST['office_name'] ) ) ) : '',
			'phone'             => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['phone']) ? '' : $_POST['phone'] ) ) ) : '',
			'email'             => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( (string) ( is_array($_POST['email']) ? '' : $_POST['email'] ) ) ) : '',
			'currency_symbol'   => isset( $_POST['currency_symbol'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['currency_symbol']) ? '' : $_POST['currency_symbol'] ) ) ) : '',
			'default_area_unit' => isset( $_POST['default_area_unit'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['default_area_unit']) ? '' : $_POST['default_area_unit'] ) ) ) : 'sqft',
			'setup_done'        => true,
		);
		if ( '' !== $cities ) {
			$values['cities'] = array_values( array_filter( array_map( 'trim', explode( ',', $cities ) ) ) );
		}

		// The chosen pages arrive as a group (pages[] = homes), so this is an
		// array by design — and each name is made safe one by one below.
		$wanted = isset( $_POST['pages'] ) && is_array( $_POST['pages'] )
			? array_map( 'sanitize_key', array_map( 'strval', wp_unslash( $_POST['pages'] ) ) )
			: array();
		$style  = isset( $_POST['page_style'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['page_style']) ? '' : $_POST['page_style'] ) ) ) : 'ready';
		// phpcs:enable

		$office = trim( (string) $values['office_name'] );
		if ( '' === $office ) {
			self::redirect(
				admin_url( 'admin.php?page=' . SetupScreen::SLUG ),
				'error',
				__( 'Please tell us your office name so we can put it on your website.', 'estat-os' )
			);
		}

		Settings::update( $values );

		$built = array();
		if ( array() !== $wanted ) {
			$built = Pages::create( $wanted, 'blank' !== $style );
		}

		AuditLog::record(
			'office.setup',
			'settings',
			0,
			array(
				'pages' => array_keys( $built ),
				'style' => $style,
			)
		);

		self::redirect( admin_url( 'admin.php?page=' . SetupScreen::SLUG ), 'setup_done' );
	}

	/**
	 * The office would rather set things up themselves.
	 *
	 * @return void
	 */
	private static function skip_setup(): void {
		self::verify( 'estat_skip_setup', 'GET' );
		Settings::update( array( 'setup_done' => true ) );
		self::redirect( admin_url( 'admin.php?page=estat-today' ), 'saved' );
	}

	/**
	 * Which capability lets someone remove a given kind of record, and where
	 * the screen for that kind lives.
	 *
	 * Removing something is treated as part of managing it, except for
	 * properties, which keep their own stricter "delete listings" permission.
	 *
	 * @return array<string,array{cap:string,page:string,label:string}>
	 */
	private static function record_kinds(): array {
		return array(
			PostTypes::LISTING  => array(
				'cap'   => 'estat_delete_listings',
				'page'  => 'estat-listings',
				'label' => __( 'property', 'estat-os' ),
			),
			PostTypes::PROJECT  => array(
				'cap'   => 'estat_manage_projects',
				'page'  => 'estat-projects',
				'label' => __( 'society or project', 'estat-os' ),
			),
			PostTypes::AGENT    => array(
				'cap'   => 'estat_manage_team',
				'page'  => 'estat-team',
				'label' => __( 'team member', 'estat-os' ),
			),
			PostTypes::AGENCY   => array(
				'cap'   => 'estat_manage_team',
				'page'  => 'estat-team',
				'label' => __( 'agency', 'estat-os' ),
			),
		);
	}

	/**
	 * Put a record back to how it was before the last save.
	 *
	 * Deleting has always been recoverable; editing was not. Change a price by
	 * a digit and the old one was gone.
	 *
	 * @return void
	 */
	private static function undo_record(): void {
		$target = self::record_target( 'estat_undo_record_' );

		if ( ! Undo::available( $target['id'] ) ) {
			self::redirect( $target['back'], 'error', __( 'There is nothing to undo on this one.', 'estat-os' ) );
		}

		if ( ! Undo::restore( $target['id'] ) ) {
			self::redirect( $target['back'], 'error', __( 'That could not be undone. Nothing was changed.', 'estat-os' ) );
		}

		AuditLog::record(
			'record.undone',
			$target['post']->post_type,
			$target['id'],
			array( 'title' => $target['post']->post_title )
		);

		self::redirect( $target['back'], 'undone' );
	}

	/* ---------------------------------------------------------------------
	 * The bin: move, restore, delete permanently, empty, undo
	 *
	 * One server-side pass per press. The browser never sends one request per
	 * record: an office that has ticked forty properties deserves one honest
	 * answer ("45 moved · 3 failed"), not forty chances to time out halfway
	 * and leave nobody sure what happened.
	 * ------------------------------------------------------------------ */

	/**
	 * Move records to the bin — one, or a sweep.
	 *
	 * The single-record form arrives with a record_id (the button on a row);
	 * a sweep arrives with record_ids[] (the toolbar). Both come through
	 * here, so there is exactly one place where "moving to the bin" is
	 * decided, audited and answered for.
	 *
	 * @return void
	 */
	private static function bin_records(): void {
		// Two buttons reach this: the row's own, and the bar that acts on
		// everything ticked. The bar carries the list's key, the row its
		// own — both are made by this plugin, for this person, this session.
		self::verify_any( array( 'estat_bin_records', 'estat_bulk_records' ) );

		$back = self::safe_back();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
		$why = isset( $_POST['bin_reason'] ) && ! is_array( $_POST['bin_reason'] )
			? Sanitize::textarea( wp_unslash( (string) $_POST['bin_reason'] ) )
			: '';

		$ids   = self::picked_ids();
		$wrong = self::ids_problem( $ids, __( 'Nothing was chosen, so nothing was moved.', 'estat-os' ) );
		if ( '' !== $wrong ) {
			self::redirect( $back, 'error', $wrong );
		}

		$result = Bin::batch( 'move', $ids, $why );

		if ( ! $result['done'] ) {
			self::redirect( $back, 'error', self::bin_answer( $result, __( 'moved to the bin', 'estat-os' ) ) );
		}

		$token = Bin::remember_undo( $result['done'] );

		$message = self::bin_answer( $result, __( 'moved to the bin', 'estat-os' ) );
		if ( '' !== $token ) {
			$message .= ' ' . __( 'Mistake? Press Undo and they come straight back.', 'estat-os' );
		}

		self::redirect( $back, 'binned', $message, $token );
	}

	/**
	 * One press that clears a whole set, however many that is.
	 *
	 * Ticking rows is right when the office is choosing. It is the wrong
	 * job when two hundred and thirty properties arrived by mistake and
	 * every one of them has to go: the list shows twenty at a time and the
	 * bar stops at a hundred, so clearing the set meant walking through it
	 * page by page. This press names the set instead of the rows — the
	 * drafts, or everything one spreadsheet brought in — and moves all of
	 * it at once.
	 *
	 * Nothing here destroys anything. Every record goes to the bin, in one
	 * batch, and the answer comes back with an Undo that puts all of them
	 * back where they were and in the state they were in.
	 *
	 * @return void
	 */
	private static function sweep_records(): void {
		// One press, one key of its own: the button is its own form, made
		// by this plugin, for this person, this session.
		self::verify( 'estat_sweep_records' );

		$back = self::safe_back();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
		$scope = isset( $_POST['sweep_scope'] ) && ! is_array( $_POST['sweep_scope'] )
			? sanitize_key( (string) wp_unslash( $_POST['sweep_scope'] ) )
			: '';

		$ids = self::sweep_ids( $scope );

		if ( ! $ids ) {
			self::redirect( $back, 'error', __( 'Nothing was there to clean up, so nothing moved.', 'estat-os' ) );
		}

		/*
		 * No ceiling here. The bar stops at a hundred because a person
		 * ticked a hundred rows and should be told what happened to them;
		 * this press names a whole set and means all of it, so a limit
		 * would only mean pressing again and never being finished.
		 */
		$result = Bin::batch( 'move', $ids, __( 'Cleaned up in one press', 'estat-os' ) );

		if ( ! $result['done'] ) {
			self::redirect( $back, 'error', self::bin_answer( $result, __( 'moved to the bin', 'estat-os' ) ) );
		}

		$token = Bin::remember_undo( $result['done'] );

		$message = self::bin_answer( $result, __( 'moved to the bin', 'estat-os' ) );
		if ( '' !== $token ) {
			$message .= ' ' . __( 'Mistake? Press Undo and they come straight back.', 'estat-os' );
		}

		self::redirect( $back, 'binned', $message, $token );
	}

	/**
	 * Which records a named set is, worked out on the server.
	 *
	 * The button never carries a list of ids: a page can sit open for an
	 * hour while the office changes, and a list written into it would be a
	 * list of what was true then. The press carries the name of the set —
	 * "draft", "import-14" — and the records are looked up now.
	 *
	 * @param string $scope The name of the set, as the button wrote it.
	 * @return int[]
	 */
	private static function sweep_ids( string $scope ): array {
		// A guard, not a limit: a sweep is a whole set, and no office has
		// five thousand of one thing by accident.
		$ceiling = 5000;

		if ( 0 === strpos( $scope, 'import-' ) ) {
			$job_id = (int) substr( $scope, 7 );
			$job    = Spreadsheet::get_job( $job_id );

			if ( ! $job || empty( $job['created_ids'] ) ) {
				return array();
			}

			// The list is kept as JSON in one column, so it is read back here.
			$raw  = json_decode( (string) $job['created_ids'], true );
			$made = is_array( $raw ) ? array_values( array_unique( array_filter( array_map( 'absint', $raw ) ) ) ) : array();

			if ( ! $made ) {
				return array();
			}

			/*
			 * Only what that import made, only what is still standing, and
			 * only if it is a property: an import record keeps its list for
			 * months, and half of it may have been binned already.
			 */
			$still = get_posts(
				array(
					'post_type'              => PostTypes::LISTING,
					'post__in'               => $made,
					'post_status'            => array( 'publish', 'draft', 'pending', 'private' ),
					'numberposts'            => $ceiling,
					'fields'                 => 'ids',
					'orderby'                => 'post__in',
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'suppress_filters'       => false,
				)
			);

			return array_map( 'intval', (array) $still );
		}

		$status = in_array( $scope, array( 'draft', 'pending', 'private', 'publish' ), true ) ? $scope : '';

		if ( '' === $status ) {
			return array();
		}

		$ids = get_posts(
			array(
				'post_type'              => PostTypes::LISTING,
				'post_status'            => $status,
				'numberposts'            => $ceiling,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'suppress_filters'       => false,
			)
		);

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Bring records back out of the bin, each to the state it was in.
	 *
	 * @return void
	 */
	private static function restore_records(): void {
		self::verify_any( array( 'estat_restore_records', 'estat_bulk_records' ) );

		$back = self::safe_back();

		$ids   = self::picked_ids();
		$wrong = self::ids_problem( $ids, __( 'Nothing was chosen, so nothing was restored.', 'estat-os' ) );
		if ( '' !== $wrong ) {
			self::redirect( $back, 'error', $wrong );
		}

		$result = Bin::batch( 'restore', $ids );

		self::redirect( $back, 'restored', self::bin_answer( $result, __( 'restored', 'estat-os' ) ) );
	}

	/**
	 * Delete records for good — only ever from inside the bin.
	 *
	 * The typed word is checked here as well as on the screen: a form posted
	 * by hand, or a page left open from this morning, must not be able to
	 * destroy a record without somebody having said so in words.
	 *
	 * @return void
	 */
	private static function delete_forever(): void {
		self::verify_any( array( 'estat_delete_forever', 'estat_bulk_records' ) );

		$back = self::safe_back();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
		$typed = isset( $_POST['confirm_word'] ) && ! is_array( $_POST['confirm_word'] )
			? strtoupper( trim( sanitize_text_field( wp_unslash( (string) $_POST['confirm_word'] ) ) ) )
			: '';

		if ( 'DELETE' !== $typed ) {
			self::redirect(
				$back,
				'error',
				__( 'Nothing was deleted. Type DELETE in the box to confirm that you really mean it.', 'estat-os' )
			);
		}

		$ids   = self::picked_ids();
		$wrong = self::ids_problem( $ids, __( 'Nothing was chosen, so nothing was deleted.', 'estat-os' ) );
		if ( '' !== $wrong ) {
			self::redirect( $back, 'error', $wrong );
		}

		$result = Bin::batch( 'delete', $ids );

		self::redirect( $back, 'deleted', self::bin_answer( $result, __( 'deleted permanently', 'estat-os' ) ) );
	}

	/**
	 * Empty the bin in one press — with the same typed confirmation, and in
	 * batches, so a bin holding more than the ceiling is emptied completely
	 * instead of stopping halfway with no explanation.
	 *
	 * @return void
	 */
	private static function empty_bin(): void {
		self::verify( 'estat_empty_bin' );

		$back = self::safe_back();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$typed = isset( $_POST['confirm_word'] ) ? strtoupper( trim( sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['confirm_word'] ) ? '' : $_POST['confirm_word'] ) ) ) ) ) : '';

		if ( 'DELETE' !== $typed ) {
			self::redirect(
				$back,
				'error',
				__( 'Nothing was deleted. Type DELETE in the box to confirm that you really mean it.', 'estat-os' )
			);
		}

		$done   = array();
		$failed = array();
		$rounds = 0;

		// Each round takes the next slice of what is left in the bin. The
		// loop is bounded so a runaway can never hold a shared-hosting
		// request open forever.
		while ( $rounds < 20 ) {
			++$rounds;
			$ids = Bin::all_ids( self::BULK_LIMIT );
			if ( ! $ids ) {
				break;
			}

			$result = Bin::batch( 'delete', $ids );
			$done   = array_merge( $done, $result['done'] );
			$failed = $failed + $result['failed'];

			if ( ! $result['done'] ) {
				break; // Nothing moved; another round would spin.
			}
		}

		AuditLog::record( 'bin.emptied', 'bulk', 0, array( 'changed' => count( $done ), 'failed' => count( $failed ) ) );

		$message = 0 === count( $done )
			? __( 'The bin is empty. There was nothing left to delete.', 'estat-os' )
			: self::bin_answer(
				array(
					'done'   => $done,
					'failed' => $failed,
				),
				__( 'deleted permanently', 'estat-os' )
			);

		self::redirect( $back, 'deleted', $message );
	}

	/**
	 * Undo a sweep that just happened.
	 *
	 * The records are put back exactly where they were — a live property
	 * comes back live — because Undo means "as if I had not pressed it".
	 *
	 * @return void
	 */
	private static function undo_bin(): void {
		self::verify( 'estat_undo_bin_' . ( isset( $_GET['token'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( is_array( $_GET['token'] ) ? '' : $_GET['token'] ) ) : '' ), 'GET' );

		$back  = self::safe_back();
		$token = isset( $_GET['token'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( is_array( $_GET['token'] ) ? '' : $_GET['token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( null === Bin::undo_ids( (string) $token ) ) {
			self::redirect( $back, 'error', __( 'That Undo has expired. Nothing was changed — anything in the bin can still be restored from the Bin screen.', 'estat-os' ) );
		}

		$result = Bin::undo( (string) $token );

		self::redirect( $back, 'restored', self::bin_answer( $result, __( 'restored', 'estat-os' ) ) );
	}

	/**
	 * The answer to a bulk press, said out loud.
	 *
	 * @param array{done:int[],failed:array<int,string>} $result What happened.
	 * @param string                                     $verb   What was done.
	 * @return string
	 */
	private static function bin_answer( array $result, string $verb ): string {
		// The office list is a list of properties, so the answer talks about
		// properties: "7 properties moved to the bin", not "7 records".
		$line = Bin::summary(
			$result,
			$verb,
			array(
				'one'  => __( 'property', 'estat-os' ),
				'many' => __( 'properties', 'estat-os' ),
			)
		);

		if ( ! empty( $result['failed'] ) ) {
			$line .= ' ' . Bin::reasons( (array) $result['failed'] );
		}

		return $line;
	}

	/**
	 * Which records a press was about: the ones that were ticked.
	 *
	 * One way of saying it, because one way is all a person can hold in
	 * their head. Earlier versions also let the bar say "everything the
	 * filter is showing" and worked that list out on the server; it was
	 * correct, and it was impossible to be sure of — the button changed
	 * records that were not on the screen. That choice is gone. What is
	 * ticked is what happens, and rows can be ticked a pageful at a time.
	 *
	 * @return int[]
	 */
	private static function picked_ids(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by the caller.
		$raw = isset( $_POST['record_ids'] ) && is_array( $_POST['record_ids'] ) ? (array) wp_unslash( $_POST['record_ids'] ) : array();
		$single = isset( $_POST['record_id'] ) && ! is_array( $_POST['record_id'] ) ? absint( wp_unslash( $_POST['record_id'] ) ) : 0;
		// phpcs:enable

		$ids = array_values( array_unique( array_filter( array_map( 'absint', $raw ) ) ) );
		if ( $single > 0 ) {
			$ids[] = $single;
		}

		// Ceiling: one bar press acts on at most this many records. The bar
		// says so before it is pressed (the count turns red), so nothing is
		// dropped silently.
		$ids = array_slice( array_values( array_unique( array_filter( $ids ) ) ), 0, self::BULK_LIMIT );

		return $ids;
	}

	/**
	 * Every record the list was showing, worked out on the server.
	 *
	 * @param array<string,mixed> $scope The filters the screen was using.
	 * @return int[]
	 */
	private static function ids_matching( array $scope ): array {
		$clean = static function ( string $key, string $default = '' ) use ( $scope ): string {
			$value = $scope[ $key ] ?? $default;
			if ( is_array( $value ) ) {
				return $default;
			}

			return sanitize_text_field( (string) $value );
		};

		$ceiling = self::BULK_LIMIT + 1; // One more than we will act on, so "too many" is knowable.

		if ( 'bin' === sanitize_key( $clean( 'kind', 'listing' ) ) ) {
			return Bin::all_ids(
				$ceiling,
				array(
					'deleted_by' => (int) $clean( 'deleted_by', '0' ),
					'previous'   => sanitize_key( $clean( 'previous' ) ),
					'date_from'  => $clean( 'from' ),
					'date_to'    => $clean( 'to' ),
					'type'       => sanitize_key( $clean( 'type' ) ),
					'locality'   => sanitize_key( $clean( 'locality' ) ),
					'search'     => $clean( 's' ),
				)
			);
		}

		$status = sanitize_key( $clean( 'status', 'any' ) );
		$search = $clean( 's' );

		if ( 'attention' === $status ) {
			$ids = array();
			foreach ( \EstatOS\Data\Health::attention( 300 ) as $row ) {
				if ( ! empty( $row['id'] ) ) {
					$ids[] = (int) $row['id'];
				}
			}

			return array_slice( $ids, 0, $ceiling );
		}

		$args = array(
			'post_type'      => \EstatOS\Data\PostTypes::LISTING,
			'post_status'    => in_array( $status, array( 'publish', 'draft', 'pending', 'private' ), true )
				? $status
				: array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => $ceiling,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'orderby'        => 'ID',
			'order'          => 'ASC',
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		return array_map( 'absint', get_posts( $args ) );
	}

	/**
	 * The ticks that must be there before anything happens, or the answer
	 * that says why nothing did.
	 *
	 * @param int[] $ids Chosen records.
	 * @return string '' when the list is fine, otherwise what to say.
	 */
	private static function ids_problem( array $ids, string $nothing ): string {
		if ( ! $ids ) {
			return $nothing;
		}

		if ( count( $ids ) > self::BULK_LIMIT ) {
			return sprintf(
				/* translators: %d: the most records that can be changed at once. */
				__( 'That is too many at once. Please do up to %d at a time.', 'estat-os' ),
				self::BULK_LIMIT
			);
		}

		return '';
	}

	/**
	 * Where to send somebody back to, without letting a referer point
	 * anywhere but this site's own admin.
	 *
	 * @return string
	 */
	private static function safe_back(): string {
		/*
		 * Which screen to come back to.
		 *
		 * The form says so itself (back_page), because the Referer cannot be
		 * relied on here: WordPress refuses a referer that is the same URL
		 * as the request, and that is exactly what happens when the Bin's
		 * own form posts back to the Bin screen — pressing Empty bin used
		 * to throw the office over to the Properties list instead of
		 * showing "Recycle bin is empty" where they were standing.
		 *
		 * The name is a list of ours, never a link somebody can type: only
		 * pages this plugin owns are allowed through.
		 */
		$asked = '';
		if ( isset( $_POST['back_page'] ) && ! is_array( $_POST['back_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verified the nonce.
			$asked = sanitize_key( wp_unslash( (string) $_POST['back_page'] ) );
		} elseif ( isset( $_GET['back_page'] ) && ! is_array( $_GET['back_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$asked = sanitize_key( wp_unslash( (string) $_GET['back_page'] ) );
		}

		if ( '' !== $asked && in_array( $asked, self::pages_we_may_return_to(), true ) ) {
			return admin_url( 'admin.php?page=' . $asked );
		}

		$referer = wp_get_referer();
		if ( $referer && false !== strpos( $referer, admin_url() ) ) {
			return $referer;
		}

		return admin_url( 'admin.php?page=estat-listings' );
	}

	/**
	 * The screens a form is allowed to ask to return to.
	 *
	 * @return string[]
	 */
	private static function pages_we_may_return_to(): array {
		return array( 'estat-listings', 'estat-bin', 'estat-today', 'estat-projects', 'estat-team', 'estat-enquiries', 'estat-duplicates' );
	}

	/**
	 * Act on several records at once.
	 *
	 * Doing twenty listings one at a time meant twenty page loads. This does
	 * them in one, but it is deliberately not a shortcut around permission:
	 * every record is looked up, matched to its kind, and checked against that
	 * kind's own capability. A user who may bin listings but not team members
	 * gets exactly the listings binned and is told the rest were skipped.
	 *
	 * Permanent deletion is not offered here. Removing many records forever
	 * from a checkbox column is too easy to do by accident, so bulk can only
	 * move things to the bin, bring them back, publish, or unpublish.
	 *
	 * @return void
	 */
	private static function bulk_records(): void {
		self::verify( 'estat_bulk_records' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$operation = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( is_array($_POST['bulk_action']) ? '' : $_POST['bulk_action'] ) ) : '';
		$back_page = isset( $_POST['back_page'] ) ? sanitize_key( wp_unslash( is_array($_POST['back_page']) ? '' : $_POST['back_page'] ) ) : 'estat-listings';
		// phpcs:enable

		$back = admin_url( 'admin.php?page=' . $back_page );

		if ( ! in_array( $operation, array_keys( self::bulk_operations() ), true ) ) {
			self::redirect( $back, 'error', __( 'Please choose what to do with the ones you ticked.', 'estat-os' ) );
		}

		// The ticked rows arrive as a group (record_ids[] = 12), so this is
		// read as an array by design. "Select all 240 properties" is resolved
		// on the server from the same filters the screen drew.
		$ids   = self::picked_ids();
		$wrong = self::ids_problem( $ids, __( 'Nothing was ticked, so nothing was changed.', 'estat-os' ) );
		if ( '' !== $wrong ) {
			self::redirect( $back, 'error', $wrong );
		}

		$kinds   = self::record_kinds();
		$done    = 0;
		$skipped = 0;

		foreach ( $ids as $id ) {
			$post = get_post( $id );

			if ( ! $post || ! isset( $kinds[ $post->post_type ] ) ) {
				++$skipped;
				continue;
			}

			if ( ! current_user_can( $kinds[ $post->post_type ]['cap'] ) ) {
				++$skipped;
				continue;
			}

			if ( self::apply_bulk( $operation, $post ) ) {
				++$done;
			} else {
				++$skipped;
			}
		}

		AuditLog::record(
			'records.bulk',
			'bulk',
			0,
			array(
				'operation' => $operation,
				'changed'   => $done,
				'skipped'   => $skipped,
			)
		);

		if ( 0 === $done ) {
			self::redirect( $back, 'error', __( 'Nothing was changed. You may not have permission for the ones you ticked.', 'estat-os' ) );
		}

		$message = sprintf(
			/* translators: 1: number changed, 2: what was done. */
			_n( '%1$d record %2$s.', '%1$d records %2$s.', $done, 'estat-os' ),
			$done,
			self::bulk_operations()[ $operation ]['done']
		);

		if ( $skipped > 0 ) {
			$message .= ' ' . sprintf(
				/* translators: %d: number skipped. */
				_n( '%d was skipped because you do not have permission for it.', '%d were skipped because you do not have permission for them.', $skipped, 'estat-os' ),
				$skipped
			);
		}

		self::redirect( $back, 'saved', $message );
	}

	/**
	 * Carry out one bulk operation on one record.
	 *
	 * @param string   $operation Operation key.
	 * @param \WP_Post $post      Record.
	 * @return bool Whether anything changed.
	 */
	private static function apply_bulk( string $operation, \WP_Post $post ): bool {
		$id = (int) $post->ID;

		switch ( $operation ) {
			case 'publish':
				if ( 'publish' === $post->post_status || 'trash' === $post->post_status ) {
					return false;
				}

				return (bool) wp_update_post(
					array(
						'ID'          => $id,
						'post_status' => 'publish',
					)
				);

			case 'draft':
				if ( 'draft' === $post->post_status || 'trash' === $post->post_status ) {
					return false;
				}

				return (bool) wp_update_post(
					array(
						'ID'          => $id,
						'post_status' => 'draft',
					)
				);

			case 'pending':
				if ( 'pending' === $post->post_status || 'trash' === $post->post_status ) {
					return false;
				}

				return (bool) wp_update_post(
					array(
						'ID'          => $id,
						'post_status' => 'pending',
					)
				);

			case 'private':
				if ( 'private' === $post->post_status || 'trash' === $post->post_status ) {
					return false;
				}

				return (bool) wp_update_post(
					array(
						'ID'          => $id,
						'post_status' => 'private',
					)
				);
		}

		return false;
	}

	/**
	 * The things bulk can do, in plain words.
	 *
	 * @return array<string,array{label:string,done:string}>
	 */
	public static function bulk_operations(): array {
		return array(
			'publish' => array(
				'label' => __( 'Live — show it on the website', 'estat-os' ),
				'done'  => __( 'now live on the website', 'estat-os' ),
			),
			'draft'   => array(
				'label' => __( 'Draft — keep it off the website', 'estat-os' ),
				'done'  => __( 'now drafts, off the website', 'estat-os' ),
			),
			'pending' => array(
				'label' => __( 'Waiting for approval', 'estat-os' ),
				'done'  => __( 'now waiting for approval', 'estat-os' ),
			),
			'private' => array(
				'label' => __( 'Paused — hidden from the website', 'estat-os' ),
				'done'  => __( 'now paused', 'estat-os' ),
			),
		);
	}

	/**
	 * Resolve and authorise the record named in the request.
	 *
	 * Redirects and stops if the record is missing, is not one of ours, or the
	 * signed-in person is not allowed to remove that kind of thing.
	 *
	 * @param string $nonce_prefix Nonce action prefix.
	 * @return array{id:int,post:\WP_Post,kind:array{cap:string,page:string,label:string},back:string}
	 */
	private static function record_target( string $nonce_prefix ): array {
		$id = isset( $_GET['record_id'] ) ? absint( wp_unslash( is_array($_GET['record_id']) ? '' : $_GET['record_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::verify( $nonce_prefix . $id, 'GET' );

		$fallback = admin_url( 'admin.php?page=estat-listings' );
		$post     = $id > 0 ? get_post( $id ) : null;
		$kinds    = self::record_kinds();

		if ( ! $post || ! isset( $kinds[ $post->post_type ] ) ) {
			self::redirect( $fallback, 'error', __( 'That record could not be found. It may already have been removed.', 'estat-os' ) );
		}

		$kind = $kinds[ $post->post_type ];
		if ( ! current_user_can( $kind['cap'] ) ) {
			self::redirect( admin_url( 'admin.php?page=' . $kind['page'] ), 'forbidden' );
		}

		return array(
			'id'   => $id,
			'post' => $post,
			'kind' => $kind,
			'back' => admin_url( 'admin.php?page=' . $kind['page'] ),
		);
	}

	/**
	 * Move a record to the bin. Nothing is destroyed; it can be put back.
	 *
	 * @return void
	 */
	private static function trash_record(): void {
		$target = self::record_target( 'estat_trash_record_' );

		if ( 'trash' === $target['post']->post_status ) {
			self::redirect( $target['back'], 'trashed' );
		}

		// One lifecycle for everybody: the row button, the toolbar, the phone
		// and the WordPress post list all end up in Bin::move(), so what is
		// recorded about a record — who moved it, when, from what state — is
		// the same whichever door was used.
		$result = Bin::move( $target['id'], '' );
		if ( is_wp_error( $result ) ) {
			self::redirect( $target['back'], 'error', $result->get_error_message() );
		}

		self::redirect( $target['back'], 'trashed' );
	}

	/**
	 * Put a record back from the bin, exactly as it was.
	 *
	 * @return void
	 */
	private static function restore_record(): void {
		$target = self::record_target( 'estat_restore_record_' );

		if ( 'trash' !== $target['post']->post_status ) {
			self::redirect( $target['back'], 'restored' );
		}

		// Back to where it was — Live stays Live, a draft stays a draft, a
		// paused property stays paused. The old code forced everything to a
		// draft, which quietly took live properties off the website after a
		// restore that was supposed to change nothing.
		$result = Bin::restore( $target['id'] );
		if ( is_wp_error( $result ) ) {
			self::redirect( $target['back'], 'error', $result->get_error_message() );
		}

		self::redirect(
			$target['back'],
			'restored',
			sprintf(
				/* translators: %s: the state the record came back as (Live, Draft…). */
				__( 'Brought back as “%s”.', 'estat-os' ),
				\EstatOS\Support\Status::label( \EstatOS\Support\Status::PUBLICATION, (string) $result['to'] )
			)
		);
	}

	/**
	 * Delete a record for good. Only ever from the bin, and only after the
	 * office has typed DELETE to confirm.
	 *
	 * @return void
	 */
	private static function delete_record(): void {
		$target = self::record_target( 'estat_delete_record_' );

		$confirm = isset( $_GET['confirm'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['confirm']) ? '' : $_GET['confirm'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'DELETE' !== $confirm ) {
			self::redirect( $target['back'], 'error', __( 'Nothing was deleted. Type DELETE in the box to confirm you really mean it.', 'estat-os' ) );
		}

		// Bin::delete_forever() carries the whole policy: only from the bin,
		// only with the permanent-delete permission, enquiries and history
		// kept, shared media left alone.
		$result = Bin::delete_forever( $target['id'] );
		if ( is_wp_error( $result ) ) {
			self::redirect( $target['back'], 'error', $result->get_error_message() );
		}

		self::redirect( $target['back'], 'deleted' );
	}

	/**
	 * The quick "Add a Home" form.
	 *
	 * @return void
	 */
	private static function add_home(): void {
		/*
		 * Two names for one key: the screen posts `estat_add_home` when it is
		 * making a new property, and an older page still open in the browser
		 * posts `estat_save_listing_0`. Both are ours and both are accepted,
		 * so a form that was loaded a minute ago does not turn into "that
		 * link has expired".
		 */
		self::verify_any( array( 'estat_add_home', 'estat_save_listing_0' ) );

		$status = ( 'publish' === self::save_mode() && current_user_can( 'estat_publish_listings' ) ) ? 'publish' : 'draft';

		/*
		 * Every field the form posted, not a chosen ten. The highlights
		 * arrive as a group (highlights[] = "Corner plot", …) and stay one —
		 * flattening to a single string was one of the ways a typed line went
		 * missing.
		 */
		$input           = self::listing_input();
		$input['status'] = $status;

		$result = Listings::save( $input );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-add-home' ), 'error', self::first_message( $result ) );
		}

		/*
		 * The editor lives on its own page. This used to point at the list
		 * with ?edit=, which the list ignores — so after publishing, the
		 * office landed on a table of properties with no sign of which one
		 * had just been saved. It opens the property it just saved.
		 */
		self::redirect(
			admin_url( 'admin.php?page=estat-add-home&edit=' . (int) $result ),
			'publish' === $status ? 'published' : 'draft'
		);
	}

	/**
	 * The full listing editor.
	 *
	 * @return void
	 */
	private static function save_listing(): void {
		$listing_id = self::int_post( 'listing_id' );

		/*
		 * This is the screen's own action, and the screen has two jobs.
		 *
		 * Add a home posts `action=estat_save_listing` whether it is making a
		 * new property or editing one, and it carries the nonce for whichever
		 * of the two it is. A link to one record carries
		 * `estat_save_listing_{id}`. All of those are ours — reading only the
		 * last one is what turned every Publish into "that link has expired",
		 * with the property untouched.
		 *
		 * And when there is no id at all, this is not an edit: it is a new
		 * property, and it goes down the create path.
		 */
		self::verify_any( array( 'estat_save_listing_' . $listing_id, 'estat_add_home' ) );

		if ( $listing_id <= 0 ) {
			self::add_home();
			return;
		}

		$input = self::listing_input();

		$mode = self::save_mode();
		if ( 'publish' === $mode ) {
			$input['status'] = 'publish';
		} elseif ( 'draft' === $mode ) {
			$input['status'] = 'draft';
		} else {
			$input['status'] = (string) get_post_status( $listing_id );
		}

		$result = Listings::save( $input, $listing_id );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ), 'error', self::first_message( $result ) );
		}

		/*
		 * Now that it is saved, ask the one question this screen cannot
		 * answer on its own: is this something the office already has?
		 *
		 * The verdict is kept against the record, so it is waiting here on
		 * the next visit rather than living only in the moment of typing —
		 * and the office hears it while it is still thinking about this
		 * property, instead of finding out from a visitor who saw the same
		 * flat twice on the website.
		 */
		Duplicate::remember( 'listing', (int) $result );

		$notice = 'publish' === $input['status'] ? 'published' : 'saved';
		self::redirect( admin_url( 'admin.php?page=estat-add-home&edit=' . $listing_id ), $notice );
	}

	/* --------------------------------------------------------------------- *
	 * Enquiries and visits
	 * --------------------------------------------------------------------- */

	/**
	 * Update one enquiry — F1: status pipeline, lost_reason, intent, locality, budget, notes timeline.
	 *
	 * @return void
	 */
	private static function update_lead(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::verify( 'estat_update_lead_' . $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$input = array(
			'status'      => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( is_array($_POST['status']) ? '' : $_POST['status'] ) ) : null,
			'lost_reason' => isset( $_POST['lost_reason'] ) ? sanitize_key( wp_unslash( is_array($_POST['lost_reason']) ? '' : $_POST['lost_reason'] ) ) : null,
			'followup_at' => isset( $_POST['followup_at'] ) ? Sanitize::text( wp_unslash( is_array($_POST['followup_at']) ? '' : $_POST['followup_at'] ) ) : null,
			'intent'      => isset( $_POST['intent'] ) ? sanitize_key( wp_unslash( is_array($_POST['intent']) ? '' : $_POST['intent'] ) ) : null,
		);
		if ( isset( $_POST['agent_id'] ) && current_user_can( 'estat_assign_leads' ) ) {
			$input['agent_id'] = absint( wp_unslash( is_array($_POST['agent_id']) ? '' : $_POST['agent_id'] ) );
			$input['assigned_agent_id'] = $input['agent_id'];
		}
		$note = isset( $_POST['note'] ) ? Sanitize::textarea( wp_unslash( is_array($_POST['note']) ? '' : $_POST['note'] ) ) : '';
		// phpcs:enable

		$input  = array_filter( $input, static fn( $value ) => null !== $value && '' !== $value );
		// Keep lost_reason even if empty when status lost — validator will complain.
		if ( isset( $_POST['status'] ) && 'lost' === sanitize_key( wp_unslash( is_array($_POST['status']) ? '' : $_POST['status'] ) ) ) {
			$input['lost_reason'] = isset( $_POST['lost_reason'] ) ? sanitize_key( wp_unslash( is_array($_POST['lost_reason']) ? '' : $_POST['lost_reason'] ) ) : '';
		}

		$result = Leads::update( $lead_id, $input );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), 'error', self::first_message( $result ) );
		}
		if ( '' !== $note ) {
			Leads::append_note( $lead_id, $note );
		}

		self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), isset( $input['agent_id'] ) ? 'assigned' : 'saved' );
	}

	/**
	 * Book a site visit from an enquiry.
	 *
	 * @return void
	 */
	private static function schedule_visit(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::verify( 'estat_schedule_visit_' . $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$result = Visits::schedule(
			array(
				'lead_id'      => $lead_id,
				'listing_id'   => isset( $_POST['listing_id'] ) ? absint( wp_unslash( is_array($_POST['listing_id']) ? '' : $_POST['listing_id'] ) ) : 0,
				'agent_id'     => isset( $_POST['agent_id'] ) ? absint( wp_unslash( is_array($_POST['agent_id']) ? '' : $_POST['agent_id'] ) ) : 0,
				'scheduled_at' => isset( $_POST['scheduled_at'] ) ? Sanitize::text( wp_unslash( is_array($_POST['scheduled_at']) ? '' : $_POST['scheduled_at'] ) ) : '',
			)
		);
		// phpcs:enable

		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), 'error', self::first_message( $result ) );
		}
		self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), 'visit_scheduled' );
	}

	/**
	 * Record how a visit went.
	 *
	 * @return void
	 */
	private static function update_visit(): void {
		$visit_id = self::int_post( 'visit_id' );
		self::verify( 'estat_update_visit_' . $visit_id );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$outcome = isset( $_POST['outcome'] ) ? sanitize_key( wp_unslash( is_array($_POST['outcome']) ? '' : $_POST['outcome'] ) ) : '';
		$result  = Visits::update( $visit_id, array( 'outcome' => $outcome ) );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-visits' ), 'error', self::first_message( $result ) );
		}
		self::redirect( admin_url( 'admin.php?page=estat-visits' ), 'saved' );
	}

	/**
	 * Permanently remove someone's personal details.
	 *
	 * @return void
	 */
	private static function erase_lead(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::verify( 'estat_erase_lead_' . $lead_id );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$confirm = isset( $_POST['confirm'] ) ? trim( (string) wp_unslash( is_array($_POST['confirm']) ? '' : $_POST['confirm'] ) ) : '';
		if ( 'DELETE' !== $confirm ) {
			self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), 'error', __( 'Nothing was erased. Type DELETE in capital letters to confirm.', 'estat-os' ) );
		}

		Leads::erase( $lead_id );
		self::redirect( admin_url( 'admin.php?page=estat-enquiries' ), 'erased' );
	}

	/* --------------------------------------------------------------------- *
	 * Projects, team
	 * --------------------------------------------------------------------- */

	/**
	 * Save a society or project.
	 *
	 * @return void
	 */
	private static function save_project(): void {
		self::verify( 'estat_save_project' );
		$project_id = self::int_post( 'project_id' );

		$input  = self::post_fields(
			array(
				'title', 'description', 'locality', 'developer', 'project_type', 'category', 'address',
				'project_status', 'possession_date',
				'price_min', 'price_max', 'total_units', 'available_units', 'unit_types',
				'highlights', 'regulatory_id', 'external_id', 'cover_id',
			)
		);
		$result = Projects::save( $input, $project_id );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-projects' ), 'error', self::first_message( $result ) );
		}
		Duplicate::remember( 'project', (int) $result );

		self::redirect( admin_url( 'admin.php?page=estat-projects&edit=' . (int) $result ), 'saved' );
	}

	/**
	 * Save a team member.
	 *
	 * @return void
	 */
	private static function save_agent(): void {
		self::verify( 'estat_save_agent' );
		$agent_id = self::int_post( 'agent_id' );

		$input  = self::post_fields( array( 'title', 'role', 'phone', 'whatsapp', 'email', 'bio', 'photo_id', 'external_id', 'user_id' ) );
		$result = Agents::save( $input, $agent_id );
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-team' ), 'error', self::first_message( $result ) );
		}
		self::redirect( admin_url( 'admin.php?page=estat-team&edit=' . (int) $result ), 'saved' );
	}

	/* --------------------------------------------------------------------- *
	 * Forms
	 * --------------------------------------------------------------------- */

	/* --------------------------------------------------------------------- *
	 * Records that look like records the office already has
	 * --------------------------------------------------------------------- */

	/**
	 * "These two are different records."
	 *
	 * Said once and written down. The engine does not raise the same pair
	 * again, because being asked the same question twice is how offices
	 * start ignoring the question altogether.
	 *
	 * @return void
	 */
	private static function duplicate_keep(): void {
		$post_id = self::int_post( 'post_id' );
		self::verify( 'estat_duplicate_keep_' . $post_id );

		$other_id = self::int_post( 'other_id' );
		$kind     = self::duplicate_kind();
		$back     = self::safe_back();

		if ( $post_id <= 0 || $other_id <= 0 ) {
			self::redirect( $back, 'error', __( 'That record could not be found.', 'estat-os' ) );
		}
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			self::redirect( $back, 'forbidden' );
		}

		Duplicate::keep_both( $post_id, $other_id, $kind );
		self::redirect( $back, 'duplicate_kept' );
	}

	/**
	 * "This one should not be here."
	 *
	 * The record goes to the bin through Bin::move(), the same door every
	 * other removal uses, so what is remembered about it — who moved it,
	 * when, from what state — is the same whichever way it was decided.
	 *
	 * @return void
	 */
	private static function duplicate_bin(): void {
		$post_id = self::int_post( 'post_id' );
		self::verify( 'estat_duplicate_bin_' . $post_id );

		$back = self::safe_back();

		if ( $post_id <= 0 ) {
			self::redirect( $back, 'error', __( 'That record could not be found.', 'estat-os' ) );
		}
		if ( ! current_user_can( 'estat_bin_listings' ) ) {
			self::redirect( $back, 'forbidden' );
		}

		$result = Bin::move( $post_id, '' );
		if ( is_wp_error( $result ) ) {
			self::redirect( $back, 'error', $result->get_error_message() );
		}

		Duplicate::forget( $post_id );
		AuditLog::record(
			'duplicate.binned',
			get_post_type( $post_id ) ? (string) get_post_type( $post_id ) : 'listing',
			$post_id,
			array(
				'by'   => get_current_user_id(),
				'said' => __( 'Moved to the bin because it looked like a record the office already had.', 'estat-os' ),
			)
		);

		self::redirect( $back, 'duplicate_binned' );
	}

	/**
	 * Look at one record again, against what the office has today.
	 *
	 * @return void
	 */
	private static function duplicate_rescan(): void {
		$post_id = self::int_post( 'post_id' );
		self::verify( 'estat_duplicate_rescan_' . $post_id );

		$kind = self::duplicate_kind();
		$back = self::safe_back();

		if ( $post_id <= 0 || ! current_user_can( 'estat_manage_listings' ) ) {
			self::redirect( $back, 'forbidden' );
		}

		$match = Duplicate::remember( $kind, $post_id );

		/* translators: %s is the name of the record it now looks like. */
		$detail = $match
			? sprintf( __( 'Looked again. It still looks like %s.', 'estat-os' ), (string) ( $match['title'] ?? '' ) )
			: __( 'Looked again. Nothing here is like it.', 'estat-os' );

		self::redirect( $back, 'duplicate_scanned', $detail );
	}

	/**
	 * Look through the whole inventory and write down what looks alike.
	 *
	 * @return void
	 */
	private static function duplicate_scan(): void {
		self::verify( 'estat_duplicate_scan' );

		$back = self::safe_back();
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			self::redirect( $back, 'forbidden' );
		}

		$kind = isset( $_POST['kind'] ) && ! is_array( $_POST['kind'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
			? sanitize_key( wp_unslash( (string) $_POST['kind'] ) )
			: 'listings';
		$kind = in_array( $kind, array( 'listings', 'projects' ), true ) ? $kind : 'listings';

		$result = Duplicate::scan( 'projects' === $kind ? 'project' : 'listing' );

		// Held for one person, so two people looking do not trip over it.
		set_transient( 'estat_duplicate_scan_' . get_current_user_id(), $result, HOUR_IN_SECONDS );

		$stopped = ! empty( $result['stopped'] );
		/* translators: 1: how many records were looked at, 2: how many pairs were written down. */
		$detail = $stopped
			? sprintf( __( 'Looked at %1$d records and found %2$d pairs so far. There is more to read — press Look again to carry on.', 'estat-os' ), (int) $result['looked'], count( (array) $result['pairs'] ) )
			: sprintf( __( 'Looked at %1$d records and found %2$d pairs that look alike.', 'estat-os' ), (int) $result['looked'], count( (array) $result['pairs'] ) );

		self::redirect( admin_url( 'admin.php?page=estat-duplicates&kind=' . $kind ), 'duplicate_scanned', $detail );
	}

	/**
	 * Which kind of record a duplicate action is about.
	 *
	 * The record itself is the honest answer; the form only says so when it
	 * knows, because a society and a property are edited on screens that
	 * look nothing alike.
	 *
	 * @return string 'project' or 'listing'.
	 */
	private static function duplicate_kind(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verified the nonce.
		$asked = isset( $_POST['kind'] ) && ! is_array( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) $_POST['kind'] ) ) : '';
		if ( in_array( $asked, array( 'listing', 'project', 'listings', 'projects' ), true ) ) {
			return in_array( $asked, array( 'project', 'projects' ), true ) ? 'project' : 'listing';
		}

		$post_id = self::int_post( 'post_id' );
		$type    = $post_id > 0 ? (string) get_post_type( $post_id ) : '';

		return PostTypes::PROJECT === $type ? 'project' : 'listing';
	}

	/**
	 * Create, save, duplicate or delete a form.
	 *
	 * @param string $action Action key.
	 * @return void
	 */
	private static function form_action( string $action ): void {
		$forms_url = admin_url( 'admin.php?page=estat-forms' );
		$form_id   = self::int_post( 'form_id' );

		if ( 'create_form' === $action ) {
			self::verify( 'estat_create_form' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$name = isset( $_POST['name'] ) ? Sanitize::text( wp_unslash( is_array($_POST['name']) ? '' : $_POST['name'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$template_key = isset( $_POST['template'] ) ? sanitize_key( wp_unslash( is_array($_POST['template']) ? '' : $_POST['template'] ) ) : '';
			$template     = '' !== $template_key ? Templates::get( $template_key ) : null;

			// An unknown template must not silently produce an empty form.
			if ( '' !== $template_key && ! $template ) {
				self::redirect( $forms_url, 'error', __( 'That ready-made form is not available. Please pick another.', 'estat-os' ) );
			}

			if ( $template ) {
				// The office may not have typed a name; the template has one.
				if ( '' === $name ) {
					$name = (string) $template['label'];
				}
				$definition = $template['definition'];
				$settings   = array_merge( Forms::default_settings(), (array) $template['settings'] );
			} else {
				$definition = Forms::starter_definition();
				$settings   = Forms::default_settings();
			}

			$result = Forms::save(
				array(
					'name'       => $name,
					'definition' => $definition,
					'settings'   => $settings,
				)
			);
			if ( is_wp_error( $result ) ) {
				self::redirect( $forms_url, 'error', self::first_message( $result ) );
			}
			self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . (int) $result ), 'saved' );
		}

		if ( 'duplicate_form' === $action ) {
			self::verify( 'estat_duplicate_form_' . $form_id );
			$result = Forms::duplicate( $form_id );
			if ( is_wp_error( $result ) ) {
				self::redirect( $forms_url, 'error', self::first_message( $result ) );
			}
			self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . (int) $result ), 'saved' );
		}

		if ( 'delete_form' === $action ) {
			self::verify( 'estat_delete_form_' . $form_id );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$confirm = isset( $_POST['confirm'] ) ? trim( (string) wp_unslash( is_array($_POST['confirm']) ? '' : $_POST['confirm'] ) ) : '';
			if ( 'DELETE' !== $confirm ) {
				self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . $form_id ), 'error', __( 'Nothing was deleted. Type DELETE in capital letters to confirm.', 'estat-os' ) );
			}
			Forms::delete( $form_id );
			self::redirect( $forms_url, 'deleted' );
		}

		// save_form.
		self::verify( 'estat_save_form_' . $form_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$definition = isset( $_POST['definition'] ) ? (string) wp_unslash( is_array($_POST['definition']) ? '' : $_POST['definition'] ) : '[]';
		$decoded    = json_decode( $definition, true );
		$settings   = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- har value Forms::save() me alag se saaf hoti hai.
		$name       = isset( $_POST['name'] ) ? Sanitize::text( wp_unslash( is_array($_POST['name']) ? '' : $_POST['name'] ) ) : '';
		// phpcs:enable

		if ( ! is_array( $decoded ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . $form_id ), 'error', __( 'The form layout could not be read, so nothing was changed. Please try again.', 'estat-os' ) );
		}

		// Unticked boxes never reach the server, so make the intent explicit.
		foreach ( array( 'create_lead', 'store_submission', 'notify', 'require_consent' ) as $flag ) {
			$settings[ $flag ] = ! empty( $settings[ $flag ] );
		}

		$result = Forms::save(
			array(
				'name'       => $name,
				'definition' => $decoded,
				'settings'   => $settings,
			),
			$form_id
		);
		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . $form_id ), 'error', self::first_message( $result ) );
		}
		self::redirect( admin_url( 'admin.php?page=estat-forms&edit=' . (int) $result ), 'saved' );
	}

	/* --------------------------------------------------------------------- *
	 * Spreadsheets
	 * --------------------------------------------------------------------- */

	/**
	 * Upload and start an import.
	 *
	 * @return void
	 */
	private static function import_csv(): void {
		self::verify( 'estat_import_csv' );
		$url = admin_url( 'admin.php?page=estat-spreadsheet' );

		if ( empty( $_FILES['estat_csv'] ) || ! is_array( $_FILES['estat_csv'] ) ) {
			self::redirect( $url, 'error', __( 'Please choose a CSV file to upload.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$stored = Spreadsheet::store_upload( (array) $_FILES['estat_csv'] );
		if ( is_wp_error( $stored ) ) {
			self::redirect( $url, 'error', self::first_message( $stored ) );
		}

		/*
		 * What is in the file — properties, societies, team or enquiries.
		 * The screen has asked this all along (its "What is in this file?"
		 * box) and the answer was thrown away: every file was imported as
		 * properties, so a societies sheet came in as a hundred flats.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above.
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_POST['kind'] ) ? '' : $_POST['kind'] ) ) ) : 'listings';
		$kind = in_array( $kind, array( 'listings', 'projects', 'agents', 'leads' ), true ) ? $kind : 'listings';

		$preview = Spreadsheet::preview( (string) $stored, 1 );
		if ( is_wp_error( $preview ) ) {
			self::redirect( $url, 'error', self::first_message( $preview ) );
		}

		$mapping = Spreadsheet::guess_mapping( (array) ( $preview['headers'] ?? array() ), $kind );
		$job_id  = Spreadsheet::create_job( (string) $stored, $kind, $mapping );
		if ( is_wp_error( $job_id ) ) {
			self::redirect( $url, 'error', self::first_message( $job_id ) );
		}

		// Read what we can while the request has time; the daily job takes the rest.
		$progress = Spreadsheet::run_job( (int) $job_id );
		$detail   = is_wp_error( $progress )
			? self::first_message( $progress )
			: sprintf(
				/* translators: 1: rows added, 2: rows updated */
				__( '%1$d added, %2$d updated so far.', 'estat-os' ),
				(int) ( $progress['created'] ?? 0 ),
				(int) ( $progress['updated'] ?? 0 )
			);

		self::redirect( $url, is_wp_error( $progress ) ? 'error' : 'imported', $detail );
	}

	/**
	 * F6: Preview uploaded CSV — show headers, sample rows, mapping guess, bridge selector.
	 *
	 * @return void
	 */
	private static function preview_csv(): void {
		self::verify( 'estat_import_csv' );
		$url = admin_url( 'admin.php?page=estat-spreadsheet' );

		if ( empty( $_FILES['estat_csv'] ) || ! is_array( $_FILES['estat_csv'] ) ) {
			self::redirect( $url, 'error', __( 'Please choose a CSV file to upload.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$stored = Spreadsheet::store_upload( (array) $_FILES['estat_csv'] );
		if ( is_wp_error( $stored ) ) {
			self::redirect( $url, 'error', self::first_message( $stored ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['kind']) ? '' : $_POST['kind'] ) ) ) : 'listings';
		$kind = in_array( $kind, array( 'listings', 'projects', 'agents', 'leads' ), true ) ? $kind : 'listings';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$bridge = isset( $_POST['bridge_type'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['bridge_type']) ? '' : $_POST['bridge_type'] ) ) ) : '';
		$bridge = in_array( $bridge, array_keys( Spreadsheet::bridge_systems() ), true ) ? $bridge : '';

		$preview = Spreadsheet::preview( (string) $stored, 5 );
		if ( is_wp_error( $preview ) ) {
			self::redirect( $url, 'error', self::first_message( $preview ) );
		}

		// Nobody should have to know that their sheet is a "developer master
		// sheet" for us to read it: if the headings say so, we work it out.
		if ( '' === $bridge ) {
			$bridge = Spreadsheet::guess_bridge( (array) ( $preview['headers'] ?? array() ), $kind );
		}

		$mapping = Spreadsheet::guess_mapping( (array) ( $preview['headers'] ?? array() ), $kind, $bridge );

		/*
		 * The wrong answer to "What is in this file?" is expensive: a sheet of
		 * societies read as properties lands in the property list as names
		 * that are not properties, and the office has to undo an import to
		 * get rid of them. Most of the time the columns themselves settle the
		 * question, so they are asked first — and the answer is only used (and
		 * said out loud on the next screen, with a way back) when the file is
		 * clearly one thing and not the other.
		 */
		$switched_from = '';
		$suggested     = Spreadsheet::guess_kind( (array) ( $preview['headers'] ?? array() ) );
		if ( '' !== $suggested && $suggested !== $kind ) {
			$switched_from = $kind;
			$kind          = $suggested;
			$bridge        = Spreadsheet::guess_bridge( (array) ( $preview['headers'] ?? array() ), $kind );
			$mapping       = Spreadsheet::guess_mapping( (array) ( $preview['headers'] ?? array() ), $kind, $bridge );
		}

		// Store preview in transient for confirm step.
		$transient_key = 'estat_preview_' . get_current_user_id() . '_' . md5( $stored );
		set_transient( $transient_key, array(
			'path'    => $stored,
			'kind'    => $kind,
			'bridge'  => $bridge,
			'headers' => $preview['headers'],
			'rows'    => $preview['rows'],
			'total'   => $preview['total'],
			'mapping' => $mapping,
			// Kept only so the next screen can say what was changed and offer
			// the way back.
			'switched_from' => $switched_from,
		), 30 * MINUTE_IN_SECONDS );

		$redirect = add_query_arg( array(
			'page' => 'estat-spreadsheet',
			'estat_preview' => $transient_key,
		), admin_url( 'admin.php' ) );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Read the same file as a different kind of record.
	 *
	 * The upload box asks what is in the file, and the columns sometimes
	 * disagree. Rather than making the office upload the file again to change
	 * their mind, the preview screen carries one button per direction: this
	 * re-reads the file that is already sitting in the uploads folder, with
	 * the columns guessed again for the other kind, and shows the preview
	 * once more. Nothing is written either way — the button is on the screen
	 * that comes before anything is saved.
	 *
	 * @return void
	 */
	private static function switch_kind(): void {
		self::verify( 'estat_switch_kind' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$preview_key = isset( $_POST['preview_key'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['preview_key'] ) ? '' : $_POST['preview_key'] ) ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$kind  = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_POST['kind'] ) ? '' : $_POST['kind'] ) ) ) : '';
		$kind  = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads' ), 'listings' );
		$base  = admin_url( 'admin.php?page=estat-spreadsheet' );

		$data = '' !== $preview_key ? get_transient( $preview_key ) : false;
		if ( ! $data || empty( $data['path'] ) ) {
			self::redirect( $base, 'error', __( 'Preview expired. Please upload again.', 'estat-os' ) );
		}

		$headers         = (array) ( $data['headers'] ?? array() );
		$data['kind']    = $kind;
		$data['bridge']  = Spreadsheet::guess_bridge( $headers, $kind );
		$data['mapping'] = Spreadsheet::guess_mapping( $headers, $kind, (string) $data['bridge'] );
		// The office has now said what the file is, twice. No notice after
		// this, and no second guess.
		$data['switched_from'] = '';

		set_transient( $preview_key, $data, 30 * MINUTE_IN_SECONDS );

		wp_safe_redirect( add_query_arg( array( 'page' => 'estat-spreadsheet', 'estat_preview' => $preview_key ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * F6: Confirm import after preview — create job with mapping edited by user.
	 *
	 * @return void
	 */
	private static function confirm_import(): void {
		self::verify( 'estat_confirm_import' );
		$base_url = admin_url( 'admin.php?page=estat-spreadsheet' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$preview_key = isset( $_POST['preview_key'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['preview_key']) ? '' : $_POST['preview_key'] ) ) ) : '';
		// Transient key contains prefix, need full sanitization via text.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$preview_key_raw = isset( $_POST['preview_key'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['preview_key']) ? '' : $_POST['preview_key'] ) ) ) : '';
		$preview_key = $preview_key_raw;

		$data = get_transient( $preview_key );
		if ( ! $data || empty( $data['path'] ) ) {
			self::redirect( $base_url, 'error', __( 'Preview expired. Please upload again.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		// The column choices (mapping[3] = price) are a list by design.
		$mapping_input = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] ) ? (array) wp_unslash( $_POST['mapping'] ) : array();
		$mapping = array();
		foreach ( $mapping_input as $col => $header ) {
			$col = sanitize_key( (string) $col );
			$header = sanitize_text_field( (string) $header );
			if ( '' !== $header ) {
				$mapping[ $col ] = $header;
			}
		}

		if ( ! $mapping ) {
			$mapping = $data['mapping'];
		}

		/*
		 * One more answer travels with the job: what to do with a row that
		 * looks like something the office already has. It is asked here,
		 * before anything is written, and it is remembered by the job —
		 * because a long file is finished by a cron run long after this
		 * page was closed.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified at the door.
		$duplicate_mode = isset( $_POST['duplicate_mode'] ) && ! is_array( $_POST['duplicate_mode'] )
			? sanitize_key( wp_unslash( (string) $_POST['duplicate_mode'] ) )
			: 'skip';

		$job_id = Spreadsheet::create_job( (string) $data['path'], (string) $data['kind'], $mapping, (string) ( $data['bridge'] ?? '' ), $duplicate_mode );
		if ( is_wp_error( $job_id ) ) {
			self::redirect( $base_url, 'error', self::first_message( $job_id ) );
		}

		// Dry run first for preview.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$dry = isset( $_POST['dry_run'] ) ? (bool) $_POST['dry_run'] : false;
		if ( $dry ) {
			$dry_result = Spreadsheet::run_job( (int) $job_id, 25.0, true );
			delete_transient( $preview_key );
			$detail = is_wp_error( $dry_result ) ? self::first_message( $dry_result ) : sprintf( __( 'Dry run over the whole file: %1$d would be added, %2$d updated, %3$d skipped, %4$d rows with a problem. Nothing was written.', 'estat-os' ), (int) $dry_result['created'], (int) $dry_result['updated'], (int) $dry_result['skipped'], count( $dry_result['errors'] ?? array() ) );
			self::redirect( $base_url, 'imported', $detail );
		}

		// Read the whole file now, not fifty rows and then a wait for tomorrow.
		$progress = Spreadsheet::run_job( (int) $job_id );
		delete_transient( $preview_key );

		if ( is_wp_error( $progress ) ) {
			self::redirect( $base_url, 'error', self::first_message( $progress ) );
		}

		$detail = (int) ( $progress['processed'] ?? 0 ) >= (int) ( $progress['total'] ?? 0 )
			/* translators: 1: rows added, 2: rows updated, 3: rows skipped, 4: import number */
			? sprintf( __( 'Done: %1$d added, %2$d updated, %3$d skipped. Import #%4$d — you can undo it from Recent imports.', 'estat-os' ), (int) $progress['created'], (int) $progress['updated'], (int) $progress['skipped'], (int) $job_id )
			/* translators: 1: rows added, 2: rows updated, 3: rows skipped, 4: rows still to read, 5: import number */
			: sprintf( __( 'Reading in the background: %1$d added, %2$d updated, %3$d skipped so far, %4$d rows to go. Import #%5$d. You can close this page.', 'estat-os' ), (int) $progress['created'], (int) $progress['updated'], (int) $progress['skipped'], max( 0, (int) ( $progress['total'] ?? 0 ) - (int) ( $progress['processed'] ?? 0 ) ), (int) $job_id );

		self::redirect( $base_url, 'imported', $detail );
	}

	/**
	 * F6: Undo an import job.
	 *
	 * @return void
	 */
	private static function undo_import(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$job_id = isset( $_GET['job_id'] ) ? absint( wp_unslash( is_array($_GET['job_id']) ? '' : $_GET['job_id'] ) ) : 0;
		self::verify( 'estat_undo_import_' . $job_id, 'GET' );
		$url = admin_url( 'admin.php?page=estat-spreadsheet' );

		if ( ! $job_id ) {
			self::redirect( $url, 'error', __( 'Invalid job.', 'estat-os' ) );
		}

		$result = Spreadsheet::undo_job( $job_id );
		if ( is_wp_error( $result ) ) {
			self::redirect( $url, 'error', self::first_message( $result ) );
		}

		$detail = sprintf( __( 'Import undone: %1$d trashed, %2$d restored.', 'estat-os' ), (int) $result['trashed'], (int) $result['restored'] );
		self::redirect( $url, 'imported', $detail );
	}

	/**
	 * F6: Export preview — show first 5 rows before download.
	 *
	 * @return void
	 */
	private static function export_preview(): void {
		self::verify( 'estat_export_csv', 'GET' );
		// The screens' own links say kind=listings / kind=leads while this
		// read `what`, so every export button produced the same file whatever
		// it was pointed at. Both names are read now.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$what = '';
		foreach ( array( 'what', 'kind' ) as $key ) {
			if ( isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ) {
				$what = sanitize_key( wp_unslash( (string) $_GET[ $key ] ) );
				break;
			}
		}
		// phpcs:enable
		if ( '' === $what ) {
			$what = 'listings';
		}
		$preview = Spreadsheet::export_preview( $what, 5 );

		$redirect = add_query_arg( array(
			'page' => 'estat-spreadsheet',
			'estat_export_preview' => $what,
		), admin_url( 'admin.php' ) );

		// Store preview in transient for display.
		set_transient( 'estat_export_preview_' . $what . '_' . get_current_user_id(), $preview, 5 * MINUTE_IN_SECONDS );

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Stream an export.
	 *
	 * @return void
	 */
	private static function export_csv(): void {
		self::verify( 'estat_export_csv', 'GET' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$what = isset( $_GET['what'] ) ? sanitize_key( wp_unslash( is_array($_GET['what']) ? '' : $_GET['what'] ) ) : 'listings';
		if ( 'leads' === $what ) {
			self::export_leads_csv();
			return;
		}
		$csv  = Spreadsheet::export( $what );
		AuditLog::record( 'export.created', 'export', 0, array( 'kind' => $what ) );
		self::send_csv( 'estat-' . $what . '-' . gmdate( 'Y-m-d' ) . '.csv', $csv );
	}

	private static function export_leads_csv(): void {
		self::verify( 'estat_export_csv', 'GET' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$consent_only = ! empty( $_GET['consent_only'] );
		$csv = Leads::export_csv( array(), $consent_only );
		AuditLog::record( 'export.created', 'export', 0, array( 'kind' => 'leads' ) );
		self::send_csv( 'estat-leads-' . gmdate( 'Y-m-d' ) . '.csv', $csv );
	}

	private static function download_ics(): void {
		self::verify( 'estat_download_ics_' . ( isset( $_GET['visit_id'] ) ? absint( wp_unslash( is_array($_GET['visit_id']) ? '' : $_GET['visit_id'] ) ) : 0 ), 'GET' );
		$visit_id = isset( $_GET['visit_id'] ) ? absint( wp_unslash( is_array($_GET['visit_id']) ? '' : $_GET['visit_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$ics = Visits::ics( $visit_id );
		if ( ! $ics ) {
			wp_die( esc_html__( 'That visit could not be found.', 'estat-os' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/calendar; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=visit-' . $visit_id . '.ics' );
		echo $ics; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/**
	 * Send a header-only template file.
	 *
	 * @return void
	 */
	private static function sample_csv(): void {
		self::verify( 'estat_sample_csv', 'GET' );

		// The sample follows what the office is importing: a sheet of societies
		// is no use with a property's columns on it.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, nonce checked above.
		$kind    = isset( $_GET['kind'] ) ? sanitize_key( wp_unslash( is_array( $_GET['kind'] ) ? '' : $_GET['kind'] ) ) : 'listings';
		$kind    = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads' ), 'listings' );
		$columns = array_keys( Spreadsheet::columns( $kind ) );

		$examples = array(
			'listings' => array(
				'"REF-001","3 BHK apartment near the metro","sale","apartment","Green Park","8500000","1450","sqft","3","2"',
			),
			'projects' => array(
				'"SOC-001","Green Park Residency","Gated society with a club and a park.","Sector 48, Gurugram","Green Park Developers","ready","2024-06-30","7500000","18000000","420","35","2 BHK, 3 BHK, 4 BHK","RC/GUR/2019/0123","28.4089","77.0377"',
				'"SOC-002","Sunrise Heights","Two towers, possession next year.","Golf Course Extension","Sunrise Builders","construction","2027-03-31","9500000","22000000","260","120","3 BHK, 4 BHK","","28.4461","77.0965"',
			),
			'agents'   => array(
				'"TM-001","Sunita Rao","Sales consultant","+91 98100 00001","+91 98100 00001","sunita@example.com","Looks after Golf Course Road."',
			),
			'leads'    => array(
				'"Ravi Menon","+91 98100 00002","ravi@example.com","Wants a 3 BHK for rent in Sector 48.","Website form","REF-001"',
			),
		);

		$csv = implode( ',', $columns ) . "\n" . implode( "\n", $examples[ $kind ] ) . "\n";
		self::send_csv( 'estat-sample-' . $kind . '.csv', $csv );
	}

	/* --------------------------------------------------------------------- *
	 * Settings and tools
	 * --------------------------------------------------------------------- */

	/**
	 * Save one tab of settings without disturbing the others.
	 *
	 * @return void
	 */
	private static function save_settings(): void {
		self::verify( 'estat_save_settings' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$tab   = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( is_array($_POST['tab']) ? '' : $_POST['tab'] ) ) : 'office';
		/*
		 * The settings arrive as a group (settings[name] = value), so this is
		 * an array by design. It used to be flattened to a single empty string
		 * on the way in — every box on the screen was read, checked, and then
		 * thrown away, so pressing "Save changes" silently changed nothing at
		 * all. wp_unslash() already walks an array, and every value is checked
		 * again key by key in Settings::sanitize().
		 */
		$input = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		// phpcs:enable

		/*
		 * A ticked box posts, an unticked one posts its hidden 0 — so every
		 * switch the form drew already arrives with an honest answer.
		 *
		 * What used to happen next was not honest: every switch that belongs to
		 * the tab, whether the form carried it or not, was written down as off.
		 * Saving one tab therefore switched off the boxes on the other tabs —
		 * print, sharing, the EMI calculator and the rest — and the office saw
		 * features "stop working" after saving an unrelated setting.
		 *
		 * Only the switches this form actually carried are settled here, and a
		 * form says which ones those are.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$scope = isset( $_POST['estat_flags'] ) ? sanitize_text_field( wp_unslash( is_array( $_POST['estat_flags'] ) ? '' : $_POST['estat_flags'] ) ) : '';
		foreach ( array_filter( array_map( 'trim', explode( ',', $scope ) ) ) as $flag ) {
			$flag = sanitize_key( $flag );
			if ( in_array( $flag, self::tab_flags( $tab ), true ) ) {
				$input[ $flag ] = ! empty( $input[ $flag ] );
			}
		}
		if ( 'advanced' === $tab && ! isset( $input['webhook_events'] ) ) {
			$input['webhook_events'] = array();
		}

		Settings::update( $input );

		// A screen that keeps one switch of its own (Forms shows the Elementor
		// switch) can ask to be taken back to itself after saving.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$back = isset( $_POST['back_url'] ) ? esc_url_raw( wp_unslash( (string) ( is_array( $_POST['back_url'] ) ? '' : $_POST['back_url'] ) ) ) : '';
		$back = $back ? wp_validate_redirect( $back, '' ) : '';
		self::redirect( $back ? $back : admin_url( 'admin.php?page=estat-settings&tab=' . $tab ), 'saved' );
	}

	/**
	 * Checkbox keys per settings tab.
	 *
	 * @param string $tab Tab slug.
	 * @return string[]
	 */
	public static function tab_flags( string $tab ): array {
		// The tab slugs the screens send. Older slugs are kept as aliases so a
		// bookmarked settings page still saves what it always saved.
		switch ( $tab ) {
			case 'general':
			case 'office':
				return array( 'show_regulatory', 'allow_visitor_lang' );
			case 'listings':
			case 'website':
				return array( 'enable_favorites', 'enable_compare', 'enable_schema', 'share_enabled', 'print_enabled', 'emi_enabled', 'locality_pages', 'search_alerts_enabled' );
			case 'leads':
			case 'emails':
				return array( 'notify_new_lead', 'notify_listing_approval', 'notify_daily_summary', 'notify_weekly_report' );
			case 'pocket':
				return array( 'pocket_show_enquiries', 'pocket_agents_edit_live' );
			case 'integrations':
				return array( 'elementor_forms_to_enquiries', 'webhook_retry' );
			case 'advanced':
			case 'tools':
				return array( 'webhook_enabled', 'practice_mode', 'multi_agency', 'delete_data_on_uninstall' );
			default:
				return array();
		}
	}

	/**
	 * Maintenance and practice-mode buttons.
	 *
	 * @param string $action Action key.
	 * @return void
	 */
	private static function tool( string $action ): void {
		self::verify( 'estat_tool_' . $action );
		$url = admin_url( 'admin.php?page=estat-settings&tab=tools' );

		switch ( $action ) {
			case 'rebuild_index':
				$done  = 0;
				$total = 0;
				// Work in bounded batches so shared hosting never times out.
				for ( $i = 0; $i < 25; $i++ ) {
					$count = SearchIndex::rebuild_batch( 200, $done );
					$done += 200;
					$total += $count;
					if ( $count < 200 ) {
						break;
					}
				}
				AuditLog::record( 'maintenance.reindex', 'index', 0, array( 'listings' => $total ) );
				self::redirect(
					$url,
					'index_rebuilt',
					/* translators: %d: number of properties */
					sprintf( __( '%d properties are ready for searching.', 'estat-os' ), $total )
				);
				break;

			case 'repair_tables':
				Schema::install();
				AuditLog::record( 'maintenance.repair', 'schema', 0, array() );
				self::redirect( $url, 'saved', Schema::healthy() ? __( 'The office database looks healthy.', 'estat-os' ) : __( 'Some tables are still missing. Your host can fix this — ask them to let WordPress create the tables it needs.', 'estat-os' ) );
				break;

			case 'clear_cache':
				wp_cache_flush();
				delete_transient( 'estat_stats' );
				delete_transient( 'estat_search_counts' );
				self::redirect( $url, 'saved', __( 'Temporary data cleared.', 'estat-os' ) );
				break;

			case 'purge_caches':
				// This is the button somebody presses when they changed something
				// and the website still shows yesterday. It clears the plugin's
				// own temporary data and asks every cache plugin on the site to
				// start again, so the answer is not "wait and see".
				\EstatOS\Support\Cache::purge_all( 'Requested from Settings' );
				self::redirect( $url, 'saved', __( 'Caches cleared. Open the website and press reload.', 'estat-os' ) );
				break;

			case 'tidy_public_pages':
				// The pages an older version made still carry the office's own
				// note on them, and a search engine prints that note under the
				// site. This is the button that puts the visitor's line back.
				$report = \EstatOS\Frontend\Pages::tidy_old_pages();
				$said   = sprintf(
					/* translators: 1: pages tidied, 2: pages put aside */
					__( '%1$d pages tidied, %2$d old pages put aside as drafts. Open Pages to see them.', 'estat-os' ),
					(int) $report['tidied'],
					(int) $report['aside']
				);
				if ( ! empty( $report['names'] ) ) {
					$said .= ' ' . sprintf(
						/* translators: %s: page names */
						__( 'Set aside: %s', 'estat-os' ),
						implode( ', ', array_map( 'sanitize_text_field', (array) $report['names'] ) )
					);
				}
				self::redirect( $url, 'saved', $said );
				break;

			case 'run_housekeeping':
				Scheduler::run_daily();
				self::redirect( $url, 'saved', __( 'The daily jobs have been run.', 'estat-os' ) );
				break;

			case 'seed_practice':
				$created = PracticeMode::seed();
				Settings::update( array( 'practice_mode' => true ) );
				self::redirect(
					$url,
					'practice_seeded',
					/* translators: %d: number of sample properties */
					sprintf( __( '%d sample properties were added. They are all clearly marked.', 'estat-os' ), (int) ( $created['listings'] ?? 0 ) )
				);
				break;

			case 'clear_practice':
				$removed = PracticeMode::clear();
				Settings::update( array( 'practice_mode' => false ) );
				self::redirect(
					$url,
					'practice_cleared',
					/* translators: %d: number of sample records removed */
					sprintf( __( '%d sample records were removed. Your real data was not touched.', 'estat-os' ), (int) array_sum( array_map( 'intval', $removed ) ) )
				);
				break;

			case 'create_public_pages':
				$created = \EstatOS\Frontend\Pages::create_all( true );
				self::redirect(
					$url,
					'saved',
					sprintf( __( '%d helper pages created. Open Pages to look at them.', 'estat-os' ), count( $created ) )
				);
				break;

			case 'test_mail':
				/*
				 * The office presses this to find out whether email reaches them
				 * at all. Until now the button only had a name in the list of
				 * allowed actions — pressing it did nothing whatsoever.
				 */
				$to = trim( (string) Settings::get( 'notify_email', '' ) );
				if ( '' === $to || ! is_email( $to ) ) {
					$user = wp_get_current_user();
					$to   = (string) $user->user_email;
				}
				if ( '' === $to || ! is_email( $to ) ) {
					self::redirect( $url, 'error', __( 'Add a notification email in this tab first, then press this again.', 'estat-os' ) );
				}
				$sent = wp_mail(
					$to,
					__( 'Test email from your property website', 'estat-os' ),
					__( 'If you got this, your email settings are working.', 'estat-os' )
				);
				if ( $sent ) {
					Settings::update( array( 'test_mail_last_sent' => current_time( 'mysql' ) ) );
					AuditLog::record( 'mail.test_sent', 'settings', 0, array( 'to' => $to ) );
					/* translators: %s: email address the test was sent to. */
					self::redirect( $url, 'saved', sprintf( __( 'Test email sent to %s. Open your inbox and check.', 'estat-os' ), $to ) );
				}
				AuditLog::record( 'mail.test_failed', 'settings', 0, array( 'to' => $to ) );
				self::redirect( $url, 'error', __( 'Email could not be sent. Your host may have switched sending off — ask them to turn it on, or connect an email service.', 'estat-os' ) );
				break;

			case 'repair_broken_data':
				$result = \EstatOS\Install\RepairData::run();
				$msg = sprintf(
					/* translators: 1: fixed count, 2: merged count, 3: drafted count */
					__( 'Repair done: %1$d locality fixed, %2$d locality merged, %3$d pages drafted. Details: %4$s', 'estat-os' ),
					(int) $result['locality_fixed'],
					(int) $result['locality_merged'],
					(int) $result['pages_drafted'],
					implode( ' | ', array_merge( $result['locality_details'], $result['pages_details'] ) )
				);
				AuditLog::record( 'maintenance.repair_data', 'repair', 0, $result );
				self::redirect( $url, 'saved', $msg );
				break;
		}
	}

	/* --------------------------------------------------------------------- *
	 * Helpers
	 * --------------------------------------------------------------------- */

	/**
	 * Check the nonce for an action, or stop.
	 *
	 * @param string $nonce_action Nonce action name.
	 * @param string $method       POST or GET.
	 * @return void
	 */
	/**
	 * Stop unless the request carries a valid key for one of these purposes.
	 *
	 * A single screen can carry more than one legitimate press — the list
	 * has a bar that acts on many records, and the same records have their
	 * own row buttons — and each of those is built by our own screens with
	 * its own word. Accepting the small set of words that belong to the
	 * same screen is what makes the bar and the row buttons both work while
	 * still refusing a request that carries nothing, or something invented.
	 *
	 * @param string[] $nonce_actions Purposes that are acceptable here.
	 * @param string   $method        'POST' or 'GET'.
	 * @return void
	 */
	private static function verify_any( array $nonce_actions, string $method = 'POST' ): void {
		$source = 'GET' === $method ? $_GET : $_POST; // phpcs:ignore WordPress.Security.NonceVerification
		/*
		 * A nonce may arrive under either of two names: the plugin's own
		 * forms use estat_nonce, while links built with wp_create_nonce()
		 * and pasted into a URL carry _wpnonce. Both are the same secret;
		 * reading only one name is how "add to calendar" ended up returning
		 * "that link has expired" on every press.
		 */
		if ( isset( $source['estat_nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $source['estat_nonce'] ) );
		} elseif ( isset( $source['_wpnonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $source['_wpnonce'] ) );
		} else {
			$nonce = '';
		}

		foreach ( $nonce_actions as $nonce_action ) {
			if ( wp_verify_nonce( $nonce, (string) $nonce_action ) ) {
				return;
			}
		}

		wp_die(
			esc_html__( 'That link or form has expired. Please go back, refresh the page and try once more. Nothing was changed.', 'estat-os' ),
			esc_html__( 'Please try again', 'estat-os' ),
			array( 'response' => 403, 'back_link' => true )
		);
	}

	/**
	 * What the request is asking for, whichever way it was sent.
	 *
	 * The office's own screens post `estat_action=save_listing`. The plain
	 * forms — Add a home, Settings — go the WordPress road instead: they post
	 * to admin-post.php with `action=estat_save_listing`, the convention
	 * WordPress itself uses for its `admin_post_{action}` hook.
	 *
	 * Nothing read that second name. Every press of "Save as draft" or
	 * "Publish" on the Add a home screen, and every press of "Save changes"
	 * on Settings, arrived at a handler that had already returned: the form
	 * posted, the page reloaded, and not one field was stored. The button
	 * looked alive and did nothing at all.
	 *
	 * Both names are read now. Anything that is not ours is left alone —
	 * WordPress uses `action=edit`, `action=trash` and so on, and none of
	 * those begin with `estat_`.
	 *
	 * @return string Action key, or '' when this is not one of ours.
	 */
	private static function requested_action(): string {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['estat_action'] ) && ! is_array( $_REQUEST['estat_action'] ) ) {
			return sanitize_key( wp_unslash( (string) $_REQUEST['estat_action'] ) );
		}
		if ( isset( $_REQUEST['action'] ) && ! is_array( $_REQUEST['action'] ) ) {
			$raw = sanitize_key( wp_unslash( (string) $_REQUEST['action'] ) );
			if ( 0 === strpos( $raw, 'estat_' ) ) {
				return substr( $raw, strlen( 'estat_' ) );
			}
		}
		// phpcs:enable
		return '';
	}

	/**
	 * Which of the two save buttons was pressed.
	 *
	 * The buttons on the Add a home screen are `name="save" value="publish"`.
	 * The handler read `estat_save_mode`, so the answer was never heard and
	 * a property was saved as a draft even when the office had pressed
	 * Publish. Both names are read now.
	 *
	 * @return string 'publish', 'draft', or '' when neither was sent.
	 */
	private static function save_mode(): string {
		foreach ( array( 'estat_save_mode', 'save' ) as $key ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ) {
				$mode = sanitize_key( wp_unslash( (string) $_POST[ $key ] ) );
				if ( '' !== $mode ) {
					return $mode;
				}
			}
		}
		return '';
	}

	/**
	 * Everything the form posted, minus the machinery.
	 *
	 * The Add a home screen showed fifteen boxes and the handler kept ten of
	 * them: the photographs, the society, the city and the "price on request"
	 * tick were read off the screen and dropped on the floor. What is on the
	 * screen is what is saved now; anything the data layer does not know is
	 * ignored there, by a rule, rather than here by accident.
	 *
	 * @return array<string,mixed>
	 */
	private static function listing_input(): array {
		$skip = array(
			'estat_action',
			'estat_save_mode',
			'estat_nonce',
			'_wpnonce',
			'_wp_http_referer',
			'action',
			'listing_id',
			'save',
		);
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
		$raw = wp_unslash( $_POST );
		// phpcs:enable
		$out = array();
		foreach ( (array) $raw as $key => $value ) {
			if ( in_array( (string) $key, $skip, true ) ) {
				continue;
			}
			$out[ (string) $key ] = $value;
		}

		// One money box on the screen, two names in the data: the answer to
		// "for sale or rent" decides where the figure belongs.
		if ( array_key_exists( 'price_on_request', $out ) ) {
			if ( ! empty( $out['price_on_request'] ) ) {
				$out['price_type'] = 'on_request';
				$out['price']      = 0;
			} else {
				$out['price_type'] = 'fixed';
			}
			unset( $out['price_on_request'] );
		}

		return $out;
	}

	/**
	 * Stop unless the request carries a valid key for this one purpose.
	 *
	 * @param string $nonce_action Purpose.
	 * @param string $method       'POST' or 'GET'.
	 * @return void
	 */
	private static function verify( string $nonce_action, string $method = 'POST' ): void {
		self::verify_any( array( $nonce_action ), $method );
	}

	/**
	 * Collect a known set of POST fields without sanitising them here;
	 * the data layer sanitises every value against its own schema.
	 *
	 * @param string[] $keys Field names.
	 * @return array<string,mixed>
	 */
	private static function post_fields( array $keys ): array {
		$out = array();
		foreach ( $keys as $key ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
			if ( isset( $_POST[ $key ] ) ) {
				$out[ $key ] = wp_unslash( is_array($_POST[ $key ]) ? '' : $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			}
		}
		return $out;
	}

	/**
	 * One positive integer from POST.
	 *
	 * @param string $key Field name.
	 * @return int
	 */
	private static function int_post( string $key ): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? absint( wp_unslash( is_array($_POST[ $key ]) ? '' : $_POST[ $key ] ) ) : 0;
	}

	/**
	 * The first friendly message from an error object.
	 *
	 * @param WP_Error $error Error.
	 * @return string
	 */
	private static function first_message( WP_Error $error ): string {
		$message = $error->get_error_message();
		return '' !== $message ? $message : __( 'Something went wrong and nothing was saved.', 'estat-os' );
	}

	/**
	 * Where to send someone back to when we cannot tell.
	 *
	 * @return string
	 */
	private static function back(): string {
		$referer = wp_get_referer();
		return $referer ? $referer : admin_url( 'admin.php?page=estat-today' );
	}

	/**
	 * Redirect with a notice and stop.
	 *
	 * @param string $url    Destination.
	 * @param string $notice Notice key.
	 * @param string $detail Optional detail line.
	 * @return void
	 */
	/* --------------------------------------------------------------------- *
	 * Data health and list names
	 * --------------------------------------------------------------------- */

	/**
	 * The "these records need filling" list as a spreadsheet, so it can be
	 * worked through in Excel and imported back (the reference number is what
	 * makes the import an update instead of a second property).
	 *
	 * @return void
	 */
	private static function health_csv(): void {
		self::verify( 'estat_health_csv', 'GET' );
		$rows = \EstatOS\Data\Health::attention( 300 );
		self::send_csv( 'properties-to-fix-' . gmdate( 'Ymd' ) . '.csv', \EstatOS\Data\Health::csv( $rows ) );
	}

	/**
	 * Merge one term into another and remove the first.
	 *
	 * This is how a locality name that an import cut in half ("Sohna Road
	 * (Sector 49") is put right: every record moves onto the name that stays,
	 * then the broken name is deleted. Nothing else is deleted.
	 *
	 * @return void
	 */
	private static function merge_terms(): void {
		self::verify( 'estat_merge_terms' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( is_array( $_POST['taxonomy'] ) ? '' : $_POST['taxonomy'] ) ) : '';
		$from     = isset( $_POST['merge_from'] ) ? absint( wp_unslash( is_array( $_POST['merge_from'] ) ? '' : $_POST['merge_from'] ) ) : 0;
		$into     = isset( $_POST['into'] ) && is_array( $_POST['into'] ) ? array_map( 'absint', wp_unslash( $_POST['into'] ) ) : array();
		// phpcs:enable

		$allowed = array( \EstatOS\Data\Taxonomies::LOCALITY, \EstatOS\Data\Taxonomies::AMENITY, \EstatOS\Data\Taxonomies::FEATURE );
		$back    = admin_url( 'admin.php?page=estat-spreadsheet' );
		if ( ! in_array( $taxonomy, $allowed, true ) ) {
			self::redirect( $back, 'error', __( 'That is not a list this tool can tidy.', 'estat-os' ) );
		}
		$target = isset( $into[ $from ] ) ? (int) $into[ $from ] : 0;
		if ( $from <= 0 || $target <= 0 || $from === $target ) {
			self::redirect( $back, 'error', __( 'Choose the name that should stay before pressing Merge.', 'estat-os' ) );
		}

		$source_term = get_term( $from, $taxonomy );
		$target_term = get_term( $target, $taxonomy );
		if ( ! $source_term instanceof \WP_Term || ! $target_term instanceof \WP_Term ) {
			self::redirect( $back, 'error', __( 'One of those two names no longer exists.', 'estat-os' ) );
		}

		$moved = 0;
		foreach ( array( \EstatOS\Data\PostTypes::LISTING, \EstatOS\Data\PostTypes::PROJECT ) as $post_type ) {
			$ids = get_posts(
				array(
					'post_type'      => $post_type,
					'post_status'    => 'any',
					'posts_per_page' => 500,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => $taxonomy,
							'field'    => 'term_id',
							'terms'    => $from,
						),
					),
				)
			);
			foreach ( $ids as $id ) {
				$result = wp_set_object_terms( (int) $id, array( $target ), $taxonomy, true );
				if ( ! is_wp_error( $result ) ) {
					wp_remove_object_terms( (int) $id, array( $from ), $taxonomy );
					$moved++;
				}
			}
		}

		$old_name = (string) $source_term->name;
		$new_name = (string) $target_term->name;
		wp_delete_term( $from, $taxonomy );
		AuditLog::record( 'term.merged', $taxonomy, $target, array( 'from' => $old_name, 'into' => $new_name, 'moved' => $moved ) );

		/* translators: 1: old name, 2: new name, 3: number of records moved */
		self::redirect( $back, 'merged', sprintf( __( 'Done: "%1$s" is now "%2$s". %3$d records moved.', 'estat-os' ), $old_name, $new_name, $moved ) );
	}

	private static function redirect( string $url, string $notice, string $detail = '', string $undo_token = '' ): void {
		$args = array( 'estat_notice' => $notice );
		if ( '' !== $detail ) {
			// add_query_arg() encodes on its own; encoding here as well meant
			// the words arrived with %20 and %E2%80%94 in them, on the rare
			// screens that did try to show them.
			$args['estat_detail'] = $detail;
		}
		/*
		 * A sweep can be taken back, but only if the offer travels with the
		 * answer. The token was being handed to this function and quietly
		 * dropped — so the notice promised "Press Undo" and there was no
		 * Undo to press. It rides in the address now, and the notices on
		 * the next screen pick it up.
		 */
		if ( '' !== $undo_token ) {
			$args['estat_undo'] = $undo_token;
		}
		wp_safe_redirect( add_query_arg( $args, $url ) );
		exit;
	}

	/**
	 * Send a CSV download and stop.
	 *
	 * @param string $filename File name.
	 * @param string $csv      File body.
	 * @return void
	 */
	private static function send_csv( string $filename, string $csv ): void {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . sanitize_file_name( $filename ) );
		header( 'Content-Length: ' . strlen( $csv ) );
		// Excel opens UTF-8 correctly only with a byte order mark.
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}
}
