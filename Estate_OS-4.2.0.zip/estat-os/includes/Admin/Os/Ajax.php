<?php
/**
 * Answers the interface without leaving the page.
 *
 * When somebody opens a property in the side drawer, drags a card across
 * the pipeline, or approves a change request, the screen must not reload.
 * These are the small questions and answers that make that possible.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os;

use EstatOS\Csv\Spreadsheet;
use EstatOS\Data\Agents;
use EstatOS\Data\Bin;
use EstatOS\Data\Duplicate;
use EstatOS\Data\Listings;
use EstatOS\Data\Media;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Data\Taxonomies;
use EstatOS\Data\Templates;
use EstatOS\Forms\Forms;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;
use EstatOS\Support\Comparison;
use EstatOS\Support\Format;
use EstatOS\Support\Status;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class Ajax {

	/** Every question the office asks from the browser. */
	private const ACTIONS = array(
		'estat_os_drawer'   => 'drawer',
		'estat_os_action'   => 'act',
		'estat_os_save'     => 'save',
		'estat_os_upload'   => 'upload',
		'estat_os_search'   => 'search',
	);

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		foreach ( array_keys( self::ACTIONS ) as $action ) {
			add_action( 'wp_ajax_' . $action, array( __CLASS__, 'handle' ) );
		}
	}

	/**
	 * One door in, one place to check the person is allowed through it.
	 *
	 * @return void
	 */
	public static function handle(): void {
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'Please sign in again.', 'estat-os' ) ), 401 );
		}
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action = isset( $_POST['os_action'] ) ? sanitize_key( wp_unslash( (string) $_POST['os_action'] ) ) : '';
		if ( '' === $action ) {
			// Fall back to the registered action name.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( (string) $_POST['action'] ) ) : '';
			$action = self::ACTIONS[ $raw ] ?? '';
		}

		if ( ! isset( array_flip( self::ACTIONS )[ $action ] ) && ! in_array( $action, self::ACTIONS, true ) ) {
			wp_send_json_error( array( 'message' => __( 'That request was not understood.', 'estat-os' ) ), 400 );
		}

		$method = array( __CLASS__, $action );
		if ( ! is_callable( $method ) ) {
			wp_send_json_error( array( 'message' => __( 'That request was not understood.', 'estat-os' ) ), 400 );
		}

		call_user_func( $method );
	}

	/* ------------------------------------------------------------------ read */

	/**
	 * The right-hand drawer. One screen's worth of a record, no page load.
	 *
	 * @return void
	 */
	private static function drawer(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) $_POST['kind'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id   = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$ids  = isset( $_POST['ids'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['ids'] ) ? '' : $_POST['ids'] ) ) ) : '';

		if ( '' !== $ids ) {
			$ids = implode( ',', array_slice( array_filter( array_map( 'absint', explode( ',', $ids ) ) ), 0, 4 ) );
		}

		$out = array( 'title' => '', 'html' => '', 'foot' => '' );

		switch ( $kind ) {
			case 'listing':
			case 'property':
				$out = self::drawer_listing( $id );
				break;
			case 'project':
				$out = self::drawer_project( $id );
				break;
			case 'lead':
			case 'enquiry':
				$out = self::drawer_lead( $id );
				break;
			case 'visit':
				$out = self::drawer_visit( $id );
				break;
			case 'agent':
			case 'member':
				$out = self::drawer_agent( $id );
				break;
			case 'source':
				$out = self::drawer_source( $id );
				break;
			case 'compare':
				$out = self::drawer_compare();
				break;
			default:
				wp_send_json_error( array( 'message' => __( 'Nothing to show.', 'estat-os' ) ), 404 );
		}

		wp_send_json_success( $out );
	}

	/**
	 * A property, in full.
	 *
	 * @param int $id Property.
	 * @return array<string,string>
	 */
	private static function drawer_listing( int $id ): array {
		$post = get_post( $id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type || ! current_user_can( 'estat_manage_listings' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}

		$data  = Listings::to_array( $id, true );
		$done  = Listings::completeness( $id );
		$cover = get_the_post_thumbnail_url( $id, 'large' );

		ob_start();
		echo '<div class="dr__hero">';
		if ( $cover ) {
			printf( '<div class="dr__img" style="background-image:url(%1$s)"></div>', esc_url( $cover ) );
		}
		echo '<div class="dr__hero__b">';
		echo '<h3>' . esc_html( get_the_title( $post ) ) . '</h3>';
		printf( '<div class="mut">%1$s</div>', esc_html( (string) ( $data['locality'] ?? '' ) ) );
		echo '<div style="margin-top:var(--s3);display:flex;gap:var(--s2);flex-wrap:wrap">';
		echo Ui::status_badge( Status::PUBLICATION, (string) $post->post_status );
		echo Ui::status_badge( Status::AVAILABILITY, (string) ( $data['availability'] ?? 'available' ) );
		echo '</div></div></div>';

		echo '<div class="dr__b">';

		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Price', 'estat-os' ),
			esc_html( (string) ( $data['price_display'] ?? Format::price_range( (float) ( $data['price'] ?? 0 ), (float) ( $data['price'] ?? 0 ), (string) ( $data['offer'] ?? 'sale' ) ) ) )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Size', 'estat-os' ),
			esc_html( Format::area( (float) ( $data['area'] ?? 0 ), (string) ( $data['area_unit'] ?? 'sqft' ) ) )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Bedrooms', 'estat-os' ),
			esc_html( '' === (string) ( $data['bedrooms'] ?? '' ) ? '—' : (string) $data['bedrooms'] )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Reference', 'estat-os' ),
			esc_html( (string) ( $data['ref'] ?? '' ) ?: '—' )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Society', 'estat-os' ),
			esc_html( (string) ( $data['project_name'] ?? '' ) ?: '—' )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Handled by', 'estat-os' ),
			esc_html( (string) ( $data['agent_name'] ?? '' ) ?: '—' )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'On the market for', 'estat-os' ),
			/* translators: %s: how long. */
			esc_html( sprintf( __( '%s days', 'estat-os' ), (string) Listings::days_listed( $id ) ) )
		);

		echo '<div class="divider"></div>';
		printf( '<div class="lbl" style="margin-bottom:var(--s2)">%1$s</div>', esc_html__( 'How complete the record is', 'estat-os' ) );
		echo Ui::meter( (int) ( $done['percent'] ?? 0 ) );
		printf( '<div class="mut" style="font-size:var(--fs-meta);margin-top:var(--s2)">%1$s</div>', esc_html( (string) ( $done['label'] ?? '' ) ) );

		echo '</div>';

		$foot  = '<a class="btn btn--ghost" href="' . esc_url( admin_url( 'admin.php?page=estat-add-home&edit=' . $id ) ) . '">';
		$foot .= esc_html__( 'Open and edit', 'estat-os' ) . '</a>';
		$foot .= '<a class="btn btn--bronze" href="' . esc_url( (string) get_permalink( $id ) ) . '">';
		$foot .= esc_html__( 'See it on the website', 'estat-os' ) . '</a>';

		return array(
			'title' => (string) get_the_title( $post ),
			'html'  => (string) ob_get_clean(),
			'foot'  => $foot,
		);
	}

	/**
	 * A society or project, in full.
	 *
	 * @param int $id Project.
	 * @return array<string,string>
	 */
	private static function drawer_project( int $id ): array {
		if ( ! current_user_can( 'estat_manage_projects' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}

		$post = $id > 0 ? get_post( $id ) : null;
		if ( $id > 0 && ( ! $post || PostTypes::PROJECT !== $post->post_type ) ) {
			return array(
				'title' => '',
				'html'  => '<div class="dr__b"><div class="mut">' . esc_html__( 'That society or project is no longer here.', 'estat-os' ) . '</div></div>',
				'foot'  => '',
			);
		}

		/*
		 * Reading the record through the same door the website uses, so the
		 * form always shows the words the public page would show — and a
		 * blank sheet when this is a new one.
		 */
		$data = $post && method_exists( Projects::class, 'to_array' ) ? Projects::to_array( $id ) : array();

		$meta = function ( string $key, string $fallback = '' ) use ( $id, $data ) {
			if ( array_key_exists( $key, $data ) && '' !== (string) $data[ $key ] ) {
				return (string) $data[ $key ];
			}
			if ( $id > 0 ) {
				$raw = (string) get_post_meta( $id, '_estat_' . $key, true );
				if ( '' !== $raw ) {
					return $raw;
				}
			}
			return $fallback;
		};

		$localities = $id > 0 ? wp_get_post_terms( $id, Taxonomies::LOCALITY, array( 'fields' => 'names' ) ) : array();
		if ( is_wp_error( $localities ) ) {
			$localities = array();
		}
		$locality = implode( ', ', (array) $localities );

		ob_start();
		echo '<div class="dr__b">';

		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html( $id > 0
				? __( 'Change whatever is wrong and press Save. Nothing reaches the website until you do.', 'estat-os' )
				: __( 'A new society or project. Name it, fill in what you know, and press Save.', 'estat-os' ) )
		);

		printf(
			'<div class="field"><label class="field__lbl" for="pf-title">%1$s</label>'
			. '<input class="in" id="pf-title" name="title" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Name of the society or project', 'estat-os' ),
			esc_attr( $post ? (string) $post->post_title : '' ),
			esc_attr__( 'For example: Trehan Iris Broadway', 'estat-os' )
		);

		/*
		 * The cover photograph.
		 *
		 * A project without one is a grey card in a row of grey cards, so
		 * the picker sits directly under the name rather than at the
		 * bottom where nobody reaches it.
		 */
		$cover_id  = $post ? (int) get_post_thumbnail_id( $id ) : 0;
		$cover_url = $cover_id ? (string) get_the_post_thumbnail_url( $id, 'medium' ) : '';

		echo '<div class="field"><label class="field__lbl" for="pf-cover">'
			. esc_html__( 'Cover photo', 'estat-os' ) . '</label><div class="pickrow">';
		printf(
			'<span class="pickprev%1$s" data-cover-prev%2$s></span>',
			$cover_url ? ' is-on' : '',
			$cover_url ? ' style="background-image:url(' . esc_url( $cover_url ) . ')"' : ''
		);
		printf( '<input type="hidden" id="pf-cover" name="cover_id" value="%1$d">', $cover_id );
		echo '<span class="pickrow__b">'
			. '<button type="button" class="btn btn--sm" data-pick="cover" data-target="cover_id" data-multiple="0">'
			. esc_html__( 'Choose photo', 'estat-os' ) . '</button>'
			. '<button type="button" class="btn btn--sm btn--ghost" data-clear-pick data-target="cover_id">'
			. esc_html__( 'Remove', 'estat-os' ) . '</button></span></div>';
		echo '<p class="mut" style="margin:6px 0 0">'
			. esc_html__( 'The photograph at the top of the project page, and the one on its card.', 'estat-os' )
			. '</p></div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="pf-dev">%1$s</label>'
			. '<input class="in" id="pf-dev" name="developer" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Builder or developer', 'estat-os' ),
			esc_attr( $meta( 'developer' ) ),
			esc_attr__( 'Who is building it', 'estat-os' )
		);
		echo '<div class="field"><label class="field__lbl" for="pf-stage">' . esc_html__( 'Stage', 'estat-os' ) . '</label>'
			. '<select class="in" id="pf-stage" name="project_status">';
		$stage_now = (string) $meta( 'project_status', (string) $meta( 'stage' ) );
		printf( '<option value=""%1$s>%2$s</option>', selected( $stage_now, '', false ), esc_html__( 'Not said yet', 'estat-os' ) );
		foreach ( Vocabulary::construction() as $key => $word ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $key ), selected( $stage_now, $key, false ), esc_html( $word ) );
		}
		echo '</select></div>';
		echo '</div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="pf-kind">%1$s</label>'
			. '<input class="in" id="pf-kind" name="project_type" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'What kind of homes or units', 'estat-os' ),
			esc_attr( $meta( 'project_type' ) ),
			esc_attr__( 'Apartments, floors, shops…', 'estat-os' )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="pf-loc">%1$s</label>'
			. '<input class="in" id="pf-loc" name="locality" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Locality', 'estat-os' ),
			esc_attr( $locality ),
			esc_attr__( 'Sector 57, Gurugram', 'estat-os' )
		);
		echo '</div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="pf-pmin">%1$s</label>'
			. '<input class="in" id="pf-pmin" name="price_min" inputmode="numeric" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Price from', 'estat-os' ),
			esc_attr( $meta( 'price_min' ) ),
			esc_attr__( '18500000', 'estat-os' )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="pf-pmax">%1$s</label>'
			. '<input class="in" id="pf-pmax" name="price_max" inputmode="numeric" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Price up to', 'estat-os' ),
			esc_attr( $meta( 'price_max' ) ),
			esc_attr__( '34000000', 'estat-os' )
		);
		echo '</div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="pf-units">%1$s</label>'
			. '<input class="in" id="pf-units" name="total_units" inputmode="numeric" value="%2$s"></div>',
			esc_html__( 'Total homes or units', 'estat-os' ),
			esc_attr( $meta( 'total_units' ) )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="pf-avail">%1$s</label>'
			. '<input class="in" id="pf-avail" name="available_units" inputmode="numeric" value="%2$s"></div>',
			esc_html__( 'Still available', 'estat-os' ),
			esc_attr( $meta( 'available_units' ) )
		);
		echo '</div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="pf-poss">%1$s</label>'
			. '<input class="in" id="pf-poss" name="possession_date" value="%2$s" placeholder="%3$s"></div>',
			esc_html__( 'Possession', 'estat-os' ),
			esc_attr( $meta( 'possession_date' ) ),
			esc_attr__( 'March 2027', 'estat-os' )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="pf-status">%1$s</label>'
			. '<select class="in" id="pf-status" name="status">',
			esc_html__( 'Where it stands', 'estat-os' )
		);
		$status_now = $post ? (string) $post->post_status : 'draft';
		printf( '<option value="publish"%1$s>%2$s</option>', selected( $status_now, 'publish', false ), esc_html__( 'On the website', 'estat-os' ) );
		printf( '<option value="draft"%1$s>%2$s</option>', selected( $status_now, 'draft', false ), esc_html__( 'Not on the website yet', 'estat-os' ) );
		echo '</select></div>';
		echo '</div>';

		printf(
			'<div class="field"><label class="field__lbl" for="pf-addr">%1$s</label>'
			. '<input class="in" id="pf-addr" name="address" value="%2$s"></div>',
			esc_html__( 'Address', 'estat-os' ),
			esc_attr( $meta( 'address' ) )
		);

		printf(
			'<div class="field"><label class="field__lbl" for="pf-desc">%1$s</label>'
			. '<textarea class="in" id="pf-desc" name="description" rows="5" style="min-height:110px">%2$s</textarea></div>',
			esc_html__( 'What should be said about it', 'estat-os' ),
			esc_textarea( $post ? (string) $post->post_content : '' )
		);

		/*
		 * The gallery.
		 *
		 * The same photographs the website shows, picked from the media
		 * library the office already keeps them in — not a second upload
		 * area with its own copies.
		 */
		$raw = $id > 0 ? get_post_meta( $id, '_estat_gallery', true ) : '';
		$raw = is_array( $raw ) ? $raw : explode( ',', (string) $raw );
		$gal = array_values( array_unique( array_filter( array_map( 'absint', (array) $raw ) ) ) );

		$tiles = '';
		foreach ( $gal as $aid ) {
			$thumb = (string) wp_get_attachment_image_url( $aid, 'thumbnail' );
			if ( '' === $thumb ) {
				continue;
			}
			$tiles .= '<span class="picktile" data-tile="' . (int) $aid . '" style="background-image:url(' . esc_url( $thumb ) . ')">'
				. '<button type="button" class="picktile__x" data-rm-pick="' . (int) $aid . '" data-target="gallery" aria-label="'
				. esc_attr__( 'Remove this photo', 'estat-os' ) . '">&times;</button></span>';
		}

		echo '<div class="field"><label class="field__lbl">' . esc_html__( 'Photo gallery', 'estat-os' ) . '</label>';
		printf( '<input type="hidden" name="gallery" value="%1$s">', esc_attr( implode( ',', $gal ) ) );
		printf( '<div class="pickgrid" data-gal-grid data-target="gallery">%1$s</div>', $tiles );
		echo '<button type="button" class="btn btn--sm" data-pick="gallery" data-target="gallery" data-multiple="1">'
			. esc_html__( 'Add photos', 'estat-os' ) . '</button></div>';

		echo '</div>';

		$foot  = '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>';
		$foot .= '<button type="button" class="btn btn--bronze" data-act="save-project" data-id="' . $id . '">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		if ( $post ) {
			$foot .= '<a class="btn btn--primary" href="' . esc_url( (string) get_permalink( $id ) ) . '" target="_blank" rel="noopener">'
				. esc_html__( 'See it on the website', 'estat-os' ) . '</a>';
		}

		return array(
			'title' => $post ? (string) $post->post_title : __( 'Add a society or project', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => $foot,
		);
	}

	/**
	 * Compare — the pick list, and then the answer.
	 *
	 * One drawer, two states. With nothing picked it lists the office's own
	 * properties with a tick beside each; with two to four picked it puts
	 * them side by side and asks the same ten questions of every one. The
	 * questions live here, once, so an agent's screen and an owner's screen
	 * cannot disagree about what "comparable" means.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_compare(): array {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw  = isset( $_POST['ids'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['ids'] ) ? '' : $_POST['ids'] ) ) ) : '';
		$picked = array_values( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
		$picked = array_slice( array_unique( $picked ), 0, 4 );

		if ( count( $picked ) >= 2 ) {
			return self::compare_table( $picked );
		}

		$found = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 60,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'Tick two, three or four homes and press Compare. They are put beside each other with the same questions asked of every one.', 'estat-os' )
		);

		if ( ! $found ) {
			echo '<div class="empty"><div class="empty__t">' . esc_html__( 'No properties yet', 'estat-os' ) . '</div>'
				. '<div class="empty__d">' . esc_html__( 'Add a home first, then there is something to compare.', 'estat-os' ) . '</div></div></div>';
			return array( 'title' => __( 'Compare', 'estat-os' ), 'html' => (string) ob_get_clean(), 'foot' => '' );
		}

		echo '<div class="cmp__pick">';
		foreach ( $found as $home ) {
			$id    = (int) $home->ID;
			$money = (string) get_post_meta( $id, '_estat_price', true );
			printf(
				'<label class="cmp__pickrow"><input type="checkbox" class="cmp-pick" value="%1$d">'
				. '<span class="cmp__pickn"><b>%2$s</b><i>%3$s</i></span>'
				. '<span class="cmp__pickp">%4$s</span></label>',
				$id,
				esc_html( get_the_title( $id ) ),
				esc_html( (string) ( Format::money( (float) $money ) ?: __( 'No price', 'estat-os' ) ) ),
				esc_html( (string) get_post_status( $id ) )
			);
		}
		echo '</div></div>';

		return array(
			'title' => __( 'Compare properties', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="compare-run">' . esc_html__( 'Compare', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * The same ten questions, asked of every property.
	 *
	 * @param int[] $ids Two to four property IDs.
	 * @return array<string,string>
	 */
	private static function compare_table( array $ids ): array {
		// One list, written down once, shared with the pocket and the website.
		$questions = Comparison::questions();

		$cols = '';
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
				continue;
			}

			$facts = Comparison::facts( $id );

			$rows = '';
			foreach ( $questions as $key => $word ) {
				$value = trim( (string) $facts[ $key ] );
				$rows .= '<div class="cmp__row"><span>' . esc_html( $word ) . '</span><b>'
					. ( '' !== $value ? esc_html( $value ) : '<i class="mut">' . esc_html__( 'not said', 'estat-os' ) . '</i>' )
					. '</b></div>';
			}

			$cover = get_the_post_thumbnail( $id, 'medium' );
			$cols .= '<div class="cmp__col">'
				. '<button type="button" class="cmp__head" data-drawer="listing" data-id="' . $id . '">'
				. '<span class="cmp__cov' . ( $cover ? '' : ' is-empty' ) . '">' . $cover . '</span>'
				. '<b>' . esc_html( get_the_title( $id ) ) . '</b></button>' . $rows . '</div>';
		}

		$return = array_map( 'absint', $ids );

		return array(
			'title' => __( 'Side by side', 'estat-os' ),
			'html'  => '<div class="dr__b"><div class="cmp" style="--cols:' . count( $return ) . '">' . $cols . '</div></div>',
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Close', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="compare-pick" data-ids="' . esc_attr( implode( ',', $return ) ) . '">'
				. esc_html__( 'Pick different ones', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * A blank enquiry sheet — what the Add button on Enquiries opens.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_lead_new(): array {
		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'An enquiry somebody made by phone, at the desk, or on the website. Name and one way to reach them is enough.', 'estat-os' )
		);

		printf(
			'<div class="field"><label class="field__lbl" for="lf-name">%1$s</label>'
			. '<input class="in" id="lf-name" name="name" value="" placeholder="%2$s"></div>',
			esc_html__( 'Name', 'estat-os' ),
			esc_attr__( 'Who is it', 'estat-os' )
		);

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="lf-phone">%1$s</label>'
			. '<input class="in" id="lf-phone" name="phone" inputmode="tel" value="" placeholder="%2$s"></div>',
			esc_html__( 'Phone', 'estat-os' ),
			esc_attr__( '+91 98765 43210', 'estat-os' )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="lf-email">%1$s</label>'
			. '<input class="in" id="lf-email" name="email" type="email" value="" placeholder="%2$s"></div>',
			esc_html__( 'Email', 'estat-os' ),
			esc_attr__( 'name@example.com', 'estat-os' )
		);
		echo '</div>';

		printf(
			'<div class="field"><label class="field__lbl" for="lf-msg">%1$s</label>'
			. '<textarea class="in" id="lf-msg" name="message" rows="3" style="min-height:80px" placeholder="%2$s"></textarea></div>',
			esc_html__( 'What they are after', 'estat-os' ),
			esc_attr__( '3 BHK in Sector 57, ready to move', 'estat-os' )
		);

		printf( '<input type="hidden" name="status" value="%1$s">', esc_attr( 'new' ) );
		printf( '<input type="hidden" name="source" value="%1$s">', esc_attr( 'office' ) );
		echo '</div>';

		return array(
			'title' => __( 'New enquiry', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="save-lead" data-id="0">' . esc_html__( 'Add the enquiry', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * A blank visit sheet — what the Add button on Visits opens.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_visit_new(): array {
		$leads = Leads::query( array( 'per_page' => 60, 'page' => 1 ) );
		$opts  = '<option value="0">' . esc_html__( 'Nobody in particular', 'estat-os' ) . '</option>';
		foreach ( (array) ( $leads['items'] ?? array() ) as $lead ) {
			$name = trim( (string) ( $lead['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$phone = trim( (string) ( $lead['phone'] ?? '' ) );
			$opts .= '<option value="' . (int) $lead['id'] . '">' . esc_html( $name . ( '' !== $phone ? ' · ' . $phone : '' ) ) . '</option>';
		}

		$homes = '<option value="0">' . esc_html__( 'No property named', 'estat-os' ) . '</option>';
		$found = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => 60,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		foreach ( (array) $found as $home ) {
			$homes .= '<option value="' . (int) $home->ID . '">' . esc_html( (string) $home->post_title ) . '</option>';
		}

		$soon = gmdate( 'Y-m-d H:i', time() + 2 * HOUR_IN_SECONDS );

		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'Book a visit. Pick who is coming and where, then say when.', 'estat-os' )
		);

		echo '<div class="field"><label class="field__lbl" for="vf-lead">' . esc_html__( 'Who is coming', 'estat-os' ) . '</label>'
			. '<select class="in" id="vf-lead" name="lead_id">' . $opts . '</select></div>';

		echo '<div class="field"><label class="field__lbl" for="vf-home">' . esc_html__( 'Which property', 'estat-os' ) . '</label>'
			. '<select class="in" id="vf-home" name="listing_id">' . $homes . '</select></div>';

		printf(
			'<div class="field"><label class="field__lbl" for="vf-when">%1$s</label>'
			. '<input class="in" id="vf-when" name="scheduled_at" type="datetime-local" value="%2$s"></div>',
			esc_html__( 'Date and time', 'estat-os' ),
			esc_attr( $soon )
		);
		echo '</div>';

		return array(
			'title' => __( 'Schedule a visit', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="save-visit" data-id="0">' . esc_html__( 'Book the visit', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * An enquiry, in full.
	 *
	 * @param int $id Lead.
	 * @return array<string,string>
	 */
	private static function drawer_lead( int $id ): array {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}
		$lead = $id > 0 ? Leads::get( $id ) : null;
		if ( $id > 0 && ! $lead ) {
			wp_send_json_error( array( 'message' => __( 'That enquiry is no longer here.', 'estat-os' ) ), 404 );
		}

		if ( 0 === $id ) {
			return self::drawer_lead_new();
		}

		ob_start();
		echo '<div class="dr__b">';
		foreach ( array(
			'name'    => __( 'Name', 'estat-os' ),
			'phone'   => __( 'Phone', 'estat-os' ),
			'email'   => __( 'Email', 'estat-os' ),
			'source'  => __( 'Where it came from', 'estat-os' ),
			'message' => __( 'What they said', 'estat-os' ),
			'budget'  => __( 'Budget', 'estat-os' ),
		) as $key => $word ) {
			$value = (string) ( $lead[ $key ] ?? '' );
			if ( '' === $value ) {
				continue;
			}
			printf(
				'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
				esc_html( $word ),
				esc_html( $value )
			);
		}
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Stage', 'estat-os' ),
			Ui::status_badge( Status::LEAD, (string) ( $lead['status'] ?? 'new' ) )
		);
		echo '</div>';

		$phone = (string) ( $lead['phone'] ?? '' );
		$foot  = '';
		if ( '' !== $phone ) {
			$foot .= '<a class="btn btn--ghost" href="https://wa.me/' . esc_attr( preg_replace( '/\D/', '', $phone ) ) . '" target="_blank" rel="noopener">';
			$foot .= esc_html__( 'WhatsApp', 'estat-os' ) . '</a>';
			$foot .= '<a class="btn btn--ghost" href="tel:' . esc_attr( $phone ) . '">' . esc_html__( 'Call', 'estat-os' ) . '</a>';
		}
		/*
		 * The history, printed on the card.
		 *
		 * Every change to an enquiry is written down — a stage moved, a visit
		 * booked, a note added — and until now the desk could not read any of
		 * it: the only screen that showed the history was the phone app. This
		 * is the same list, same words, in the drawer. It is printed here
		 * rather than fetched, so opening an enquiry is still one request.
		 */
		$events = \EstatOS\Leads\LeadEvents::for_lead( $id );
		if ( $events ) {
			echo '<div class="divider"></div>';
			echo '<h3 class="dr__h">' . esc_html__( 'History', 'estat-os' ) . '</h3>';
			echo '<ol class="dr__story">';
			foreach ( array_slice( $events, 0, 20 ) as $event ) {
				$stamp = (string) ( $event['created_at'] ?? '' );
				$when  = '' !== $stamp ? \EstatOS\Support\Format::date( $stamp ) . ' ' . \EstatOS\Support\Format::time( $stamp ) : '';
				printf(
					'<li class="dr__storyrow"><span class="dr__storydot"></span><span class="dr__storytext">%1$s</span><span class="dr__storywhen">%2$s</span></li>',
					esc_html( \EstatOS\Leads\LeadEvents::words( $event ) ),
					esc_html( $when )
				);
			}
			echo '</ol>';
			if ( count( $events ) > 20 ) {
				printf(
					'<p class="mut" style="font-size:var(--fs-meta)">%s</p>',
					esc_html( sprintf(
						/* translators: %d: how many older entries are not shown. */
						__( '%d older entries are kept in the log.', 'estat-os' ),
						count( $events ) - 20
					) )
				);
			}
		}

		$foot .= '<button type="button" class="btn btn--bronze" data-act="lead-advance" data-id="' . (int) $id . '">';
		$foot .= esc_html__( 'Move on a stage', 'estat-os' ) . '</button>';

		return array(
			'title' => (string) ( $lead['name'] ?? __( 'Enquiry', 'estat-os' ) ),
			'html'  => (string) ob_get_clean(),
			'foot'  => $foot,
		);
	}

	/**
	 * A site visit, in full.
	 *
	 * @param int $id Visit.
	 * @return array<string,string>
	 */
	private static function drawer_visit( int $id ): array {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}
		$visit = $id > 0 && method_exists( Visits::class, 'get' ) ? Visits::get( $id ) : null;
		if ( $id > 0 && ! $visit ) {
			wp_send_json_error( array( 'message' => __( 'That visit is no longer here.', 'estat-os' ) ), 404 );
		}

		if ( 0 === $id ) {
			return self::drawer_visit_new();
		}

		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'When', 'estat-os' ),
			esc_html( (string) ( $visit['scheduled_at'] ?? '' ) )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Property', 'estat-os' ),
			esc_html( (string) ( $visit['listing_title'] ?? '' ) ?: '—' )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Who is going', 'estat-os' ),
			esc_html( (string) ( $visit['agent_name'] ?? '' ) ?: '—' )
		);
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Result', 'estat-os' ),
			Ui::status_badge( Status::VISIT, (string) ( $visit['outcome'] ?? 'pending' ) )
		);
		if ( ! empty( $visit['notes'] ) ) {
			printf(
				'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
				esc_html__( 'Notes', 'estat-os' ),
				esc_html( (string) $visit['notes'] )
			);
		}
		echo '</div>';

		// The same three answers the list offers, in the office's own words.
		$foot  = '<button type="button" class="btn btn--ghost" data-act="visit-done" data-id="' . (int) $id . '">';
		$foot .= esc_html__( 'Mark done', 'estat-os' ) . '</button>';
		$foot .= '<button type="button" class="btn btn--bronze" data-act="visit-no_show" data-id="' . (int) $id . '">';
		$foot .= esc_html__( 'No-show', 'estat-os' ) . '</button>';
		$foot .= '<button type="button" class="btn btn--ghost" data-act="visit-cancelled" data-id="' . (int) $id . '">';
		$foot .= esc_html__( 'Cancel it', 'estat-os' ) . '</button>';

		return array(
			'title' => (string) ( $visit['lead_name'] ?? __( 'Visit', 'estat-os' ) ),
			'html'  => (string) ob_get_clean(),
			'foot'  => $foot,
		);
	}

	/**
	 * A team member, or an empty card for a new one.
	 *
	 * @param int $id Agent, or 0 to make a new one.
	 * @return array<string,string>
	 */
	private static function drawer_agent( int $id ): array {
		if ( ! current_user_can( 'estat_manage_team' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}

		$agent = array();
		if ( $id > 0 ) {
			$agent = Agents::to_array( $id );
		}

		ob_start();
		echo '<div class="dr__b">';
		echo '<div class="dr__person">';
		if ( ! empty( $agent['photo'] ) ) {
			printf( '<span class="av av--48" style="background-image:url(%1$s)"></span>', esc_url( (string) $agent['photo'] ) );
		} else {
			printf( '<span class="av av--48">%1$s</span>', esc_html( Ui::initials( (string) ( $agent['name'] ?? '' ) ) ) );
		}
		echo '<div><div style="font-weight:var(--fw-sem)">' . esc_html( (string) ( $agent['name'] ?? __( 'New member', 'estat-os' ) ) ) . '</div>';
		printf( '<div class="mut" style="font-size:var(--fs-meta)">%1$s</div>', esc_html( (string) ( $agent['role'] ?? '' ) ) );
		echo '</div></div>';

		echo '<div class="divider"></div>';

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="name" value="%2$s"></div>',
			esc_html__( 'Name', 'estat-os' ),
			esc_attr( (string) ( $agent['name'] ?? '' ) )
		);
		printf(
			'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="role" value="%2$s"></div>',
			esc_html__( 'What they do', 'estat-os' ),
			esc_attr( (string) ( $agent['role'] ?? '' ) )
		);
		echo '</div>';
		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="phone" value="%2$s"></div>',
			esc_html__( 'Phone', 'estat-os' ),
			esc_attr( (string) ( $agent['phone'] ?? '' ) )
		);
		printf(
			'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="email" value="%2$s"></div>',
			esc_html__( 'Email', 'estat-os' ),
			esc_attr( (string) ( $agent['email'] ?? '' ) )
		);
		echo '</div>';
		echo '</div>';

		$foot  = '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>';
		$foot .= '<button type="button" class="btn btn--bronze" data-act="save-agent" data-id="' . $id . '">' . esc_html__( 'Save', 'estat-os' ) . '</button>';

		return array(
			'title' => $id > 0 ? (string) ( $agent['name'] ?? '' ) : __( 'Add a member', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => $foot,
		);
	}

	/**
	 * Where enquiries come from, with the numbers behind it.
	 *
	 * @param int $id Unused; kept so every drawer answers the same shape.
	 * @return array<string,string>
	 */
	private static function drawer_source( int $id ): array {
		if ( ! current_user_can( 'estat_view_reports' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['name'] ) ) : '';

		ob_start();
		echo '<div class="dr__b">';
		printf( '<div class="mut">%1$s</div>', esc_html__( 'Enquiries that arrived through this route in the last ninety days.', 'estat-os' ) );
		echo '<div class="divider"></div>';
		printf(
			'<div class="kv"><span class="kv__k">%1$s</span><span class="kv__v">%2$s</span></div>',
			esc_html__( 'Route', 'estat-os' ),
			esc_html( '' !== $name ? $name : __( 'Not recorded', 'estat-os' ) )
		);
		echo '</div>';

		return array(
			'title' => '' !== $name ? $name : __( 'Where enquiries come from', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '',
		);
	}

	/* ----------------------------------------------------------------- write */

	/**
	 * Small state changes: approve, decline, put back, destroy, and so on.
	 *
	 * Everything here is one record at a time and always says what happened.
	 *
	 * @return void
	 */
	private static function act(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( (string) $_POST['do'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;

		switch ( $do ) {
			case 'restore':
				self::need( 'estat_restore_listings' );
				self::settle( Bin::restore( $id ), $id, __( 'Put back where it was', 'estat-os' ) );

			case 'purge':
				self::need( 'estat_delete_listings' );
				self::settle( Bin::delete_forever( $id ), $id, __( 'Destroyed for good', 'estat-os' ) );

			case 'empty-bin':
				self::need( 'estat_delete_listings' );
				if ( ! Bin::may_empty() ) {
					wp_send_json_error( array( 'message' => __( 'You may not empty the bin.', 'estat-os' ) ), 403 );
				}
				$ids  = Bin::all_ids( 500 );
				$res  = Bin::batch( 'delete_forever', $ids );
				$gone = is_array( $res ) ? (int) ( $res['deleted'] ?? count( $ids ) ) : count( $ids );
				wp_send_json_success( array( 'done' => true, 'say' => sprintf( __( 'Bin emptied — %d removed', 'estat-os' ), $gone ) ) );

			case 'approve':
				// 'estat_approve_listings' was never a capability this plugin
				// declared, so current_user_can() answered no for everybody —
				// the office owner included — and every approval was refused
				// with "You do not have permission to do that." while the
				// same decision worked from the phone. The cap that exists is
				// estat_review_listings.
				self::need( 'estat_review_listings' );
				self::settle_request( $id, true );

			case 'decline':
				self::need( 'estat_review_listings' );
				self::settle_request( $id, false );

			case 'keep-both':
				self::need( 'estat_manage_listings' );
				$pair = Duplicate::stored( $id );
				Duplicate::keep_both( $id, (int) ( $pair['of'] ?? 0 ) );
				wp_send_json_success( array( 'id' => $id, 'done' => true, 'say' => __( 'Kept both', 'estat-os' ) ) );

			case 'bin':
				self::need( 'estat_bin_listings' );
				self::settle( Bin::move( $id, __( 'Marked as a duplicate', 'estat-os' ) ), $id, __( 'Moved to the bin', 'estat-os' ) );

			case 'undo-import':
				self::need( 'estat_import_inventory' );
				self::settle( Spreadsheet::undo_job( $id ), $id, __( 'Import undone', 'estat-os' ) );

			case 'scan':
				self::need( 'estat_manage_listings' );
				// "Check now" on the Duplicates screen sent do=scan, and no
				// case answered it: the button said "That action is not
				// known." The engine was there all along, wired only to an
				// admin-post route the screen never posts to.
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$kind   = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_POST['kind'] ) ? '' : $_POST['kind'] ) ) ) : 'listings';
				$kind   = in_array( $kind, array( 'listings', 'projects' ), true ) ? $kind : 'listings';
				$result = Duplicate::scan( 'projects' === $kind ? 'project' : 'listing' );
				// Held for this person, exactly as the admin-post route did,
				// so the screen shows the pairs it just found.
				set_transient( 'estat_duplicate_scan_' . get_current_user_id(), $result, HOUR_IN_SECONDS );

				$found  = count( (array) ( $result['pairs'] ?? array() ) );
				$looked = (int) ( $result['looked'] ?? 0 );
				$say    = ! empty( $result['stopped'] )
					/* translators: 1: records looked at, 2: pairs found so far */
					? sprintf( __( 'Looked at %1$d records and found %2$d pairs so far. Press again to carry on.', 'estat-os' ), $looked, $found )
					/* translators: 1: records looked at, 2: pairs found */
					: sprintf( __( 'Looked at %1$d records and found %2$d pairs that look alike.', 'estat-os' ), $looked, $found );
				wp_send_json_success( array( 'done' => true, 'found' => $found, 'reload' => true, 'say' => $say ) );

			/*
			 * A visit's outcome is whatever the office's own vocabulary says it
			 * is — done, no-show, cancelled — and this pair of cases was not
			 * that list. The screen draws its buttons from the vocabulary, so
			 * it offered "No-show" and "Cancel" against a server that knew
			 * "missed" instead: pressing either did nothing at all, and the
			 * drawer's own "Mark as not happening" asked for a word the office
			 * never uses, which the visit refused in silence by writing back
			 * the outcome it already had. The outcome is now read off the end
			 * of the instruction and checked against the vocabulary, so every
			 * button the screen can draw is one the server can answer, and
			 * the old word is still understood.
			 */
			case 'visit-done':
			case 'visit-no_show':
			case 'visit-cancelled':
			case 'visit-missed':
				self::need( 'estat_manage_visits' );
				$outcome = substr( $do, strlen( 'visit-' ) );
				if ( 'missed' === $outcome ) {
					$outcome = 'no_show';   // the word an older page still sends
				}
				$words = \EstatOS\Support\Vocabulary::visit_outcomes();
				if ( ! isset( $words[ $outcome ] ) ) {
					wp_send_json_error( array( 'message' => __( 'That action is not known.', 'estat-os' ) ), 400 );
				}
				self::settle(
					Visits::update( $id, array( 'outcome' => $outcome ) ),
					$id,
					sprintf(
						/* translators: %s: the outcome word, e.g. "Completed". */
						__( 'Marked %s', 'estat-os' ),
						strtolower( (string) $words[ $outcome ] )
					)
				);

			case 'lead-advance':
				self::need( 'estat_manage_leads' );
				$moved = self::advance( $id );
				if ( ! $moved ) {
					wp_send_json_error( array( 'message' => __( 'That enquiry could not be moved. Open it and try again.', 'estat-os' ) ), 422 );
				}
				wp_send_json_success( array( 'id' => $id, 'done' => true, 'say' => __( 'Moved on a stage', 'estat-os' ) ) );

			case 'detach-media':
				self::need( 'estat_manage_listings' );
				if ( ! Media::link( $id, 0 ) ) {
					wp_send_json_error( array( 'message' => __( 'That picture could not be unlinked.', 'estat-os' ) ), 422 );
				}
				wp_send_json_success( array( 'id' => $id, 'done' => true, 'say' => __( 'Unlinked', 'estat-os' ) ) );

			case 'delete-media':
				self::need( 'estat_manage_listings' );
				$gone = wp_delete_attachment( $id, true );
				if ( ! $gone ) {
					wp_send_json_error( array( 'message' => __( 'That picture could not be deleted.', 'estat-os' ) ), 422 );
				}
				wp_send_json_success( array( 'id' => $id, 'done' => true, 'say' => __( 'Deleted', 'estat-os' ) ) );

			default:
				wp_send_json_error( array( 'message' => __( 'That action is not known.', 'estat-os' ) ), 400 );
		}
	}

	/**
	 * Saving the three things the office edits without leaving the page:
	 * a website form, the order of page blocks, and the colour tokens.
	 *
	 * @return void
	 */
	private static function save(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$what = isset( $_POST['what'] ) ? sanitize_key( wp_unslash( (string) $_POST['what'] ) ) : '';

		if ( 'blocks' === $what ) {
			self::need( 'estat_manage_settings' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$type   = isset( $_POST['type'] ) && 'project' === $_POST['type'] ? 'project' : 'listing';
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$blocks = isset( $_POST['blocks'] ) ? (array) wp_unslash( $_POST['blocks'] ) : array();

			$clean = array();
			foreach ( $blocks as $block ) {
				$block = (array) $block;
				$bid   = sanitize_key( (string) ( $block['id'] ?? '' ) );
				if ( '' === $bid ) {
					continue;
				}
				$clean[] = array(
					'id'      => $bid,
					'label'   => sanitize_text_field( (string) ( $block['label'] ?? '' ) ),
					'enabled' => ! empty( $block['enabled'] ),
				);
			}
			Templates::save_blocks( $clean, $type );
			wp_send_json_success( array( 'done' => true, 'say' => __( 'Order saved', 'estat-os' ) ) );
		}

		if ( 'tokens' === $what ) {
			self::need( 'estat_manage_settings' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw    = isset( $_POST['tokens'] ) ? (array) wp_unslash( $_POST['tokens'] ) : array();
			$tokens = array();
			foreach ( $raw as $key => $value ) {
				$key   = sanitize_text_field( (string) $key );
				$value = sanitize_text_field( (string) $value );
				if ( '' === $key || '' === $value ) {
					continue;
				}
				$tokens[ $key ] = $value;
			}
			Settings::update( array( 'design_tokens' => $tokens ) );
			wp_send_json_success( array( 'done' => true, 'say' => __( 'Colours saved', 'estat-os' ) ) );
		}

		if ( 'form' === $what ) {
			self::need( 'estat_manage_forms' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$id     = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw    = isset( $_POST['definition'] ) ? (string) wp_unslash( $_POST['definition'] ) : '';
			$define = json_decode( $raw, true );
			if ( ! is_array( $define ) ) {
				wp_send_json_error( array( 'message' => __( 'That form could not be read.', 'estat-os' ) ), 422 );
			}
			/*
			 * A form with no boxes in it is not a form. Saving one used to be
			 * allowed, and it left a named, published-looking shell in the
			 * "which form" list that asks a visitor for nothing and answers
			 * nothing — a screen the office would find hard to explain. The
			 * office's own save now refuses it and says so, which is also the
			 * moment somebody deleting the last box finds out.
			 */
			$boxes = 0;
			foreach ( (array) ( $define['rows'] ?? array() ) as $row ) {
				foreach ( (array) ( $row['columns'] ?? array() ) as $column ) {
					$boxes += count( (array) ( $column['fields'] ?? array() ) );
				}
			}
			foreach ( (array) ( $define['steps'] ?? array() ) as $step ) {
				foreach ( (array) ( $step['rows'] ?? array() ) as $row ) {
					foreach ( (array) ( $row['columns'] ?? array() ) as $column ) {
						$boxes += count( (array) ( $column['fields'] ?? array() ) );
					}
				}
			}
			if ( 0 === $boxes ) {
				wp_send_json_error(
					array( 'message' => __( 'A form needs at least one box. Add one and press Save again.', 'estat-os' ) ),
					422
				);
			}

			$new = Forms::save( $define, $id );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Form saved', 'estat-os' ) ) );
		}

		if ( 'project' === $what ) {
			self::need( 'estat_manage_projects' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$id    = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$input = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();

			$clean = array();
			foreach ( array(
				'title',
				'status',
				'description',
				'developer',
				'project_type',
				'project_status',
				'price_min',
				'price_max',
				'total_units',
				'available_units',
				'possession_date',
				'address',
				'locality',
				'category',
				'unit_types',
				'highlights',
				'gallery',
				'cover_id',
			) as $key ) {
				if ( isset( $input[ $key ] ) ) {
					$clean[ $key ] = is_array( $input[ $key ] ) ? $input[ $key ] : sanitize_text_field( (string) $input[ $key ] );
				}
			}

			$saved = Projects::save( $clean, $id );
			if ( is_wp_error( $saved ) ) {
				wp_send_json_error( array( 'message' => $saved->get_error_message() ), 422 );
			}

			wp_send_json_success( array(
				'done' => true,
				'id'   => (int) $saved,
				'say'  => $id > 0 ? __( 'Society saved', 'estat-os' ) : __( 'Society added', 'estat-os' ),
			) );
		}

		if ( 'lead' === $what ) {
			self::need( 'estat_manage_leads' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$id    = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$input = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();

			$clean = array();
			foreach ( array( 'name', 'phone', 'email', 'message', 'status', 'source' ) as $key ) {
				if ( isset( $input[ $key ] ) ) {
					$clean[ $key ] = sanitize_text_field( (string) $input[ $key ] );
				}
			}

			if ( $id > 0 ) {
				$ok = Leads::update( $id, $clean );
				if ( is_wp_error( $ok ) ) {
					wp_send_json_error( array( 'message' => $ok->get_error_message() ), 422 );
				}
				wp_send_json_success( array( 'done' => true, 'id' => $id, 'say' => __( 'Enquiry saved', 'estat-os' ) ) );
			}

			$clean['source'] = $clean['source'] ?? 'office';
			$new             = Leads::create( $clean );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Enquiry added', 'estat-os' ) ) );
		}

		if ( 'visit' === $what ) {
			self::need( 'estat_manage_visits' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$input  = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();
			$when_s = sanitize_text_field( (string) ( $input['scheduled_at'] ?? '' ) );

			$clean = array(
				'lead_id'      => absint( $input['lead_id'] ?? 0 ),
				'listing_id'   => absint( $input['listing_id'] ?? 0 ),
				'agent_id'     => absint( $input['agent_id'] ?? 0 ),
				'scheduled_at' => $when_s,
			);

			$new = Visits::schedule( $clean );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Visit booked', 'estat-os' ) ) );
		}

		if ( 'agent' === $what ) {
			self::need( 'estat_manage_team' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$id   = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$rows = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();
			$new  = Agents::save( array(
				'name'  => sanitize_text_field( (string) ( $rows['name'] ?? '' ) ),
				'role'  => sanitize_text_field( (string) ( $rows['role'] ?? '' ) ),
				'phone' => sanitize_text_field( (string) ( $rows['phone'] ?? '' ) ),
				'email' => sanitize_email( (string) ( $rows['email'] ?? '' ) ),
			), $id );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Saved', 'estat-os' ) ) );
		}

		wp_send_json_error( array( 'message' => __( 'There is nothing to save there.', 'estat-os' ) ), 400 );
	}

	/**
	 * Files dropped on the gallery.
	 *
	 * @return void
	 */
	private static function upload(): void {
		self::need( 'estat_manage_listings' );
		if ( empty( $_FILES['file'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file arrived.', 'estat-os' ) ), 400 );
		}
		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) $_POST['kind'] ) ) : 'photo';
		$moved = wp_handle_upload( $_FILES['file'], array( 'test_form' => false ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( isset( $moved['error'] ) ) {
			wp_send_json_error( array( 'message' => (string) $moved['error'] ), 422 );
		}

		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$url      = (string) $moved['url'];
		$file     = (string) $moved['file'];
		$title    = sanitize_file_name( wp_basename( $file ) );
		$attach   = array(
			'guid'           => $url,
			'post_mime_type' => (string) wp_check_filetype( $file )['type'],
			'post_title'     => $title,
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$attach_id = wp_insert_attachment( $attach, $file );
		if ( ! $attach_id || is_wp_error( $attach_id ) ) {
			wp_send_json_error( array( 'message' => __( 'The file could not be kept.', 'estat-os' ) ), 500 );
		}
		wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $file ) );
		if ( method_exists( Media::class, 'set_kind' ) ) {
			Media::set_kind( $attach_id, $kind );
		}
		wp_send_json_success( array( 'id' => $attach_id, 'url' => $url, 'say' => __( 'Added', 'estat-os' ) ) );
	}

	/**
	 * The quick search in the top bar.
	 *
	 * @return void
	 */
	private static function search(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$q = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['q'] ) ) : '';
		if ( strlen( $q ) < 2 ) {
			wp_send_json_success( array( 'items' => array() ) );
		}

		$items = array();

		if ( current_user_can( 'estat_manage_listings' ) ) {
			$found = get_posts( array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				's'              => $q,
				'posts_per_page' => 6,
				'fields'         => 'ids',
			) );
			foreach ( $found as $pid ) {
				/*
				 * The line under the name is the locality, which this plugin
				 * keeps as a taxonomy term — not in post meta. It used to read
				 * a meta key nothing writes, so every property in the palette
				 * came with a blank second line.
				 */
				$terms    = wp_get_object_terms( (int) $pid, Taxonomies::LOCALITY, array( 'fields' => 'names' ) );
				$where    = ( is_wp_error( $terms ) || ! $terms ) ? '' : implode( ', ', (array) $terms );
				$project  = (int) get_post_meta( $pid, '_estat_project_id', true );
				if ( $project > 0 ) {
					$where = trim( get_the_title( $project ) . ( '' === $where ? '' : ' · ' . $where ) );
				}
				$items[] = array(
					'kind'  => 'listing',
					'id'    => (int) $pid,
					'title' => (string) get_the_title( $pid ),
					'sub'   => $where,
					'url'   => admin_url( 'admin.php?page=estat-add-home&edit=' . (int) $pid ),
				);
			}

			/*
			 * Properties whose locality or society matches — the palette's box
			 * says it searches properties, and a name is not the only thing a
			 * person types. "sector 79" found nothing before this.
			 */
			$by_place = get_posts(
				array(
					'post_type'      => PostTypes::LISTING,
					'post_status'    => array( 'publish', 'draft', 'pending' ),
					'posts_per_page' => 4,
					'fields'         => 'ids',
					'suppress_filters' => true,
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					'tax_query'      => array(
						array(
							'taxonomy' => Taxonomies::LOCALITY,
							'field'    => 'name',
							'terms'    => $q,
							'operator' => 'LIKE',
						),
					),
				)
			);
			$have     = wp_list_pluck( $items, 'id' );
			foreach ( $by_place as $pid ) {
				if ( in_array( (int) $pid, array_map( 'intval', $have ), true ) ) {
					continue;
				}
				$terms   = wp_get_object_terms( (int) $pid, Taxonomies::LOCALITY, array( 'fields' => 'names' ) );
				$items[] = array(
					'kind'  => 'listing',
					'id'    => (int) $pid,
					'title' => (string) get_the_title( $pid ),
					'sub'   => ( is_wp_error( $terms ) || ! $terms ) ? '' : implode( ', ', (array) $terms ),
					'url'   => admin_url( 'admin.php?page=estat-add-home&edit=' . (int) $pid ),
				);
			}
		}

		/*
		 * People. The box promises them ("Search properties, leads, people,
		 * settings…") and no branch answered for a name in the team:
		 * "rohit" found nothing at all.
		 */
		if ( current_user_can( 'estat_manage_team' ) ) {
			$people = get_posts(
				array(
					'post_type'      => PostTypes::AGENT,
					'post_status'    => array( 'publish', 'draft' ),
					'posts_per_page' => 4,
					's'              => $q,
				)
			);
			foreach ( $people as $person ) {
				$items[] = array(
					'kind'  => 'agent',
					'id'    => (int) $person->ID,
					'title' => (string) $person->post_title,
					'sub'   => (string) get_post_meta( (int) $person->ID, '_estat_phone', true ),
					'url'   => admin_url( 'admin.php?page=estat-team' ),
				);
			}
		}

		if ( current_user_can( 'estat_manage_leads' ) && method_exists( Leads::class, 'query' ) ) {
			$found = Leads::query( array( 'search' => $q, 'per_page' => 5 ) );
			foreach ( (array) ( $found['items'] ?? array() ) as $lead ) {
				$items[] = array(
					'kind'  => 'lead',
					'id'    => (int) ( $lead['id'] ?? 0 ),
					'title' => (string) ( $lead['name'] ?? '' ),
					'sub'   => (string) ( $lead['phone'] ?? '' ),
					'url'   => admin_url( 'admin.php?page=estat-enquiries&lead=' . (int) ( $lead['id'] ?? 0 ) ),
				);
			}
		}

		wp_send_json_success( array( 'items' => $items ) );
	}

	/* ----------------------------------------------------------------- bits */

	/**
	 * Answer with what actually happened.
	 *
	 * "done" used to be `(bool) $result`, and every refusal these classes
	 * return is a WP_Error — an object, and therefore true. So a property
	 * that was refused ("That one is not in the bin.") was still reported as
	 * "Put back where it was", the row slid out of the table, and the office
	 * was left believing it had done something it had not. A refusal is now a
	 * refusal, with the reason the office would understand.
	 *
	 * @param mixed  $result Whatever the writer returned.
	 * @param int    $id     Record id.
	 * @param string $say    What to say when it really worked.
	 * @return void
	 */
	private static function settle( $result, int $id, string $say ): void {
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'id' => $id, 'message' => $result->get_error_message() ), 422 );
		}
		if ( false === $result || null === $result ) {
			wp_send_json_error( array( 'id' => $id, 'message' => __( 'That did not work. Please try again.', 'estat-os' ) ), 422 );
		}
		wp_send_json_success( array( 'id' => $id, 'done' => true, 'say' => $say ) );
	}

	/**
	 * Stop with a clear answer when the person may not do this.
	 *
	 * @param string $cap Capability.
	 * @return void
	 */
	private static function need( string $cap ): void {
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do that.', 'estat-os' ) ), 403 );
		}
	}

	/**
	 * What the drawer shows when the answer is no.
	 *
	 * @return string
	 */
	private static function denied(): string {
		return '<div class="empty"><div class="empty__t">' . esc_html__( 'Not for you', 'estat-os' ) . '</div>' .
			'<div class="empty__d">' . esc_html__( 'You do not have permission to look at this.', 'estat-os' ) . '</div></div>';
	}

	/**
	 * Record a decision on a change request.
	 *
	 * @param int    $id     Request.
	 * @param string $answer approved | declined.
	 * @return bool
	 */
	/**
	 * Answer a change request the way the office means it, and say so honestly.
	 *
	 * The desk's Approve button used to write \"approved\" into the requests
	 * table and stop there: the agent's proposed change — the new price, the
	 * moved photograph — was never applied, while the same decision taken on
	 * the phone went through Requests::approve() and did apply it. The two
	 * halves of the office disagreed, and the desk's answer looked done when
	 * nothing had happened. Worse, the button reported success even when the
	 * id matched no request at all: a mistyped or stale id wrote nothing and
	 * still toasted \"Approved\".
	 *
	 * @param int  $request_id Request to answer.
	 * @param bool $yes        True to approve, false to decline.
	 * @return void
	 */
	private static function settle_request( int $request_id, bool $yes ): void {
		$result = $yes
			? \EstatOS\Field\Requests::approve( $request_id )
			: \EstatOS\Field\Requests::decline( $request_id, '' );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'id' => $request_id, 'message' => $result->get_error_message() ), 422 );
		}

		wp_send_json_success(
			array(
				'id'      => $request_id,
				'done'    => true,
				'reload'  => true,
				'say'     => $yes ? __( 'Approved', 'estat-os' ) : __( 'Declined', 'estat-os' ),
			)
		);
	}

	private static function review( int $id, string $answer ): bool {
		global $wpdb;
		$table = \EstatOS\Install\Schema::table( 'estat_requests' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$done = $wpdb->update(
			$table,
			array(
				'status'      => $answer,
				'reviewed_by' => get_current_user_id(),
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%d', '%s' ),
			array( '%d' )
		);
		return false !== $done;
	}

	/**
	 * Push an enquiry one stage forward.
	 *
	 * @param int $id Lead.
	 * @return bool
	 */
	private static function advance( int $id ): bool {
		$lead = Leads::get( $id );
		if ( ! $lead ) {
			return false;
		}
		$order = \EstatOS\Support\Vocabulary::lead_pipeline_order();
		$now   = (string) ( $lead['status'] ?? 'new' );
		$at    = array_search( $now, $order, true );
		$next  = false === $at ? ( $order[0] ?? 'new' ) : ( $order[ $at + 1 ] ?? $now );
		return (bool) Leads::update( $id, array( 'status' => $next ) );
	}
}
