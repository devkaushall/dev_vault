<?php
/**
 * Today — the one screen the office opens first.
 *
 * Four numbers that say how the office is doing, then the list of things
 * that actually need a person. Nothing here is a report: if a number is on
 * this screen it is because someone can act on it today.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Series;
use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Health;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Worklist;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Work\MyDay;

defined( 'ABSPATH' ) || exit;

final class TodayScreen {

	public static function render(): void {
		$counts = Shell::counts();
		$leads  = Leads::counts();
		$visits = Visits::counts();
		$day    = MyDay::summary();
		$tasks  = Worklist::tasks( 12 );

		$hour = (int) current_time( 'G' );
		$hi   = $hour < 12 ? __( 'Good morning', 'estat-os' ) : ( $hour < 17 ? __( 'Good afternoon', 'estat-os' ) : __( 'Good evening', 'estat-os' ) );
		$name = wp_get_current_user()->first_name ?: wp_get_current_user()->display_name;

		$waiting = count( $tasks );
		$sub     = $waiting
			? sprintf(
				/* translators: %d number of jobs waiting. */
				_n( '%d thing needs you before the day gets away.', '%d things need you before the day gets away.', $waiting, 'estat-os' ),
				$waiting
			)
			: __( 'Nothing is waiting on you. Everything else is running itself.', 'estat-os' );

		Shell::open( 'estat-today' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html( wp_date( 'l, j F' ) ) . '</span></div>';
		echo '<h1>' . esc_html( $hi . ( $name ? ', ' . $name : '' ) ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html( $sub ) . '</p>';
		echo '</div><div class="phead__r">';
		echo Ui::link_button( admin_url( 'admin.php?page=estat-reports' ), __( 'Full report', 'estat-os' ), 'chart' );
		echo Ui::link_button( admin_url( 'admin.php?page=estat-add-home' ), __( 'Add a home', 'estat-os' ), 'plus', 'primary' );
		echo '</div></div>';

		echo '<div class="bento">';

		self::metric(
			__( 'Total Properties', 'estat-os' ),
			(int) $counts['listings'],
			'home',
			'var(--bronze)',
			'var(--bronze-soft)',
			0,
			Series::listings(),
			__( 'in the inventory', 'estat-os' )
		);

		self::metric(
			__( 'Open Enquiries', 'estat-os' ),
			(int) ( $leads['new'] ?? 0 ),
			'inbox',
			'var(--info)',
			'var(--info-soft)',
			60,
			Series::leads(),
			sprintf(
				/* translators: %d enquiries waiting on a first reply. */
				_n( '%d has not been answered yet', '%d have not been answered yet', (int) ( $leads['new'] ?? 0 ), 'estat-os' ),
				(int) ( $leads['new'] ?? 0 )
			)
		);

		self::metric(
			__( 'Pending Visits', 'estat-os' ),
			(int) ( $visits['pending'] ?? 0 ),
			'calendar',
			'var(--warn)',
			'var(--warn-soft)',
			120,
			Series::visits(),
			sprintf(
				/* translators: %d visits happening today. */
				_n( '%d of them today', '%d of them today', (int) ( $visits['today'] ?? 0 ), 'estat-os' ),
				(int) ( $visits['today'] ?? 0 )
			)
		);

		self::metric(
			__( 'Deals Won', 'estat-os' ),
			(int) ( $leads['won'] ?? 0 ),
			'star',
			'var(--pos)',
			'var(--pos-soft)',
			180,
			Series::leads(),
			__( 'closed so far', 'estat-os' )
		);

		self::worklist( $tasks );
		self::side_column( $leads );

		echo '</div><!-- /bento -->';

		Shell::close();
	}

	/** One metric card. */
	private static function metric(
		string $label,
		int $value,
		string $icon,
		string $tone,
		string $soft,
		int $delay,
		array $series,
		string $foot
	): void {
		printf(
			'<div class="panel metric b3 anim" style="--d:%1$dms;--mc:%2$s;--mc-soft:%3$s">',
			$delay,
			esc_attr( $tone ),
			esc_attr( $soft )
		);
		echo '<div class="metric__top"><div class="metric__ico">';
		Ui::ico( $icon );
		echo '</div><div class="metric__lbl"><div class="lbl">' . esc_html( $label ) . '</div></div></div>';
		echo '<div class="metric__n num" data-count="' . (int) $value . '">0</div>';
		echo '<div class="metric__ft"><span class="mut">' . esc_html( $foot ) . '</span></div>';
		echo Series::spark( $series, $tone );
		echo '</div>';
	}

	/** The list of jobs. */
	private static function worklist( array $tasks ): void {
		echo '<div class="panel b8 anim" style="--d:240ms">';
		echo '<div class="panel__h"><div>';
		echo '<h3>' . esc_html__( 'Worklist', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Overdue follow-ups, new leads, incomplete listings', 'estat-os' ) . '</div>';
		echo '</div><div class="panel__hr">';
		echo '<div class="seg" role="tablist" data-seg="worklist">';
		$tabs = array(
			'all'       => __( 'All', 'estat-os' ),
			'followup'  => __( 'Overdue', 'estat-os' ),
			'leads'     => __( 'Leads', 'estat-os' ),
			'listings'  => __( 'Listings', 'estat-os' ),
		);
		$first = true;
		foreach ( $tabs as $key => $word ) {
			echo '<button type="button" class="seg__b' . ( $first ? ' is-on' : '' ) . '" data-seg-v="' . esc_attr( $key ) . '">' . esc_html( $word ) . '</button>';
			$first = false;
		}
		echo '</div></div></div>';

		echo '<div class="panel__b" id="worklist">';
		if ( ! $tasks ) {
			echo Ui::empty_state(
				'check',
				__( 'Nothing is waiting', 'estat-os' ),
				__( 'Every lead has been answered and every listing is complete.', 'estat-os' )
			);
		} else {
			foreach ( $tasks as $i => $t ) {
				$kind = self::kind_of( $t );
				$tone = 'danger' === ( $t['tone'] ?? '' ) ? 'danger' : ( 'warning' === ( $t['tone'] ?? '' ) ? 'pending' : ( 'success' === ( $t['tone'] ?? '' ) ? 'live' : 'bronze' ) );
				printf(
					'<div class="wl__i" data-kind="%1$s" style="animation:eos-rise 380ms var(--e-out) both;animation-delay:%2$dms">',
					esc_attr( $kind ),
					$i * 45
				);
				echo '<span class="wl__tick" role="checkbox" aria-checked="false" tabindex="0">';
				Ui::ico( 'check' );
				echo '</span>';
				echo '<div class="wl__b"><div class="wl__t">' . esc_html( (string) $t['title'] ) . '</div>';
				echo '<div class="wl__m">';
				Ui::ico( 'clock' );
				echo '<span>' . esc_html( (string) $t['detail'] ) . '</span></div></div>';
				echo '<span class="badge badge--' . esc_attr( $tone ) . '">' . esc_html( (string) ( $t['action'] ?? '' ) ) . '</span>';
				if ( ! empty( $t['url'] ) ) {
					echo '<a class="btn btn--ghost btn--sm" href="' . esc_url( $t['url'] ) . '">' . esc_html( (string) ( $t['action'] ?: __( 'Open', 'estat-os' ) ) ) . '</a>';
				}
				echo '</div>';
			}
		}
		echo '</div></div>';
	}

	/** Which worklist filter a task belongs to. */
	private static function kind_of( array $t ): string {
		$url = (string) ( $t['url'] ?? '' );
		if ( false !== strpos( $url, 'page=estat-enquiries' ) ) {
			return false !== strpos( $url, 'followup' ) ? 'followup' : 'leads';
		}
		if ( false !== strpos( $url, 'page=estat-listings' ) ) {
			return 'listings';
		}
		if ( false !== strpos( $url, 'page=estat-visits' ) ) {
			return 'leads';
		}
		return 'all';
	}

	/** Pipeline at a glance, and the properties still missing a photograph. */
	private static function side_column( array $leads ): void {
		echo '<div class="b4 anim" style="--d:300ms;display:grid;gap:var(--s4);align-content:start">';

		echo '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">';
		esc_html_e( 'Pipeline at a glance', 'estat-os' );
		echo '</div><div id="miniPipe" style="display:grid;gap:var(--s2)">';

		$pipes = array(
			array( __( 'New', 'estat-os' ), (int) ( $leads['new'] ?? 0 ), 'var(--info)' ),
			array( __( 'Contacted', 'estat-os' ), (int) ( $leads['contacted'] ?? 0 ), 'var(--warn)' ),
			array( __( 'Scheduled', 'estat-os' ), (int) ( $leads['scheduled'] ?? 0 ), 'var(--bronze)' ),
			array( __( 'Won', 'estat-os' ), (int) ( $leads['won'] ?? 0 ), 'var(--pos)' ),
		);
		$total = 0;
		foreach ( $pipes as $p ) {
			$total += $p[1];
		}
		$total = $total > 0 ? $total : 1;

		foreach ( $pipes as $p ) {
			$w = round( $p[1] / $total * 100, 1 );
			echo '<div><div style="display:flex;font-size:var(--fs-meta);margin-bottom:5px">';
			echo '<span class="mut">' . esc_html( $p[0] ) . '</span>';
			echo '<b style="margin-left:auto">' . (int) $p[1] . '</b></div>';
			echo '<div style="height:6px;border-radius:99px;background:var(--inset);overflow:hidden">';
			echo '<i style="display:block;height:100%;border-radius:99px;background:' . esc_attr( $p[2] ) . ';width:0;transition:width 900ms var(--e-out)" data-w="' . esc_attr( (string) $w ) . '"></i>';
			echo '</div></div>';
		}
		echo '</div></div>';

		// Properties nobody has photographed yet.
		$bare = self::without_photo();
		echo '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">';
		esc_html_e( 'Needs a photograph', 'estat-os' );
		echo '</div>';
		if ( ! $bare ) {
			echo '<p class="mut" style="font-size:var(--fs-name);margin:0">' . esc_html__( 'Every property has a cover photo.', 'estat-os' ) . '</p>';
		} else {
			echo '<div style="display:grid;gap:var(--s3)">';
			foreach ( $bare as $row ) {
				echo '<div class="wl__i" style="padding:0">';
				echo '<div class="tthumb">';
				Ui::ico( 'image' );
				echo '</div><div class="wl__b"><div class="wl__t">' . esc_html( $row['title'] ) . '</div>';
				echo '<div class="wl__m">' . esc_html( $row['meta'] ) . '</div></div></div>';
			}
			echo '</div>';
			echo '<a class="btn btn--ghost btn--sm btn--block" style="margin-top:var(--s4)" href="' . esc_url( admin_url( 'admin.php?page=estat-listings&filter=nophoto' ) ) . '">';
			esc_html_e( 'Show all', 'estat-os' );
			echo '</a>';
		}
		echo '</div>';

		echo '</div>';
	}

	/**
	 * Listings with no cover image, newest first.
	 *
	 * @return array<int,array<string,string>>
	 */
	private static function without_photo(): array {
		$q = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 3,
				'no_found_rows'  => true,
				'meta_query'     => array(
					'relation' => 'OR',
					array(
						'key'     => '_thumbnail_id',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_thumbnail_id',
						'value'   => '0',
						'compare' => '=',
					),
				),
			)
		);

		$out = array();
		foreach ( $q->posts as $p ) {
			$out[] = array(
				'title' => get_the_title( $p ),
				'meta'  => sprintf(
					/* translators: %s: how long ago. */
					__( 'Added %s ago', 'estat-os' ),
					human_time_diff( (int) get_post_time( 'U', true, $p ), time() )
				),
				'url'   => admin_url( 'admin.php?page=estat-listings&edit=' . (int) $p->ID ),
			);
		}
		return $out;
	}
}
