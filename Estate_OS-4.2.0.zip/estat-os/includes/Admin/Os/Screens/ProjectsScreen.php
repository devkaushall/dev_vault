<?php
/**
 * Societies & Projects — the developments the office sells inside.
 *
 * A card per project with the numbers that matter on it, and a drawer when
 * you open one: every home the office holds inside that project, so you can
 * answer "what do you have in Trehan Iris" without leaving the screen.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Support\Status;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class ProjectsScreen {

	private const PER_PAGE = 24;

	public static function render(): void {
		$page  = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
		$stage = isset( $_GET['stage'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['stage'] ) ? '' : $_GET['stage'] ) ) ) : '';

		$args = array(
			'post_type'      => PostTypes::PROJECT,
			'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => self::PER_PAGE,
			'paged'          => $page,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( '' !== $stage ) {
			$args['meta_query'] = array(
				array(
					'key'   => '_estat_stage',
					'value' => $stage,
				),
			);
		}
		$q = new \WP_Query( $args );

		Shell::open( 'estat-projects' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Inventory', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Societies & Projects', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Every development the office sells inside. Open one to see the homes within it.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<a class="btn btn--ghost" href="#estat-project-filters">';
		Ui::ico( 'filter' );
		esc_html_e( 'Filter', 'estat-os' );
		echo '</a>';
		echo '<button type="button" class="btn btn--primary" data-drawer="project" data-id="0">';
		Ui::ico( 'plus' );
		esc_html_e( 'Add project', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<div class="filters" id="estat-project-filters">';
		$stages = Vocabulary::construction();
		printf(
			'<a class="chipf%1$s" href="%2$s">%3$s</a>',
			'' === $stage ? ' is-on' : '',
			esc_url( admin_url( 'admin.php?page=estat-projects' ) ),
			esc_html__( 'All', 'estat-os' )
		);
		foreach ( $stages as $key => $word ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s</a>',
				$key === $stage ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-projects&stage=' . $key ) ),
				esc_html( $word )
			);
		}
		echo '</div>';

		echo '<div class="bento bento--cards" id="projGrid">';
		if ( ! $q->have_posts() ) {
			echo '<div class="panel b12 anim">';
			echo Ui::empty_state(
				'layers',
				__( 'No projects yet', 'estat-os' ),
				__( 'Add the developments you sell inside, and every home in them can be grouped under one name.', 'estat-os' )
			);
			echo '</div>';
		} else {
			foreach ( $q->posts as $i => $p ) {
				self::card( (int) $p->ID, $i );
			}
		}
		echo '</div>';

		self::pager( $q, $page );

		/*
		 * "Add a project" in the quick-add menu arrives here with ?new=1.
		 * Without this the flag is read by nobody and the button looks
		 * broken: the page reloads and nothing happens.
		 */
		Shell::maybe_open_new( 'project' );
		Shell::close();
	}

	/** One project card. */
	private static function card( int $id, int $i ): void {
		$data  = Projects::to_array( $id );
		$stats = Projects::stats( $id );
		$cover = (string) ( $data['cover'] ?? '' );
		$stage = (string) ( $data['stage'] ?? '' );

		printf(
			'<button type="button" class="panel card card--lift b3 anim" style="--d:%1$dms" data-drawer="project" data-id="%2$d">',
			$i * 40,
			$id
		);

		printf(
			'<span class="pcard__cov"%1$s>%2$s</span>',
			$cover ? ' style="background-image:url(' . esc_url( $cover ) . ')"' : '',
			$cover ? '' : Ui::icon( 'layers' )
		);

		printf( '<b class="pcard__name">%1$s</b>', esc_html( get_the_title( $id ) ) );
		printf(
			'<span class="pcard__by mut">%1$s</span>',
			esc_html( (string) ( $data['developer'] ?: __( 'Builder not named', 'estat-os' ) ) )
		);

		echo '<span class="pcard__tags">';
		if ( $stage ) {
			echo Ui::status_badge( Status::CONSTRUCTION, $stage );
		}
		echo Ui::status_badge( Status::PUBLICATION, (string) get_post_status( $id ) );
		echo '</span>';

		echo '<span class="divider"></span>';
		echo '<span class="pcard__stats">';
		self::stat( __( 'Homes', 'estat-os' ), (int) $stats['listings'] );
		self::stat( __( 'Available', 'estat-os' ), (int) $stats['available'] );
		printf(
			'<span class="pcard__from"><span class="lbl">%1$s</span><b>%2$s</b></span>',
			esc_html__( 'From', 'estat-os' ),
			esc_html( ! empty( $data['price_display'] ) ? (string) $data['price_display'] : __( 'On request', 'estat-os' ) )
		);
		echo '</span>';

		/*
		 * The card opens the drawer, and the drawer is where a society is
		 * edited. Say so on the card, or nobody finds it.
		 */
		echo '<span class="pcard__cta">';
		Ui::ico( 'edit' );
		esc_html_e( 'Edit', 'estat-os' );
		echo '</span>';

		echo '</button>';
	}

	private static function stat( string $label, int $n ): void {
		echo '<span><span class="lbl">' . esc_html( $label ) . '</span>';
		echo '<b class="num">' . (int) $n . '</b></span>';
	}

	private static function pager( \WP_Query $q, int $page ): void {
		$pages = (int) $q->max_num_pages;
		if ( $pages < 2 ) {
			return;
		}
		echo '<div class="pager"><div class="pager__i">';
		printf(
			/* translators: 1: current page, 2: total pages. */
			esc_html__( 'Page %1$s of %2$s', 'estat-os' ),
			'<b>' . (int) $page . '</b>',
			esc_html( (string) $pages )
		);
		echo '</div>';
		for ( $p = 1; $p <= $pages; $p++ ) {
			printf(
				'<a class="pg%1$s" href="%2$s">%3$d</a>',
				$p === $page ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-projects&paged=' . $p ) ),
				$p
			);
		}
		echo '</div>';
	}
}
