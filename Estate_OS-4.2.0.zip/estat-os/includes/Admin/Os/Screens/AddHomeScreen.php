<?php
/**
 * Add / edit a home.
 *
 * Four sections on the left, and on the right the two things that decide
 * whether this property is ready to go out: how much of it is filled in, and
 * whether the office already has it under another name.
 *
 * The completeness number is the same one the rest of the plugin uses —
 * Listings::completeness() — so a property that says 100% here is a property
 * the public templates will draw in full.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Duplicate;
use EstatOS\Data\Highlights;
use EstatOS\Data\Listings;
use EstatOS\Data\Picker;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class AddHomeScreen {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to add listings.', 'estat-os' ) );
		}

		$id      = isset( $_GET['edit'] ) ? absint( wp_unslash( (string) ( is_array( $_GET['edit'] ) ? 0 : $_GET['edit'] ) ) ) : 0;
		$editing = $id > 0 && PostTypes::LISTING === get_post_type( $id );
		$post    = $editing ? get_post( $id ) : null;

		/*
		 * Duplicate opens this same screen with the values of another
		 * property in it. The button has always pointed at
		 * `estat-add-home&copy=ID` and nothing here ever read `copy`, so
		 * pressing Duplicate gave a blank form and the record was never
		 * seen again. The values are loaded; the id stays zero, because
		 * saving is meant to make a second property, not overwrite the
		 * first.
		 */
		$copy   = isset( $_GET['copy'] ) ? absint( wp_unslash( (string) ( is_array( $_GET['copy'] ) ? 0 : $_GET['copy'] ) ) ) : 0;
		$source = ( ! $editing && $copy > 0 && PostTypes::LISTING === get_post_type( $copy ) ) ? $copy : 0;

		wp_enqueue_media();

		$values = self::values( $editing ? $id : $source );
		$done   = $editing ? Listings::completeness( $id ) : array( 'score' => 0, 'missing' => array() );
		$dups   = $editing ? Duplicate::check_saved( 'listing', $id, 3 ) : array();

		Shell::open( 'estat-add-home' );

		self::head( $editing, $source );
		self::form( $values, $editing ? $id : 0, $done, $dups );

		Shell::close();
	}

	/** Page heading. */
	private static function head( bool $editing, int $source = 0 ): void {
		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow">';
		echo '<a class="btn btn--quiet btn--sm" href="' . esc_url( admin_url( 'admin.php?page=estat-listings' ) ) . '">';
		Ui::ico( 'chev-l' );
		esc_html_e( 'Properties', 'estat-os' );
		echo '</a></div>';
		echo '<h1>' . esc_html( $editing ? __( 'Edit this home', 'estat-os' ) : __( 'Add a home', 'estat-os' ) ) . '</h1>';
		$sub = __( 'Four short sections. The panel on the right tells you what is still missing.', 'estat-os' );
		if ( $source > 0 ) {
			$sub = sprintf(
				/* translators: %s: the property the values were copied from. */
				__( 'Copied from %s. Check the headline and the price — saving this makes a second property.', 'estat-os' ),
				(string) get_the_title( $source )
			);
		}
		echo '<p class="phead__sub mut">' . esc_html( $sub ) . '</p>';
		echo '</div></div>';
	}

	/** Everything already stored for this property. */
	private static function values( int $id ): array {
		$v = array(
			'title'            => '',
			'offer'            => 'sale',
			'property_type'    => 'apartment',
			'locality'         => '',
			'city'             => (string) Settings::get( 'city', '' ),
			'price'            => '',
			'price_on_request' => false,
			'price_type'       => 'fixed',
			'area'             => '',
			'area_unit'        => (string) Settings::get( 'default_area_unit', 'sqft' ),
			'bedrooms'         => '',
			'project_id'       => 0,
			'cover_id'         => 0,
			'gallery'          => array(),
			'highlights'       => array(),
		);

		if ( $id > 0 ) {
			$post = get_post( $id );
			if ( $post ) {
				$v['title'] = $post->post_title;
			}
			foreach ( array( 'offer', 'property_type', 'price', 'area', 'area_unit', 'bedrooms', 'project_id' ) as $key ) {
				$raw = get_post_meta( $id, '_estat_' . $key, true );
				if ( '' !== $raw && false !== $raw ) {
					$v[ $key ] = $raw;
				}
			}
			$v['price_type']       = (string) get_post_meta( $id, '_estat_price_type', true );
			$v['price_on_request'] = 'on_request' === $v['price_type'] || (bool) get_post_meta( $id, '_estat_price_on_request', true );
			$v['cover_id']   = (int) get_post_thumbnail_id( $id );
			$v['gallery']    = array_values( array_filter( array_map( 'absint', (array) get_post_meta( $id, '_estat_gallery', true ) ) ) );
			$v['highlights'] = (array) Highlights::get( $id );

			$terms = wp_get_object_terms( $id, Taxonomies::LOCALITY, array( 'fields' => 'names' ) );
			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				$v['locality'] = (string) $terms[0];
			}
		}

		return $v;
	}

	/** The form. */
	private static function form( array $v, int $id, array $done, array $dups ): void {
		$localities = get_terms( array( 'taxonomy' => Taxonomies::LOCALITY, 'hide_empty' => false, 'number' => 300 ) );
		$localities = is_wp_error( $localities ) ? array() : $localities;

		/*
		 * One form, two jobs, and the key has to match the job.
		 *
		 * The form used to carry the same pair every time — the nonce for a
		 * new property and the action for editing one. So on a new property
		 * the save checked `estat_save_listing_0` against a form that carried
		 * `estat_add_home`, refused, and showed "that link or form has
		 * expired" with the property untouched. The pair now follows the
		 * screen: new posts the new-property key, edit posts the record's.
		 */
		$nonce_action = $id > 0 ? 'estat_save_listing_' . $id : 'estat_add_home';
		$post_action  = $id > 0 ? 'estat_save_listing' : 'estat_add_home';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="estat-add-home-form">';
		wp_nonce_field( $nonce_action, 'estat_nonce' );
		echo '<input type="hidden" name="action" value="' . esc_attr( $post_action ) . '">';
		echo '<input type="hidden" name="listing_id" value="' . (int) $id . '">';

		echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:var(--s5);align-items:start">';

		echo '<div style="display:grid;gap:var(--s4)">';
		self::basics( $v, $localities );
		self::price( $v );
		self::media( $v );
		self::highlights( $v );
		self::actions( $id );
		echo '</div>';

		echo '<div style="display:grid;gap:var(--s4);position:sticky;top:0">';
		self::completeness( $done );
		self::duplicate_card( $dups, $id );
		echo '</div>';

		echo '</div></form>';
	}

	/* ---------------------------------------------------------------- sections */

	private static function basics( array $v, array $localities ): void {
		echo '<div class="panel anim" style="--d:0ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '1 · Basics', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'What is it, and where is it?', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4);grid-template-columns:1fr 1fr">';

		self::field(
			__( 'Headline', 'estat-os' ),
			'<input class="in" name="title" id="ahTitle" value="' . esc_attr( (string) $v['title'] ) . '" placeholder="' . esc_attr__( '3 BHK apartment in Sushant Lok II', 'estat-os' ) . '">',
			true
		);
		self::select( __( 'For', 'estat-os' ), 'offer', Vocabulary::offers(), (string) $v['offer'] );
		self::select( __( 'Kind', 'estat-os' ), 'property_type', Vocabulary::property_types(), (string) $v['property_type'] );

		$list = '<datalist id="estat-locality-list">';
		foreach ( $localities as $t ) {
			$list .= '<option value="' . esc_attr( $t->name ) . '"></option>';
		}
		$list .= '</datalist>';
		self::field(
			__( 'Locality', 'estat-os' ),
			'<input class="in" name="locality" list="estat-locality-list" value="' . esc_attr( (string) $v['locality'] ) . '" placeholder="' . esc_attr__( 'Start typing, or add a new one', 'estat-os' ) . '">' . $list
		);
		self::field(
			__( 'City', 'estat-os' ),
			'<input class="in" name="city" value="' . esc_attr( (string) $v['city'] ) . '">'
		);
		$pick = Picker::options( PostTypes::PROJECT, __( 'Not part of a project', 'estat-os' ), (int) $v['project_id'] );
		$opts = '';
		foreach ( (array) $pick['options'] as $key => $label ) {
			$opts .= '<option value="' . esc_attr( (string) $key ) . '"' . selected( (string) $v['project_id'], (string) $key, false ) . '>' . esc_html( (string) $label ) . '</option>';
		}
		self::field(
			__( 'Society or project', 'estat-os' ),
			'<select class="in" name="project_id">' . $opts . '</select>',
			false,
			true
		);

		echo '</div></div>';
	}

	private static function price( array $v ): void {
		echo '<div class="panel anim" style="--d:60ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '2 · Price', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'What does it cost?', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4);grid-template-columns:1fr 1fr">';

		self::field(
			__( 'Price', 'estat-os' ),
			'<input class="in" name="price" id="ahPrice" inputmode="numeric" value="' . esc_attr( (string) $v['price'] ) . '" placeholder="18500000">'
		);
		self::field(
			__( 'Price on request?', 'estat-os' ),
			'<label class="cbrow" style="height:36px"><i class="cb" data-toggle="price_on_request" role="checkbox" aria-checked="' . ( $v['price_on_request'] ? 'true' : 'false' ) . '" tabindex="0"></i>' .
			'<input type="hidden" name="price_on_request" id="ahOnRequest" value="' . ( $v['price_on_request'] ? '1' : '0' ) . '">' .
			'<span style="font-size:var(--fs-name)">' . esc_html__( 'Hide the number and say "Price on request"', 'estat-os' ) . '</span></label>'
		);
		self::field(
			__( 'Area', 'estat-os' ),
			'<input class="in" name="area" id="ahArea" inputmode="numeric" value="' . esc_attr( (string) $v['area'] ) . '" placeholder="1750">'
		);
		self::field(
			__( 'Rate per sq ft', 'estat-os' ),
			'<input class="in" id="ahRate" readonly style="background:var(--inset)" value="">'
		);
		self::field(
			__( 'Bedrooms', 'estat-os' ),
			'<input class="in" name="bedrooms" inputmode="numeric" value="' . esc_attr( (string) $v['bedrooms'] ) . '" placeholder="3">'
		);
		self::select( __( 'Measured in', 'estat-os' ), 'area_unit', Vocabulary::area_units(), (string) $v['area_unit'] );

		echo '</div></div>';
	}

	private static function media( array $v ): void {
		echo '<div class="panel anim" style="--d:120ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '3 · Media', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Photographs, and one cover', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b">';

		echo '<div class="dropzone" data-dropzone style="padding:var(--s6)">';
		Ui::ico( 'upload' );
		echo '<h4>' . esc_html__( 'Drop photographs here', 'estat-os' ) . '</h4>';
		echo '<p>' . esc_html__( 'or click to choose — JPG or PNG', 'estat-os' ) . '</p>';
		echo '</div>';

		/*
		 * The photographs, and the field that carries them.
		 *
		 * The screen has a drop zone that said "Drop photographs here" and a
		 * grid under it that nothing ever filled, and the form posted no
		 * photograph field at all — so the office could add as many pictures
		 * as it liked and none of them were ever part of the property. The
		 * grid is filled from what is stored, and one hidden field carries
		 * the list to the save.
		 */
		echo '<div id="ahMedia" style="display:grid;grid-template-columns:repeat(6,1fr);gap:var(--s2);margin-top:var(--s3)">';
		foreach ( (array) $v['gallery'] as $gid ) {
			$gid = (int) $gid;
			$url = $gid > 0 ? (string) wp_get_attachment_image_url( $gid, 'thumbnail' ) : '';
			if ( '' === $url ) {
				continue;
			}
			printf(
				'<span class="picked" data-gid="%1$d" style="position:relative;display:block;aspect-ratio:1;border-radius:var(--r-sm);overflow:hidden;background:var(--inset)">'
				. '<img src="%2$s" alt="" style="width:100%%;height:100%%;object-fit:cover">'
				. '<button type="button" class="iconbtn" data-rmgid aria-label="%3$s" style="position:absolute;top:2px;right:2px;width:20px;height:20px;background:var(--panel)">×</button>'
				. '</span>',
				$gid,
				esc_url( $url ),
				esc_attr__( 'Remove this photograph', 'estat-os' )
			);
		}
		echo '</div>';
		echo '<input type="hidden" name="gallery" id="ahGallery" value="' . esc_attr( implode( ',', array_map( 'strval', (array) $v['gallery'] ) ) ) . '">';

		$cover_url = $v['cover_id'] ? wp_get_attachment_image_url( (int) $v['cover_id'], 'medium' ) : '';
		echo '<div style="display:flex;gap:var(--s3);align-items:center;margin-top:var(--s3)">';
		echo '<div id="ahCover" style="width:64px;height:64px;border-radius:var(--r-sm);background:var(--inset);display:grid;place-items:center;overflow:hidden;flex:none">';
		echo $cover_url
			? '<img src="' . esc_url( $cover_url ) . '" alt="" style="width:100%;height:100%;object-fit:cover">'
			: Ui::icon( 'image' );
		echo '</div>';
		echo '<input type="hidden" name="cover_id" id="ahCoverId" value="' . (int) $v['cover_id'] . '">';
		echo '<button type="button" class="btn btn--ghost btn--sm" id="ahCoverPick">' . esc_html__( 'Choose cover', 'estat-os' ) . '</button>';
		echo '<span class="mut" style="font-size:var(--fs-meta)">' . esc_html__( 'The photograph buyers see first.', 'estat-os' ) . '</span>';
		echo '</div>';

		echo '</div></div>';
	}

	private static function highlights( array $v ): void {
		$lines = array_values( array_filter( array_map( 'strval', (array) $v['highlights'] ), 'strlen' ) );
		if ( ! $lines ) {
			$lines = array( '' );
		}

		// The handful of highlights worth a single press. The catalogue holds
		// the tick-boxes the office uses; showing the first few here is the
		// difference between remembering the exact code and choosing from a
		// list. The phone app has these; the desk had an empty box.
		$suggestions = array();
		foreach ( Highlights::all() as $meta ) {
			if ( count( $suggestions ) >= 6 ) {
				break;
			}
			$label = (string) $meta['label'];
			if ( in_array( $label, $lines, true ) ) {
				continue;
			}
			$suggestions[] = $label;
		}

		echo '<div class="panel anim" style="--d:180ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '4 · Highlights', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Five or six lines a buyer will actually read', 'estat-os' ) . '</div></div>';
		echo '<div class="panel__hr"><button type="button" class="btn btn--ghost btn--sm" id="ahAddHl">';
		Ui::ico( 'plus' );
		esc_html_e( 'Add line', 'estat-os' );
		echo '</button></div></div>';

		echo '<div class="panel__b">';
		if ( $suggestions ) {
			echo '<div style="display:flex;flex-wrap:wrap;gap:var(--s2);margin-bottom:var(--s3)">';
			foreach ( $suggestions as $label ) {
				echo '<button type="button" class="chip chipf" data-hl-chip="' . esc_attr( $label ) . '">' . esc_html( $label ) . '</button>';
			}
			echo '</div>';
		}

		echo '<div id="ahHl" style="display:grid;gap:var(--s2)">';
		foreach ( $lines as $line ) {
			echo self::hl_row( $line ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in hl_row().
		}
		echo '</div>';

		/*
		 * One empty entry of the group, always.
		 *
		 * Every row is name="highlights[]". If the office removes the last
		 * row, the browser posts no highlights group at all — and for a
		 * property that already had highlights that means the group is
		 * absent rather than empty, so the old lines stayed. This posts an
		 * empty row so "I removed them" is something the server can hear.
		 */
		echo '<input type="hidden" name="highlights[]" value="">';
		echo '</div></div>';
	}

	/** One highlight line, as the browser builds it too. */
	private static function hl_row( string $line ): string {
		return '<div class="hlrow">'
			. '<i class="hlrow__dot"></i>'
			. '<input class="in hlrow__in" name="highlights[]" value="' . esc_attr( $line ) . '" placeholder="' . esc_attr__( 'Add a highlight', 'estat-os' ) . '">'
			. '<button type="button" class="iconbtn hlrow__x" data-rmhl aria-label="' . esc_attr__( 'Remove this line', 'estat-os' ) . '">'
			. Ui::icon( 'x' )
			. '</button></div>';
	}

	private static function actions( int $id ): void {
		echo '<div style="display:flex;gap:var(--s2);justify-content:flex-end">';
		echo '<a class="btn btn--ghost" href="' . esc_url( admin_url( 'admin.php?page=estat-listings' ) ) . '">' . esc_html__( 'Cancel', 'estat-os' ) . '</a>';
		echo '<button type="submit" class="btn btn--ghost" name="save" value="draft">' . esc_html__( 'Save as draft', 'estat-os' ) . '</button>';
		echo '<button type="submit" class="btn btn--bronze" name="save" value="publish" id="ahPublish">' . esc_html( $id ? __( 'Save changes', 'estat-os' ) : __( 'Publish', 'estat-os' ) ) . '</button>';
		echo '</div>';
	}

	/** Right column: completeness. */
	private static function completeness( array $done ): void {
		$pct = (int) ( $done['score'] ?? 0 );
		echo '<div class="panel panel--pad anim" style="--d:100ms">';
		echo '<div class="lbl">' . esc_html__( 'Completeness', 'estat-os' ) . '</div>';
		echo '<div style="display:flex;align-items:baseline;gap:var(--s2);margin:var(--s2) 0 var(--s3)">';
		echo '<span class="dsp" style="font-size:38px" id="ahPct" data-count="' . $pct . '">0%</span>';
		echo '<span class="mut" style="font-size:var(--fs-meta)">' . esc_html__( 'ready to publish', 'estat-os' ) . '</span>';
		echo '</div>';
		echo '<div class="meter"><div class="meter__track">';
		echo '<i class="meter__fill ' . esc_attr( $pct >= 85 ? 'is-hi' : ( $pct >= 55 ? 'is-mid' : 'is-lo' ) ) . '" id="ahBar" data-w="' . $pct . '"></i>';
		echo '</div></div>';
		echo '<div class="divider"></div>';

		echo '<div id="ahChecks" style="display:grid;gap:var(--s2)">';
		foreach ( self::checklist() as $c ) {
			$ok = self::check_ok( $c, $done );
			printf(
				'<div data-check="%1$s" style="display:flex;align-items:center;gap:var(--s2);font-size:var(--fs-name);color:%2$s">',
				esc_attr( $c['key'] ),
				$ok ? 'var(--pos-deep)' : 'var(--ink-3)'
			);
			echo '<span style="width:16px;height:16px;border-radius:99px;display:grid;place-items:center;flex:none;' .
				( $ok ? 'background:var(--pos);color:#fff' : 'box-shadow:inset 0 0 0 1.5px var(--line-strong)' ) . '">';
			if ( $ok ) {
				echo '<span style="width:9px;height:9px;display:block">' . Ui::icon( 'check' ) . '</span>';
			}
			echo '</span>' . esc_html( $c['label'] ) . '</div>';
		}
		echo '</div>';

		echo '</div>';
	}

	/** The five things a property needs before it should go on the website. */
	private static function checklist(): array {
		return array(
			array( 'key' => 'title', 'label' => __( 'A clear headline', 'estat-os' ) ),
			array( 'key' => 'price', 'label' => __( 'A price, or "on request"', 'estat-os' ) ),
			array( 'key' => 'cover_id', 'label' => __( 'A main photograph', 'estat-os' ) ),
			array( 'key' => 'locality', 'label' => __( 'A locality', 'estat-os' ) ),
			array( 'key' => 'highlights', 'label' => __( 'At least three highlights', 'estat-os' ) ),
		);
	}

	private static function check_ok( array $c, array $done ): bool {
		if ( empty( $done['missing'] ) ) {
			return false;
		}
		$missing = array();
		foreach ( (array) $done['missing'] as $m ) {
			$missing[] = is_array( $m ) ? (string) ( $m['field'] ?? '' ) : (string) $m;
		}
		return ! in_array( $c['key'], $missing, true );
	}

	/** Right column: the duplicate warning. Filled live by JavaScript. */
	private static function duplicate_card( array $dups, int $id ): void {
		echo '<div class="panel anim" id="ahDupCard" style="--d:160ms;display:none;border-color:var(--warn-line);background:var(--warn-soft)">';
		echo '<div class="panel__b" style="padding:var(--s4)">';
		echo '<div style="display:flex;gap:var(--s3)">';
		echo '<span style="width:18px;height:18px;color:var(--warn);flex:none;margin-top:1px">' . Ui::icon( 'alert' ) . '</span>';
		echo '<div style="flex:1;min-width:0" id="ahDupBody"></div>';
		echo '</div></div></div>';
	}

	/* ----------------------------------------------------------------- pieces */

	private static function field( string $label, string $inner, bool $full = false, bool $span = false ): void {
		printf(
			'<div class="field"%1$s><label class="field__lbl">%2$s</label>%3$s</div>',
			( $full || $span ) ? ' style="grid-column:1/-1"' : '',
			esc_html( $label ),
			$inner
		);
	}

	private static function select( string $label, string $name, array $choices, string $current ): void {
		$opts = '';
		foreach ( $choices as $key => $word ) {
			$opts .= '<option value="' . esc_attr( (string) $key ) . '"' . selected( $current, (string) $key, false ) . '>' . esc_html( (string) $word ) . '</option>';
		}
		self::field( $label, '<select class="in" name="' . esc_attr( $name ) . '">' . $opts . '</select>' );
	}
}
