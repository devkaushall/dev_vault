<?php
/**
 * Duplicates — two records that may be the same thing.
 *
 * Both properties are drawn side by side with the rows that differ marked,
 * and a score that says how sure the machine is. The office answers two
 * questions only: are these the same, and if they are, which one stays.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Duplicate;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;

defined( 'ABSPATH' ) || exit;

final class DuplicatesScreen {

	/** Which rows to put side by side, and how to read each. */
	private const ROWS = array(
		'title'      => 'Title',
		'price'      => 'Price',
		'area'       => 'Area',
		'bedrooms'   => 'Bedrooms',
		'locality'   => 'Locality',
		'project'    => 'Project',
		'availability' => 'Availability',
		'agent'      => 'With',
		'added'      => 'Added',
	);

	public static function render(): void {
		$pairs = self::pairs();

		Shell::open( 'estat-duplicates' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Inventory', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Duplicates', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Records that look like the same property twice. Keep both if they really are different.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		printf(
			'<button type="button" class="btn btn--ghost" data-act="scan-duplicates">%1$s%2$s</button>',
			Ui::icon( 'restore' ),
			esc_html__( 'Look again', 'estat-os' )
		);
		echo '</div></div>';

		if ( ! $pairs ) {
			echo '<div class="panel anim">';
			echo Ui::empty_state(
				'check',
				__( 'Nothing looks duplicated', 'estat-os' ),
				__( 'When two properties look like the same home, they will be brought here for you to compare.', 'estat-os' ),
				'<button type="button" class="btn btn--primary" data-act="scan-duplicates">' . esc_html__( 'Check now', 'estat-os' ) . '</button>'
			);
			echo '</div>';
		} else {
			self::compare( $pairs );
		}

		Shell::close();
	}

	/**
	 * Every flagged property with the record it was matched against.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function pairs(): array {
		$q = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'     => Duplicate::META_SCORE,
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		$out = array();
		foreach ( $q->posts as $id ) {
			$stored = Duplicate::stored( (int) $id );
			if ( empty( $stored['of'] ) ) {
				continue;
			}
			$out[] = array(
				'id'      => (int) $id,
				'other'   => (int) $stored['of'],
				'score'   => (int) $stored['score'],
				'band'    => (string) $stored['band'],
				'reasons' => (array) ( $stored['reasons'] ?? array() ),
			);
		}
		return $out;
	}

	/** The split-screen comparison, one pair at a time. */
	private static function compare( array $pairs ): void {
		$index = isset( $_GET['i'] ) ? max( 0, (int) wp_unslash( (string) ( is_array( $_GET['i'] ) ? 0 : $_GET['i'] ) ) ) : 0;
		if ( $index >= count( $pairs ) ) {
			$index = 0;
		}
		$pair  = $pairs[ $index ];
		$left  = self::describe( (int) $pair['id'] );
		$right = self::describe( (int) $pair['other'] );

		echo '<input type="hidden" id="dupIdx" value="' . (int) $index . '" data-total="' . count( $pairs ) . '">';

		echo '<div class="panel anim" style="--d:0ms">';
		echo '<div class="panel__h"><div>';
		echo '<h3>' . esc_html( self::band_word( (string) $pair['band'] ) ) . '</h3>';
		echo '<div class="lbl">' . esc_html( implode( ' · ', array_map( 'strval', $pair['reasons'] ) ) ) . '</div>';
		echo '</div><div class="panel__hr">';
		printf(
			'<button type="button" class="btn btn--ghost btn--sm" id="dupPrev"%1$s>%2$s%3$s</button>',
			$index <= 0 ? ' disabled' : '',
			Ui::icon( 'chev-l' ),
			esc_html__( 'Previous', 'estat-os' )
		);
		echo '<span class="mut" style="font-size:var(--fs-meta);padding:0 var(--s2)">' . sprintf(
			/* translators: 1: which pair, 2: how many. */
			esc_html__( '%1$s of %2$s', 'estat-os' ),
			(int) ( $index + 1 ),
			count( $pairs )
		) . '</span>';
		printf(
			'<button type="button" class="btn btn--ghost btn--sm" id="dupNext"%1$s>%2$s%3$s</button>',
			$index >= count( $pairs ) - 1 ? ' disabled' : '',
			esc_html__( 'Next', 'estat-os' ),
			Ui::icon( 'chev-r' )
		);
		echo '</div></div>';

		echo '<div class="panel__b" style="padding:var(--s5)">';

		echo '<div class="cmp">';

		echo '<div class="panel panel--pad">';
		self::side( $left, __( 'This one', 'estat-os' ), (int) $pair['id'] );
		echo '</div>';

		echo '<div class="cmp__mid">';
		echo '<div class="score" style="--v:' . (int) $pair['score'] . '">';
		echo '<b>' . (int) $pair['score'] . '</b><span>' . esc_html__( 'match', 'estat-os' ) . '</span>';
		echo '</div>';
		echo '<div style="display:grid;gap:var(--s2);width:100%;margin-top:var(--s4)">';
		printf(
			'<button type="button" class="btn btn--ghost btn--sm btn--block" data-act="keep-both" data-id="%1$d" data-other="%2$d">%3$s</button>',
			(int) $pair['id'],
			(int) $pair['other'],
			esc_html__( 'Keep both', 'estat-os' )
		);
		printf(
			'<button type="button" class="btn btn--danger btn--sm btn--block" data-act="bin" data-id="%1$d">%2$s</button>',
			(int) $pair['other'],
			esc_html__( 'Move to bin', 'estat-os' )
		);
		echo '</div></div>';

		echo '<div class="panel panel--pad">';
		self::side( $right, __( 'Looks like', 'estat-os' ), (int) $pair['other'] );
		echo '</div>';

		echo '</div></div></div>';
	}

	/** One side of the comparison. */
	private static function side( array $data, string $heading, int $id ): void {
		echo '<div class="lbl" style="margin-bottom:var(--s3)">' . esc_html( $heading ) . '</div>';
		echo '<div style="display:grid;gap:var(--s3)">';
		if ( ! empty( $data['cover'] ) ) {
			echo '<img src="' . esc_url( (string) $data['cover'] ) . '" alt="" style="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:var(--r-sm)">';
		}
		echo '<div class="kv">';
		foreach ( self::ROWS as $key => $word ) {
			$value = (string) ( $data[ $key ] ?? '' );
			echo '<div class="kv__r"><span class="mut">' . esc_html( $word ) . '</span>';
			echo '<b>' . esc_html( '' === $value ? '—' : $value ) . '</b></div>';
		}
		echo '</div>';
		echo '<a class="btn btn--ghost btn--sm btn--block" href="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ) . '">' . esc_html__( 'Open', 'estat-os' ) . '</a>';
		echo '</div>';
	}

	/** Flatten a property into the rows the comparison shows. */
	private static function describe( int $id ): array {
		$d = Listings::to_array( $id );
		return array(
			'cover'        => (string) ( $d['cover'] ?? '' ),
			'title'        => get_the_title( $id ),
			'price'        => (string) ( $d['price_display'] ?? '' ) ?: __( 'On request', 'estat-os' ),
			'area'         => ! empty( $d['area_sqft'] ) ? number_format_i18n( (float) $d['area_sqft'] ) . ' sq ft' : '',
			'bedrooms'     => ! empty( $d['bedrooms'] ) ? (string) (int) $d['bedrooms'] : '',
			'locality'     => (string) ( $d['locality'][0] ?? '' ),
			'project'      => ! empty( $d['project_id'] ) ? get_the_title( (int) $d['project_id'] ) : '',
			'availability' => (string) ( $d['availability'] ?? '' ),
			'agent'        => ! empty( $d['agent_id'] ) ? get_the_title( (int) $d['agent_id'] ) : '',
			'added'        => (string) ( $d['days_listed'] ?? '' ) ? sprintf(
				/* translators: %s how long ago. */
				__( '%s days ago', 'estat-os' ),
				number_format_i18n( (int) $d['days_listed'] )
			) : '',
		);
	}

	private static function band_word( string $band ): string {
		$words = array(
			Duplicate::BAND_SAME  => __( 'These look like the same property', 'estat-os' ),
			Duplicate::BAND_NEAR  => __( 'These are very close', 'estat-os' ),
			Duplicate::BAND_MAYBE => __( 'These might be the same', 'estat-os' ),
		);
		return $words[ $band ] ?? __( 'Have a look at these two', 'estat-os' );
	}
}
