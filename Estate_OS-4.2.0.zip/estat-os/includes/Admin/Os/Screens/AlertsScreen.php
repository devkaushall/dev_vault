<?php
/**
 * Search alerts — the saved searches visitors left on the website.
 *
 * Somebody who cannot find what they want can ask to be told when it
 * appears. This is the list of everyone who asked, and what they asked for.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Search\Alerts;

defined( 'ABSPATH' ) || exit;

final class AlertsScreen {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_die( esc_html__( 'You do not have permission to see saved searches.', 'estat-os' ) );
		}

		$found = Alerts::query();
		$items = (array) ( $found['items'] ?? array() );

		Shell::open( 'estat-search-alerts' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'From the website', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Saved searches', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'People who asked to be told when a home like the one they want goes up.', 'estat-os' ) . '</p>';
		echo '</div></div>';

		if ( empty( $items ) ) {
			echo '<div class="panel"><div class="empty"><div class="empty__ico">';
			Ui::ico( 'bell' );
			echo '</div><div class="empty__t">' . esc_html__( 'Nobody is watching a search yet', 'estat-os' ) . '</div>';
			echo '<div class="empty__d">' . esc_html__( 'When a visitor on your website saves a search, it shows up here.', 'estat-os' ) . '</div></div></div>';
			Shell::close();
			return;
		}

		echo '<div class="panel anim">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'Who is watching', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Newest first', 'estat-os' ) . '</div></div>';
		printf( '<div class="panel__hr"><span class="lbl">%1$s</span></div>', esc_html( sprintf( _n( '%d saved search', '%d saved searches', (int) $found['total'], 'estat-os' ), (int) $found['total'] ) ) );
		echo '</div>';

		echo '<div class="tw"><table class="tb"><thead><tr>';
		echo '<th>' . esc_html__( 'Person', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'What they are looking for', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'How often', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Asked', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'State', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $i => $row ) {
			$filters = json_decode( (string) $row['filters'], true );
			$wanted  = is_array( $filters ) ? self::describe( $filters ) : '';
			$state   = ! empty( $row['unsubscribed'] )
				? array( __( 'Stopped', 'estat-os' ), '' )
				: ( empty( $row['confirmed'] )
					? array( __( 'Waiting for them to confirm', 'estat-os' ), 'badge--pending' )
					: array( __( 'Watching', 'estat-os' ), 'badge--live' ) );

			printf(
				'<tr class="hlrow" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%1$dms">',
				min( 300, $i * 24 )
			);
			echo '<td><div class="tcell"><span class="tname">' . esc_html( (string) ( $row['name'] ?: $row['email'] ) ) . '</span>';
			printf( '<span class="tmeta mut">%1$s</span>', esc_html( (string) $row['email'] ) );
			echo '</div></td>';
			printf( '<td><span class="mut">%1$s</span></td>', esc_html( '' !== $wanted ? $wanted : '—' ) );
			printf( '<td><span class="mut">%1$s</span></td>', esc_html( self::frequency( (string) $row['frequency'] ) ) );
			printf(
				'<td><span class="mut">%1$s</span></td>',
				esc_html( ! empty( $row['created_at'] )
					/* translators: %s: how long ago. */
					? sprintf( __( '%s ago', 'estat-os' ), human_time_diff( strtotime( (string) $row['created_at'] ) ?: time(), time() ) )
					: '—' )
			);
			printf( '<td><span class="badge %1$s">%2$s</span></td>', esc_attr( $state[1] ), esc_html( $state[0] ) );
			echo '</tr>';
		}

		echo '</tbody></table></div></div>';

		Shell::close();
	}

	/**
	 * Turn a filter blob into one readable line.
	 *
	 * @param array<string,mixed> $filters Saved filters.
	 * @return string
	 */
	private static function describe( array $filters ): string {
		$bits = array();
		$map  = array(
			'locality'   => __( 'area', 'estat-os' ),
			'city'       => __( 'city', 'estat-os' ),
			'bedrooms'   => __( 'bedrooms', 'estat-os' ),
			'property_type' => __( 'type', 'estat-os' ),
			'offer'      => __( 'looking to', 'estat-os' ),
			'min_price'  => __( 'from', 'estat-os' ),
			'max_price'  => __( 'up to', 'estat-os' ),
		);
		foreach ( $map as $key => $word ) {
			if ( ! isset( $filters[ $key ] ) || '' === (string) $filters[ $key ] ) {
				continue;
			}
			$bits[] = ucfirst( (string) $filters[ $key ] ) . ' (' . $word . ')';
		}
		return implode( ' · ', $bits );
	}

	/**
	 * Plain words for the sending rhythm.
	 *
	 * @param string $frequency Stored value.
	 * @return string
	 */
	private static function frequency( string $frequency ): string {
		$words = array(
			'instant' => __( 'As soon as one appears', 'estat-os' ),
			'daily'   => __( 'Once a day', 'estat-os' ),
			'weekly'  => __( 'Once a week', 'estat-os' ),
		);
		return $words[ $frequency ] ?? ucfirst( $frequency );
	}
}
