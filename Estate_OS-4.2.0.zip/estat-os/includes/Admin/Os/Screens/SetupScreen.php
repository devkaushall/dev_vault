<?php
/**
 * First-run setup — four short questions, then a working website.
 *
 * A new office has no idea which menu to open first, and no way to know
 * that adding properties does nothing until a page exists to show them
 * on. This asks only what cannot be guessed, builds the pages, and hands
 * back a short list of what to do next.
 *
 * Nothing here is compulsory. Everything it sets can be changed later in
 * Settings, and skipping it leaves the plugin working as before.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\PostTypes;
use EstatOS\Install\Pages;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class SetupScreen {

	public const SLUG = 'estat-setup';

	/**
	 * Should the office be nudged to run setup?
	 *
	 * True until they finish it or dismiss it. An office that already has
	 * pages in place is not nagged — they clearly did not need us.
	 *
	 * @return bool
	 */
	public static function needed(): bool {
		if ( (bool) Settings::get( 'setup_done', false ) ) {
			return false;
		}
		return array() === Pages::existing();
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to set up the office.', 'estat-os' ) );
		}

		$settings = Settings::all();
		$pages    = Pages::existing();
		$done     = array() !== $pages;

		Shell::open( self::SLUG );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Welcome', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html( $done ? __( 'Your website is ready', 'estat-os' ) : __( 'Let us set up your office', 'estat-os' ) ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html( $done
			? __( 'These pages are live now. Click any of them to see what a visitor sees.', 'estat-os' )
			: __( 'Four short questions. Everything here can be changed later, in Settings.', 'estat-os' ) ) . '</p>';
		echo '</div></div>';

		if ( $done ) {
			self::finished( $pages );
		} else {
			self::form( $settings );
		}

		Shell::close();
	}

	/**
	 * The setup questions.
	 *
	 * @param array<string,mixed> $settings Current settings.
	 * @return void
	 */
	private static function form( array $settings ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="estat-form">';
		echo '<input type="hidden" name="estat_action" value="run_setup">';
		wp_nonce_field( 'estat_run_setup', 'estat_nonce' );

		echo '<div class="panel anim">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '1. Who are you?', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'The name and number visitors will see on your website', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';
		self::field( 'office_name', __( 'Office name', 'estat-os' ), (string) $settings['office_name'], __( 'Sharma Properties', 'estat-os' ), __( 'The name your customers know you by.', 'estat-os' ), true );
		self::field( 'phone', __( 'Phone number', 'estat-os' ), (string) $settings['phone'], '+91 98765 43210', __( 'Where enquiries should call you.', 'estat-os' ), true );
		self::field( 'email', __( 'Email address', 'estat-os' ), (string) $settings['email'], 'office@example.com', __( 'We send a note here whenever a new enquiry arrives.', 'estat-os' ) );
		echo '</div></div>';

		echo '<div class="panel anim" style="--d:80ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '2. Where do you work?', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'So prices and areas read the way your customers expect', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';
		self::field(
			'cities',
			__( 'Main areas you cover', 'estat-os' ),
			is_array( $settings['cities'] ) ? implode( ', ', $settings['cities'] ) : (string) $settings['cities'],
			__( 'Gurugram, Sohna Road, Golf Course Extension', 'estat-os' ),
			__( 'Separate them with commas. You can add more any time.', 'estat-os' )
		);
		self::field( 'currency_symbol', __( 'Currency sign', 'estat-os' ), (string) $settings['currency_symbol'], '₹', __( 'The sign shown in front of every price.', 'estat-os' ) );
		self::select(
			'default_area_unit',
			__( 'How you usually measure size', 'estat-os' ),
			(string) $settings['default_area_unit'],
			array(
				'sqft' => __( 'Square feet', 'estat-os' ),
				'sqyd' => __( 'Square yards', 'estat-os' ),
				'sqm'  => __( 'Square metres', 'estat-os' ),
			),
			__( 'You can still enter a property in any unit; we convert it for you.', 'estat-os' )
		);
		echo '</div></div>';

		echo '<div class="panel anim" style="--d:160ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '3. Which pages should we build?', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Right now your properties have nowhere to appear', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s3)">';
		foreach ( Pages::catalogue() as $key => $page ) {
			printf(
				'<label class="cbrow"><span class="cb"><input type="checkbox" class="cb__i" name="pages[]" value="%1$s" checked><i></i></span>' .
				'<span><b style="font-size:var(--fs-name)">%2$s</b><span class="mut" style="display:block;font-size:var(--fs-meta)">%3$s</span></span></label>',
				esc_attr( $key ),
				esc_html( (string) $page['title'] ),
				esc_html( (string) $page['description'] )
			);
		}
		echo '</div></div>';

		echo '<div class="panel anim" style="--d:240ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( '4. How should those pages look?', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Either way you can redesign them later, in Elementor or anywhere else', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s3)">';
		printf(
			'<label class="cbrow"><span class="cb"><input type="radio" class="cb__i" name="page_style" value="ready" checked><i></i></span>' .
			'<span><b style="font-size:var(--fs-name)">%1$s</b><span class="mut" style="display:block;font-size:var(--fs-meta)">%2$s</span></span></label>',
			esc_html__( 'Ready to use', 'estat-os' ),
			esc_html__( 'Each page comes with a heading, a short introduction and your properties already laid out. Best if you want something working today.', 'estat-os' )
		);
		printf(
			'<label class="cbrow"><span class="cb"><input type="radio" class="cb__i" name="page_style" value="blank"><i></i></span>' .
			'<span><b style="font-size:var(--fs-name)">%1$s</b><span class="mut" style="display:block;font-size:var(--fs-meta)">%2$s</span></span></label>',
			esc_html__( 'Just the bare page', 'estat-os' ),
			esc_html__( 'An empty page with only the property list dropped in, so you can design the rest yourself in Elementor.', 'estat-os' )
		);
		echo '</div>';
		echo '<div class="panel__f" style="display:flex;gap:var(--s3);align-items:center;padding:var(--s4);border-top:1px solid var(--line)">';
		echo '<button type="submit" class="btn btn--bronze">' . esc_html__( 'Set up my office', 'estat-os' ) . '</button>';
		echo '<a class="btn btn--ghost" href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?estat_action=skip_setup' ), 'estat_skip_setup', 'estat_nonce' ) ) . '">';
		esc_html_e( 'Skip this, I will do it myself', 'estat-os' );
		echo '</a></div>';
		echo '</div>';

		echo '</form>';
	}

	/**
	 * One line to fill in.
	 *
	 * @param string $name     Field name.
	 * @param string $label    Words on the box.
	 * @param string $value    Current value.
	 * @param string $example  Greyed example.
	 * @param string $help     Line underneath.
	 * @param bool   $required Must be filled in.
	 * @return void
	 */
	private static function field( string $name, string $label, string $value, string $example, string $help = '', bool $required = false ): void {
		printf(
			'<div class="field"><label class="field__lbl">%1$s%2$s</label>' .
			'<input class="in" name="%3$s" value="%4$s" placeholder="%5$s"%6$s>' .
			'%7$s</div>',
			esc_html( $label ),
			$required ? ' <span style="color:var(--dang)">*</span>' : '',
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $example ),
			$required ? ' required' : '',
			'' !== $help ? '<div class="help mut">' . esc_html( $help ) . '</div>' : ''
		);
	}

	/**
	 * One line to choose from.
	 *
	 * @param string              $name  Field name.
	 * @param string              $label Words on the box.
	 * @param string              $value Current value.
	 * @param array<string,string> $options Choices.
	 * @param string              $help  Line underneath.
	 * @return void
	 */
	private static function select( string $name, string $label, string $value, array $options, string $help = '' ): void {
		echo '<div class="field"><label class="field__lbl">' . esc_html( $label ) . '</label>';
		echo '<select class="in" name="' . esc_attr( $name ) . '">';
		foreach ( $options as $key => $word ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $key ),
				selected( $value, $key, false ),
				esc_html( $word )
			);
		}
		echo '</select>';
		echo '' !== $help ? '<div class="help mut">' . esc_html( $help ) . '</div>' : '';
		echo '</div>';
	}

	/**
	 * What the office sees once setup has run.
	 *
	 * @param array<string,int> $pages Pages in place.
	 * @return void
	 */
	private static function finished( array $pages ): void {
		$catalogue = Pages::catalogue();

		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'Your pages', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Live now', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="padding:0">';
		foreach ( $pages as $key => $id ) {
			$title = isset( $catalogue[ $key ] ) ? $catalogue[ $key ]['title'] : get_the_title( $id );
			printf(
				'<div class="rowi"><div class="rowi__l"><b>%1$s</b></div>' .
				'<div class="rowi__r"><a class="btn btn--ghost btn--sm" href="%2$s" target="_blank" rel="noopener">%3$s</a>' .
				'<a class="btn btn--ghost btn--sm" href="%4$s">%5$s</a></div></div>',
				esc_html( (string) $title ),
				esc_url( (string) get_permalink( $id ) ),
				esc_html__( 'See it', 'estat-os' ),
				esc_url( (string) get_edit_post_link( $id, 'url' ) ),
				esc_html__( 'Edit', 'estat-os' )
			);
		}
		echo '</div></div>';

		self::next_steps();
	}

	/**
	 * A short, honest list of what still needs doing.
	 *
	 * Each item only appears while it is outstanding, so the list shrinks
	 * to nothing as the office gets going rather than nagging forever.
	 *
	 * @return void
	 */
	public static function next_steps(): void {
		$listings = wp_count_posts( PostTypes::LISTING );
		$live     = isset( $listings->publish ) ? (int) $listings->publish : 0;
		$drafts   = isset( $listings->draft ) ? (int) $listings->draft : 0;
		$team     = (int) wp_count_posts( PostTypes::AGENT )->publish;

		$steps = array();

		if ( 0 === $live + $drafts ) {
			$steps[] = array(
				'title' => __( 'Add your first property', 'estat-os' ),
				'note'  => __( 'It takes about two minutes. You only need a name, a price and where it is.', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-add-home' ),
				'label' => __( 'Add a home', 'estat-os' ),
			);
		} elseif ( 0 === $live ) {
			$steps[] = array(
				'title' => __( 'Put a property on your website', 'estat-os' ),
				'note'  => __( 'You have properties saved as drafts. Nobody can see a draft until you publish it.', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-listings&status=draft' ),
				'label' => __( 'See my drafts', 'estat-os' ),
			);
		}

		if ( 0 === $team ) {
			$steps[] = array(
				'title' => __( 'Add the people in your office', 'estat-os' ),
				'note'  => __( 'Enquiries can then be handed to whoever is dealing with them.', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-team' ),
				'label' => __( 'Add someone', 'estat-os' ),
			);
		}

		if ( '' === (string) Settings::get( 'email', '' ) ) {
			$steps[] = array(
				'title' => __( 'Tell us where to send new enquiries', 'estat-os' ),
				'note'  => __( 'Without an email address you will have to check this screen to spot new enquiries.', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-settings' ),
				'label' => __( 'Add an email address', 'estat-os' ),
			);
		}

		if ( array() === $steps ) {
			return;
		}

		echo '<div class="panel anim" style="--d:120ms"><div class="panel__h"><div><h3>' . esc_html__( 'What to do next', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'This list gets shorter on its own as you go', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="padding:0">';
		foreach ( $steps as $i => $step ) {
			printf(
				'<div class="rowi"><div class="rowi__l"><b>%1$d. %2$s</b><span class="mut" style="display:block;font-size:var(--fs-meta)">%3$s</span></div>' .
				'<div class="rowi__r"><a class="btn btn--bronze btn--sm" href="%4$s">%5$s</a></div></div>',
				$i + 1,
				esc_html( (string) $step['title'] ),
				esc_html( (string) $step['note'] ),
				esc_url( (string) $step['url'] ),
				esc_html( (string) $step['label'] )
			);
		}
		echo '</div></div>';
	}
}
