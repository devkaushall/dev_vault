<?php
/**
 * Site Visits — the only screen in the office that runs on a clock.
 *
 * A month calendar on the left with a dot on every day that has something in
 * it, and the visits themselves on the right, soonest first. Each visit can
 * be closed three ways — happened, did not show, called off — and that word
 * is what the reports and the agent's phone app read.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Support\Status;

defined( 'ABSPATH' ) || exit;

final class VisitsScreen {

	public static function render(): void {
		$year  = (int) ( $_GET['y'] ?? gmdate( 'Y' ) );
		$month = (int) ( $_GET['m'] ?? gmdate( 'n' ) );
		if ( $month < 1 ) {
			$month = 12;
			--$year;
		}
		if ( $month > 12 ) {
			$month = 1;
			++$year;
		}

		// Whole month plus the leading and trailing days of the weeks it
		// touches, so the calendar is always a whole number of rows.
		$first  = mktime( 0, 0, 0, $month, 1, $year );
		$days   = (int) gmdate( 't', $first );
		$lead   = ( (int) gmdate( 'N', $first ) ) - 1; // Monday-first.
		$start  = $first - $lead * DAY_IN_SECONDS;
		$cells  = (int) ceil( ( $lead + $days ) / 7 ) * 7;
		$today  = (int) current_time( 'Ymd' );

		$from = gmdate( 'Y-m-d 00:00:00', $start );
		$to   = gmdate( 'Y-m-d 23:59:59', $start + ( $cells - 1 ) * DAY_IN_SECONDS );

		$rows   = Schema::healthy() ? Visits::query( array( 'from' => $from, 'to' => $to, 'per_page' => 200 ) ) : array( 'items' => array() );
		$by_day = array();
		foreach ( (array) $rows['items'] as $v ) {
			$key = (string) mysql2date( 'Ymd', (string) $v['scheduled_at'] );
			$by_day[ $key ][] = (array) $v;
		}

		$upcoming = Schema::healthy()
			? Visits::query( array( 'from' => current_time( 'mysql', true ), 'per_page' => 20 ) )
			: array( 'items' => array() );

		Shell::open( 'estat-visits' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Customers', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Site Visits', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Who is going where, and with whom.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<button type="button" class="btn btn--primary" data-drawer="visit" data-id="0">';
		Ui::ico( 'plus' );
		esc_html_e( 'Schedule visit', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:var(--s5);align-items:start">';

		self::calendar( $year, $month, $start, $days, $lead, $cells, $by_day, $today );
		self::upcoming( (array) $upcoming['items'] );

		echo '</div>';

		Shell::maybe_open_new( 'visit' );
		Shell::close();
	}

	/** The month grid. */
	private static function calendar( int $year, int $month, int $start, int $days, int $lead, int $cells, array $by_day, int $today ): void {
		echo '<div class="panel">';
		echo '<div class="panel__h"><div>';
		echo '<h3>' . esc_html( self::month_name( $month ) . ' ' . $year ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'A dot means a visit is booked that day', 'estat-os' ) . '</div>';
		echo '</div><div class="panel__hr">';

		$prev_m = $month - 1;
		$prev_y = $year;
		if ( $prev_m < 1 ) {
			$prev_m = 12;
			--$prev_y;
		}
		$next_m = $month + 1;
		$next_y = $year;
		if ( $next_m > 12 ) {
			$next_m = 1;
			++$next_y;
		}
		printf(
			'<button type="button" class="iconbtn" data-cal="%1$d-%2$d" aria-label="%3$s">%4$s</button>',
			$prev_y,
			$prev_m,
			esc_attr__( 'Previous month', 'estat-os' ),
			Ui::icon( 'chev-l' )
		);
		printf(
			'<button type="button" class="iconbtn" data-cal="%1$d-%2$d" aria-label="%3$s">%4$s</button>',
			$next_y,
			$next_m,
			esc_attr__( 'Next month', 'estat-os' ),
			Ui::icon( 'chev-r' )
		);
		echo '</div></div>';

		echo '<div class="panel__b">';
		echo '<div class="cal" id="cal">';
		foreach ( array( 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ) as $dow ) {
			echo '<div class="cal__dh">' . esc_html( $dow ) . '</div>';
		}

		for ( $i = 0; $i < $cells; $i++ ) {
			$ts   = $start + $i * DAY_IN_SECONDS;
			$key  = (int) gmdate( 'Ymd', $ts );
			$out  = $i < $lead || $i >= $lead + $days;
			$hers = $by_day[ (string) $key ] ?? array();
			$cls  = 'cal__d';
			if ( $out ) {
				$cls .= ' is-out';
			}
			if ( $key === $today ) {
				$cls .= ' is-today';
			}
			printf( '<div class="%1$s" data-day="%2$d">', esc_attr( $cls ), $key );
			echo '<div class="cal__n">' . esc_html( gmdate( 'j', $ts ) ) . '</div>';
			foreach ( array_slice( $hers, 0, 3 ) as $v ) {
				echo '<span class="cal__e" data-drawer="visit" data-id="' . (int) $v['id'] . '" title="' . esc_attr( self::visit_title( $v ) ) . '"></span>';
			}
			if ( count( $hers ) > 3 ) {
				echo '<span class="cal__e" style="background:var(--line-strong)">+' . ( count( $hers ) - 3 ) . '</span>';
			}
			echo '</div>';
		}
		echo '</div></div></div>';
	}

	/** The list down the right-hand side. */
	private static function upcoming( array $items ): void {
		echo '<div class="panel" style="position:sticky;top:0">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'Coming up', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Soonest first', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" id="visitList" style="display:grid;gap:var(--s3)">';

		if ( ! $items ) {
			echo Ui::empty_state(
				'calendar',
				__( 'Nothing booked', 'estat-os' ),
				__( 'When you fix a time with a buyer it will appear here.', 'estat-os' )
			);
		} else {
			foreach ( $items as $i => $v ) {
				$v = (array) $v;
				printf(
					'<div class="wl__i" data-id="%1$d" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%2$dms">',
					(int) $v['id'],
					$i * 40
				);
				echo '<div class="tthumb" style="background:var(--bronze-soft);color:var(--bronze)">';
				Ui::ico( 'clock' );
				echo '</div>';
				echo '<div class="wl__b"><div class="wl__t">' . esc_html( self::visit_title( $v ) ) . '</div>';
				echo '<div class="wl__m">' . esc_html( self::when( (string) $v['scheduled_at'] ) . ' · ' . self::agent_name( (int) ( $v['agent_id'] ?? 0 ) ) ) . '</div>';
				echo '<div style="display:flex;gap:var(--s2);margin-top:var(--s2)">';
				echo Ui::status_badge( Status::VISIT, (string) ( $v['outcome'] ?? 'pending' ) );
				echo '</div></div>';
				echo '<div style="display:grid;gap:4px">';
				foreach ( array( 'done' => __( 'Done', 'estat-os' ), 'no_show' => __( 'No-show', 'estat-os' ), 'cancelled' => __( 'Cancel', 'estat-os' ) ) as $outcome => $word ) {
					printf(
						'<button type="button" class="btn btn--quiet btn--sm" data-act="visit-%1$s" data-id="%2$d">%3$s</button>',
						esc_attr( $outcome ),
						(int) $v['id'],
						esc_html( $word )
					);
				}
				echo '</div>';
				echo '</div>';
			}
		}

		echo '</div></div>';
	}

	private static function visit_title( array $v ): string {
		$prop = ! empty( $v['listing_id'] ) ? get_the_title( (int) $v['listing_id'] ) : __( 'a property', 'estat-os' );
		$lead = ! empty( $v['lead_id'] ) ? Leads::get( (int) $v['lead_id'] ) : null;
		$who  = $lead && ! empty( $lead['name'] ) ? (string) $lead['name'] : __( 'a buyer', 'estat-os' );
		/* translators: 1: buyer name, 2: property name. */
		return sprintf( __( '%1$s — %2$s', 'estat-os' ), $who, $prop );
	}

	private static function when( string $mysql ): string {
		if ( '' === $mysql ) {
			return '';
		}
		return mysql2date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), $mysql );
	}

	private static function agent_name( int $agent_id ): string {
		if ( $agent_id <= 0 ) {
			return __( 'nobody assigned', 'estat-os' );
		}
		$name = get_the_title( $agent_id );
		return $name ?: __( 'nobody assigned', 'estat-os' );
	}

	private static function month_name( int $month ): string {
		$names = array(
			1 => __( 'January', 'estat-os' ), 2 => __( 'February', 'estat-os' ), 3 => __( 'March', 'estat-os' ),
			4 => __( 'April', 'estat-os' ), 5 => __( 'May', 'estat-os' ), 6 => __( 'June', 'estat-os' ),
			7 => __( 'July', 'estat-os' ), 8 => __( 'August', 'estat-os' ), 9 => __( 'September', 'estat-os' ),
			10 => __( 'October', 'estat-os' ), 11 => __( 'November', 'estat-os' ), 12 => __( 'December', 'estat-os' ),
		);
		return $names[ $month ] ?? '';
	}
}
