<?php
/**
 * Pipeline — where every enquiry has got to.
 *
 * Five columns across the screen. A card is a person, and dragging it to
 * another column is exactly the same change the office screen would make —
 * the JavaScript calls the same AJAX endpoint with the same permission check,
 * so a drag can never do something a form could not.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class PipelineScreen {

	/** Colour for each pipeline column, in the order they appear. */
	private const TONES = array(
		'new'       => 'var(--info)',
		'contacted' => 'var(--warn)',
		'scheduled' => 'var(--bronze)',
		'won'       => 'var(--pos)',
		'lost'      => 'var(--ink-4)',
	);

	public static function render(): void {
		$columns = Vocabulary::lead_pipeline_order();
		$labels  = Vocabulary::lead_statuses();
		$cards   = self::cards( $columns );

		Shell::open( 'estat-pipeline' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Customers', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Pipeline', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Drag a person to the column they belong in now.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<div class="searchbox" style="width:210px">';
		Ui::ico( 'search' );
		echo '<input class="in" id="kbSearch" placeholder="' . esc_attr__( 'Find a deal…', 'estat-os' ) . '">';
		echo '</div>';
		echo '<button type="button" class="btn btn--ghost" data-drawer="deal" data-id="0">';
		Ui::ico( 'plus' );
		esc_html_e( 'Add deal', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<div class="kb" id="kb">';
		foreach ( $columns as $col ) {
			$list = $cards[ $col ] ?? array();
			$sum  = 0;
			foreach ( $list as $d ) {
				$sum += (float) ( $d['amount'] ?? 0 );
			}
			printf(
				'<div class="kb__col" data-col="%1$s"><div class="kb__h">',
				esc_attr( $col )
			);
			echo '<i class="dotc" style="background:' . esc_attr( self::TONES[ $col ] ?? 'var(--ink-4)' ) . '"></i>';
			echo '<h4>' . esc_html( $labels[ $col ] ?? $col ) . '</h4>';
			echo '<span class="kb__n">' . count( $list ) . '</span></div>';
			echo '<div class="kb__amt">' . esc_html( $sum > 0 ? self::short( $sum ) : '—' ) . '</div>';
			echo '<div class="kb__list">';
			foreach ( $list as $i => $d ) {
				self::card( $d, $col, $i );
			}
			if ( ! $list ) {
				echo '<div class="mut" style="font-size:var(--fs-meta);padding:var(--s3) 0">' . esc_html__( 'Nobody here', 'estat-os' ) . '</div>';
			}
			echo '</div></div>';
		}
		echo '</div>';

		Shell::close();
	}

	/** Every lead, bucketed by status. */
	private static function cards( array $columns ): array {
		$out = array();
		foreach ( $columns as $c ) {
			$out[ $c ] = array();
		}
		if ( ! Schema::healthy() ) {
			return $out;
		}

		$result = Leads::query( array( 'per_page' => 200, 'page' => 1 ) );
		foreach ( $result['items'] as $lead ) {
			$lead  = (array) $lead;
			$col   = (string) ( $lead['status'] ?? 'new' );
			if ( ! isset( $out[ $col ] ) ) {
				$col = 'new';
			}
			$out[ $col ][] = array(
				'id'     => (int) ( $lead['id'] ?? 0 ),
				'title'  => (string) ( $lead['name'] ?? '' ) ?: __( 'No name given', 'estat-os' ),
				'prop'   => self::interest( $lead ),
				'amount' => (float) ( $lead['budget_max'] ?? 0 ),
				'who'    => self::agent_initials( (int) ( $lead['assigned_agent_id'] ?? 0 ) ),
			);
		}
		return $out;
	}

	private static function interest( array $lead ): string {
		if ( ! empty( $lead['listing_id'] ) ) {
			return get_the_title( (int) $lead['listing_id'] );
		}
		if ( ! empty( $lead['locality'] ) ) {
			return (string) $lead['locality'];
		}
		return __( 'Nothing named yet', 'estat-os' );
	}

	private static function agent_initials( int $agent_id ): string {
		if ( $agent_id <= 0 ) {
			return '—';
		}
		$name = get_the_title( $agent_id );
		return $name ? Ui::initials( $name ) : '—';
	}

	private static function card( array $d, string $col, int $i ): void {
		printf(
			'<div class="kcard" data-col="%1$s" data-id="%2$d" style="animation:eos-rise 340ms var(--e-out) both;animation-delay:%3$dms">',
			esc_attr( $col ),
			(int) $d['id'],
			$i * 40
		);
		echo '<div class="kcard__t">' . esc_html( $d['title'] ) . '</div>';
		echo '<div class="kcard__m">';
		Ui::ico( 'home' );
		echo '<span>' . esc_html( $d['prop'] ) . '</span></div>';
		echo '<div class="kcard__f"><span class="kcard__av">' . esc_html( $d['who'] ) . '</span>';
		echo '<span class="kcard__amt num">' . esc_html( $d['amount'] > 0 ? self::short( $d['amount'] ) : '—' ) . '</span></div>';
		echo '</div>';
	}

	/** 1,20,00,000 becomes "1.2 Cr". */
	private static function short( float $n ): string {
		if ( $n >= 10000000 ) {
			return '₹' . rtrim( rtrim( number_format_i18n( $n / 10000000, 2 ), '0' ), '.' ) . ' Cr';
		}
		if ( $n >= 100000 ) {
			return '₹' . rtrim( rtrim( number_format_i18n( $n / 100000, 2 ), '0' ), '.' ) . ' L';
		}
		if ( $n >= 1000 ) {
			return '₹' . rtrim( rtrim( number_format_i18n( $n / 1000, 1 ), '0' ), '.' ) . ' K';
		}
		return '₹' . number_format_i18n( $n );
	}
}
