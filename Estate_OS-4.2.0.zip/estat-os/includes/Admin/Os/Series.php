<?php
/**
 * Estat.OS — small number series for the sparklines and the reports screen.
 *
 * Every series is one grouped query and is then cached for five minutes.
 * A dashboard that ran eight queries per card would be a slow dashboard,
 * and these numbers only ever have to be roughly current.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os;

use EstatOS\Data\PostTypes;
use EstatOS\Install\Schema;

defined( 'ABSPATH' ) || exit;

final class Series {

	private const CACHE = 5 * MINUTE_IN_SECONDS;

	/**
	 * New listings per day, oldest bucket first.
	 *
	 * @param int $days How many daily buckets.
	 * @return array<int,int>
	 */
	public static function listings( int $days = 8 ): array {
		$key = 'estat_os_ser_listings_' . $days;
		$hit = get_transient( $key );
		if ( is_array( $hit ) ) {
			return $hit;
		}

		global $wpdb;
		$days  = max( 2, min( 90, $days ) );
		$since = gmdate( 'Y-m-d H:i:s', time() - ( $days - 1 ) * DAY_IN_SECONDS );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(post_date) AS d, COUNT(*) AS c
				 FROM {$wpdb->posts}
				 WHERE post_type = %s
				   AND post_status IN ('publish','draft','pending','private')
				   AND post_date >= %s
				 GROUP BY DATE(post_date)",
				PostTypes::LISTING,
				$since
			)
		);
		// phpcs:enable

		$out = self::bucket( $rows, $days );
		set_transient( $key, $out, self::CACHE );
		return $out;
	}

	/**
	 * New enquiries per day.
	 *
	 * @param int $days How many daily buckets.
	 * @return array<int,int>
	 */
	public static function leads( int $days = 8 ): array {
		$key = 'estat_os_ser_leads_' . $days;
		$hit = get_transient( $key );
		if ( is_array( $hit ) ) {
			return $hit;
		}

		$out = array();
		if ( Schema::healthy() ) {
			global $wpdb;
			$days  = max( 2, min( 90, $days ) );
			$since = gmdate( 'Y-m-d H:i:s', time() - ( $days - 1 ) * DAY_IN_SECONDS );
			$table = Schema::table( 'estat_leads' );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT DATE(created_at) AS d, COUNT(*) AS c
					 FROM {$table}
					 WHERE created_at >= %s
					 GROUP BY DATE(created_at)",
					$since
				)
			);
			// phpcs:enable
			$out = self::bucket( $rows, $days );
		} else {
			$out = array_fill( 0, $days, 0 );
		}

		set_transient( $key, $out, self::CACHE );
		return $out;
	}

	/**
	 * Visits scheduled per day.
	 *
	 * @param int $days How many daily buckets.
	 * @return array<int,int>
	 */
	public static function visits( int $days = 8 ): array {
		$key = 'estat_os_ser_visits_' . $days;
		$hit = get_transient( $key );
		if ( is_array( $hit ) ) {
			return $hit;
		}

		$out = array();
		if ( Schema::healthy() ) {
			global $wpdb;
			$days  = max( 2, min( 90, $days ) );
			$since = gmdate( 'Y-m-d H:i:s', time() - ( $days - 1 ) * DAY_IN_SECONDS );
			$table = Schema::table( 'estat_visits' );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT DATE(scheduled_at) AS d, COUNT(*) AS c
					 FROM {$table}
					 WHERE scheduled_at >= %s
					 GROUP BY DATE(scheduled_at)",
					$since
				)
			);
			// phpcs:enable
			$out = self::bucket( $rows, $days );
		} else {
			$out = array_fill( 0, $days, 0 );
		}

		set_transient( $key, $out, self::CACHE );
		return $out;
	}

	/**
	 * Turn sparse `DATE(x)` rows into one value per day, oldest first.
	 *
	 * @param array<int,object> $rows Rows with ->d and ->c.
	 * @param int               $days Bucket count.
	 * @return array<int,int>
	 */
	private static function bucket( array $rows, int $days ): array {
		$filled = array();
		foreach ( $rows as $r ) {
			$filled[ (string) $r->d ] = (int) $r->c;
		}
		$out = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$day   = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
			$out[] = (int) ( $filled[ $day ] ?? 0 );
		}
		return $out;
	}

	/** Forget every cached series. Called when records change. */
	public static function forget(): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_estat_os_ser_%'" );
	}

	/**
	 * An SVG sparkline for a series.
	 *
	 * @param array<int,int> $values Oldest first.
	 * @param string         $tone   CSS colour.
	 */
	public static function spark( array $values, string $tone = 'var(--bronze)' ): string {
		$values = array_values( array_map( 'intval', $values ) );
		if ( count( $values ) < 2 ) {
			$values = array( 0, 0 );
		}
		$max = max( $values );
		$max = $max > 0 ? $max : 1;
		$n   = count( $values );
		$pts = array();
		foreach ( $values as $i => $v ) {
			$x = ( $n > 1 ) ? ( $i * 120 / ( $n - 1 ) ) : 0;
			$y = 30 - ( $v / $max ) * 26;
			$pts[] = round( $x, 1 ) . ' ' . round( $y, 1 );
		}
		$line = implode( ' L', $pts );
		return '<svg class="spark" viewBox="0 0 120 34" preserveAspectRatio="none" aria-hidden="true">' .
			'<path d="M' . $line . '" stroke="' . esc_attr( $tone ) . '" style="--len:150"/></svg>';
	}

	/**
	 * Which page the address is asking for.
	 *
	 * @return int
	 */
	public static function page(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['paged'] ) ? (int) wp_unslash( is_array( $_GET['paged'] ) ? 1 : $_GET['paged'] ) : 1;
		return max( 1, $page );
	}

	/**
	 * The row of page numbers under a list.
	 *
	 * @param array<string,mixed> $res  Anything that carries `page` and `pages`.
	 * @param string              $slug The screen, so the links point at it.
	 * @return void
	 */
	public static function pager( array $res, string $slug ): void {
		$page  = max( 1, (int) ( $res['page'] ?? 1 ) );
		$pages = max( 1, (int) ( $res['pages'] ?? 1 ) );
		if ( $pages <= 1 ) {
			return;
		}

		$base = admin_url( 'admin.php?page=' . sanitize_key( $slug ) );
		echo '<div class="pager"><div class="pager__i">';

		printf(
			'<a class="pg%1$s" href="%2$s" aria-label="%3$s">%4$s</a>',
			$page <= 1 ? ' is-off' : '',
			esc_url( $base . '&paged=' . max( 1, $page - 1 ) ),
			esc_attr__( 'Previous page', 'estat-os' ),
			'<svg class="ico"><use href="#eos-i-chev-l"></use></svg>'
		);

		$from = max( 1, $page - 2 );
		$to   = min( $pages, $from + 4 );
		$from = max( 1, $to - 4 );

		for ( $p = $from; $p <= $to; $p++ ) {
			printf(
				'<a class="pg%1$s" href="%2$s">%3$d</a>',
				$p === $page ? ' is-on' : '',
				esc_url( $base . '&paged=' . $p ),
				$p
			);
		}

		printf(
			'<a class="pg%1$s" href="%2$s" aria-label="%3$s">%4$s</a>',
			$page >= $pages ? ' is-off' : '',
			esc_url( $base . '&paged=' . min( $pages, $page + 1 ) ),
			esc_attr__( 'Next page', 'estat-os' ),
			'<svg class="ico"><use href="#eos-i-chev-r"></use></svg>'
		);

		echo '</div></div>';
	}
}
