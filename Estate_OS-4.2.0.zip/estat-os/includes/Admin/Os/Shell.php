<?php
/**
 * Estat.OS — the office shell.
 *
 * Two sidebars, one inside the other's territory, and never in each other's
 * way:
 *
 *   WordPress's own left menu           — untouched, belongs to WordPress
 *     the office's module navigation    — ours, drawn in the content area
 *       the top bar and the canvas      — ours, where a module is worked in
 *
 * The office used to push the WordPress menu off the screen and put its own
 * navigation in the space it vacated. That read as a different program
 * wearing WordPress's clothes. Now both menus are on screen at once: the
 * outer one is WordPress's, the inner one is ours, and the two are drawn in
 * deliberately different materials — WordPress's is dark, ours is light — so
 * the eye never has to work out which is which.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os;

use EstatOS\Data\Bin;
use EstatOS\Data\Duplicate;
use EstatOS\Data\Health;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;
use EstatOS\Support\Logo;
use EstatOS\Support\Status;
use EstatOS\Work\MyDay;

defined( 'ABSPATH' ) || exit;

final class Shell {

	/**
	 * The fifteen modules, written down once.
	 *
	 * The sidebar, the command palette, the quick-add menu and the WordPress
	 * menu registration all read from this list, so a module can never be
	 * reachable from one place and missing from another.
	 *
	 * 'group' => which cluster of the sidebar it belongs to.
	 * 'icon'  => sprite name.
	 * 'badge' => optional count shown on the right of the row.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function modules(): array {
		return array(
			'estat-today'       => array(
				'title' => __( 'Today', 'estat-os' ),
				'icon'  => 'today',
				'group' => __( 'Overview', 'estat-os' ),
				'cap'   => 'estat_manage_listings',
			),
			'estat-reports'     => array(
				'title' => __( 'Reports & Analytics', 'estat-os' ),
				'icon'  => 'chart',
				'group' => __( 'Overview', 'estat-os' ),
				'cap'   => 'estat_view_reports',
			),

			'estat-listings'    => array(
				'title' => __( 'Properties', 'estat-os' ),
				'icon'  => 'home',
				'group' => __( 'Inventory', 'estat-os' ),
				'cap'   => 'estat_manage_listings',
				'badge' => 'listings',
			),
			'estat-projects'    => array(
				'title' => __( 'Societies & Projects', 'estat-os' ),
				'icon'  => 'layers',
				'group' => __( 'Inventory', 'estat-os' ),
				'cap'   => 'estat_manage_projects',
				'badge' => 'projects',
			),
			'estat-gallery'     => array(
				'title' => __( 'Gallery & Media', 'estat-os' ),
				'icon'  => 'image',
				'group' => __( 'Inventory', 'estat-os' ),
				'cap'   => 'estat_manage_listings',
			),
			'estat-duplicates'  => array(
				'title' => __( 'Duplicates', 'estat-os' ),
				'icon'  => 'copy',
				'group' => __( 'Inventory', 'estat-os' ),
				'cap'   => 'estat_manage_listings',
				'badge' => 'duplicates',
			),

			'estat-enquiries'   => array(
				'title' => __( 'Enquiries', 'estat-os' ),
				'icon'  => 'inbox',
				'group' => __( 'Customers', 'estat-os' ),
				'cap'   => 'estat_manage_leads',
				'badge' => 'enquiries',
			),
			'estat-pipeline'    => array(
				'title' => __( 'Pipeline', 'estat-os' ),
				'icon'  => 'kanban',
				'group' => __( 'Customers', 'estat-os' ),
				'cap'   => 'estat_manage_leads',
			),
			'estat-visits'      => array(
				'title' => __( 'Site Visits', 'estat-os' ),
				'icon'  => 'calendar',
				'group' => __( 'Customers', 'estat-os' ),
				'cap'   => 'estat_manage_visits',
				'badge' => 'visits',
			),

			'estat-team'        => array(
				'title' => __( 'Team', 'estat-os' ),
				'icon'  => 'users',
				'group' => __( 'People', 'estat-os' ),
				'cap'   => 'estat_manage_team',
				'badge' => 'team',
			),
			'estat-requests'    => array(
				'title' => __( 'Change Requests', 'estat-os' ),
				'icon'  => 'shuffle',
				'group' => __( 'People', 'estat-os' ),
				'cap'   => 'estat_request_listings',
				'badge' => 'requests',
			),

			'estat-forms'       => array(
				'title' => __( 'Forms', 'estat-os' ),
				'icon'  => 'form',
				'group' => __( 'Build', 'estat-os' ),
				'cap'   => 'estat_manage_forms',
			),
			'estat-spreadsheet' => array(
				'title' => __( 'Import & Export', 'estat-os' ),
				'icon'  => 'upload',
				'group' => __( 'Build', 'estat-os' ),
				'cap'   => 'estat_import_inventory',
			),

			'estat-settings'    => array(
				'title' => __( 'Settings', 'estat-os' ),
				'icon'  => 'settings',
				'group' => __( 'System', 'estat-os' ),
				'cap'   => 'estat_manage_settings',
			),
			'estat-bin'         => array(
				'title' => __( 'Bin', 'estat-os' ),
				'icon'  => 'trash',
				'group' => __( 'System', 'estat-os' ),
				'cap'   => 'estat_bin_listings',
				'badge' => 'bin',
			),
		);
	}

	public static function counts(): array {
		$cached = get_transient( 'estat_os_counts' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$counts = array(
			'listings'   => self::count_posts( PostTypes::LISTING, array( 'publish', 'draft', 'pending', 'private' ) ),
			'projects'   => self::count_posts( PostTypes::PROJECT, array( 'publish', 'draft', 'pending', 'private' ) ),
			'team'       => self::count_posts( PostTypes::AGENT, array( 'publish', 'draft', 'private' ) ),
			'duplicates' => self::count_duplicates(),
			'bin'        => Bin::count(),
		);

		$leads       = Leads::counts();
		$counts['enquiries'] = (int) ( $leads['new'] ?? 0 );

		$visits        = Visits::counts();
		$counts['visits'] = (int) ( $visits['upcoming'] ?? 0 );

		$counts['requests'] = self::count_requests();

		set_transient( 'estat_os_counts', $counts, MINUTE_IN_SECONDS );
		return $counts;
	}

	/** Clear the cached sidebar counts. Called whenever a record changes. */
	public static function forget_counts(): void {
		delete_transient( 'estat_os_counts' );
	}

	private static function count_posts( string $type, array $statuses ): int {
		$q = new \WP_Query(
			array(
				'post_type'      => $type,
				'post_status'    => $statuses,
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			)
		);
		return (int) $q->found_posts;
	}

	private static function count_duplicates(): int {
		$q = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'meta_query'     => array(
					array(
						'key'     => Duplicate::META_SCORE,
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			)
		);
		return (int) $q->found_posts;
	}

	private static function count_requests(): int {
		$pending = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'pending',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			)
		);
		$asked = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'meta_query'     => array(
					array(
						'key'     => '_estat_request_status',
						'value'   => 'pending',
						'compare' => '=',
					),
				),
			)
		);
		return (int) $pending->found_posts + (int) $asked->found_posts;
	}

	/**
	 * The notifications behind the bell.
	 *
	 * Deliberately short: the bell is a nudge, not an inbox. Everything here
	 * is a real count taken from the office's own records.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function notifications(): array {
		$out     = array();
		$summary = MyDay::summary();
		$counts  = self::counts();

		if ( ! empty( $summary['followups'] ) ) {
			$out[] = array(
				'icon'  => 'clock',
				'tone'  => 'warn',
				'title' => __( 'Follow-ups are overdue', 'estat-os' ),
				'when'  => __( 'now', 'estat-os' ),
				'msg'   => sprintf(
					/* translators: %d is a number of enquiries. */
					_n( '%d enquiry is waiting on a call.', '%d enquiries are waiting on a call.', (int) $summary['followups'], 'estat-os' ),
					(int) $summary['followups']
				),
			);
		}
		if ( ! empty( $summary['enquiries'] ) ) {
			$out[] = array(
				'icon'  => 'inbox',
				'tone'  => 'info',
				'title' => __( 'New enquiries', 'estat-os' ),
				'when'  => __( 'today', 'estat-os' ),
				'msg'   => sprintf(
					/* translators: %d is a number of enquiries. */
					_n( '%d new enquiry has not been answered yet.', '%d new enquiries have not been answered yet.', (int) $summary['enquiries'], 'estat-os' ),
					(int) $summary['enquiries']
				),
			);
		}
		if ( ! empty( $counts['requests'] ) ) {
			$out[] = array(
				'icon'  => 'shuffle',
				'tone'  => 'warn',
				'title' => __( 'Change requests waiting', 'estat-os' ),
				'when'  => __( 'pending', 'estat-os' ),
				'msg'   => sprintf(
					/* translators: %d is a number of requests. */
					_n( '%d change is waiting for your yes or no.', '%d changes are waiting for your yes or no.', (int) $counts['requests'], 'estat-os' ),
					(int) $counts['requests']
				),
				'link'  => 'estat-requests',
			);
		}
		if ( ! empty( $counts['duplicates'] ) ) {
			$out[] = array(
				'icon'  => 'copy',
				'tone'  => 'info',
				'title' => __( 'Possible duplicates found', 'estat-os' ),
				'when'  => __( 'unread', 'estat-os' ),
				'msg'   => sprintf(
					/* translators: %d is a number of properties. */
					_n( '%d property looks like a copy of another.', '%d properties look like copies of another.', (int) $counts['duplicates'], 'estat-os' ),
					(int) $counts['duplicates']
				),
				'link'  => 'estat-duplicates',
			);
		}
		if ( ! empty( $summary['listings'] ) ) {
			$out[] = array(
				'icon'  => 'home',
				'tone'  => 'warn',
				'title' => __( 'Properties need attention', 'estat-os' ),
				'when'  => __( 'open', 'estat-os' ),
				'msg'   => sprintf(
					/* translators: %d is a number of properties. */
					_n( '%d property is incomplete or was sent back.', '%d properties are incomplete or were sent back.', (int) $summary['listings'], 'estat-os' ),
					(int) $summary['listings']
				),
				'link'  => 'estat-listings',
			);
		}

		if ( ! $out ) {
			$out[] = array(
				'icon'  => 'check',
				'tone'  => 'pos',
				'title' => __( 'Nothing is waiting on you', 'estat-os' ),
				'when'  => '',
				'msg'   => __( 'Every lead has been answered and every listing is complete.', 'estat-os' ),
			);
		}

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Drawing
	 * ------------------------------------------------------------------ */

	/**
	 * Open the app: sprite, sidebar, top bar, canvas.
	 *
	 * @param string $slug The module running, so its row can be marked.
	 */
	public static function open( string $slug ): void {
		$modules = self::modules();
		$title   = $modules[ $slug ]['title'] ?? __( 'Today', 'estat-os' );
		$user    = wp_get_current_user();

		Ui::sprite();
		echo '<div class="estat-os">';
		echo '<div class="app" id="app">';

		self::rail( $slug );

		echo '<div class="main">';
		self::topbar( $title, $user );
		echo '<main class="canvas" id="canvas">';
		echo '<section class="screen" data-screen="' . esc_attr( $slug ) . '">';
	}

	/** Close the canvas, the app, and draw the overlays every screen shares. */
	public static function close(): void {
		echo '</section>';
		echo '</main><!-- /canvas -->';
		echo '</div><!-- /main -->';
		echo '</div><!-- /app -->';

		self::overlays();

		echo '</div><!-- /estat-os -->';
	}

	/**
	 * The slugs in the order the module navigation shows them, split into
	 * the clusters they belong to.
	 *
	 * @return array{0:string[],1:array<string,string[]>}
	 */
	private static function grouped(): array {
		$order  = array();
		$groups = array();

		foreach ( self::modules() as $slug => $m ) {
			if ( ! current_user_can( $m['cap'] ) ) {
				continue;
			}
			$g = (string) $m['group'];
			if ( ! isset( $groups[ $g ] ) ) {
				$groups[ $g ] = array();
				$order[]      = $g;
			}
			$groups[ $g ][] = $slug;
		}

		return array( $order, $groups );
	}

	/**
	 * The office's own module navigation.
	 *
	 * This is the second sidebar — the one that lives inside the content
	 * area WordPress gives us, immediately to the right of WordPress's own
	 * menu. It carries only our modules, so it can be shorter and plainer
	 * than a whole-site menu, and it is drawn light on purpose: two dark
	 * columns side by side read as one confused column.
	 *
	 * @param string $slug Which module is open.
	 * @return void
	 */
	private static function rail( string $slug ): void {
		$modules = self::modules();
		$counts  = self::counts();

		echo '<aside class="rail" id="rail" aria-label="' . esc_attr__( 'Office modules', 'estat-os' ) . '">';

		/*
		 * The office's own name and mark, not ours. A square with an "E" in it
		 * said "this is a demo"; the person opening this screen at nine in the
		 * morning works for Mayfair, and the app should say so. The picture
		 * comes from Settings, or from WordPress if the office never set it
		 * there, and falls back to the drawn roof only if there is nothing at
		 * all — never to a broken image.
		 */
		$mark   = Logo::img( 'estat-logo--plate', '' );
		$office = Settings::office_name();

		echo '<div class="brand' . ( '' !== $mark ? ' brand--logo' : '' ) . '">';
		if ( '' !== $mark ) {
			echo '<span class="brand__mark brand__mark--logo">' . $mark . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built by Logo::img().
		} else {
			echo '<div class="brand__mark">';
			Ui::ico( 'roof' );
			echo '</div>';
		}
		echo '<div class="brand__txt">';
		echo '<div class="brand__name">' . esc_html( $office ) . '</div>';
		echo '<div class="brand__sub">' . esc_html__( 'The office', 'estat-os' ) . '</div>';
		echo '</div>';
		echo '</div>';

		echo '<nav class="rail__scroll rail-scroll" id="nav">';

		list( $order, $groups ) = self::grouped();
		foreach ( $order as $g ) {
			echo '<div class="rail__group">';
			echo '<div class="rail__gname">' . esc_html( $g ) . '</div>';
			foreach ( $groups[ $g ] as $mslug ) {
				$m      = $modules[ $mslug ];
				$active = ( $mslug === $slug ) ? ' is-active' : '';
				$badge  = '';
				if ( ! empty( $m['badge'] ) && ! empty( $counts[ $m['badge'] ] ) ) {
					$badge = '<span class="nav__badge">' . esc_html( (string) $counts[ $m['badge'] ] ) . '</span>';
				}
				printf(
					'<a class="nav%1$s" href="%2$s"%3$s>%4$s<span class="nav__txt">%5$s</span>%6$s</a>',
					esc_attr( $active ),
					esc_url( admin_url( 'admin.php?page=' . $mslug ) ),
					( $mslug === $slug ) ? ' aria-current="page"' : '',
					Ui::icon( $m['icon'] ),
					esc_html( $m['title'] ),
					$badge
				);
			}
			echo '</div>';
		}

		echo '</nav>';

		echo '<div class="rail__foot">';
		echo '<button type="button" class="rail__collapse" id="railToggle" aria-pressed="false">';
		Ui::ico( 'collapse' );
		echo '<span class="nav__txt">' . esc_html__( 'Collapse', 'estat-os' ) . '</span></button>';
		echo '</div>';

		echo '</aside>';
	}

	/** The top bar. */
	private static function topbar( string $title, \WP_User $user ): void {
		echo '<header class="top">';

		echo '<div class="top__crumb"><h1 class="dsp">' . esc_html( $title ) . '</h1></div>';

		echo '<div class="search">';
		Ui::ico( 'search', 'search__ico' );
		echo '<input class="search__in" id="searchIn" type="search" placeholder="' . esc_attr__( 'Search properties, leads, people…', 'estat-os' ) . '" autocomplete="off" aria-label="' . esc_attr__( 'Search', 'estat-os' ) . '">';
		echo '<span class="search__kbd"><kbd>⌘</kbd><kbd>K</kbd></span>';
		echo '</div>';

		echo '<div class="top__acts">';

		// Quick add — a menu, not a screen, because the thing you want to add
		// depends on what you were just looking at.
		echo '<button type="button" class="btn btn--bronze btn--sm" data-quickadd>';
		Ui::ico( 'plus' );
		esc_html_e( 'Quick Add', 'estat-os' );
		echo '</button>';

		$notes = self::notifications();
		$hot   = count( $notes ) > 1;
		echo '<button type="button" class="iconbtn" id="bellBtn" title="' . esc_attr__( 'Notifications', 'estat-os' ) . '" aria-haspopup="true">';
		Ui::ico( 'bell' );
		echo ( $hot ? '<i class="iconbtn__dot"></i>' : '' );
		echo '</button>';

		$name = $user->display_name ?: $user->user_login;
		echo '<button type="button" class="me" id="meBtn" aria-haspopup="true">';
		echo '<span class="me__av">' . esc_html( Ui::initials( $name ) ) . '</span>';
		echo '<span><span class="me__name">' . esc_html( $name ) . '</span>';
		echo '<span class="me__role">' . esc_html( self::role_word( $user ) ) . '</span></span>';
		echo '</button>';

		echo '</div>';
		echo '</header>';
	}

	/** A plain word for the highest Estat capability this person holds. */
	private static function role_word( \WP_User $user ): string {
		if ( $user->has_cap( 'estat_manage_settings' ) ) {
			return __( 'Office Owner', 'estat-os' );
		}
		if ( $user->has_cap( 'estat_manage_listings' ) ) {
			return __( 'Office Staff', 'estat-os' );
		}
		if ( $user->has_cap( 'estat_manage_leads' ) ) {
			return __( 'Sales', 'estat-os' );
		}
		return __( 'Agent', 'estat-os' );
	}

	/** Drawer, command palette, toasts, popover, bulk bar. */
	private static function overlays(): void {
		echo '<div class="scrim" id="scrim" hidden></div>';

		echo '<aside class="drawer" id="drawer" role="dialog" aria-modal="true" aria-labelledby="dwTitle">';
		echo '<div class="dw__h"><div class="dw__t">';
		echo '<div class="lbl" id="dwKicker"></div>';
		echo '<h2 id="dwTitle"></h2><p id="dwSub"></p>';
		echo '</div>';
		echo '<button type="button" class="iconbtn" id="dwClose" aria-label="' . esc_attr__( 'Close', 'estat-os' ) . '">';
		Ui::ico( 'x' );
		echo '</button></div>';
		echo '<div class="dw__b" id="dwBody"></div>';
		echo '<div class="dw__f" id="dwFoot"></div>';
		echo '</aside>';

		echo '<div class="cmdk" id="cmdk" role="dialog" aria-modal="true" aria-label="' . esc_attr__( 'Search', 'estat-os' ) . '">';
		echo '<div class="cmdk__p">';
		echo '<input class="cmdk__in" id="cmdkIn" type="search" placeholder="' . esc_attr__( 'Search properties, leads, people, settings…', 'estat-os' ) . '">';
		echo '<div class="cmdk__l" id="cmdkList"></div>';
		echo '<div class="cmdk__f"><span>↑↓ ' . esc_html__( 'to move', 'estat-os' ) . '</span><span>↵ ' . esc_html__( 'to open', 'estat-os' ) . '</span><span>esc ' . esc_html__( 'to close', 'estat-os' ) . '</span></div>';
		echo '</div></div>';

		echo '<div class="toasts" id="toasts" role="status" aria-live="polite"></div>';
		echo '<div class="pop" id="pop"></div>';

		echo '<div class="bulkbar" id="bulkbar">';
		echo '<b id="bulkN">0 ' . esc_html__( 'selected', 'estat-os' ) . '</b>';
		echo '<button type="button" class="btn btn--sm" data-bulk="restore" style="background:rgba(255,255,255,.1);color:#fff">' . esc_html__( 'Restore', 'estat-os' ) . '</button>';
		echo '<button type="button" class="btn btn--sm" data-bulk="delete" style="background:var(--dang);color:#fff">' . esc_html__( 'Delete forever', 'estat-os' ) . '</button>';
		echo '<button type="button" class="iconbtn bulkbar__x" id="bulkX" aria-label="' . esc_attr__( 'Clear selection', 'estat-os' ) . '">';
		Ui::ico( 'x' );
		echo '</button></div>';
	}

	/* ---------------------------------------------------------------------
	 * Menus handed to JavaScript
	 * ------------------------------------------------------------------ */

	/**
	 * Open the create drawer when a screen is reached with ?new=1.
	 *
	 * The quick-add menu used to send the office to `...&new=1`, which no
	 * screen ever read: the page simply reloaded and nothing happened. Now
	 * the drawer opens itself, and the flag is taken back out of the
	 * address, so a later refresh does not open it again.
	 *
	 * @param string $kind Drawer kind: 'project', 'enquiry', 'visit'.
	 * @return void
	 */
	public static function maybe_open_new( string $kind ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a flag, not data.
		if ( empty( $_GET['new'] ) ) {
			return;
		}

		echo '<script>(function(){'
			. 'function go(){'
			. 'if(window.EstatOS&&window.EstatOS.openDrawer){window.EstatOS.openDrawer(' . wp_json_encode( $kind, JSON_HEX_TAG | JSON_HEX_AMP ) . ',"0");}'
			. 'if(window.history&&window.history.replaceState){try{var u=new URL(window.location.href);'
			. 'u.searchParams.delete("new");window.history.replaceState({},"",u.toString());}catch(e){}}'
			. '}'
			. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",go);}else{go();}'
			. '})();</script>';
	}

	/** Quick-add entries. */
	public static function quick_add(): array {
		$out = array();
		if ( current_user_can( 'estat_manage_listings' ) ) {
			$out[] = array(
				'icon' => 'home',
				'label' => __( 'Add a home', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-add-home' ),
			);
		}
		if ( current_user_can( 'estat_manage_projects' ) ) {
			$out[] = array(
				'icon' => 'layers',
				'label' => __( 'Add a project', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-projects&new=1' ),
			);
		}
		if ( current_user_can( 'estat_manage_leads' ) ) {
			$out[] = array(
				'icon' => 'inbox',
				'label' => __( 'New enquiry', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-enquiries&new=1' ),
			);
			$out[] = array(
				'icon' => 'calendar',
				'label' => __( 'Schedule a visit', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-visits&new=1' ),
			);
		}
		if ( current_user_can( 'estat_manage_team' ) ) {
			$out[] = array(
				'icon' => 'users',
				'label' => __( 'Add a team member', 'estat-os' ),
				'url'   => admin_url( 'admin.php?page=estat-team&new=1' ),
			);
		}
		return $out;
	}

	/** Everything the command palette can jump to. */
	public static function palette(): array {
		$out = array();
		foreach ( self::modules() as $slug => $m ) {
			if ( ! current_user_can( $m['cap'] ) ) {
				continue;
			}
			$out[] = array(
				'icon'  => $m['icon'],
				'label' => $m['title'],
				'group' => $m['group'],
				'url'   => admin_url( 'admin.php?page=' . $slug ),
			);
		}
		return $out;
	}

	/** Status words and their colours, for the shared JavaScript. */
	public static function status_tones(): array {
		$families = array(
			'publication'  => Status::labels( Status::PUBLICATION ),
			'availability' => Status::labels( Status::AVAILABILITY ),
			'verification' => Status::labels( Status::VERIFICATION ),
			'construction' => Status::labels( Status::CONSTRUCTION ),
			'lead'         => Status::labels( Status::LEAD ),
			'visit'        => Status::labels( Status::VISIT ),
			'request'      => Status::labels( Status::REQUEST ),
		);
		$tones = array();
		foreach ( $families as $family => $labels ) {
			foreach ( array_keys( $labels ) as $value ) {
				$tones[ $family . '.' . $value ] = Status::tone( $family, $value );
			}
		}
		return $tones;
	}
}
