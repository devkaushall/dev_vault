<?php
/**
 * Frontend CSS control.
 *
 * The office asked for one thing: the website's styling should be theirs to
 * change, without having to know which of five stylesheets does what.
 *
 * This class is the whole answer, and it is deliberately small:
 *
 *   1. It stops loading a stylesheet on pages that have nothing of ours on
 *      them. The design tokens were being sent to every page on the site, from
 *      the home page to a page that never mentions a property.
 *
 *   2. It lets the office take the website's two stylesheets out of the queue
 *      and put their own in their place, from Settings -> Website CSS. The
 *      files stay on disk; turning the switch back puts them straight back.
 *
 *   3. It prints whatever CSS the office wrote, last, after every theme and
 *      page-builder stylesheet on the page — so their rules win without needing
 *      !important or a fight with the theme.
 *
 * It never touches the office screens or the phone app. Those load their own
 * stylesheets on their own pages and this class has no hooks that reach them.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class CssControl {

	/**
	 * The stylesheet handles that draw the public website.
	 *
	 * Kept in one place because three different methods need to agree about
	 * them: the isolator, the dependency keeper and the report.
	 */
	public const PUBLIC_HANDLES = array( 'estat-public', 'estat-forms', 'estat-share' );

	/**
	 * Stylesheets that cannot do their job without tokens.css.
	 *
	 * While any of these is on the page the tokens must stay, or every colour
	 * on a property card would fall back to the browser's defaults.
	 */
	public const TOKEN_DEPENDENTS = array( 'estat-public', 'estat-forms', 'estat-share' );

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		/*
		 * Priority 99: after every component has asked for its stylesheet
		 * (they all enqueue on 10), and after Elementor has built its own
		 * list, but before WordPress prints anything at 100.
		 */
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'isolate' ), 99 );

		/*
		 * The office's own CSS. Printed at the very end of the head so it
		 * comes after the theme, Elementor, the kit and the page CSS.
		 */
		add_action( 'wp_head', array( __CLASS__, 'print_custom_css' ), 999 );

		/*
		 * The share stylesheet is a dependency of nothing and a dependency on
		 * tokens. Stopping it on pages without a property keeps both of them
		 * off that page — which is the whole point of this file.
		 */
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'gate_tokens' ), 100 );
	}

	/**
	 * Which stylesheet setup is the office using?
	 *
	 * 'plugin' — the plugin's own stylesheets draw the website (default).
	 * 'custom' — the office's own CSS draws the website.
	 *
	 * @return string
	 */
	public static function mode(): string {
		$mode = (string) Settings::get( 'frontend_css_mode', 'plugin' );
		return in_array( $mode, array( 'plugin', 'custom' ), true ) ? $mode : 'plugin';
	}

	/**
	 * Does this page need the design tokens?
	 *
	 * A page needs them if anything of ours is going to be drawn on it. The
	 * two cheap, honest tests are: is one of our records being shown, and does
	 * the post or an Elementor template mention one of our widgets.
	 *
	 * Where the answer is not certain the tokens are kept. A missing colour is
	 * worse than an unnecessary stylesheet.
	 *
	 * @return bool
	 */
	public static function page_needs_tokens(): bool {
		if ( is_admin() ) {
			return true;
		}

		// Our own record pages and archives.
		if ( is_singular( array( 'estat_listing', 'estat_project', 'estat_agent' ) )
			|| is_post_type_archive( array( 'estat_listing', 'estat_project', 'estat_agent' ) )
			|| is_tax( array( 'estat_locality', 'estat_amenity', 'estat_feature' ) ) ) {
			return true;
		}

		// A form anywhere on the page.
		if ( 'custom' !== self::mode() && self::page_mentions_shortcode( 'estat_form' ) ) {
			return true;
		}

		// A shortcode of ours in the content.
		foreach ( self::shortcodes() as $tag ) {
			if ( self::page_mentions_shortcode( $tag ) ) {
				return true;
			}
		}

		// An Elementor page that carries one of our widgets.
		if ( self::elementor_uses_widget() ) {
			return true;
		}

		return (bool) apply_filters( 'estat_page_needs_tokens', false );
	}

	/**
	 * The shortcode tags the plugin registers.
	 *
	 * @return string[]
	 */
	private static function shortcodes(): array {
		return array(
			'estat_properties', 'estat_property', 'estat_projects', 'estat_project',
			'estat_agents', 'estat_search', 'estat_form', 'estat_enquiry',
			'estat_gallery', 'estat_emi', 'estat_compare', 'estat_favorites',
			'estat_localities', 'estat_help',
		);
	}

	/**
	 * Does the current page's content contain a shortcode?
	 *
	 * @param string $tag Shortcode tag.
	 * @return bool
	 */
	private static function page_mentions_shortcode( string $tag ): bool {
		$post = get_post();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		if ( has_shortcode( (string) $post->post_content, $tag ) ) {
			return true;
		}
		// Elementor keeps its content in its own meta, not in post_content.
		$elementor = (string) get_post_meta( $post->ID, '_elementor_data', true );
		return '' !== $elementor && false !== strpos( $elementor, 'estat_' . $tag );
	}

	/**
	 * Is an Elementor template on this page built with one of our widgets?
	 *
	 * @return bool
	 */
	private static function elementor_uses_widget(): bool {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return false;
		}
		$post_id = (int) get_queried_object_id();
		if ( $post_id <= 0 ) {
			return false;
		}
		$data = (string) get_post_meta( $post_id, '_elementor_data', true );
		return '' !== $data && false !== strpos( $data, 'estat_' );
	}

	/**
	 * Keep the tokens off pages that do not use them, and keep the website's
	 * stylesheets in the head where they belong.
	 *
	 * @return void
	 */
	public static function gate_tokens(): void {
		if ( is_admin() || ! wp_style_is( 'estat-tokens', 'enqueued' ) ) {
			return;
		}

		/*
		 * Something on the page depends on the tokens — leave them alone.
		 * WordPress prints a dependency whether or not it is still queued, so
		 * removing them here while a dependent is queued would achieve
		 * nothing except a confusing audit trail.
		 */
		foreach ( self::TOKEN_DEPENDENTS as $handle ) {
			if ( wp_style_is( $handle, 'enqueued' ) ) {
				return;
			}
		}

		if ( self::page_needs_tokens() ) {
			return;
		}

		wp_dequeue_style( 'estat-tokens' );
	}

	/**
	 * Apply the office's choice: our stylesheets, or theirs.
	 *
	 * In 'custom' mode every website stylesheet of ours leaves the queue. The
	 * files stay on disk and the setting is one click away from putting them
	 * straight back.
	 *
	 * In 'plugin' mode there is one thing left to fix: a stylesheet asked for
	 * during the page render is printed in the footer, which is why property
	 * cards used to appear unstyled for a moment and then jump. When the page
	 * is known to use our components, the stylesheet is asked for here — before
	 * anything is printed — so it arrives in the head with the rest.
	 *
	 * @return void
	 */
	public static function isolate(): void {
		if ( 'custom' === self::mode() ) {
			foreach ( self::PUBLIC_HANDLES as $handle ) {
				wp_dequeue_style( $handle );
			}
			return;
		}

		if ( self::page_renders_components() && wp_style_is( 'estat-public', 'registered' ) ) {
			wp_enqueue_style( 'estat-public' );
		}
	}

	/**
	 * Will this page draw one of our components?
	 *
	 * Same question as page_needs_tokens(), asked without the form special
	 * case: a page can show a card without showing a form.
	 *
	 * @return bool
	 */
	public static function page_renders_components(): bool {
		if ( is_singular( array( 'estat_listing', 'estat_project', 'estat_agent' ) )
			|| is_post_type_archive( array( 'estat_listing', 'estat_project', 'estat_agent' ) )
			|| is_tax( array( 'estat_locality', 'estat_amenity', 'estat_feature' ) ) ) {
			return true;
		}
		foreach ( self::shortcodes() as $tag ) {
			if ( self::page_mentions_shortcode( $tag ) ) {
				return true;
			}
		}
		return self::elementor_uses_widget();
	}

	/**
	 * Print the office's own CSS, last.
	 *
	 * The text is stored by the Settings screen, which sanitizes it on the way
	 * in. It is CSS: it is printed as written, because escaping it would turn
	 * every quote in it into an entity and the stylesheet would stop working.
	 * Only a style-closing sequence is removed, which is the one thing that
	 * could step outside the <style> element.
	 *
	 * @return void
	 */
	public static function print_custom_css(): void {
		$css = (string) Settings::get( 'custom_css', '' );
		$css = trim( $css );
		if ( '' === $css ) {
			return;
		}
		/*
		 * A stylesheet cannot contain its own closing tag, and it has no use
		 * for a script or a PHP tag either. Removed here as well as on the way
		 * into the settings, because this is the line that actually prints:
		 * whatever path the text arrived by, it cannot leave the <style>.
		 */
		$css = str_ireplace( array( '</style', '<script', '<\?php' ), '', $css );
		echo "<style id=\"estat-custom-css\">\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * What this class did on the last page load — used by the Settings screen
	 * so the office can see the effect of its own switch.
	 *
	 * @return array<string,mixed>
	 */
	public static function report(): array {
		return array(
			'mode'    => self::mode(),
			'tokens'  => wp_style_is( 'estat-tokens', 'enqueued' ) || wp_style_is( 'estat-tokens', 'done' ),
			'public'  => wp_style_is( 'estat-public', 'enqueued' ) || wp_style_is( 'estat-public', 'done' ),
			'share'   => wp_style_is( 'estat-share', 'enqueued' ) || wp_style_is( 'estat-share', 'done' ),
			'custom'  => '' !== trim( (string) Settings::get( 'custom_css', '' ) ),
			'needs'   => self::page_needs_tokens(),
		);
	}
}
