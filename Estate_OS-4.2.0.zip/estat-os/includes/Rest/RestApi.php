<?php
/**
 * REST API: namespace estat/v1.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Rest;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Forms\Submissions;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Search\Query;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;
use EstatOS\Support\Comparison;
use EstatOS\Support\Format;
use EstatOS\Support\Sanitize;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * Public routes expose only marketing information and are rate limited.
 * Everything about people or office operations requires a capability.
 */
final class RestApi {

	/**
	 * API namespace. Public contract.
	 */
	public const NS = 'estat/v1';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register all routes.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		// 3.0.7 health check for acceptance
		register_rest_route(
			self::NS,
			'/health',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => function() { return new \WP_REST_Response( array( 'ok' => true, 'version' => ESTAT_VERSION ), 200 ); },
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/properties',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_properties' ),
				'permission_callback' => '__return_true',
				'args'                => self::search_args(),
			)
		);

		register_rest_route(
			self::NS,
			'/properties/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_property' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array( 'required' => true, 'validate_callback' => array( __CLASS__, 'is_id' ), 'sanitize_callback' => 'absint' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/projects/(?P<id>\d+)/stats',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_project_stats' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array( 'required' => true, 'validate_callback' => array( __CLASS__, 'is_id' ), 'sanitize_callback' => 'absint' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/agents',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_agents' ),
				'permission_callback' => '__return_true',
			)
		);

		// A landing spot for form plugins that can only POST somewhere —
		// Elementor Pro's "Webhook" action being the common one. It is public
		// on purpose (the sender has no login) and protected the same way the
		// public form endpoint is: a shared secret, spam checks and dedupe.
		/*
		 * The visitor's shortlist, sent to the office.
		 *
		 * A visitor who has put three homes together is the warmest enquiry
		 * the website produces, and until now that work vanished when they
		 * closed the tab. This turns it into an ordinary enquiry — the same
		 * Leads::create() the forms use, so it appears in the office list
		 * and is chased like any other — and hands back the WhatsApp link
		 * carrying the same three homes.
		 */
		register_rest_route(
			self::NS,
			'/shortlist',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'send_shortlist' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/enquiries',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_enquiry' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/forms/(?P<id>\d+)/submit',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'submit_form' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array( 'required' => true, 'validate_callback' => array( __CLASS__, 'is_id' ), 'sanitize_callback' => 'absint' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/leads',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_leads' ),
					'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_lead' ),
					'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/leads/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'update_lead' ),
				'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
			)
		);

		register_rest_route(
			self::NS,
			'/visits',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_visits' ),
					'permission_callback' => static fn() => current_user_can( 'estat_manage_visits' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_visit' ),
					'permission_callback' => static fn() => current_user_can( 'estat_manage_visits' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/visits/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'update_visit' ),
				'permission_callback' => static fn() => current_user_can( 'estat_manage_visits' ),
			)
		);

		register_rest_route(
			self::NS,
			'/audit',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_audit' ),
				'permission_callback' => static fn() => current_user_can( 'estat_view_audit' ),
			)
		);

		register_rest_route(
			self::NS,
			'/maintenance/(?P<task>[a-z_\-]+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'run_maintenance' ),
				'permission_callback' => static fn() => current_user_can( 'estat_run_maintenance' ),
			)
		);

		// the office v3: search alerts.
		register_rest_route(
			self::NS,
			'/alerts',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_alerts' ),
					'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_alert' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			self::NS,
			'/share',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'log_share' ),
				'permission_callback' => '__return_true',
			)
		);

		// F11: v2 full API — versioned, documented.
		register_rest_route(
			'estat/v2',
			'/properties',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_properties_v2' ),
				'permission_callback' => '__return_true',
				'args'                => self::search_args(),
			)
		);
		register_rest_route(
			'estat/v2',
			'/properties/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_property_v2' ),
				'permission_callback' => '__return_true',
				'args'                => array( 'id' => array( 'required' => true, 'validate_callback' => array( __CLASS__, 'is_id' ), 'sanitize_callback' => 'absint' ) ),
			)
		);
		register_rest_route(
			'estat/v2',
			'/projects',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_projects_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/projects/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_project_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/projects/stages',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_project_stages_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/agents',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_agents_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/localities',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_localities_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/amenities',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_amenities_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/features',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_features_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/filters',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_filters_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/forms',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_forms_v2' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'estat/v2',
			'/alerts',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_alerts_v2' ),
				'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
			)
		);
		register_rest_route(
			'estat/v2',
			'/webhooks/log',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_webhook_log_v2' ),
				'permission_callback' => static fn() => current_user_can( 'estat_manage_settings' ),
			)
		);
		register_rest_route(
			'estat/v2',
			'/openapi',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_openapi_v2' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Search argument schema.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function search_args(): array {
		return array(
			'keyword'       => array( 'sanitize_callback' => 'sanitize_text_field' ),
			'offer'         => array( 'sanitize_callback' => 'sanitize_text_field' ),
			'property_type' => array(),
			'locality'      => array(),
			'bedrooms_min'  => array( 'sanitize_callback' => 'absint' ),
			'price_min'     => array(),
			'price_max'     => array(),
			'area_min'      => array(),
			'area_max'      => array(),
			'orderby'       => array( 'sanitize_callback' => 'sanitize_text_field' ),
			'page'          => array( 'sanitize_callback' => 'absint', 'default' => 1 ),
			'per_page'      => array( 'sanitize_callback' => 'absint', 'default' => 12 ),
		);
	}

	/**
	 * Public property search.
	 * B9 fix: returns all published listings with pagination per_page ≤50.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_properties( WP_REST_Request $request ) {
		$limited = self::rate_limit( 'search', 60 );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$params = (array) $request->get_params();
		// Ensure per_page capped at 50 as per B9, not 60.
		if ( isset( $params['per_page'] ) ) {
			$params['per_page'] = min( 50, max( 1, (int) $params['per_page'] ) );
		} else {
			$params['per_page'] = 12;
		}
		if ( isset( $params['page'] ) ) {
			$params['page'] = max( 1, (int) $params['page'] );
		}

		$results = Query::search( $params );
		$items   = array();
		foreach ( $results['ids'] as $id ) {
			$items[] = Listings::to_array( (int) $id, false );
		}

		// Fallback if index empty but posts exist (migration case).
		if ( 0 === $results['total'] ) {
			$q = new \WP_Query(
				array(
					'post_type'      => PostTypes::LISTING,
					'post_status'    => 'publish',
					'posts_per_page' => $params['per_page'],
					'paged'          => $params['page'],
					'no_found_rows'  => false,
					'fields'         => 'ids',
				)
			);
			if ( $q->have_posts() ) {
				$items = array();
				foreach ( $q->posts as $pid ) {
					$items[] = Listings::to_array( (int) $pid, false );
				}
				$results['total'] = (int) $q->found_posts;
				$results['pages'] = (int) $q->max_num_pages;
			}
		}

		$response = new WP_REST_Response(
			array(
				'items' => $items,
				'total' => $results['total'],
				'page'  => $results['page'],
				'pages' => $results['pages'],
				'per_page' => $params['per_page'],
			),
			200
		);
		// Rule 7: Cache-Control max-age=60 on listing queries.
		$response->header( 'Cache-Control', 'public, max-age=60' );
		return $response;
	}

	/**
	 * Public property detail.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_property( WP_REST_Request $request ) {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) || 'publish' !== $post->post_status ) {
			return new WP_Error( 'estat_not_found', __( 'That property could not be found.', 'estat-os' ), array( 'status' => 404 ) );
		}

		/*
		 * A visitor's shortlist may hold a single home or a whole society,
		 * and the same screen draws both. Answering only for single homes
		 * meant a heart on a project card came back as "not found" and
		 * dropped quietly out of the list the visitor had built.
		 */
		if ( PostTypes::PROJECT === $post->post_type ) {
			$data = Projects::to_array( $id );
		} else {
			$data            = Listings::to_array( $id, false );
			$data['agent']   = (int) $data['agent_id'] > 0 ? Agents::to_array( (int) $data['agent_id'] ) : null;
			$data['project'] = (int) $data['project_id'] > 0 ? array( 'id' => (int) $data['project_id'], 'name' => get_the_title( (int) $data['project_id'] ) ) : null;
		}

		/*
		 * The side-by-side table is drawn in the visitor's browser, so the
		 * questions and the answers have to travel in this reply. They come
		 * from the one list the office and the agent's phone already use,
		 * blanks included — a question left out reads as a fact that does
		 * not exist, while "not said" reads as the truth.
		 */
		$data['questions'] = Comparison::questions();
		$data['facts']     = Comparison::facts( $id );

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * Project statistics.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_project_stats( WP_REST_Request $request ) {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		// A draft or trashed project must look exactly like one that never
		// existed, otherwise the reply confirms it is there.
		if ( ! $post || PostTypes::PROJECT !== $post->post_type || 'publish' !== $post->post_status ) {
			return new WP_Error( 'estat_not_found', __( 'That society or project could not be found.', 'estat-os' ), array( 'status' => 404 ) );
		}
		return new WP_REST_Response( Projects::stats( $id ), 200 );
	}

	/**
	 * Public team directory (business contact details only).
	 *
	 * @return WP_REST_Response
	 */
	public static function get_agents(): WP_REST_Response {
		$ids   = get_posts(
			array(
				'post_type'      => PostTypes::AGENT,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$items = array();
		foreach ( $ids as $id ) {
			$items[] = Agents::to_array( (int) $id );
		}
		return new WP_REST_Response( array( 'items' => $items, 'total' => count( $items ) ), 200 );
	}

	/**
	 * Is this a number? Used to check an id arriving in a URL.
	 *
	 * This exists because the obvious spelling — `'validate_callback' =>
	 * 'is_numeric'` — is a fatal error, not a validation. WordPress calls a
	 * validation callback with three arguments ( the value, the request, the
	 * parameter name ), and PHP's own `is_numeric()` accepts exactly one: PHP
	 * 8 answers with ArgumentCountError, WordPress turns that into its
	 * "critical error" page, and every request to the route returns HTTP 500.
	 *
	 * That is what broke `/estat/v1/properties/{id}` and
	 * `/estat/v2/properties/{id}` for every property, and with them the
	 * website's Compare, Favorites and Saved pages, which fetch a property to
	 * draw it. The list endpoints were never affected because their arguments
	 * carry no validation callback.
	 *
	 * A method of this class is a plain function to PHP, and PHP ignores
	 * arguments a plain function does not declare — so declaring one here
	 * makes the three-argument call harmless.
	 *
	 * @param mixed $value Value from the URL.
	 * @return bool
	 */
	public static function is_id( $value ): bool {
		return is_numeric( $value );
	}

	/**
	 * Public form submission.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function submit_form( WP_REST_Request $request ) {
		$form_id = (int) $request['id'];
		$params  = (array) $request->get_params();

		$nonce = Sanitize::text( $params['estat_nonce'] ?? '' );
		if ( ! wp_verify_nonce( $nonce, 'estat_form_submit_' . $form_id ) ) {
			return new WP_Error( 'estat_bad_nonce', __( 'This page has been open for a while. Please refresh and send the form again.', 'estat-os' ), array( 'status' => 403 ) );
		}

		$result = Submissions::handle( $form_id, $params );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Send the visitor's shortlist to the office, and hand back WhatsApp.
	 *
	 * Three guards, the same shape the public forms use: a nonce so the
	 * request comes from a page we drew, a honeypot field so a bot filling
	 * in every input is caught, and a per-address rate limit so one visitor
	 * cannot post the same list forty times.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function send_shortlist( WP_REST_Request $request ) {
		$params = (array) $request->get_params();

		$nonce = Sanitize::text( $params['estat_nonce'] ?? '' );
		if ( ! wp_verify_nonce( $nonce, 'estat_shortlist' ) ) {
			return new WP_Error( 'estat_bad_nonce', __( 'This page has been open a while. Please refresh and try again.', 'estat-os' ), array( 'status' => 403 ) );
		}

		// Honeypot: a field no person can see is always empty for a person.
		if ( '' !== Sanitize::text( $params['estat_website'] ?? '' ) ) {
			return new WP_Error( 'estat_spam', __( 'That could not be sent.', 'estat-os' ), array( 'status' => 422 ) );
		}

		$name  = Sanitize::text( $params['name'] ?? '' );
		$phone = Sanitize::phone( (string) ( $params['phone'] ?? '' ) );
		$email = Sanitize::email( (string) ( $params['email'] ?? '' ) );

		if ( '' === $name || ( '' === $phone && '' === $email ) ) {
			return new WP_Error(
				'estat_need_contact',
				__( 'Please leave a name and a phone number so the office can call you back.', 'estat-os' ),
				array( 'status' => 422 )
			);
		}

		$ids = array_values( array_filter( array_map( 'absint', explode( ',', (string) ( $params['ids'] ?? '' ) ) ) ) );
		$ids = array_slice( array_unique( $ids ), 0, 4 );
		if ( ! $ids ) {
			return new WP_Error( 'estat_nothing_picked', __( 'Put at least one property in the shortlist first.', 'estat-os' ), array( 'status' => 422 ) );
		}

		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$key = 'estat_sl_' . substr( hash( 'sha256', $ip . '|' . wp_salt( 'auth' ) ), 0, 32 );
		$has = (int) get_transient( $key );
		if ( $has >= 5 ) {
			return new WP_Error( 'estat_slow_down', __( 'That is a few times already. Please call the office instead.', 'estat-os' ), array( 'status' => 429 ) );
		}
		set_transient( $key, $has + 1, 10 * MINUTE_IN_SECONDS );

		$lines = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			if ( ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) {
				continue;
			}
			$line = '• ' . get_the_title( $id );
			$want = Comparison::facts( $id );
			if ( '' !== trim( (string) ( $want['price'] ?? '' ) ) ) {
				$line .= ' — ' . (string) $want['price'];
			}
			$line .= ' — ' . (string) get_permalink( $id );
			$lines[] = $line;
		}

		if ( ! $lines ) {
			return new WP_Error( 'estat_nothing_picked', __( 'Those properties are no longer on the website.', 'estat-os' ), array( 'status' => 422 ) );
		}

		$message = sprintf(
			/* translators: %d: how many properties. */
			_n( 'Shortlist from the website — %d property:', 'Shortlist from the website — %d properties:', count( $lines ), 'estat-os' ),
			count( $lines )
		) . "\n" . implode( "\n", $lines );

		$lead = Leads::create(
			array(
				'name'            => $name,
				'phone'           => $phone,
				'email'           => $email,
				'message'         => $message,
				'source'          => 'comparison',
				'source_url'      => Sanitize::url( (string) ( $params['page_url'] ?? '' ) ),
				'consent'         => true,
				'idempotency_key' => Sanitize::text( (string) ( $params['idempotency_key'] ?? '' ) ),
			)
		);

		if ( is_wp_error( $lead ) ) {
			$lead->add_data( array( 'status' => 422 ) );
			return $lead;
		}

		$digits = \EstatOS\Frontend\WhatsApp::number();

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'lead_id'  => (int) $lead,
				'whatsapp' => '' !== $digits ? 'https://wa.me/' . $digits . '?text=' . rawurlencode( $message ) : '',
				'message'  => __( 'Sent to the office. Continue to send the same list on WhatsApp.', 'estat-os' ),
			),
			200
		);
	}

	/**
	 * Office enquiry list.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function get_leads( WP_REST_Request $request ): WP_REST_Response {
		return new WP_REST_Response( Leads::query( (array) $request->get_params() ), 200 );
	}

	/**
	 * Create an enquiry from an authorised client.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_lead( WP_REST_Request $request ) {
		$result = Leads::create( (array) $request->get_params() );
		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 422 ) );
			return $result;
		}
		return new WP_REST_Response( array( 'lead_id' => (int) $result ), 201 );
	}

	/**
	 * Update an enquiry.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function update_lead( WP_REST_Request $request ) {
		$id     = (int) $request['id'];
		$params = (array) $request->get_params();
		if ( isset( $params['agent_id'] ) && ! current_user_can( 'estat_assign_leads' ) ) {
			return new WP_Error( 'estat_forbidden', __( 'You are not allowed to assign enquiries.', 'estat-os' ), array( 'status' => 403 ) );
		}
		$result = Leads::update( $id, $params );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( Leads::get( $id ), 200 );
	}

	/**
	 * Visit list.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function get_visits( WP_REST_Request $request ): WP_REST_Response {
		return new WP_REST_Response( Visits::query( (array) $request->get_params() ), 200 );
	}

	/**
	 * Schedule a visit.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_visit( WP_REST_Request $request ) {
		$result = Visits::schedule( (array) $request->get_params() );
		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 422 ) );
			return $result;
		}
		return new WP_REST_Response( array( 'visit_id' => (int) $result ), 201 );
	}

	/**
	 * Update a visit.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function update_visit( WP_REST_Request $request ) {
		$id     = (int) $request['id'];
		$result = Visits::update( $id, (array) $request->get_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( Visits::get( $id ), 200 );
	}

	/**
	 * Activity history.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function get_audit( WP_REST_Request $request ): WP_REST_Response {
		return new WP_REST_Response( AuditLog::query( (array) $request->get_params() ), 200 );
	}

	/**
	 * Run an allow-listed maintenance task.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function run_maintenance( WP_REST_Request $request ) {
		$task = sanitize_key( (string) $request['task'] );
		switch ( $task ) {
			case 'rebuild_index':
				$offset = (int) $request->get_param( 'offset' );
				$done   = SearchIndex::rebuild_batch( 200, $offset );
				AuditLog::record( 'maintenance.run', 'maintenance', 0, array( 'task' => $task, 'rows' => $done ) );
				return new WP_REST_Response( array( 'processed' => $done, 'next_offset' => $offset + $done, 'complete' => $done < 200 ), 200 );

			case 'expire_listings':
				$count = \EstatOS\Cron\Scheduler::expire_listings();
				return new WP_REST_Response( array( 'expired' => $count ), 200 );

			case 'index_status':
				return new WP_REST_Response( SearchIndex::status(), 200 );

			default:
				return new WP_Error( 'estat_unknown_task', __( 'That maintenance task does not exist.', 'estat-os' ), array( 'status' => 404 ) );
		}
	}

	/**
	 * Rate limit anonymous public calls.
	 *
	 * @param string $bucket Bucket name.
	 * @param int    $limit  Calls allowed per minute.
	 * @return true|WP_Error
	 */
	private static function rate_limit( string $bucket, int $limit ) {
		if ( is_user_logged_in() ) {
			return true;
		}
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : ''; // phpcs:ignore
		$key = 'estat_api_' . $bucket . '_' . substr( hash( 'sha256', $ip . wp_salt( 'auth' ) ), 0, 24 );
		$hits = (int) get_transient( $key );
		if ( $hits >= $limit ) {
			return new WP_Error( 'estat_rate_limited', __( 'Too many requests. Please slow down and try again in a minute.', 'estat-os' ), array( 'status' => 429 ) );
		}
		set_transient( $key, $hits + 1, MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Accept an enquiry posted by another form tool.
	 *
	 * Elementor Pro (and most form plugins) can POST the submitted fields to a
	 * URL. This turns that POST into a proper enquiry, going through exactly
	 * the same checks as our own forms — nothing gets a shortcut into the
	 * database just because it arrived from somewhere else.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_enquiry( WP_REST_Request $request ) {
		$settings = Settings::all();
		$secret   = (string) ( $settings['inbound_secret'] ?? '' );

		// Without a secret configured the door stays shut, rather than
		// silently accepting anything the whole internet sends.
		if ( '' === $secret ) {
			return new WP_Error(
				'estat_inbound_disabled',
				__( 'Incoming enquiries are turned off. Set a secret key in Office Settings first.', 'estat-os' ),
				array( 'status' => 403 )
			);
		}

		$given = (string) $request->get_param( 'secret' );

		if ( '' === $given ) {
			$given = (string) $request->get_header( 'x_estat_secret' );
		}

		// hash_equals keeps the comparison constant-time.
		if ( ! hash_equals( $secret, $given ) ) {
			return new WP_Error(
				'estat_inbound_forbidden',
				__( 'That secret key is not correct.', 'estat-os' ),
				array( 'status' => 403 )
			);
		}

		$fields = $request->get_param( 'fields' );

		// Elementor posts the boxes at the top level rather than under
		// "fields", so accept both shapes.
		if ( ! is_array( $fields ) ) {
			$fields = (array) $request->get_params();
			unset( $fields['secret'], $fields['form_id'], $fields['page_url'], $fields['idempotency_key'] );
		}

		$name = Sanitize::text( $fields['name'] ?? '' );

		$phone = Sanitize::text( $fields['phone'] ?? '' );
		$email = Sanitize::email( $fields['email'] ?? '' );

		if ( '' === $phone && '' === $email ) {
			return new WP_Error(
				'estat_inbound_incomplete',
				__( 'An enquiry needs at least a phone number or an email address.', 'estat-os' ),
				array( 'status' => 422 )
			);
		}

		$lead = Leads::create(
			array(
				'name'              => $name,
				'phone'             => $phone,
				'email'             => $email,
				'message'           => Sanitize::textarea( $fields['message'] ?? '' ),
				'listing_id'        => Sanitize::int( $fields['property_id'] ?? 0 ),
				'source'            => Sanitize::text( $fields['source'] ?? 'website' ),
				'submission_source' => Sanitize::url( $request->get_param( 'page_url' ) ?? '' ),
				'idempotency_key'   => Sanitize::text( $request->get_param( 'idempotency_key' ) ?? '' ),
			)
		);

		if ( is_wp_error( $lead ) ) {
			return $lead;
		}

		AuditLog::record( 'lead.inbound', 'lead', (int) $lead, array( 'via' => 'rest' ) );

		return new WP_REST_Response(
			array(
				'ok'      => true,
				'lead_id' => (int) $lead,
			),
			201
		);
	}

	/**
	 * the office v3: get search alerts (office only).
	 *
	 * @return WP_REST_Response
	 */
	public static function get_alerts(): WP_REST_Response {
		return new WP_REST_Response( \EstatOS\Search\Alerts::query(), 200 );
	}

	/**
	 * the office v3: create search alert (public).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_alert( WP_REST_Request $request ) {
		$limited = self::rate_limit( 'alerts', 20 );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$params = $request->get_json_params();
		if ( ! $params ) {
			$params = $request->get_params();
		}

		// Filters may be JSON string from shortcode.
		if ( isset( $params['filters'] ) && is_string( $params['filters'] ) ) {
			$decoded = json_decode( $params['filters'], true );
			if ( is_array( $decoded ) ) {
				$params['filters'] = $decoded;
			}
		}
		if ( isset( $params['query'] ) && is_string( $params['query'] ) ) {
			$decoded = json_decode( $params['query'], true );
			if ( is_array( $decoded ) ) {
				$params['query'] = $decoded;
			}
		}

		$result = \EstatOS\Search\Alerts::create(
			array(
				'name'       => $params['name'] ?? '',
				'email'      => $params['email'] ?? '',
				'filters'    => $params['filters'] ?? $params['query'] ?? array(),
				'query'      => $params['query'] ?? $params['filters'] ?? array(),
				'phone'      => $params['phone'] ?? '',
				'frequency'  => $params['frequency'] ?? 'instant',
				'source_url' => $params['source_url'] ?? '',
			)
		);

		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 422 ) );
			return $result;
		}

		return new WP_REST_Response( array( 'id' => (int) $result, 'success' => true ), 201 );
	}

	/**
	 * the office v3: log share event.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function log_share( WP_REST_Request $request ): WP_REST_Response {
		return \EstatOS\Frontend\Share::rest_share( $request );
	}

	/**
	 * the office v3: versioned v2 properties with more fields.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_properties_v2( WP_REST_Request $request ) {
		$limited = self::rate_limit( 'search_v2', 60 );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$results = Query::search( (array) $request->get_params() );
		$items   = array();
		foreach ( $results['ids'] as $id ) {
			$arr = Listings::to_array( (int) $id, false );
			// v2 adds extra fields — F11.
			$arr['share_url'] = get_permalink( $id );
			$arr['print_url'] = add_query_arg( 'print', '1', get_permalink( $id ) );
			$arr['verified']  = 'office_verified' === (string) $arr['verification'];
			$arr['is_new']    = (int) ( $arr['days_listed'] ?? 0 ) < (int) Settings::get( 'just_listed_days', 7 );
			// EMI estimate: 80% loan, 8.5% annual, 20y
			$rate = 8.5 / 12 / 100;
			$n = 20 * 12;
			$arr['emi_estimate'] = $arr['price_min'] > 0 ? (int) round( $arr['price_min'] * 0.8 * $rate * pow(1+$rate,$n) / (pow(1+$rate,$n)-1) ) : 0;
			$items[] = $arr;
		}

		return new WP_REST_Response(
			array(
				'version' => '2.0',
				'items'   => $items,
				'total'   => $results['total'],
				'page'    => $results['page'],
				'pages'   => $results['pages'],
				'per_page'=> $results['per_page'],
			),
			200
		);
	}

	public static function get_property_v2( WP_REST_Request $request ) {
		$id = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || \EstatOS\Data\PostTypes::LISTING !== $post->post_type || 'publish' !== $post->post_status ) {
			return new WP_Error( 'estat_not_found', __( 'That property could not be found.', 'estat-os' ), array( 'status' => 404 ) );
		}
		$data = Listings::to_array( $id, false );
		$data['share_url'] = get_permalink( $id );
		$data['print_url'] = add_query_arg( 'print', '1', get_permalink( $id ) );
		$data['verified'] = 'office_verified' === (string) $data['verification'];
		$data['is_new'] = (int) ( $data['days_listed'] ?? 0 ) < (int) Settings::get( 'just_listed_days', 7 );
		$data['agent'] = (int) $data['agent_id'] > 0 ? Agents::to_array( (int) $data['agent_id'] ) : null;
		$data['project'] = (int) $data['project_id'] > 0 ? Projects::to_array( (int) $data['project_id'] ) : null;
		$data['localities'] = wp_get_object_terms( $id, \EstatOS\Data\Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); if (is_wp_error($data['localities'])) $data['localities'] = array();
		$data['amenities'] = wp_get_object_terms( $id, \EstatOS\Data\Taxonomies::AMENITY, array( 'fields' => 'names' ) ); if (is_wp_error($data['amenities'])) $data['amenities'] = array();
		$data['features'] = wp_get_object_terms( $id, \EstatOS\Data\Taxonomies::FEATURE, array( 'fields' => 'names' ) ); if (is_wp_error($data['features'])) $data['features'] = array();
		// The same ten questions as the office, so any screen that asks for
		// version 2 gets the side-by-side answers without a second call.
		$data['questions'] = Comparison::questions();
		$data['facts'] = Comparison::facts( $id );
		return new WP_REST_Response( array( 'version' => '2.0', 'item' => $data ), 200 );
	}

	public static function get_projects_v2( WP_REST_Request $request ) {
		$params   = (array) $request->get_params();
		$page     = max( 1, (int) ( $params['page'] ?? 1 ) );
		$per_page = min( 50, max( 1, (int) ( $params['per_page'] ?? 12 ) ) );
		$stage    = isset( $params['stage'] ) ? sanitize_key( (string) $params['stage'] ) : '';
		$search   = isset( $params['search'] ) ? Sanitize::text( (string) $params['search'] ) : '';

		/*
		 * This endpoint used to answer with the same fifty projects whatever
		 * was asked of it: `page`, `per_page` and every filter in the URL were
		 * read by nobody. Anything built on it — an app, a widget, another
		 * site — could only ever see the first page.
		 */
		$args = array(
			'post_type'      => PostTypes::PROJECT,
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'fields'         => 'ids',
			'no_found_rows'  => false,
		);
		if ( '' !== $stage ) {
			$args['meta_key']   = '_estat_project_status';
			$args['meta_value'] = $stage;
		}
		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		$query = new \WP_Query( $args );
		$items = array();
		foreach ( (array) $query->posts as $pid ) {
			$proj = Projects::to_array( (int) $pid );
			$proj['stage_label'] = \EstatOS\Support\Vocabulary::project_stage_label( $proj['stage'] ?? '' );
			$proj['progress'] = \EstatOS\Support\Vocabulary::project_stage_progress()[ $proj['stage'] ?? '' ] ?? 0;
			$items[] = $proj;
		}

		return new WP_REST_Response(
			array(
				'version'  => '2.0',
				'items'    => $items,
				'total'    => (int) $query->found_posts,
				'page'     => $page,
				'pages'    => (int) $query->max_num_pages,
				'per_page' => $per_page,
			),
			200
		);
	}

	public static function get_project_v2( WP_REST_Request $request ) {
		$id = (int) $request['id'];
		$proj = Projects::to_array( $id );
		if ( ! $proj ) { return new WP_Error( 'estat_not_found', 'Project not found', array( 'status' => 404 ) ); }
		$proj['stage_label'] = \EstatOS\Support\Vocabulary::project_stage_label( $proj['stage'] ?? '' );
		$proj['progress'] = \EstatOS\Support\Vocabulary::project_stage_progress()[ $proj['stage'] ?? '' ] ?? 0;
		$proj['stats'] = Projects::stats( $id );
		return new WP_REST_Response( array( 'version' => '2.0', 'item' => $proj ), 200 );
	}

	public static function get_project_stages_v2(): WP_REST_Response {
		return new WP_REST_Response( array( 'version' => '2.0', 'stages' => \EstatOS\Support\Vocabulary::project_statuses(), 'order' => \EstatOS\Support\Vocabulary::project_stage_order(), 'progress' => \EstatOS\Support\Vocabulary::project_stage_progress() ), 200 );
	}

	public static function get_agents_v2(): WP_REST_Response {
		$ids = get_posts( array( 'post_type' => \EstatOS\Data\PostTypes::AGENT, 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids' ) );
		$items = array();
		foreach ( $ids as $id ) { $items[] = Agents::to_array( (int) $id ); }
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => $items ), 200 );
	}

	public static function get_localities_v2(): WP_REST_Response {
		$terms = get_terms( array( 'taxonomy' => \EstatOS\Data\Taxonomies::LOCALITY, 'hide_empty' => false, 'number' => 200 ) );
		$terms = is_wp_error( $terms ) ? array() : $terms;
		$out = array();
		foreach ( $terms as $t ) { $out[] = array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'count' => $t->count, 'url' => get_term_link( $t ) ); }
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => $out ), 200 );
	}

	public static function get_amenities_v2(): WP_REST_Response {
		$terms = get_terms( array( 'taxonomy' => \EstatOS\Data\Taxonomies::AMENITY, 'hide_empty' => false, 'number' => 200 ) );
		$terms = is_wp_error( $terms ) ? array() : $terms;
		$out = array();
		foreach ( $terms as $t ) { $out[] = array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'count' => $t->count, 'url' => get_term_link( $t ) ); }
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => $out ), 200 );
	}

	public static function get_features_v2(): WP_REST_Response {
		$terms = get_terms( array( 'taxonomy' => \EstatOS\Data\Taxonomies::FEATURE, 'hide_empty' => false, 'number' => 200 ) );
		$terms = is_wp_error( $terms ) ? array() : $terms;
		$out = array();
		foreach ( $terms as $t ) { $out[] = array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'count' => $t->count, 'url' => get_term_link( $t ) ); }
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => $out ), 200 );
	}

	public static function get_filters_v2(): WP_REST_Response {
		return new WP_REST_Response( array( 'version' => '2.0', 'enabled' => \EstatOS\Search\Query::enabled_filters(), 'ordered' => \EstatOS\Search\Query::ordered_filters(), 'all' => \EstatOS\Support\Vocabulary::all_filters() ), 200 );
	}

	public static function get_forms_v2(): WP_REST_Response {
		$forms = \EstatOS\Forms\Forms::all();
		$out = array();
		foreach ( $forms as $f ) { $out[] = array( 'id' => $f['id'], 'name' => $f['name'], 'status' => $f['status'], 'shortcode' => '[estat_form id="' . $f['id'] . '"]' ); }
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => $out ), 200 );
	}

	public static function get_alerts_v2(): WP_REST_Response {
		return new WP_REST_Response( array( 'version' => '2.0', 'data' => \EstatOS\Search\Alerts::query() ), 200 );
	}

	public static function get_webhook_log_v2(): WP_REST_Response {
		return new WP_REST_Response( array( 'version' => '2.0', 'items' => \EstatOS\Webhooks\Webhooks::recent( 50 ) ), 200 );
	}

	public static function get_openapi_v2(): WP_REST_Response {
		$spec = array(
			'openapi' => '3.0.0',
			'info' => array( 'title' => 'Estat.OS API', 'version' => '2.0', 'description' => 'Webhooks, versioned API and event emails' ),
			'servers' => array( array( 'url' => rest_url( 'estat/v2/' ) ) ),
			'paths' => array(
				'/properties' => array( 'get' => array( 'summary' => 'Search properties — 23 filters', 'parameters' => array( array( 'name' => 'keyword', 'in' => 'query' ), array( 'name' => 'locality', 'in' => 'query' ), array( 'name' => 'price_max', 'in' => 'query' ), array( 'name' => 'amenities', 'in' => 'query' ), array( 'name' => 'features', 'in' => 'query' ), array( 'name' => 'verified', 'in' => 'query' ) ) ) ),
				'/properties/{id}' => array( 'get' => array( 'summary' => 'Property detail with share_url, print_url, verified, is_new, localities, amenities, features' ) ),
				'/projects' => array( 'get' => array( 'summary' => 'List projects with stage_label & progress' ) ),
				'/projects/{id}' => array( 'get' => array( 'summary' => 'Project detail + stats' ) ),
				'/projects/stages' => array( 'get' => array( 'summary' => 'Project stages Planning/UC/Ready with order & progress' ) ),
				'/localities' => array( 'get' => array( 'summary' => 'Localities with counts' ) ),
				'/amenities' => array( 'get' => array( 'summary' => 'Amenities with counts' ) ),
				'/features' => array( 'get' => array( 'summary' => 'Features with counts' ) ),
				'/filters' => array( 'get' => array( 'summary' => '23 filters config — enabled, ordered, all' ) ),
				'/webhooks/log' => array( 'get' => array( 'summary' => 'Recent webhook deliveries (office only)' ) ),
				'/openapi' => array( 'get' => array( 'summary' => 'This OpenAPI spec' ) ),
			),
		);
		return new WP_REST_Response( $spec, 200 );
	}
}
