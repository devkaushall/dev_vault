<?php
/**
 * The office's own face.
 *
 * Every screen the plugin draws — the office dashboard, the agent's pocket,
 * the sign-in page — used to open with a coloured square and a letter. That
 * is a placeholder, and a placeholder on the first screen of the day reads as
 * "this is not finished". A property office is a business with a name and a
 * mark of its own; the app should carry it.
 *
 * Where the picture comes from, in order, and there is no fourth attempt
 * because a missing logo must never be a broken image:
 *
 *   1. `logo_id` in the plugin's own Settings — an office that uploaded its
 *      logo to the plugin.
 *   2. The logo WordPress itself is set to use (Site Identity / Site Icon).
 *      Most offices already set this once and never think about it again.
 *   3. The mark shipped inside the plugin, so the app is never faceless.
 *
 * A different office can point step 3 anywhere with the `estat_logo_url`
 * filter, and the shipped mark can be replaced the same way.
 *
 * Rules for this file:
 *
 * - `img()` is the only way to draw one, and it always returns an `<img>` with
 *   a real width, a real height and an alt that is empty unless somebody needs
 *   the name read out. An empty alt is deliberate: the name is written next to
 *   it in words, and a screen reader saying it twice is a stutter, not help.
 * - Nothing here writes to disk, calls the network or touches the theme. A
 *   logo that cannot be found is `logo_url()` returning an empty string, and
 *   the caller falls back to the drawn roof it used before.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Logo {

	/**
	 * The picture to show, or an empty string when there is none at all.
	 *
	 * Two shapes are asked for. A **mark** is the square slot — the top of a
	 * column, the corner of a bar — where only the device should show. A
	 * **lockup** is the whole thing, device and name together, for a screen
	 * with room to breathe, which means the sign-in page. An office's own
	 * uploaded logo is used as-is for both, because we cannot know which
	 * shape they drew.
	 *
	 * @param string $variant Either 'mark' or 'lockup'.
	 * @return string Absolute URL.
	 */
	public static function url( string $variant = 'mark' ): string {
		$id = (int) Settings::get( 'logo_id', 0 );
		if ( $id > 0 ) {
			$url = wp_get_attachment_image_url( $id, 'medium' );
			if ( is_string( $url ) && '' !== $url ) {
				return $url;
			}
		}

		$theme_id = (int) get_theme_mod( 'custom_logo', 0 );
		if ( $theme_id > 0 ) {
			$url = wp_get_attachment_image_url( $theme_id, 'medium' );
			if ( is_string( $url ) && '' !== $url ) {
				return $url;
			}
		}

		$icon = get_site_icon_url( 512 );
		if ( is_string( $icon ) && '' !== $icon ) {
			return $icon;
		}

		$shipped = 'lockup' === $variant
			? ESTAT_URL . 'assets/img/mayfair.png'
			: ESTAT_URL . 'assets/img/mayfair-mark.png';

		/**
		 * Filter the mark the app falls back to.
		 *
		 * @param string $shipped Absolute URL.
		 * @param string $variant Either 'mark' or 'lockup'.
		 */
		return (string) apply_filters( 'estat_logo_url', $shipped, $variant );
	}

	/**
	 * Draw the picture.
	 *
	 * @param string $class   Extra classes for the layout it sits in.
	 * @param string $label   Readable name for screen readers. Empty means the
	 *                        name is already written beside it in words.
	 * @param string $variant 'mark' for a square slot, 'lockup' for the whole
	 *                        logo on a screen with room for it.
	 * @return string
	 */
	public static function img( string $class = '', string $label = '', string $variant = 'mark' ): string {
		$url = self::url( $variant );
		if ( '' === $url ) {
			return '';
		}

		/*
		 * A dark bar needs the light-inked version of the same mark: a logo
		 * drawn for a white page disappears on a black one, which is exactly
		 * what happened to the rail before this file existed. Only our own
		 * shipped file has a second version; an office's upload is used as
		 * they drew it.
		 */
		if ( false !== strpos( $class, 'is-on-dark' )
			&& ESTAT_URL . 'assets/img/mayfair-mark.png' === $url
			&& self::has( 'mayfair-on-dark.png' ) ) {
			$url = ESTAT_URL . 'assets/img/mayfair-on-dark.png';
		}

		return '<img class="estat-logo estat-logo--' . esc_attr( $variant ) . ' ' . esc_attr( $class ) . '" src="' . esc_url( $url ) . '"'
			. ' alt="' . esc_attr( $label ) . '" decoding="async" loading="eager"'
			. ( '' === $label ? ' aria-hidden="true"' : '' ) . '>';
	}

	/** Is a shipped file actually there? A missing one is not an error. */
	private static function has( string $file ): bool {
		return file_exists( ESTAT_DIR . 'assets/img/' . $file );
	}
}
