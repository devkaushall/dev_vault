<?php
/**
 * Database tables owned by the plugin.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Install;

defined( 'ABSPATH' ) || exit;

/**
 * Operational records live in dedicated, indexed tables so the plugin stays
 * fast on shared hosting with roughly ten thousand listings.
 *
 * Table names are part of the public data contract.
 */
final class Schema {

	/** The one-time "a missing key is NULL, never an empty string" upgrade. */
	private const KEY_FIX_OPTION = 'estat_os_key_nullable';

	/** Where the names of any tables that failed to be created are kept. */
	const MISSING_KEY = 'estat_os_missing_tables';

	/**
	 * Object cache key for the table health answer.
	 *
	 * @var string
	 */
	const HEALTH_KEY = 'estat_schema_healthy';

	/**
	 * Per-request memo of the table health answer.
	 *
	 * @var bool|null
	 */
	private static $healthy = null;

	/**
	 * Table base names.
	 *
	 * @return string[]
	 */
	public static function tables(): array {
		return array( 'estat_leads', 'estat_lead_events', 'estat_visits', 'estat_forms', 'estat_submissions', 'estat_index', 'estat_audit', 'estat_webhook_log', 'estat_import_jobs', 'estat_requests', 'estat_search_alerts', 'estat_alerts', 'estat_templates', 'estat_share_log' );
	}

	/**
	 * Fully qualified table name.
	 *
	 * @param string $name Base name without prefix.
	 * @return string
	 */
	public static function table( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . $name;
	}

	/**
	 * Create or update all tables. dbDelta is idempotent.
	 *
	 * @return void
	 */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$p       = $wpdb->prefix;

		$sql = array();

		/*
		 * idempotency_key is NULL, not an empty string: the column is UNIQUE,
		 * the database allows one empty string only, and before this the
		 * second enquiry that arrived without a key was refused outright.
		 * (The note lives out here on purpose — a comment inside a CREATE
		 * TABLE is standard SQL but not every database layer will read it,
		 * and a table that fails to parse is a table that never exists.)
		 */
		$sql[] = "CREATE TABLE {$p}estat_leads (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			name VARCHAR(191) NOT NULL DEFAULT '',
			phone VARCHAR(32) NOT NULL DEFAULT '',
			email VARCHAR(191) NOT NULL DEFAULT '',
			message TEXT NULL,
			intent VARCHAR(20) NOT NULL DEFAULT '',
			locality VARCHAR(191) NOT NULL DEFAULT '',
			budget_min DECIMAL(18,2) NOT NULL DEFAULT 0,
			budget_max DECIMAL(18,2) NOT NULL DEFAULT 0,
			source VARCHAR(64) NOT NULL DEFAULT 'website',
			source_url VARCHAR(255) NOT NULL DEFAULT '',
			submission_source VARCHAR(191) NOT NULL DEFAULT '',
			utm_source VARCHAR(100) NOT NULL DEFAULT '',
			utm_medium VARCHAR(100) NOT NULL DEFAULT '',
			utm_campaign VARCHAR(100) NOT NULL DEFAULT '',
			listing_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			assigned_agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(32) NOT NULL DEFAULT 'new',
			lost_reason VARCHAR(32) NOT NULL DEFAULT '',
			notes LONGTEXT NULL,
			followup_at DATETIME NULL,
			consent TINYINT(1) NOT NULL DEFAULT 0,
			consent_text_version VARCHAR(20) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			practice TINYINT(1) NOT NULL DEFAULT 0,
			erased TINYINT(1) NOT NULL DEFAULT 0,
			dedupe_hash CHAR(64) NOT NULL DEFAULT '',
			idempotency_key CHAR(64) NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY dedupe_hash (dedupe_hash),
			KEY status_created (status, created_at),
			KEY agent_id (agent_id),
			KEY assigned_agent_id (assigned_agent_id),
			KEY listing_id (listing_id),
			KEY phone (phone),
			KEY created_at (created_at),
			KEY followup_at (followup_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_lead_events (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			lead_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(32) NOT NULL DEFAULT 'created',
			payload LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY lead_id (lead_id),
			KEY type (type),
			KEY created_at (created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_visits (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			lead_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			listing_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			scheduled_at DATETIME NOT NULL,
			outcome VARCHAR(32) NOT NULL DEFAULT 'pending',
			notes TEXT NULL,
			reminder_sent TINYINT(1) NOT NULL DEFAULT 0,
			practice TINYINT(1) NOT NULL DEFAULT 0,
			dedupe_hash CHAR(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY dedupe_hash (dedupe_hash),
			KEY scheduled_at (scheduled_at),
			KEY lead_id (lead_id),
			KEY agent_id (agent_id),
			KEY outcome (outcome)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_forms (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			name VARCHAR(191) NOT NULL DEFAULT '',
			slug VARCHAR(191) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			definition LONGTEXT NULL,
			settings LONGTEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_submissions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			lead_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			payload LONGTEXT NULL,
			page_url VARCHAR(255) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			idempotency_key CHAR(64) NULL DEFAULT NULL,
			practice TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY form_created (form_id, created_at),
			KEY lead_id (lead_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_index (
			listing_id BIGINT UNSIGNED NOT NULL,
			post_status VARCHAR(20) NOT NULL DEFAULT 'draft',
			title VARCHAR(255) NOT NULL DEFAULT '',
			search_text TEXT NULL,
			offer VARCHAR(20) NOT NULL DEFAULT '',
			property_type VARCHAR(32) NOT NULL DEFAULT '',
			availability VARCHAR(20) NOT NULL DEFAULT '',
			construction VARCHAR(20) NOT NULL DEFAULT '',
			furnishing VARCHAR(20) NOT NULL DEFAULT '',
			facing VARCHAR(20) NOT NULL DEFAULT '',
			price DECIMAL(18,2) NOT NULL DEFAULT 0,
			rent DECIMAL(18,2) NOT NULL DEFAULT 0,
			price_sort DECIMAL(18,2) NOT NULL DEFAULT 0,
			area_sqft DECIMAL(14,2) NOT NULL DEFAULT 0,
			bedrooms SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			bathrooms SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			floor SMALLINT NOT NULL DEFAULT 0,
			total_floors SMALLINT NOT NULL DEFAULT 0,
			parking SMALLINT NOT NULL DEFAULT 0,
			balconies SMALLINT NOT NULL DEFAULT 0,
			age SMALLINT NOT NULL DEFAULT 0,
			locality_ids VARCHAR(191) NOT NULL DEFAULT '',
			amenities_ids VARCHAR(191) NOT NULL DEFAULT '',
			features_ids VARCHAR(191) NOT NULL DEFAULT '',
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			featured TINYINT(1) NOT NULL DEFAULT 0,
			investment TINYINT(1) NOT NULL DEFAULT 0,
			verified TINYINT(1) NOT NULL DEFAULT 0,
			practice TINYINT(1) NOT NULL DEFAULT 0,
			completeness SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			latitude DECIMAL(10,7) NULL,
			longitude DECIMAL(10,7) NULL,
			possession_date DATE NULL,
			published_at DATETIME NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (listing_id),
			KEY status_offer (post_status, offer),
			KEY price_sort (price_sort),
			KEY area_sqft (area_sqft),
			KEY bedrooms (bedrooms),
			KEY property_type (property_type),
			KEY project_id (project_id),
			KEY agent_id (agent_id),
			KEY featured (featured),
			KEY verified (verified),
			KEY facing (facing),
			KEY published_at (published_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_audit (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			action VARCHAR(64) NOT NULL DEFAULT '',
			object_type VARCHAR(32) NOT NULL DEFAULT '',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			context LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY action_created (action, created_at),
			KEY object (object_type, object_id),
			KEY created_at (created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_webhook_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			event VARCHAR(64) NOT NULL DEFAULT '',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			status_code SMALLINT NOT NULL DEFAULT 0,
			success TINYINT(1) NOT NULL DEFAULT 0,
			attempt SMALLINT UNSIGNED NOT NULL DEFAULT 1,
			error VARCHAR(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY event_created (event, created_at)
		) {$charset};";

		$sql[] = "CREATE TABLE {$p}estat_import_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			kind VARCHAR(32) NOT NULL DEFAULT 'listings',
			file_path VARCHAR(255) NOT NULL DEFAULT '',
			mapping LONGTEXT NULL,
			state VARCHAR(20) NOT NULL DEFAULT 'pending',
			total_rows INT UNSIGNED NOT NULL DEFAULT 0,
			processed_rows INT UNSIGNED NOT NULL DEFAULT 0,
			created_count INT UNSIGNED NOT NULL DEFAULT 0,
			updated_count INT UNSIGNED NOT NULL DEFAULT 0,
			skipped_count INT UNSIGNED NOT NULL DEFAULT 0,
			errors LONGTEXT NULL,
			file_hash CHAR(64) NOT NULL DEFAULT '',
			created_ids LONGTEXT NULL,
			undo_data LONGTEXT NULL,
			bridge_type VARCHAR(32) NOT NULL DEFAULT '',
			duplicate_mode VARCHAR(20) NOT NULL DEFAULT 'skip',
			PRIMARY KEY  (id),
			KEY state (state),
			KEY file_hash (file_hash)
		) {$charset};";

		/*
		 * Changes an agent has proposed to a record that is not theirs.
		 *
		 * Only the fields being changed are stored, as JSON, never a copy of
		 * the whole record. Two requests against the same property can then
		 * be approved independently without one silently reverting the
		 * other's untouched fields.
		 */
		$sql[] = "CREATE TABLE {$p}estat_requests (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			record_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			record_type VARCHAR(32) NOT NULL DEFAULT '',
			requested_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reviewed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			changes LONGTEXT NULL,
			message TEXT NULL,
			reason TEXT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY record_id (record_id),
			KEY requested_by (requested_by)
		) {$charset};";

		// Search alerts — visitor watches a search, gets email when match goes live.
		// Old table name kept for BC, new table per brief F4 is estat_alerts.
		$sql[] = "CREATE TABLE {$p}estat_search_alerts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			email VARCHAR(191) NOT NULL DEFAULT '',
			name VARCHAR(191) NOT NULL DEFAULT '',
			filters LONGTEXT NULL,
			filters_hash CHAR(64) NOT NULL DEFAULT '',
			active TINYINT(1) NOT NULL DEFAULT 1,
			confirmed TINYINT(1) NOT NULL DEFAULT 0,
			confirm_token CHAR(64) NOT NULL DEFAULT '',
			last_sent_at DATETIME NULL,
			last_listing_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			send_count INT UNSIGNED NOT NULL DEFAULT 0,
			source_url VARCHAR(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY email (email),
			KEY active (active),
			KEY filters_hash (filters_hash)
		) {$charset};";

		// F4: brief says {prefix}estat_alerts with query json, frequency instant|daily, token, etc.
		$sql[] = "CREATE TABLE {$p}estat_alerts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			email VARCHAR(191) NOT NULL DEFAULT '',
			phone VARCHAR(32) NOT NULL DEFAULT '',
			query LONGTEXT NULL,
			frequency VARCHAR(20) NOT NULL DEFAULT 'instant',
			confirmed TINYINT(1) NOT NULL DEFAULT 0,
			token VARCHAR(64) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			last_sent_at DATETIME NULL,
			unsubscribed_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY email (email),
			KEY confirmed (confirmed),
			KEY token (token)
		) {$charset};";

		// Templates — drag-drop order of listing page blocks.
		$sql[] = "CREATE TABLE {$p}estat_templates (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			name VARCHAR(191) NOT NULL DEFAULT '',
			slug VARCHAR(191) NOT NULL DEFAULT '',
			type VARCHAR(32) NOT NULL DEFAULT 'listing',
			blocks LONGTEXT NULL,
			settings LONGTEXT NULL,
			is_default TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY type (type)
		) {$charset};";

		// Share log — optional analytics for WhatsApp / copy link.
		$sql[] = "CREATE TABLE {$p}estat_share_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			listing_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			channel VARCHAR(32) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY listing_id (listing_id),
			KEY channel (channel),
			KEY created_at (created_at)
		) {$charset};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}

		// dbDelta reports nothing when it fails, and a missing table used to
		// turn into nothing but "the office database is not ready yet" on
		// every screen, with no way to find out which one. What is missing is
		// written down, and said out loud in the office (see Admin::boot).
		self::audit_tables();

		self::clear_empty_keys( $p );

		self::flush_health();
	}



	/**
	 * Move the old "empty string" idempotency keys to NULL.
	 *
	 * Before the column allowed NULL, the only value a row could carry when
	 * the page sent no key was '', and a UNIQUE index can hold that value
	 * exactly once. Every enquiry after the first then failed to save. The
	 * rows written back then are tidied here so an old row cannot collide
	 * with anything again.
	 *
	 * Runs after dbDelta, and stays quiet on an installation whose column is
	 * still NOT NULL: in that case the insert path hands the row a key of its
	 * own instead, so nothing is lost either way.
	 *
	 * @param string $p Table prefix.
	 * @return void
	 */
	private static function clear_empty_keys( string $p ): void {
		global $wpdb;

		// Once per installation. dbDelta does move a column's nullability on
		// MySQL, but it is not the thing to gamble a customer's enquiries on,
		// so the change is asked for plainly and the flag says it was asked.
		if ( '1' === get_option( self::KEY_FIX_OPTION ) ) {
			return;
		}

		$done = true;

		foreach ( array( 'estat_leads', 'estat_submissions' ) as $name ) {
			$table = $p . $name;
			$wpdb->suppress_errors( true );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$altered = $wpdb->query( "ALTER TABLE {$table} MODIFY idempotency_key CHAR(64) NULL DEFAULT NULL" );

			/*
			 * Did it actually happen?
			 *
			 * An ALTER can be refused — a database that does not allow it, a
			 * table that is locked, a driver that will not run one. Refused
			 * looks exactly like done: the query returns false, the error is
			 * suppressed and the old code wrote "finished" in the option and
			 * never looked again. So the claim is now tested three ways, and
			 * the option is only written when all three agree:
			 *
			 *   1. the column itself reports that it may hold NULL,
			 *   2. the rows that still hold an empty string are cleared —
			 *      if the column still refuses NULL this statement fails,
			 *   3. nothing is left holding an empty string afterwards.
			 *
			 * When the test cannot be passed the option is deleted, not set.
			 * The next plugin update tries again, and in the meantime no
			 * enquiry is lost: Leads::create() hands every key-less row a key
			 * of its own, so a second walk-in enquiry saves either way.
			 */
			$col = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
				$wpdb->prepare( 'SHOW COLUMNS FROM ' . $table . ' LIKE %s', 'idempotency_key' ),
				ARRAY_A
			);

			$before = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE idempotency_key = ''" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$after  = $before;
			$clear  = 0;

			if ( $before > 0 ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$clear = $wpdb->query( "UPDATE {$table} SET idempotency_key = NULL WHERE idempotency_key = ''" );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$after = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE idempotency_key = ''" );
				if ( false === $clear ) {
					$after = $before;
				}
			}

			$wpdb->suppress_errors( false );

			if ( false === $altered || ! is_array( $col ) || 'YES' !== strtoupper( (string) ( $col['Null'] ?? '' ) ) || $after > 0 ) {
				$done = false;
			}
		}

		if ( $done ) {
			update_option( self::KEY_FIX_OPTION, '1', false );
		} else {
			delete_option( self::KEY_FIX_OPTION );
		}
	}

	/**
	 * Write down any table that is not there, so the office can be told.
	 *
	 * The answer is kept in an option rather than recomputed on every screen:
	 * this runs once per install or upgrade, and the "not ready" message the
	 * office sees is raised from the cached health answer.
	 *
	 * @return array<int,string> Table names that are missing, without prefix.
	 */
	public static function audit_tables(): array {
		global $wpdb;

		$missing = array();
		foreach ( self::tables() as $name ) {
			$table = $wpdb->prefix . $name;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			if ( $found !== $table ) {
				$missing[] = $name;
			}
		}

		if ( $missing ) {
			update_option( self::MISSING_KEY, $missing, false );
		} else {
			delete_option( self::MISSING_KEY );
		}

		return $missing;
	}

	/**
	 * The tables the office is missing, if any.
	 *
	 * @return array<int,string>
	 */
	public static function missing_tables(): array {
		$stored = get_option( self::MISSING_KEY, array() );
		return is_array( $stored ) ? array_values( array_filter( array_map( 'strval', $stored ) ) ) : array();
	}

	/**
	 * Whether all expected tables exist.
	 *
	 * @return bool
	 */
	public static function healthy(): bool {
		if ( null !== self::$healthy ) {
			return self::$healthy;
		}

		// This is consulted on nearly every read path, so the answer is cached
		// for the request and in the object cache. Without this a single
		// listings page would issue one SHOW TABLES per table per call.
		$cached = wp_cache_get( self::HEALTH_KEY, 'estat' );
		if ( is_string( $cached ) && '' !== $cached ) {
			self::$healthy = ( 'yes' === $cached );
			return self::$healthy;
		}

		global $wpdb;
		$healthy = true;
		foreach ( self::tables() as $name ) {
			$table = $wpdb->prefix . $name;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			if ( $found !== $table ) {
				$healthy = false;
				break;
			}
		}

		self::$healthy = $healthy;
		wp_cache_set( self::HEALTH_KEY, $healthy ? 'yes' : 'no', 'estat', HOUR_IN_SECONDS );
		return $healthy;
	}

	/**
	 * Forget the cached health answer.
	 *
	 * Call this after creating or dropping tables so the next check looks again.
	 *
	 * @return void
	 */
	public static function flush_health(): void {
		self::$healthy = null;
		wp_cache_delete( self::HEALTH_KEY, 'estat' );
	}
}
