/**
 * Estat.OS — favorites and property comparison.
 * Guest choices live in localStorage; nothing personal is stored.
 */
( function () {
	'use strict';

	var settings = window.estatPublic || { i18n: {} };
	var FAV_KEY = 'estat_favorites';
	var CMP_KEY = 'estat_compare';
	var MAX_COMPARE = 4;

	function read( key ) {
		try {
			var raw = window.localStorage.getItem( key );
			var list = raw ? JSON.parse( raw ) : [];
			return Array.isArray( list ) ? list.filter( function ( id ) {
				return typeof id === 'number' && id > 0;
			} ) : [];
		} catch ( e ) {
			return [];
		}
	}

	function write( key, list ) {
		try {
			window.localStorage.setItem( key, JSON.stringify( list.slice( 0, 100 ) ) );
		} catch ( e ) {
			/* storage may be full or blocked; the page still works */
		}
	}

	function toggle( key, id, limit ) {
		var list = read( key );
		var index = list.indexOf( id );
		if ( index !== -1 ) {
			list.splice( index, 1 );
		} else {
			if ( limit && list.length >= limit ) {
				return { list: list, added: false, full: true };
			}
			list.push( id );
		}
		write( key, list );
		return { list: list, added: index === -1, full: false };
	}

	function syncButtons() {
		var favorites = read( FAV_KEY );
		var compares = read( CMP_KEY );
		document.querySelectorAll( '.estat-fav' ).forEach( function ( button ) {
			var id = parseInt( button.getAttribute( 'data-listing' ), 10 );
			button.setAttribute( 'aria-pressed', favorites.indexOf( id ) !== -1 ? 'true' : 'false' );
		} );
		document.querySelectorAll( '.estat-compare' ).forEach( function ( button ) {
			var id = parseInt( button.getAttribute( 'data-listing' ), 10 );
			button.setAttribute( 'aria-pressed', compares.indexOf( id ) !== -1 ? 'true' : 'false' );
		} );
	}

	/*
	 * The comparison table.
	 *
	 * The rows are not written here. Each property arrives from the server
	 * with the same ten questions the office and the agent's phone ask —
	 * already in the reader's language — and this only lays them out. That
	 * is the whole point: one website cannot end up asking a different ten
	 * things from the office.
	 *
	 * A question with no answer prints the words "Not said" rather than
	 * being dropped, because a gap you can see is a gap the office can fill.
	 */
	function say( key, fallback ) {
		return ( settings.i18n && settings.i18n[ key ] ) || fallback;
	}

	function notSaid() {
		return '<span class="estat-compare-none">' + say( 'notSaid', 'Not said' ) + '</span>';
	}

	function escapeText( text ) {
		return String( text ).replace( /[&<>"]/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ c ];
		} );
	}

	function cell( value ) {
		var text = ( value === null || value === undefined ) ? '' : String( value ).trim();
		if ( '' === text || '0' === text ) {
			return notSaid();
		}
		return '<span>' + escapeText( text ) + '</span>';
	}

	function renderCompare() {
		var panel = document.querySelector( '#estat-compare-panel .estat-compare-table' );
		if ( ! panel ) {
			return;
		}
		var ids = read( CMP_KEY );
		var note = document.querySelector( '#estat-compare-panel .estat-compare-note' );
		var send = document.querySelector( '#estat-compare-panel .estat-compare-send' );

		if ( ! ids.length ) {
			panel.innerHTML = '';
			if ( note ) { note.textContent = ''; }
			if ( send ) { send.hidden = true; }
			return;
		}

		Promise.all( ids.map( function ( id ) {
			return fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
				return r.ok ? r.json() : null;
			} ).catch( function () {
				return null;
			} );
		} ) ).then( function ( items ) {
			items = items.filter( Boolean );
			panel.innerHTML = '';
			if ( ! items.length ) {
				// Picked properties that could not be fetched are not an
				// empty comparison — say what happened.
				panel.innerHTML = '<p class="estat-muted">'
					+ escapeText( say( 'failed', 'That did not go through. Please try again.' ) ) + '</p>';
				if ( note ) { note.textContent = ''; }
				if ( send ) { send.hidden = true; }
				return;
			}

			if ( note ) {
				note.textContent = items.length === 1
					? say( 'onePicked', 'One property is in the comparison. Add another to see them side by side.' )
					: ( ( settings.i18n && settings.i18n.picked ) || '%d are side by side.' ).replace( '%d', items.length );
			}
			if ( send ) { send.hidden = items.length < 1; }

			/*
			 * The questions travel with every property. If one reply were
			 * ever to arrive without them, fall back to the keys of the
			 * answers themselves rather than drawing an empty table — a
			 * blank comparison is worse than one with plain headings.
			 */
			var questions = items[ 0 ].questions || {};
			var keys = Object.keys( questions );
			if ( ! keys.length ) {
				items.forEach( function ( item ) {
					Object.keys( item.facts || {} ).forEach( function ( key ) {
						if ( keys.indexOf( key ) === -1 ) { keys.push( key ); }
						if ( ! questions[ key ] ) {
							questions[ key ] = key.charAt( 0 ).toUpperCase() + key.slice( 1 );
						}
					} );
				} );
			}

			var table = document.createElement( 'table' );
			table.className = 'estat-compare-grid';
			var head = document.createElement( 'tr' );
			head.appendChild( document.createElement( 'th' ) );
			items.forEach( function ( item ) {
				var th = document.createElement( 'th' );
				var link = document.createElement( 'a' );
				link.href = item.url;
				link.textContent = item.title;
				th.appendChild( link );
				var drop = document.createElement( 'button' );
				drop.type = 'button';
				drop.className = 'estat-compare-drop';
				drop.setAttribute( 'data-listing', String( item.id ) );
				drop.textContent = say( 'remove', 'Remove' );
				th.appendChild( drop );
				head.appendChild( th );
			} );
			table.appendChild( head );

			keys.forEach( function ( key ) {
				var tr = document.createElement( 'tr' );
				var label = document.createElement( 'th' );
				label.scope = 'row';
				label.textContent = questions[ key ];
				tr.appendChild( label );
				items.forEach( function ( item ) {
					var td = document.createElement( 'td' );
					td.innerHTML = cell( ( item.facts || {} )[ key ] );
					tr.appendChild( td );
				} );
				table.appendChild( tr );
			} );

			panel.appendChild( table );
		} );
	}

	/**
	 * "Send this list to the office."
	 *
	 * The shortlist becomes an ordinary enquiry — the same one the contact
	 * form makes — and then WhatsApp opens with the same list written out,
	 * so the visitor can carry on in the app they already use.
	 */
	function wireShortlistForm() {
		var form = document.querySelector( '#estat-compare-panel .estat-shortlist-form' );
		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var ids = read( CMP_KEY );
			if ( ! ids.length ) {
				return;
			}

			var button = form.querySelector( 'button[type=submit]' );
			var said   = form.querySelector( '.estat-shortlist-said' );
			var name   = form.querySelector( '[name=name]' );
			var phone  = form.querySelector( '[name=phone]' );

			if ( name && '' === name.value.trim() ) {
				if ( said ) { said.textContent = say( 'needName', 'Please leave your name.' ); }
				if ( name ) { name.focus(); }
				return;
			}
			if ( phone && phone.value.replace( /\D+/g, '' ).length < 8 ) {
				if ( said ) { said.textContent = say( 'needPhone', 'Please leave a phone number the office can call.' ); }
				if ( phone ) { phone.focus(); }
				return;
			}

			if ( button ) { button.disabled = true; }
			if ( said ) { said.textContent = say( 'sending', 'Sending…' ); }

			var body = new FormData( form );
			body.append( 'ids', ids.join( ',' ) );
			body.append( 'estat_nonce', settings.shortlistNonce || '' );
			body.append( 'page_url', window.location.href );
			body.append( 'idempotency_key', 'sl-' + ids.join( '-' ) + '-' + Math.floor( Date.now() / 60000 ) );

			fetch( settings.restUrl + 'shortlist', {
				method: 'POST',
				credentials: 'same-origin',
				body: body
			} ).then( function ( r ) {
				return r.json();
			} ).then( function ( res ) {
				if ( button ) { button.disabled = false; }
				if ( ! res || ! res.ok ) {
					if ( said ) {
						said.textContent = ( res && res.message ) || say( 'failed', 'That did not go through. Please try again.' );
					}
					return;
				}
				if ( said ) { said.textContent = res.message || say( 'sent', 'Sent to the office.' ); }
				if ( res.whatsapp ) {
					window.open( res.whatsapp, '_blank', 'noopener' );
				}
			} ).catch( function () {
				if ( button ) { button.disabled = false; }
				if ( said ) { said.textContent = say( 'failed', 'That did not go through. Please try again.' ); }
			} );
		} );
	}

/*
	 * The saved list.
	 *
	 * Cards, not names: a visitor recognises their own shortlist by the
	 * photographs, not by a title. Each one carries the one action worth
	 * taking from here — put it in the comparison, or take it off the list.
	 */
	/*
	 * Shown or hidden by a class, not by the `hidden` attribute.
	 *
	 * `.estat-empty` is drawn with `display:grid`, and a stylesheet rule
	 * beats the browser's own `[hidden] { display:none }` — so a page that
	 * set `hidden` on it still showed it. That is how a visitor whose one
	 * saved property failed to load saw "1 saved" and "Nothing saved yet" on
	 * the same screen at the same time.
	 */
	function show( node, visible ) {
		if ( ! node ) {
			return;
		}
		node.hidden = ! visible;
		node.classList.toggle( 'is-hidden', ! visible );
	}

	function renderFavorites() {
		var section = document.querySelector( '#estat-favorites .estat-grid' );
		if ( ! section ) {
			return;
		}
		var empty = document.querySelector( '#estat-favorites .estat-empty' );
		var count = document.querySelector( '#estat-favorites .estat-favorites-count' );
		var ids = read( FAV_KEY );

		if ( ! ids.length ) {
			section.innerHTML = '';
			show( empty, true );
			if ( count ) { count.textContent = ''; }
			return;
		}

		/*
		 * The empty state is not decided yet — it waits to see what was
		 * actually drawn. A fetch that fails is not the same thing as a
		 * list that is empty, and saying "nothing saved" when the answer
		 * from the server was an error sends the visitor to look for a
		 * problem that is not theirs.
		 */
		show( empty, false );

		Promise.all( ids.map( function ( id ) {
			return fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
				return r.ok ? r.json() : null;
			} ).catch( function () {
				return null;
			} );
		} ) ).then( function ( items ) {
			items = items.filter( Boolean );
			section.innerHTML = '';

			/*
			 * The count belongs to what is on the screen, not to what is in
			 * the browser: three saved and two drawn reads "2 saved", and a
			 * visit that fails outright says so instead of pretending the
			 * list is empty.
			 */
			if ( count ) {
				count.textContent = items.length
					? ( ( settings.i18n && settings.i18n.savedCount ) || '%d saved' ).replace( '%d', items.length )
					: '';
			}
			if ( ! items.length ) {
				if ( ids.length ) {
					section.innerHTML = '<p class="estat-muted">'
						+ escapeText( say( 'failed', 'That did not go through. Please try again.' ) ) + '</p>';
				} else {
					show( empty, true );
				}
				return;
			}

			items.forEach( function ( item ) {
				var card = document.createElement( 'article' );
				card.className = 'estat-card estat-fav-card';

				if ( item.cover ) {
					var shot = document.createElement( 'a' );
					shot.className = 'estat-fav-shot';
					shot.href = item.url;
					shot.style.backgroundImage = 'url(' + item.cover + ')';
					shot.setAttribute( 'aria-hidden', 'true' );
					card.appendChild( shot );
				}

				var body = document.createElement( 'div' );
				body.className = 'estat-card-body';

				var title = document.createElement( 'h3' );
				title.className = 'estat-card-title';
				var link = document.createElement( 'a' );
				link.href = item.url;
				link.textContent = item.title;
				title.appendChild( link );

				var price = document.createElement( 'p' );
				price.className = 'estat-card-price';
				price.textContent = item.price_display || say( 'onRequest', 'Price on request' );

				body.appendChild( title );
				body.appendChild( price );

				var where = ( item.facts && item.facts.locality ) || '';
				if ( where ) {
					var line = document.createElement( 'p' );
					line.className = 'estat-fav-where';
					line.textContent = where;
					body.appendChild( line );
				}

				var acts = document.createElement( 'div' );
				acts.className = 'estat-fav-acts';

				var cmp = document.createElement( 'button' );
				cmp.type = 'button';
				cmp.className = 'estat-compare estat-btn estat-btn--ghost';
				cmp.setAttribute( 'data-listing', String( item.id ) );
				cmp.textContent = say( 'compareThis', 'Compare' );
				acts.appendChild( cmp );

				var off = document.createElement( 'button' );
				off.type = 'button';
				off.className = 'estat-fav estat-btn estat-btn--quiet';
				off.setAttribute( 'data-listing', String( item.id ) );
				off.textContent = say( 'remove', 'Remove' );
				acts.appendChild( off );

				body.appendChild( acts );
				card.appendChild( body );
				section.appendChild( card );
			} );

			syncButtons();
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		var fav = event.target.closest ? event.target.closest( '.estat-fav' ) : null;
		if ( fav ) {
			toggle( FAV_KEY, parseInt( fav.getAttribute( 'data-listing' ), 10 ), 0 );
			syncButtons();
			renderFavorites();
			return;
		}
		var drop = event.target.closest ? event.target.closest( '.estat-compare-drop' ) : null;
		if ( drop ) {
			toggle( CMP_KEY, parseInt( drop.getAttribute( 'data-listing' ), 10 ), 0 );
			syncButtons();
			renderCompare();
			return;
		}

		var cmp = event.target.closest ? event.target.closest( '.estat-compare' ) : null;
		if ( cmp ) {
			var result = toggle( CMP_KEY, parseInt( cmp.getAttribute( 'data-listing' ), 10 ), MAX_COMPARE );
			if ( result.full ) {
				window.alert( ( settings.i18n && settings.i18n.compareFull ) || 'You can compare up to four properties at a time.' );
				return;
			}
			syncButtons();
			renderCompare();

			/*
			 * If the table is somewhere else on this page, take them to it.
			 * Choosing three properties one after another and never being
			 * shown the result is how a comparison gets forgotten.
			 */
			var panel = document.querySelector( '#estat-compare-panel' );
			if ( panel && ! panel.contains( cmp ) && typeof panel.scrollIntoView === 'function' ) {
				panel.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			}
		}
	} );

	document.addEventListener( 'DOMContentLoaded', function () {
		syncButtons();
		renderCompare();
		renderFavorites();
		wireShortlistForm();
	} );
}() );

/* ------------------------------------------------------------------
 * The monthly repayment estimate.
 *
 * Everything happens here in the browser. No request is made, nothing
 * is stored, and no lead is created by someone moving the numbers
 * around — which matters, because a visitor working out affordability
 * is thinking, not enquiring, and should not be treated as a lead for
 * doing so.
 * ------------------------------------------------------------------ */

( function () {
	'use strict';

	var config = window.estatPublic || {};
	var strings = config.i18n || {};
	var symbol = config.currency || '\u20b9';
	var indian = config.priceStyle !== 'plain' && config.priceStyle !== 'short';

	/**
	 * Trim a number the way the server's Format::money() does, so the
	 * calculator and the price above it read as one website.
	 */
	function trim( value ) {
		var rounded = Math.round( value * 100 ) / 100;

		return String( rounded ).replace( /\.0+$/, '' ).replace( /(\.\d*[1-9])0+$/, '$1' );
	}

	function money( amount ) {
		if ( ! isFinite( amount ) || amount < 0 ) {
			return symbol + '0';
		}

		if ( indian ) {
			if ( amount >= 10000000 ) {
				return symbol + trim( amount / 10000000 ) + ' ' + ( strings.crore || 'Cr' );
			}
			if ( amount >= 100000 ) {
				return symbol + trim( amount / 100000 ) + ' ' + ( strings.lakh || 'Lakh' );
			}
			if ( amount >= 1000 ) {
				return symbol + trim( amount / 1000 ) + ' ' + ( strings.thousand || 'K' );
			}
		} else if ( amount >= 1000000 ) {
			return symbol + trim( amount / 1000000 ) + 'M';
		} else if ( amount >= 1000 ) {
			return symbol + trim( amount / 1000 ) + 'K';
		}

		return symbol + Math.round( amount ).toLocaleString();
	}

	/**
	 * The formula every Indian lender publishes:
	 *
	 *   EMI = P x R x (1+R)^N / ((1+R)^N - 1)
	 *
	 * A rate of exactly zero would divide by zero, so that case is the
	 * plain principal split evenly across the months.
	 */
	function monthlyPayment( principal, annualRate, years ) {
		var months = years * 12;

		if ( principal <= 0 || months <= 0 ) {
			return 0;
		}

		if ( annualRate <= 0 ) {
			return principal / months;
		}

		var monthly = annualRate / 12 / 100;
		var growth = Math.pow( 1 + monthly, months );

		return ( principal * monthly * growth ) / ( growth - 1 );
	}

	function setUp( panel ) {
		var loanBox = panel.querySelector( '.estat-emi-loan' );
		var rateBox = panel.querySelector( '.estat-emi-rate' );
		var yearsBox = panel.querySelector( '.estat-emi-years' );
		var value = panel.querySelector( '.estat-emi-value' );
		var total = panel.querySelector( '.estat-emi-total' );

		if ( ! loanBox || ! rateBox || ! yearsBox || ! value ) {
			return;
		}

		function recalculate() {
			var principal = parseFloat( loanBox.value );
			var rate = parseFloat( rateBox.value );
			var years = parseFloat( yearsBox.value );

			// An empty or nonsense box should say so rather than print NaN.
			if ( ! isFinite( principal ) || ! isFinite( rate ) || ! isFinite( years ) || years <= 0 ) {
				value.textContent = '\u2014';
				if ( total ) {
					total.textContent = strings.emiCheck || 'Please check the numbers.';
				}
				return;
			}

			var payment = monthlyPayment( principal, rate, years );

			value.textContent = money( payment );

			if ( total ) {
				total.textContent = ( strings.emiTotal || '%s repaid in total' )
					.replace( '%s', money( payment * years * 12 ) );
			}
		}

		[ loanBox, rateBox, yearsBox ].forEach( function ( box ) {
			box.addEventListener( 'input', recalculate );
			box.addEventListener( 'change', recalculate );
		} );

		recalculate();
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		Array.prototype.forEach.call( document.querySelectorAll( '.estat-emi' ), setUp );
	} );
}() );

/**
 * Photo gallery on a property page.
 *
 * The office uploads a gallery and the page shows the first photo large, with
 * the rest as thumbnails under it. Nobody should have to reload the page to
 * see photo four, so a click swaps the large one and marks the thumb.
 */
( function () {
	document.addEventListener( 'DOMContentLoaded', function () {
		var galleries = document.querySelectorAll( '[data-estat-gallery]' );
		Array.prototype.forEach.call( galleries, function ( gallery ) {
			var main = gallery.querySelector( '.estat-gallery-main img' );
			if ( ! main ) {
				return;
			}
			var thumbs = gallery.querySelectorAll( '.estat-gallery-thumb' );
			Array.prototype.forEach.call( thumbs, function ( thumb ) {
				thumb.addEventListener( 'click', function () {
					var src = thumb.getAttribute( 'data-estat-photo' );
					if ( ! src ) {
						return;
					}
					main.removeAttribute( 'srcset' );
					main.setAttribute( 'src', src );
					Array.prototype.forEach.call( thumbs, function ( other ) {
						other.classList.remove( 'is-current' );
					} );
					thumb.classList.add( 'is-current' );
				} );
			} );
		} );
	} );
}() );
