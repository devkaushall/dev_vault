/*!
 * Estate OS — the office interface.
 *
 * Everything here answers one question: when somebody touches the screen,
 * does something answer? The drawer slides in instead of a new page loading,
 * numbers count up instead of appearing, a card lifts when it is dragged,
 * and a toast confirms whatever was just done.
 *
 * No libraries. Plain browser JavaScript, kept in one place.
 */
(function () {
	'use strict';

	if (!window.estatOs) { return; }

	var CFG = window.estatOs;
	var I18N = CFG.i18n || {};
	var AJAX = CFG.ajax || '/wp-admin/admin-ajax.php';
	var NONCE = CFG.nonce || '';

	/* ---------------------------------------------------------------- utils */

	function $(sel, root) { return (root || document).querySelector(sel); }
	function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
	function word(key, fallback) { return I18N[key] || fallback || key; }

	/**
	 * Text that is going to be written as markup, made safe first.
	 *
	 * Some of what this screen writes comes from the database — a property
	 * title, a photograph's name, a message the office built out of a field
	 * label. Written straight into innerHTML those are markup, and whatever
	 * somebody typed becomes elements. This turns the five characters that
	 * change the meaning of markup into text.
	 */
	function esc(value) {
		return String(value === null || value === undefined ? '' : value)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	/** An icon name can only ever be one of the marks this plugin draws. */
	function iconName(name) {
		var clean = String(name || 'dot').replace(/[^a-z0-9_-]/gi, '');
		return clean || 'dot';
	}

	function el(tag, cls, html) {
		var node = document.createElement(tag);
		if (cls) { node.className = cls; }
		if (html !== undefined) { node.innerHTML = html; }
		return node;
	}

	/** Ask the office something and get an answer back. */
	function ask(payload) {
		var body = new FormData();
		body.append('_ajax_nonce', NONCE);
		Object.keys(payload || {}).forEach(function (key) {
			body.append(key, payload[key]);
		});
		return fetch(AJAX, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		}).then(function (res) { return res.json(); });
	}

	/* ------------------------------------------------- the WordPress offset */

	/**
	 * How far in from the left edge our panel begins.
	 *
	 * The panel is pinned to the window so that scrolling WordPress's menu
	 * cannot drag the office around with it. Pinning needs a number for the
	 * left edge, and that number is the width of WordPress's menu — which
	 * is not a fixed number: WordPress folds it to icons when asked, hides
	 * it entirely on a phone, and different admin colour schemes pad it
	 * differently. So it is measured rather than assumed, and measured
	 * again whenever it changes.
	 *
	 * @return void
	 */
	/*
	 * How far down the window the office may begin.
	 *
	 * WordPress pins a toolbar to the top. It is 32px on a computer, 46px
	 * on a phone, and taller than either when a busy toolbar wraps onto a
	 * second line — so it is measured, never assumed. On a phone the toolbar
	 * is not pinned: it sits at the top of the page and scrolls away, so the
	 * office follows it up as it goes.
	 */
	function measureTop() {
		var bar  = document.getElementById('wpadminbar');
		var root = document.documentElement;
		var px   = 0;

		if (bar) {
			var rect    = bar.getBoundingClientRect();
			var pinned  = getComputedStyle(bar).position === 'fixed';
			var visible = rect.height > 0 && getComputedStyle(bar).display !== 'none';

			if (visible) {
				px = pinned ? Math.round(rect.height)
					: Math.round(Math.max(0, Math.min(rect.height, rect.bottom)));
			}
		}

		root.style.setProperty('--estat-top', px + 'px');
	}

	function measureOffset() {
		var menu = document.getElementById('adminmenuwrap') || document.getElementById('adminmenuback');
		var root = document.documentElement;
		var px = 0;

		if (menu) {
			var rect = menu.getBoundingClientRect();
			var shown = getComputedStyle(menu).visibility !== 'hidden' &&
				menu.getClientRects().length > 0;
			/* WordPress parks the menu off screen on a phone; a menu that
			   is parked must not push the office to the right. */
			px = (shown && rect.width > 4 && rect.right > 0) ? Math.round(rect.right) : 0;
		}

		root.style.setProperty('--estat-offset', px + 'px');
	}

	function watchOffset() {
		measureTop();
		measureOffset();

		var bar = document.getElementById('wpadminbar');
		if (bar && typeof ResizeObserver === 'function') {
			new ResizeObserver(measureTop).observe(bar);
		}

		/* On a phone the toolbar scrolls away, so the office moves up with
		   it. There is nothing else to listen to but the scroll. */
		window.addEventListener('scroll', measureTop, { passive: true });

		var menu = document.getElementById('adminmenuwrap');
		if (menu && typeof ResizeObserver === 'function') {
			new ResizeObserver(measureOffset).observe(menu);
		}
		window.addEventListener('resize', function () { measureTop(); measureOffset(); });
		window.addEventListener('orientationchange', function () { measureTop(); measureOffset(); });

		/* WordPress folds and unfolds the menu by adding a class to <body>,
		   and the button that does it gives no event of its own. */
		if (typeof MutationObserver === 'function') {
			new MutationObserver(measureOffset).observe(document.body, {
				attributes: true,
				attributeFilter: ['class']
			});
		}
		document.addEventListener('click', function (e) {
			if (e.target instanceof Element && e.target.closest('#collapse-button, #wp-admin-bar-menu-toggle')) {
				setTimeout(measureOffset, 60);
			}
		});
	}

	/* --------------------------------------------------------------- toasts */

	var TOASTS = null;

	function toast(message, kind, action) {
		if (!TOASTS) { TOASTS = $('#toasts'); }
		if (!TOASTS) { return; }

		var node = el('div', 'toast' + (kind ? ' toast--' + kind : ' toast--info'));

		var badge = el('span', 'toast__ico');
		badge.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#eos-i-' +
			(kind === 'err' ? 'alert' : kind === 'warn' ? 'alert' : 'check') + '"></use></svg>';
		node.appendChild(badge);

		var body = el('div', 'toast__b');
		body.appendChild(el('div', 'toast__t', message));
		node.appendChild(body);

		if (action && action.label) {
			var button = el('button', 'toast__undo', action.label);
			button.type = 'button';
			button.addEventListener('click', function () {
				action.run();
				dismiss(node);
			});
			node.appendChild(button);
		}

		var cross = el('button', 'toast__x');
		cross.type = 'button';
		cross.setAttribute('aria-label', 'Close');
		cross.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#eos-i-x"></use></svg>';
		cross.addEventListener('click', function () { dismiss(node); });
		node.appendChild(cross);

		TOASTS.appendChild(node);
		setTimeout(function () { dismiss(node); }, 4200);
	}

	function dismiss(node) {
		if (!node || node.classList.contains('is-out')) { return; }
		node.classList.add('is-out');
		setTimeout(function () { if (node.parentNode) { node.parentNode.removeChild(node); } }, 260);
	}

	/* ---------------------------------------------------------- the backdrop */

	function scrimOn() {
		var scrim = $('#scrim');
		if (scrim) {
			scrim.hidden = false;
			scrim.classList.add('is-on');
		}
		document.documentElement.style.overflow = 'hidden';
	}

	function scrimOff() {
		var scrim = $('#scrim');
		var busy = $('.drawer.is-on') || $('.cmdk.is-on');
		if (busy) { return; }
		if (scrim) {
			scrim.classList.remove('is-on');
			setTimeout(function () {
				if (!$('.drawer.is-on') && !$('.cmdk.is-on')) { scrim.hidden = true; }
			}, 320);
		}
		document.documentElement.style.overflow = '';
	}

	/* ---------------------------------------------------------------- drawer */

	var DRAWER_LABEL = {
		listing: 'Property', property: 'Property', project: 'Society / project',
		lead: 'Enquiry', enquiry: 'Enquiry', visit: 'Site visit',
		agent: 'Team member', member: 'Team member', deal: 'Deal', source: 'Lead source'
	};

	function openDrawer(kind, id, extra) {
		var drawer = $('#drawer');
		if (!drawer) { return; }

		var title = $('#dwTitle');
		var kicker = $('#dwKicker');
		var sub = $('#dwSub');
		var body = $('#dwBody');
		var foot = $('#dwFoot');

		if (kicker) { kicker.textContent = DRAWER_LABEL[kind] || 'Details'; }
		if (title) { title.textContent = word('loading', 'Loading…'); }
		if (sub) { sub.textContent = ''; }
		if (body) { body.innerHTML = '<div class="dw__load"><i class="spin"></i></div>'; }
		if (foot) { foot.innerHTML = ''; }

		drawer.classList.add('is-on');
		drawer.setAttribute('aria-hidden', 'false');
		scrimOn();

		ask({
			action: 'estat_os_drawer',
			os_action: 'drawer',
			kind: kind,
			id: id,
			ids: (extra && extra.ids) || '',
			name: (extra && extra.name) || ''
		}).then(function (res) {
			if (!res || !res.success) {
				if (title) { title.textContent = '—'; }
				if (body) { body.innerHTML = '<div class="empty"><div class="empty__t">' +
					esc((res && res.data && res.data.message) || word('failed', 'That did not work.')) + '</div></div>'; }
				return;
			}
			var data = res.data;
			if (title) { title.textContent = data.title || '—'; }
			if (sub) { sub.textContent = data.sub || ''; }
			if (body) { body.innerHTML = data.html || ''; }
			if (foot) { foot.innerHTML = data.foot || ''; }
			countUp(body);
		}).catch(function () {
			if (body) { body.innerHTML = '<div class="empty"><div class="empty__t">' +
				word('failed', 'That did not work. Try again.') + '</div></div>'; }
		});
	}

	function closeDrawer() {
		var drawer = $('#drawer');
		if (!drawer) { return; }
		drawer.classList.remove('is-on');
		drawer.setAttribute('aria-hidden', 'true');
		scrimOff();
	}

	/* ------------------------------------------------------- command palette */

	var CMDK_INDEX = -1;

	function paletteSource() {
		var out = (CFG.palette || []).map(function (row) {
			return { icon: row.icon, label: row.label, group: row.group || 'Go to', url: row.url };
		});
		(CFG.quick || []).forEach(function (row) {
			out.push({ icon: row.icon || 'plus', label: row.label, group: 'Add', url: row.url });
		});
		return out;
	}

	function drawPalette(rows) {
		var list = $('#cmdkList');
		if (!list) { return; }
		list.innerHTML = '';
		CMDK_INDEX = -1;

		if (!rows.length) {
			list.appendChild(el('div', 'cmdk__e', '<span class="mut">' + word('noResults', 'Nothing matched') + '</span>'));
			return;
		}

		var lastGroup = '';
		rows.forEach(function (row, i) {
			if (row.group && row.group !== lastGroup) {
				lastGroup = row.group;
				list.appendChild(el('div', 'cmdk__g', row.group));
			}
			var item = el('a', 'cmdk__i');
			item.href = row.url;
			item.setAttribute('data-i', String(i));
			item.innerHTML =
				'<svg class="ico" aria-hidden="true"><use href="#eos-i-' + iconName(row.icon) + '"></use></svg>' +
				'<span class="cmdk__l2">' + esc(row.label) + '</span>' +
				'<span class="cmdk__k">↵</span>';
			item.addEventListener('mouseenter', function () { highlight(i); });
			list.appendChild(item);
		});
		highlight(0);
	}

	function highlight(i) {
		var items = $$('#cmdkList .cmdk__i');
		items.forEach(function (node) { node.classList.remove('is-on'); });
		CMDK_INDEX = i;
		if (items[i]) {
			items[i].classList.add('is-on');
			items[i].scrollIntoView({ block: 'nearest' });
		}
	}

	function openPalette() {
		var box = $('#cmdk');
		if (!box) { return; }
		box.classList.add('is-on');
		scrimOn();
		RECORD_ROWS = [];
		var input = $('#cmdkIn');
		if (input) {
			input.value = '';
			setTimeout(function () { input.focus(); }, 40);
		}
		drawPalette(paletteSource());
	}

	function closePalette() {
		var box = $('#cmdk');
		if (!box) { return; }
		box.classList.remove('is-on');
		scrimOff();
	}

	/*
	 * The list the palette is showing: the screens first, then whatever the
	 * office found in its own records.
	 *
	 * Until now this list was screens only, and only screens could ever be
	 * searched from the top bar. The box above the list says "Search
	 * properties, leads, people…" and the office has an endpoint that finds
	 * exactly those — every property, every enquiry, every person, with the
	 * right page for each — but nothing in the interface ever called it. The
	 * search field blurred itself the moment it was clicked and handed the
	 * keyboard to this list, so typing reached `filterPalette()` and stopped
	 * there: a search box that could not search. The record results are
	 * drawn into the same list now, under their own heading, and a row opens
	 * the record the way a row of the table would.
	 */
	var RECORD_ROWS = [];
	var RECORD_TIMER = null;

	function paletteRows(term) {
		var rows = paletteSource();
		var show = rows;
		if (term) {
			show = rows.filter(function (row) {
				return row.label.toLowerCase().indexOf(term) > -1 ||
					(row.group || '').toLowerCase().indexOf(term) > -1;
			});
		}
		return show.concat(RECORD_ROWS);
	}

	function filterPalette(q) {
		var term = (q || '').trim().toLowerCase();
		drawPalette(paletteRows(term));
		searchRecords(q);
	}

	/** Ask the office for records matching what is being typed, a beat later. */
	function searchRecords(q) {
		clearTimeout(RECORD_TIMER);
		var term = (q || '').trim();
		if (term.length < 2) {
			RECORD_ROWS = [];
			return;
		}
		RECORD_TIMER = setTimeout(function () {
			ask({ action: 'estat_os_search', os_action: 'search', q: term }).then(function (res) {
				var items = (res && res.success && res.data && res.data.items) || [];
				RECORD_ROWS = items.map(function (row) {
					var what = row.kind === 'agent' ? 'users' : (row.kind === 'project' ? 'layers' : 'home');
					var label = String(row.title || '');
					if (row.sub) { label += ' · ' + row.sub; }
					return {
						icon: what,
						label: label,
						group: word('records', 'Properties, people and enquiries'),
						url: row.url
					};
				});
				// The palette may have been closed or re-typed while this was in
				// the air; drawing now would be drawing into a stale list.
				var input = $('#cmdkIn');
				var box = $('#cmdk');
				if (input && box && box.classList.contains('is-on') && input.value.trim() === term) {
					drawPalette(paletteRows(term.toLowerCase()));
				}
			});
		}, 260);
	}

	/* --------------------------------------------------------- top-bar search */

	function drawSearchResults(res) {
		var input = $('#searchIn');
		var box = $('#pop');
		if (!box) { return; }
		var items = (res && res.success && res.data && res.data.items) || [];

		box.innerHTML = '';
		if (!items.length) {
			box.appendChild(el('div', 'pop__e', '<span class="mut">' + word('noResults', 'Nothing matched') + '</span>'));
		} else {
			/*
			 * The words here came out of the database — a property title, a
			 * locality, a person's name — and the office types them by hand or
			 * imports them. Building the row as a string put them in the page
			 * as markup: a property called `<img src=x onerror=…>` ran the
			 * moment anybody searched for it. So they go in as text, and the
			 * only markup is the two elements made here.
			 */
			items.forEach(function (row) {
				var link = el('a', 'pop__i');
				link.href = row.url;
				var name = document.createElement('b');
				name.textContent = row.title || '';
				var where = document.createElement('span');
				where.className = 'mut';
				where.textContent = row.sub || (DRAWER_LABEL[row.kind] || '');
				link.appendChild(name);
				link.appendChild(where);
				box.appendChild(link);
			});
		}
		placePop(box, input);
	}

	/* --------------------------------------------------------------- popovers */

	function placePop(box, anchor) {
		if (!box || !anchor) { return; }
		var rect = anchor.getBoundingClientRect();
		box.style.top = Math.round(rect.bottom + 8) + 'px';
		var width = box.offsetWidth || 280;
		var left = Math.min(rect.left, window.innerWidth - width - 16);
		box.style.left = Math.max(12, left) + 'px';
		box.classList.add('is-on');
	}

	function closePop() {
		var box = $('#pop');
		if (box) { box.classList.remove('is-on'); }
		$$('[aria-expanded="true"]').forEach(function (node) { node.setAttribute('aria-expanded', 'false'); });
	}

	function drawNotes() {
		var box = $('#pop');
		var btn = $('#bellBtn');
		if (!box || !btn) { return; }
		var notes = CFG.notes || [];

		box.innerHTML = '';
		box.appendChild(el('div', 'pop__h', 'Notifications'));
		if (!notes.length) {
			box.appendChild(el('div', 'pop__e', '<span class="mut">Nothing is waiting.</span>'));
		} else {
			notes.slice(0, 8).forEach(function (note) {
				var row = el('a', 'pop__n' + (note.tone ? ' pop__n--' + note.tone : ''));
				row.href = note.url || '#';
				row.innerHTML =
					'<svg class="ico" aria-hidden="true"><use href="#eos-i-' + iconName(note.icon) + '"></use></svg>' +
					'<span class="pop__nb"><b>' + esc(note.title) + '</b>' +
					'<span class="mut">' + esc(note.msg) + '</span>' +
					'<span class="lbl">' + esc(note.when) + '</span></span>';
				box.appendChild(row);
			});
		}
		placePop(box, btn);
	}

	function drawMe() {
		var box = $('#pop');
		var btn = $('#meBtn');
		if (!box || !btn) { return; }

		box.innerHTML = '';
		box.appendChild(el('div', 'pop__h', 'You'));
		[
			{ label: 'Pocket (phone app)', icon: 'phone', url: (CFG.home || '').replace('page=' + (CFG.page || ''), 'page=estat-pocket') },
			{ label: 'Settings', icon: 'sliders', url: (CFG.home || '') + '&x=1' },
			{ label: 'Sign out', icon: 'exit', url: (CFG.home || '').replace('admin.php', '').replace('page=' + (CFG.page || ''), '') + 'wp-login.php?action=logout' }
		].forEach(function (row) {
			var link = el('a', 'pop__i');
			link.href = row.url;
			link.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#eos-i-' + iconName(row.icon) + '"></use></svg>' + esc(row.label);
			box.appendChild(link);
		});
		placePop(box, btn);
	}

	function drawQuickAdd() {
		var box = $('#pop');
		var btn = $('[data-quickadd]');
		if (!box || !btn) { return; }

		box.innerHTML = '';
		box.appendChild(el('div', 'pop__h', 'Quick add'));
		(CFG.quick || []).forEach(function (row) {
			var link = el('a', 'pop__i');
			link.href = row.url;
			link.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#eos-i-' +
				iconName(row.icon || 'plus') + '"></use></svg>' + esc(row.label);
			box.appendChild(link);
		});
		placePop(box, btn);
	}

	/* ------------------------------------------------------------ count-ups */

	function countUp(root) {
		$$('[data-count]', root).forEach(function (node) {
			if (node.dataset.counted === '1') { return; }
			node.dataset.counted = '1';

			var target = parseFloat(node.getAttribute('data-count')) || 0;
			if (target === 0) { node.textContent = '0'; return; }

			var start = performance.now();
			var span = Math.min(1100, 380 + Math.abs(target) * 6);

			function step(now) {
				var t = Math.min(1, (now - start) / span);
				var eased = 1 - Math.pow(1 - t, 3);
				node.textContent = Math.round(target * eased).toLocaleString();
				if (t < 1) { requestAnimationFrame(step); }
			}
			requestAnimationFrame(step);
		});
	}

	/* ------------------------------------------------------------ bulk bar */

	function selectedIds() {
		var ids = $$('.cb__i[data-row]:checked').map(function (node) { return node.getAttribute('data-row'); });
		$$('tr.is-picked[data-id]').forEach(function (row) {
			var id = row.getAttribute('data-id');
			if (id && ids.indexOf(id) === -1) { ids.push(id); }
		});
		return ids;
	}

	function bulkRefresh() {
		var bar = $('#bulkbar');
		var label = $('#bulkN');
		if (!bar || !label) { return; }
		var ids = selectedIds();
		label.textContent = ids.length + ' ' + word('selected', 'selected');
		bar.classList.toggle('is-on', ids.length > 0);
	}

	function syncHeadCheckbox() {
		var head = $('.cb__i[data-all]');
		if (!head) { return; }
		var rows = $$('.cb__i[data-row]');
		head.checked = rows.length > 0 && rows.every(function (node) { return node.checked; });
		head.indeterminate = !head.checked && rows.some(function (node) { return node.checked; });
	}

	/* ---------------------------------------------------------------- toggles */

	function flip(toggle, on) {
		if (!toggle) { return; }
		var state = (typeof on === 'boolean') ? on : toggle.getAttribute('aria-checked') !== 'true';
		toggle.setAttribute('aria-checked', state ? 'true' : 'false');
		toggle.classList.toggle('is-on', state);
		toggle.dispatchEvent(new CustomEvent('estat:toggle', { detail: { on: state }, bubbles: true }));
	}

	/* --------------------------------------------------------------- actions */

	var RUNNING = {};

	function run(name, payload, okMessage) {
		if (RUNNING[name]) { return; }
		RUNNING[name] = true;

		ask(payload).then(function (res) {
			RUNNING[name] = false;
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work. Try again.'), 'err');
				return;
			}
			toast(okMessage || (res.data && res.data.say) || word('saved', 'Saved'), 'ok');
			document.dispatchEvent(new CustomEvent('estat:done', { detail: { name: name, res: res } }));
		}).catch(function () {
			RUNNING[name] = false;
			toast(word('failed', 'That did not work. Try again.'), 'err');
		});
	}

	function confirmSay(node) {
		return node.getAttribute('data-confirm') || word('confirm', 'Are you sure?');
	}

	/** One switchboard for every button that carries data-act. */
	function handleAct(node) {
		var act = node.getAttribute('data-act');
		var id = node.getAttribute('data-id') || '0';
		var type = node.getAttribute('data-type') || '';

		switch (act) {
			case 'close-drawer':
				closeDrawer();
				return;

			case 'restore':
			case 'purge':
			case 'approve':
			case 'decline':
			case 'keep-both':
			case 'bin':
			case 'undo-import':
			case 'visit-done':
			case 'visit-no_show':
			case 'visit-cancelled':
			case 'visit-missed':
			case 'lead-advance':
				if (!window.confirm(confirmSay(node))) { return; }
				run(act + id, { action: 'estat_os_action', os_action: 'act', do: act, id: id }, '');
				return;

			case 'empty-bin':
				if (!window.confirm(confirmSay(node))) { return; }
				run('empty-bin', { action: 'estat_os_action', os_action: 'act', do: 'empty-bin' }, '');
				return;

			case 'save-agent':
				saveAgent(node);
				return;
			case 'save-project':
				saveProject(node);
				return;
			case 'compare-run': {
				var picked = $$('.cmp-pick:checked').map(function (box) { return box.value; });
				if (picked.length < 2) {
					toast('Tick at least two properties to compare.', 'err');
					return;
				}
				if (picked.length > 4) {
					toast('Four at a time is the most that stays readable.', 'err');
					return;
				}
				openDrawer('compare', 0, { ids: picked.join(',') });
				return;
			}

			case 'compare-pick':
				openDrawer('compare', 0, { ids: node.getAttribute('data-ids') || '' });
				return;

			case 'save-lead':
				saveLead(node);
				return;
			case 'save-visit':
				saveVisit(node);
				return;

			case 'blocks-save':
				saveBlocks(node);
				return;

			case 'tokens-save':
				saveTokens();
				return;

			case 'tokens-reset':
				$$('#setBody [data-token]').forEach(function (input) {
					input.value = input.getAttribute('data-default') || '';
					previewTokens();
				});
				toast('Defaults put back', 'ok');
				return;

			case 'duplicate':
				window.location.href = 'admin.php?page=estat-add-home&copy=' + id;
				return;

			case 'export-leads':
				window.location.href = 'admin-post.php?action=estat_export_csv&kind=leads';
				return;

			case 'scan-duplicates':
				run('scan', { action: 'estat_os_action', os_action: 'act', do: 'scan' }, '');
				return;

			case 'test-mail':
				run('test-mail', { action: 'estat_test_mail' }, 'Test email sent');
				return;

			case 'test-webhook':
				run('test-webhook', { action: 'estat_test_webhook' }, 'Test sent');
				return;

			case 'form-preview':
				toast('Preview opens on the website', 'ok');
				return;

			case 'new-project':
				openDrawer('project', 0);
				return;

			default:
				return;
		}
	}

	/*
	 * One way to save whatever the drawer is holding.
	 *
	 * Project, enquiry and visit all travel the same road — collect every
	 * named field in the drawer body, send it, say what happened. Keeping
	 * it in one place is what stops the three of them drifting apart and
	 * one of them quietly stopping working.
	 */
	function saveDrawer(button, what, needTitle) {
		var body = $('#dwBody');
		if (!body) { return; }

		var fields = {};
		$$('input[name], textarea[name], select[name]', body).forEach(function (el) {
			fields[el.name] = el.value;
		});

		if (needTitle && (!fields.title || !fields.title.trim())) {
			toast(word('need_title', 'Give the society or project a name first.'), 'err');
			return;
		}

		var id = button.getAttribute('data-id') || '0';
		button.disabled = true;

		var payload = { action: 'estat_os_save', os_action: 'save', what: what, id: id };
		Object.keys(fields).forEach(function (key) { payload['fields[' + key + ']'] = fields[key]; });

		ask(payload).then(function (res) {
			button.disabled = false;
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
				return;
			}
			toast((res.data && res.data.say) || word('saved', 'Saved'), 'ok');
			closeDrawer();
			window.location.reload();
		})['catch'](function () {
			button.disabled = false;
			toast(word('failed', 'That did not work.'), 'err');
		});
	}

	function saveProject(button) { saveDrawer(button, 'project', true); }
	function saveLead(button) { saveDrawer(button, 'lead', false); }
	function saveVisit(button) { saveDrawer(button, 'visit', false); }

	function saveAgent(button) {
		var body = $('#dwBody');
		if (!body) { return; }
		var fields = {};
		$$('input[name]', body).forEach(function (input) { fields[input.name] = input.value; });

		var payload = { action: 'estat_os_save', os_action: 'save', what: 'agent', id: button.getAttribute('data-id') || '0' };
		Object.keys(fields).forEach(function (key) { payload['fields[' + key + ']'] = fields[key]; });

		ask(payload).then(function (res) {
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
				return;
			}
			toast(word('saved', 'Saved'), 'ok');
			closeDrawer();
			setTimeout(function () { window.location.reload(); }, 500);
		});
	}

	function saveBlocks(button) {
		var wrap = $('#blocks');
		if (!wrap) { return; }
		var blocks = $$('.block', wrap).map(function (node) {
			return {
				id: node.getAttribute('data-block'),
				label: ($('.block__n', node) || {}).textContent || '',
				enabled: ($('.tgl', node) || {}).getAttribute('aria-checked') === 'true'
			};
		});

		var payload = {
			action: 'estat_os_save', os_action: 'save', what: 'blocks',
			type: button.getAttribute('data-type') || wrap.getAttribute('data-type') || 'listing'
		};
		blocks.forEach(function (block, i) {
			payload['blocks[' + i + '][id]'] = block.id;
			payload['blocks[' + i + '][label]'] = block.label;
			payload['blocks[' + i + '][enabled]'] = block.enabled ? '1' : '';
		});

		ask(payload).then(function (res) {
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
				return;
			}
			toast(word('saved', 'Saved'), 'ok');
		});
	}

	function saveTokens() {
		var inputs = $$('#setBody [data-token]');
		if (!inputs.length) { return; }
		var payload = { action: 'estat_os_save', os_action: 'save', what: 'tokens' };
		inputs.forEach(function (input) {
			payload['tokens[' + input.getAttribute('data-token') + ']'] = input.value;
		});
		ask(payload).then(function (res) {
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
				return;
			}
			toast('Colours saved', 'ok');
		});
	}

	function previewTokens() {
		var box = $('#tokPreview');
		if (!box) { return; }
		$$('#setBody [data-token]').forEach(function (input) {
			box.style.setProperty(input.getAttribute('data-token'), input.value);
		});
	}

	/* ------------------------------------------------------------ page blocks */

	function wireBlocks() {
		var wrap = $('#blocks');
		if (!wrap) { return; }
		var dragging = null;

		$$('.block', wrap).forEach(function (node) {
			node.draggable = true;
			node.addEventListener('dragstart', function () {
				dragging = node;
				node.classList.add('is-drag');
			});
			node.addEventListener('dragend', function () {
				node.classList.remove('is-drag');
				$$('.block', wrap).forEach(function (n) { n.classList.remove('is-over'); });
				dragging = null;
			});
			node.addEventListener('dragover', function (e) {
				e.preventDefault();
				if (dragging && dragging !== node) { node.classList.add('is-over'); }
			});
			node.addEventListener('dragleave', function () { node.classList.remove('is-over'); });
			node.addEventListener('drop', function (e) {
				e.preventDefault();
				node.classList.remove('is-over');
				if (!dragging || dragging === node) { return; }
				var all = $$('.block', wrap);
				var from = all.indexOf(dragging);
				var to = all.indexOf(node);
				if (from < to) { node.after(dragging); } else { node.before(dragging); }
			});
		});
	}

	/* -------------------------------------------------------------- pipeline */

	function wireKanban() {
		var board = $('#kb');
		if (!board) { return; }

		$$('.kcol', board).forEach(function (col) {
			col.addEventListener('dragover', function (e) {
				e.preventDefault();
				col.classList.add('is-over');
			});
			col.addEventListener('dragleave', function () { col.classList.remove('is-over'); });
			col.addEventListener('drop', function (e) {
				e.preventDefault();
				col.classList.remove('is-over');
				if (!window.EstatDrag) { return; }
				var card = document.getElementById('kcard-' + window.EstatDrag);
				var stage = col.getAttribute('data-col');
				if (!card || card.getAttribute('data-col') === stage) { return; }

				var from = card.getAttribute('data-col');
				card.setAttribute('data-col', stage);
				$('.kcol__list', col).appendChild(card);
				renumber();

				ask({
					action: 'estat_move_pipeline',
					lead_id: window.EstatDrag,
					status: stage
				}).then(function (res) {
					if (!res || !res.success) {
						card.setAttribute('data-col', from);
						toast(word('failed', 'That did not work. Try again.'), 'err');
						renumber();
						return;
					}
					toast(word('moved', 'Moved'), 'ok');
				});
			});
		});

		$$('.kcard', board).forEach(function (card) {
			card.draggable = true;
			card.id = card.id || ('kcard-' + card.getAttribute('data-id'));
			card.addEventListener('dragstart', function () {
				window.EstatDrag = card.getAttribute('data-id');
				card.classList.add('is-drag');
			});
			card.addEventListener('dragend', function () {
				card.classList.remove('is-drag');
				$$('.kcol', board).forEach(function (c) { c.classList.remove('is-over'); });
				window.EstatDrag = null;
			});
		});
	}

	function renumber() {
		$$('.kcol__num, .kcol__c').forEach(function () { /* counts refresh below */ });
		$$('.kcol').forEach(function (col) {
			var n = $$('.kcard', col).length;
			var badge = $('.chipc__n', col) || $('.kcol__n', col);
			if (badge) { badge.textContent = String(n); }
		});
	}

	/* --------------------------------------------------------------- gallery */

	function wireGallery() {
		var drop = $('#galDrop');
		var pick = $('#galPick');
		if (!drop || !pick) { return; }

		pick.addEventListener('click', function () {
			if (!window.wp || !window.wp.media) { return; }
			var frame = window.wp.media({ title: 'Choose files', multiple: true });
			frame.on('select', function () {
				frame.state().get('selection').map(function (att) {
					att = att.toJSON();
					appendTile(att);
				});
			});
			frame.open();
		});

		['dragenter', 'dragover'].forEach(function (name) {
			drop.addEventListener(name, function (e) {
				e.preventDefault();
				drop.classList.add('is-over');
			});
		});
		['dragleave', 'drop'].forEach(function (name) {
			drop.addEventListener(name, function (e) {
				e.preventDefault();
				drop.classList.remove('is-over');
			});
		});
		drop.addEventListener('drop', function (e) {
			var files = e.dataTransfer && e.dataTransfer.files;
			if (files) { uploadFiles(files); }
		});

		var input = $('#galUploads');
		if (input) {
			input.addEventListener('change', function () {
				uploadFiles(input.files);
				input.value = '';
			});
			drop.addEventListener('click', function () { input.click(); });
		}
	}

	/*
	 * Picking photographs for a record.
	 *
	 * The drawer's body is replaced every time it opens, so nothing inside
	 * it can hold a listener of its own. One listener on the document, keyed
	 * off the button's own attributes, is what makes it work every time.
	 */
	function thumbOf(att) {
		if (att.sizes && att.sizes.medium && att.sizes.medium.url) { return att.sizes.medium.url; }
		if (att.sizes && att.sizes.thumbnail && att.sizes.thumbnail.url) { return att.sizes.thumbnail.url; }
		return att.url;
	}

	function galGrid() { return $('#dwBody [data-gal-grid]'); }

	function addGalTile(grid, att) {
		var tile = document.createElement('span');
		tile.className = 'picktile';
		tile.setAttribute('data-tile', String(att.id));
		tile.style.backgroundImage = 'url(' + thumbOf(att) + ')';

		var x = document.createElement('button');
		x.type = 'button';
		x.className = 'picktile__x';
		x.innerHTML = '&times;';
		x.setAttribute('data-rm-pick', String(att.id));
		x.setAttribute('data-target', grid.getAttribute('data-target') || 'gallery');
		x.setAttribute('aria-label', 'Remove this photo');

		tile.appendChild(x);
		grid.appendChild(tile);
	}

	function pickMedia(btn) {
		if (!window.wp || !window.wp.media) {
			toast('The media library is not available on this screen.', 'err');
			return;
		}

		var multiple = btn.getAttribute('data-multiple') === '1';
		var target   = btn.getAttribute('data-target') || '';

		var frame = window.wp.media({
			title: multiple ? 'Add photos' : 'Choose a photo',
			multiple: multiple,
			library: { type: 'image' }
		});

		frame.on('select', function () {
			var sel = frame.state().get('selection').toJSON();
			if (!sel || !sel.length) { return; }

			var input = $('#dwBody [name="' + target + '"]');
			if (!input) { return; }

			if (multiple) {
				var have = input.value ? input.value.split(',').filter(function (v) { return v !== ''; }) : [];
				sel.forEach(function (att) {
					if (have.indexOf(String(att.id)) === -1) { have.push(String(att.id)); }
				});
				input.value = have.join(',');

				var grid = galGrid();
				if (grid) { sel.forEach(function (att) { addGalTile(grid, att); }); }
			} else {
				input.value = String(sel[0].id);
				var prev = $('#dwBody [data-cover-prev]');
				if (prev) {
					prev.style.backgroundImage = 'url(' + thumbOf(sel[0]) + ')';
					prev.classList.add('is-on');
				}
			}
		});

		frame.open();
	}

	function rmPick(btn) {
		var id  = btn.getAttribute('data-rm-pick');
		var inp = $('#dwBody [name="' + (btn.getAttribute('data-target') || 'gallery') + '"]');
		if (inp) {
			inp.value = inp.value.split(',').filter(function (v) { return v !== '' && v !== id; }).join(',');
		}
		var tile = btn.closest('.picktile');
		if (tile) { tile.remove(); }
	}

	function clearPick(btn) {
		var inp = $('#dwBody [name="' + (btn.getAttribute('data-target') || '') + '"]');
		if (inp) { inp.value = ''; }
		var prev = $('#dwBody [data-cover-prev]');
		if (prev) { prev.style.backgroundImage = ''; prev.classList.remove('is-on'); }
	}

	function uploadFiles(files) {
		Array.prototype.forEach.call(files, function (file) {
			var body = new FormData();
			body.append('action', 'estat_os_upload');
			body.append('os_action', 'upload');
			body.append('_ajax_nonce', NONCE);
			body.append('kind', (function () {
				var active = $('#galTabs .nav__b.is-on');
				return active ? (active.getAttribute('data-kind') || 'photo') : 'photo';
			})());
			body.append('file', file);

			fetch(AJAX, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (!res || !res.success) {
						toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
						return;
					}
					toast(word('uploaded', 'Added'), 'ok');
					appendTile({ id: res.data.id, url: res.data.url, title: file.name });
				});
		});
	}

	function appendTile(att) {
		var grid = $('#galGrid');
		if (!grid) { return; }
		var empty = $('.empty', grid);
		if (empty) { empty.remove(); }

		var tile = el('div', 'tile anim');
		tile.setAttribute('data-id', String(att.id || 0));
		// The picture's name can be edited in the media library, so it is a
		// word like any other: text, never markup.
		var media = el('div', 'tile__m');
		if (att.url) {
			media.style.backgroundImage = 'url("' + String(att.url).replace(/"/g, '%22') + '")';
		}
		var foot = el('div', 'tile__f');
		var label = el('span', 'tile__n');
		label.textContent = att.title || att.filename || '';
		foot.appendChild(label);
		tile.appendChild(media);
		tile.appendChild(foot);
		grid.insertBefore(tile, grid.firstChild);
	}

	function galleryCount() {
		var label = $('#galCount');
		if (!label) { return; }
		var n = $$('#galGrid .tile.is-picked').length;
		label.textContent = n ? (n + ' ' + word('selected', 'selected')) : '';
		var wrap = $('#galSelectAllWrap');
		if (wrap) { wrap.style.display = n ? '' : 'none'; }
	}

	/* ----------------------------------------------------------- form builder */

	function wireBuilder() {
		var canvas = $('#fbCanvas');
		var tools = $('#fbTools');
		if (!canvas || !tools) { return; }

		$$('[data-tool]', tools).forEach(function (tool) {
			tool.draggable = true;
			tool.addEventListener('dragstart', function (e) {
				e.dataTransfer.setData('text/plain', tool.getAttribute('data-tool'));
			});
			tool.addEventListener('click', function () {
				addField(tool.getAttribute('data-tool'));
			});
		});

		canvas.addEventListener('click', function (e) {
			var x = e.target instanceof Element ? e.target.closest('[data-fx]') : null;
			if (x) { return; }                                  // the ✕ has its own handler
			if (e.target instanceof Element && e.target.closest('[data-toggle]')) { return; }
			var box = e.target instanceof Element ? e.target.closest('.fbfield, .fld') : null;
			if (box && canvas.contains(box)) { openFieldSettings(box); }
		});
		canvas.addEventListener('dragover', function (e) { e.preventDefault(); canvas.classList.add('is-over'); });
		canvas.addEventListener('dragleave', function () { canvas.classList.remove('is-over'); });
		canvas.addEventListener('drop', function (e) {
			e.preventDefault();
			canvas.classList.remove('is-over');
			addField(e.dataTransfer.getData('text/plain'));
		});
	}

	/*
	 * A box added in this session is drawn exactly the way the screen draws one
	 * that was already on the form — same classes, same attributes. The two
	 * halves used to differ, and the difference was not cosmetic: the save read
	 * one shape and the screen wrote the other, so saving a form kept only the
	 * boxes added since the page opened and silently wrote away all the rest.
	 */
	function addField(kind) {
		var canvas = $('#fbCanvas');
		if (!canvas || !kind) { return; }
		var empty = $('#fbEmpty');
		if (empty) { empty.remove(); }

		var id = 'f' + Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36);
		var field = el('div', 'fbfield fld');
		field.setAttribute('data-f', id);
		field.setAttribute('data-kind', kind);
		field.setAttribute('data-type', kind);
		field.setAttribute('data-label', '');
		field.setAttribute('data-ph', '');
		field.setAttribute('data-req', '');
		field.setAttribute('data-options', '[]');
		field.innerHTML =
			'<div class="fbfield__h fld__h"><span class="fbfield__grip fld__g">&vellip;</span>' +
			'<b>' + esc(fieldWord(kind)) + '</b>' +
			'<button type="button" class="fbfield__x fld__x" data-fx="' + esc(id) + '" aria-label="Remove">&times;</button></div>' +
			'<div class="fbfield__b fld__b">' + fieldPreview(kind, fieldWord(kind)) + '</div>';
		canvas.appendChild(field);
		field.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
		field.animate(
			[{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }],
			{ duration: 260, easing: 'cubic-bezier(.2,.7,.3,1)' }
		);
		openFieldSettings(field);        // so the label can be typed straight away
	}

	/** The word the office uses for a kind of box. */
	function fieldWord(kind) {
		var words = { text: 'Text', email: 'Email', phone: 'Phone', select: 'Dropdown',
			checkbox: 'Checkbox', radio: 'Choice', textarea: 'Long text', date: 'Date',
			number: 'Number', url: 'Link', file: 'File' };
		return words[kind] || (kind.charAt(0).toUpperCase() + kind.slice(1).replace(/_/g, ' '));
	}

	function fieldPreview(kind, word) {
		var label = word || fieldWord(kind);
		switch (kind) {
			case 'textarea':
				return '<label class="field__lbl">' + label + '</label><textarea class="in" rows="3"></textarea>';
			case 'select':
			case 'radio':
			case 'checkbox':
				return '<label class="field__lbl">' + label + '</label>' +
					'<div class="in in--fake">Choices, one per line</div>';
			case 'file':
				return '<label class="field__lbl">' + label + '</label>' +
					'<div class="in in--fake">Choose a file</div>';
			case 'date':
				return '<label class="field__lbl">' + label + '</label><input class="in" type="date">';
			case 'number':
				return '<label class="field__lbl">' + label + '</label><input class="in" type="number">';
			default:
				return '<label class="field__lbl">' + label + '</label><input class="in" type="text">';
		}
	}

	/**
	 * The panel on the right: the box you clicked, and what it should say.
	 *
	 * The screen has always told the office "Click a field on the canvas to
	 * change it", and nothing was ever wired to that sentence: there was no way
	 * to rename a box, mark it required, or write its choices. Every form built
	 * in the office therefore kept the palette's own words as its labels, and a
	 * dropdown had nothing in it. The panel is drawn here and writes straight
	 * back onto the box, which is what the save reads.
	 *
	 * @param {Element} node The box.
	 * @return {void}
	 */
	function openFieldSettings(node) {
		var panel = $('#fbSettings');
		if (!panel || !node) { return; }

		$$('#fbCanvas .fbfield, #fbCanvas .fld').forEach(function (el) { el.classList.remove('is-on'); });
		node.classList.add('is-on');

		var kind = node.getAttribute('data-kind') || node.getAttribute('data-type') || 'text';
		var wantsChoices = (kind === 'select' || kind === 'radio' || kind === 'checkbox');
		var options = [];
		try { options = JSON.parse(node.getAttribute('data-options') || '[]'); } catch (e) { options = []; }

		panel.innerHTML =
			'<div style="display:grid;gap:var(--s3)">' +
				'<div><div class="lbl">What it asks</div>' +
				'<input class="in" id="fbSetLabel" value="' + esc(node.getAttribute('data-label') || '') + '" placeholder="' + esc(fieldWord(kind)) + '"></div>' +
				'<div><div class="lbl">The hint inside it</div>' +
				'<input class="in" id="fbSetPh" value="' + esc(node.getAttribute('data-ph') || '') + '" placeholder="Optional"></div>' +
				(wantsChoices ? '<div><div class="lbl">Choices, one per line</div>' +
					'<textarea class="in" id="fbSetOpts" rows="4">' + esc(options.join('\n')) + '</textarea></div>' : '') +
				'<label class="cbrow" style="height:36px"><i class="cb" id="fbSetReq" data-toggle="fb-required" ' +
					'role="checkbox" aria-checked="' +
					(node.getAttribute('data-req') === '1' ? 'true' : 'false') + '" tabindex="0"></i>' +
					'<span style="font-size:var(--fs-name)">Must be filled in</span></label>' +
				'<div class="mut" style="font-size:var(--fs-meta)">' + esc(fieldWord(kind)) + ' box</div>' +
			'</div>';

		var label = $('#fbSetLabel', panel);
		var ph = $('#fbSetPh', panel);
		var opts = $('#fbSetOpts', panel);
		var req = $('#fbSetReq', panel);

		function write() {
			var word = (label && label.value.trim()) || fieldWord(kind);
			node.setAttribute('data-label', label ? label.value.trim() : '');
			node.setAttribute('data-ph', ph ? ph.value : '');
			if (opts) {
				var lines = opts.value.split('\n').map(function (l) { return l.trim(); })
					.filter(function (l) { return l !== ''; });
				node.setAttribute('data-options', JSON.stringify(lines));
			}
			var head = $('b', node);
			if (head) { head.textContent = word; }
			var body = $('.fld__b', node) || $('.fbfield__b', node);
			if (body) { body.innerHTML = fieldPreview(kind, word); }
		}

		[label, ph, opts].forEach(function (input) {
			if (input) { input.addEventListener('input', write); }
		});
		if (req) {
			/*
			 * The tick answers through the page's own switch, not a private
			 * click handler: `flip()` sets the drawn state and announces it,
			 * and the box keeps the answer. Two handlers on one tick is how a
			 * tick ends up flipping itself back.
			 */
			req.addEventListener('estat:toggle', function (e) {
				node.setAttribute('data-req', e.detail && e.detail.on ? '1' : '');
				write();
			});
		}
		if (label) { label.focus(); }
	}

	function saveForm() {
		var canvas = $('#fbCanvas');
		var select = $('#fbFormId');
		if (!canvas) { return; }

		/*
		 * Everything the box knows, read off the box.
		 *
		 * This used to read four attributes and invent the rest — always
		 * `required: false`, never the placeholder, never the choices — so
		 * pressing Save quietly turned every required box optional and every
		 * dropdown into an empty one. A save may not lose what it does not
		 * understand; it now carries the lot through.
		 */
		var fields = $$('.fbfield, .fld', canvas).map(function (node, i) {
			var options = [];
			try {
				options = JSON.parse(node.getAttribute('data-options') || '[]');
			} catch (e) {
				options = [];
			}
			return {
				id: node.getAttribute('data-f') || ('f' + i),
				type: node.getAttribute('data-kind') || node.getAttribute('data-type') || 'text',
				label: node.getAttribute('data-label') || (($('b', node) || {}).textContent || ''),
				placeholder: node.getAttribute('data-ph') || '',
				required: node.getAttribute('data-req') === '1',
				options: options,
				width: '100',
				order: i
			};
		});

		ask({
			action: 'estat_os_save',
			os_action: 'save',
			what: 'form',
			id: select ? select.value : '0',
			definition: JSON.stringify({
				steps: [{ id: 's1', title: 'Your details', rows: [{ columns: [{ width: '100', fields: fields }] }] }]
			})
		}).then(function (res) {
			if (!res || !res.success) {
				toast((res && res.data && res.data.message) || word('failed', 'That did not work.'), 'err');
				return;
			}
			toast(word('saved', 'Saved'), 'ok');
		});
	}

	/* -------------------------------------------------------------- CSV wizard */

	function wireWizard() {
		var drop = $('#csvDrop');
		var file = $('#csvFile');
		if (!drop || !file) { return; }

		drop.addEventListener('click', function () { file.click(); });
		['dragenter', 'dragover'].forEach(function (name) {
			drop.addEventListener(name, function (e) { e.preventDefault(); drop.classList.add('is-over'); });
		});
		['dragleave', 'drop'].forEach(function (name) {
			drop.addEventListener(name, function (e) { e.preventDefault(); drop.classList.remove('is-over'); });
		});
		drop.addEventListener('drop', function (e) {
			if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
				file.files = e.dataTransfer.files;
				showFileName(e.dataTransfer.files[0].name);
			}
		});
		file.addEventListener('change', function () {
			if (file.files && file.files[0]) { showFileName(file.files[0].name); }
		});

		var next = $('#csvNext');
		if (next) {
			next.addEventListener('click', function () {
				gotoStep(2);
			});
		}
	}

	function showFileName(name) {
		var drop = $('#csvDrop');
		if (!drop) { return; }
		var label = $('.dropzone__t', drop);
		if (label) { label.textContent = name; }
		drop.classList.add('is-got');
		var next = $('#csvNext');
		if (next) { next.disabled = false; }
	}

	function gotoStep(n) {
		$$('#wiz .wiz__s').forEach(function (step) {
			step.classList.toggle('is-on', step.getAttribute('data-s') === String(n));
		});
		$$('#wiz .wiz__dot').forEach(function (dot) {
			var at = parseInt(dot.getAttribute('data-s'), 10);
			dot.classList.toggle('is-on', at === n);
			dot.classList.toggle('is-done', at < n);
		});
	}

	/* ----------------------------------------------------------- duplicates */

	function wireDuplicates() {
		var prev = $('#dupPrev');
		var next = $('#dupNext');
		if (!prev && !next) { return; }
		var idx = parseInt(($('#dupIdx') || {}).textContent || '1', 10);

		function go(step) {
			var box = $('#dupBody');
			if (!box) { return; }
			box.style.opacity = '.35';
			toast(word('working', 'Working…'), '');
			window.location.search = window.location.search
				.replace(/([?&])i=\d+/, '$1i=' + Math.max(1, idx + step));
		}
		if (prev) { prev.addEventListener('click', function () { go(-1); }); }
		if (next) { next.addEventListener('click', function () { go(1); }); }
	}

	/* ------------------------------------------------------------ reveal on */

	function wireReveal() {
		if (!('IntersectionObserver' in window)) {
			$$('.anim').forEach(function (n) { n.style.opacity = '1'; });
			return;
		}
		var seen = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.style.animationPlayState = 'running';
					seen.unobserve(entry.target);
				}
			});
		}, { rootMargin: '0px 0px -40px 0px' });
		$$('.anim').forEach(function (node) { seen.observe(node); });
	}

	/* ------------------------------------------------------------------ boot */

	function boot() {
		/* Pin the panel to the right of WordPress's menu before anything
		   else is measured, so no card is ever laid out at the wrong width. */
		watchOffset();

		countUp(document);
		wireReveal();

		/* The office's own navigation can be narrowed to icons. The choice is
		   remembered in this browser, so it stays as you left it. */
		var app = $('#app');
		var railToggle = $('#railToggle');
		if (app && railToggle) {
			if (localStorage.getItem('estatRail') === 'thin') {
				app.classList.add('rail-collapsed');
				railToggle.setAttribute('aria-pressed', 'true');
			}
			railToggle.addEventListener('click', function () {
				var thin = app.classList.toggle('rail-collapsed');
				railToggle.setAttribute('aria-pressed', thin ? 'true' : 'false');
				localStorage.setItem('estatRail', thin ? 'thin' : 'wide');
			});
		}
		wireKanban();
		wireGallery();
		wireBuilder();
		wireWizard();
		wireBlocks();
		wireDuplicates();
		wireLogoPick();
		previewTokens();

		/* One listener for the whole page — cheaper, and nothing is missed. */
		document.addEventListener('click', function (e) {
			var node = e.target;
			if (!(node instanceof Element)) { return; }

			/*
			 * Two shapes of switch. `.tgl` is the drawn switch; `.cb` with a
			 * data-toggle is the square tick-box, and it was never wired to
			 * anything at all: pressing it did nothing, so the "price on
			 * request" answer was never carried into the form and the hidden
			 * field stayed empty.
			 */
			var toggle = node.closest('.tgl') || node.closest('[data-toggle]');
			if (toggle) { flip(toggle); return; }

			var pick = node.closest('[data-pick]');
			if (pick) { e.preventDefault(); pickMedia(pick); return; }

			var rmPickBtn = node.closest('[data-rm-pick]');
			if (rmPickBtn) { e.preventDefault(); rmPick(rmPickBtn); return; }

			var clearBtn = node.closest('[data-clear-pick]');
			if (clearBtn) { e.preventDefault(); clearPick(clearBtn); return; }

			var act = node.closest('[data-act]');
			if (act) { e.preventDefault(); handleAct(act); return; }

			var drawer = node.closest('[data-drawer]');
			if (drawer) {
				e.preventDefault();
				openDrawer(drawer.getAttribute('data-drawer'), drawer.getAttribute('data-id') || '0');
				return;
			}

			var bulk = node.closest('[data-bulk]');
			if (bulk) { handleBulk(bulk.getAttribute('data-bulk')); return; }

			if (node.closest('#dwClose') || node.closest('#scrim')) { closeDrawer(); closePalette(); closePop(); return; }
			if (node.closest('[data-quickadd]')) { e.preventDefault(); drawQuickAdd(); return; }
			if (node.closest('#bellBtn')) { e.preventDefault(); drawNotes(); return; }
			if (node.closest('#meBtn')) { e.preventDefault(); drawMe(); return; }
			if (node.closest('#bulkX')) { e.preventDefault(); clearBulk(); return; }

			/* A row in a table opens that record. */
			var row = node.closest('tr[data-id]');
			if (row && !node.closest('.rowacts') && !node.closest('.cb') && !node.closest('a')) {
				var kind = row.closest('#enqRows') ? 'lead'
					: row.closest('#propRows') ? 'listing'
					: row.closest('#visitList') ? 'visit'
					: row.closest('#reqList') ? 'request'
					: row.closest('#ahDupBody') ? 'listing'
					: null;
				if (kind) { openDrawer(kind, row.getAttribute('data-id')); }
				return;
			}

			/*
			 * The row tick-box on the properties table.
			 *
			 * It is an <i>, not an <input>, and nothing listened for it — so
			 * ticking rows never showed the bulk bar and "the office could
			 * not select anything". It now behaves exactly like the real
			 * checkboxes: the row is picked, the bar counts it.
			 */
			var rowcb = node.closest('[data-rowcb]');
			if (rowcb) {
				var on = rowcb.getAttribute('aria-checked') !== 'true';
				rowcb.setAttribute('aria-checked', on ? 'true' : 'false');
				rowcb.classList.toggle('is-on', on);
				var tr = rowcb.closest('tr');
				if (tr) { tr.classList.toggle('is-picked', on); }
				bulkRefresh();
				syncHeadCheckbox();
				return;
			}

			/* A tile in the gallery is picked, not opened. */
			var tile = node.closest('#galGrid .tile');
			if (tile) { tile.classList.toggle('is-picked'); galleryCount(); return; }

			if (!node.closest('#pop')) { closePop(); }
		});

		/* Checkboxes drive the bulk bar. */
		document.addEventListener('change', function (e) {
			var node = e.target;
			if (!(node instanceof Element)) { return; }
			if (node.matches('.cb__i[data-row]')) { bulkRefresh(); syncHeadCheckbox(); }
			if (node.matches('.cb__i[data-all]')) {
				$$('.cb__i[data-row]').forEach(function (box) { box.checked = node.checked; });
				bulkRefresh();
			}
			if (node.matches('[data-token]')) { previewTokens(); }
		});

		/* Segmented controls inside a screen. */
		document.addEventListener('click', function (e) {
			var node = e.target instanceof Element ? e.target : null;
			if (!node) { return; }

			/*
			 * The worklist's own tick. The stylesheet has promised this for
			 * a while — `.wl__i.is-done .wl__tick` is filled green — and no
			 * code ever added the class, so the circle invited a press and
			 * did nothing. It marks the row done on screen; the work itself
			 * (the call, the listing) is untouched.
			 */
			var tick = node.closest('.wl__tick');
			if (tick) {
				e.preventDefault();
				var item = tick.closest('.wl__i');
				if (item) { item.classList.toggle('is-done'); }
				tick.setAttribute('aria-checked', item && item.classList.contains('is-done') ? 'true' : 'false');
				return;
			}

			/*
			 * A segmented control. Two spellings exist in the screens: the
			 * button itself carries `data-seg`, or it carries `data-seg-v`
			 * inside a group that carries `data-seg`. Only the first was
			 * wired, so the Worklist tabs (All / Overdue / Leads / Listings)
			 * on Today lit up nothing and filtered nothing.
			 */
			var seg = node.closest('[data-seg]');
			var value = null;
			if (seg && seg.tagName === 'BUTTON') {
				value = seg.getAttribute('data-seg');
			} else if (seg) {
				var btn = node.closest('[data-seg-v]');
				if (btn) { value = btn.getAttribute('data-seg-v'); seg = btn; }
			}
			if (null === value) { return; }

			e.preventDefault();
			var group = seg.parentNode;
			if (group) { $$('[data-seg], [data-seg-v]', group).forEach(function (b) { b.classList.remove('is-on'); }); }
			seg.classList.add('is-on');
			document.dispatchEvent(new CustomEvent('estat:seg', { detail: { value: value } }));
			filterWorklist(value);
		});

	/**
	 * Show only the worklist rows the chosen tab is about.
	 *
	 * The rows carry data-kind ("followup", "leads", "listings") and the tab
	 * says which one it wants. Nothing used either, so the four tabs were
	 * decoration.
	 */
	function filterWorklist(value) {
		var list = $('#worklist');
		if (!list) { return; }
		var rows = $$('.wl__i', list);
		if (!rows.length) { return; }
		var shown = 0;
		rows.forEach(function (row) {
			var kind = row.getAttribute('data-kind') || '';
			var on = (value === 'all' || value === kind);
			row.hidden = !on;
			if (on) { shown++; }
		});
		var note = $('#wlEmpty');
		if (!shown) {
			if (!note) {
				note = el('p', 'mut');
				note.id = 'wlEmpty';
				note.setAttribute('style', 'padding:var(--s4)');
				note.textContent = word('noResults', 'Nothing matched');
				list.appendChild(note);
			}
			note.hidden = false;
		} else if (note) {
			note.hidden = true;
		}
	}

		/* Keyboard: ⌘K opens the palette, Escape closes everything. */
		document.addEventListener('keydown', function (e) {
			if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
				e.preventDefault();
				$('#cmdk') && $('#cmdk').classList.contains('is-on') ? closePalette() : openPalette();
				return;
			}
			if (e.key === 'Escape') {
				closePalette();
				closeDrawer();
				closePop();
				return;
			}
			/*
			 * A tick-box drawn as an <i> has to answer the keyboard too: the
			 * screen tells the browser it is a checkbox (role, tabindex) and
			 * a checkbox that only answers a mouse is a lie.
			 */
			if (e.key === 'Enter' || e.key === ' ') {
				var kb = e.target instanceof Element ? (e.target.closest('[data-toggle]') || e.target.closest('[data-rowcb]')) : null;
				if (kb) {
					e.preventDefault();
					kb.click();
					return;
				}
			}
			var box = $('#cmdk');
			if (box && box.classList.contains('is-on')) {
				var items = $$('#cmdkList .cmdk__i');
				if (e.key === 'ArrowDown') { e.preventDefault(); highlight(Math.min(items.length - 1, CMDK_INDEX + 1)); }
				if (e.key === 'ArrowUp') { e.preventDefault(); highlight(Math.max(0, CMDK_INDEX - 1)); }
				if (e.key === 'Enter') {
					var at = items[CMDK_INDEX];
					if (at) { window.location.href = at.href; }
				}
			}
		});

		/* The palette filters as you type. */
		var cmdkIn = $('#cmdkIn');
		if (cmdkIn) {
			cmdkIn.addEventListener('input', function () { filterPalette(cmdkIn.value); });
		}

		/* The top-bar search asks the office. */
		var searchIn = $('#searchIn');
		if (searchIn) {
			var timer = null;
			searchIn.addEventListener('focus', function () { openPalette(); searchIn.blur(); });
			searchIn.addEventListener('input', function () {
				clearTimeout(timer);
				var q = searchIn.value;
				timer = setTimeout(function () {
					if (q.trim().length < 2) { closePop(); return; }
					ask({ action: 'estat_os_search', os_action: 'search', q: q }).then(drawSearchResults);
				}, 260);
			});
		}

		/* The form builder saves from its own button. */
		var fbSave = $('#fbSave');
		if (fbSave) { fbSave.addEventListener('click', function (e) { e.preventDefault(); saveForm(); }); }

		/* Removing a field in the builder. */
		document.addEventListener('click', function (e) {
			var x = e.target instanceof Element ? e.target.closest('[data-fx]') : null;
			if (!x) { return; }
			e.preventDefault();
			var field = document.querySelector('[data-f="' + x.getAttribute('data-fx') + '"]');
			if (field) {
				field.animate([{ opacity: 1 }, { opacity: 0, transform: 'scale(.97)' }], { duration: 200 })
					.onfinish = function () { field.remove(); };
			}
		});

		/* Gallery: select all. */
		var all = $('#galSelectAll');
		if (all) {
			all.addEventListener('click', function (e) {
				e.preventDefault();
				$$('#galGrid .tile').forEach(function (t) { t.classList.add('is-picked'); });
				galleryCount();
			});
		}

		/* Whatever was just done: take the row away, or leave a way back. */
		document.addEventListener('estat:done', function (e) {
			var detail = e.detail || {};
			var id = (detail.res && detail.res.data && detail.res.data.id) || null;

			if (['restore', 'purge', 'bin', 'approve', 'decline', 'keep-both'].indexOf(detail.name.replace(/\d+$/, '')) > -1 && id) {
				var row = document.querySelector('[data-row="' + id + '"]');
				var wrap = row ? row.closest('tr, .card, .wl__i, .diff') : null;
				if (wrap) {
					wrap.animate(
						[{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(18px)' }],
						{ duration: 240, easing: 'ease-in' }
					).onfinish = function () {
						wrap.remove();
						bulkRefresh();
						if (!$$('tbody tr').length) { setTimeout(function () { window.location.reload(); }, 700); }
					};
				}
			}
			if (detail.name === 'empty-bin') { setTimeout(function () { window.location.reload(); }, 700); }
			if (detail.name === 'undo-import') { setTimeout(function () { window.location.reload(); }, 700); }
		});

		/* Switches: dim a block that is switched off, and carry the answer
		   into the form so it is saved even if nothing else here runs. */
		document.addEventListener('estat:toggle', function (e) {
			var toggle = e.target;

			if (toggle.getAttribute('data-toggle') === 'block-on') {
				var block = toggle.closest('.block');
				if (block) { block.classList.toggle('is-placeholder', !e.detail.on); }
				return;
			}

			var name = toggle.getAttribute('data-toggle');
			var carry = document.getElementById('tgl_' + name);
			if (!carry && name) {
				// The plain forms put the answer in a hidden field that
				// carries the switch's own name. Looking only for the
				// `tgl_` prefix meant the Add a home screen's "price on
				// request" tick was pressed, drawn as on, and posted as
				// empty.
				carry = document.querySelector('input[type="hidden"][name="' + name + '"]');
			}
			if (carry) { carry.value = e.detail.on ? '1' : '0'; }
		});

		/* Fade the canvas in, so arriving never looks like a jump. */
		var canvas = $('#canvas');
		if (canvas) { canvas.classList.add('is-in'); }

		bulkRefresh();
		syncHeadCheckbox();
		wireAddHome();
	}

	function handleBulk(what) {
		var ids = selectedIds();
		if (!ids.length) { return; }
		if (!window.confirm(what === 'delete'
			? 'Delete these for good? They can never be brought back.'
			: 'Put these back where they were?')) { return; }

		var done = 0;
		ids.forEach(function (id) {
			ask({
				action: 'estat_os_action',
				os_action: 'act',
				do: what === 'delete' ? 'purge' : 'restore',
				id: id
			}).then(function () {
				done++;
				if (done === ids.length) {
					toast(what === 'delete' ? word('deleted', 'Removed') : word('restored', 'Put back'), 'ok');
					setTimeout(function () { window.location.reload(); }, 700);
				}
			});
		});
	}

	/*
	 * Settings -> The office -> Office logo.
	 *
	 * WordPress's own media window does the picking; this only listens for the
	 * answer. `wp.media` is loaded on this screen (wp_enqueue_media), but a
	 * missing one must not leave a dead button: with no media frame the
	 * button says so rather than doing nothing.
	 */
	function wireLogoPick() {
		var pick = document.getElementById('estatLogoPick');
		if (!pick) { return; }
		var input = pick.querySelector('[data-logo-input]');
		var img = pick.querySelector('.logopick__img');
		var choose = pick.querySelector('[data-logo-choose]');
		var clear = pick.querySelector('[data-logo-clear]');

		if (choose) {
			choose.addEventListener('click', function () {
				if (!window.wp || !window.wp.media) {
					toast(word('failed', 'That did not work. Try again.'), 'bad');
					return;
				}
				var frame = window.wp.media({
					title: choose.textContent,
					library: { type: 'image' },
					button: { text: word('saved', 'Use this picture') },
					multiple: false
				});
				frame.on('select', function () {
					var file = frame.state().get('selection').first().toJSON();
					if (!file || !file.id) { return; }
					if (input) { input.value = file.id; }
					var url = (file.sizes && file.sizes.medium && file.sizes.medium.url) || file.url;
					if (img && url) { img.src = url; }
					toast(word('saved', 'Saved'), 'ok');
				});
				frame.open();
			});
		}

		if (clear) {
			clear.addEventListener('click', function () {
				if (input) { input.value = '0'; }
				var own = img ? img.getAttribute('data-default') : '';
				if (img && own) { img.src = own; }
				toast(word('saved', 'Saved'), 'ok');
			});
		}
	}

	/*
	 * Add a home — the parts of the screen that had no ear.
	 *
	 * The screen offers a highlight list with an "Add line" button, chips for
	 * the usual highlights, a drop zone for photographs, a cover picker and a
	 * live completeness meter. None of them were wired to anything: pressing
	 * Add line did nothing, so the screen sat at one empty box for ever, and
	 * the meter kept saying 0%.
	 */
	function wireAddHome() {
		var form = $('#estat-add-home-form');
		var list = $('#ahHl');
		if (!form || !list) { return; }

		function row(value) {
			var box = el('div', 'hlrow');
			var input = el('input', 'in hlrow__in');
			input.setAttribute('name', 'highlights[]');
			input.setAttribute('placeholder', 'Add a highlight');
			input.value = value || '';
			var x = el('button', 'iconbtn hlrow__x');
			x.setAttribute('type', 'button');
			x.setAttribute('data-rmhl', '');
			x.setAttribute('aria-label', 'Remove this line');
			x.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#eos-i-x"></use></svg>';
			box.appendChild(el('i', 'hlrow__dot'));
			box.appendChild(input);
			box.appendChild(x);
			return box;
		}

		function add(value) {
			var empty = null;
			$$('.hlrow__in', list).forEach(function (inp) {
				if (!empty && inp.value.trim() === '') { empty = inp; }
			});
			if (value && empty) {
				empty.value = value;
				empty.focus();
				completeness();
				return;
			}
			if (value && $$('.hlrow__in', list).some(function (inp) { return inp.value.trim() === value; })) {
				return; // Already on the list.
			}
			var box = row(value);
			list.appendChild(box);
			var inp = $('.hlrow__in', box);
			if (inp) { inp.focus(); }
			completeness();
		}

		var addBtn = $('#ahAddHl');
		if (addBtn) {
			addBtn.addEventListener('click', function (e) { e.preventDefault(); add(''); });
		}

		form.addEventListener('click', function (e) {
			var target = e.target instanceof Element ? e.target : null;
			if (!target) { return; }

			var chip = target.closest('[data-hl-chip]');
			if (chip) {
				e.preventDefault();
				add(chip.getAttribute('data-hl-chip') || '');
				return;
			}

			var x = target.closest('[data-rmhl]');
			if (x) {
				e.preventDefault();
				var box = x.closest('.hlrow');
				if (box) { box.remove(); }
				// Never leave the list without a place to type.
				if (!$$('.hlrow', list).length) { add(''); }
				completeness();
				return;
			}

			var rm = target.closest('[data-rmgid]');
			if (rm) {
				e.preventDefault();
				var picked = rm.closest('.picked');
				var gid = picked ? picked.getAttribute('data-gid') : '';
				var field = $('#ahGallery');
				if (field && gid) {
					field.value = field.value.split(',').filter(function (v) { return v && v !== gid; }).join(',');
				}
				if (picked) { picked.remove(); }
			}
		});

		/* The rate works itself out from the two boxes it comes from. */
		function rate() {
			var out = $('#ahRate');
			if (!out) { return; }
			var price = parseFloat(($('#ahPrice') || {}).value || '');
			var area = parseFloat(($('#ahArea') || {}).value || '');
			out.value = (price > 0 && area > 0) ? Math.round(price / area) + ' per ' + (($('[name="area_unit"]') || {}).value || 'sqft') : '';
		}

		/* The meter counts what the checklist counts. */
		function completeness() {
			var filled = function (sel) { var n = $(sel, form); return !!(n && String(n.value || '').trim() !== ''); };
			var lines = $$('.hlrow__in', list).filter(function (inp) { return inp.value.trim() !== ''; }).length;
			var onRequest = $('#ahOnRequest');
			var checks = {
				title: filled('#ahTitle'),
				price: filled('#ahPrice') || (onRequest && onRequest.value === '1'),
				cover_id: !!parseInt(($('#ahCoverId') || {}).value || '0', 10),
				locality: filled('[name="locality"]'),
				highlights: lines >= 3
			};
			var done = 0;
			Object.keys(checks).forEach(function (key) {
				if (checks[key]) { done++; }
				var row = $('[data-check="' + key + '"]', form.parentNode || document);
				if (row) {
					row.style.color = checks[key] ? 'var(--pos-deep)' : 'var(--ink-3)';
					var dot = row.firstElementChild;
					if (dot) {
						dot.setAttribute('style', 'width:16px;height:16px;border-radius:99px;display:grid;place-items:center;flex:none;' +
							(checks[key] ? 'background:var(--pos);color:#fff' : 'box-shadow:inset 0 0 0 1.5px var(--line-strong)'));
						dot.innerHTML = checks[key] ? '<span style="width:9px;height:9px;display:block"><svg class="ico" aria-hidden="true"><use href="#eos-i-check"></use></svg></span>' : '';
					}
				}
			});
			var pct = Math.round((done / 5) * 100);
			var pctEl = $('#ahPct');
			if (pctEl) { pctEl.textContent = pct + '%'; }
			var bar = $('#ahBar');
			if (bar) {
				bar.style.width = pct + '%';
				bar.classList.toggle('is-hi', pct >= 80);
				bar.classList.toggle('is-mid', pct >= 40 && pct < 80);
				bar.classList.toggle('is-lo', pct < 40);
			}
		}

		if ($('#ahRate')) {
			['#ahPrice', '#ahArea'].forEach(function (sel) {
				var node = $(sel, form);
				if (node) { node.addEventListener('input', rate); }
			});
			var unit = $('[name="area_unit"]', form);
			if (unit) { unit.addEventListener('change', rate); }
			rate();
		}

		form.addEventListener('input', completeness);
		form.addEventListener('change', completeness);
		form.addEventListener('estat:toggle', function () { setTimeout(completeness, 0); });

		/* Cover, and the photographs dropped on the zone. */
		function pickCover() {
			if (!window.wp || !window.wp.media) { toast(word('failed', 'That did not work. Try again.'), 'bad'); return; }
			var frame = window.wp.media({ title: 'Choose the cover', library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				var file = frame.state().get('selection').first().toJSON();
				if (!file || !file.id) { return; }
				var field = $('#ahCoverId');
				if (field) { field.value = file.id; }
				var box = $('#ahCover');
				if (box) {
					var url = (file.sizes && file.sizes.medium && file.sizes.medium.url) || file.url;
					box.innerHTML = '';
					var thumb = document.createElement('img');
					thumb.src = url;
					thumb.alt = '';
					thumb.style.cssText = 'width:100%;height:100%;object-fit:cover';
					box.appendChild(thumb);
				}
				completeness();
				toast(word('saved', 'Saved'), 'ok');
			});
			frame.open();
		}

		var coverBtn = $('#ahCoverPick');
		if (coverBtn) { coverBtn.addEventListener('click', function (e) { e.preventDefault(); pickCover(); }); }

		var zone = $('[data-dropzone]', form);
		if (zone) {
			zone.addEventListener('click', function (e) {
				e.preventDefault();
				if (!window.wp || !window.wp.media) { toast(word('failed', 'That did not work. Try again.'), 'bad'); return; }
				var frame = window.wp.media({ title: 'Choose photographs', library: { type: 'image' }, multiple: true });
				frame.on('select', function () {
					var grid = $('#ahMedia');
					var field = $('#ahGallery');
					var ids = field && field.value ? field.value.split(',') : [];
					frame.state().get('selection').forEach(function (att) {
						var file = att.toJSON();
						if (!file || !file.id) { return; }
						if (ids.indexOf(String(file.id)) === -1) { ids.push(String(file.id)); }
						if (!grid) { return; }
						var url = (file.sizes && file.sizes.thumbnail && file.sizes.thumbnail.url) || file.url;
						var tile = el('span', 'picked', '<img src="' + url + '" alt="" style="width:100%;height:100%;object-fit:cover">' +
							'<button type="button" class="iconbtn" data-rmgid aria-label="Remove this photograph" style="position:absolute;top:2px;right:2px;width:20px;height:20px;background:var(--panel)">×</button>');
						tile.setAttribute('data-gid', String(file.id));
						tile.setAttribute('style', 'position:relative;display:block;aspect-ratio:1;border-radius:var(--r-sm);overflow:hidden;background:var(--inset)');
						grid.appendChild(tile);
					});
					if (field) { field.value = ids.join(','); }
					completeness();
					toast(word('uploaded', 'Added'), 'ok');
				});
				frame.open();
			});
		}

		completeness();
	}

	function clearBulk() {
		$$('.cb__i[data-row]').forEach(function (box) { box.checked = false; });
		bulkRefresh();
		syncHeadCheckbox();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

	window.EstatOS = { toast: toast, openDrawer: openDrawer, closeDrawer: closeDrawer, logoPick: wireLogoPick };
})();
