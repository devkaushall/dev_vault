<?php
/**
 * The visual form builder.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Forms\FieldTypes;
use EstatOS\Forms\Forms;
use EstatOS\Forms\Templates;
use EstatOS\Forms\Submissions;

defined( 'ABSPATH' ) || exit;

/**
 * A focused layout builder: rows, columns and fields, with responsive widths.
 * The definition is edited as structured data by the JavaScript builder and
 * posted back as JSON, which the server re-validates from scratch.
 */
final class FormsScreen {

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_forms' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage forms.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$edit_id = isset( $_GET['edit'] ) ? absint( wp_unslash( $_GET['edit'] ) ) : 0;
		$view    = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : '';
		// phpcs:enable

		if ( 'submissions' === $view ) {
			self::submissions( $edit_id );
			return;
		}
		if ( $edit_id > 0 ) {
			self::builder( $edit_id );
			return;
		}
		self::form_list();
	}

	/**
	 * The list of forms.
	 *
	 * @return void
	 */
	private static function form_list(): void {
		$forms = Forms::all( 100 );

		Partials::card_open(
			__( 'Start with a ready-made form', 'estat-os' ),
			__( 'Pick the one closest to what you need. It arrives complete and working — you can change anything afterwards.', 'estat-os' )
		);
		?>
		<div class="estat-template-grid">
			<?php foreach ( Templates::all() as $key => $template ) : ?>
				<form method="post" class="estat-template-card" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>">
					<?php wp_nonce_field( 'estat_create_form', 'estat_nonce' ); ?>
					<input type="hidden" name="estat_action" value="create_form" />
					<input type="hidden" name="template" value="<?php echo esc_attr( (string) $key ); ?>" />
					<input type="hidden" name="name" value="<?php echo esc_attr( (string) $template['label'] ); ?>" />

					<span class="estat-template-icon" aria-hidden="true"><?php echo esc_html( (string) $template['icon'] ); ?></span>
					<span class="estat-template-name"><?php echo esc_html( (string) $template['label'] ); ?></span>
					<span class="estat-template-desc"><?php echo esc_html( (string) $template['description'] ); ?></span>
					<span class="estat-template-best"><?php echo esc_html( (string) $template['best_for'] ); ?></span>

					<button type="submit" class="button button-primary"><?php esc_html_e( 'Use this one', 'estat-os' ); ?></button>
				</form>
			<?php endforeach; ?>
		</div>
		<?php
		Partials::card_close();

		Partials::card_open( __( 'Or start from scratch', 'estat-os' ), __( 'Only if none of the ready-made ones fit.', 'estat-os' ) );
		?>
		<form method="post" class="estat-form-admin estat-inline-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>">
			<?php wp_nonce_field( 'estat_create_form', 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="create_form" />
			<label class="screen-reader-text" for="estat-new-form"><?php esc_html_e( 'Form name', 'estat-os' ); ?></label>
			<input type="text" id="estat-new-form" name="name" required placeholder="<?php esc_attr_e( 'For example: Property enquiry', 'estat-os' ); ?>" />
			<button type="submit" class="button"><?php esc_html_e( 'Create an empty form', 'estat-os' ); ?></button>
		</form>
		<?php
		Partials::card_close();

		if ( ! $forms ) {
			Partials::empty_state(
				array(
					'icon'       => '📝',
					'title'      => __( 'No forms yet', 'estat-os' ),
					'message'    => __( 'A form is how someone on your website reaches your office. Every message it receives becomes an enquiry automatically.', 'estat-os' ),
					'reassuring' => true,
					'steps'      => array(
						__( 'Create a form using the button above.', 'estat-os' ),
						__( 'Drag the boxes you want people to fill in.', 'estat-os' ),
						__( 'Copy its shortcode onto any page of your website.', 'estat-os' ),
					),
				)
			);
			return;
		}

		Partials::card_open( __( 'Your forms', 'estat-os' ) );
		echo '<table class="widefat estat-table"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Form', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'How to place it', 'estat-os' ) . '</th>';
		echo '<th scope="col"><span class="screen-reader-text">' . esc_html__( 'Actions', 'estat-os' ) . '</span></th>';
		echo '</tr></thead><tbody>';
		foreach ( $forms as $form ) {
			$id = (int) $form['id'];
			echo '<tr>';
			echo '<th scope="row" data-label="' . esc_attr__( 'Form', 'estat-os' ) . '"><a href="' . esc_url( admin_url( 'admin.php?page=estat-forms&edit=' . $id ) ) . '">' . esc_html( (string) $form['name'] ) . '</a></th>';
			echo '<td data-label="' . esc_attr__( 'How to place it', 'estat-os' ) . '">';
			echo '<code class="estat-copyable">[estat_form id="' . esc_html( (string) $id ) . '"]</code><br />';
			echo '<span class="estat-muted">' . esc_html__( 'Or use the "Estat Form" block in Elementor and pick this form.', 'estat-os' ) . '</span>';
			echo '</td>';
			echo '<td data-label="' . esc_attr__( 'Responses', 'estat-os' ) . '">';
			echo '<a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=estat-forms&edit=' . $id ) ) . '">' . esc_html__( 'Design', 'estat-os' ) . '</a> ';
			echo '<a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=estat-forms&view=submissions&edit=' . $id ) ) . '">' . esc_html__( 'Responses', 'estat-os' ) . '</a> ';
			echo '<form method="post" class="estat-inline-form" action="' . esc_url( admin_url( 'admin.php?page=estat-forms' ) ) . '">';
			wp_nonce_field( 'estat_duplicate_form_' . $id, 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="duplicate_form" /><input type="hidden" name="form_id" value="' . esc_attr( (string) $id ) . '" />';
			echo '<button type="submit" class="button button-small">' . esc_html__( 'Duplicate', 'estat-os' ) . '</button>';
			echo '</form>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		Partials::card_close();
	}

	/**
	 * The builder for one form.
	 *
	 * @param int $form_id Form ID.
	 * @return void
	 */
	private static function builder( int $form_id ): void {
		$form = Forms::get( $form_id );
		if ( ! $form ) {
			Partials::empty_state(
				array(
					'icon'    => '🔍',
					'title'   => __( 'That form could not be found', 'estat-os' ),
					'message' => __( 'It may have been deleted, or the link you followed may be out of date.', 'estat-os' ),
					'action'  => admin_url( 'admin.php?page=estat-forms' ),
					'label'   => __( 'Back to forms', 'estat-os' ),
				)
			);
			return;
		}
		$settings = $form['settings'];
		?>
		<form method="post" class="estat-form-admin estat-builder-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms&edit=' . $form_id ) ); ?>">
			<?php wp_nonce_field( 'estat_save_form_' . $form_id, 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="save_form" />
			<input type="hidden" name="form_id" value="<?php echo esc_attr( (string) $form_id ); ?>" />
			<input type="hidden" name="definition" id="estat-definition" value="<?php echo esc_attr( (string) wp_json_encode( $form['definition'] ) ); ?>" />

			<div class="estat-builder-layout">
				<div class="estat-builder-main">
					<?php Partials::card_open( __( 'Design your form', 'estat-os' ), __( 'Drag a field into a row. Set how wide each field should be on a computer, tablet and phone.', 'estat-os' ) ); ?>
					<div class="estat-builder" id="estat-builder"
						data-definition="<?php echo esc_attr( (string) wp_json_encode( $form['definition'] ) ); ?>">
						<p class="description"><?php esc_html_e( 'Loading the designer…', 'estat-os' ); ?></p>
					</div>
					<noscript>
						<p class="notice notice-warning"><?php esc_html_e( 'The visual designer needs JavaScript. Your existing form still works exactly as it is.', 'estat-os' ); ?></p>
					</noscript>
					<?php Partials::card_close(); ?>

					<?php
					Partials::card_open(
						__( 'Add a field', 'estat-os' ),
						__( 'The boxes an estate office needs most are here. Everything else is under "More field types".', 'estat-os' )
					);

					$all_types = FieldTypes::all();
					?>
					<div class="estat-field-palette" id="estat-field-palette">
						<div class="estat-palette-common">
							<?php foreach ( FieldTypes::common() as $type ) : ?>
								<?php if ( ! isset( $all_types[ $type ] ) ) : ?>
									<?php continue; ?>
								<?php endif; ?>
								<button
									type="button"
									class="button estat-add-field estat-palette-chip"
									data-type="<?php echo esc_attr( $type ); ?>"
									data-label="<?php echo esc_attr( (string) $all_types[ $type ]['label'] ); ?>"
								>
									<?php echo esc_html( (string) $all_types[ $type ]['label'] ); ?>
								</button>
							<?php endforeach; ?>
						</div>

						<details class="estat-palette-more">
							<summary><?php esc_html_e( 'More field types', 'estat-os' ); ?></summary>

							<label class="screen-reader-text" for="estat-palette-search"><?php esc_html_e( 'Search field types', 'estat-os' ); ?></label>
							<input
								type="search"
								id="estat-palette-search"
								class="estat-palette-search"
								placeholder="<?php esc_attr_e( 'Search for a box, for example "date"', 'estat-os' ); ?>"
							/>

							<p class="estat-palette-empty" hidden><?php esc_html_e( 'No field type matches that. Try a shorter word.', 'estat-os' ); ?></p>

							<?php foreach ( FieldTypes::groups() as $group ) : ?>
								<div class="estat-palette-group">
									<p class="estat-palette-group-title"><?php echo esc_html( (string) $group['label'] ); ?></p>
									<div class="estat-palette-group-items">
										<?php foreach ( (array) $group['types'] as $type ) : ?>
											<?php if ( ! isset( $all_types[ $type ] ) ) : ?>
												<?php continue; ?>
											<?php endif; ?>
											<button
												type="button"
												class="button estat-add-field estat-palette-chip"
												data-type="<?php echo esc_attr( $type ); ?>"
												data-label="<?php echo esc_attr( (string) $all_types[ $type ]['label'] ); ?>"
											>
												<?php echo esc_html( (string) $all_types[ $type ]['label'] ); ?>
											</button>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endforeach; ?>
						</details>
					</div>
					<?php Partials::card_close(); ?>
				</div>

				<aside class="estat-builder-side">
					<?php
					Partials::card_open(
						__( 'What visitors will see', 'estat-os' ),
						__( 'This updates as you change the form.', 'estat-os' )
					);
					?>
					<div class="estat-form-preview" id="estat-form-preview" aria-live="polite">
						<p class="description"><?php esc_html_e( 'Loading the preview…', 'estat-os' ); ?></p>
					</div>
					<?php Partials::card_close(); ?>

					<?php Partials::card_open( __( 'Form details', 'estat-os' ) ); ?>
					<?php
					Partials::field( array( 'name' => 'name', 'label' => __( 'Form name', 'estat-os' ), 'value' => (string) $form['name'], 'required' => true, 'help' => __( 'Only your office sees this name.', 'estat-os' ) ) );
					Partials::field( array( 'name' => 'settings[submit_label]', 'label' => __( 'Button text', 'estat-os' ), 'value' => (string) $settings['submit_label'], 'example' => __( 'Send enquiry', 'estat-os' ) ) );
					Partials::field( array( 'name' => 'settings[success_message]', 'type' => 'textarea', 'rows' => 2, 'label' => __( 'Message after sending', 'estat-os' ), 'value' => (string) $settings['success_message'] ) );
					Partials::field( array( 'name' => 'settings[error_message]', 'type' => 'textarea', 'rows' => 2, 'label' => __( 'Message if something is wrong', 'estat-os' ), 'value' => (string) $settings['error_message'] ) );
					Partials::field( array( 'name' => 'settings[redirect_url]', 'type' => 'url', 'label' => __( 'Send them to a page afterwards', 'estat-os' ), 'value' => (string) $settings['redirect_url'], 'help' => __( 'Optional. Leave empty to show the message instead.', 'estat-os' ) ) );
					?>
					<?php Partials::card_close(); ?>

					<?php Partials::card_open( __( 'What happens with the information', 'estat-os' ), __( 'Changing the look of the form never changes these settings.', 'estat-os' ) ); ?>
					<?php
					Partials::field( array( 'name' => 'settings[create_lead]', 'type' => 'checkbox', 'label' => __( 'Create an enquiry', 'estat-os' ), 'checkbox_label' => __( 'Add every submission to the Enquiries inbox', 'estat-os' ), 'value' => (bool) $settings['create_lead'] ) );
					Partials::field( array( 'name' => 'settings[store_submission]', 'type' => 'checkbox', 'label' => __( 'Keep a copy', 'estat-os' ), 'checkbox_label' => __( 'Store the full response so you can look at it later', 'estat-os' ), 'value' => (bool) $settings['store_submission'] ) );
					Partials::field( array( 'name' => 'settings[notify]', 'type' => 'checkbox', 'label' => __( 'Email the office', 'estat-os' ), 'checkbox_label' => __( 'Send an email whenever this form is used', 'estat-os' ), 'value' => (bool) $settings['notify'] ) );
					Partials::field( array( 'name' => 'settings[notify_email]', 'type' => 'email', 'label' => __( 'Send those emails to', 'estat-os' ), 'value' => (string) $settings['notify_email'], 'help' => __( 'Leave empty to use the address in Office Settings.', 'estat-os' ) ) );
					Partials::field( array( 'name' => 'settings[require_consent]', 'type' => 'checkbox', 'label' => __( 'Ask for consent', 'estat-os' ), 'checkbox_label' => __( 'Require a tick box before the form can be sent', 'estat-os' ), 'value' => (bool) $settings['require_consent'] ) );
					Partials::field( array( 'name' => 'settings[rate_limit]', 'type' => 'number', 'label' => __( 'Maximum submissions per visitor', 'estat-os' ), 'value' => (int) $settings['rate_limit'], 'min' => 1, 'max' => 60, 'help' => __( 'Within ten minutes. This stops automated spam.', 'estat-os' ) ) );
					?>
					<?php Partials::card_close(); ?>

					<?php Partials::card_open( __( 'Where to use this form', 'estat-os' ) ); ?>
					<p><?php esc_html_e( 'Paste this into any page or post:', 'estat-os' ); ?></p>
					<code class="estat-copyable">[estat_form id="<?php echo esc_html( (string) $form_id ); ?>"]</code>
					<p class="description"><?php esc_html_e( 'In Elementor, add the "Estat Form" block and choose this form. The same form can be used on as many pages as you like.', 'estat-os' ); ?></p>
					<?php Partials::card_close(); ?>

					<div class="estat-form-actions-admin estat-sticky-actions">
						<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Save form', 'estat-os' ); ?></button>
						<a class="button-link" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>"><?php esc_html_e( 'Back to forms', 'estat-os' ); ?></a>
					</div>
				</aside>
			</div>
		</form>

		<form method="post" class="estat-delete-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>">
			<?php wp_nonce_field( 'estat_delete_form_' . $form_id, 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="delete_form" />
			<input type="hidden" name="form_id" value="<?php echo esc_attr( (string) $form_id ); ?>" />
			<details class="estat-danger">
				<summary><?php esc_html_e( 'Delete this form', 'estat-os' ); ?></summary>
				<p><?php esc_html_e( 'The responses you have already received are kept. Only the form itself is removed.', 'estat-os' ); ?></p>
				<label for="estat-confirm-delete"><?php esc_html_e( 'Type DELETE in capital letters to confirm.', 'estat-os' ); ?></label>
				<input type="text" id="estat-confirm-delete" name="confirm" autocomplete="off" />
				<button type="submit" class="button estat-danger-button"><?php esc_html_e( 'Delete form', 'estat-os' ); ?></button>
			</details>
		</form>
		<?php
	}

	/**
	 * Responses received through a form.
	 *
	 * @param int $form_id Form ID.
	 * @return void
	 */
	private static function submissions( int $form_id ): void {
		if ( ! current_user_can( 'estat_view_submissions' ) ) {
			wp_die( esc_html__( 'You do not have permission to see form responses.', 'estat-os' ) );
		}
		$results = Submissions::query( array( 'form_id' => $form_id, 'per_page' => 30 ) );

		Partials::card_open( __( 'Responses', 'estat-os' ) );
		if ( ! $results['items'] ) {
			Partials::empty_state(
				array(
					'icon'       => '📬',
					'title'      => __( 'No responses yet', 'estat-os' ),
					'message'    => __( 'Nobody has filled in this form so far. Check that it is placed on a page people actually visit.', 'estat-os' ),
					'reassuring' => true,
					'action'     => admin_url( 'admin.php?page=estat-forms' ),
					'label'      => __( 'Back to forms', 'estat-os' ),
				)
			);
			Partials::card_close();
			return;
		}
		echo '<table class="widefat estat-table"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'When', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'What they sent', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Enquiry', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $results['items'] as $row ) {
			$payload = json_decode( (string) $row['payload'], true );
			$payload = is_array( $payload ) ? $payload : array();
			echo '<tr>';
			echo '<td data-label="' . esc_attr__( 'When', 'estat-os' ) . '">' . esc_html( get_date_from_gmt( (string) $row['created_at'] ) ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'What they sent', 'estat-os' ) . '"><dl class="estat-payload">';
			foreach ( $payload as $key => $value ) {
				echo '<dt>' . esc_html( (string) $key ) . '</dt><dd>' . esc_html( is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value ) . '</dd>';
			}
			echo '</dl></td>';
			echo '<td data-label="' . esc_attr__( 'Enquiry', 'estat-os' ) . '">';
			if ( (int) $row['lead_id'] > 0 ) {
				echo '<a href="' . esc_url( admin_url( 'admin.php?page=estat-enquiries#lead-' . (int) $row['lead_id'] ) ) . '">' . esc_html__( 'Open enquiry', 'estat-os' ) . '</a>';
			} else {
				echo '<span class="estat-muted">—</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		Partials::card_close();
	}
}
