<?php
/**
 * Reusable public HTML components shared by shortcodes and Elementor widgets.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Agents;
use EstatOS\Data\Highlights;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Search\Query;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * One implementation of every visible component. Elementor widgets and
 * shortcodes both call these, so the two can never drift apart.
 */
final class Components {

	/**
	 * A property card.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function card( int $listing_id ): string {
		$data = Listings::to_array( $listing_id, false );
		if ( ! $data ) {
			return '';
		}
		// Never show a visitor a property the office has not published. Staff
		// who may edit listings still see it, so previewing a draft works.
		if ( 'publish' !== (string) $data['status'] && ! current_user_can( 'estat_manage_listings' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );

		$locality = ! empty( $data['locality'] ) ? (string) $data['locality'][0] : '';
		$beds     = (int) $data['bedrooms'];

		ob_start();
		?>
		<article class="estat-card" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>">
			<a class="estat-card-media" href="<?php echo esc_url( (string) $data['url'] ); ?>">
				<?php if ( '' !== (string) $data['cover'] ) : ?>
					<img src="<?php echo esc_url( (string) $data['cover'] ); ?>" alt="<?php echo esc_attr( (string) $data['title'] ); ?>" loading="lazy" decoding="async" />
				<?php else : ?>
					<span class="estat-card-noimage" aria-hidden="true"></span>
				<?php endif; ?>
				<?php if ( ! empty( $data['featured'] ) ) : ?>
					<span class="estat-badge estat-badge-featured"><?php esc_html_e( 'Featured', 'estat-os' ); ?></span>
				<?php endif; ?>
				<span class="estat-badge estat-badge-offer"><?php echo esc_html( Vocabulary::label( 'offers', (string) $data['offer'] ) ); ?></span>
			</a>
			<div class="estat-card-body">
				<h3 class="estat-card-title"><a href="<?php echo esc_url( (string) $data['url'] ); ?>"><?php echo esc_html( (string) $data['title'] ); ?></a></h3>
				<?php if ( '' !== $locality ) : ?>
					<p class="estat-card-locality"><?php echo esc_html( $locality ); ?></p>
				<?php endif; ?>
				<p class="estat-card-price"><?php echo esc_html( (string) $data['price_display'] ); ?></p>
				<?php
				$chips = Highlights::for_card( $listing_id );
				if ( $chips ) :
					?>
					<ul class="estat-chips">
						<?php foreach ( $chips as $chip ) : ?>
							<li class="estat-chip">
								<?php if ( '' !== (string) $chip['icon'] ) : ?>
									<span class="estat-chip-icon" aria-hidden="true"><?php echo esc_html( (string) $chip['icon'] ); ?></span>
								<?php endif; ?>
								<span class="estat-chip-text"><?php echo esc_html( (string) $chip['label'] ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<ul class="estat-card-facts">
					<li><?php echo esc_html( Vocabulary::label( 'property_types', (string) $data['property_type'] ) ); ?></li>
				</ul>
				<div class="estat-card-actions">
					<?php if ( Settings::get( 'enable_favorites' ) ) : ?>
						<button type="button" class="estat-fav" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<span class="screen-reader-text"><?php esc_html_e( 'Save this property', 'estat-os' ); ?></span>
							<span aria-hidden="true">♥</span>
						</button>
					<?php endif; ?>
					<?php if ( Settings::get( 'enable_compare' ) ) : ?>
						<button type="button" class="estat-compare" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>" aria-pressed="false">
							<?php esc_html_e( 'Compare', 'estat-os' ); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>
		</article>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A property directory with pagination.
	 *
	 * @param array<string,mixed> $args Search filters.
	 * @return string
	 */
	public static function directory( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		$results = Query::search( $args );

		ob_start();
		echo '<div class="estat-directory">';
		if ( empty( $results['ids'] ) ) {
			echo '<p class="estat-empty">' . esc_html__( 'No properties match what you are looking for. Try widening your search.', 'estat-os' ) . '</p>';
		} else {
			echo '<div class="estat-grid">';
			foreach ( $results['ids'] as $id ) {
				echo self::card( (int) $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
			echo self::pagination( (int) $results['page'], (int) $results['pages'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * Pagination links.
	 *
	 * @param int $page  Current page.
	 * @param int $pages Total pages.
	 * @return string
	 */
	public static function pagination( int $page, int $pages ): string {
		if ( $pages < 2 ) {
			return '';
		}
		$links = paginate_links(
			array(
				'base'      => add_query_arg( 'estat_page', '%#%' ),
				'format'    => '',
				'current'   => max( 1, $page ),
				'total'     => $pages,
				'type'      => 'array',
				'prev_text' => __( 'Previous', 'estat-os' ),
				'next_text' => __( 'Next', 'estat-os' ),
			)
		);
		if ( ! is_array( $links ) ) {
			return '';
		}
		$out = '<nav class="estat-pagination" aria-label="' . esc_attr__( 'Property pages', 'estat-os' ) . '"><ul>';
		foreach ( $links as $link ) {
			$out .= '<li>' . wp_kses_post( $link ) . '</li>';
		}
		return $out . '</ul></nav>';
	}

	/**
	 * The search form.
	 *
	 * @param array<string,mixed> $args Options: action.
	 * @return string
	 */
	public static function search_form( array $args = array() ): string {
		wp_enqueue_style( 'estat-public' );
		$action = isset( $args['action'] ) ? esc_url( (string) $args['action'] ) : esc_url( (string) get_post_type_archive_link( PostTypes::LISTING ) );

		$localities = get_terms(
			array(
				'taxonomy'   => Taxonomies::LOCALITY,
				'hide_empty' => true,
				'number'     => 200,
			)
		);
		$localities = is_wp_error( $localities ) ? array() : $localities;

		$get = static function ( string $key ): string {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return isset( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) ) : '';
		};

		ob_start();
		?>
		<form class="estat-search" method="get" action="<?php echo esc_url( $action ); ?>" role="search">
			<div class="estat-search-row">
				<div class="estat-search-field">
					<label for="estat-q"><?php esc_html_e( 'What are you looking for?', 'estat-os' ); ?></label>
					<input type="search" id="estat-q" name="keyword" value="<?php echo esc_attr( $get( 'keyword' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 3 BHK near the metro', 'estat-os' ); ?>" />
				</div>
				<div class="estat-search-field">
					<label for="estat-offer"><?php esc_html_e( 'Buy or rent', 'estat-os' ); ?></label>
					<select id="estat-offer" name="offer">
						<option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option>
						<?php foreach ( Vocabulary::offers() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'offer' ), $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="estat-search-field">
					<label for="estat-type"><?php esc_html_e( 'Property type', 'estat-os' ); ?></label>
					<select id="estat-type" name="property_type[]">
						<option value=""><?php esc_html_e( 'Any', 'estat-os' ); ?></option>
						<?php foreach ( Vocabulary::property_types() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $get( 'property_type' ), $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<?php if ( $localities ) : ?>
					<div class="estat-search-field">
						<label for="estat-locality"><?php esc_html_e( 'Locality', 'estat-os' ); ?></label>
						<select id="estat-locality" name="locality[]">
							<option value=""><?php esc_html_e( 'Anywhere', 'estat-os' ); ?></option>
							<?php foreach ( $localities as $term ) : ?>
								<option value="<?php echo esc_attr( (string) $term->term_id ); ?>" <?php selected( $get( 'locality' ), (string) $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<div class="estat-search-field">
					<label for="estat-beds"><?php esc_html_e( 'Bedrooms (minimum)', 'estat-os' ); ?></label>
					<input type="number" id="estat-beds" name="bedrooms_min" min="0" max="20" value="<?php echo esc_attr( $get( 'bedrooms_min' ) ); ?>" />
				</div>
				<div class="estat-search-field">
					<label for="estat-price-max"><?php esc_html_e( 'Budget up to', 'estat-os' ); ?></label>
					<input type="number" id="estat-price-max" name="price_max" min="0" step="1000" value="<?php echo esc_attr( $get( 'price_max' ) ); ?>" placeholder="<?php esc_attr_e( 'For example: 9000000', 'estat-os' ); ?>" />
				</div>
			</div>
			<div class="estat-search-actions">
				<button type="submit" class="estat-btn estat-btn-primary"><?php esc_html_e( 'Search properties', 'estat-os' ); ?></button>
			</div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * A map, using OpenStreetMap by default so no paid key is needed.
	 *
	 * @param float  $lat   Latitude.
	 * @param float  $lng   Longitude.
	 * @param string $label Marker label.
	 * @return string
	 */
	public static function map( float $lat, float $lng, string $label = '' ): string {
		$provider = (string) Settings::get( 'map_provider', 'osm' );
		if ( 'none' === $provider || ( 0.0 === $lat && 0.0 === $lng ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );

		if ( 'google' === $provider && '' !== (string) Settings::get( 'google_maps_key' ) ) {
			$src = add_query_arg(
				array(
					'key' => rawurlencode( (string) Settings::get( 'google_maps_key' ) ),
					'q'   => rawurlencode( $lat . ',' . $lng ),
				),
				'https://www.google.com/maps/embed/v1/place'
			);
		} else {
			$delta = 0.01;
			$bbox  = ( $lng - $delta ) . ',' . ( $lat - $delta ) . ',' . ( $lng + $delta ) . ',' . ( $lat + $delta );
			$src   = add_query_arg(
				array( 'bbox' => $bbox, 'layer' => 'mapnik', 'marker' => $lat . ',' . $lng ),
				'https://www.openstreetmap.org/export/embed.html'
			);
		}

		return '<div class="estat-map"><iframe title="' . esc_attr( '' !== $label ? $label : __( 'Map', 'estat-os' ) ) . '" src="' . esc_url( $src ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>';
	}

	/**
	 * The team directory.
	 *
	 * @param int $limit Maximum team members.
	 * @return string
	 */
	public static function agents( int $limit = 12 ): string {
		wp_enqueue_style( 'estat-public' );
		$ids = get_posts(
			array(
				'post_type'      => PostTypes::AGENT,
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, min( 100, $limit ) ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		if ( ! $ids ) {
			return '<p class="estat-empty">' . esc_html__( 'No team members have been added yet.', 'estat-os' ) . '</p>';
		}
		ob_start();
		echo '<div class="estat-grid estat-team">';
		foreach ( $ids as $id ) {
			$agent = Agents::to_array( (int) $id );
			?>
			<article class="estat-agent">
				<?php if ( '' !== (string) $agent['photo'] ) : ?>
					<img class="estat-agent-photo" src="<?php echo esc_url( (string) $agent['photo'] ); ?>" alt="<?php echo esc_attr( (string) $agent['name'] ); ?>" loading="lazy" />
				<?php endif; ?>
				<h3><a href="<?php echo esc_url( (string) $agent['url'] ); ?>"><?php echo esc_html( (string) $agent['name'] ); ?></a></h3>
				<?php if ( '' !== (string) $agent['role'] ) : ?>
					<p class="estat-agent-role"><?php echo esc_html( (string) $agent['role'] ); ?></p>
				<?php endif; ?>
				<p class="estat-agent-contact">
					<?php if ( '' !== (string) $agent['phone'] ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $agent['phone'] ) ); ?>"><?php esc_html_e( 'Call', 'estat-os' ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== (string) $agent['whatsapp'] ) : ?>
						<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', (string) $agent['whatsapp'] ) ); ?>" rel="nofollow noopener"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
					<?php endif; ?>
				</p>
			</article>
			<?php
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * The comparison tray.
	 *
	 * @return string
	 */
	public static function compare(): string {
		if ( ! Settings::get( 'enable_compare' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		return '<section class="estat-compare-panel" id="estat-compare-panel" aria-live="polite">'
			. '<h2>' . esc_html__( 'Compare properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-empty">' . esc_html__( 'Choose "Compare" on a few properties and they will appear here side by side.', 'estat-os' ) . '</p>'
			. '<div class="estat-compare-table"></div></section>';
	}

	/**
	 * The saved-properties list.
	 *
	 * @return string
	 */
	public static function favorites(): string {
		if ( ! Settings::get( 'enable_favorites' ) ) {
			return '';
		}
		wp_enqueue_style( 'estat-public' );
		wp_enqueue_script( 'estat-public' );
		return '<section class="estat-favorites" id="estat-favorites" aria-live="polite">'
			. '<h2>' . esc_html__( 'Your saved properties', 'estat-os' ) . '</h2>'
			. '<p class="estat-empty">' . esc_html__( 'Nothing saved yet. Tap the heart on any property to keep it here.', 'estat-os' ) . '</p>'
			. '<div class="estat-grid"></div></section>';
	}
}
