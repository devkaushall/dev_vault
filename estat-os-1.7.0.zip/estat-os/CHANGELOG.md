# Changelog

All notable changes to Estat.OS are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project follows
[semantic versioning](https://semver.org/).

## [1.7.0] — 2026-09-09

The second and third parts of the "make it easier" work: a shorter property
screen, and real help on every screen.

### Changed

* **The property editor no longer shows 45 fields at once.** The ones an office
  fills in for nearly every property — what it is, the price, the size,
  bedrooms, bathrooms, the locality, photos, the description, who is handling
  it — now come first. The rest sit in five fold-away groups with plain
  headings: rent and deposit, more details about the building, floor plans and
  video, exact address and map, and builder and reference details. **Not one
  field was removed**; a test pins all 45 by name and fails if any goes missing.
* **A group that already holds information opens by itself**, so reopening a
  listing never makes it look as though details were lost.
* **Locality moved up** to sit with the basics. It is a required field and asking
  where a property is belongs with asking what it is.

### Added

* **Real help on all fourteen screens.** "Need help?" previously gave five
  screens a couple of lines and the other nine a single generic sentence. Every
  screen now explains what it is for, what to do on it, and the one or two
  things that catch people out — in plain words, with no technical jargon
  (a test fails if jargon creeps back in).
* Help now warns before anything irreversible: that Remove uses a bin you can
  recover from, that deleting a file is permanent, that imported properties
  arrive as drafts, and that deactivating or uninstalling keeps your data unless
  you explicitly ask otherwise.

## [1.6.0] — 2026-09-09

Making the plugin easier to start with. Until now an office could switch the
plugin on, add ten properties, and still see nothing on their website — because
nothing had told WordPress where those properties should appear. That is fixed.

### Added

* **A welcome screen that sets the office up.** A fresh install now opens on a
  short form: your name and number, the areas you cover and how you measure
  size, which pages you want, and whether those pages should arrive ready to use
  or bare for you to design yourself. Four questions, then a working website.
  It can be skipped, and everything it sets can be changed later in Office
  Settings.
* **The plugin builds your website pages for you.** Properties, Contact us, Our
  team and Saved properties. Choosing "ready to use" gives each page a heading,
  a short introduction written around your own office name, and your properties
  already laid out. Choosing "bare" drops in only the property list so you can
  build the rest in Elementor. Existing offices are untouched.
* **A "what to do next" list.** Shown on the welcome screen and at the top of
  Today. It suggests adding a first property, publishing a draft, adding your
  team, or giving an email address for enquiries — and each item disappears by
  itself once it is done, so the list empties as the office gets going.
* **A one-time reminder** on the office screens while setup is still outstanding.
  It goes away for good once setup is finished or skipped.

### Notes

* Building the pages is safe to repeat. A page that already exists is reused,
  never duplicated, and a page you have written yourself is adopted and left
  exactly as you wrote it.
* Upgrading an office that is already running never triggers the welcome screen.

## [1.5.1] — 2026-09-09

A full line-by-line audit of the plugin was carried out before first use. It
found five genuine faults. All five are fixed here, each with a test that fails
if the fix is ever removed.

### Security

* **An agent could award their own listing the office "verified" badge.** The
  guard that was supposed to prevent this checked a value the plugin never
  actually stored, so it never did anything. Setting the verification state now
  requires the "Mark listings as office verified" permission, and anyone without
  it leaves the existing badge exactly as the office set it — they can neither
  add one nor take one away, while their ordinary edits keep working.
* **A spreadsheet export could run commands on the office computer.** A website
  visitor could type a formula such as `=cmd|' /C calc'!A0` into a public
  enquiry form; when the office later exported their enquiries and opened the
  file, Excel or LibreOffice would treat it as a formula rather than as text.
  Exported cells that begin with `=`, `+`, `-`, `@`, a tab or a carriage return
  are now written as plain text. Stored data is untouched and genuine numbers
  are unaffected.
* **Unpublished projects were confirmed to anonymous visitors.** The public
  project statistics endpoint checked the record type but not whether it was
  published, so a draft or binned project answered differently from one that
  never existed. A draft now looks exactly like a missing record.
* **A draft property could be shown on the website.** The property card never
  checked whether the property was published, so choosing a draft in the
  Elementor widget put it in front of visitors. Visitors now see nothing for an
  unpublished property, while office staff can still preview their own drafts.

### Added

* **Records can finally be removed.** Nothing in the plugin could be deleted at
  all. Properties, societies and projects, team members, agencies, articles and
  documents now each have a **Remove** button that moves the record to a bin.
  Binned records can be **put back** at any time, and only something already in
  the bin can be deleted for good — which additionally requires typing DELETE to
  confirm. A restored record always comes back as a draft, so putting something
  back can never republish it to the website by accident. The listings screen
  has a new "In the bin" filter, and every removal is written to the activity
  history.

### Fixed

* The test harness now models WordPress's bin (`wp_trash_post` and
  `wp_untrash_post`), which it previously did not.

## [1.5.0] — 2026-09-09

### Added

* **Five ready-made forms.** Property enquiry, Book a site visit, Contact us,
  Sell or rent out a property, and Free property valuation. Each one arrives
  complete and working — fields, labels, wording and what happens with the
  information — so nobody has to build a form from an empty screen.
* **Standard field names across every template.** A phone box is always called
  `phone`, a locality always `locality`. Reports, exports and integrations can
  rely on the name whichever form the office started from. A test pins the exact
  field list of all five templates so a rename cannot slip through.
* **A palette people can read.** The eight boxes an estate office actually uses
  — Name, Phone, Email, Message, Property type, Locality, Budget, Consent — come
  first. The other twenty are folded into four groups (Choices, Date and time,
  Property, Advanced) behind "More field types", with a search box.
* **Three smart property fields**: `property_type` and `locality` fill their own
  choices from the office's own vocabulary and localities, and `budget` ships
  with sensible ranges.
* **A live preview** beside the designer showing roughly what a visitor will
  see, updating as the form changes. Its boxes are disabled so nobody can type
  into the preview by mistake.
* **Simpler field settings.** One plain "Half width" tick replaces three
  always-open width dropdowns (the exact per-device widths are still there,
  folded away), plus one simple "only show this box when …" rule.
* **Enquiries can be posted in from another form tool.** New public endpoint
  `POST estat/v1/enquiries` for Elementor Pro's Webhook action or any similar
  plugin. It is protected by a secret key set in Office Settings — with no key
  configured the endpoint refuses everything, so it is never open by default.
  Submissions go through the same cleaning, validation and duplicate checks as
  our own forms.

### Fixed

* The test harness was missing a `wp_list_pluck` stub, which made form
  validation fatal under test rather than failing honestly.

### Developer notes

* New `EstatOS\Forms\Templates`: `all()`, `get( $key )`, `STANDARD_IDS`.
  Filter `estat_form_templates`.
* New `FieldTypes::common()` and `FieldTypes::groups()`, filter
  `estat_form_field_groups`. Every registered type stays reachable in the
  palette — enforced by a test.
* New setting `inbound_secret`, compared with `hash_equals()`. Audit event
  `lead.inbound`.

## [1.4.0] — 2026-09-09

### Fixed

* **Dark mode was genuinely broken in places.** 40 style rules still used a
  hardcoded colour left over from before the design system existed, so parts of
  the office screens stayed white — table rows, panels, the form builder — when
  dark mode was on. Every one of them now uses a design token. A test walks the
  whole stylesheet and fails the build if a hardcoded colour is ever added back.
* **One style rule referred to a colour name that was never defined**
  (`--estat-soft`), so that text fell back to the browser default. Corrected to
  `--estat-ink-soft`, and a test now checks every colour name used actually
  exists.
* **Table rows were unreadable on a phone in several screens.** On a narrow
  screen each row becomes a small card and the column headings are hidden, so
  every cell must carry its own label. Insights, Gallery, Forms, Projects and
  Team had cells without one, showing values with nothing to say what they were.

### Added

* **A proper phone layout.** Buttons and boxes are now big enough to tap,
  typing no longer makes the phone zoom in, the search bar stacks instead of
  squashing, stat tiles go two-per-row, and wide tables can be swiped sideways
  instead of stretching the page off screen.
* **Empty screens now explain themselves** with a heading, a plain description,
  and where it helps a short numbered path out — and they distinguish "you have
  nothing here yet" (calm, with a first step) from "your search found nothing"
  (with a button to clear the filters).
* **Small conveniences.** A pressed Save button shows a spinner so a slow save
  does not look like a dead button; pressing Save twice can no longer create the
  same record twice; leaving a half-filled form warns first; `/` jumps to the
  search box, Ctrl/Cmd+S saves, and Escape closes an open confirmation drawer.
* Messages after saving now say what actually happened — publishing says the
  property is live, a draft says only the office can see it, an import says the
  new properties are drafts, and erasing says plainly that it cannot be undone.

### Developer notes

* `Partials::empty_state()` accepts either the original sentence or an array
  with `title`, `message`, `icon`, `steps`, `action`, `label`, `hint` and
  `reassuring`. Every existing call still works unchanged.
* The busy state deliberately does not disable the submit button: disabling one
  drops its `name`/`value` and would silently change what the form does.

## [1.3.0] — 2026-09-09

### Added

* **The dashboard now says what to do, not just how many.** "Today" opens with
  a short list of real jobs — overdue follow-ups first, then today's site
  visits, unanswered enquiries, enquiries nobody owns, and half-finished
  listings — each naming the person or property and linking straight to the
  screen where the work gets done. When there is genuinely nothing waiting, it
  says so and offers something useful instead of showing an empty box.
* **Adding a home is now four short steps** — the basics, price and size, a
  photo, then the highlights — instead of one long form. It is still a single
  form that posts in one go, so nothing about saving changed. If a required box
  is empty, the form points at it on that step rather than failing at the end.
  With scripting unavailable every step is simply visible, so the form still
  works.

### Changed

* **Listings, Enquiries, Site Visits, Gallery and Insights now share one search
  and filter bar**, so they look and behave the same instead of each being
  slightly different. Every list also says how many results it found.

### Developer notes

* New `EstatOS\Data\Worklist` class: `tasks( int $limit )` returns jobs shaped
  `{urgency, tone, icon, title, detail, action, url}`, lowest urgency first,
  capped at `Worklist::LIMIT`. Each source is bounded and permission-checked, so
  a user is never shown a job they cannot act on. Filter: `estat_worklist`.
* New `Partials::toolbar()` renders the shared search/filter bar.
* New `Support\Format::time()` for times of day.

## [1.2.0] — 2026-09-09

### Added

* **A real Gallery screen.** The Gallery menu used to be a link to the raw
  WordPress media library — it showed every file on the site, used language an
  estate office does not need, and loaded a heavy uploader that some browsers
  flag as suspicious. It is now the plugin's own screen: tabs for Photos, Floor
  plans, Brochures and Documents, a picture grid for images and a plain list for
  paperwork, search, a filter for files not yet attached to anything, and a
  drag-and-drop area that uploads through the plugin's own endpoint with no
  third-party uploader involved.
* Files can be filed by what they are, and attached to a property or project, so
  the gallery shows which listing a photo belongs to.
* **Light and dark screens.** Office Settings now offers Light, Dark, or
  Automatic (follow the computer). It affects only the office screens; the
  public website is untouched.

### Changed

* **The admin screens were redesigned.** Softer cards with gentle shadows,
  calmer tables, clearer buttons and inputs, better spacing and typography.
  Every colour, radius and spacing step is now a single design token, which is
  what makes the dark theme possible without touching each screen.
* Movement is switched off automatically for anyone whose computer asks for
  reduced motion.

### Developer notes

* New `EstatOS\Data\Media` class: `kinds()`, `query()`, `to_array()`,
  `kind_of()`, `set_kind()`, `link()`, `counts()`. It reads; all writes go
  through capability-checked admin actions.
* New setting `admin_theme` (`light` | `dark` | `auto`), sanitised to a fixed
  list. It is reflected as an `estat-theme-*` body class.
* The removal action verifies the target really is a file before deleting, on
  its own account rather than relying on WordPress to refuse.
* The test harness now honours `post_mime_type` and `meta_query`, which it
  previously ignored.

## [1.1.1] — 2026-09-09

### Fixed

* **Most of the Office menu was missing, and pages refused to open.** On a live
  site only Site Visits, Forms, Spreadsheet, Reports and Office Settings
  appeared; Today, Add a Home, Listings, Enquiries, Societies & Projects, Team,
  Gallery and Insights were gone, and opening Enquiries showed "Sorry, you are
  not allowed to access this page" even for the site administrator.

  The cause: several content types mapped WordPress's three per-record
  permissions (`edit_post`, `read_post`, `delete_post`) onto the same office
  permission. WordPress remembers those names in a global list and from then on
  treats them as per-record permissions that require a specific record ID. Every
  ordinary permission check made without a record ID — which is what a menu
  entry does — then returned "no" for everybody, administrators included.

  Each content type now uses its own private per-record permission names, and
  the office permissions are left alone. All roles, including administrator,
  are granted the new names on upgrade.

* The test suite never had an `administrator` role, so the part of the installer
  that grants permissions to administrators was never exercised and the fault
  above could not be caught. The harness now starts with the built-in WordPress
  roles present.

### Changed

* Database version raised to 3. The upgrade only repairs permissions; no
  business data is read, changed or removed.

## [1.1.0] — 2026-09-08

### Added

* **Highlight tags on property cards.** When someone adds a property they can
  tick the things that actually sell it — corner plot, park facing, near metro,
  clear title, lift, power backup and thirty more, grouped into Position,
  Condition, Paperwork, Comfort, Nearby and Money. The best three appear as
  small tags on the property card, and the add-a-property screen shows a live
  preview of exactly which ones will make it onto the card. A property with
  nothing ticked still shows bedrooms, bathrooms and size, so no card is ever
  blank.
* **Insights is now a real screen.** Blogs, Articles and Insights live together
  on one page with a tab for each, their own topics, a search box, drafts, cover
  pictures and a proper editor. It no longer sends the office to the WordPress
  post editor. A piece can be re-filed from one tab to another without changing
  its web address.
* A new `estat_manage_insights` permission, granted to owners and agents.
  Existing sites pick it up automatically on upgrade — nothing to reinstall.

### Changed

* Property cards show the highlight tags in place of the old repeated
  bedroom/size line, so the card reads like an advert rather than a form.
* Database version raised to 2. The upgrade only adds a permission and the three
  insight categories; no existing data is touched, rewritten or removed.

### Developer notes

* New filters `estat_highlights` (change the catalogue) and
  `estat_listing_highlights` (change what a single property shows).
* `Listings::save()` accepts a `highlights` array of keys; unknown keys are
  discarded. `Listings::to_array()` now returns `highlights` and `chips`.
* The integration harness reads `ESTAT_VERSION` and `ESTAT_DB_VERSION` from the
  plugin file instead of hardcoding them, so upgrade paths are genuinely tested.

## [1.0.0] — 2026-09-08

The first stable release, following a dedicated production validation and
release hardening phase. See `docs/release-readiness.md` for the full report and
`docs/implementation-matrix.md` for requirement-by-requirement status.

### Naming

* The product is **Estat.OS**, authored by DEVil
  (https://github.com/devkaushall). The PHP namespace is `EstatOS`, the text
  domain is `estat-os`, constants use the `ESTAT_` prefix, hooks, options,
  capabilities and tables use `estat_`, CSS classes and admin slugs use
  `estat-`, the REST namespace is `estat/v1`, and webhook headers are
  `X-Estat-Event`, `X-Estat-Timestamp` and `X-Estat-Signature`.

### Fixed during release hardening

* New-enquiry notification emails were only sent for enquiries that arrived
  through a form. Enquiries created via the REST API, a CSV import, the admin
  screens or another plugin notified nobody, even though the setting said they
  would. The `estat_lead_created` hook is now wired up, with a guard so a form
  enquiry is never emailed twice.
* The table health check ran eight uncached `SHOW TABLES` queries every time it
  was called, from thirty-four call sites. It is now cached per request and in
  the object cache, which takes a paged property search from ten queries down to
  two.
* All six `fgetcsv()`/`fputcsv()` calls now pass explicit RFC 4180 arguments,
  removing a PHP 8.4 deprecation and a behaviour change due in PHP 9.
* The plugin now shows a clear admin notice on an unsupported PHP or WordPress
  version instead of causing a fatal error.
* Fixed an undefined-property warning on the Today screen for users with no
  first name set.

### Added

* **Inventory** — properties, societies and projects, team members, agencies and
  documents, with a beginner-first editor split into three short chapters and a
  readiness score out of 100.
* **Add a Home** — a nine-question form that never sends you to the WordPress
  editor.
* **Discovery** — a dedicated flat search index table, filtered search,
  favourites and side-by-side compare of up to four properties.
* **Pipeline** — enquiries with de-duplication and idempotency, notes, follow-up
  dates, agent assignment, and a site-visit diary with outcomes.
* **Forms** — a visual drag-and-drop builder with 25 field types, per-device
  width controls, conditional logic, consent handling, spam rate limiting, and a
  form-to-enquiry pipeline.
* **Reporting** — office health, pipeline shape, per-person performance, busiest
  localities and enquiry sources.
* **Spreadsheets** — batched CSV import with de-duplication on your own
  reference numbers, plus one-click export of everything.
* **REST API** — the `estat/v1` namespace, with rate limiting on anonymous
  routes.
* **Webhooks** — five events, HMAC-SHA256 signed, with retries and a delivery
  log.
* **Elementor** — seventeen presentation-only widgets, including a *Estat Form*
  widget. Elementor is never required.
* **Languages** — English and natural Hinglish written in Latin script, plus a
  `.pot` file and documentation for adding more.
* **Care and safety** — audit log, daily and hourly housekeeping, privacy export
  and erasure, practice mode with one-click sample data, and maintenance tools
  for rebuilding the search index and repairing tables.
* **Roles** — Office Owner and Office Agent, built from nineteen granular
  capabilities.

### Security

* Capability and nonce checks on every write, all output escaped, all SQL
  prepared.
* Uploaded spreadsheets stored in a protected folder.
* Prices marked *on request* are never exposed publicly, including through the
  API and structured data.

### Notes

* Deactivating or deleting the plugin keeps all of your data. Erasure only
  happens if you explicitly opt in beforehand.
* Content-copy protection is deliberately out of scope.

[1.0.0]: https://github.com/devkaushall/estat-os/releases/tag/v1.0.0
