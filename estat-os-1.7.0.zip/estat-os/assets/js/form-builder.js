/**
 * Estat.OS - visual form builder.
 *
 * Renders a rows / columns / fields tree, lets the office drag fields
 * between columns, and writes the whole definition back into a hidden
 * input as JSON. The server re-validates everything, so nothing here is
 * trusted; this file only has to be pleasant to use.
 */
( function ( window, document ) {
	'use strict';

	var config = window.estatBuilder || {};
	var types = config.fieldTypes || {};
	var t = config.i18n || {};

	var WIDTHS = [ '100', '75', '66', '50', '33', '25' ];

	var root = null;
	var input = null;
	var model = { rows: [] };
	var selected = null;
	var counter = 0;

	/* ---------------------------------------------------------- Helpers */

	function el( tag, className, text ) {
		var node = document.createElement( tag );
		if ( className ) {
			node.className = className;
		}
		if ( text !== undefined ) {
			node.textContent = text;
		}
		return node;
	}

	function uid( prefix ) {
		counter += 1;
		return prefix + '_' + Date.now().toString( 36 ) + counter.toString( 36 );
	}

	function typeLabel( type ) {
		return ( types[ type ] && types[ type ].label ) || type;
	}

	function hasOptions( type ) {
		return !! ( types[ type ] && types[ type ].options );
	}

	function commit() {
		if ( input ) {
			input.value = JSON.stringify( model );
		}
	}

	/* ------------------------------------------------------ Model edits */

	function newField( type ) {
		var field = {
			id: uid( 'f' ),
			type: type,
			label: typeLabel( type ),
			placeholder: '',
			help: '',
			required: false,
			width: '100',
			width_tablet: '100',
			width_mobile: '100',
			options: []
		};
		if ( hasOptions( type ) ) {
			field.options = [
				{ value: 'one', label: 'One' },
				{ value: 'two', label: 'Two' }
			];
		}
		return field;
	}

	function newColumn() {
		return { width: '100', width_tablet: '100', width_mobile: '100', fields: [] };
	}

	function newRow() {
		return { heading: '', gap: 'normal', columns: [ newColumn() ] };
	}

	function ensureShape() {
		if ( ! model || ! Array.isArray( model.rows ) || ! model.rows.length ) {
			model = { rows: [ newRow() ] };
		}
		model.rows.forEach( function ( row ) {
			if ( ! Array.isArray( row.columns ) || ! row.columns.length ) {
				row.columns = [ newColumn() ];
			}
			row.columns.forEach( function ( column ) {
				if ( ! Array.isArray( column.fields ) ) {
					column.fields = [];
				}
				column.fields.forEach( function ( field ) {
					if ( ! field.id ) {
						field.id = uid( 'f' );
					}
				} );
			} );
		} );
	}

	function findField( id ) {
		var found = null;
		model.rows.forEach( function ( row, r ) {
			row.columns.forEach( function ( column, c ) {
				column.fields.forEach( function ( field, f ) {
					if ( field.id === id ) {
						found = { field: field, row: r, column: c, index: f };
					}
				} );
			} );
		} );
		return found;
	}

	function removeField( id ) {
		var at = findField( id );
		if ( at ) {
			model.rows[ at.row ].columns[ at.column ].fields.splice( at.index, 1 );
		}
	}

	function moveField( id, rowIndex, columnIndex, position ) {
		var at = findField( id );
		if ( ! at ) {
			return;
		}
		var field = at.field;
		model.rows[ at.row ].columns[ at.column ].fields.splice( at.index, 1 );
		var target = model.rows[ rowIndex ].columns[ columnIndex ].fields;
		var index = typeof position === 'number' ? position : target.length;
		target.splice( Math.max( 0, Math.min( index, target.length ) ), 0, field );
	}

	/* ----------------------------------------------------------- Render */

	function widthSelect( value, onChange, label ) {
		var wrap = el( 'span' );
		var caption = el( 'label', null, label );
		var select = el( 'select' );
		WIDTHS.forEach( function ( width ) {
			var option = el( 'option', null, width + '%' );
			option.value = width;
			if ( String( value ) === width ) {
				option.selected = true;
			}
			select.appendChild( option );
		} );
		select.addEventListener( 'change', function () {
			onChange( select.value );
			commit();
		} );
		caption.appendChild( select );
		wrap.appendChild( caption );
		return wrap;
	}

	function textRow( labelText, value, onChange, multiline ) {
		var wrap = el( 'p', 'estat-builder-input' );
		var label = el( 'label', null, labelText );
		var control = multiline ? el( 'textarea' ) : el( 'input' );
		if ( ! multiline ) {
			control.type = 'text';
		} else {
			control.rows = 2;
		}
		control.value = value || '';
		control.style.width = '100%';
		control.addEventListener( 'input', function () {
			onChange( control.value );
			commit();
		} );
		label.appendChild( control );
		wrap.appendChild( label );
		return wrap;
	}

	function renderFieldEditor( field ) {
		var box = el( 'div', 'estat-builder-field-editor' );

		box.appendChild( textRow( t.label || 'Label', field.label, function ( value ) {
			field.label = value;
			var title = document.querySelector( '[data-field="' + field.id + '"] .estat-builder-field-title' );
			if ( title ) {
				title.textContent = value;
			}
		} ) );

		if ( field.type !== 'heading' && field.type !== 'paragraph' && field.type !== 'divider' ) {
			box.appendChild( textRow( t.placeholder || 'Example text inside the box', field.placeholder, function ( value ) {
				field.placeholder = value;
			} ) );
			box.appendChild( textRow( t.help || 'Short explanation', field.help, function ( value ) {
				field.help = value;
			} ) );

			var requiredWrap = el( 'p' );
			var requiredLabel = el( 'label', 'estat-inline-check' );
			var requiredBox = el( 'input' );
			requiredBox.type = 'checkbox';
			requiredBox.checked = !! field.required;
			requiredBox.addEventListener( 'change', function () {
				field.required = requiredBox.checked;
				commit();
			} );
			requiredLabel.appendChild( requiredBox );
			requiredLabel.appendChild( document.createTextNode( ' ' + ( t.required || 'This information is required' ) ) );
			requiredWrap.appendChild( requiredLabel );
			box.appendChild( requiredWrap );
		}

		if ( hasOptions( field.type ) ) {
			var lines = ( field.options || [] ).map( function ( option ) {
				return option.label;
			} ).join( '\n' );
			box.appendChild( textRow( t.options || 'Choices (one per line)', lines, function ( value ) {
				field.options = value.split( '\n' ).map( function ( line ) {
					return line.trim();
				} ).filter( Boolean ).map( function ( line ) {
					return { value: line.toLowerCase().replace( /[^a-z0-9]+/g, '_' ), label: line };
				} );
			}, true ) );
		}

		// Most people only ever want "full width" or "half, side by side".
		// The exact per-device percentages are still there, just folded away.
		var sizeWrap = el( 'p' );
		var sizeLabel = el( 'label', 'estat-inline-check' );
		var halfBox = el( 'input' );
		halfBox.type = 'checkbox';
		halfBox.checked = Number( field.width ) <= 50;
		halfBox.addEventListener( 'change', function () {
			if ( halfBox.checked ) {
				field.width = '50';
				field.width_tablet = '50';
			} else {
				field.width = '100';
				field.width_tablet = '100';
			}

			// Side by side never reads well on a phone.
			field.width_mobile = '100';
			commit();
			refreshPreview();
		} );
		sizeLabel.appendChild( halfBox );
		sizeLabel.appendChild( document.createTextNode( ' ' + ( t.halfWidth || 'Half width (sits next to the box beside it)' ) ) );
		sizeWrap.appendChild( sizeLabel );
		box.appendChild( sizeWrap );

		// Exact widths, for anyone who wants them.
		var fine = el( 'details', 'estat-builder-fine' );
		var fineSummary = el( 'summary', null, t.exactWidths || 'Exact widths' );
		fine.appendChild( fineSummary );

		var widths = el( 'div', 'estat-builder-widths' );
		widths.appendChild( widthSelect( field.width, function ( value ) {
			field.width = value;
			refreshPreview();
		}, t.width || 'Width on a computer' ) );
		widths.appendChild( widthSelect( field.width_tablet, function ( value ) {
			field.width_tablet = value;
			refreshPreview();
		}, t.widthTablet || 'Width on a tablet' ) );
		widths.appendChild( widthSelect( field.width_mobile, function ( value ) {
			field.width_mobile = value;
			refreshPreview();
		}, t.widthMobile || 'Width on a phone' ) );
		fine.appendChild( widths );
		box.appendChild( fine );

		// One simple rule: only show this box when another one has a value.
		box.appendChild( renderConditionEditor( field ) );

		return box;
	}

	/**
	 * "Only show this when ..." — one rule, in plain words.
	 */
	function renderConditionEditor( field ) {
		var wrap = el( 'details', 'estat-builder-condition' );
		var rule = field.condition || { field: '', operator: 'is', value: '' };
		var isOn = !! rule.field;

		var summary = el( 'summary', null, isOn
			? ( t.conditionOn || 'Only shown sometimes' )
			: ( t.conditionOff || 'Always shown' ) );
		wrap.appendChild( summary );

		if ( isOn ) {
			wrap.setAttribute( 'open', 'open' );
		}

		var line = el( 'div', 'estat-condition-line' );
		line.appendChild( el( 'span', null, t.conditionWhen || 'Only show this box when' ) );

		var picker = el( 'select' );
		var none = el( 'option', null, t.conditionAlways || '— always show it —' );
		none.value = '';
		picker.appendChild( none );

		// A field may only depend on one that comes before it, otherwise the
		// rule could never be satisfied.
		everyFieldBefore( field.id ).forEach( function ( other ) {
			var option = el( 'option', null, other.label || other.id );
			option.value = other.id;
			if ( rule.field === other.id ) {
				option.selected = true;
			}
			picker.appendChild( option );
		} );

		var valueBox = el( 'input' );
		valueBox.type = 'text';
		valueBox.value = rule.value || '';
		valueBox.placeholder = t.conditionValue || 'has this answer';
		valueBox.disabled = ! rule.field;

		picker.addEventListener( 'change', function () {
			field.condition = {
				field: picker.value,
				operator: 'is',
				value: picker.value ? valueBox.value : ''
			};
			valueBox.disabled = ! picker.value;
			summary.textContent = picker.value
				? ( t.conditionOn || 'Only shown sometimes' )
				: ( t.conditionOff || 'Always shown' );
			commit();
			refreshPreview();
		} );

		valueBox.addEventListener( 'input', function () {
			field.condition = {
				field: picker.value,
				operator: 'is',
				value: valueBox.value
			};
			commit();
		} );

		line.appendChild( picker );
		line.appendChild( el( 'span', null, t.conditionIs || 'is' ) );
		line.appendChild( valueBox );
		wrap.appendChild( line );

		return wrap;
	}

	/**
	 * Every field that appears before this one, in form order.
	 */
	function everyFieldBefore( id ) {
		var out = [];
		var stop = false;

		model.rows.forEach( function ( row ) {
			row.columns.forEach( function ( column ) {
				column.fields.forEach( function ( field ) {
					if ( field.id === id ) {
						stop = true;
					}
					if ( ! stop && field.type !== 'heading' && field.type !== 'paragraph' && field.type !== 'submit' ) {
						out.push( field );
					}
				} );
			} );
		} );

		return out;
	}

	function renderField( field ) {
		var node = el( 'div', 'estat-builder-field' );
		node.setAttribute( 'data-field', field.id );
		node.setAttribute( 'draggable', 'true' );
		node.setAttribute( 'tabindex', '0' );
		if ( selected === field.id ) {
			node.classList.add( 'is-selected' );
		}

		var head = el( 'div', 'estat-builder-field-head' );
		var title = el( 'strong', 'estat-builder-field-title', field.label || typeLabel( field.type ) );
		var type = el( 'span', 'estat-builder-field-type', typeLabel( field.type ) );
		head.appendChild( title );
		head.appendChild( type );

		var remove = el( 'button', 'button-link estat-danger-link', t.remove || 'Remove' );
		remove.type = 'button';
		remove.addEventListener( 'click', function ( event ) {
			event.stopPropagation();
			if ( ! window.confirm( t.confirmDelete || 'Remove this field?' ) ) {
				return;
			}
			removeField( field.id );
			commit();
			render();
		} );
		head.appendChild( remove );
		node.appendChild( head );

		node.addEventListener( 'click', function () {
			selected = ( selected === field.id ) ? null : field.id;
			render();
		} );

		if ( selected === field.id ) {
			var editor = renderFieldEditor( field );
			editor.addEventListener( 'click', function ( event ) {
				event.stopPropagation();
			} );
			node.appendChild( editor );
		}

		return node;
	}

	function renderColumn( column, rowIndex, columnIndex ) {
		var node = el( 'div', 'estat-builder-column' );
		node.setAttribute( 'data-row', String( rowIndex ) );
		node.setAttribute( 'data-column', String( columnIndex ) );

		column.fields.forEach( function ( field ) {
			node.appendChild( renderField( field ) );
		} );

		if ( ! column.fields.length ) {
			node.appendChild( el( 'p', 'estat-muted', t.dragHint || 'Drag a field here' ) );
		}

		node.addEventListener( 'dragover', function ( event ) {
			event.preventDefault();
			node.classList.add( 'is-over' );
		} );
		node.addEventListener( 'dragleave', function () {
			node.classList.remove( 'is-over' );
		} );
		node.addEventListener( 'drop', function ( event ) {
			event.preventDefault();
			node.classList.remove( 'is-over' );
			var id = event.dataTransfer ? event.dataTransfer.getData( 'text/plain' ) : '';
			if ( ! id ) {
				return;
			}
			moveField( id, rowIndex, columnIndex );
			commit();
			render();
		} );

		return node;
	}

	function renderRow( row, rowIndex ) {
		var node = el( 'div', 'estat-builder-row' );

		var head = el( 'div', 'estat-builder-row-head' );
		var heading = el( 'input' );
		heading.type = 'text';
		heading.value = row.heading || '';
		heading.placeholder = t.rowHeading || 'Optional heading for this row';
		heading.addEventListener( 'input', function () {
			row.heading = heading.value;
			commit();
		} );
		head.appendChild( heading );

		var controls = el( 'span', 'estat-builder-row-controls' );

		var addColumn = el( 'button', 'button button-small', t.addColumn || 'Add a column' );
		addColumn.type = 'button';
		addColumn.addEventListener( 'click', function () {
			row.columns.push( newColumn() );
			commit();
			render();
		} );
		controls.appendChild( addColumn );

		var up = el( 'button', 'button button-small', '\u2191' );
		up.type = 'button';
		up.setAttribute( 'aria-label', t.moveUp || 'Move up' );
		up.disabled = rowIndex === 0;
		up.addEventListener( 'click', function () {
			var moved = model.rows.splice( rowIndex, 1 )[ 0 ];
			model.rows.splice( rowIndex - 1, 0, moved );
			commit();
			render();
		} );
		controls.appendChild( up );

		var down = el( 'button', 'button button-small', '\u2193' );
		down.type = 'button';
		down.setAttribute( 'aria-label', t.moveDown || 'Move down' );
		down.disabled = rowIndex === model.rows.length - 1;
		down.addEventListener( 'click', function () {
			var moved = model.rows.splice( rowIndex, 1 )[ 0 ];
			model.rows.splice( rowIndex + 1, 0, moved );
			commit();
			render();
		} );
		controls.appendChild( down );

		var removeRow = el( 'button', 'button button-small estat-danger-button', t.remove || 'Remove' );
		removeRow.type = 'button';
		removeRow.addEventListener( 'click', function () {
			if ( ! window.confirm( t.confirmDeleteRow || t.confirmDelete || 'Remove this row?' ) ) {
				return;
			}
			model.rows.splice( rowIndex, 1 );
			ensureShape();
			commit();
			render();
		} );
		controls.appendChild( removeRow );

		head.appendChild( controls );
		node.appendChild( head );

		var columns = el( 'div', 'estat-builder-columns' );
		row.columns.forEach( function ( column, columnIndex ) {
			columns.appendChild( renderColumn( column, rowIndex, columnIndex ) );
		} );
		node.appendChild( columns );

		return node;
	}

	function render() {
		if ( ! root ) {
			return;
		}
		root.textContent = '';
		ensureShape();

		model.rows.forEach( function ( row, index ) {
			root.appendChild( renderRow( row, index ) );
		} );

		var addRow = el( 'button', 'button', t.addRow || 'Add a row' );
		addRow.type = 'button';
		addRow.addEventListener( 'click', function () {
			model.rows.push( newRow() );
			commit();
			render();
		} );
		root.appendChild( addRow );

		commit();
		refreshPreview();
	}

	/* ------------------------------------------------------------- Drag */

	function initDrag() {
		root.addEventListener( 'dragstart', function ( event ) {
			var field = event.target.closest ? event.target.closest( '.estat-builder-field' ) : null;
			if ( ! field || ! event.dataTransfer ) {
				return;
			}
			event.dataTransfer.effectAllowed = 'move';
			event.dataTransfer.setData( 'text/plain', field.getAttribute( 'data-field' ) || '' );
		} );
	}

	/* ------------------------------------------------------------ Setup */

	function initPalette() {
		var palette = document.getElementById( 'estat-field-palette' );
		if ( ! palette ) {
			return;
		}
		palette.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '.estat-add-field' );
			if ( ! button ) {
				return;
			}
			event.preventDefault();
			ensureShape();
			var lastRow = model.rows[ model.rows.length - 1 ];
			var field = newField( button.getAttribute( 'data-type' ) || 'text' );
			lastRow.columns[ lastRow.columns.length - 1 ].fields.push( field );
			selected = field.id;
			commit();
			render();
			var node = document.querySelector( '[data-field="' + field.id + '"]' );
			if ( node ) {
				node.scrollIntoView( { block: 'center' } );
				node.focus();
			}
		} );
	}

	/* --------------------------------------------------- Live preview */

	/**
	 * Show the form roughly as a visitor will see it.
	 *
	 * This is a picture, not a working form: the boxes are disabled so nobody
	 * can type into the preview and think they have filled the real thing in.
	 */
	function refreshPreview() {
		var host = document.getElementById( 'estat-form-preview' );

		if ( ! host ) {
			return;
		}

		host.textContent = '';

		var visible = 0;

		model.rows.forEach( function ( row ) {
			var rowNode = el( 'div', 'estat-preview-row' );

			row.columns.forEach( function ( column ) {
				column.fields.forEach( function ( field ) {
					rowNode.appendChild( previewField( field, column ) );
					visible++;
				} );
			} );

			if ( rowNode.childNodes.length ) {
				host.appendChild( rowNode );
			}
		} );

		if ( ! visible ) {
			host.appendChild( el( 'p', 'description', t.previewEmpty || 'Add a field and it will appear here.' ) );
			return;
		}

		var button = el( 'span', 'estat-preview-submit', submitLabel() );
		host.appendChild( button );
	}

	function submitLabel() {
		var box = document.querySelector( '[name="settings[submit_label]"]' );

		return ( box && box.value ) || t.previewSend || 'Send enquiry';
	}

	function previewField( field, column ) {
		var wrap = el( 'div', 'estat-preview-field' );
		var width = Number( column.width || field.width || 100 );

		wrap.style.width = ( width >= 100 ? 100 : width ) + '%';

		if ( field.condition && field.condition.field ) {
			wrap.classList.add( 'is-conditional' );
		}

		if ( 'heading' === field.type ) {
			wrap.appendChild( el( 'strong', 'estat-preview-heading', field.label || '' ) );
			return wrap;
		}

		if ( 'paragraph' === field.type ) {
			wrap.appendChild( el( 'p', 'estat-preview-text', field.label || '' ) );
			return wrap;
		}

		if ( 'hidden' === field.type ) {
			wrap.appendChild( el( 'span', 'estat-preview-hidden', ( t.previewHidden || 'Hidden:' ) + ' ' + ( field.label || field.id ) ) );
			return wrap;
		}

		var label = el( 'span', 'estat-preview-label', field.label || typeLabel( field.type ) );

		if ( field.required ) {
			label.appendChild( el( 'span', 'estat-preview-required', ' *' ) );
		}

		wrap.appendChild( label );

		var control;

		if ( 'textarea' === field.type || 'message' === field.type || 'address' === field.type ) {
			control = el( 'textarea' );
			control.rows = 2;
		} else if ( 'checkbox' === field.type || 'consent' === field.type ) {
			control = el( 'input' );
			control.type = 'checkbox';
		} else if ( hasOptions( field.type ) || 'select' === field.type || 'property_type' === field.type || 'locality' === field.type || 'budget' === field.type ) {
			control = el( 'select' );
			var choices = field.options || [];

			if ( ! choices.length ) {
				var placeholderOption = el( 'option', null, t.previewChoices || 'Your choices appear here' );
				control.appendChild( placeholderOption );
			} else {
				choices.slice( 0, 8 ).forEach( function ( choice ) {
					control.appendChild( el( 'option', null, choice.label || choice ) );
				} );
			}
		} else {
			control = el( 'input' );
			control.type = 'text';
		}

		control.disabled = true;
		control.placeholder = field.placeholder || '';
		wrap.appendChild( control );

		if ( field.help ) {
			wrap.appendChild( el( 'span', 'estat-preview-help', field.help ) );
		}

		return wrap;
	}

	/* ------------------------------------------- Searching the palette */

	function initPaletteSearch() {
		var search = document.getElementById( 'estat-palette-search' );
		var more = document.querySelector( '.estat-palette-more' );

		if ( ! search || ! more ) {
			return;
		}

		var empty = more.querySelector( '.estat-palette-empty' );
		var groups = Array.prototype.slice.call( more.querySelectorAll( '.estat-palette-group' ) );

		search.addEventListener( 'input', function () {
			var term = search.value.trim().toLowerCase();
			var anyShown = false;

			groups.forEach( function ( group ) {
				var shownHere = 0;

				Array.prototype.forEach.call( group.querySelectorAll( '.estat-palette-chip' ), function ( chip ) {
					var label = ( chip.getAttribute( 'data-label' ) || chip.textContent || '' ).toLowerCase();
					var match = '' === term || label.indexOf( term ) !== -1;

					chip.hidden = ! match;

					if ( match ) {
						shownHere++;
					}
				} );

				// A group heading with nothing under it is just noise.
				group.hidden = 0 === shownHere;

				if ( shownHere ) {
					anyShown = true;
				}
			} );

			if ( empty ) {
				empty.hidden = anyShown;
			}
		} );
	}

	function start() {
		root = document.getElementById( 'estat-builder' );
		input = document.getElementById( 'estat-definition' );
		if ( ! root ) {
			return;
		}

		try {
			model = JSON.parse( root.getAttribute( 'data-definition' ) || '{}' );
		} catch ( error ) {
			model = { rows: [] };
		}
		if ( ! model || typeof model !== 'object' ) {
			model = { rows: [] };
		}

		ensureShape();
		render();
		initDrag();
		initPalette();
		initPaletteSearch();
		refreshPreview();

		// The preview shows the button's wording, so follow it as it is typed.
		var submitBox = document.querySelector( '[name="settings[submit_label]"]' );
		if ( submitBox ) {
			submitBox.addEventListener( 'input', refreshPreview );
		}
	}

	if ( document.readyState !== 'loading' ) {
		start();
	} else {
		document.addEventListener( 'DOMContentLoaded', start );
	}
} )( window, document );
