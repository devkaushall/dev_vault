<?php
/**
 * The icon set.
 *
 * Every icon in Estat.OS is an inline SVG drawn on the same 24px grid with the
 * same 1.75 stroke weight, round caps and round joins. That consistency is the
 * whole point: emoji were used before, and emoji are drawn by the operating
 * system, so the same screen looked different on Windows, macOS, Android and
 * Linux, at different weights and different colours. Nothing tied them
 * together.
 *
 * Rules for this file:
 *
 * - Icons are decorative. Every one is `aria-hidden`, and the thing next to it
 *   must carry the real, readable name. An icon never carries meaning alone.
 * - Icons inherit `currentColor`, so they follow the theme, including dark
 *   mode, without a second definition.
 * - `name()` is the only way to draw one. An unknown name returns an empty
 *   string rather than a broken glyph or a PHP notice.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Inline SVG icons.
 */
final class Icon {

	/**
	 * Every icon path, keyed by name.
	 *
	 * Paths only. The wrapper, stroke and size are added by render().
	 *
	 * @return array<string,string>
	 */
	public static function paths(): array {
		return array(

			/* ---------------------------------------------- Screens */

			'home'        => '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.8V20h14V9.8"/><path d="M9.5 20v-6h5v6"/>',
			'search'      => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
			'inbox'       => '<path d="M3 12h5l2 3h4l2-3h5"/><path d="M4.5 6h15l1.5 6v6H3v-6z"/>',
			'car'         => '<path d="M5 16.5h14"/><path d="M6.5 16.5V19H4v-2.5"/><path d="M20 16.5V19h-2.5v-2.5"/><path d="M4 16.5v-4l2-5h12l2 5v4z"/><circle cx="7.5" cy="13" r="1"/><circle cx="16.5" cy="13" r="1"/>',
			'chart'       => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M3 20h18"/>',
			'image'       => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="m4 17 5-4.5 4 3.5 3-2.5 4 3.5"/>',
			'document'    => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
			'form'        => '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8"/><path d="M8 12h8"/><path d="M8 16h4"/>',
			'person'      => '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.6 3.1-5.5 7-5.5s7 1.9 7 5.5"/>',
			'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
			'arrow-right' => '<path d="M4 12h15"/><path d="m13 6 6 6-6 6"/>',
			'upload'      => '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
			'check'       => '<path d="m4.5 12.5 5 5 10-11"/>',
			'heart'       => '<path d="M12 20s-7.5-4.6-7.5-9.4A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7.5 2.6C19.5 15.4 12 20 12 20z"/>',

			/* ------------------------------------- Property position */

			'corner'      => '<path d="M5 5v14h14"/><path d="M5 5h8v8H5z"/>',
			'tree'        => '<path d="M12 21v-4"/><path d="M12 17a5 5 0 0 0 1.4-9.8A4 4 0 0 0 6 8.5 4 4 0 0 0 7 17z"/>',
			'road'        => '<path d="M6 3 4 21"/><path d="m18 3 2 18"/><path d="M12 4v3"/><path d="M12 11v3"/><path d="M12 18v3"/>',
			'shop'        => '<path d="M4 9h16v11H4z"/><path d="M4 9 5.5 4h13L20 9"/><path d="M9.5 20v-6h5v6"/>',
			'lock'        => '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
			'sun'         => '<circle cx="12" cy="12" r="4"/><path d="M12 3v2"/><path d="M12 19v2"/><path d="M3 12h2"/><path d="M19 12h2"/><path d="m5.6 5.6 1.4 1.4"/><path d="m17 17 1.4 1.4"/><path d="M18.4 5.6 17 7"/><path d="m7 17-1.4 1.4"/>',
			'compass'     => '<circle cx="12" cy="12" r="8.5"/><path d="m15 9-2 4.5L8.5 15l2-4.5z"/>',

			/* ------------------------------------ Property condition */

			'key'         => '<circle cx="8" cy="14" r="3.5"/><path d="m10.5 11.5 8-8"/><path d="m15.5 6.5 2 2"/><path d="m18 4 2 2"/>',
			'sparkle'     => '<path d="M12 4v6"/><path d="M12 14v6"/><path d="M4 12h6"/><path d="M14 12h6"/>',
			'brush'       => '<path d="M6 14 14.5 5.5a2.1 2.1 0 0 1 3 3L9 17"/><path d="M6 14c-1.5 1.5-1 4-3 5 2.5 1 5 .5 6-2.5"/>',
			'lotus'       => '<path d="M12 20c-4 0-7-2.5-8-6 2.5-.5 4.5 0 6 1.2"/><path d="M12 20c4 0 7-2.5 8-6-2.5-.5-4.5 0-6 1.2"/><path d="M12 20c-2-3-2-7 0-11 2 4 2 8 0 11z"/>',

			/* ------------------------------------ Property paperwork */

			'certificate' => '<path d="M6 3h12v13H6z"/><path d="M9 7h6"/><path d="M9 11h4"/><circle cx="12" cy="19" r="2.5"/>',
			'bank'        => '<path d="M3 9.5 12 4l9 5.5"/><path d="M5 9.5V18"/><path d="M9.5 9.5V18"/><path d="M14.5 9.5V18"/><path d="M19 9.5V18"/><path d="M3 20.5h18"/>',
			'shield'      => '<path d="M12 3.5 5 6v6c0 4 3 7 7 8.5 4-1.5 7-4.5 7-8.5V6z"/><path d="m9 12 2 2 4-4"/>',
			'receipt'     => '<path d="M6 3h12v18l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 21z"/><path d="M9.5 8h5"/><path d="M9.5 12h5"/>',

			/* -------------------------------------- Property comfort */

			'lift'        => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="m9.5 9 1.5-2 1.5 2"/><path d="m9.5 15 1.5 2 1.5-2"/><path d="M15.5 7v10"/>',
			'battery'     => '<rect x="3" y="8" width="15" height="8" rx="2"/><path d="M21 11v2"/><path d="m10.5 10-1.5 3h2l-1.5 3"/>',
			'guard'       => '<circle cx="12" cy="7.5" r="3"/><path d="M5.5 20c0-3.4 2.9-5.2 6.5-5.2s6.5 1.8 6.5 5.2"/><path d="M9 20v-3"/><path d="M15 20v-3"/>',
			'drop'        => '<path d="M12 3.5s5.5 6 5.5 9.7A5.5 5.5 0 0 1 6.5 13.2C6.5 9.5 12 3.5 12 3.5z"/>',
			'kitchen'     => '<ellipse cx="12" cy="14" rx="7.5" ry="4.5"/><path d="M4.5 14c0-1 .5-2 1.5-2.5"/><path d="M9 7.5c0-1 1-1.5 1-2.5"/><path d="M12.5 7.5c0-1 1-1.5 1-2.5"/>',
			'balcony'     => '<path d="M4 11h16"/><path d="M5 11V6h14v5"/><path d="M4 11v8"/><path d="M20 11v8"/><path d="M9 11v8"/><path d="M15 11v8"/><path d="M3 19h18"/>',
			'leaf'        => '<path d="M5 19c0-8 5.5-13 15-13 0 9-5 14-11 14a5 5 0 0 1-4-1z"/><path d="M9 15c2-3 4.5-5 8-6.5"/>',
			'pool'        => '<path d="M3 17.5c1.5 0 1.5 1.2 3 1.2s1.5-1.2 3-1.2 1.5 1.2 3 1.2 1.5-1.2 3-1.2 1.5 1.2 3 1.2 1.5-1.2 3-1.2"/><path d="M7 15V5.5A1.5 1.5 0 0 1 10 5.5"/><path d="M15 15V5.5A1.5 1.5 0 0 1 18 5.5"/><path d="M7 10h8"/>',
			'gym'         => '<path d="M4 9v6"/><path d="M20 9v6"/><path d="M7 6.5v11"/><path d="M17 6.5v11"/><path d="M7 12h10"/>',
			'columns'     => '<path d="M3 20h18"/><path d="M4.5 8 12 3.5 19.5 8"/><path d="M4 8h16"/><path d="M7 8v9"/><path d="M12 8v9"/><path d="M17 8v9"/>',

			/* --------------------------------------- Property nearby */

			'metro'       => '<rect x="5" y="4" width="14" height="12" rx="3"/><path d="M5 10h14"/><circle cx="9" cy="13" r="1"/><circle cx="15" cy="13" r="1"/><path d="m7 20 2-4"/><path d="m17 20-2-4"/>',
			'school'      => '<path d="m12 4 9 4-9 4-9-4z"/><path d="M7 10.5V16c0 1.5 2.5 3 5 3s5-1.5 5-3v-5.5"/>',
			'hospital'    => '<rect x="4" y="6" width="16" height="14" rx="2"/><path d="M12 10v6"/><path d="M9 13h6"/><path d="M9 6V4h6v2"/>',
			'cart'        => '<path d="M3 4h2l2.5 11h10L20 7H6"/><circle cx="9" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/>',
			'plane'       => '<path d="M3 12.5 21 5l-4.5 8.5L21 19l-7-2.5-3.5 4-.5-4.5z"/>',

			/* ---------------------------------------- Property money */

			'trend-up'    => '<path d="M3 17 9.5 10.5l4 4L21 7"/><path d="M15.5 7H21v5.5"/>',
			'handshake'   => '<path d="m3 12 3-3 4 4 2-1.5 2 1.5 4-4 3 3"/><path d="M6 9V7h5"/><path d="M18 9V7h-5"/><path d="m10 13 2 2 2-2"/>',
			'no-fee'      => '<circle cx="12" cy="12" r="8.5"/><path d="m6 6 12 12"/>',
		);
	}

	/**
	 * Draw an icon.
	 *
	 * @param string $name  Icon name.
	 * @param int    $size  Pixel size.
	 * @param string $class Extra class names.
	 * @return string Safe SVG markup, or an empty string for an unknown name.
	 */
	public static function render( string $name, int $size = 20, string $class = '' ): string {
		$paths = self::paths();

		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}

		$size    = max( 12, min( 64, $size ) );
		$classes = trim( 'estat-icon ' . $class );

		return sprintf(
			'<svg class="%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%3$s</svg>',
			esc_attr( $classes ),
			$size,
			$paths[ $name ] // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static path data defined above.
		);
	}

	/**
	 * Is this a name we can draw?
	 *
	 * @param string $name Icon name.
	 * @return bool
	 */
	public static function has( string $name ): bool {
		return isset( self::paths()[ $name ] );
	}
}
