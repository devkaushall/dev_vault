<?php
/**
 * Practice mode: clearly marked demo records with one-click cleanup.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Data\Agents;
use EstatOS\Install\Schema;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Practice records carry the _estat_practice flag and a visible PRACTICE badge,
 * so they can never be mistaken for real business data.
 */
final class PracticeMode {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_filter( 'the_title', array( __CLASS__, 'badge_title' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	/**
	 * Whether practice mode is on.
	 *
	 * @return bool
	 */
	public static function active(): bool {
		return (bool) Settings::get( 'practice_mode', false );
	}

	/**
	 * Add a PRACTICE badge to practice record titles.
	 *
	 * @param string $title   Title.
	 * @param int    $post_id Post ID.
	 * @return string
	 */
	public static function badge_title( $title, $post_id = 0 ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 || ! in_array( get_post_type( $post_id ), PostTypes::all(), true ) ) {
			return $title;
		}
		if ( ! get_post_meta( $post_id, '_estat_practice', true ) ) {
			return $title;
		}
		return '[' . __( 'PRACTICE', 'estat-os' ) . '] ' . $title;
	}

	/**
	 * Persistent reminder while practice mode is on.
	 *
	 * @return void
	 */
	public static function notice(): void {
		if ( ! self::active() || ! current_user_can( 'estat_manage_listings' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false === strpos( (string) $screen->id, 'estat' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Practice mode is on.', 'estat-os' ) . '</strong> ';
		esc_html_e( 'Anything you add now is marked PRACTICE and can be removed in one click from Office Settings.', 'estat-os' );
		echo '</p></div>';
	}

	/**
	 * Create a small set of neutral practice records.
	 *
	 * @return array<string,int> Counts created.
	 */
	public static function seed(): array {
		$created = array( 'listings' => 0, 'projects' => 0, 'agents' => 0 );

		$agent_id = Agents::save(
			array(
				'title'  => __( 'Practice Agent', 'estat-os' ),
				'role'   => __( 'Sales', 'estat-os' ),
				'phone'  => '+10000000000',
				'email'  => 'agent@example.com',
			)
		);
		if ( ! is_wp_error( $agent_id ) ) {
			update_post_meta( (int) $agent_id, '_estat_practice', 1 );
			++$created['agents'];
		}

		$project_id = Projects::save(
			array(
				'title'          => __( 'Practice Residency', 'estat-os' ),
				'description'    => __( 'A sample society used for practice. Delete it whenever you like.', 'estat-os' ),
				'project_status' => 'ready',
				'total_units'    => 120,
				'available_units'=> 14,
			)
		);
		if ( ! is_wp_error( $project_id ) ) {
			update_post_meta( (int) $project_id, '_estat_practice', 1 );
			++$created['projects'];
		}

		$samples = array(
			array( 'title' => __( 'Practice: 2 BHK apartment with a park view', 'estat-os' ), 'offer' => 'sale', 'type' => 'apartment', 'price' => 6500000, 'area' => 950, 'beds' => 2 ),
			array( 'title' => __( 'Practice: 3 BHK builder floor near the market', 'estat-os' ), 'offer' => 'rent', 'type' => 'builder_floor', 'rent' => 32000, 'area' => 1400, 'beds' => 3 ),
			array( 'title' => __( 'Practice: corner shop on the main road', 'estat-os' ), 'offer' => 'lease', 'type' => 'commercial_shop', 'rent' => 55000, 'area' => 400, 'beds' => 0 ),
		);
		foreach ( $samples as $sample ) {
			$listing_id = Listings::save(
				array(
					'title'         => $sample['title'],
					'status'        => 'draft',
					'description'   => __( 'This is practice information so you can try the system safely. It is not a real property.', 'estat-os' ),
					'offer'         => $sample['offer'],
					'property_type' => $sample['type'],
					'price'         => $sample['price'] ?? 0,
					'rent'          => $sample['rent'] ?? 0,
					'area'          => $sample['area'],
					'area_unit'     => 'sqft',
					'bedrooms'      => $sample['beds'],
					'locality'      => array( __( 'Practice Locality', 'estat-os' ) ),
					'agent_id'      => is_wp_error( $agent_id ) ? 0 : (int) $agent_id,
					'project_id'    => is_wp_error( $project_id ) ? 0 : (int) $project_id,
				)
			);
			if ( ! is_wp_error( $listing_id ) ) {
				update_post_meta( (int) $listing_id, '_estat_practice', 1 );
				SearchIndex::index_listing( (int) $listing_id );
				++$created['listings'];
			}
		}

		AuditLog::record( 'practice.seeded', 'practice', 0, $created );
		return $created;
	}

	/**
	 * Remove every practice record. Real data is never touched.
	 *
	 * @return array<string,int> Counts removed.
	 */
	public static function clear(): array {
		global $wpdb;
		$removed = array( 'posts' => 0, 'leads' => 0, 'visits' => 0, 'submissions' => 0 );

		$ids = get_posts(
			array(
				'post_type'      => PostTypes::all(),
				'post_status'    => 'any',
				'posts_per_page' => 1000,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => '_estat_practice', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		foreach ( $ids as $id ) {
			wp_delete_post( (int) $id, true );
			++$removed['posts'];
		}

		if ( Schema::healthy() ) {
			foreach ( array( 'estat_leads' => 'leads', 'estat_visits' => 'visits', 'estat_submissions' => 'submissions' ) as $table => $key ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$removed[ $key ] = (int) $wpdb->delete( Schema::table( $table ), array( 'practice' => 1 ), array( '%d' ) );
			}
		}

		AuditLog::record( 'practice.cleared', 'practice', 0, $removed );
		return $removed;
	}
}
