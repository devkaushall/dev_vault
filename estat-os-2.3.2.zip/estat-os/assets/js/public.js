/**
 * Estat.OS — favorites and property comparison.
 * Guest choices live in localStorage; nothing personal is stored.
 */
( function () {
	'use strict';

	var settings = window.estatPublic || { i18n: {} };
	var FAV_KEY = 'estat_favorites';
	var CMP_KEY = 'estat_compare';
	var MAX_COMPARE = 4;

	function read( key ) {
		try {
			var raw = window.localStorage.getItem( key );
			var list = raw ? JSON.parse( raw ) : [];
			return Array.isArray( list ) ? list.filter( function ( id ) {
				return typeof id === 'number' && id > 0;
			} ) : [];
		} catch ( e ) {
			return [];
		}
	}

	function write( key, list ) {
		try {
			window.localStorage.setItem( key, JSON.stringify( list.slice( 0, 100 ) ) );
		} catch ( e ) {
			/* storage may be full or blocked; the page still works */
		}
	}

	function toggle( key, id, limit ) {
		var list = read( key );
		var index = list.indexOf( id );
		if ( index !== -1 ) {
			list.splice( index, 1 );
		} else {
			if ( limit && list.length >= limit ) {
				return { list: list, added: false, full: true };
			}
			list.push( id );
		}
		write( key, list );
		return { list: list, added: index === -1, full: false };
	}

	function syncButtons() {
		var favorites = read( FAV_KEY );
		var compares = read( CMP_KEY );
		document.querySelectorAll( '.estat-fav' ).forEach( function ( button ) {
			var id = parseInt( button.getAttribute( 'data-listing' ), 10 );
			button.setAttribute( 'aria-pressed', favorites.indexOf( id ) !== -1 ? 'true' : 'false' );
		} );
		document.querySelectorAll( '.estat-compare' ).forEach( function ( button ) {
			var id = parseInt( button.getAttribute( 'data-listing' ), 10 );
			button.setAttribute( 'aria-pressed', compares.indexOf( id ) !== -1 ? 'true' : 'false' );
		} );
	}

	function renderCompare() {
		var panel = document.querySelector( '#estat-compare-panel .estat-compare-table' );
		if ( ! panel ) {
			return;
		}
		var ids = read( CMP_KEY );
		if ( ! ids.length ) {
			panel.innerHTML = '';
			return;
		}
		Promise.all( ids.map( function ( id ) {
			return fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
				return r.ok ? r.json() : null;
			} ).catch( function () {
				return null;
			} );
		} ) ).then( function ( items ) {
			items = items.filter( Boolean );
			if ( ! items.length ) {
				panel.innerHTML = '';
				return;
			}
			var rows = [
				[ 'Price', 'price_display' ],
				[ 'Bedrooms', 'bedrooms' ],
				[ 'Bathrooms', 'bathrooms' ],
				[ 'Parking', 'parking' ],
				[ 'Floor', 'floor' ],
				[ 'Furnishing', 'furnishing' ],
				[ 'Type', 'property_type' ],
				[ 'Availability', 'availability' ]
			];
			var table = document.createElement( 'table' );
			var head = document.createElement( 'tr' );
			head.appendChild( document.createElement( 'th' ) );
			items.forEach( function ( item ) {
				var th = document.createElement( 'th' );
				var link = document.createElement( 'a' );
				link.href = item.url;
				link.textContent = item.title;
				th.appendChild( link );
				head.appendChild( th );
			} );
			table.appendChild( head );

			rows.forEach( function ( row ) {
				var tr = document.createElement( 'tr' );
				var label = document.createElement( 'th' );
				label.scope = 'row';
				label.textContent = row[ 0 ];
				tr.appendChild( label );
				items.forEach( function ( item ) {
					var td = document.createElement( 'td' );
					var value = item[ row[ 1 ] ];
					td.textContent = ( value === null || value === '' || value === 0 ) ? '—' : String( value );
					tr.appendChild( td );
				} );
				table.appendChild( tr );
			} );

			panel.innerHTML = '';
			panel.appendChild( table );
		} );
	}

	function renderFavorites() {
		var section = document.querySelector( '#estat-favorites .estat-grid' );
		if ( ! section ) {
			return;
		}
		var ids = read( FAV_KEY );
		if ( ! ids.length ) {
			section.innerHTML = '';
			return;
		}
		Promise.all( ids.map( function ( id ) {
			return fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
				return r.ok ? r.json() : null;
			} ).catch( function () {
				return null;
			} );
		} ) ).then( function ( items ) {
			section.innerHTML = '';
			items.filter( Boolean ).forEach( function ( item ) {
				var card = document.createElement( 'article' );
				card.className = 'estat-card';
				var body = document.createElement( 'div' );
				body.className = 'estat-card-body';
				var title = document.createElement( 'h3' );
				title.className = 'estat-card-title';
				var link = document.createElement( 'a' );
				link.href = item.url;
				link.textContent = item.title;
				title.appendChild( link );
				var price = document.createElement( 'p' );
				price.className = 'estat-card-price';
				price.textContent = item.price_display || '';
				body.appendChild( title );
				body.appendChild( price );
				card.appendChild( body );
				section.appendChild( card );
			} );
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		var fav = event.target.closest ? event.target.closest( '.estat-fav' ) : null;
		if ( fav ) {
			toggle( FAV_KEY, parseInt( fav.getAttribute( 'data-listing' ), 10 ), 0 );
			syncButtons();
			renderFavorites();
			return;
		}
		var cmp = event.target.closest ? event.target.closest( '.estat-compare' ) : null;
		if ( cmp ) {
			var result = toggle( CMP_KEY, parseInt( cmp.getAttribute( 'data-listing' ), 10 ), MAX_COMPARE );
			if ( result.full ) {
				window.alert( ( settings.i18n && settings.i18n.compareFull ) || 'You can compare up to four properties at a time.' );
				return;
			}
			syncButtons();
			renderCompare();
		}
	} );

	document.addEventListener( 'DOMContentLoaded', function () {
		syncButtons();
		renderCompare();
		renderFavorites();
	} );
}() );
