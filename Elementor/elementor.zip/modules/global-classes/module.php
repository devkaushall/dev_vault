<?php

namespace Elementor\Modules\GlobalClasses;

use Elementor\Core\Base\Module as BaseModule;
use Elementor\Core\Experiments\Manager as Experiments_Manager;
use Elementor\Modules\AtomicWidgets\Module as Atomic_Widgets_Module;
use Elementor\Modules\DesignSystemSync\Classes\Global_Classes_Sync_Map;
use Elementor\Modules\GlobalClasses\Database\Global_Classes_Database_Updater;
use Elementor\Modules\GlobalClasses\ImportExport\Import_Export;
use Elementor\Modules\GlobalClasses\ImportExportCustomization\Import_Export_Customization;
use Elementor\Modules\GlobalClasses\Utils\Template_Library_Global_Classes;
use Elementor\Modules\GlobalClasses\Usage\Global_Classes_Usage;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Module extends BaseModule {
	const NAME = Atomic_Widgets_Module::EXPERIMENT_NAME;
	const PACKAGES = [
		'editor-global-classes',
	];

	public function get_name() {
		return 'global-classes';
	}

	public function __construct() {
		parent::__construct();

		$is_atomic_widgets_active = Plugin::$instance->experiments->is_feature_active( Atomic_Widgets_Module::EXPERIMENT_NAME );

		if ( $is_atomic_widgets_active ) {
			( new Global_Class_Post_Type() )->register();
			( new Global_Classes_Post_IDs() )->register_hooks();

			$relations = new Global_Classes_Relations();
			$relations->register_hooks();

			add_filter( 'elementor/editor/v2/packages', fn( $packages ) => $this->add_packages( $packages ) );

			( new Global_Classes_Usage() )->register_hooks();
			( new Global_Classes_REST_API() )->register_hooks();
			( new Atomic_Global_Styles( $relations ) )->register_hooks();
			( new Global_Classes_Cleanup() )->register_hooks();
			( new Import_Export() )->register_hooks();
			( new Import_Export_Customization() )->register_hooks();
			( new Global_Classes_Database_Updater() )->register();

			add_filter(
				'elementor/template_library/export/build_snapshots',
				[ Template_Library_Global_Classes::class, 'add_global_classes_snapshot' ],
				10,
				4
			);

			add_filter(
				'elementor/template_library/get_data/extract_snapshots',
				[ Template_Library_Global_Classes::class, 'extract_global_classes_from_data' ],
				10,
				3
			);

			add_filter(
				'elementor/template_library/import/process_content',
				[ Template_Library_Global_Classes::class, 'process_global_classes_import' ],
				20,
				3
			);

			add_filter(
				'elementor/kit/meta_to_preserve_on_kit_import',
				[ $this, 'add_meta_to_preserve_on_kit_import' ]
			);

			add_action( 'elementor/kit/after_new_kit_created', [ $this, 'create_global_classes_posts_for_new_kit' ], 10, 1 );
		}
	}

	public function add_meta_to_preserve_on_kit_import( array $meta_keys ): array {
		return array_merge( $meta_keys, [
			Global_Classes_Order::META_KEY,
			Global_Classes_Order::META_KEY_PREVIEW,
			Global_Classes_Labels::META_KEY_FRONTEND,
			Global_Classes_Labels::META_KEY_PREVIEW,
			Global_Classes_Relations::META_KEY_FRONTEND,
			Global_Classes_Relations::META_KEY_PREVIEW,
			Global_Classes_Relations::META_KEY_USAGE_INDEXED_FRONTEND,
			Global_Classes_Relations::META_KEY_USAGE_INDEXED_PREVIEW,
			Global_Classes_Relations::META_KEY_CLASS_RELATED_POSTS_FRONTEND,
			Global_Classes_Relations::META_KEY_CLASS_RELATED_POSTS_PREVIEW,
			Global_Classes_Sync_Map::META_KEY,
		] );
	}

	/**
	 * Duplicates global classes posts from the previous kit to the new kit, after a new kit is created.
	 * So each kit has its own, separate, global classes posts, and editing one kit's classes will not affect the other kits.
	 *
	 * @param array $params The parameters passed to the action - 'new_kit_id' and 'previous_kit_id'.
	 * @return void
	 */
	public function create_global_classes_posts_for_new_kit( array $params ): void {
		[ 'new_kit_id' => $new_kit_id, 'previous_kit_id' => $previous_kit_id ] = $params;

		$previous_kit = Plugin::$instance->kits_manager->get_kit( $previous_kit_id );
		$new_kit = Plugin::$instance->kits_manager->get_kit( $new_kit_id );

		if ( ! $previous_kit || ! $new_kit ) {
			return;
		}

		$preview_order = Global_Classes_Order::make( $previous_kit )->set_preview( true )->get_order();
		$frontend_order = Global_Classes_Order::make( $previous_kit )->set_preview( false )->get_order();
		$all_classes = array_unique( array_merge( $preview_order, $frontend_order ) );

		foreach ( $all_classes as $class_id ) {
			Global_Class_Post::clone_to_other_kit( $class_id, $previous_kit, $new_kit );
		}
	}

	private function add_packages( $packages ) {
		return array_merge( $packages, self::PACKAGES );
	}
}
