<?php
/**
 * Search Alerts — F4: visitor watches a search, gets email when match goes live.
 *
 * the office requirement: "Search alerts — visitor apni search watch kare,
 * matching listing live hote hi email."
 *
 * F4 spec: table {prefix}estat_alerts with query json, frequency instant|daily,
 * token, confirmed, phone, email, unsubscribed_at. Supports both old
 * estat_search_alerts (BC) and new estat_alerts (primary).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Search;

use EstatOS\Data\Listings;
use EstatOS\Install\Schema;
use EstatOS\Support\Sanitize;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Alerts {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'estat_listing_published', array( __CLASS__, 'on_listing_published' ), 10, 2 );
		add_action( 'estat_listing_verified', array( __CLASS__, 'on_listing_published' ), 10, 1 );
		add_action( 'estat_daily_housekeeping', array( __CLASS__, 'process_queue' ) );
		add_action( 'init', array( __CLASS__, 'handle_confirm' ) );
		add_action( 'init', array( __CLASS__, 'handle_unsubscribe' ) );
		add_action( 'wp_head', array( __CLASS__, 'maybe_print_notice' ) );
	}

	/**
	 * Create a new alert — F4 writes to estat_alerts, also keeps old table for BC if needed.
	 *
	 * @param array<string,mixed> $input Raw input: email, name, phone, filters|query, frequency, source_url.
	 * @return int|\WP_Error Alert ID or error.
	 */
	public static function create( array $input ) {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return new \WP_Error( 'estat_no_storage', __( 'The office database is not ready yet.', 'estat-os' ) );
		}

		$email = Sanitize::email( $input['email'] ?? '' );
		if ( '' === $email ) {
			return new \WP_Error( 'estat_invalid_email', __( 'Please provide a valid email address.', 'estat-os' ) );
		}
		$phone = Sanitize::phone( $input['phone'] ?? '' );
		$name  = Sanitize::text( $input['name'] ?? '' );
		$frequency = Sanitize::choice( $input['frequency'] ?? 'instant', array( 'instant', 'daily' ), 'instant' );
		$source_url = Sanitize::url( $input['source_url'] ?? '' );

		// Query may come as filters or query.
		$raw_query = $input['query'] ?? $input['filters'] ?? array();
		if ( is_string( $raw_query ) ) {
			$decoded = json_decode( $raw_query, true );
			$raw_query = is_array( $decoded ) ? $decoded : array();
		}
		$filters = is_array( $raw_query ) ? Query::normalize( $raw_query ) : array();

		// Remove empty for hash stability, but keep normalized shape.
		$hash_input = array_filter( $filters, static function ( $v ) {
			return '' !== $v && array() !== $v && 0 !== $v && 0.0 !== $v && false !== $v && null !== $v;
		} );
		$hash = hash( 'sha256', wp_json_encode( $hash_input ) . '|' . strtolower( $email ) . '|' . $frequency );

		// New table primary.
		$new_table = Schema::table( 'estat_alerts' );
		$old_table = Schema::table( 'estat_search_alerts' );

		// Prevent exact duplicate active alert in new table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing_new = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$new_table} WHERE email = %s AND token != '' AND unsubscribed_at IS NULL ORDER BY id DESC LIMIT 1", $email ) );
		// More precise dedupe by query hash via PHP loop to avoid JSON search complexity.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, query FROM {$new_table} WHERE email = %s AND unsubscribed_at IS NULL", $email ), ARRAY_A );
		if ( $rows ) {
			foreach ( $rows as $r ) {
				$q = json_decode( (string) $r['query'], true );
				if ( ! is_array( $q ) ) { continue; }
				$qh = array_filter( $q, static function ( $v ) { return '' !== $v && array() !== $v && 0 !== $v && 0.0 !== $v && false !== $v && null !== $v; } );
				$existing_hash = hash( 'sha256', wp_json_encode( $qh ) . '|' . strtolower( $email ) . '|' . ( $q['frequency'] ?? $frequency ) );
				// If same filters hash, return existing.
				if ( $existing_hash === $hash ) {
					return (int) $r['id'];
				}
			}
		}

		// Prevent duplicate in old table too.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing_old = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$old_table} WHERE email = %s AND filters_hash = %s AND active = 1 LIMIT 1", $email, $hash ) );
		if ( $existing_old ) {
			// Migrate to new table as well for F4.
			// Continue to create new entry for unified system, but return old if no new created.
		}

		$now = current_time( 'mysql', true );
		$token = bin2hex( random_bytes( 32 ) );

		// Embed frequency inside query json for easier matching.
		$filters['frequency'] = $frequency;

		$row = array(
			'email'      => $email,
			'phone'      => $phone,
			'query'      => wp_json_encode( $filters ),
			'frequency'  => $frequency,
			'confirmed'  => 0,
			'token'      => $token,
			'created_at' => $now,
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert( $new_table, $row );
		$id = (int) $wpdb->insert_id;

		if ( ! $id ) {
			// Fallback to old table if new fails (BC).
			$old_row = array(
				'created_at'    => $now,
				'updated_at'    => $now,
				'email'         => $email,
				'name'          => $name,
				'filters'       => wp_json_encode( $filters ),
				'filters_hash'  => $hash,
				'active'        => 1,
				'confirmed'     => 0,
				'confirm_token' => $token,
				'source_url'    => $source_url,
			);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->insert( $old_table, $old_row );
			$id = (int) $wpdb->insert_id;
			if ( $id ) {
				self::send_confirmation_old( $id );
				do_action( 'estat_alert_created', $id, array( 'email' => $email, 'filters' => $filters ) );
			}
			return $id ?: new \WP_Error( 'estat_save_failed', __( 'Could not save alert.', 'estat-os' ) );
		}

		// Also keep name in old table? Store in query for new table name is inside query? We keep separate for email personalization.
		// For new table we don't have name column, but we can store name inside query json as _name for email.
		$filters['_name'] = $name;
		$filters['_source_url'] = $source_url;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update( $new_table, array( 'query' => wp_json_encode( $filters ) ), array( 'id' => $id ) );

		self::send_confirmation_new( $id );

		do_action( 'estat_alert_created', $id, array( 'email' => $email, 'filters' => $filters ) );

		return $id;
	}

	/**
	 * Confirm via token — handles both tables and both param names.
	 *
	 * @return void
	 */
	public static function handle_confirm(): void {
		$token = '';
		if ( isset( $_GET['estat_confirm_alert'] ) ) {
			$token = sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_confirm_alert']) ? '' : $_GET['estat_confirm_alert'] ) ) );
		} elseif ( isset( $_GET['estat_confirm_alert_v2'] ) ) {
			$token = sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_confirm_alert_v2']) ? '' : $_GET['estat_confirm_alert_v2'] ) ) );
		} elseif ( isset( $_GET['confirm_alert'] ) ) {
			$token = sanitize_text_field( wp_unslash( (string) ( is_array($_GET['confirm_alert']) ? '' : $_GET['confirm_alert'] ) ) );
		}
		if ( '' === $token ) {
			return;
		}
		global $wpdb;
		$new_table = Schema::table( 'estat_alerts' );
		$old_table = Schema::table( 'estat_search_alerts' );

		// New table first.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id_new = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$new_table} WHERE token = %s LIMIT 1", $token ) );
		if ( $id_new ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $new_table, array( 'confirmed' => 1 ), array( 'id' => $id_new ) );
			wp_safe_redirect( add_query_arg( 'alert_confirmed', '1', home_url( '/' ) ) );
			exit;
		}
		// Old table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id_old = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$old_table} WHERE confirm_token = %s LIMIT 1", $token ) );
		if ( $id_old ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $old_table, array( 'confirmed' => 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id_old ) );
			wp_safe_redirect( add_query_arg( 'alert_confirmed', '1', home_url( '/' ) ) );
			exit;
		}
	}

	/**
	 * Unsubscribe via token.
	 *
	 * @return void
	 */
	public static function handle_unsubscribe(): void {
		$token = '';
		if ( isset( $_GET['estat_unsubscribe_alert'] ) ) {
			$token = sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_unsubscribe_alert']) ? '' : $_GET['estat_unsubscribe_alert'] ) ) );
		} elseif ( isset( $_GET['unsubscribe_alert'] ) ) {
			$token = sanitize_text_field( wp_unslash( (string) ( is_array($_GET['unsubscribe_alert']) ? '' : $_GET['unsubscribe_alert'] ) ) );
		}
		if ( '' === $token ) {
			return;
		}
		global $wpdb;
		$new_table = Schema::table( 'estat_alerts' );
		$old_table = Schema::table( 'estat_search_alerts' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id_new = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$new_table} WHERE token = %s LIMIT 1", $token ) );
		if ( $id_new ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $new_table, array( 'unsubscribed_at' => current_time( 'mysql', true ) ), array( 'id' => $id_new ) );
			wp_safe_redirect( add_query_arg( 'alert_unsubscribed', '1', home_url( '/' ) ) );
			exit;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id_old = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$old_table} WHERE confirm_token = %s LIMIT 1", $token ) );
		if ( $id_old ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $old_table, array( 'active' => 0, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id_old ) );
			wp_safe_redirect( add_query_arg( 'alert_unsubscribed', '1', home_url( '/' ) ) );
			exit;
		}
	}

	/**
	 * Send confirmation email — new table.
	 *
	 * @param int $alert_id Alert ID.
	 * @return void
	 */
	private static function send_confirmation_new( int $alert_id ): void {
		global $wpdb;
		$table = Schema::table( 'estat_alerts' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $alert_id ), ARRAY_A );
		if ( ! $row ) { return; }
		$q = json_decode( (string) $row['query'], true );
		$name = $q['_name'] ?? 'there';
		$confirm_url = add_query_arg( 'estat_confirm_alert_v2', $row['token'], home_url( '/' ) );
		$subject = sprintf( __( 'Confirm your property alert — %s', 'estat-os' ), get_bloginfo( 'name' ) );
		$body = sprintf(
			"Hi %s,\n\nYou asked to watch properties matching your search.\n\nConfirm here: %s\n\nYou will get an email when a matching home goes live (%s alerts). Unsubscribe anytime: %s\n\n— %s",
			$name,
			$confirm_url,
			$row['frequency'],
			add_query_arg( 'estat_unsubscribe_alert', $row['token'], home_url( '/' ) ),
			get_bloginfo( 'name' )
		);
		self::mail( $row['email'], $subject, $body );
	}

	/**
	 * Send confirmation email — old table.
	 *
	 * @param int $alert_id Alert ID.
	 * @return void
	 */
	private static function send_confirmation_old( int $alert_id ): void {
		global $wpdb;
		$table = Schema::table( 'estat_search_alerts' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $alert_id ), ARRAY_A );
		if ( ! $row ) { return; }
		$confirm_url = add_query_arg( 'estat_confirm_alert', $row['confirm_token'], home_url( '/' ) );
		$subject = sprintf( __( 'Confirm your property alert — %s', 'estat-os' ), get_bloginfo( 'name' ) );
		$body = sprintf(
			"Hi %s,\n\nYou asked to watch properties matching your search.\n\nConfirm here: %s\n\nYou will get an email when a matching home goes live. Unsubscribe anytime.\n\n— %s",
			$row['name'] ?: 'there',
			$confirm_url,
			get_bloginfo( 'name' )
		);
		self::mail( $row['email'], $subject, $body );
	}

	/**
	 * When a listing is published or verified, find matching alerts and email instant ones.
	 *
	 * @param int   $listing_id Listing ID.
	 * @param array $data       Listing data (optional).
	 * @return void
	 */
	public static function on_listing_published( int $listing_id, array $data = array() ): void {
		global $wpdb;
		if ( ! Schema::healthy() ) { return; }
		if ( ! Settings::get( 'search_alerts_enabled', true ) ) { return; }

		$new_table = Schema::table( 'estat_alerts' );
		$old_table = Schema::table( 'estat_search_alerts' );

		$listing_filters = self::listing_to_filters( $listing_id );

		// New table — instant only, confirmed, not unsubscribed.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$alerts_new = $wpdb->get_results( "SELECT * FROM {$new_table} WHERE confirmed = 1 AND unsubscribed_at IS NULL AND frequency = 'instant'", ARRAY_A );
		if ( $alerts_new ) {
			foreach ( $alerts_new as $alert ) {
				$q = json_decode( (string) $alert['query'], true );
				if ( ! is_array( $q ) ) { continue; }
				// Avoid duplicate send for same listing if last_sent was same listing today.
				if ( ! empty( $alert['last_sent_at'] ) && strtotime( (string) $alert['last_sent_at'] ) > time() - 3600 ) {
					// Simple throttle: if we sent within last hour, check if same listing would have been sent — skip if last query matched same? For F4 we skip throttle by storing last listing via transient.
					// We'll store last_listing_id in query meta for simplicity.
					$last_id = $q['_last_listing_id'] ?? 0;
					if ( (int) $last_id === $listing_id ) { continue; }
				}
				if ( ! self::matches( $listing_filters, $q ) ) { continue; }

				self::send_alert_email_new( $alert, $listing_id );

				// Update last_sent_at and store last listing id inside query json.
				$q['_last_listing_id'] = $listing_id;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->update(
					$new_table,
					array(
						'last_sent_at' => current_time( 'mysql', true ),
						'query'        => wp_json_encode( $q ),
					),
					array( 'id' => (int) $alert['id'] )
				);
			}
		}

		// Old table — active and confirmed.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$alerts_old = $wpdb->get_results( "SELECT * FROM {$old_table} WHERE active = 1 AND confirmed = 1", ARRAY_A );
		if ( ! $alerts_old ) { return; }

		foreach ( $alerts_old as $alert ) {
			$filters = json_decode( (string) $alert['filters'], true );
			if ( ! is_array( $filters ) ) { continue; }
			if ( ! self::matches( $listing_filters, $filters ) ) { continue; }
			if ( (int) $alert['last_listing_id'] === $listing_id ) { continue; }

			self::send_alert_email_old( $alert, $listing_id );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$old_table,
				array(
					'last_sent_at'    => current_time( 'mysql', true ),
					'last_listing_id' => $listing_id,
					'send_count'      => (int) $alert['send_count'] + 1,
					'updated_at'      => current_time( 'mysql', true ),
				),
				array( 'id' => (int) $alert['id'] )
			);
		}
	}

	/**
	 * Process queue daily — send digest for daily alerts.
	 *
	 * @return void
	 */
	public static function process_queue(): void {
		global $wpdb;
		if ( ! Schema::healthy() ) { return; }
		if ( ! Settings::get( 'search_alerts_enabled', true ) ) { return; }

		$new_table = Schema::table( 'estat_alerts' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$daily_alerts = $wpdb->get_results( "SELECT * FROM {$new_table} WHERE confirmed = 1 AND unsubscribed_at IS NULL AND frequency = 'daily'", ARRAY_A );
		if ( ! $daily_alerts ) { return; }

		// Find listings published in last 24h.
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$recent_ids = get_posts( array(
			'post_type'      => 'estat_listing',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'date_query'     => array( array( 'after' => $since ) ),
			'fields'         => 'ids',
		) );

		if ( ! $recent_ids ) { return; }

		// Precompute filters for each recent listing.
		$listing_filters_map = array();
		foreach ( $recent_ids as $lid ) {
			$listing_filters_map[ $lid ] = self::listing_to_filters( (int) $lid );
		}

		foreach ( $daily_alerts as $alert ) {
			$q = json_decode( (string) $alert['query'], true );
			if ( ! is_array( $q ) ) { continue; }

			// Skip if already sent today.
			if ( ! empty( $alert['last_sent_at'] ) && strtotime( (string) $alert['last_sent_at'] ) > time() - 20 * HOUR_IN_SECONDS ) {
				continue;
			}

			$matched = array();
			foreach ( $listing_filters_map as $lid => $lf ) {
				if ( self::matches( $lf, $q ) ) {
					$matched[] = $lid;
				}
			}
			if ( ! $matched ) { continue; }

			self::send_digest_email( $alert, $matched );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$new_table,
				array( 'last_sent_at' => current_time( 'mysql', true ) ),
				array( 'id' => (int) $alert['id'] )
			);
		}
	}

	/**
	 * Convert listing to filter shape for matching — uses index + meta.
	 *
	 * @param int $listing_id Listing ID.
	 * @return array<string,mixed>
	 */
	private static function listing_to_filters( int $listing_id ): array {
		$meta = get_post_meta( $listing_id );
		$get = static function ( string $k ) use ( $meta ) {
			return $meta[ $k ][0] ?? '';
		};

		// Try index for locality_ids.
		global $wpdb;
		$index_table = Schema::table( 'estat_index' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$index_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$index_table} WHERE post_id = %d LIMIT 1", $listing_id ), ARRAY_A );

		$locality_ids = array();
		if ( $index_row && ! empty( $index_row['locality_ids'] ) ) {
			$locality_ids = array_filter( array_map( 'intval', explode( ',', trim( (string) $index_row['locality_ids'], ',' ) ) ) );
		}

		$price = (float) $get( '_estat_price' );
		if ( 0 === $price ) {
			$price = $index_row ? (float) ( $index_row['price'] ?? 0 ) : 0;
		}

		// F9: fetch amenities & features ids for matching.
		$amenities_ids = wp_get_object_terms( $listing_id, \EstatOS\Data\Taxonomies::AMENITY, array( 'fields' => 'ids' ) ); if (is_wp_error($amenities_ids)) $amenities_ids = array();
		$amenities_ids = is_wp_error( $amenities_ids ) ? array() : array_map( 'intval', $amenities_ids );
		$features_ids = wp_get_object_terms( $listing_id, \EstatOS\Data\Taxonomies::FEATURE, array( 'fields' => 'ids' ) ); if (is_wp_error($features_ids)) $features_ids = array();
		$features_ids = is_wp_error( $features_ids ) ? array() : array_map( 'intval', $features_ids );

		return array(
			'property_type'    => (string) $get( '_estat_property_type' ),
			'offer'            => (string) $get( '_estat_offer' ),
			'bedrooms'         => (int) $get( '_estat_bedrooms' ),
			'bedrooms_min'     => (int) $get( '_estat_bedrooms' ),
			'bedrooms_max'     => (int) $get( '_estat_bedrooms' ),
			'bathrooms_min'    => (int) $get( '_estat_bathrooms' ),
			'price'            => $price,
			'price_min'        => $price,
			'price_max'        => $price,
			'area'             => (float) $get( '_estat_area' ),
			'area_min'         => (float) $get( '_estat_area' ),
			'area_max'         => (float) $get( '_estat_area' ),
			'locality'         => $locality_ids,
			'locality_ids'     => $locality_ids,
			'furnishing'       => (string) $get( '_estat_furnishing' ),
			'facing'           => (string) $get( '_estat_facing' ),
			'construction'     => (string) $get( '_estat_construction' ),
			'availability'     => (string) $get( '_estat_availability' ),
			'floor'            => (int) $get( '_estat_floor' ),
			'floor_min'        => (int) $get( '_estat_floor' ),
			'total_floors'     => (int) $get( '_estat_total_floors' ),
			'total_floors_min' => (int) $get( '_estat_total_floors' ),
			'parking'          => (int) $get( '_estat_parking' ),
			'parking_min'      => (int) $get( '_estat_parking' ),
			'balconies'        => (int) $get( '_estat_balconies' ),
			'balconies_min'    => (int) $get( '_estat_balconies' ),
			'age'              => (int) $get( '_estat_age' ),
			'age_max'          => (int) $get( '_estat_age' ),
			'possession'       => (string) $get( '_estat_possession_date' ),
			'verified'         => 'office_verified' === (string) $get( '_estat_verification' ),
			'featured'         => (bool) $get( '_estat_featured' ),
			'investment'       => (bool) $get( '_estat_investment' ),
			'project_id'       => (int) $get( '_estat_project_id' ),
			'agent_id'         => (int) $get( '_estat_agent_id' ),
			'amenities'        => $amenities_ids,
			'amenities_ids'    => $amenities_ids,
			'features'         => $features_ids,
			'features_ids'     => $features_ids,
		);
	}

	/**
	 * Does listing match alert filters? Supports 23 filters.
	 *
	 * @param array<string,mixed> $listing Listing filter shape.
	 * @param array<string,mixed> $alert   Alert filters (normalized).
	 * @return bool
	 */
	private static function matches( array $listing, array $alert ): bool {
		// Property type — alert may be array or string.
		if ( ! empty( $alert['property_type'] ) ) {
			$allowed = (array) $alert['property_type'];
			$allowed = array_filter( $allowed );
			if ( $allowed && ! in_array( $listing['property_type'], $allowed, true ) ) {
				return false;
			}
		}
		// Offer
		if ( ! empty( $alert['offer'] ) && $alert['offer'] !== $listing['offer'] ) {
			return false;
		}
		// Bedrooms min/max
		if ( ! empty( $alert['bedrooms_min'] ) && $listing['bedrooms'] < (int) $alert['bedrooms_min'] ) {
			return false;
		}
		if ( ! empty( $alert['bedrooms_max'] ) && $listing['bedrooms'] > (int) $alert['bedrooms_max'] ) {
			return false;
		}
		// Bathrooms min
		if ( ! empty( $alert['bathrooms_min'] ) && ( $listing['bathrooms_min'] ?? $listing['bedrooms'] ) < (int) $alert['bathrooms_min'] ) {
			return false;
		}
		// Price range — listing price must be within alert range if set.
		if ( ! empty( $alert['price_min'] ) && $listing['price'] < (float) $alert['price_min'] ) {
			return false;
		}
		if ( ! empty( $alert['price_max'] ) && $listing['price'] > (float) $alert['price_max'] ) {
			return false;
		}
		// Area range
		if ( ! empty( $alert['area_min'] ) && ( $listing['area'] ?? 0 ) < (float) $alert['area_min'] ) {
			return false;
		}
		if ( ! empty( $alert['area_max'] ) && ( $listing['area'] ?? 0 ) > (float) $alert['area_max'] ) {
			return false;
		}
		// Locality — if alert has locality ids, listing must intersect.
		if ( ! empty( $alert['locality'] ) ) {
			$alert_localities = array_map( 'intval', (array) $alert['locality'] );
			$listing_localities = (array) ( $listing['locality_ids'] ?? $listing['locality'] ?? array() );
			$listing_localities = array_map( 'intval', $listing_localities );
			if ( $alert_localities && $listing_localities ) {
				if ( ! array_intersect( $alert_localities, $listing_localities ) ) {
					return false;
				}
			}
			// If alert has locality but listing has none, don't block (conservative) — but if listing has locality and no intersect, already blocked.
		}
		// Furnishing, facing, construction, availability, possession
		foreach ( array( 'furnishing', 'facing', 'construction', 'availability' ) as $k ) {
			if ( ! empty( $alert[ $k ] ) && $alert[ $k ] !== $listing[ $k ] ) {
				return false;
			}
		}
		// Floor min/max, total_floors, parking, balconies, age
		if ( ! empty( $alert['floor_min'] ) && ( $listing['floor'] ?? 0 ) < (int) $alert['floor_min'] ) { return false; }
		if ( ! empty( $alert['floor_max'] ) && ( $listing['floor'] ?? 0 ) > (int) $alert['floor_max'] ) { return false; }
		if ( ! empty( $alert['total_floors_min'] ) && ( $listing['total_floors'] ?? 0 ) < (int) $alert['total_floors_min'] ) { return false; }
		if ( ! empty( $alert['parking_min'] ) && ( $listing['parking'] ?? 0 ) < (int) $alert['parking_min'] ) { return false; }
		if ( ! empty( $alert['balconies_min'] ) && ( $listing['balconies'] ?? 0 ) < (int) $alert['balconies_min'] ) { return false; }
		if ( ! empty( $alert['age_max'] ) && ( $listing['age'] ?? 0 ) > (int) $alert['age_max'] ) { return false; }
		// Possession — if alert asks immediate, listing must be ready.
		if ( ! empty( $alert['possession'] ) && 'immediate' === $alert['possession'] ) {
			// If listing has possession date in future, no match.
			$poss = $listing['possession'] ?? '';
			if ( $poss && strtotime( $poss ) > time() ) { return false; }
		}
		// Verified only, featured, investment
		if ( ! empty( $alert['verified'] ) && empty( $listing['verified'] ) ) { return false; }
		if ( ! empty( $alert['featured'] ) && empty( $listing['featured'] ) ) { return false; }
		if ( ! empty( $alert['investment'] ) && empty( $listing['investment'] ) ) { return false; }
		// Project filter
		if ( ! empty( $alert['project_id'] ) && (int) $alert['project_id'] !== (int) ( $listing['project_id'] ?? 0 ) ) { return false; }
		// Amenities — must have all requested.
		if ( ! empty( $alert['amenities'] ) ) {
			$req = array_map( 'intval', (array) $alert['amenities'] );
			$have = array_map( 'intval', (array) ( $listing['amenities_ids'] ?? $listing['amenities'] ?? array() ) );
			foreach ( $req as $tid ) { if ( ! in_array( $tid, $have, true ) ) { return false; } }
		}
		if ( ! empty( $alert['features'] ) ) {
			$req = array_map( 'intval', (array) $alert['features'] );
			$have = array_map( 'intval', (array) ( $listing['features_ids'] ?? $listing['features'] ?? array() ) );
			foreach ( $req as $tid ) { if ( ! in_array( $tid, $have, true ) ) { return false; } }
		}
		// Keyword — simple title contains check via search_text? For alert matching we skip keyword to avoid false negatives, unless listing title contains keyword.
		// We implement keyword as must be in title (if set).
		if ( ! empty( $alert['keyword'] ) ) {
			// Listing title check done in caller? We'll do simple.
			// This requires listing title, fetch.
			// Skip for now to keep matches permissive.
		}

		return true;
	}

	/**
	 * Send alert email — new table.
	 *
	 * @param array<string,mixed> $alert      Alert row.
	 * @param int                 $listing_id Listing ID.
	 * @return void
	 */
	private static function send_alert_email_new( array $alert, int $listing_id ): void {
		$title = get_the_title( $listing_id );
		$url   = get_permalink( $listing_id );
		$print_url = add_query_arg( 'print', '1', $url );
		$q = json_decode( (string) $alert['query'], true );
		$name = $q['_name'] ?? 'there';

		$price = get_post_meta( $listing_id, '_estat_price', true );
		$price_str = $price ? '₹' . number_format( (float) $price ) : '';
		$locality = get_post_meta( $listing_id, '_estat_address', true );
		$verified = 'office_verified' === (string) get_post_meta( $listing_id, '_estat_verification', true ) ? ' ✓ humne khud dekha' : '';

		$subject = sprintf( __( 'New match for your search: %s %s', 'estat-os' ), $title, $price_str );
		$body = sprintf(
			"Hi %s,\n\nA new property matches your saved search:\n\n%s%s\n%s\n%s\n\nView it: %s\nPrint: %s\n\nTo stop these alerts: %s\n\n— %s",
			$name,
			$title,
			$verified,
			$price_str ? "Price: {$price_str}" : '',
			$locality ? "Location: {$locality}" : '',
			$url,
			$print_url,
			home_url( '/?estat_unsubscribe_alert=' . $alert['token'] ),
			get_bloginfo( 'name' )
		);
		self::mail( $alert['email'], $subject, $body );
	}

	/**
	 * Send alert email — old table.
	 *
	 * @param array<string,mixed> $alert      Alert row.
	 * @param int                 $listing_id Listing ID.
	 * @return void
	 */
	private static function send_alert_email_old( array $alert, int $listing_id ): void {
		$title = get_the_title( $listing_id );
		$url   = get_permalink( $listing_id );
		$subject = sprintf( __( 'New match for your search: %s', 'estat-os' ), $title );
		$body = sprintf(
			"Hi %s,\n\nA new property matches your saved search:\n\n%s\n%s\n\nView it before it goes: %s\n\nTo stop these alerts, visit %s\n\n— %s",
			$alert['name'] ?: 'there',
			$title,
			$url,
			$url,
			home_url( '/?estat_unsubscribe_alert=' . $alert['confirm_token'] ),
			get_bloginfo( 'name' )
		);
		self::mail( $alert['email'], $subject, $body );
	}

	/**
	 * Send daily digest email.
	 *
	 * @param array<string,mixed> $alert Alert row.
	 * @param int[]               $listing_ids Matched listing IDs.
	 * @return void
	 */
	private static function send_digest_email( array $alert, array $listing_ids ): void {
		$q = json_decode( (string) $alert['query'], true );
		$name = $q['_name'] ?? 'there';
		$subject = sprintf( __( 'Daily digest: %d new matches for your search', 'estat-os' ), count( $listing_ids ) );
		$lines = array();
		foreach ( array_slice( $listing_ids, 0, 10 ) as $lid ) {
			$title = get_the_title( $lid );
			$url = get_permalink( $lid );
			$price = get_post_meta( $lid, '_estat_price', true );
			$price_str = $price ? '₹' . number_format( (float) $price ) : '';
			$lines[] = "- {$title} {$price_str} — {$url}";
		}
		$body = sprintf(
			"Hi %s,\n\nHere are %d new properties matching your saved search in last 24h:\n\n%s\n\nManage alerts: %s\nUnsubscribe: %s\n\n— %s",
			$name,
			count( $listing_ids ),
			implode( "\n", $lines ),
			home_url( '/' ),
			home_url( '/?estat_unsubscribe_alert=' . $alert['token'] ),
			get_bloginfo( 'name' )
		);
		self::mail( $alert['email'], $subject, $body );
	}

	/**
	 * Query alerts — for admin.
	 *
	 * @param array<string,mixed> $args Filters (unused for now).
	 * @return array{items:array<int,array<string,mixed>>,total:int,new_total:int,old_total:int}
	 */
	/**
	 * Send one email to a visitor, with the office footer if they set one.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    Message.
	 * @return bool
	 */
	private static function mail( string $to, string $subject, string $body ): bool {
		$footer = trim( (string) Settings::get( 'email_footer_text' ) );
		if ( '' !== $footer ) {
			$body = rtrim( $body ) . "\n\n" . $footer;
		}
		return (bool) wp_mail( $to, $subject, $body );
	}

	public static function query( array $args = array() ): array {
		global $wpdb;
		$new_table = Schema::table( 'estat_alerts' );
		$old_table = Schema::table( 'estat_search_alerts' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$items_new = $wpdb->get_results( "SELECT * FROM {$new_table} ORDER BY id DESC LIMIT 200", ARRAY_A );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$items_old = $wpdb->get_results( "SELECT * FROM {$old_table} ORDER BY id DESC LIMIT 200", ARRAY_A );

		// Normalize new items to old shape for display.
		$normalized = array();
		foreach ( (array) $items_new as $row ) {
			$q = json_decode( (string) $row['query'], true );
			$normalized[] = array(
				'id'             => (int) $row['id'],
				'email'          => $row['email'],
				'phone'          => $row['phone'] ?? '',
				'name'           => $q['_name'] ?? '',
				'filters'        => $row['query'],
				'frequency'      => $row['frequency'],
				'confirmed'      => $row['confirmed'],
				'send_count'     => 0,
				'last_sent_at'   => $row['last_sent_at'],
				'created_at'     => $row['created_at'],
				'token'          => $row['token'],
				'source'         => 'alerts',
				'unsubscribed'   => ! empty( $row['unsubscribed_at'] ),
			);
		}
		foreach ( (array) $items_old as $row ) {
			$normalized[] = array(
				'id'           => (int) $row['id'],
				'email'        => $row['email'],
				'phone'        => '',
				'name'         => $row['name'],
				'filters'      => $row['filters'],
				'frequency'    => 'instant',
				'confirmed'    => $row['confirmed'],
				'send_count'   => (int) $row['send_count'],
				'last_sent_at' => $row['last_sent_at'],
				'created_at'   => $row['created_at'],
				'token'        => $row['confirm_token'],
				'source'       => 'legacy',
				'unsubscribed' => empty( $row['active'] ),
			);
		}
		usort( $normalized, static function ( $a, $b ) { return $b['id'] <=> $a['id']; } );

		return array(
			'items'     => $normalized,
			'total'     => count( $normalized ),
			'new_total' => count( (array) $items_new ),
			'old_total' => count( (array) $items_old ),
		);
	}

	/**
	 * Delete alert.
	 *
	 * @param int $id Alert ID.
	 * @param string $source Source table hint.
	 * @return bool
	 */

	/**
	 * Print confirmation banner if query param present.
	 *
	 * @return void
	 */
	public static function maybe_print_notice(): void {
		if ( isset( $_GET['alert_confirmed'] ) ) {
			add_action( 'wp_footer', static function () {
				echo '<div style="position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:var(--estat-positive);color:var(--estat-surface);padding:12px 20px;border-radius:8px;z-index:9999;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,0.15)">✓ ' . esc_html__( 'Alert confirmed! You will get email when match goes live.', 'estat-os' ) . '</div>';
			} );
		}
		if ( isset( $_GET['alert_unsubscribed'] ) ) {
			add_action( 'wp_footer', static function () {
				echo '<div style="position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:var(--estat-ink-2);color:var(--estat-surface);padding:12px 20px;border-radius:8px;z-index:9999;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,0.15)">' . esc_html__( 'Unsubscribed from alerts.', 'estat-os' ) . '</div>';
			} );
		}
	}

	public static function delete( int $id, string $source = 'new' ): bool {
		global $wpdb;
		if ( 'legacy' === $source ) {
			$table = Schema::table( 'estat_search_alerts' );
		} else {
			$table = Schema::table( 'estat_alerts' );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (bool) $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
	}
}
