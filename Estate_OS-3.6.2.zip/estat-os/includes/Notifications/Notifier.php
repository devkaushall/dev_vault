<?php
/**
 * Office notifications.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Notifications;

use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Plain, short emails. Every notification can be switched off in settings and
 * the office is never emailed twice for the same event.
 */
final class Notifier {

	/**
	 * Enquiry IDs already announced this request, so an enquiry is never
	 * emailed twice.
	 *
	 * @var array<int,bool>
	 */
	private static $announced = array();


	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		// Four emails, and no more. The office asked for exactly these:
		// an enquiry, a property waiting for approval, the morning summary
		// and the weekly report. Everything else that used to mail the
		// office now shows up on the Today screen instead.
		add_action( 'estat_lead_created', array( __CLASS__, 'on_lead_created' ), 10, 1 );
		add_action( 'estat_listing_needs_approval', array( __CLASS__, 'listing_needs_approval' ), 10, 1 );

		// The office can set the name and address its emails come from.
		add_filter( 'wp_mail_from', array( __CLASS__, 'mail_from_address' ) );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'mail_from_name' ) );
	}

	/**
	 * Announce an enquiry that arrived from anywhere: the REST API, an import,
	 * the admin screens or another plugin.
	 *
	 * Form submissions call new_lead() directly so they can honour the
	 * per-form recipient, so this guards against sending the same enquiry
	 * twice.
	 *
	 * @param int $lead_id Lead ID.
	 * @return void
	 */
	public static function on_lead_created( int $lead_id ): void {
		if ( isset( self::$announced[ $lead_id ] ) ) {
			return;
		}
		self::new_lead( $lead_id );
	}

	/**
	 * Send the mail with a consistent from-name and plain text body.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    Body.
	 * @return bool
	 */
	private static function send( string $to, string $subject, string $body ): bool {
		if ( ! is_email( $to ) ) {
			return false;
		}
		$body    = self::with_footer( $body );
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		return (bool) wp_mail( $to, wp_specialchars_decode( $subject ), $body, $headers );
	}

	/**
	 * The line the office wants at the bottom of its emails, if any.
	 *
	 * @param string $body Message so far.
	 * @return string
	 */
	public static function with_footer( string $body ): string {
		$footer = trim( (string) Settings::get( 'email_footer_text' ) );

		/*
		 * Who the mail is from, printed under every message.
		 *
		 * The office fills in its tagline, address, hours, phone and the
		 * person to ask for — all of it sat unread on the settings screen, so
		 * an enquiry email arrived looking like it came from nobody. A line
		 * the office already wrote into its own footer is not repeated: their
		 * words win, and the signature only fills the gaps.
		 */
		$lines = array(
			Settings::office_name(),
			trim( (string) Settings::get( 'tagline', '' ) ),
			trim( (string) Settings::get( 'address', '' ) ),
			trim( (string) Settings::get( 'office_phone', '' ) ),
			trim( (string) Settings::get( 'office_email', '' ) ),
			trim( (string) Settings::get( 'office_hours', '' ) ),
			trim( (string) Settings::get( 'contact_person', '' ) ),
			trim( (string) Settings::get( 'privacy_url', '' ) ),
		);
		$signature = array();
		foreach ( $lines as $line ) {
			if ( '' === $line ) {
				continue;
			}
			if ( '' !== $footer && false !== stripos( $footer, $line ) ) {
				continue;
			}
			$signature[] = $line;
		}
		if ( $signature ) {
			$body = rtrim( $body ) . "\n\n--\n" . implode( "\n", $signature );
		}
		if ( '' === $footer ) {
			return $body;
		}
		return rtrim( $body ) . "\n\n" . $footer;
	}

	/**
	 * Address our emails are sent from, when the office has set one.
	 */
	public static function mail_from_address( string $address ): string {
		$set = trim( (string) Settings::get( 'email_from_address' ) );
		return is_email( $set ) ? $set : $address;
	}

	/**
	 * Name our emails are sent from, when the office has set one.
	 */
	public static function mail_from_name( string $name ): string {
		$set = trim( (string) Settings::get( 'email_from_name' ) );
		return '' !== $set ? $set : $name;
	}

	/**
	 * Notify the office about a new enquiry.
	 *
	 * @param int    $lead_id  Lead ID.
	 * @param int    $form_id  Form ID.
	 * @param string $override Optional recipient override.
	 * @return void
	 */
	public static function new_lead( int $lead_id, int $form_id = 0, string $override = '' ): void {
		if ( isset( self::$announced[ $lead_id ] ) ) {
			return;
		}
		self::$announced[ $lead_id ] = true;

		if ( ! Settings::get( 'notify_new_lead' ) ) {
			return;
		}
		$lead = $lead_id > 0 ? Leads::get( $lead_id ) : null;
		// F1: don't email for spam.
		if ( $lead && 'spam' === $lead['status'] ) {
			return;
		}
		$to   = is_email( $override ) ? $override : Settings::notification_email();

		$lines   = array();
		$lines[] = __( 'A new enquiry has arrived.', 'estat-os' );
		$lines[] = '';
		if ( $lead ) {
			$lines[] = __( 'Name:', 'estat-os' ) . ' ' . $lead['name'];
			if ( '' !== (string) $lead['phone'] ) {
				$lines[] = __( 'Phone:', 'estat-os' ) . ' ' . $lead['phone'];
			}
			if ( '' !== (string) $lead['email'] ) {
				$lines[] = __( 'Email:', 'estat-os' ) . ' ' . $lead['email'];
			}
			if ( (int) $lead['listing_id'] > 0 ) {
				$lines[] = __( 'Property:', 'estat-os' ) . ' ' . get_the_title( (int) $lead['listing_id'] );
			}
			if ( '' !== (string) $lead['message'] ) {
				$lines[] = '';
				$lines[] = __( 'Message:', 'estat-os' );
				$lines[] = (string) $lead['message'];
			}
		}
		$lines[] = '';
		$lines[] = __( 'Open your office dashboard to reply:', 'estat-os' );
		$lines[] = admin_url( 'admin.php?page=estat-enquiries' );

		self::send( $to, sprintf( /* translators: %s: office name */ __( '[%s] New enquiry', 'estat-os' ), Settings::office_name() ), implode( "\n", $lines ) );
	}

	/**
	 * A property has been sent in and is waiting for the office to say yes.
	 *
	 * Fired from the pocket when somebody on the ground sends a draft, and
	 * from the office screens when a listing is parked for review.
	 *
	 * @param int $listing_id Listing ID.
	 * @return void
	 */
	public static function listing_needs_approval( int $listing_id ): void {
		if ( ! Settings::get( 'notify_listing_approval', true ) ) {
			return;
		}
		$post = get_post( $listing_id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
			return;
		}
		$to = Settings::notification_email();
		if ( ! is_email( $to ) ) {
			return;
		}

		$who   = (int) $post->post_author;
		$user  = $who > 0 ? get_userdata( $who ) : false;
		$name  = is_object( $user ) && isset( $user->display_name ) ? (string) $user->display_name : '';
		$row   = Listings::to_array( $listing_id );
		$price = (string) ( $row['price_display'] ?? '' );

		$lines   = array();
		$lines[] = __( 'A property is waiting for your approval.', 'estat-os' );
		$lines[] = '';
		$lines[] = __( 'Property:', 'estat-os' ) . ' ' . $post->post_title;
		if ( '' !== (string) $price ) {
			$lines[] = __( 'Price:', 'estat-os' ) . ' ' . (string) $price;
		}
		if ( '' !== $name ) {
			$lines[] = __( 'Sent in by:', 'estat-os' ) . ' ' . $name;
		}
		$lines[] = '';
		$lines[] = __( 'Nothing is on your website yet. Open it, check the details, and put it live when you are happy.', 'estat-os' );
		$lines[] = admin_url( 'admin.php?page=estat-listings&status=pending' );

		self::send(
			$to,
			sprintf(
				/* translators: %s: office name. */
				__( '[%s] A property is waiting for your approval', 'estat-os' ),
				Settings::office_name()
			),
			implode( "\n", $lines )
		);
	}

	/**
	 * The morning summary: what today looks like, in one screenful.
	 *
	 * @param array<string,int> $counts Numbers already worked out by the scheduler.
	 * @return void
	 */
	public static function daily_summary( array $counts ): void {
		if ( ! Settings::get( 'notify_daily_summary', true ) ) {
			return;
		}
		$to = Settings::notification_email();
		if ( ! is_email( $to ) ) {
			return;
		}

		$visits    = (int) ( $counts['visits_today'] ?? 0 );
		$enquiries = (int) ( $counts['enquiries_new'] ?? 0 );
		$followups = (int) ( $counts['followups_due'] ?? 0 );
		$waiting   = (int) ( $counts['waiting_approval'] ?? 0 );
		$drafts    = (int) ( $counts['drafts'] ?? 0 );

		$lines   = array();
		$lines[] = sprintf(
			/* translators: %s: today's date. */
			__( 'Good morning. Here is %s.', 'estat-os' ),
			date_i18n( 'l, j F' )
		);
		$lines[] = '';
		$lines[] = $visits > 0
			? sprintf(
				/* translators: %d: number of visits. */
				_n( '%d site visit is booked for today.', '%d site visits are booked for today.', $visits, 'estat-os' ),
				$visits
			)
			: __( 'No site visits are booked for today.', 'estat-os' );
		$lines[] = $followups > 0
			? sprintf(
				/* translators: %d: number of enquiries. */
				_n( '%d enquiry needs a follow-up.', '%d enquiries need a follow-up.', $followups, 'estat-os' ),
				$followups
			)
			: __( 'No follow-ups are due.', 'estat-os' );
		$lines[] = $enquiries > 0
			? sprintf(
				/* translators: %d: number of enquiries. */
				_n( '%d enquiry came in since yesterday.', '%d enquiries came in since yesterday.', $enquiries, 'estat-os' ),
				$enquiries
			)
			: __( 'No new enquiries since yesterday.', 'estat-os' );
		if ( $waiting > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of properties. */
				_n( '%d property is waiting for your approval.', '%d properties are waiting for your approval.', $waiting, 'estat-os' ),
				$waiting
			);
		}
		if ( $drafts > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of properties. */
				_n( '%d draft is still not on the website.', '%d drafts are still not on the website.', $drafts, 'estat-os' ),
				$drafts
			);
		}
		$lines[] = '';
		$lines[] = __( 'Open your office dashboard:', 'estat-os' );
		$lines[] = admin_url( 'admin.php?page=estat-today' );

		self::send(
			$to,
			sprintf(
				/* translators: %s: office name. */
				__( '[%s] This morning at the office', 'estat-os' ),
				Settings::office_name()
			),
			implode( "\n", $lines )
		);
	}

	/**
	 * The weekly report: last seven days, in plain words.
	 *
	 * @param array<string,int|string> $counts Numbers from the scheduler.
	 * @return void
	 */
	public static function weekly_report( array $counts ): void {
		if ( ! Settings::get( 'notify_weekly_report', true ) ) {
			return;
		}
		$to = Settings::notification_email();
		if ( ! is_email( $to ) ) {
			return;
		}

		$enquiries = (int) ( $counts['enquiries'] ?? 0 );
		$visits    = (int) ( $counts['visits'] ?? 0 );
		$happened  = (int) ( $counts['visits_done'] ?? 0 );
		$won       = (int) ( $counts['won'] ?? 0 );
		$lost      = (int) ( $counts['lost'] ?? 0 );
		$live      = (int) ( $counts['live'] ?? 0 );
		$source    = (string) ( $counts['top_source'] ?? '' );

		$lines   = array();
		$lines[] = __( 'Here is how the office did in the last seven days.', 'estat-os' );
		$lines[] = '';
		$lines[] = sprintf(
			/* translators: %d: number of enquiries. */
			_n( '%d enquiry arrived.', '%d enquiries arrived.', $enquiries, 'estat-os' ),
			$enquiries
		);
		$lines[] = sprintf(
			/* translators: %d: number of site visits. */
			_n( '%d site visit was arranged.', '%d site visits were arranged.', $visits, 'estat-os' ),
			$visits
		);
		if ( $happened > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of visits. */
				_n( '%d of them actually happened.', '%d of them actually happened.', $happened, 'estat-os' ),
				$happened
			);
		}
		$lines[] = $won > 0
			? sprintf(
				/* translators: %d: number of deals. */
				_n( '%d deal was closed.', '%d deals were closed.', $won, 'estat-os' ),
				$won
			)
			: __( 'No deals were closed.', 'estat-os' );
		if ( $lost > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of enquiries. */
				_n( '%d enquiry was marked lost.', '%d enquiries were marked lost.', $lost, 'estat-os' ),
				$lost
			);
		}
		if ( '' !== $source ) {
			$lines[] = sprintf(
				/* translators: %s: where the enquiries came from. */
				__( 'Most of them came from: %s.', 'estat-os' ),
				$source
			);
		}
		$lines[] = sprintf(
			/* translators: %d: number of properties. */
			_n( '%d property is on your website.', '%d properties are on your website.', $live, 'estat-os' ),
			$live
		);
		$lines[] = '';
		$lines[] = __( 'The full report, with the charts, is here:', 'estat-os' );
		$lines[] = admin_url( 'admin.php?page=estat-reports' );

		self::send(
			$to,
			sprintf(
				/* translators: %s: office name. */
				__( '[%s] Your week at the office', 'estat-os' ),
				Settings::office_name()
			),
			implode( "\n", $lines )
		);
	}
}
