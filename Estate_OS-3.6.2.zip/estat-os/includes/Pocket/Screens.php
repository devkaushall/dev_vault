<?php
/**
 * Every screen of the pocket, rendered server-side from the plugin's own
 * data classes. No JavaScript is required for anything on these pages; the
 * phone browser only draws what the office already knows how to do.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Pocket;

use EstatOS\Data\Meta;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Data\Agents;
use EstatOS\I18n\Language;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Status;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Rendering only. Every write goes through Actions.
 */
final class Screens {

	/**
	 * Entry point from the router.
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID for the two-record views.
	 * @return void
	 */
	public static function render( string $view, int $id = 0 ): void {
		if ( ! is_user_logged_in() ) {
			self::shell( __( 'Agent pocket', 'estat-os' ), self::login(), '', true );
			return;
		}

		if ( 'login' === $view ) {
			Pocket::redirect( '' );
		}

		if ( ! Pocket::can_use() ) {
			self::shell(
				__( 'Agent pocket', 'estat-os' ),
				'<div class="estat-pocket-notice">' .
				esc_html__( 'You are signed in, but this account is not part of an office yet. Ask your office owner for a role, then open this link again.', 'estat-os' ) .
				'</div>',
				'',
				true
			);
			return;
		}

		$body = '';
		switch ( $view ) {
			case 'listings':
				$body = self::listings();
				break;
			case 'new':
				// /agent/new/{id} is the edit half of the same form.
				$body = self::form( $id );
				break;
			case 'listing':
				$body = self::listing( $id );
				break;
			case 'change':
				$body = self::change( $id );
				break;
			case 'inbox':
			case 'leads':
				$body = self::leads_list();
				break;
			case 'visits':
				$body = self::visits();
				break;
			case 'visit':
				$body = self::visit_mode( $id );
				break;
			case 'capture':
				$body = self::capture();
				break;
			case 'capture-lead':
				$body = self::quick_enquiry( false );
				break;
			case 'capture-want':
				$body = self::quick_enquiry( true );
				break;
			case 'capture-visit':
				$body = self::quick_visit();
				break;
			case 'capture-owner':
				$body = self::owner_update();
				break;
			case 'more':
				$body = self::more();
				break;
			case 'search':
				$body = self::search_page();
				break;
			case 'enquiry':
				$body = self::may_see_enquiries()
					? self::enquiry( $id )
					: '<div class="estat-pocket-notice">' . esc_html__( 'Enquiries stay in the office. Your office has switched them off for phones.', 'estat-os' ) . '</div>';
				break;
			case 'approvals':
				$body = Pocket::is_office() ? self::approvals() : Pocket::fail_to_today( 'nope' );
				break;
			case 'you':
				$body = self::you();
				break;
			default:
				$body = self::my_day();
				break;
		}

		self::shell( self::title_for( $view ), $body, $view );
	}

	/**
	 * The heading each view carries.
	 *
	 * @param string $view View slug.
	 * @return string
	 */
	private static function title_for( string $view ): string {
		$titles = array(
			''          => __( 'Today', 'estat-os' ),
			'listings'  => __( 'My listings', 'estat-os' ),
			'new'       => __( 'Add a property', 'estat-os' ),
			'listing'   => __( 'Listing', 'estat-os' ),
			'change'    => __( 'Ask for a change', 'estat-os' ),
			'inbox'     => __( 'Enquiries & visits', 'estat-os' ),
			'enquiry'   => __( 'Enquiry', 'estat-os' ),
			'approvals' => __( 'Approvals', 'estat-os' ),
			'you'       => __( 'You', 'estat-os' ),
			'leads'     => __( 'Leads', 'estat-os' ),
			'visits'    => __( 'Site visits', 'estat-os' ),
			'visit'     => __( 'Visit', 'estat-os' ),
			'more'      => __( 'More', 'estat-os' ),
			'capture'   => __( 'Add something', 'estat-os' ),
			'capture-lead'  => __( 'Add an enquiry', 'estat-os' ),
			'capture-want'  => __( 'What a client wants', 'estat-os' ),
			'capture-visit' => __( 'Log a visit', 'estat-os' ),
			'capture-owner' => __( 'Owner update', 'estat-os' ),
			'search'    => __( 'Search', 'estat-os' ),
		);
		return $titles[ $view ] ?? __( 'Today', 'estat-os' );
	}

	/* ---------------------------------------------------------------------
	 * Shell, login
	 * ------------------------------------------------------------------ */

	/**
	 * The page furniture: head, flash, tabs, sign-out.
	 *
	 * @param string $title  Page title.
	 * @param string $body   Already-escaped HTML.
	 * @param string $active Tab slug.
	 * @param bool   $bare   Hide the tab bar (login and refusal).
	 * @return void
	 */
	private static function shell( string $title, string $body, string $active = '', bool $bare = false ): void {
		$flash = Pocket::flash();
		$out   = '<!DOCTYPE html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="utf-8">';
		$out  .= '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';
		$out  .= '<meta name="theme-color" content="#fbf9f4" media="(prefers-color-scheme: light)">';
		$out  .= '<meta name="theme-color" content="#16171a" media="(prefers-color-scheme: dark)">';
		$out  .= '<meta name="robots" content="noindex, follow">';
		$out  .= '<title>' . esc_html( $title ) . ' · ' . esc_html( get_bloginfo( 'name' ) ) . '</title>';
		foreach ( array( 'tokens.css', 'pocket.css' ) as $sheet ) {
			$css_ver = file_exists( ESTAT_DIR . 'assets/css/' . $sheet )
				? (string) filemtime( ESTAT_DIR . 'assets/css/' . $sheet )
				: ESTAT_VERSION;
			$out .= '<link rel="stylesheet" href="' . esc_url( ESTAT_URL . 'assets/css/' . $sheet . '?ver=' . $css_ver ) . '">';
		}
		$tokens_css = apply_filters( 'estat_pocket_inline_tokens', '' );
		if ( '' !== $tokens_css ) {
			$out .= '<style id="estat-design-tokens-overrides">' . $tokens_css . '</style>';
		}
		$out .= '</head><body class="estat-pocket">';
		// Responsive app shell: sidebar for PC, bottom tabs for mobile
		$out .= '<div class="estat-pocket-app">';

		if ( ! $bare ) {
			// Desktop sidebar
			$out .= '<aside class="estat-pocket-sidebar" aria-label="' . esc_attr__( 'Navigation', 'estat-os' ) . '">';
			$out .= '<a class="estat-pocket-sidebar-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
			$out .= '<nav class="estat-pocket-sidebar-nav" aria-label="' . esc_attr__( 'Sections', 'estat-os' ) . '">';
			$out .= self::sidebar_tabs( $active );
			$out .= '</nav>';
			$out .= '<div class="estat-pocket-sidebar-foot">';
			$out .= '<div class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="desktop">' . esc_html__( 'Desktop', 'estat-os' ) . '</div>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . esc_html__( 'Sign out', 'estat-os' ) . '</a>';
			$out .= '<div class="estat-pocket-hint" style="margin:0">/agent • ' . esc_html( wp_get_current_user()->display_name ) . '</div>';
			$out .= '</div>';
			$out .= '</aside>';
		}

		$out .= '<main class="estat-pocket-main">';
		$out .= '<div class="estat-pocket-screen">';

		if ( ! $bare ) {
			$out .= '<header class="estat-pocket-head">';
			$out .= '<a class="estat-pocket-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
			$out .= '<div style="display:flex;gap:8px;align-items:center">';
			$out .= '<span class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="desktop">' . esc_html__( 'PC', 'estat-os' ) . '</span>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . esc_html__( 'Sign out', 'estat-os' ) . '</a>';
			$out .= '</div>';
			$out .= '</header>';
		}

		if ( '' !== $flash ) {
			$out .= '<div class="estat-pocket-flash">' . esc_html( $flash ) . '</div>';
		}

		/*
		 * Field capture happens where the network is bad.
		 *
		 * A quiet line, shown only when the phone is actually offline, so
		 * nobody is left wondering whether what they typed went anywhere.
		 */
		$out .= '<div class="estat-pocket-offline" id="estat-pocket-offline" hidden role="status" aria-live="polite"'
			. ' data-offline="' . esc_attr__( 'No network. What you type is kept on this phone; photographs and voice notes will go up when the network is back.', 'estat-os' ) . '"'
			. ' data-online="' . esc_attr__( 'Back online. Press Save when you are ready.', 'estat-os' ) . '"></div>';

		/*
		 * What the phone is still holding.
		 *
		 * Two things put a whole form in here: pressing Save with no
		 * network, and a send that failed once the network was gone. Each
		 * entry is kept on the phone exactly as it stood — answers,
		 * photographs, voice note — and goes up through the same action a
		 * normal save uses, so nothing about it is a second way of
		 * storing a property. The line only appears when there is
		 * something waiting.
		 */
		$out .= '<div class="estat-pocket-queue" id="estat-pocket-queue" hidden role="status" aria-live="polite"'
			. ' data-wait="' . esc_attr__( '%d waiting to go up', 'estat-os' ) . '"'
			. ' data-sending="' . esc_attr__( 'Sending what was kept…', 'estat-os' ) . '"'
			. ' data-sent="' . esc_attr__( 'Sent. It went up.', 'estat-os' ) . '"'
			. ' data-open="' . esc_attr__( 'Open it', 'estat-os' ) . '"'
			. ' data-now="' . esc_attr__( 'Send now', 'estat-os' ) . '"'
			. ' data-failed="' . esc_attr__( 'Still no network.', 'estat-os' ) . '"'
			. ' data-see="' . esc_url( Pocket::url( 'queue' ) ) . '"'
			. ' data-see-word="' . esc_attr__( 'See them', 'estat-os' ) . '"></div>';

		$out .= $body;
		$out .= '</div>'; // .estat-pocket-screen
		$out .= '</main>'; // .estat-pocket-main
		$out .= '</div>'; // .estat-pocket-app

		if ( ! $bare ) {
			$out .= self::tabs( $active );
		}

		// Tiny JS to keep device mark in sync + improve UX stability
		$out .= '<script>document.addEventListener("DOMContentLoaded",function(){'
			. 'var bar=document.getElementById("estat-pocket-offline");'
			. 'function net(){ if(!bar){return;} if(navigator.onLine){ bar.hidden=true; } else { bar.hidden=false; bar.textContent=bar.getAttribute("data-offline"); } }'
			. 'function came(){ if(!bar){return;} bar.hidden=false; bar.textContent=bar.getAttribute("data-online"); setTimeout(net,4000); }'
			. 'window.addEventListener("online",came);'
			. 'window.addEventListener("offline",net); net();'
			. self::queue_script()
			. 'var w=window.innerWidth;var d=w<768?"mobile":w<1024?"tablet":"desktop";'
			. 'document.querySelectorAll(".estat-pocket-device").forEach(function(el){el.setAttribute("data-device",el.getAttribute("data-device"));});'
			. 'function onResize(){var nw=window.innerWidth;var nd=nw<768?"mobile":nw<1024?"tablet":"desktop";'
			. 'document.body.setAttribute("data-device",nd);}'
			. 'onResize();window.addEventListener("resize",onResize);'
			. '});</script>';

		$out .= '</body></html>';
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every piece escaped as it was built.
	}

	/**
	 * The bit of script that carries what the phone is holding.
	 *
	 * It lives in the shell, not on one screen, because a queued save must
	 * be able to go up from wherever the agent happens to be standing —
	 * Today, a property, an enquiry. Everything it needs comes from the
	 * queue line's own attributes, so it has no strings of its own to keep
	 * in step. Returns a piece of one script tag; see shell().
	 *
	 * @return string
	 */
	private static function queue_script(): string {
		return 'window.estatQueueKeep=function(form,draftKey){'
			. 'try{var pairs=[];new FormData(form).forEach(function(v,n){pairs.push([n,v]);});'
			. 'estatQueuePut({id:"estat-"+Date.now()+"-"+Math.random().toString(36).slice(2,8),url:form.getAttribute("action"),at:Date.now(),draftKey:draftKey||"",pairs:pairs})'
			. '.then(estatQueuePaint).catch(function(){estatQueuePaint();});'
			. '}catch(e){'
			. 'var err=document.getElementById("estat-w-error");'
			. 'if(err){var q=document.getElementById("estat-pocket-queue");err.textContent=q?q.getAttribute("data-failed"):"";err.style.display="inline-flex";}'
			. '}};'
			. 'function estatQLine(){return document.getElementById("estat-pocket-queue");}'
			. 'function estatQSay(text){var line=estatQLine();if(!line){return;}line.hidden=false;line.textContent=text;}'
			. 'function estatQueueDb(){return new Promise(function(res,rej){if(!window.indexedDB){rej(new Error("no storage"));return;}'
			. 'var ask=indexedDB.open("estat_pocket_queue",1);'
			. 'ask.onupgradeneeded=function(){ask.result.createObjectStore("saves",{keyPath:"id"});};'
			. 'ask.onsuccess=function(){res(ask.result);};ask.onerror=function(){rej(ask.error);};});}'
			. 'function estatQueuePut(item){return estatQueueDb().then(function(db){return new Promise(function(res,rej){'
			. 'var tx=db.transaction("saves","readwrite");tx.objectStore("saves").put(item);tx.oncomplete=function(){res(true);};tx.onerror=function(){rej(tx.error);};});});}'
			. 'function estatQueueAll(){return estatQueueDb().then(function(db){return new Promise(function(res,rej){'
			. 'var ask=db.transaction("saves","readonly").objectStore("saves").getAll();'
			. 'ask.onsuccess=function(){res(ask.result||[]);};ask.onerror=function(){rej(ask.error);};});});}'
			. 'function estatQueueDel(id){return estatQueueDb().then(function(db){return new Promise(function(res,rej){'
			. 'var tx=db.transaction("saves","readwrite");tx.objectStore("saves").delete(id);tx.oncomplete=function(){res(true);};tx.onerror=function(){rej(tx.error);};});});}'
			. 'function estatQueuePaint(gone){var line=estatQLine();if(!line){return;}'
			. 'estatQueueAll().then(function(items){'
			. 'if(!items.length){'
			. 'if(gone){line.hidden=false;line.innerHTML="";var said=document.createElement("span");said.textContent=line.getAttribute("data-sent");line.appendChild(said);'
			. 'var go=document.createElement("a");go.href=gone;go.textContent=line.getAttribute("data-open");line.appendChild(go);'
			. 'setTimeout(function(){line.hidden=true;},8000);return;}'
			. 'line.hidden=true;return;}'
			. 'line.hidden=false;line.innerHTML="";var said=document.createElement("span");'
			. 'said.textContent=line.getAttribute("data-wait").replace("%d",items.length);line.appendChild(said);'
			. 'var now=document.createElement("button");now.type="button";now.textContent=navigator.onLine?line.getAttribute("data-now"):line.getAttribute("data-failed");'
			. 'now.addEventListener("click",function(){estatQueueFlush();});line.appendChild(now);'
			. 'var see=document.createElement("a");see.href=line.getAttribute("data-see");see.textContent=line.getAttribute("data-see-word");'
			. 'see.addEventListener("click",function(ev){if(!navigator.onLine){ev.preventDefault();now.textContent=line.getAttribute("data-failed");}});line.appendChild(see);'
			. '}).catch(function(){});}'
			. 'function estatQueueFlush(){var line=estatQLine();'
			. 'if(!navigator.onLine){estatQueuePaint();return;}'
			. 'if(line){estatQSay(line.getAttribute("data-sending"));}'
			. 'estatQueueAll().then(function(items){var chain=Promise.resolve();'
			. 'items.forEach(function(item){chain=chain.then(function(){'
			. 'var body=new FormData();'
			. 'item.pairs.forEach(function(pair){if(pair[1] instanceof File){body.append(pair[0],pair[1],pair[1].name);}else{body.append(pair[0],pair[1]);}});'
			. 'return fetch(item.url,{method:"POST",body:body,credentials:"same-origin",redirect:"follow"})'
			. '.then(function(res){if(!res.ok){return false;}'
			. 'return estatQueueDel(item.id).then(function(){'
			. 'if(item.draftKey){try{localStorage.removeItem(item.draftKey);localStorage.removeItem(item.draftKey.replace("draft_","cid_"));}catch(e){}}'
			. 'return res.url;});}).catch(function(){'
			. 'item.tries=(item.tries||0)+1;estatQueuePut(item);return false;});'
			. '}).then(function(url){if(url){estatQueuePaint(url);}});});'
			. 'return chain.then(function(){estatQueuePaint();});}).catch(function(){});}'
			. 'window.addEventListener("online",function(){setTimeout(estatQueueFlush,600);});'
			. 'document.addEventListener("DOMContentLoaded",function(){'
			. 'if(document.getElementById("estat-q-rows")){return;}'
			. 'estatQueuePaint();if(navigator.onLine){setTimeout(function(){estatQueueFlush();},1200);}});';
	}

	/**
	 * You — the agent's own page.
	 *
	 * The office keeps its settings on the office screens (Settings in the
	 * plugin menu). What belongs to the person holding the phone is here and
	 * nowhere else: their name and numbers, the language they read, their
	 * password, what they have so far — plus a plain list of the office's
	 * decisions that change their day, so nothing has to be guessed at.
	 *
	 * @return string
	 */
	private static function you(): string {
		$user_id  = get_current_user_id();
		$agent_id = Pocket::agent_id();
		$user     = wp_get_current_user();
		$off      = Pocket::is_office();

		// The team record when there is one, otherwise what the person typed
		// on this screen last time.
		$mine = array( 'name' => $user->display_name, 'phone' => '', 'whatsapp' => '', 'email' => (string) $user->user_email );
		if ( $agent_id > 0 ) {
			$agent = Agents::to_array( $agent_id );
			$mine  = array(
				'name'     => (string) ( $agent['name'] ?? $user->display_name ),
				'phone'    => (string) ( $agent['phone'] ?? '' ),
				'whatsapp' => (string) ( $agent['whatsapp'] ?? '' ),
				'email'    => (string) ( $agent['email'] ?? $user->user_email ),
			);
		} else {
			$kept = (array) get_user_meta( $user_id, '_estat_pocket_contact', true );
			foreach ( array( 'name', 'phone', 'whatsapp', 'email' ) as $key ) {
				if ( isset( $kept[ $key ] ) && '' !== (string) $kept[ $key ] ) {
					$mine[ $key ] = (string) $kept[ $key ];
				}
			}
		}

		// What this person has, in plain numbers. Properties only: a society
		// is not a flat, and "on the website" would start meaning two things.
		$live   = 0;
		$drafts = 0;
		foreach ( Pocket::my_records( '', PostTypes::LISTING ) as $record ) {
			if ( 'publish' === $record->post_status ) {
				++$live;
			} elseif ( 'draft' === $record->post_status ) {
				++$drafts;
			}
		}
		$mine_waiting = 0;
		$waiting      = Requests::query( array( 'status' => 'pending', 'per_page' => 100, 'requested_by' => $user_id ) );
		$mine_waiting = (int) ( $waiting['total'] ?? 0 );
		$enquiries    = 0;
		if ( self::may_see_enquiries() ) {
			$scope = self::leads_scope();
			if ( ! $off ) {
				$scope['agent_id'] = $agent_id;
			}
			$asked     = Leads::query( array_merge( $scope, array( 'per_page' => 1 ) ) );
			$enquiries = (int) ( $asked['total'] ?? 0 );
		}

		$out  = '<h1 class="estat-pocket-title">' . esc_html__( 'You', 'estat-os' ) . '</h1>';
		$out .= '<div class="estat-pocket-banner">' . Pocket::icon( 'person', 14 ) .
			'<div>' . esc_html__( 'Your own details live here. The office\'s settings live on the office screens — this page only changes what belongs to you.', 'estat-os' ) . '</div></div>';

		/* -------- my details -------- */
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'you' ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="save_you">';
		$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'My details', 'estat-os' ) . '</h2>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'The office sees these, and your number is the one a client calls about your properties.', 'estat-os' ) . '</p>';
		$out .= self::field( __( 'My name', 'estat-os' ), 'name', 'text', (string) $mine['name'] );
		$out .= self::field( __( 'My phone', 'estat-os' ), 'phone', 'tel', (string) $mine['phone'], __( 'Where clients should call', 'estat-os' ) );
		$out .= self::field( __( 'My WhatsApp', 'estat-os' ), 'whatsapp', 'tel', (string) $mine['whatsapp'], __( 'Same as the phone number, if that is easier', 'estat-os' ) );
		$out .= self::field( __( 'My email', 'estat-os' ), 'email', 'email', (string) $mine['email'] );
		if ( $agent_id <= 0 ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Your office has not linked you to the team list yet. Until they do, these stay with your login only — ask them to add you under Team.', 'estat-os' ) . '</p>';
		}
		$out .= '<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Save my details', 'estat-os' ) . '</button>';
		$out .= '</form>';

		/* -------- language -------- */
		$current = (string) get_user_meta( $user_id, Language::USER_META, true );
		if ( '' === $current || 'auto' === $current ) {
			$current = Language::resolve();
		}
		$out .= '<div class="estat-pocket-card">';
		$out .= '<h2 class="estat-pocket-h2">' . Pocket::icon( 'globe', 16 ) . ' ' . esc_html__( 'The language I read', 'estat-os' ) . '</h2>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'This changes the app on this login only. Your office chooses the language of the website and their own screens.', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-chips">';
		foreach ( Language::available() as $locale => $label ) {
			$on     = $locale === $current;
			$out   .= '<a class="estat-pocket-pill ' . ( $on ? 'is-accent' : 'is-quiet' ) . '" href="' .
				esc_url( add_query_arg( 'estat_lang', $locale, Pocket::url( 'you' ) ) ) . '">' .
				( $on ? Pocket::icon( 'check', 12 ) . ' ' : '' ) . esc_html( (string) $label ) . '</a>';
		}
		$out .= '</div></div>';

		/* -------- password -------- */
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'you' ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="save_password">';
		$out .= '<h2 class="estat-pocket-h2">' . Pocket::icon( 'key', 16 ) . ' ' . esc_html__( 'My password', 'estat-os' ) . '</h2>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'At least 8 letters or numbers. After you change it, your other devices will ask you to sign in again — this phone stays signed in.', 'estat-os' ) . '</p>';
		$out .= self::field( __( 'New password', 'estat-os' ), 'new_password', 'password', '' );
		$out .= self::field( __( 'Type it once more', 'estat-os' ), 'again_password', 'password', '' );
		$out .= '<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Change my password', 'estat-os' ) . '</button>';
		$out .= '</form>';

		/* -------- what I have -------- */
		$out .= '<div class="estat-pocket-card">';
		$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'What I have so far', 'estat-os' ) . '</h2>';
		$out .= '<div class="estat-pocket-facts">';
		$rows = array(
			array( __( 'On the website', 'estat-os' ), (string) $live ),
			array( __( 'Still in drafts', 'estat-os' ), (string) $drafts ),
			array( __( 'Waiting for office', 'estat-os' ), (string) $mine_waiting ),
		);
		if ( self::may_see_enquiries() ) {
			$rows[] = array( __( 'My enquiries', 'estat-os' ), (string) $enquiries );
		}
		foreach ( $rows as $row ) {
			$out .= '<div class="estat-pocket-fact"><i>' . esc_html( (string) $row[0] ) . '</i><b>' . esc_html( (string) $row[1] ) . '</b></div>';
		}
		$out .= '</div></div>';

		/* -------- what the office decides -------- */
		$seed     = Settings::all();
		$ready    = (int) ( $seed['completeness_threshold'] ?? 0 );
		$keep_days = (int) ( $seed['listing_expiry_days'] ?? 0 );
		$lines    = array(
			array(
				__( 'Can I see enquiries?', 'estat-os' ),
				self::may_see_enquiries() ? __( 'Yes', 'estat-os' ) : __( 'No', 'estat-os' ),
			),
			array(
				__( 'A property must be this ready before I can send it', 'estat-os' ),
				$ready > 0
					/* translators: %d: score out of 100. */
					? sprintf( __( '%d out of 100', 'estat-os' ), $ready )
					: __( 'Anything I type is enough', 'estat-os' ),
			),
			array(
				__( 'How long a property stays on the website', 'estat-os' ),
				$keep_days > 0
					/* translators: %d: number of days. */
					? sprintf( _n( '%d day, then it comes off by itself', '%d days, then it comes off by itself', $keep_days, 'estat-os' ), $keep_days )
					: __( 'Until the office takes it off', 'estat-os' ),
			),
			array(
				__( 'Can I fix a property that is already on the website?', 'estat-os' ),
				current_user_can( 'estat_publish_listings' ) || ! empty( $seed['pocket_agents_edit_live'] )
					? __( 'Yes', 'estat-os' )
					: __( 'No — I send the change and the office applies it', 'estat-os' ),
			),
			array(
				__( 'Who gets the office emails', 'estat-os' ),
				'' !== trim( (string) ( $seed['notify_email'] ?? '' ) )
					? (string) $seed['notify_email']
					: __( 'The office login address', 'estat-os' ),
			),
		);
		$out .= '<div class="estat-pocket-card">';
		$out .= '<h2 class="estat-pocket-h2">' . Pocket::icon( 'shield', 16 ) . ' ' . esc_html__( 'The office decides these', 'estat-os' ) . '</h2>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'They are kept in one place on the office screens, so there is only ever one answer. Ask your office to change any of them.', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-facts">';
		foreach ( $lines as $line ) {
			$out .= '<div class="estat-pocket-fact"><i>' . esc_html( (string) $line[0] ) . '</i><b>' . esc_html( (string) $line[1] ) . '</b></div>';
		}
		$out .= '</div></div>';

		return $out;
	}

	/**
	 * Bottom bar for mobile + reused for sidebar.
	 */
	/**
	 * The five doors of the app, and the one button that starts everything.
	 *
	 * Today, Leads, Properties, Visits, More — the same five on a phone and on
	 * a desk, so nobody has to learn the product twice. Capture sits in the
	 * middle, where a thumb already is, and it is the only thing on the bar
	 * that is not a door: it starts work instead of showing it.
	 *
	 * @return array<string,array{0:string,1:string,2:string}> slug => icon, label, which door it lights up.
	 */
	private static function nav_items(): array {
		$items = array(
			''         => array( 'home', __( 'Today', 'estat-os' ), 'today' ),
			'leads'    => array( 'inbox', __( 'Leads', 'estat-os' ), 'leads' ),
			'listings' => array( 'list-checks', __( 'Properties', 'estat-os' ), 'listings' ),
			'visits'   => array( 'calendar', __( 'Visits', 'estat-os' ), 'visits' ),
			'more'     => array( 'menu', __( 'More', 'estat-os' ), 'more' ),
		);

		// The office can keep enquiries to itself (Settings → Staff app). When it
		// does, the door is simply not there — an empty room is not a feature.
		if ( ! self::may_see_enquiries() ) {
			unset( $items['leads'] );
		}

		return $items;
	}

	/**
	 * Which door a view belongs to, so the bar keeps a light on across the
	 * side screens (a property page still reads "Properties").
	 *
	 * @param string $view View slug.
	 * @return string
	 */
	private static function door_for( string $view ): string {
		$map = array(
			'today'     => 'today',
			'inbox'     => 'leads',
			'enquiry'   => 'leads',
			'listings'  => 'listings',
			'listing'   => 'listings',
			'new'       => 'listings',
			'change'    => 'listings',
			'leads'     => 'leads',
			'visits'    => 'visits',
			'visit'     => 'visits',
			/* Add is an action, not a door: nothing on the bar lights up
			   while the capture sheet is open, and that is the point. */
			'capture'       => 'capture',
			'capture-lead'  => 'capture',
			'capture-want'  => 'capture',
			'capture-visit' => 'capture',
			'capture-owner' => 'capture',
			'approvals' => 'more',
			'you'       => 'more',
			'more'      => 'more',
			'search'    => 'more',
		);
		return $map[ $view ] ?? ( '' === $view ? 'today' : $view );
	}

	private static function tabs( string $active ): string {
		$door = self::door_for( $active );
		$out  = '<nav class="estat-pocket-tabs" aria-label="' . esc_attr__( 'Sections', 'estat-os' ) . '">';

		$half = 0;
		foreach ( self::nav_items() as $slug => $tab ) {
			if ( $half >= 2 ) {
				break;
			}
			++$half;
			$out .= self::tab_link( $slug, $tab, $door );
		}

		// ＋ Capture — in the middle, always in reach.
		$out .= '<a class="estat-pocket-capture" href="' . esc_url( Pocket::url( 'capture' ) ) . '" aria-label="' . esc_attr__( 'Add something new', 'estat-os' ) . '">' .
			Pocket::icon( 'plus', 26 ) . '<span>' . esc_html__( 'Add', 'estat-os' ) . '</span></a>';

		foreach ( array_slice( self::nav_items(), 2, null, true ) as $slug => $tab ) {
			$out .= self::tab_link( $slug, $tab, $door );
		}

		return $out . '</nav>';
	}

	/**
	 * One door on the bar.
	 *
	 * @param string                          $slug Door.
	 * @param array{0:string,1:string,2:string} $tab  Icon, label, door key.
	 * @param string                          $door Door that is lit.
	 * @return string
	 */
	private static function tab_link( string $slug, array $tab, string $door ): string {
		$on = $tab[2] === $door;
		return sprintf(
			'<a class="estat-pocket-tab%1$s" href="%2$s" aria-current="%3$s">%4$s<span>%5$s</span></a>',
			$on ? ' is-on' : '',
			esc_url( Pocket::url( $slug ) ),
			$on ? 'page' : 'false',
			Pocket::icon( $tab[0], 22 ),
			esc_html( $tab[1] )
		);
	}

	private static function sidebar_tabs( string $active ): string {
		$door = self::door_for( $active );
		$out  = '';

		$out .= '<a class="estat-pocket-tab estat-pocket-sideadd" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' .
			Pocket::icon( 'plus', 18 ) . '<span>' . esc_html__( 'Add something new', 'estat-os' ) . '</span></a>';

		foreach ( self::nav_items() as $slug => $tab ) {
			$out .= self::tab_link( $slug, $tab, $door );
		}

		$out .= '<a class="estat-pocket-tab estat-pocket-sideadd" href="' . esc_url( Pocket::url( 'search' ) ) . '">' .
			Pocket::icon( 'search', 18 ) . '<span>' . esc_html__( 'Search', 'estat-os' ) . '</span></a>';

		return $out;
	}

	/**
	 * Sign-in, aimed at the WordPress account the person already has.
	 *
	 * @return string
	 */
	private static function login(): string {
		$action = esc_url( wp_login_url( Pocket::url() ) );
		return sprintf(
			'<div class="estat-pocket-login"><div class="estat-pocket-login-mark">%1$s</div>' .
			'<h1 class="estat-pocket-login-title">%2$s</h1>' .
			'<p class="estat-pocket-lead">%3$s</p>' .
			'<form class="estat-pocket-card estat-pocket-login-card" method="post" action="%4$s">' .
			'<input type="hidden" name="redirect_to" value="%5$s">' .
			'<label class="estat-pocket-label" for="estat-p-log">%6$s</label>' .
			'<input class="estat-pocket-input" id="estat-p-log" name="log" type="text" autocomplete="username" required>' .
			'<label class="estat-pocket-label" for="estat-p-pwd">%7$s</label>' .
			'<input class="estat-pocket-input" id="estat-p-pwd" name="pwd" type="password" autocomplete="current-password" required>' .
			'<label class="estat-pocket-check"><input type="checkbox" name="rememberme" value="forever"> %8$s</label>' .
			'%9$s' .
			'<button class="estat-pocket-btn is-go" type="submit">%10$s</button>' .
			'</form>' .
			'<p class="estat-pocket-hint">%11$s</p></div>',
			Pocket::icon( 'key', 24 ),
			esc_html__( 'Agent pocket', 'estat-os' ),
			esc_html__( 'Add and update listings from anywhere. Everything you send is checked by the office before it reaches the website.', 'estat-os' ),
			$action,
			esc_attr( Pocket::url() ),
			esc_html__( 'Username, email or your phone number', 'estat-os' ),
			esc_html__( 'Password', 'estat-os' ),
			esc_html__( 'Remember me', 'estat-os' ),
			wp_nonce_field( 'logged_in', '_wpnonce', true, false ),
			esc_html__( 'Sign in', 'estat-os' ),
			esc_html__( 'This is your office WordPress account — the same one that opens the dashboard. Forgotten passwords are reset there, by your office owner.', 'estat-os' )
		);
	}

	/* ---------------------------------------------------------------------
	 * Today
	 * ------------------------------------------------------------------ */

	/**
	 * My Day — the first screen, and the only one that has to be read.
	 *
	 * It answers three questions without any tapping: what needs attention,
	 * what to do next (with the reason written under it, so nobody has to
	 * guess why it is being suggested), and where to start something new.
	 *
	 * Nothing here is a widget for the sake of filling space. If there is no
	 * work, the screen says so and offers the one useful thing left: capture.
	 *
	 * @return string
	 */
	private static function my_day(): string {
		$agent = Pocket::agent_id();
		$user  = wp_get_current_user();

		$summary = \EstatOS\Work\MyDay::summary( $agent );
		$next    = \EstatOS\Work\MyDay::next_action( $agent );
		$tasks   = \EstatOS\Work\MyDay::tasks( $agent, 6 );

		$attention = (int) $summary['enquiries'] + (int) $summary['followups'] + (int) $summary['listings'];

		$hour = (int) current_time( 'G' );
		if ( $hour < 12 ) {
			$greeting = __( 'Good morning', 'estat-os' );
		} elseif ( $hour < 17 ) {
			$greeting = __( 'Good afternoon', 'estat-os' );
		} else {
			$greeting = __( 'Good evening', 'estat-os' );
		}

		$first = trim( (string) $user->first_name );
		if ( '' === $first ) {
			$first = (string) $user->display_name;
		}

		$out = '<p class="estat-pocket-greet">' . esc_html( $greeting . ', ' . $first ) . '</p>';

		// Search sits at the top on every screen, the way an app's does.
		$out .= self::search_bar();

		/* ---------------------------------------------------- what needs me */
		if ( $attention > 0 ) {
			$out .= '<p class="estat-pocket-summary">' . esc_html(
				sprintf(
					/* translators: %d: how many things need attention. */
					_n( '%d thing needs attention', '%d things need attention', $attention, 'estat-os' ),
					$attention
				)
			) . '</p>';
			$out .= self::attention_chips( $summary );
		} else {
			$out .= '<div class="estat-pocket-card is-quiet">' .
				'<p class="estat-pocket-hint" style="margin:0"><b>' . esc_html__( 'Nothing is waiting on you.', 'estat-os' ) . '</b><br>' .
				esc_html__( 'No enquiry to answer and no visit booked. A good moment to add something new, or check an old listing with its owner.', 'estat-os' ) . '</p></div>';
		}

		/* -------------------------------------------------------- next action */
		if ( $next ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Next', 'estat-os' ) . '</h2>';
			$out .= self::task_card( $next, true );

			$rest = array_slice( $tasks, 1 );
			if ( $rest ) {
				$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Then', 'estat-os' ) . '</h2>';
				foreach ( $rest as $task ) {
					$out .= self::task_card( $task, false );
				}
			}

			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'This list is built from what is actually unfinished — a passed follow-up, a visit today, a listing the office sent back. It shrinks as you work.', 'estat-os' ) . '</p>';
		} else {
			$out .= '<a class="estat-pocket-btn is-go estat-pocket-big" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' .
				Pocket::icon( 'plus', 18 ) . ' ' . esc_html__( 'Add a property', 'estat-os' ) . '</a>';
		}

		return $out;
	}

	/**
	 * The counts, as chips you can tap. Four separate facts, four doors.
	 *
	 * @param array<string,int> $summary Counts.
	 * @return string
	 */
	private static function attention_chips( array $summary ): string {
		$rows = array(
			array( 'inbox', __( 'new enquiries', 'estat-os' ), (int) $summary['enquiries'], Pocket::url( 'leads' ), __( 'enquiries to answer', 'estat-os' ) ),
			array( 'phone', __( 'follow-ups late', 'estat-os' ), (int) $summary['followups'], Pocket::url( 'leads' ), __( 'follow-ups that have passed', 'estat-os' ) ),
			array( 'calendar', __( 'visits today', 'estat-os' ), (int) $summary['visits'], Pocket::url( 'visits' ), __( 'visits today', 'estat-os' ) ),
			array( 'list-checks', __( 'listings need work', 'estat-os' ), (int) $summary['listings'], Pocket::url( 'listings' ), __( 'listings needing attention', 'estat-os' ) ),
		);

		$out = '<div class="estat-pocket-chips">';
		foreach ( $rows as $row ) {
			list( $icon, $label, $count, $url, $spoken ) = $row;
			$state = $count > 0 ? ' is-loud' : ' is-quiet';
			$out  .= '<a class="estat-pocket-chip' . $state . '" href="' . esc_url( $url ) . '" aria-label="' . esc_attr( $count . ' ' . $spoken ) . '">' .
				'<b>' . (int) $count . '</b> ' . esc_html( $label ) . '</a>';
		}
		return $out . '</div>';
	}

	/**
	 * One job, with its reason, and the action that finishes it.
	 *
	 * @param array<string,mixed> $task     Task row from Work\MyDay.
	 * @param bool                $is_next  Is this the one being recommended?
	 * @return string
	 */
	private static function task_card( array $task, bool $is_next ): string {
		$tone = '' !== (string) $task['tone'] ? ' is-' . (string) $task['tone'] : '';
		$out  = '<div class="estat-pocket-task' . $tone . ( $is_next ? ' is-next' : '' ) . '">';
		$out .= '<div class="estat-pocket-tasktop"><span class="estat-pocket-well">' . Pocket::icon( (string) $task['icon'], 18 ) . '</span>';
		$out .= '<div class="estat-pocket-tasktext"><b>' . esc_html( (string) $task['title'] ) . '</b>';
		if ( '' !== (string) $task['detail'] ) {
			$out .= '<i>' . esc_html( (string) $task['detail'] ) . '</i>';
		}
		$out .= '</div></div>';

		$out .= '<div class="estat-pocket-taskacts">';
		if ( '' !== (string) $task['phone'] ) {
			$out .= '<a class="estat-pocket-btn is-go" href="' . esc_attr( 'tel:' . preg_replace( '/[^0-9+]/', '', (string) $task['phone'] ) ) . '">' .
				Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call now', 'estat-os' ) . '</a>';
		}
		$out .= '<a class="estat-pocket-btn" href="' . esc_url( (string) $task['url'] ) . '">' . esc_html( (string) $task['action'] ) . '</a>';
		$out .= '</div></div>';

		return $out;
	}

	/**
	 * The search field at the top of the app.
	 *
	 * @return string
	 */
	private static function search_bar(): string {
		return '<form class="estat-pocket-search" method="get" action="' . esc_url( Pocket::url( 'search' ) ) . '" role="search">' .
			Pocket::icon( 'search', 18 ) .
			'<input type="search" name="q" value="" placeholder="' . esc_attr__( 'Search a client, a property, a visit', 'estat-os' ) . '" aria-label="' . esc_attr__( 'Search anything', 'estat-os' ) . '" enterkeyhint="search">' .
			'</form>';
	}

	/**
	 * Leads — clients, not rows.
	 *
	 * The phone's job here is to get somebody talking: the name, what they
	 * want, and a call button, in that order of importance. The table on the
	 * office screen is the right shape for the office; this is the right
	 * shape for a person standing in a car park.
	 *
	 * @return string
	 */
	private static function leads_list(): string {
		if ( ! self::may_see_enquiries() ) {
			return '<div class="estat-pocket-notice">' . esc_html__( 'Enquiries stay in the office. Your office has switched them off for phones.', 'estat-os' ) . '</div>';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$filter = isset( $_GET['show'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['show'] ) ? '' : $_GET['show'] ) ) ) : 'open';

		$scope = self::leads_scope();
		$args  = array_merge( $scope, array( 'per_page' => 40 ) );

		if ( 'open' === $filter ) {
			$open = array();
			foreach ( array( 'new', 'contacted', 'scheduled' ) as $status ) {
				$page = Leads::query( array_merge( $args, array( 'status' => $status, 'per_page' => 40 ) ) );
				$open = array_merge( $open, (array) $page['items'] );
			}
			usort(
				$open,
				static function ( $a, $b ) {
					return strcmp( (string) $b['updated_at'], (string) $a['updated_at'] );
				}
			);
			$items = array_slice( $open, 0, 40 );
		} elseif ( 'all' === $filter ) {
			$page  = Leads::query( $args );
			$items = (array) $page['items'];
		} else {
			$page  = Leads::query( array_merge( $args, array( 'status' => $filter ) ) );
			$items = (array) $page['items'];
		}

		$out = self::search_bar();

		$chips = array(
			'open'      => __( 'Working on', 'estat-os' ),
			'new'       => Status::label( Status::LEAD, 'new' ),
			'scheduled' => Status::label( Status::LEAD, 'scheduled' ),
			'won'       => Status::label( Status::LEAD, 'won' ),
			'lost'      => Status::label( Status::LEAD, 'lost' ),
			'all'       => __( 'All', 'estat-os' ),
		);
		$out .= '<div class="estat-pocket-chips">';
		foreach ( $chips as $key => $label ) {
			$on   = $key === $filter;
			$url  = 'open' === $key ? Pocket::url( 'leads' ) : add_query_arg( 'show', $key, Pocket::url( 'leads' ) );
			$out .= '<a class="estat-pocket-chip' . ( $on ? ' is-on' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
		$out .= '</div>';

		if ( ! $items ) {
			return $out . self::empty_state(
				__( 'No enquiries here', 'estat-os' ),
				__( 'When somebody asks about a property — from the website, a call, or a walk-in — it appears here with their number ready to tap.', 'estat-os' ),
				Pocket::url( 'capture' ),
				__( 'Add an enquiry', 'estat-os' )
			);
		}

		foreach ( $items as $lead ) {
			$out .= self::lead_card( $lead );
		}

		return $out;
	}

	/**
	 * One client, as a card.
	 *
	 * @param array<string,mixed> $lead Lead row.
	 * @return string
	 */
	private static function lead_card( array $lead ): string {
		$name = trim( (string) $lead['name'] );
		if ( '' === $name ) {
			$name = __( 'Someone', 'estat-os' );
		}
		$initial = strtoupper( mb_substr( $name, 0, 1 ) );
		$status  = (string) $lead['status'];
		$word    = Status::label( Status::LEAD, $status );
		$tone    = Status::tone( Status::LEAD, $status );
		$wants   = \EstatOS\Work\MyDay::requirement_line( $lead );

		$phone = preg_replace( '/[^0-9+]/', '', (string) $lead['phone'] );
		$wa    = self::whatsapp_url( (string) $lead['phone'] );

		$last = (string) ( $lead['followup_at'] ?? '' );
		$line = '';
		if ( '' !== $last ) {
			$line = sprintf(
				/* translators: %s: date of the next follow-up. */
				__( 'Follow-up %s', 'estat-os' ),
				Format::date( $last )
			);
		} else {
			$updated = (string) ( $lead['updated_at'] ?? $lead['created_at'] ?? '' );
			if ( '' !== $updated ) {
				/* translators: %s: when this client was last touched. */
				$line = sprintf( __( 'Last contact %s', 'estat-os' ), Format::date( $updated ) );
			}
		}

		$out  = '<div class="estat-pocket-person">';
		$out .= '<a class="estat-pocket-person-head" href="' . esc_url( Pocket::url( 'enquiry', (int) $lead['id'] ) ) . '">';
		$out .= '<span class="estat-pocket-avatar" aria-hidden="true">' . esc_html( $initial ) . '</span>';
		$out .= '<span class="estat-pocket-person-text"><b>' . esc_html( $name ) . '</b>';
		if ( '' !== $wants ) {
			$out .= '<i>' . esc_html( $wants ) . '</i>';
		}
		if ( '' !== $line ) {
			$out .= '<span class="estat-pocket-person-meta">' . esc_html( $line ) . '</span>';
		}
		$out .= '</span>';
		if ( '' !== $word ) {
			$out .= '<span class="estat-pocket-pill' . ( '' !== $tone ? ' is-' . $tone : '' ) . '">' . esc_html( $word ) . '</span>';
		}
		$out .= '</a>';

		$out .= '<div class="estat-pocket-person-acts">';
		if ( '' !== $phone ) {
			$out .= '<a class="estat-pocket-btn is-go" href="' . esc_attr( 'tel:' . $phone ) . '">' . Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call', 'estat-os' ) . '</a>';
		}
		if ( '' !== $wa ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( $wa ) . '">' . Pocket::icon( 'whatsapp', 14 ) . ' WhatsApp</a>';
		}
		$out .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'enquiry', (int) $lead['id'] ) ) . '">' . esc_html__( 'Open', 'estat-os' ) . '</a>';
		$out .= '</div></div>';

		return $out;
	}

	/**
	 * A WhatsApp link for an Indian number, or '' when the number cannot be
	 * one. Kept in one place so every button in the app behaves the same.
	 *
	 * @param string $phone Stored phone.
	 * @return string
	 */
	private static function whatsapp_url( string $phone ): string {
		$digits = preg_replace( '/\D/', '', $phone );
		if ( '' === $digits ) {
			return '';
		}
		if ( '0' === substr( $digits, 0, 1 ) ) {
			$digits = substr( $digits, 1 );
		}
		if ( 10 === strlen( $digits ) ) {
			$digits = '91' . $digits;
		}
		if ( strlen( $digits ) < 10 ) {
			return '';
		}
		return 'https://wa.me/' . $digits;
	}

	/**
	 * Visits — today first, then what is booked, then what just happened.
	 *
	 * @return string
	 */
	private static function visits(): string {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			return '<div class="estat-pocket-notice">' . esc_html__( 'Site visits are not part of your work here. Ask the office.', 'estat-os' ) . '</div>';
		}

		$scope = Pocket::is_office() ? array() : array( 'agent_id' => Pocket::agent_id() );
		$now   = current_time( 'timestamp', true );

		$upcoming = Visits::query(
			array_merge(
				$scope,
				array(
					'from'     => gmdate( 'Y-m-d H:i:s', $now - 3 * HOUR_IN_SECONDS ),
					'per_page' => 20,
				)
			)
		);
		$past = Visits::query(
			array_merge(
				$scope,
				array(
					'to'       => gmdate( 'Y-m-d H:i:s', $now - 3 * HOUR_IN_SECONDS ),
					'per_page' => 10,
				)
			)
		);

		$out = self::search_bar();

		$out .= '<div class="estat-pocket-chips">';
		$out .= '<a class="estat-pocket-chip is-on" href="' . esc_url( Pocket::url( 'visits' ) ) . '">' . esc_html__( 'Coming up', 'estat-os' ) . '</a>';
		$out .= '<a class="estat-pocket-chip" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' . Pocket::icon( 'plus', 14 ) . ' ' . esc_html__( 'Book a visit', 'estat-os' ) . '</a>';
		$out .= '</div>';

		$pending = array();
		foreach ( (array) $upcoming['items'] as $visit ) {
			if ( 'pending' === (string) $visit['outcome'] ) {
				$pending[] = $visit;
			}
		}

		if ( ! $pending ) {
			$out .= self::empty_state(
				__( 'No visit booked', 'estat-os' ),
				__( 'A visit booked from an enquiry shows up here on the day, with the client’s name and number.', 'estat-os' ),
				Pocket::url( 'capture' ),
				__( 'Book a visit', 'estat-os' )
			);
		} else {
			foreach ( $pending as $visit ) {
				$out .= self::visit_card( $visit );
			}
		}

		$done = array();
		foreach ( (array) $past['items'] as $visit ) {
			if ( 'pending' !== (string) $visit['outcome'] ) {
				$done[] = $visit;
			}
		}
		if ( $done ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Just finished', 'estat-os' ) . '</h2>';
			foreach ( $done as $visit ) {
				$out .= self::visit_card( $visit );
			}
		}

		return $out;
	}

	/**
	 * One visit, as a card — with the visit itself as the way in.
	 *
	 * @param array<string,mixed> $visit Visit row.
	 * @return string
	 */
	private static function visit_card( array $visit ): string {
		$lead  = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
		$name  = $lead ? trim( (string) $lead['name'] ) : '';
		$name  = '' !== $name ? $name : __( 'Client', 'estat-os' );
		$title = (int) $visit['listing_id'] > 0 ? (string) get_the_title( (int) $visit['listing_id'] ) : '';

		$outcome = (string) $visit['outcome'];
		$word    = Status::label( Status::VISIT, $outcome );
		$tone    = Status::tone( Status::VISIT, $outcome );

		$out  = '<a class="estat-pocket-task" href="' . esc_url( Pocket::url( 'visit', (int) $visit['id'] ) ) . '">';
		$out .= '<div class="estat-pocket-tasktop"><span class="estat-pocket-well">' . Pocket::icon( 'calendar', 18 ) . '</span>';
		$out .= '<div class="estat-pocket-tasktext"><b>' . esc_html( $name ) . '</b><i>' .
			esc_html( Format::date( (string) $visit['scheduled_at'] ) . ' · ' . Format::time( (string) $visit['scheduled_at'] ) ) .
			( '' !== $title ? ' · ' . esc_html( $title ) : '' ) . '</i></div>';
		$out .= '<span class="estat-pocket-pill' . ( '' !== $tone ? ' is-' . $tone : '' ) . '">' . esc_html( $word ) . '</span>';
		$out .= '</div></a>';

		return $out;
	}

	/**
	 * Visit mode — one screen for the three parts of a visit.
	 *
	 * Before: what has to be true for the visit to be worth going to.
	 * During: the visit itself, marked as happening.
	 * After: what happened, why, and what comes next.
	 *
	 * The whole point is that an agent does not have to find four screens
	 * while standing outside a flat with a client.
	 *
	 * @param int $visit_id Visit row id.
	 * @return string
	 */
	private static function visit_mode( int $visit_id ) {
		$visit = Visits::get( $visit_id );
		if ( ! $visit ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$lead = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
		if ( $lead && ! self::lead_is_mine( $lead ) ) {
			return Pocket::fail_to_today( 'nope' );
		}
		if ( ! $lead && ! Pocket::is_office() && (int) $visit['agent_id'] !== Pocket::agent_id() ) {
			return Pocket::fail_to_today( 'nope' );
		}

		$name  = $lead ? trim( (string) $lead['name'] ) : '';
		$name  = '' !== $name ? $name : __( 'Client', 'estat-os' );
		$title = (int) $visit['listing_id'] > 0 ? (string) get_the_title( (int) $visit['listing_id'] ) : '';
		$when  = (string) $visit['scheduled_at'];
		$outcome = (string) $visit['outcome'];

		$out  = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'visits' ) ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'All visits', 'estat-os' ) . '</a>';

		// The one thing the agent needs to read from arm's length.
		$out .= '<div class="estat-pocket-visithead">';
		$out .= '<h1 class="estat-pocket-title">' . esc_html( $name ) . '</h1>';
		$out .= '<p class="estat-pocket-visitsub">' . esc_html( Format::date( $when ) . ' · ' . Format::time( $when ) ) . '</p>';
		if ( '' !== $title ) {
			$out .= '<p class="estat-pocket-visitsub">' . esc_html( $title ) . '</p>';
		}
		$out .= '<p><span class="estat-pocket-pill' . ( '' !== Status::tone( Status::VISIT, $outcome ) ? ' is-' . Status::tone( Status::VISIT, $outcome ) : '' ) . '">' . esc_html( Status::label( Status::VISIT, $outcome ) ) . '</span></p>';
		$out .= '</div>';

		$phone = $lead ? preg_replace( '/[^0-9+]/', '', (string) $lead['phone'] ) : '';
		$wa    = $lead ? self::whatsapp_url( (string) $lead['phone'] ) : '';
		$out  .= '<div class="estat-pocket-actions">';
		if ( '' !== $phone ) {
			$out .= '<a class="estat-pocket-btn is-go" href="' . esc_attr( 'tel:' . $phone ) . '">' . Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call the client', 'estat-os' ) . '</a>';
		}
		if ( '' !== $wa ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( $wa ) . '">' . Pocket::icon( 'whatsapp', 14 ) . ' WhatsApp</a>';
		}
		if ( $lead ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'enquiry', (int) $lead['id'] ) ) . '">' . esc_html__( 'Open enquiry', 'estat-os' ) . '</a>';
		}
		$out .= '</div>';

		if ( 'pending' === $outcome ) {
			/* --------------------------------------------------- before */
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Before you go', 'estat-os' ) . '</h2>';
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Tick what you have checked. Anything left unticked is a reason the visit might not happen — better to find out now.', 'estat-os' ) . '</p>';

			$checks = array(
				'owner'     => __( 'Owner knows we are coming', 'estat-os' ),
				'client'    => __( 'Client has confirmed', 'estat-os' ),
				'access'    => __( 'Keys or access arranged', 'estat-os' ),
			);
			$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'visit', $visit_id ) ) . '">';
			$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
			$out .= '<input type="hidden" name="estat_pocket_action" value="visit_checks">';
			$out .= '<input type="hidden" name="visit_id" value="' . (int) $visit_id . '">';
			foreach ( $checks as $key => $label ) {
				$out .= '<label class="estat-pocket-check"><input type="checkbox" name="checks[]" value="' . esc_attr( $key ) . '"> ' . esc_html( $label ) . '</label>';
			}
			$out .= '<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Save what I checked', 'estat-os' ) . '</button>';
			$out .= '</form>';

			/* --------------------------------------------------- after */
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'After the visit', 'estat-os' ) . '</h2>';
			$out .= self::visit_outcome_form( $visit_id, $lead ? (int) $lead['id'] : 0 );
		} else {
			$out .= '<div class="estat-pocket-card is-quiet"><p class="estat-pocket-hint" style="margin:0">' .
				esc_html__( 'This visit is closed. The office can reopen it if something was written down wrongly.', 'estat-os' ) . '</p></div>';

			if ( '' !== (string) $visit['notes'] ) {
				$out .= '<div class="estat-pocket-card"><div class="estat-pocket-quote">' . esc_html( (string) $visit['notes'] ) . '</div></div>';
			}
		}

		// What was written down about this visit, so far.
		if ( $lead ) {
			$events = \EstatOS\Leads\LeadEvents::for_lead( (int) $lead['id'] );
			$shown  = 0;
			$rows   = '';
			foreach ( $events as $event ) {
				$type = (string) $event['event'];
				if ( ! in_array( $type, array( 'visit_booked', 'visit_checks', 'visit_started', 'visit_done', 'visit_no_show', 'visit_cancelled', 'visit_next' ), true ) ) {
					continue;
				}
				$rows .= '<div class="estat-pocket-row is-flat"><span class="estat-pocket-well">' . Pocket::icon( 'clock', 14 ) . '</span><span class="estat-pocket-rowmain"><b>' .
					esc_html( self::event_words( $event ) ) . '</b><i>' . esc_html( Format::date( (string) $event['created_at'] ) . ' ' . Format::time( (string) $event['created_at'] ) ) . '</i></span></div>';
				++$shown;
				if ( $shown >= 8 ) {
					break;
				}
			}
			if ( '' !== $rows ) {
				$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Written down', 'estat-os' ) . '</h2>' . $rows;
			}
		}

		return $out;
	}

	/**
	 * The three questions asked after a visit, on one card.
	 *
	 * @param int $visit_id Visit row id.
	 * @param int $lead_id  Lead id, 0 when the visit is not tied to one.
	 * @return string
	 */
private static function visit_outcome_form( int $visit_id, int $lead_id ): string {
		$out  = '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'visit', $visit_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="visit_finish">';
		$out .= '<input type="hidden" name="visit_id" value="' . (int) $visit_id . '">';
		$out .= '<input type="hidden" name="lead_id" value="' . (int) $lead_id . '">';

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'Did the visit happen?', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-bigchoice">';
		$out .= self::big_choice( 'outcome', 'done', 'check-circle', __( 'Yes, we saw it', 'estat-os' ) );
		$out .= self::big_choice( 'outcome', 'no_show', 'close', __( 'Nobody came', 'estat-os' ) );
		$out .= self::big_choice( 'outcome', 'cancelled', 'calendar', __( 'It was called off', 'estat-os' ) );
		$out .= '</div>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'If the client came and did not like the property, that is “Yes, we saw it” — say what they thought below.', 'estat-os' ) . '</p>';

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'What did the client think?', 'estat-os' ) . '</p>';
		$thoughts = array(
			''       => __( 'Nothing to add yet', 'estat-os' ),
			'yes'    => __( 'Interested', 'estat-os' ),
			'thinking' => __( 'Still thinking', 'estat-os' ),
			'no'     => __( 'Not interested', 'estat-os' ),
		);
		$out .= self::select_field( __( 'Client', 'estat-os' ), 'interest', $thoughts, '' );

		$reasons = array( '' => __( 'Choose the reason', 'estat-os' ) ) + Vocabulary::lead_lost_reasons();
		$out .= self::select_field( __( 'If they said no — why?', 'estat-os' ), 'reason', $reasons, '' );

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'What happens next?', 'estat-os' ) . '</p>';
		$steps = array(
			''         => __( 'Nothing for now', 'estat-os' ),
			'call'     => __( 'I will call them tomorrow', 'estat-os' ),
			'send'     => __( 'I will send other properties', 'estat-os' ),
			'second'   => __( 'Fix a second visit', 'estat-os' ),
			'go_ahead' => __( 'They want to go ahead', 'estat-os' ),
		);
		$out .= self::select_field( __( 'Next step', 'estat-os' ), 'next_step', $steps, '' );

		$out .= self::area_field( __( 'What did they say?', 'estat-os' ), 'notes', '', __( 'Liked the light, worried about the road noise.', 'estat-os' ) );
		$out .= '<button class="estat-pocket-btn is-go estat-pocket-big" type="submit">' . esc_html__( 'Finish the visit', 'estat-os' ) . '</button>';
		$out .= '</form>';

		return $out;
	}

	/**
	 * A large, thumb-sized choice — the shape used wherever the answer is one
	 * of three or four things and the agent is standing up.
	 *
	 * @param string $name  Field name.
	 * @param string $value Value.
	 * @param string $icon  Icon name.
	 * @param string $label Label.
	 * @return string
	 */
	private static function big_choice( string $name, string $value, string $icon, string $label ): string {
		return '<label class="estat-pocket-choice"><input type="radio" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">' .
			'<span class="estat-pocket-choice-box">' . Pocket::icon( $icon, 20 ) . '<b>' . esc_html( $label ) . '</b></span></label>';
	}

	/**
	 * The capture sheet — five ways to start something new.
	 *
	 * This is the app's front door for work: one tap from anywhere, then the
	 * smallest possible question ("what are you adding?"), then the form.
	 * Nothing is created until a form is filled in and its own button is
	 * pressed, so backing out of this screen can never leave half a record.
	 *
	 * @return string
	 */
	private static function capture(): string {
		$rows = array(
			array( 'new', 'buildings', __( 'Add a property', 'estat-os' ), __( 'Photographs, price, the owner’s number — the full listing.', 'estat-os' ) ),
			array( 'capture-lead', 'inbox', __( 'Add an enquiry', 'estat-os' ), __( 'Somebody asked about a property. Write it down before it is forgotten.', 'estat-os' ) ),
			array( 'capture-visit', 'calendar', __( 'Log a visit', 'estat-os' ), __( 'Book a site visit, or write down one that has just happened.', 'estat-os' ) ),
			array( 'capture-want', 'target', __( 'Add what a client wants', 'estat-os' ), __( 'Their budget, areas and size — so the app can find matches later.', 'estat-os' ) ),
			array( 'capture-owner', 'key', __( 'Owner update', 'estat-os' ), __( 'You have just spoken to the owner. Say what they said.', 'estat-os' ) ),
		);

		$out = '<p class="estat-pocket-lead">' . esc_html__( 'What are you adding?', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-sheet">';
		foreach ( $rows as $row ) {
			$out .= '<a class="estat-pocket-sheet-row" href="' . esc_url( Pocket::url( $row[0] ) ) . '">' .
				'<span class="estat-pocket-well is-accent">' . Pocket::icon( $row[1], 18 ) . '</span>' .
				'<span class="estat-pocket-rowmain"><b>' . esc_html( $row[2] ) . '</b><i>' . esc_html( $row[3] ) . '</i></span>' .
				Pocket::icon( 'chevron-right', 16 ) . '</a>';
		}
		$out .= '</div>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Nothing is saved until you press the button on the form itself.', 'estat-os' ) . '</p>';

		return $out;
	}

	/**
	 * A new enquiry, written down in a minute — the fields a lead actually
	 * needs, and nothing else. The full ledgers live in the office.
	 *
	 * @param bool $wants_only Lead with a requirement (capture: "what a client wants").
	 * @return string
	 */
	private static function quick_enquiry( bool $wants_only = false ): string {
		if ( ! self::may_see_enquiries() ) {
			return '<div class="estat-pocket-notice">' . esc_html__( 'Enquiries stay in the office. Your office has switched them off for phones.', 'estat-os' ) . '</div>';
		}

		$out  = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'capture-lead' ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="quick_enquiry">';

		$out .= self::field( __( 'Name', 'estat-os' ), 'name', 'text', '', __( 'Rahul Sharma', 'estat-os' ), true );
		$out .= self::field( __( 'Phone', 'estat-os' ), 'phone', 'tel', '', __( '+91 98765 43210', 'estat-os' ), true );

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'What do they want?', 'estat-os' ) . '</p>';
		$out .= self::select_field( __( 'Looking to', 'estat-os' ), 'intent', Vocabulary::lead_intents(), $wants_only ? 'buy' : '' );
		$out .= self::field( __( 'Area', 'estat-os' ), 'locality', 'text', '', __( 'Golf Course Extension', 'estat-os' ) );
		$out .= self::field( __( 'Budget from', 'estat-os' ), 'budget_min', 'text', '', '18000000' );
		$out .= self::field( __( 'Budget up to', 'estat-os' ), 'budget_max', 'text', '', '23000000' );
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Money is written in plain rupees — 18000000 is ₹1.8 Cr. Leave it empty if they did not say.', 'estat-os' ) . '</p>';

		$out .= self::area_field( __( 'What did they say?', 'estat-os' ), 'message', '', __( 'Wants a 3 BHK, ready to move, parking for two.', 'estat-os' ) );

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'Only if they said so', 'estat-os' ) . '</p>';
		$out .= self::field( __( 'Ring them back on', 'estat-os' ), 'followup_at', 'datetime-local', '' );

		$out .= '<button class="estat-pocket-btn is-go estat-pocket-big" type="submit">' . esc_html__( 'Save the enquiry', 'estat-os' ) . '</button>';
		$out .= '</form>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'The office sees this the moment you save it. Consent to be contacted is taken from the call or the walk-in you are writing down.', 'estat-os' ) . '</p>';

		return $out;
	}

	/**
	 * Booking a visit, or writing down one that just happened.
	 *
	 * @return string
	 */
	private static function quick_visit(): string {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			return '<div class="estat-pocket-notice">' . esc_html__( 'Site visits are not part of your work here. Ask the office.', 'estat-os' ) . '</div>';
		}

		$scope = Pocket::is_office() ? array() : array( 'agent_id' => Pocket::agent_id() );
		$open  = array( '' => __( 'Choose the client', 'estat-os' ) );
		foreach ( array( 'new', 'contacted', 'scheduled' ) as $status ) {
			$page = Leads::query( array_merge( $scope, array( 'status' => $status, 'per_page' => 30 ) ) );
			foreach ( (array) $page['items'] as $lead ) {
				$name = trim( (string) $lead['name'] );
				$open[ (string) $lead['id'] ] = '' !== $name ? $name : __( 'Someone', 'estat-os' );
			}
		}

		$out  = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';

		if ( count( $open ) <= 1 ) {
			return $out . self::empty_state(
				__( 'No client to book a visit for', 'estat-os' ),
				__( 'A visit belongs to an enquiry. Write the enquiry down first — then the visit.', 'estat-os' ),
				Pocket::url( 'capture-lead' ),
				__( 'Add an enquiry', 'estat-os' )
			);
		}

		// The properties on this agent's shelf, newest first.
		$props = array( '' => __( 'No particular property', 'estat-os' ) );
		foreach ( (array) Pocket::my_records( '', PostTypes::LISTING ) as $post ) {
			$props[ (string) $post->ID ] = (string) $post->post_title;
		}

		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'capture-visit' ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="quick_visit">';

		$out .= self::select_field( __( 'Client', 'estat-os' ), 'lead_id', $open, '', '', true );
		$out .= self::select_field( __( 'Property', 'estat-os' ), 'listing_id', $props, '' );
		$out .= self::field( __( 'When', 'estat-os' ), 'scheduled_at', 'datetime-local', '', '', true );
		$out .= self::area_field( __( 'Anything to remember', 'estat-os' ), 'notes', '', __( 'Owner will leave the keys with the guard.', 'estat-os' ) );
		$out .= '<button class="estat-pocket-btn is-go estat-pocket-big" type="submit">' . esc_html__( 'Book the visit', 'estat-os' ) . '</button>';
		$out .= '</form>';

		return $out;
	}

	/**
	 * Owner update — the thirty-second habit that keeps the inventory true.
	 *
	 * Pick the property, answer three questions, done. No long form, because
	 * a habit only survives if it is shorter than the phone call it follows.
	 *
	 * @return string
	 */
private static function owner_update(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$record_id = isset( $_GET['record'] ) ? absint( wp_unslash( (string) ( is_array( $_GET['record'] ) ? '' : $_GET['record'] ) ) ) : 0;

		$out = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'capture' ) ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';

		/* ------------------------------------------------ which property? */
		if ( $record_id <= 0 ) {
			$mine = Pocket::my_records( '', PostTypes::LISTING );

			if ( ! $mine ) {
				return $out . self::empty_state(
					__( 'No property to check', 'estat-os' ),
					__( 'Properties you add show up here, ready to be checked with their owner every few weeks.', 'estat-os' ),
					Pocket::url( 'new' ),
					__( 'Add a property', 'estat-os' )
				);
			}

			$out .= '<p class="estat-pocket-lead">' . esc_html__( 'Which property did you speak about?', 'estat-os' ) . '</p>';
			$out .= '<div class="estat-pocket-sheet">';
			foreach ( $mine as $post ) {
				$verification = (string) get_post_meta( (int) $post->ID, '_estat_verification', true );
				$out .= '<a class="estat-pocket-sheet-row" href="' . esc_url( add_query_arg( 'record', (int) $post->ID, Pocket::url( 'capture-owner' ) ) ) . '">' .
					'<span class="estat-pocket-well">' . Pocket::icon( 'buildings', 18 ) . '</span>' .
					'<span class="estat-pocket-rowmain"><b>' . esc_html( (string) $post->post_title ) . '</b><i>' .
					esc_html( Status::label( Status::VERIFICATION, '' !== $verification ? $verification : 'unverified' ) ) .
					'</i></span>' . Pocket::icon( 'chevron-right', 16 ) . '</a>';
			}
			$out .= '</div>';

			return $out;
		}

		/* ---------------------------------------------------- one property */
		$post = get_post( $record_id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type || ! Pocket::can_see( $post ) ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$offer        = (string) get_post_meta( $record_id, '_estat_offer', true );
		$price        = (string) get_post_meta( $record_id, '_estat_price', true );
		$rent         = (string) get_post_meta( $record_id, '_estat_rent', true );
		$availability = (string) get_post_meta( $record_id, '_estat_availability', true );
		$checked      = (string) get_post_meta( $record_id, '_estat_owner_checked_at', true );
		$is_rent      = in_array( $offer, array( 'rent', 'lease' ), true );

		$out .= '<h1 class="estat-pocket-title">' . esc_html( (string) $post->post_title ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' . esc_html(
			trim(
				( $is_rent && '' !== $rent ? Format::money( (float) $rent ) . __( ' a month', 'estat-os' ) : ( '' !== $price ? Format::money( (float) $price ) : __( 'No price on this one yet', 'estat-os' ) ) )
				. ' · ' . Status::label( Status::AVAILABILITY, '' !== $availability ? $availability : 'available' )
			)
		) . '</p>';
		$out .= '<p class="estat-pocket-hint">' . (
			'' !== $checked
				/* translators: %s: date the owner was last spoken to. */
				? esc_html( sprintf( __( 'You last checked this with the owner on %s.', 'estat-os' ), Format::date( $checked ) ) )
				: esc_html__( 'This has never been checked with the owner.', 'estat-os' ) )
			. '</p>';

		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'capture-owner' ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="owner_update">';
		$out .= '<input type="hidden" name="record_id" value="' . (int) $record_id . '">';

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'Is the money still right?', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-bigchoice">';
		$out .= self::big_choice( 'price_ok', 'yes', 'check', __( 'Yes, unchanged', 'estat-os' ) );
		$out .= self::big_choice( 'price_ok', 'no', 'pencil', __( 'It has changed', 'estat-os' ) );
		$out .= '</div>';
		$out .= self::field(
			$is_rent ? __( 'New rent a month (only if it changed)', 'estat-os' ) : __( 'New price (only if it changed)', 'estat-os' ),
			'price',
			'text',
			'',
			$is_rent ? '75000' : '18500000'
		);

		$out .= '<p class="estat-pocket-label">' . esc_html__( 'Is it still available?', 'estat-os' ) . '</p>';
		$out .= self::select_field(
			__( 'Availability', 'estat-os' ),
			'availability',
			Status::labels( Status::AVAILABILITY ),
			'' !== $availability ? $availability : 'available'
		);

		$out .= self::area_field( __( 'What did the owner say?', 'estat-os' ), 'notes', '', __( 'Happy to negotiate by a lakh. Wants the deal before Diwali.', 'estat-os' ) );
		$out .= '<button class="estat-pocket-btn is-go estat-pocket-big" type="submit">' . esc_html__( 'Save the owner update', 'estat-os' ) . '</button>';
		$out .= '</form>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'A price or availability change goes to the office for approval — the website only moves when they say yes. Checking with the owner is recorded here straight away.', 'estat-os' ) . '</p>';

		return $out;
	}

	/**
	 * More — everything that is not part of a normal day.
	 *
	 * The bottom bar has room for five things; the product has more than
	 * five. The rest lives here, plainly named, instead of being squeezed
	 * onto the bar or hidden behind an icon nobody can guess.
	 *
	 * @return string
	 */
	private static function more(): string {
		$out = '';

		$groups = array();

		$work = array();
		if ( Pocket::is_office() ) {
			$waiting = Requests::query( array( 'status' => 'pending', 'per_page' => 50 ) );
			$work[]  = array( 'approvals', 'check-circle', __( 'Waiting for you', 'estat-os' ), sprintf(
				/* translators: %d: how many requests are waiting. */
				_n( '%d change request', '%d change requests', (int) $waiting['total'], 'estat-os' ),
				(int) $waiting['total']
			) );
		}
		$work[] = array( 'change', 'pencil', __( 'Ask the office for a change', 'estat-os' ), __( 'A price, a photograph, a status — reviewed by a person.', 'estat-os' ) );
		$work[] = array( 'queue', 'clock', __( 'Waiting to go up', 'estat-os' ), __( 'Filled in where there was no network. The phone sends them when it can.', 'estat-os' ) );
		$work[] = array( 'listings', 'buildings', __( 'Societies and projects', 'estat-os' ), __( 'Society pages, apart from the property list.', 'estat-os' ), array( 'show' => 'societies' ) );

		$groups[] = array( __( 'Work', 'estat-os' ), $work );

		$groups[] = array(
			__( 'You', 'estat-os' ),
			array(
				array( 'you', 'person', __( 'Your details', 'estat-os' ), __( 'Name, numbers, language, password.', 'estat-os' ) ),
				array( 'search', 'search', __( 'Search everything', 'estat-os' ), __( 'Clients, properties and visits in one box.', 'estat-os' ) ),
			),
		);

		if ( Pocket::is_office() ) {
			$groups[] = array(
				__( 'Office', 'estat-os' ),
				array(
					array( 'approvals', 'list-checks', __( 'Approvals', 'estat-os' ), __( 'New listings and changes sent up from the phones.', 'estat-os' ) ),
				),
			);
		}

		foreach ( $groups as $group ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( $group[0] ) . '</h2>';
			$out .= '<div class="estat-pocket-sheet">';
			foreach ( $group[1] as $row ) {
				$url = '' !== (string) ( $row[4]['show'] ?? '' )
					? add_query_arg( 'show', (string) $row[4]['show'], Pocket::url( $row[0] ) )
					: Pocket::url( $row[0] );
				$out .= '<a class="estat-pocket-sheet-row" href="' . esc_url( $url ) . '">' .
					'<span class="estat-pocket-well">' . Pocket::icon( $row[1], 18 ) . '</span>' .
					'<span class="estat-pocket-rowmain"><b>' . esc_html( $row[2] ) . '</b><i>' . esc_html( $row[3] ) . '</i></span>' .
					Pocket::icon( 'chevron-right', 16 ) . '</a>';
			}
			$out .= '</div>';
		}

		return $out;
	}

	/**
	 * What this phone is still holding (Pocket 2.2).
	 *
	 * Saves made with no network live on the phone itself until they can
	 * go up, and this is where they are seen: what each one is, when it
	 * was filled, and how many times the phone has tried. Nothing here
	 * decides anything — sending goes through the same action a save
	 * always uses, and the server still checks every answer it is given.
	 *
	 * The rows are drawn by the phone, because the entries are on the
	 * phone; the screen itself only brings the paper.
	 *
	 * @return string
	 */
	private static function queue_page(): string {
		$out  = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url() ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';
		$out .= '<p class="estat-pocket-lead">' . esc_html__( 'Filled in where there was no network. Each one goes up by itself as soon as the phone can send it.', 'estat-os' ) . '</p>';
		$out .= '<div class="estat-pocket-card estat-pk-queue">';
		$out .= '<div class="estat-pocket-hint" id="estat-q-empty">' . esc_html__( 'Nothing is waiting. Everything you filled in has gone up.', 'estat-os' ) . '</div>';
		$out .= '<div id="estat-q-rows"></div>';
		$out .= '</div>';
		$out .= '<script>' . self::queue_rows_script() . '</script>';

		return $out;
	}

	/**
	 * The rows for the waiting screen, filled from the phone itself.
	 *
	 * @return string
	 */
	private static function queue_rows_script(): string {
		return 'document.addEventListener("DOMContentLoaded",function(){'
			. 'if(!window.estatQueueAll){return;}'
			. 'var rows=document.getElementById("estat-q-rows");'
			. 'if(!rows){return;}'
			. 'var empty=document.getElementById("estat-q-empty");'
			. 'var TU="' . esc_js( __( 'A new property', 'estat-os' ) ) . '";'
			. 'var T1="' . esc_js( __( 'just now', 'estat-os' ) ) . '";'
			. 'var T2="' . esc_js( __( 'minutes ago', 'estat-os' ) ) . '";'
			. 'var T3="' . esc_js( __( 'hours ago', 'estat-os' ) ) . '";'
			. 'var T4="' . esc_js( __( 'tried %d times', 'estat-os' ) ) . '";'
			. 'var T5="' . esc_js( __( 'Send now', 'estat-os' ) ) . '";'
			. 'var T6="' . esc_js( __( 'Take it off this phone', 'estat-os' ) ) . '";'
			. 'var T7="' . esc_js( __( 'Take this off the phone? What was filled in is lost.', 'estat-os' ) ) . '";'
			. 'function title(item){var t="";(item.pairs||[]).forEach(function(p){if(p[0]==="title"&&typeof p[1]==="string"){t=p[1];}});return t||TU;}'
			. 'function ago(at){if(!at){return "";}var m=Math.round((Date.now()-at)/60000);if(m<1){return T1;}if(m<60){return m+" "+T2;}return Math.round(m/60)+" "+T3;}'
			. 'function draw(items){'
			. 'if(empty){empty.hidden=items.length>0;}'
			. 'rows.innerHTML="";'
			. 'items.sort(function(a,b){return (a.at||0)-(b.at||0);});'
			. 'items.forEach(function(item){'
			. 'var row=document.createElement("div");row.className="estat-q-row";'
			. 'var main=document.createElement("div");main.className="estat-q-main";'
			. 'var name=document.createElement("b");name.textContent=title(item);main.appendChild(name);'
			. 'var meta=document.createElement("span");meta.className="estat-q-when";'
			. 'var when=ago(item.at);'
			. 'if(item.tries){when=when+" · "+T4.replace("%d",item.tries);}'
			. 'meta.textContent=when;main.appendChild(meta);row.appendChild(main);'
			. 'var acts=document.createElement("div");acts.className="estat-q-acts";'
			. 'var send=document.createElement("button");send.type="button";send.textContent=T5;'
			. 'send.addEventListener("click",function(){estatQueueFlush();setTimeout(refresh,1600);});acts.appendChild(send);'
			. 'var drop=document.createElement("button");drop.type="button";drop.className="is-quiet";drop.textContent=T6;'
			. 'drop.addEventListener("click",function(){if(!window.confirm(T7)){return;}estatQueueDel(item.id).then(refresh);});acts.appendChild(drop);'
			. 'row.appendChild(acts);rows.appendChild(row);'
			. '});'
			. '}'
			. 'function refresh(){estatQueueAll().then(draw).catch(function(){});}'
			. 'refresh();'
			. '});';
	}

	/**
	 * Search — one box for the whole office.
	 *
	 * Clients, properties and visits in one answer, grouped so the eye can
	 * skip what it does not need. Everything is looked up on the server
	 * against the person's own permissions; nothing is cached in the browser
	 * and no more than a page of each kind ever travels.
	 *
	 * @return string
	 */
	private static function search_page(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_GET['q'] ) ? '' : $_GET['q'] ) ) ) : '';

		$out = '<form class="estat-pocket-search" method="get" action="' . esc_url( Pocket::url( 'search' ) ) . '" role="search">' .
			Pocket::icon( 'search', 18 ) .
			'<input type="search" name="q" value="' . esc_attr( $q ) . '" autofocus placeholder="' . esc_attr__( 'Search a client, a property, a visit', 'estat-os' ) . '" aria-label="' . esc_attr__( 'Search anything', 'estat-os' ) . '">' .
			'</form>';

		if ( mb_strlen( trim( $q ) ) < 2 ) {
			return $out . self::empty_state(
				__( 'Find anything in the office', 'estat-os' ),
				__( 'Type a name, a number, a sector or a property — “Rahul”, “Sector 49”, “3 BHK”, “98765”. Two letters is enough to start.', 'estat-os' ),
				Pocket::url( 'leads' ),
				__( 'Open the client list', 'estat-os' )
			);
		}

		$found = array();

		/* --------------------------------------------------------- people */
		if ( self::may_see_enquiries() ) {
			$leads = Leads::query( array_merge( self::leads_scope(), array( 'search' => $q, 'per_page' => 8 ) ) );
			$rows  = '';
			foreach ( (array) $leads['items'] as $lead ) {
				$rows .= self::lead_card( $lead );
			}
			if ( '' !== $rows ) {
				$found[] = array( __( 'People', 'estat-os' ), $rows );
			}
		}

		/* ----------------------------------------------------- properties */
		$records = Pocket::my_records( $q, PostTypes::LISTING );
		if ( $records ) {
			$rows = '';
			foreach ( array_slice( (array) $records, 0, 8 ) as $post ) {
				$rows .= self::record_row( (int) $post->ID );
			}
			if ( '' !== $rows ) {
				$found[] = array( __( 'Properties', 'estat-os' ), $rows );
			}
		}

		/* ---------------------------------------------------------- visits */
		if ( current_user_can( 'estat_manage_visits' ) ) {
			$scope = Pocket::is_office() ? array() : array( 'agent_id' => Pocket::agent_id() );
			$all   = Visits::query( array_merge( $scope, array( 'per_page' => 50 ) ) );
			$needle = mb_strtolower( $q );
			$rows  = '';
			$hits  = 0;
			foreach ( (array) $all['items'] as $visit ) {
				$lead  = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
				$name  = $lead ? (string) $lead['name'] : '';
				$title = (int) $visit['listing_id'] > 0 ? (string) get_the_title( (int) $visit['listing_id'] ) : '';
				if ( false === mb_strpos( mb_strtolower( $name . ' ' . $title ), $needle ) ) {
					continue;
				}
				$rows .= self::visit_card( $visit );
				++$hits;
				if ( $hits >= 5 ) {
					break;
				}
			}
			if ( '' !== $rows ) {
				$found[] = array( __( 'Visits', 'estat-os' ), $rows );
			}
		}

		if ( ! $found ) {
			return $out . self::empty_state(
				__( 'Nothing found', 'estat-os' ),
				sprintf(
					/* translators: %s: what was typed. */
					__( 'Nothing in the office matches “%s”. Try fewer letters, or the number without spaces.', 'estat-os' ),
					$q
				),
				Pocket::url( 'capture' ),
				__( 'Add something new', 'estat-os' )
			);
		}

		foreach ( $found as $group ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( $group[0] ) . '</h2>' . $group[1];
		}

		return $out;
	}

	/**
	 * An empty screen that still has something to do on it.
	 *
	 * @param string $title   One line, bold.
	 * @param string $detail  Why it is empty and what fills it.
	 * @param string $url     Where to go.
	 * @param string $action  Button words.
	 * @return string
	 */
	private static function empty_state( string $title, string $detail, string $url, string $action ): string {
		$out  = '<div class="estat-pocket-empty">';
		$out .= '<b>' . esc_html( $title ) . '</b>';
		$out .= '<p>' . esc_html( $detail ) . '</p>';
		if ( '' !== $url && '' !== $action ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_url( $url ) . '">' . esc_html( $action ) . '</a>';
		}
		return $out . '</div>';
	}

	/**
	 * One lead event, as words a person would say.
	 *
	 * @param array<string,mixed> $event Event row.
	 * @return string
	 */
	private static function event_words( array $event ): string {
		$type    = (string) $event['event'];
		$payload = is_string( $event['payload'] ?? null ) ? json_decode( (string) $event['payload'], true ) : (array) ( $event['payload'] ?? array() );
		$payload = is_array( $payload ) ? $payload : array();

		switch ( $type ) {
			case 'created':
				return __( 'Enquiry received', 'estat-os' );
			case 'visit_booked':
				return __( 'Site visit booked', 'estat-os' );
			case 'visit_checks':
				return __( 'Visit prepared', 'estat-os' );
			case 'visit_started':
				return __( 'Visit started', 'estat-os' );
			case 'visit_done':
				return __( 'Visit completed', 'estat-os' );
			case 'visit_no_show':
				return __( 'Client said no after the visit', 'estat-os' );
			case 'visit_cancelled':
				return __( 'Visit cancelled', 'estat-os' );
			case 'visit_next':
				/* translators: %s: the next step chosen after a visit. */
				return sprintf( __( 'Next step: %s', 'estat-os' ), (string) ( $payload['next'] ?? '' ) );
			case 'status':
				return sprintf(
					/* translators: 1: old state, 2: new state. */
					__( 'Moved from %1$s to %2$s', 'estat-os' ),
					Status::label( Status::LEAD, (string) ( $payload['from'] ?? '' ) ),
					Status::label( Status::LEAD, (string) ( $payload['to'] ?? '' ) )
				);
			case 'note':
				return __( 'A note was added', 'estat-os' );
			case 'assigned':
				return __( 'Handed to a team member', 'estat-os' );
		}

		return ucfirst( str_replace( '_', ' ', $type ) );
	}


	/**
	 * The states this enquiry can be moved to from where it is.
	 *
	 * A select that offers every state invites a jump nobody can take — the
	 * server would refuse it, and the agent would be left staring at an error
	 * for a button the app itself put in front of them. So the list is built
	 * from the same rules the server enforces: the current state, plus the
	 * steps that are actually open. The office keeps the full list, because
	 * the office may put any record back on track by hand.
	 *
	 * @param string $status Current stored status.
	 * @return array<string,string>
	 */
	private static function lead_steps_from( string $status ): array {
		$all = Vocabulary::lead_statuses();
		if ( Pocket::is_office() ) {
			return $all;
		}

		$current = \EstatOS\Support\Status::label( \EstatOS\Support\Status::LEAD, $status );
		$out     = array( $status => $current );
		foreach ( \EstatOS\Support\Status::transitions( \EstatOS\Support\Status::LEAD, $status ) as $next ) {
			if ( $next !== $status && isset( $all[ $next ] ) ) {
				$out[ $next ] = $all[ $next ];
			}
		}

		return $out;
	}

	/**
	 * Leads scope: the office sees all, an agent sees only leads carried by
	 * their agent record. An agent whose record does not exist yet sees
	 * nothing — unassigned enquiries are the office's pile, not a free-for-
	 * all for whoever signs in first.
	 *
	 * @return array<string,int>
	 */
	/**
	 * May the person holding the phone see enquiries at all?
	 *
	 * The office always may. A staff member may too, unless the office has
	 * switched that off under Settings → Staff app — some offices want the
	 * phone for adding properties and nothing else.
	 *
	 * @return bool
	 */
	public static function may_see_enquiries(): bool {
		return Pocket::is_office() || (bool) \EstatOS\Settings\Settings::get( 'pocket_show_enquiries', true );
	}

	/**
	 * Which enquiries this phone may look at.
	 *
	 * @return array<string,mixed>
	 */
	public static function leads_scope(): array {
		if ( Pocket::is_office() ) {
			return array();
		}
		$agent = Pocket::agent_id();
		return array( 'agent_id' => $agent > 0 ? $agent : -1 );
	}

	/**
	 * Is this one client the agent's own?
	 *
	 * The office may open anybody's. A staff member may open the ones they
	 * took themselves and the ones the office handed to them — the same two
	 * doors the queries use, so nothing can be reached here that a list
	 * would not have shown.
	 *
	 * @param array<string,mixed> $lead Lead row.
	 * @return bool
	 */
	public static function lead_is_mine( array $lead ): bool {
		if ( Pocket::is_office() ) {
			return true;
		}
		$agent = Pocket::agent_id();
		if ( $agent <= 0 ) {
			return false;
		}
		return (int) $lead['agent_id'] === $agent
			|| ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent );
	}

	/* ---------------------------------------------------------------------
	 * Listings
	 * ------------------------------------------------------------------ */

	/**
	 * The list, with search. Rows carry the status pill and nothing else —
	 * the actions live on the detail page, where there is room to explain.
	 *
	 * @return string
	 */
	private static function listings(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['q']) ? '' : $_GET['q'] ) ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$raw_show = isset( $_GET['show'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['show'] ) ? '' : $_GET['show'] ) ) ) : 'properties';
		$show     = in_array( $raw_show, array( 'properties', 'societies' ), true ) ? $raw_show : 'properties';
		$kind     = 'societies' === $show ? PostTypes::PROJECT : PostTypes::LISTING;

		$rows = Pocket::my_records( $q, $kind );

		$out = '<form method="get" action="' . esc_url( Pocket::url( 'listings' ) ) . '" class="estat-pocket-search">' .
			'<input type="hidden" name="show" value="' . esc_attr( $show ) . '">' .
			'<input class="estat-pocket-input" type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="' .
			esc_attr__( 'Search title or locality', 'estat-os' ) . '"><button class="estat-pocket-btn" type="submit">' .
			Pocket::icon( 'search', 16 ) . '</button></form>';

		/*
		 * Properties and societies are two lists, never one.
		 *
		 * A phone showing a society inside a list of flats is a phone that
		 * makes people scroll past things they cannot act on — and tap into a
		 * property form for something that is not a property. So: one list at
		 * a time, a chip to switch, and the second chip only appears when
		 * there is something behind it.
		 */
		$societies = count( Pocket::my_records( '', PostTypes::PROJECT ) );
		if ( $societies > 0 ) {
			$out .= '<div class="estat-pocket-chips">' .
				self::list_chip( 'properties', __( 'Properties', 'estat-os' ), $show ) .
				self::list_chip( 'societies', __( 'Societies & Projects', 'estat-os' ), $show ) .
				'</div>';
		}

		if ( ! $rows ) {
			if ( 'societies' === $show ) {
				$out .= '<div class="estat-pocket-empty"><span class="estat-pocket-empty-mark">' . Pocket::icon( 'buildings', 22 ) . '</span>' .
					'<p>' . esc_html__( 'No societies or projects here yet.', 'estat-os' ) . '</p>' .
					'<p class="estat-pocket-hint">' . esc_html__( 'Societies and projects are looked after on the office screens.', 'estat-os' ) . '</p></div>';
			} else {
				$out .= '<div class="estat-pocket-empty"><span class="estat-pocket-empty-mark">' . Pocket::icon( 'form', 22 ) . '</span>' .
					'<p>' . esc_html__( 'No properties here yet. Add starts the first one.', 'estat-os' ) . '</p>' .
					'<a class="estat-pocket-btn is-go" href="' . esc_url( Pocket::url( 'new' ) ) . '">' . esc_html__( 'Add a property', 'estat-os' ) . '</a></div>';
			}
		} else {
			foreach ( $rows as $post ) {
				if ( ! Pocket::can_see( $post ) ) {
					continue; // however the query was shaped, the door is one rule.
				}
				$out .= self::record_row( (int) $post->ID );
			}
		}

		return $out . self::bin_section();
	}

	/**
	 * One chip: a link to the properties list or the societies list.
	 *
	 * @param string $slug  'properties' or 'societies'.
	 * @param string $label Words on the chip.
	 * @param string $show  Which list is open now.
	 * @return string
	 */
	private static function list_chip( string $slug, string $label, string $show ): string {
		$on = $slug === $show;
		return '<a class="' . ( $on ? 'is-on' : '' ) . '" href="' .
			esc_url( add_query_arg( 'show', $slug, Pocket::url( 'listings' ) ) ) . '">' .
			( $on ? Pocket::icon( 'check', 14 ) . ' ' : '' ) . esc_html( $label ) . '</a>';
	}

	/**
	 * What is in the bin, and the way back.
	 *
	 * Moving a property to the bin from a phone means "take it off the
	 * website and keep the details". That is only half an answer unless the
	 * phone can also show what is waiting in the bin, so this section sits
	 * quietly at the bottom of the list, closed, and opens to a Restore
	 * press for each property.
	 *
	 * @return string
	 */
	private static function bin_section(): string {
		// Two bins, because a binned society is not a binned flat: the office
		// puts both back the same way, but nobody should have to read a list
		// that quietly mixes them.
		return self::bin_group( Pocket::binned_records( PostTypes::LISTING ) ) .
			self::bin_group( Pocket::binned_records( PostTypes::PROJECT ) );
	}

	/**
	 * One bin, for one kind of record.
	 *
	 * @param \WP_Post[] $binned Records waiting in the bin.
	 * @return string
	 */
	private static function bin_group( array $binned ): string {
		if ( ! $binned ) {
			return '';
		}

		$count = count( $binned );
		$noun  = PostTypes::PROJECT === $binned[0]->post_type
			/* translators: %d: how many societies or projects are in the bin. */
			? sprintf( _n( '%d society or project in the bin', '%d societies or projects in the bin', $count, 'estat-os' ), $count )
			/* translators: %d: how many properties are in the bin. */
			: sprintf( _n( '%d property in the bin', '%d properties in the bin', $count, 'estat-os' ), $count );

		$out = '<details class="estat-pocket-card estat-pk-bin"><summary>' .
			Pocket::icon( 'inbox', 16 ) . ' ' . esc_html( $noun ) . '</summary>';
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'Being in the bin takes it off the website and keeps its details here. Nothing is gone for good. You can bring it back.', 'estat-os' ) . '</p>';

		foreach ( $binned as $post ) {
			$id   = (int) $post->ID;
			$mine = Pocket::owns( $id ) || Pocket::is_office();
			$out .= '<div class="estat-pk-bin-row"><span class="estat-pk-bin-name">' . esc_html( get_the_title( $id ) ) . '</span>';
			$out .= $mine
				? self::button( 'restore_listing', $id, __( 'Restore', 'estat-os' ), true )
				: '<span class="estat-pocket-pill">' . esc_html__( 'Somebody else put this in the bin', 'estat-os' ) . '</span>';
			$out .= '</div>';
		}

		return $out . '</details>';
	}

	/**
	 * One listing row, reused by the office approvals list.
	 *
	 * @param int $record_id Post ID.
	 * @return string
	 */
	public static function record_row( int $record_id ): string {
		$post = get_post( $record_id );
		if ( ! $post ) {
			return '';
		}
		list( $label, $tone ) = Pocket::status_of( $post );

		$is_project = PostTypes::PROJECT === $post->post_type;
		$price      = trim( (string) get_post_meta( $record_id, $is_project ? '_estat_price_min' : '_estat_price', true ) );
		$rent       = $is_project ? '' : trim( (string) get_post_meta( $record_id, '_estat_rent', true ) );
		$offer      = $is_project ? '' : (string) get_post_meta( $record_id, '_estat_offer', true );
		$price_in   = '' !== $rent && ( '' === $price || 'rent' === $offer || 'lease' === $offer ) ? $rent : $price;
		$money      = '' !== $price_in ? Format::money( (float) $price_in ) : '';
		// A society row says what it is; the money stands where the words do
		// not, and never the other way round.
		$line = $is_project
			? __( 'Society / Project', 'estat-os' ) . ( '' !== $money ? ' · ' . $money : '' )
			: $money;
		$standing = array(
			'draft'   => __( 'Not finished yet', 'estat-os' ),
			'pending' => __( 'With the office', 'estat-os' ),
			'publish' => __( 'On the website', 'estat-os' ),
			'private' => __( 'Paused', 'estat-os' ),
		);

		/*
		 * A property is several facts at once, and a card must not squash them
		 * into one word. The pill beside the name is where it stands on the
		 * website; these quieter chips underneath are whether it can still be
		 * offered and whether anyone has checked it.
		 */
		$chips = array();
		if ( ! $is_project ) {
			foreach ( array(
				\EstatOS\Support\Status::AVAILABILITY => '_estat_availability',
				\EstatOS\Support\Status::VERIFICATION => '_estat_verification',
			) as $family => $meta_key ) {
				$value = (string) get_post_meta( $record_id, $meta_key, true );
				if ( '' !== $value ) {
					$word = \EstatOS\Support\Status::label( $family, $value );
					if ( '' !== $word ) {
						$chips[] = $word;
					}
				}
			}
		}

		$thumb = get_the_post_thumbnail( $record_id, 'thumbnail', array( 'class' => 'estat-pocket-thumb' ) );
		$thumb = $thumb ? $thumb : '<span class="estat-pocket-thumb is-empty">' . Pocket::icon( 'image', 18 ) . '</span>';

		$facts = $chips
			? '<span class="estat-pocket-facts">' . esc_html( implode( ' · ', $chips ) ) . '</span>'
			: '';

		return sprintf(
			'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-thumbwrap">%2$s</span>' .
			'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s%5$s</i>%8$s</span>' .
			( '' !== $label ? '<span class="estat-pocket-pill %6$s">%7$s</span>' : '' ) . '</a>',
			esc_url( Pocket::url( 'listing', $record_id ) ),
			$thumb,
			esc_html( get_the_title( $record_id ) ),
			esc_html( $line ),
			'' !== $line ? '' : esc_html( $standing[ (string) $post->post_status ] ?? '' ),
			'' !== $tone ? 'is-' . $tone : '',
			esc_html( $label ),
			$facts
		);
	}

	/* ---------------------------------------------------------------------
	 * Listing detail and forms
	 * ------------------------------------------------------------------ */

	/**
	 * One record, everything the phone needs to know about it, and exactly
	 * the actions this person is allowed for it. No hidden buttons: if the
	 * server would refuse it, the pocket does not offer it.
	 *
	 * @param int $record_id Post ID.
	 * @return string|false
	 */
	private static function listing( int $record_id ) {
		$post = get_post( $record_id );
		if ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) || ! Pocket::can_see( $post ) ) {
			return Pocket::fail_to_today( 'gone' );
		}

		list( $label, $tone ) = Pocket::status_of( $post );
		$mine = Pocket::owns( $record_id ) || Pocket::is_office();

		/*
		 * A society or a project is not a property. It has its own fields,
		 * its own screens, and its own place in the office. Showing it a
		 * property form on a phone — "carry on editing", price, bedrooms —
		 * would be a phone guessing at something it does not own. So the
		 * pocket shows it, plainly, and says where it is looked after.
		 */
		if ( PostTypes::PROJECT === $post->post_type ) {
			return self::project_page( $post );
		}

		$meta = Meta::listing_schema();

		$out = '<h1 class="estat-pocket-title">' . esc_html( get_the_title( $record_id ) ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' .
			( '' !== $label ? '<span class="estat-pocket-pill ' . ( '' !== $tone ? 'is-' . $tone : '' ) . '">' . esc_html( $label ) . '</span> ' : '' ) .
			esc_html__( 'Last touched', 'estat-os' ) . ' ' . esc_html( Format::date( (string) $post->post_modified ) ) .
			'</p>';

		if ( 'publish' === $post->post_status ) {
			$url = Pocket::public_url( $record_id );
			if ( '' !== $url ) {
				$out .= '<a class="estat-pocket-row" href="' . esc_url( $url ) . '"><span class="estat-pocket-well">' .
					Pocket::icon( 'eye', 18 ) . '</span><span class="estat-pocket-rowmain"><b>' .
					esc_html__( 'See it on the website', 'estat-os' ) . '</b></span>' . Pocket::icon( 'external', 16 ) . '</a>';
			}
		}

		// The facts, in the order they are typed, not in the order of the
		// schema — this is the phone, not the settings room.
		$facts = array(
			'_estat_offer'    => __( 'Offer', 'estat-os' ),
			'_estat_property_type' => __( 'Type', 'estat-os' ),
			'_estat_price'    => __( 'Price', 'estat-os' ),
			'_estat_rent'     => __( 'Rent', 'estat-os' ),
			'_estat_bedrooms' => __( 'Bedrooms', 'estat-os' ),
			'_estat_bathrooms'=> __( 'Bathrooms', 'estat-os' ),
			'_estat_address'  => __( 'Address', 'estat-os' ),
			'_estat_availability' => __( 'Availability', 'estat-os' ),
		);
		$rows  = '';
		foreach ( $facts as $key => $word ) {
			$raw = (string) get_post_meta( $record_id, $key, true );
			if ( '' === $raw ) {
				continue;
			}
			$nice = $raw;
			if ( in_array( $key, array( '_estat_price', '_estat_rent' ), true ) ) {
				$nice = Format::money( (float) $raw );
			} elseif ( isset( $meta[ $key ] ) ) {
				$nice = self::nicely( $key, $raw );
			}
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html( $word ) . '</i><b>' . esc_html( $nice ) . '</b></div>';
		}
		if ( '' !== trim( (string) $post->post_content ) ) {
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html__( 'Description', 'estat-os' ) . '</i><b>' .
				esc_html( self::excerpt( (string) $post->post_content ) ) . '</b></div>';
		}
		if ( '' !== $rows ) {
			$out .= '<div class="estat-pocket-card">' . $rows . '</div>';
		}

		// Voice notes, before the photographs: somebody's own words about a
		// flat are the quickest way for the office to hear what matters.
		$notes = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $record_id, '_estat_voice_notes', true ) ) ) );
		$wrote = (string) get_post_meta( $record_id, '_estat_voice_text', true );
		if ( $notes || '' !== $wrote ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( sprintf(
				/* translators: %d: how many voice notes. */
				_n( '%d voice note', '%d voice notes', count( $notes ), 'estat-os' ),
				count( $notes )
			) ) . '</h2>';
			if ( '' !== $wrote ) {
				$out .= '<p class="estat-pocket-quote">' . esc_html( $wrote ) . '</p>';
			}
			$out .= '<div class="estat-pk-voices">';
			foreach ( $notes as $note_id ) {
				$src = wp_get_attachment_url( $note_id );
				if ( ! $src ) {
					continue;
				}
				$out .= '<div class="estat-pk-voice">' . Pocket::icon( 'speaker-high', 18 ) .
					'<audio controls preload="metadata" src="' . esc_url( $src ) . '"></audio>' .
					'<span class="estat-pk-voice-when">' . esc_html( (string) get_the_date( 'j M Y', $note_id ) ) . '</span></div>';
			}
			$out .= '</div>';
		}

		// Photos already attached, then the actions.
		$pics = (array) get_post_meta( $record_id, '_estat_gallery', true );
		if ( $pics ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( sprintf( _n( '%d photo', '%d photos', count( $pics ), 'estat-os' ), count( $pics ) ) ) . '</h2>';
			$out .= '<div class="estat-pocket-photos">';
			foreach ( array_slice( $pics, 0, 8 ) as $pic ) {
				$src = wp_get_attachment_image_url( (int) $pic, 'thumbnail' );
				if ( $src ) {
					$out .= '<img src="' . esc_url( $src ) . '" alt="" class="estat-pocket-photo">';
				}
			}
			$out .= '</div>';
		}

		$pending_here = array();
		foreach ( Requests::query( array( 'record_id' => $record_id, 'status' => 'pending', 'per_page' => 10 ) )['items'] as $req ) {
			$pending_here[] = self::request_line( $req );
		}
		if ( $pending_here ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'With the office', 'estat-os' ) . '</h2><div class="estat-pocket-card">' .
				implode( '', $pending_here ) . '</div>';
		}

		/*
		 * The buttons, and one plain sentence about where this property is.
		 *
		 * A phone should never ask somebody to work out what "pending" means.
		 * Every state gets its own line: who can see it, what the buttons do,
		 * and what happens after they are pressed. The server checks the same
		 * rules again — this text is a promise, not the lock.
		 */
		$status   = (string) $post->post_status;
		$can_pub  = current_user_can( 'estat_publish_listings' );
		$actions  = '';

		$where = array(
			'draft'   => __( 'Only you can see this. It is not on the website yet.', 'estat-os' ),
			'pending' => __( 'Waiting for approval. Nothing is on the website until the office says yes.', 'estat-os' ),
			'publish' => $mine
				? __( 'It is live on the website.', 'estat-os' )
				: __( 'It is live on the website. It belongs to somebody else, so changes go to the office as a request.', 'estat-os' ),
			'private' => __( 'It is paused: off the website, and nothing has been deleted.', 'estat-os' ),
		);
		if ( isset( $where[ $status ] ) ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html( $where[ $status ] ) . '</p>';
		}

		if ( $mine && in_array( $status, array( 'draft', 'pending' ), true ) ) {
			$actions .= '<a class="estat-pocket-btn is-go" href="' . esc_url( Pocket::url( 'new', $record_id ) ) . '">' . esc_html__( 'Carry on editing', 'estat-os' ) . '</a>';
			if ( 'draft' === $status ) {
				$actions .= self::button( 'send', $record_id, __( 'Send for approval', 'estat-os' ), true );
			}
		}
		if ( $mine && 'publish' === $status ) {
			if ( $can_pub ) {
				// Publishing rights mean correcting a live page directly, the
				// same as the office editor does.
				$actions .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'new', $record_id ) ) . '">' . esc_html__( 'Edit details', 'estat-os' ) . '</a>';
			}
			$actions .= self::button( 'pause', $record_id, __( 'Pause — hide from the website', 'estat-os' ) );
		}
		if ( $mine && 'private' === $status ) {
			$actions .= self::button( 'resume', $record_id, __( 'Put it back on the website', 'estat-os' ), true );
		}
		if ( ! $mine && in_array( $status, array( 'publish', 'private' ), true ) ) {
			$actions .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'change', $record_id ) ) . '">' .
				esc_html__( 'Ask the office to change', 'estat-os' ) . '</a>';
		}
		if ( $mine && 'publish' === $status ) {
			$actions .= '<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'change', $record_id ) ) . '">' .
				esc_html__( 'Send a correction to the office', 'estat-os' ) . '</a>';
		}

		/*
		 * One press, one question, and a sentence that says exactly what will
		 * happen to a live page — in the office's own words. The word is
		 * Move to bin, never Delete: a phone cannot destroy anything, and
		 * saying so is what makes the press safe to make.
		 */
		if ( $mine && ( \EstatOS\Data\Bin::may_move( get_post( $record_id ) ) || current_user_can( 'estat_delete_listings' ) ) ) {
			$label = 'publish' === $status
				? __( 'Move it to the bin', 'estat-os' )
				: __( 'Move this property to the bin', 'estat-os' );
			$actions .= self::button( 'trash_draft', $record_id, $label, false, array( 'estat_pocket_confirm' => 'bin' ) );
			$bye = 'publish' === $status
				? __( 'Moving it to the bin takes it off the website and keeps the details in the office bin, where it can be restored.', 'estat-os' )
				: __( 'Moving it to the bin takes it off your list and keeps the details in the office bin, where it can be restored.', 'estat-os' );
			$out .= '<p class="estat-pocket-hint">' . esc_html( $bye ) . '</p>';
		}

		if ( '' !== $actions ) {
			$out .= '<div class="estat-pocket-actions">' . $actions . '</div>';
		}

		return $out;
	}

	/**
	 * One society or project, as much as a phone should show.
	 *
	 * Read-only on purpose: the office screens own these records, and the
	 * pocket's job here is to answer "what is this and where is it", not to
	 * offer a form that would write property fields onto a society.
	 *
	 * @param \WP_Post $post Project post.
	 * @return string
	 */
	private static function project_page( \WP_Post $post ): string {
		$record_id = (int) $post->ID;
		$project   = Projects::to_array( $record_id );
		list( $label, $tone ) = Pocket::status_of( $post );

		$out = '<h1 class="estat-pocket-title">' . esc_html( get_the_title( $record_id ) ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' .
			( '' !== $label ? '<span class="estat-pocket-pill ' . ( '' !== $tone ? 'is-' . $tone : '' ) . '">' . esc_html( $label ) . '</span> ' : '' ) .
			esc_html__( 'Society / Project', 'estat-os' ) . '</p>';

		if ( 'publish' === $post->post_status ) {
			$url = (string) ( $project['url'] ?? '' );
			if ( '' !== $url ) {
				$out .= '<a class="estat-pocket-row" href="' . esc_url( $url ) . '"><span class="estat-pocket-well">' .
					Pocket::icon( 'eye', 18 ) . '</span><span class="estat-pocket-rowmain"><b>' .
					esc_html__( 'See it on the website', 'estat-os' ) . '</b></span>' . Pocket::icon( 'external', 16 ) . '</a>';
			}
		}

		$localities = (array) ( $project['locality'] ?? array() );
		$facts      = array(
			__( 'Stage', 'estat-os' )          => (string) Vocabulary::label( 'project_statuses', (string) ( $project['stage'] ?? '' ) ),
			__( 'Builder or developer', 'estat-os' ) => (string) ( $project['developer'] ?? '' ),
			__( 'What kind of homes or units', 'estat-os' ) => (string) ( $project['project_type'] ?? '' ),
			__( 'Price from', 'estat-os' )     => (string) ( $project['price_display'] ?? '' ),
			__( 'Possession', 'estat-os' )     => ! empty( $project['possession_date'] ) ? Format::month_year( (string) $project['possession_date'] ) : '',
			__( 'Locality', 'estat-os' )       => implode( ', ', $localities ),
			__( 'Address', 'estat-os' )        => (string) ( $project['address'] ?? '' ),
		);

		$rows = '';
		foreach ( $facts as $word => $value ) {
			if ( '' === trim( (string) $value ) ) {
				continue;
			}
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html( (string) $word ) . '</i><b>' . esc_html( (string) $value ) . '</b></div>';
		}
		if ( '' !== trim( (string) $post->post_content ) ) {
			$rows .= '<div class="estat-pocket-fact"><i>' . esc_html__( 'Description', 'estat-os' ) . '</i><b>' .
				esc_html( self::excerpt( (string) $post->post_content ) ) . '</b></div>';
		}
		if ( '' !== $rows ) {
			$out .= '<div class="estat-pocket-card">' . $rows . '</div>';
		}

		$pending_here = array();
		foreach ( Requests::query( array( 'record_id' => $record_id, 'status' => 'pending', 'per_page' => 10 ) )['items'] as $req ) {
			$pending_here[] = self::request_line( $req );
		}
		if ( $pending_here ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'With the office', 'estat-os' ) . '</h2><div class="estat-pocket-card">' .
				implode( '', $pending_here ) . '</div>';
		}

		$out .= '<p class="estat-pocket-hint">' .
			esc_html__( 'Societies and projects are looked after on the office screens; the phone shows them.', 'estat-os' ) . '</p>';

		return $out;
	}

	/**
	 * A calm trim: the detail page shows four lines of story, not all of it.
	 *
	 * @param string $text Raw content.
	 * @return string
	 */
	private static function excerpt( string $text ): string {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
		if ( mb_strlen( $text ) <= 160 ) {
			return $text;
		}
		return mb_substr( $text, 0, 159 ) . '…';
	}

	/**
	 * Map a stored meta value back to the words the selects show.
	 *
	 * @param string $key   Meta key.
	 * @param string $value Raw value.
	 * @return string
	 */
	private static function nicely( string $key, string $value ): string {
		$vocabs = array(
			'_estat_offer'        => 'offers',
			'_estat_property_type' => 'property_types',
			'_estat_availability' => 'availability',
		);
		if ( isset( $vocabs[ $key ] ) ) {
			/*
			 * Vocabulary::label() also knows the older names (a record kept
			 * as "Flat" must read "Flat" on the phone, not "flat"), so the
			 * label always goes through it rather than through this list.
			 */
			return Vocabulary::label( $vocabs[ $key ], $value );
		}
		return $value;
	}

	/**
	 * A post form for one action, with the nonce.
	 *
	 * @param string $action Action slug.
	 * @param int    $id     Record ID.
	 * @param string $label  Button text.
	 * @param bool   $go     Primary style.
	 * @return string
	 */
	private static function button( string $action, int $id, string $label, bool $go = false, array $extra = array() ): string {
		$hidden = '';
		foreach ( $extra as $name => $value ) {
			$hidden .= '<input type="hidden" name="' . esc_attr( (string) $name ) . '" value="' . esc_attr( (string) $value ) . '">';
		}
		return sprintf(
			'<form method="post" action="%1$s" class="estat-pocket-inlineform"><input type="hidden" name="_estat_pocket" value="%2$s">' .
			'<input type="hidden" name="estat_pocket_action" value="%3$s"><input type="hidden" name="record_id" value="%4$d">%7$s' .
			'<button class="estat-pocket-btn%5$s" type="submit">%6$s</button></form>',
			esc_url( Pocket::url( 'listing', $id ) ),
			esc_attr( wp_create_nonce( 'estat_pocket' ) ),
			sanitize_key( $action ),
			(int) $id,
			$go ? ' is-go' : '',
			esc_html( $label ),
			$hidden
		);
	}

	/**
	 * A pending request, one line, old value struck where we have it.
	 *
	 * @param array<string,mixed> $req Row from the requests table.
	 * @return string
	 */
	private static function request_line( array $req ): string {
		$changes = json_decode( (string) $req['changes'], true );
		$fields  = is_array( $changes ) ? array_diff_key( $changes, array( 'note' => true ) ) : array();
		$defs    = Requests::editable_fields();

		$bits = array();
		foreach ( $fields as $key => $value ) {
			$word  = isset( $defs[ $key ] ) ? (string) $defs[ $key ]['label'] : ucfirst( (string) $key );
			$bits[] = $word . ': ' . $value;
		}

		$name = $bits ? implode( ' · ', $bits ) : __( 'A note for the office', 'estat-os' );

		return '<div class="estat-pocket-fact"><i>' .
			esc_html( Format::date( (string) $req['created_at'] ) ) . '</i><b>' . esc_html( $name ) .
			' <em>' . esc_html__( 'waiting', 'estat-os' ) . '</em></b></div>';
	}

	/**
	 * Add a property, or carry on with one that was started.
	 *
	 * The questions come from `Steps`, which is also what the parity test
	 * reads: if the office editor asks something this form cannot type, the
	 * test fails. The order is the order of a conversation — what and where,
	 * the money, the size, the photos, the words, one last look — and the
	 * office-only questions sit at the very end.
	 *
	 * @param int $record_id 0 for a new record.
	 * @return string|false
	 */
	private static function form( int $record_id ) {
		$post = $record_id > 0 ? get_post( $record_id ) : null;
		if ( $record_id > 0 && ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) ) {
			return Pocket::fail_to_today( 'gone' );
		}
		// This form writes property fields. It must never be pointed at a
		// society or project — not by a stray link, not by a typed URL.
		if ( $post && PostTypes::PROJECT === $post->post_type ) {
			return Pocket::fail( 'listing', $record_id, __( 'Societies and projects are edited on the office screens.', 'estat-os' ) );
		}
		if ( $post && ! ( ( 'draft' === $post->post_status || 'pending' === $post->post_status ) && ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) ) {
			return Pocket::fail_to_today( 'nope' );
		}

		$office = Pocket::is_office();
		$steps  = Steps::all( $office );
		$vals   = self::form_values( $record_id );
		$symbol = (string) \EstatOS\Settings\Settings::get( 'currency_symbol', '₹' );

		$action = esc_url( Pocket::url( 'new', $record_id ) );
		$out    = '<p class="estat-pocket-lead">' . esc_html__( 'Everything the office asks for, asked in the same order. Type what you know, save it as a draft, and the rest can follow.', 'estat-os' ) . '</p>';

		$out .= '<form class="estat-pocket-card" method="post" action="' . $action . '" enctype="multipart/form-data" id="estat-wizard-form">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="save_draft">';
		$out .= '<input type="hidden" name="record_id" value="' . (int) $record_id . '">';
		$out .= '<input type="hidden" name="estat_pocket_status" value="' . esc_attr( $post ? (string) $post->post_status : 'draft' ) . '">';
		// The phone's own name for this piece of work. A save that is tried
		// twice — network drop, then again when the bars come back — must
		// land on one record, not two. The script below keeps this name
		// steady across reloads and re-sends.
		$out .= '<input type="hidden" name="estat_client_id" value="' . esc_attr( substr( (string) wp_generate_uuid4(), 0, 32 ) ) . '">';

		// The stepper: one dot per step, the step's name underneath, and the
		// nudge line that appears when something required is still empty.
		$out .= '<div id="estat-wizard-progress" class="estat-pocket-card">';
		$out .= '<div class="estat-w-steps">';
		foreach ( $steps as $i => $step ) {
			$out .= '<button type="button" class="estat-w-dot" data-step="' . (int) ( $i + 1 ) . '" aria-label="' . esc_attr( (string) $step['title'] ) . '">' . (int) ( $i + 1 ) . '</button>';
		}
		$out .= '</div>';
		$out .= '<span id="estat-w-label" class="estat-pocket-hint" style="margin:0">' . esc_html( (string) $steps[0]['title'] ) . '</span>';
		$out .= '<span id="estat-w-error" class="estat-pocket-pill is-warn" style="display:none"></span>';
		$out .= '</div>';

		foreach ( $steps as $i => $step ) {
			$num  = (int) ( $i + 1 );
			$out .= '<div class="estat-w-step" data-wstep="' . $num . '"' . ( 1 === $num ? '' : ' style="display:none"' ) . '>';
			$out .= '<h3 class="estat-w-title">' . esc_html( sprintf( '%d / %d — %s', $num, count( $steps ), (string) $step['title'] ) ) . '</h3>';
			if ( '' !== (string) ( $step['hint'] ?? '' ) ) {
				$out .= '<p class="estat-pocket-hint">' . esc_html( (string) $step['hint'] ) . '</p>';
			}
			$out .= self::render_step( $step, $vals, $record_id, $symbol );
			$out .= '</div>';
		}

		$out .= '<div class="estat-pocket-actions estat-w-bar">';
		$out .= '<button class="estat-pocket-btn" type="button" id="estat-w-back" style="display:none">← ' . esc_html__( 'Back', 'estat-os' ) . '</button>';
		$out .= '<button class="estat-pocket-btn is-go" type="button" id="estat-w-next">' . esc_html__( 'Next', 'estat-os' ) . ' →</button>';
		$out .= '<button class="estat-pocket-btn" type="submit" name="estat_pocket_next" value="draft" id="estat-w-save" style="display:none">' . esc_html__( 'Save as draft', 'estat-os' ) . '</button>';
		$out .= '<button class="estat-pocket-btn is-go" type="submit" name="estat_pocket_next" value="send" id="estat-w-send" style="display:none">' . esc_html__( 'Send for approval', 'estat-os' ) . ' ✓</button>';
		$out .= '</div>';
		$out .= '</form>';

		$out .= self::wizard_script( $steps, (string) $symbol );

		return $out;
	}

	/**
	 * One step's fields, in order, paired two to a row where that reads well.
	 *
	 * @param array<string,mixed>  $step   Step definition.
	 * @param array<string,string> $vals   Current values.
	 * @param int                  $record_id Record being edited (0 for new).
	 * @param string               $symbol Currency symbol.
	 * @return string
	 */
	private static function render_step( array $step, array $vals, int $record_id, string $symbol ): string {
		$fields = (array) ( $step['fields'] ?? array() );
		if ( ! $fields ) {
			return '<div id="estat-w-review" class="estat-pocket-card estat-w-review"></div>';
		}

		/*
		 * Fields marked with a group are shown under one heading.
		 *
		 * The plan and the brochure are the same kind of thing — a paper
		 * the office has to keep — and reading them as two separate
		 * questions made the phone ask twice for one job. One heading,
		 * two choosers, nothing else changed.
		 */
		$group_titles = array(
			'papers' => array(
				'title' => __( 'Papers', 'estat-os' ),
				'hint'  => __( 'The plan, the brochure, anything the office should keep. A photo of the paper is fine.', 'estat-os' ),
			),
		);

		$out     = '';
		$rows    = self::group_rows( $fields );
		$in_open = '';

		foreach ( $rows as $row ) {
			$first = $row[0] ?? array();
			$key   = (string) ( $first['group'] ?? '' );

			// Close a group when this row belongs to a different one.
			if ( '' !== $in_open && $key !== $in_open ) {
				$out    .= '</div>';
				$in_open = '';
			}
			if ( '' !== $key && $key !== $in_open && isset( $group_titles[ $key ] ) ) {
				$out    .= '<div class="estat-pk-group" data-group="' . esc_attr( $key ) . '">';
				$out    .= '<h3 class="estat-pocket-h2">' . esc_html( (string) $group_titles[ $key ]['title'] ) . '</h3>';
				$out    .= '<p class="estat-pocket-hint">' . esc_html( (string) $group_titles[ $key ]['hint'] ) . '</p>';
				$in_open = $key;
			}

			if ( count( $row ) > 1 ) {
				$out .= '<div class="estat-pocket-pair">';
			}
			foreach ( $row as $field ) {
				$out .= self::render_field( $field, $vals, $record_id, $symbol );
			}
			if ( count( $row ) > 1 ) {
				$out .= '</div>';
			}
		}

		if ( '' !== $in_open ) {
			$out .= '</div>';
		}

		if ( 'check' === ( $step['key'] ?? '' ) ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'A draft is yours alone. Sending it asks the office to check and put it on the website.', 'estat-os' ) . '</p>';
		}

		return $out;
	}

	/**
	 * Put short numeric boxes side by side, and leave everything else full
	 * width. Two fields share a row only when they are both short numbers
	 * that appear or disappear together.
	 *
	 * @param array<int,array<string,mixed>> $fields Field definitions.
	 * @return array<int,array<int,array<string,mixed>>>
	 */
	private static function group_rows( array $fields ): array {
		$rows = array();
		$open = array();

		foreach ( $fields as $field ) {
			$pair = 'number' === ( $field['input'] ?? '' ) || in_array( (string) ( $field['row'] ?? '' ), array( 'map' ), true );
			if ( $pair && ! $open ) {
				$open = array( $field );
				continue;
			}
			if ( $pair && $open ) {
				$first = $open[0];
				$same  = (string) ( $first['only'] ?? '' ) === (string) ( $field['only'] ?? '' );
				$samerow = (string) ( $first['row'] ?? '' ) === (string) ( $field['row'] ?? '' );
				if ( $same && $samerow ) {
					$open[] = $field;
					$rows[] = $open;
					$open   = array();
					continue;
				}
				$rows[] = $open;
				$open   = array( $field );
				continue;
			}
			if ( $open ) {
				$rows[] = $open;
				$open   = array();
			}
			$rows[] = array( $field );
		}

		if ( $open ) {
			$rows[] = $open;
		}

		return $rows;
	}

	/**
	 * One control, with its label and its one line of help.
	 *
	 * @param array<string,mixed>  $field Field definition.
	 * @param array<string,string> $vals  Current values.
	 * @param int                  $record_id Record being edited.
	 * @param string               $symbol Currency symbol.
	 * @return string
	 */
	private static function render_field( array $field, array $vals, int $record_id, string $symbol ): string {
		$name  = (string) $field['name'];
		$input = (string) ( $field['input'] ?? 'text' );
		$value = (string) ( $vals[ $name ] ?? '' );
		$only  = (string) ( $field['only'] ?? '' );
		$wrap  = '' !== $only ? ' estat-only-' . $only : '';
		$req   = ! empty( $field['required'] );
		$label = (string) ( $field['label'] ?? '' );
		if ( '' === $label ) {
			$label = Steps::label( $name );
		}
		$help = (string) ( $field['help'] ?? '' );

		// The one money box: a sale's figure lives in _estat_price and a
		// rental's in _estat_rent, and the label follows the first answer.
		if ( 'money' === $input ) {
			$is_rental = in_array( (string) ( $vals['_estat_offer'] ?? '' ), array( 'rent', 'lease' ), true );
			if ( '' === $value ) {
				$value = (string) ( $vals['_estat_rent'] ?? '' );
			}
			$label = $is_rental
				? sprintf( /* translators: %s: currency symbol */ __( 'Monthly rent (%s)', 'estat-os' ), $symbol )
				: sprintf( /* translators: %s: currency symbol */ __( 'Price (%s)', 'estat-os' ), $symbol );
			$help  = $is_rental
				? __( 'Numbers only. This is what the tenant pays each month.', 'estat-os' )
				: __( 'Numbers only.', 'estat-os' );
			return sprintf(
				'<div class="estat-field-row estat-w-field estat-money-row%1$s" data-wfield="%2$s"><label class="estat-pocket-label" for="estat-pf-%2$s">%3$s</label>' .
				'<input class="estat-pocket-input" id="estat-pf-%2$s" name="_estat_price" type="number" min="0" value="%4$s" placeholder="%5$s"%6$s>' .
				'<span hidden class="estat-money-texts" data-sale-label="%7$s" data-rent-label="%8$s"></span></div>',
				esc_attr( $wrap ),
				esc_attr( $name ),
				esc_html( $label ),
				esc_attr( $value ),
				esc_attr( $is_rental ? '32000' : '8500000' ),
				$req ? ' required' : '',
				esc_attr( sprintf( /* translators: %s: currency symbol */ __( 'Price (%s)', 'estat-os' ), $symbol ) ),
				esc_attr( sprintf( /* translators: %s: currency symbol */ __( 'Monthly rent (%s)', 'estat-os' ), $symbol ) )
			);
		}

		$control = '';
		switch ( $input ) {
			case 'select':
				$vocab = (string) ( $field['vocab'] ?? '' );
				/*
				 * The record's own answer is always in the list — an older or
				 * imported name must not turn into a different choice just
				 * because the phone opened the form.
				 */
				$choices = Steps::options( $vocab );
				if ( '' !== $value && ! isset( $choices[ $value ] ) ) {
					$choices = Vocabulary::for_select( $vocab, $value );
				}
				$control = self::select_field( $label, $name, $choices, $value, (string) ( $field['blank'] ?? '' ), $req );
				break;
			case 'project':
				$control = self::select_field( $label, $name, Steps::projects(), $value, __( 'Not part of one', 'estat-os' ) );
				break;
			case 'agent':
				$control = self::select_field( $label, $name, Steps::agents(), $value, __( 'Nobody yet', 'estat-os' ) );
				break;
			case 'checkbox':
				$control = sprintf(
					'<label class="estat-pocket-check"><input type="checkbox" name="%1$s" id="estat-pf-%1$s" value="1"%2$s> <span>%3$s</span></label>',
					esc_attr( $name ),
					'1' === $value ? ' checked' : '',
					esc_html( (string) ( $field['checkbox'] ?? $label ) )
				);
				break;
			case 'textarea':
				$control = sprintf(
					'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label><textarea class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" rows="%3$d" placeholder="%4$s">%5$s</textarea>',
					esc_attr( $name ),
					esc_html( $label ),
					(int) ( $field['rows'] ?? 3 ),
					esc_attr( (string) ( $field['example'] ?? '' ) ),
					esc_textarea( $value )
				);
				break;
			case 'photos':
				return self::photo_card( $field, $record_id );
			case 'voice':
				return self::voice_card( $field, $record_id );
			case 'date':
				$control = sprintf(
					'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label><input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="date" value="%3$s">',
					esc_attr( $name ),
					esc_html( $label ),
					esc_attr( $value )
				);
				break;
			case 'url':
				$control = sprintf(
					'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label><input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="url" value="%3$s" placeholder="%4$s" inputmode="url">',
					esc_attr( $name ),
					esc_html( $label ),
					esc_attr( $value ),
					esc_attr( (string) ( $field['example'] ?? 'https://' ) )
				);
				break;
			case 'number':
				$control = sprintf(
					'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label><input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="number" min="0" value="%3$s" placeholder="%4$s" inputmode="numeric">',
					esc_attr( $name ),
					esc_html( $label ),
					esc_attr( $value ),
					esc_attr( (string) ( $field['example'] ?? '' ) )
				);
				break;
			default:
				$control = sprintf(
					'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label><input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="text" value="%3$s" placeholder="%4$s">',
					esc_attr( $name ),
					esc_html( $label ),
					esc_attr( $value ),
					esc_attr( (string) ( $field['example'] ?? '' ) )
				);
		}

		if ( $req ) {
			$help = trim( __( 'Needed.', 'estat-os' ) . ' ' . $help );
		}

		return sprintf(
			'<div class="estat-field-row estat-w-field%1$s" data-wfield="%2$s">%3$s%4$s</div>',
			esc_attr( $wrap ),
			esc_attr( $name ),
			$control,
			'' !== $help ? '<p class="estat-pocket-hint">' . esc_html( $help ) . '</p>' : ''
		);
	}

	/**
	 * One photo list: what is already there, and a box to add more.
	 *
	 * The star moves a photo to the front — the cover is simply the first
	 * photo in the list, so nothing new had to be invented to reorder it.
	 * The cross takes one out. Both are submitted with the same draft save,
	 * which means a photo added and another one starred in the same visit
	 * arrive together instead of fighting each other.
	 *
	 * @param array<string,mixed> $field Photo field definition.
	 * @param int                 $record_id Record being edited.
	 * @return string
	 */
	private static function photo_card( array $field, int $record_id ): string {
		$name   = (string) $field['name'];
		$upload = (string) ( $field['upload'] ?? 'estat_pocket_photos' );
		$is_cover_list = '_estat_gallery' === $name;

		$ids  = $record_id > 0 ? array_values( array_filter( array_map( 'intval', (array) get_post_meta( $record_id, $name, true ) ) ) ) : array();
		$cover = $is_cover_list ? (int) get_post_thumbnail_id( $record_id ) : 0;
		$out  = '<div class="estat-field-row estat-w-field" data-wfield="' . esc_attr( $name ) . '">';
		$out .= '<label class="estat-pocket-label">' . esc_html( (string) ( $field['label'] ?? Steps::label( $name ) ) ) . '</label>';

		/*
		 * What to shoot, and how many are enough.
		 *
		 * Somebody standing in a flat with a phone does not need a lecture
		 * about photography; they need the list in their head. The count
		 * line updates itself as photos are added, so the phone answers
		 * "is that enough?" without being asked.
		 */
		$shots = (array) ( $field['shots'] ?? array() );
		if ( $shots ) {
			$out .= '<div class="estat-pk-shots" data-min="6">';
			$out .= '<b>' . esc_html__( 'Worth shooting', 'estat-os' ) . '</b>';
			$out .= '<ul>';
			foreach ( $shots as $shot ) {
				$out .= '<li>' . esc_html( (string) $shot ) . '</li>';
			}
			$out .= '</ul>';
			$out .= '<i class="estat-pk-shots-count" data-have="' . count( $ids ) . '">' . esc_html( self::shots_line( count( $ids ) ) ) . '</i>';
			$out .= '</div>';
		}

		if ( $ids ) {
			$out .= '<div class="estat-pocket-photos estat-pk-photos" data-count="' . count( $ids ) . '">';
			foreach ( $ids as $index => $id ) {
				$src = wp_get_attachment_image_url( $id, 'thumbnail' );
				if ( ! $src ) {
					continue;
				}
				$is_main = $is_cover_list && ( $index === 0 || $id === $cover );
				$out .= '<div class="estat-pk-photo' . ( $is_main ? ' is-main' : '' ) . '">';
				$out .= '<img src="' . esc_url( $src ) . '" alt="" class="estat-pocket-photo">';
				if ( $is_cover_list ) {
					$out .= '<button type="submit" name="estat_pocket_cover" value="' . (int) $id . '" class="estat-pk-photo-btn is-star" title="' . esc_attr__( 'Make this the main photo', 'estat-os' ) . '">' . ( $is_main ? '★' : '☆' ) . '</button>';
				}
				$out .= '<button type="submit" name="estat_pocket_remove" value="' . (int) $id . '" class="estat-pk-photo-btn is-x" title="' . esc_attr__( 'Take this one out', 'estat-os' ) . '">×</button>';
				$out .= '</div>';
			}
			$out .= '</div>';
		}

		/*
		 * Shooting, the way it happens on a site visit.
		 *
		 * The camera opens, one shot is taken, and the phone is still in
		 * hand — so the button stays and says how many are already in the
		 * bag: "Take another · 3 ready". Nothing is sent until Save, and
		 * every shot taken so far is still there to look at.
		 */
		$out .= '<input class="estat-pocket-input estat-pk-file" type="file" name="' . esc_attr( $upload ) . '[]" accept="image/*" multiple capture="environment" data-preview="estat-pk-prev-' . esc_attr( sanitize_html_class( $name ) ) . '" hidden>';
		$out .= '<div class="estat-pk-shoot">';
		$out .= '<button type="button" class="estat-pk-shoot-btn">' . Pocket::icon( 'camera', 20 ) .
			'<span class="estat-pk-shoot-word">' . esc_html__( 'Open the camera', 'estat-os' ) . '</span></button>';
		$out .= '<span class="estat-pk-shoot-count" role="status" aria-live="polite"></span>';
		$out .= '</div>';
		$out .= '<p class="estat-pocket-hint">' . esc_html( (string) ( $field['hint'] ?? '' ) ) . '</p>';
		$out .= '<div class="estat-pk-previews" id="estat-pk-prev-' . esc_attr( sanitize_html_class( $name ) ) . '"></div>';
		$out .= '</div>';

		return $out;
	}

	/**
	 * How many photos are enough — said plainly, not as a rule.
	 *
	 * @param int $have Photos already on the record (plus any just picked).
	 * @return string
	 */
	public static function shots_line( int $have ): string {
		if ( $have >= 6 ) {
			return __( 'That is plenty. Add more only if they add something.', 'estat-os' );
		}
		if ( 0 === $have ) {
			return __( 'Six or more is what makes a listing look real. None yet.', 'estat-os' );
		}

		return sprintf(
			/* translators: %d: how many photos so far. */
			_n( 'One so far. Six or more is what makes a listing look real.', '%d so far. Six or more is what makes a listing look real.', $have, 'estat-os' ),
			$have
		);
	}

	/**
	 * A voice note recorded on the phone.
	 *
	 * Field capture is not only photographs: the reason a flat is worth
	 * seeing — “the light in the evening”, “the road is quiet” — is in the
	 * agent's head, and typing it slows them down. This records it and
	 * carries it with the record, so the office hears it in the agent's own
	 * words. Nothing is transcribed and nothing is sent anywhere: the file
	 * goes into the same media library as the photographs.
	 *
	 * @param array<string,mixed> $field     Field definition.
	 * @param int                 $record_id Record being edited.
	 * @return string
	 */
	private static function voice_card( array $field, int $record_id ): string {
		$name   = (string) $field['name'];
		$input  = (string) ( $field['upload'] ?? 'estat_pocket_voice' );
		$ids    = $record_id > 0 ? array_values( array_filter( array_map( 'intval', (array) get_post_meta( $record_id, $name, true ) ) ) ) : array();

		$out  = '<div class="estat-field-row estat-w-field" data-wfield="' . esc_attr( $name ) . '" data-voice="' . esc_attr( $input ) . '">';
		$out .= '<label class="estat-pocket-label">' . esc_html( (string) ( $field['label'] ?? Steps::label( $name ) ) ) . '</label>';

		if ( $ids ) {
			$out .= '<div class="estat-pk-voices">';
			foreach ( $ids as $id ) {
				$src = wp_get_attachment_url( $id );
				if ( ! $src ) {
					continue;
				}
				$out .= '<div class="estat-pk-voice is-saved">' . Pocket::icon( 'speaker-high', 18 ) .
					'<audio controls preload="metadata" src="' . esc_url( $src ) . '"></audio>' .
					'<span class="estat-pk-voice-when">' . esc_html( (string) get_the_date( 'j M Y', $id ) ) . '</span>' .
					'<button type="submit" name="estat_pocket_remove_voice" value="' . (int) $id . '" class="estat-pk-photo-btn is-x" title="' . esc_attr__( 'Take this one out', 'estat-os' ) . '">×</button></div>';
			}
			$out .= '</div>';
		}

		$out .= '<div class="estat-pk-rec" data-label-record="' . esc_attr__( 'Record', 'estat-os' ) . '" data-label-stop="' . esc_attr__( 'Stop', 'estat-os' ) . '" data-label-ask="' . esc_attr__( 'May the phone use the microphone?', 'estat-os' ) . '" data-label-no="' . esc_attr__( 'This phone will not let the page use the microphone. Type the note instead.', 'estat-os' ) . '">';
		$out .= '<button type="button" class="estat-pk-rec-btn">' . Pocket::icon( 'microphone', 22 ) . '<span class="estat-pk-rec-word">' . esc_html__( 'Record', 'estat-os' ) . '</span></button>';
		$out .= '<span class="estat-pk-rec-time" hidden>0:00</span>';
		$out .= '<span class="estat-pk-rec-state" role="status" aria-live="polite"></span>';
		$out .= '</div>';

		// The recording lands in this file box as a normal file, so one save
		// carries everything — photos, plan, voice — exactly like before.
		$out .= '<input class="estat-pk-voice-file" type="file" name="' . esc_attr( $input ) . '" accept="audio/*" hidden>';

		/*
		 * Speaking is easier than typing, but it is not always possible:
		 * some phones refuse the microphone, and some rooms are too loud to
		 * talk into. The note can be written instead, and the office reads
		 * it in the same place it hears the others.
		 */
		$said = (string) ( $record_id > 0 ? get_post_meta( $record_id, '_estat_voice_text', true ) : '' );
		$out .= '<details class="estat-pk-write"' . ( '' !== $said ? ' open' : '' ) . '>';
		$out .= '<summary>' . esc_html__( 'Write it instead', 'estat-os' ) . '</summary>';
		$out .= '<textarea class="estat-pocket-input" name="_estat_voice_text" rows="3" placeholder="' . esc_attr__( 'The lift does not stop on this floor.', 'estat-os' ) . '">' . esc_textarea( $said ) . '</textarea>';
		$out .= '</details>';

		$out .= '<p class="estat-pocket-hint">' . esc_html( (string) ( $field['hint'] ?? '' ) ) . '</p>';
		$out .= '</div>';

		return $out;
	}

	/**
	 * Every value the form starts with, keyed by field name.
	 *
	 * @param int $record_id Record being edited.
	 * @return array<string,string>
	 */
	private static function form_values( int $record_id ): array {
		$vals = array();
		foreach ( Steps::names( true ) as $name ) {
			$vals[ $name ] = '';
		}
		$vals['_estat_rent'] = '';
		if ( $record_id <= 0 ) {
			return $vals;
		}
		$post = get_post( $record_id );
		if ( ! $post ) {
			return $vals;
		}

		$vals['title']       = (string) $post->post_title;
		$vals['description'] = (string) $post->post_content;

		foreach ( $vals as $name => $blank ) {
			if ( in_array( $name, array( 'title', 'description', 'locality', 'amenities', 'features' ), true ) ) {
				continue;
			}
			$raw           = get_post_meta( $record_id, $name, true );
			$vals[ $name ] = is_array( $raw ) ? implode( ', ', $raw ) : (string) $raw;
		}

		foreach (
			array(
				'locality'  => \EstatOS\Data\Taxonomies::LOCALITY,
				'amenities' => \EstatOS\Data\Taxonomies::AMENITY,
				'features'  => \EstatOS\Data\Taxonomies::FEATURE,
			) as $name => $taxonomy
		) {
			$terms = wp_get_post_terms( $record_id, $taxonomy, array( 'fields' => 'names' ) );
			$vals[ $name ] = is_wp_error( $terms ) ? '' : implode( ', ', array_map( 'strval', $terms ) );
		}

		return $vals;
	}

	/**
	 * The wizard's own JavaScript: step labels, the nudge lines, and the
	 * review that is built from every step above it.
	 *
	 * Everything the script says comes from PHP as translated text — a
	 * JavaScript file cannot read the catalogue, so a word typed here would
	 * stay English on a Hinglish site.
	 *
	 * @param array<int,array<string,mixed>> $steps Steps, in order.
	 * @param string                         $symbol Currency symbol.
	 * @return string
	 */
	private static function wizard_script( array $steps, string $symbol ): string {
		$wiz = array(
			'step'     => __( 'Step %1$d of %2$d', 'estat-os' ),
			'titles'   => array(),
			'hints'    => array(),
			'groups'   => array(),
			'need'     => array(
				'title'                => __( 'Give it a short name first.', 'estat-os' ),
				'locality'             => __( 'Add the area or address first.', 'estat-os' ),
				'_estat_price'         => __( 'Add a price or a monthly rent — one of the two is enough.', 'estat-os' ),
				'_estat_property_type' => __( 'Say what kind of property it is.', 'estat-os' ),
				'_estat_offer'         => __( 'Say whether it is for sale, rent or lease.', 'estat-os' ),
			),
			'symbol'   => $symbol,
			'photos'   => __( 'photos added', 'estat-os' ),
			'noPhotos' => __( 'no photos yet', 'estat-os' ),
			'empty'    => __( 'not filled', 'estat-os' ),
			'check'    => __( 'Look it over', 'estat-os' ),
			'fix'      => __( 'Fix this', 'estat-os' ),
			'voice'    => __( 'voice note', 'estat-os' ),
			'wroteIt'  => __( 'written note', 'estat-os' ),
			'voices'   => __( 'voice notes', 'estat-os' ),
			'voiceReady' => __( 'Voice note ready — %s. Press Save and it goes with the property.', 'estat-os' ),
			'voiceAsk'   => __( 'May the phone use the microphone?', 'estat-os' ),
			'voiceNo'    => __( 'This phone will not let the page use the microphone. Type the note instead.', 'estat-os' ),
			'shotsNone'  => __( 'Six or more is what makes a listing look real. None yet.', 'estat-os' ),
			'shotsOne'   => __( 'One so far. Six or more is what makes a listing look real.', 'estat-os' ),
			'shotsSome'  => __( '%d so far. Six or more is what makes a listing look real.', 'estat-os' ),
			'shotsMany'  => __( 'That is plenty. Add more only if they add something.', 'estat-os' ),
			'shootOpen'  => __( 'Open the camera', 'estat-os' ),
			'shootMore'  => __( 'Take another', 'estat-os' ),
			'shootReady' => __( '%d ready', 'estat-os' ),
			'takeOut'    => __( 'Take this one out', 'estat-os' ),
			'draftBack'  => __( 'Picked up where you left off — this phone still had what you typed.', 'estat-os' ),
			'offline'    => __( 'No network. What you type is kept on this phone; photographs and voice notes will go up when the network is back.', 'estat-os' ),
			'online'     => __( 'Back online. Press Save when you are ready.', 'estat-os' ),
			'offlineSave' => __( 'No network. It is on this phone now, and it will go up by itself when the bars come back.', 'estat-os' ),

		);

		foreach ( $steps as $i => $step ) {
			$wiz['titles'][] = (string) $step['title'];
			$wiz['hints'][]  = (string) ( $step['hint'] ?? '' );
			$group = array();
			foreach ( (array) ( $step['fields'] ?? array() ) as $field ) {
				$group[] = array(
					'name'  => (string) $field['name'],
					'label' => (string) ( $field['label'] ?? Steps::label( (string) $field['name'] ) ),
					'input' => (string) ( $field['input'] ?? 'text' ),
					'only'  => (string) ( $field['only'] ?? '' ),
				);
			}
			$wiz['groups'][] = $group;
		}

		return '<script>
const estatWiz = ' . wp_json_encode( $wiz ) . ';
document.addEventListener("DOMContentLoaded", function(){
  const form = document.getElementById("estat-wizard-form");
  if(!form) return;
  const max = ' . count( $steps ) . ';
  let step = 1;
  const dots = form.querySelectorAll(".estat-w-dot");
  const label = document.getElementById("estat-w-label");
  const errEl = document.getElementById("estat-w-error");
  const back = document.getElementById("estat-w-back");
  const next = document.getElementById("estat-w-next");
  const save = document.getElementById("estat-w-save");
  const send = document.getElementById("estat-w-send");
  const review = document.getElementById("estat-w-review");
  // The last look is the step with no questions of its own. Everything
  // after it (the office-only step) still saves from the same buttons.
  const checkAt = Math.max(1, estatWiz.groups.findIndex(g => !g.length) + 1);
  const NOT_A_HOME = ["plot","commercial_shop","shop","office","warehouse","industrial","farm_land"];
  const LAND = ["plot","farm_land"];
  const SALES = ["sale"];

  function fieldEl(n){ return form.querySelector("[name=\\""+n+"\\"]"); }
  function valueOf(n){ const el = fieldEl(n); return el ? String(el.value || "") : ""; }
  function isVisible(el){
    if(!el) return false;
    const row = el.closest(".estat-w-field");
    return row ? row.style.display !== "none" : true;
  }

  // Same rules the office editor uses: a plot has no bedrooms, a sale has no
  // deposit, and both lists are the ones in admin.js.
  function paint(){
    const type = valueOf("_estat_property_type");
    const offer = valueOf("_estat_offer");
    form.querySelectorAll(".estat-only-home").forEach(el => { el.style.display = NOT_A_HOME.indexOf(type) === -1 ? "" : "none"; });
    form.querySelectorAll(".estat-only-built").forEach(el => { el.style.display = LAND.indexOf(type) === -1 ? "" : "none"; });
    form.querySelectorAll(".estat-only-rent").forEach(el => { el.style.display = SALES.indexOf(offer) === -1 ? "" : "none"; });
    const moneyRow = form.querySelector(".estat-money-row .estat-money-texts");
    const moneyLabel = form.querySelector(".estat-money-row .estat-pocket-label");
    if(moneyRow && moneyLabel){
      const isRent = ["rent","lease"].indexOf(offer) !== -1;
      moneyLabel.textContent = isRent ? moneyRow.getAttribute("data-rent-label") : moneyRow.getAttribute("data-sale-label");
      const box = form.querySelector("[name=_estat_price]");
      if(box && !box.value){ box.setAttribute("placeholder", isRent ? "32000" : "8500000"); }
    }
    // The offer question decides what the rest of the form asks, so the
    // money box and the tag step follow it without a round trip.
    const priceType = form.querySelector(".estat-only-rent [name=_estat_price_type]");
    if(priceType && !priceType.value){ priceType.value = "monthly"; }
  }

  function missingIn(stepNo){
    const group = estatWiz.groups[stepNo-1] || [];
    for(let i=0;i<group.length;i++){
      const f = group[i];
      if(!f.name) continue;
      if(f.input === "photos") continue;
      const el = fieldEl(f.name);
      if(!el || !isVisible(el)) continue;
      // Kaun sa jawab zaroori hai, yeh dabba khud batata hai (required), aur
      // rent wale dabbe ka jodha ek hi sawaal ka doosra naam hai.
      const required = el.hasAttribute("required") || f.name === "_estat_price";
      if(!required) continue;
      if(f.name === "_estat_price"){
        // A rent figure may already be sitting in the old rent box.
        const p = valueOf("_estat_price"), r = valueOf("_estat_rent");
        if(p.trim() || r.trim()) continue;
      } else if(String(el.value||"").trim()){
        continue;
      }
      return { name: f.name, message: estatWiz.need[f.name] || estatWiz.fix };
    }
    return null;
  }

  function photoCount(){
    let n = 0;
    form.querySelectorAll(".estat-pk-photos .estat-pk-photo").forEach(()=>{ n++; });
    form.querySelectorAll(".estat-pk-file").forEach(input => { if(input.files){ n += input.files.length; } });
    return n;
  }

  function buildReview(){
    if(!review) return;
    let html = "";
    for(let s=0;s<max;s++){
      const group = estatWiz.groups[s] || [];
      if(!group.length){ continue; }
      let rows = "";
      group.forEach(f => {
        if(!f.name) return;
        if(f.input === "voice"){
          const el = fieldEl(f.name);
          const wrap = el ? el.closest(".estat-w-field") : null;
          const have = wrap ? wrap.querySelectorAll(".estat-pk-voice").length : 0;
          const wrote = valueOf("_estat_voice_text").trim();
          const bits = [];
          if(have){ bits.push(have+" "+(have === 1 ? estatWiz.voice : estatWiz.voices)); }
          if(wrote){ bits.push(estatWiz.wroteIt); }
          if(bits.length){ rows += "<div><b>"+f.label+":</b> "+bits.join(" · ")+"</div>"; }
          return;
        }
        if(f.input === "photos"){
          const el = fieldEl(f.name);
          const wrap = el ? el.closest(".estat-w-field") : null;
          const have = wrap ? wrap.querySelectorAll(".estat-pk-photo").length : 0;
          const adding = (el && el.files) ? el.files.length : 0;
          const total = have + adding;
          rows += "<div><b>"+f.label+":</b> "+(total ? total+" "+estatWiz.photos : estatWiz.noPhotos)+"</div>";
          return;
        }
        const el = fieldEl(f.name);
        if(!el || !isVisible(el)) return;
        let v = String(el.value||"").trim();
        if(f.input === "checkbox"){ v = el.checked ? "✓" : ""; }
        if(f.input === "select"){ v = el.options && el.selectedIndex >= 0 ? el.options[el.selectedIndex].text : v; }
        if(!v) return;
        rows += "<div><b>"+f.label+":</b> "+v.replace(/</g,"&lt;")+"</div>";
      });
      if(rows){
        html += "<div class=\\"estat-w-review-group\\"><h4>"+(s+1)+" / "+max+" — "+estatWiz.titles[s]+"</h4>"+rows+"</div>";
      }
    }
    review.innerHTML = html || "<p>"+estatWiz.empty+"</p>";
  }

  function show(s){
    const bad = s > step ? missingIn(step) : null;
    if(bad){
      if(errEl){ errEl.textContent = bad.message; errEl.style.display = "inline-flex"; setTimeout(()=>{errEl.style.display="none";}, 4000); }
      const el = fieldEl(bad.name);
      const row = el ? el.closest(".estat-w-field") : null;
      if(row){ row.classList.add("is-missing"); if(row.animate){ row.animate([{transform:"translateX(-4px)"},{transform:"translateX(4px)"},{transform:"translateX(0)"}], {duration:200}); } if(el.focus){ el.focus(); } }
      return;
    }
    step = s;
    form.querySelectorAll(".estat-w-step").forEach(d => { d.style.display = parseInt(d.getAttribute("data-wstep"),10) === step ? "block" : "none"; });
    dots.forEach(d => {
      const ds = parseInt(d.getAttribute("data-step"),10);
      d.classList.toggle("is-done", ds < step);
      d.classList.toggle("is-current", ds === step);
      d.disabled = ds > step + 1;
    });
    if(label){ label.textContent = estatWiz.step.replace("%1$d", step).replace("%2$d", max) + " — " + estatWiz.titles[step-1]; }
    if(back) back.style.display = step > 1 ? "inline-flex" : "none";
    if(next) next.style.display = step < max ? "inline-flex" : "none";
    // Saving becomes possible once somebody has seen the whole thing.
    if(save) save.style.display = step >= checkAt ? "inline-flex" : "none";
    if(send) send.style.display = step >= checkAt ? "inline-flex" : "none";
    if(step >= checkAt){ buildReview(); }
    remember();
    window.scrollTo({top:0, behavior:"smooth"});
  }

  // ---------------------------------------------------------------
  // Nothing typed in a flat should be lost to a dead battery.
  //
  // The draft is kept on the phone itself as it is typed — not only when
  // somebody moves a step — and a note says so when it is used again.
  // Photographs and voice notes cannot be kept this way: they go up with
  // the Save, and until then the phone is holding them.
  // ---------------------------------------------------------------
  const DRAFT_KEY = "estat_pocket_draft_" + (valueOf("record_id") || "new");
  let rememberTimer = null;

  function remember(){
    clearTimeout(rememberTimer);
    rememberTimer = setTimeout(function(){
      try{
        const data = {};
        form.querySelectorAll("input, select, textarea").forEach(el => { if(el.name && el.type !== "file") data[el.name] = el.value; });
        localStorage.setItem(DRAFT_KEY, JSON.stringify(data));
      }catch(e){}
    }, 400);
  }

  form.addEventListener("input", remember);
  form.addEventListener("change", remember);

  // ---------------------------------------------------------------
  // A voice note: spoken, not typed.
  //
  // Whoever is standing in the flat talks faster than they type, so the
  // phone records and the file rides along with the same Save as the
  // photographs. Nothing is transcribed and nothing leaves the site.
  // ---------------------------------------------------------------
  form.querySelectorAll(".estat-pk-rec").forEach(function(card){
    const box = card.closest(".estat-w-field");
    const files = box ? box.querySelector(".estat-pk-voice-file") : null;
    const btn = card.querySelector(".estat-pk-rec-btn");
    const word = card.querySelector(".estat-pk-rec-word");
    const time = card.querySelector(".estat-pk-rec-time");
    const state = card.querySelector(".estat-pk-rec-state");
    if(!btn || !files){ return; }
    let rec = null, chunks = [], began = 0, ticker = null, stream = null;
    const MOST = 90000; // Ninety seconds is a note, not a podcast.

    function say(text){ if(state){ state.textContent = text || ""; } }
    function mmss(ms){
      const s = Math.max(0, Math.floor(ms / 1000));
      return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
    }
    function stopClock(){ if(ticker){ clearInterval(ticker); ticker = null; } }
    function release(){
      if(stream){ stream.getTracks().forEach(t => t.stop()); stream = null; }
    }
    function reset(){
      stopClock();
      release();
      btn.classList.remove("is-recording");
      if(word){ word.textContent = card.getAttribute("data-label-record"); }
      if(time){ time.hidden = true; }
    }

    /*
     * Which sound file the phone writes.
     *
     * WordPress knows ogg and m4a as sound; the webm box it treats as film,
     * so a voice recorded into it gets refused at the door. Chrome and
     * Firefox can write ogg, iPhones write m4a, and webm stays the last
     * resort for a browser that offers nothing else.
     */
    function pickMime(){
      const wants = ["audio/ogg;codecs=opus", "audio/mp4", "audio/ogg", "audio/webm;codecs=opus"];
      if(typeof MediaRecorder === "undefined" || !MediaRecorder.isTypeSupported){ return ""; }
      for(let i=0;i<wants.length;i++){ if(MediaRecorder.isTypeSupported(wants[i])){ return wants[i]; } }
      return "";
    }

    function kindOf(type){
      const t = String(type || "");
      if(t.indexOf("ogg") !== -1){ return "ogg"; }
      if(t.indexOf("mp4") !== -1){ return "m4a"; }
      return "webm";
    }

    function keep(blob){
      const kind = kindOf(blob.type);
      const said = Math.max(1, Math.round((Date.now() - began) / 1000));
      try{
        const carrier = new DataTransfer();
        carrier.items.add(new File([blob], "voice-note." + kind, { type: blob.type || "audio/webm" }));
        files.files = carrier.files;
      }catch(e){
        say(estatWiz.voiceNo);
        return;
      }

      let box2 = box.querySelector(".estat-pk-voices");
      if(!box2){
        box2 = document.createElement("div");
        box2.className = "estat-pk-voices";
        box.insertBefore(box2, card);
      }
      box2.querySelectorAll(".is-fresh").forEach(el => el.remove());
      const row = document.createElement("div");
      row.className = "estat-pk-voice is-fresh";
      const audio = document.createElement("audio");
      audio.controls = true;
      audio.preload = "metadata";
      audio.src = URL.createObjectURL(blob);
      const tag = document.createElement("span");
      tag.className = "estat-pk-voice-when";
      tag.textContent = mmss(said * 1000);
      const cut = document.createElement("button");
      cut.type = "button";
      cut.className = "estat-pk-photo-btn is-x";
      cut.textContent = "×";
      cut.addEventListener("click", function(){
        files.value = "";
        row.remove();
        say("");
      });
      row.appendChild(audio);
      row.appendChild(tag);
      row.appendChild(cut);
      box2.appendChild(row);
      say(estatWiz.voiceReady.replace("%s", mmss(said * 1000)));
    }

    function finish(){
      if(rec && rec.state !== "inactive"){ rec.stop(); return; }
      reset();
    }

    btn.addEventListener("click", function(){
      if(rec && rec.state === "recording"){ rec.stop(); return; }

      if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || typeof MediaRecorder === "undefined"){
        say(estatWiz.voiceNo);
        return;
      }

      navigator.mediaDevices.getUserMedia({ audio: true }).then(function(got){
        stream = got;
        chunks = [];
        const wanted = pickMime();
        try{
          rec = wanted ? new MediaRecorder(stream, { mimeType: wanted }) : new MediaRecorder(stream);
        }catch(e){
          say(estatWiz.voiceNo);
          release();
          return;
        }
        rec.addEventListener("dataavailable", function(ev){ if(ev.data && ev.data.size){ chunks.push(ev.data); } });
        rec.addEventListener("stop", function(){
          const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
          reset();
          if(blob.size){ keep(blob); }
        });
        began = Date.now();
        btn.classList.add("is-recording");
        if(word){ word.textContent = card.getAttribute("data-label-stop"); }
        if(time){ time.hidden = false; time.textContent = "0:00"; }
        say("");
        ticker = setInterval(function(){
          const ms = Date.now() - began;
          if(time){ time.textContent = mmss(ms); }
          if(ms >= MOST){ finish(); }
        }, 250);
        rec.start();
      }).catch(function(){
        say(card.getAttribute("data-label-ask") ? estatWiz.voiceNo : estatWiz.voiceNo);
        reset();
      });
    });
  });

  // How many photographs are enough — the line answers itself as the roll
  // grows, so nobody has to count on their fingers.
  function refreshShots(){
    form.querySelectorAll(".estat-pk-shots").forEach(function(box){
      const field = box.closest(".estat-w-field");
      if(!field){ return; }
      let have = field.querySelectorAll(".estat-pk-photo").length;
      field.querySelectorAll(".estat-pk-file").forEach(input => { if(input.files){ have += input.files.length; } });
      const line = box.querySelector(".estat-pk-shots-count");
      if(!line){ return; }
      if(have >= 6){ line.textContent = estatWiz.shotsMany; }
      else if(have === 0){ line.textContent = estatWiz.shotsNone; }
      else if(have === 1){ line.textContent = estatWiz.shotsOne; }
      else { line.textContent = estatWiz.shotsSome.replace("%d", have); }
    });
  }

  // ---------------------------------------------------------------
  // The camera, one shot at a time.
  //
  // A visit is a walk around a flat: open the camera, take the hall,
  // take the kitchen, take the balcony. Every shot is added to the same
  // bag, counted out loud, and can be taken back out with an × before
  // saving. The bag is what goes up on Save — there is no second copy
  // anywhere, and nothing is sent until the button is pressed.
  // ---------------------------------------------------------------
  form.querySelectorAll(".estat-pk-file").forEach(input => {
    const target = document.getElementById(input.getAttribute("data-preview"));
    const box = input.closest(".estat-w-field");
    const shoot = box ? box.querySelector(".estat-pk-shoot") : null;
    const btn = shoot ? shoot.querySelector(".estat-pk-shoot-btn") : null;
    const word = shoot ? shoot.querySelector(".estat-pk-shoot-word") : null;
    const counted = shoot ? shoot.querySelector(".estat-pk-shoot-count") : null;
    const shots = box ? box.querySelector(".estat-pk-shots") : null;

    // What is in the bag right now, as files the form will send.
    let bag = [];

    function paint(){
      if(target){
        target.innerHTML = "";
        bag.forEach(function(file, index){
          const wrap = document.createElement("span");
          wrap.className = "estat-pk-shot";
          const img = document.createElement("img");
          img.src = URL.createObjectURL(file);
          img.className = "estat-pocket-photo";
          const cut = document.createElement("button");
          cut.type = "button";
          cut.className = "estat-pk-photo-btn is-x";
          cut.textContent = "×";
          cut.setAttribute("aria-label", estatWiz.takeOut);
          cut.addEventListener("click", function(){
            bag = bag.filter(function(f){ return f !== file; });
            hand();
          });
          wrap.appendChild(img);
          wrap.appendChild(cut);
          target.appendChild(wrap);
        });
      }
      if(counted){
        counted.textContent = bag.length ? estatWiz.shootReady.replace("%d", bag.length) : "";
      }
      if(word){
        word.textContent = bag.length ? estatWiz.shootMore : estatWiz.shootOpen;
      }
      // The list at the top ticks itself off, one line per shot taken —
      // a nudge, not a rule.
      if(shots){
        shots.querySelectorAll("li").forEach(function(li, i){
          li.classList.toggle("is-done", i < bag.length);
        });
      }
      refreshShots();
    }

    // Hand the whole bag back to the file box of the form itself.
    function hand(){
      try{
        const carrier = new DataTransfer();
        bag.forEach(function(file){ carrier.items.add(file); });
        input.files = carrier.files;
      }catch(e){}
      paint();
    }

    if(btn && input){
      btn.addEventListener("click", function(){ input.click(); });
    }

    input.addEventListener("change", function(){
      const picked = Array.prototype.slice.call(this.files || []);
      picked.forEach(function(file){
        // The same shot, picked twice (going back into the camera roll),
        // must not land twice.
        const already = bag.some(function(f){
          return f.name === file.name && f.size === file.size && f.lastModified === file.lastModified;
        });
        if(!already){ bag.push(file); }
      });
      hand();
    });

    if(bag.length === 0){
      // Look over what the record already carries, so the count starts true.
      const saved = box ? box.querySelectorAll(".estat-pk-photos .estat-pk-photo").length : 0;
      if(saved > 0 && shots){
        shots.querySelectorAll("li").forEach(function(li, i){ li.classList.toggle("is-done", i < saved); });
      }
    }
    paint();
  });

  ["_estat_offer","_estat_property_type"].forEach(n => {
    const el = fieldEl(n);
    if(el){ el.addEventListener("change", paint); }
  });

  dots.forEach(d => {
    d.addEventListener("click", function(){
      const target = parseInt(this.getAttribute("data-step"),10);
      if(target <= step + 1){ show(target); }
    });
  });
  if(next) next.addEventListener("click", function(){ if(step < max){ show(step + 1); } });
  if(back) back.addEventListener("click", function(){ if(step > 1){ show(step - 1); } });

  try{
    const saved = localStorage.getItem(DRAFT_KEY);
    if(saved){
      const data = JSON.parse(saved);
      let brought = 0;
      Object.keys(data).forEach(k => {
        const el = form.querySelector("[name=\\""+k+"\\"]");
        if(el && el.type !== "file" && el.type !== "checkbox" && el.value !== data[k] && (!el.value || el.value === "")){
          if(data[k] !== ""){ brought++; }
          el.value = data[k];
        }
      });
      if(brought > 0){
        const note = document.createElement("p");
        note.className = "estat-pocket-draft-note";
        note.textContent = estatWiz.draftBack;
        const head = form.querySelector(".estat-w-steps") || form.firstElementChild;
        if(head && head.parentNode){ head.parentNode.insertBefore(note, head.nextSibling); }
        else { form.insertBefore(note, form.firstElementChild); }
      }
    }
  }catch(e){}

  // ---------------------------------------------------------------
  // Saving without a network.
  //
  // A cellar, a lift, the back of a parking lot: the form is filled and
  // there is nothing to send it on. Pressing Save then keeps the whole
  // thing — every answer, every photograph, the voice note — on the phone
  // itself, and the phone sends it up by itself the moment the network
  // returns. It goes through the very same door as a normal save, so
  // there is no second way of storing a property.
  // ---------------------------------------------------------------
  const CID_KEY = "estat_pocket_cid_" + (valueOf("record_id") || "new");

  // One steady name for this piece of work, kept across reloads.
  try{
    let cid = localStorage.getItem(CID_KEY);
    const box = form.querySelector("[name=estat_client_id]");
    if(!cid){
      cid = (window.crypto && crypto.randomUUID) ? crypto.randomUUID().replace(/-/g, "").slice(0, 32) : String(Date.now()) + Math.random().toString(36).slice(2, 10);
      localStorage.setItem(CID_KEY, cid);
    }
    if(box){ box.value = cid; }
  }catch(e){}

  form.addEventListener("submit", function(ev){
    if(navigator.onLine){ return; }
    ev.preventDefault();
    if(errEl){ errEl.textContent = estatWiz.offlineSave; errEl.style.display = "inline-flex"; }
    if(window.estatQueueKeep){ window.estatQueueKeep(form, DRAFT_KEY); }
  });

  paint();
  refreshShots();
  show(1);
});


</script>';
	}

	/**
	 * One labelled input.
	 *
	 * @param string $label  Text.
	 * @param string $name   Field name.
	 * @param string $type   Input type.
	 * @param string $value  Current value.
	 * @param string $ph     Placeholder.
	 * @param bool   $req    Required.
	 * @return string
	 */
	private static function field( string $label, string $name, string $type, string $value, string $ph = '', bool $req = false ): string {
		return sprintf(
			'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label>' .
			'<input class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" type="%3$s" value="%4$s" placeholder="%5$s"%6$s>',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( $type ),
			esc_attr( $value ),
			esc_attr( $ph ),
			$req ? ' required' : ''
		);
	}

	/**
	 * One labelled select.
	 *
	 * @param string $label     Text.
	 * @param string $name      Field name.
	 * @param array<string,string> $options Choices.
	 * @param string $current   Selected key.
	 * @param string $blank     Placeholder option label.
	 * @return string
	 */
	private static function select_field( string $label, string $name, array $options, string $current, string $blank = '', bool $required = false ): string {
		$out = '<label class="estat-pocket-label" for="estat-pf-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label>';
		$out .= '<select class="estat-pocket-input" id="estat-pf-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '"' . ( $required ? ' required' : '' ) . '>';
		if ( '' !== $blank ) {
			$out .= '<option value="">' . esc_html( $blank ) . '</option>';
		}
		foreach ( $options as $key => $word ) {
			$out .= '<option value="' . esc_attr( $key ) . '"' . ( (string) $key === $current ? ' selected' : '' ) . '>' . esc_html( $word ) . '</option>';
		}
		return $out . '</select>';
	}

	/**
	 * A multiline box.
	 *
	 * @param string $label Text.
	 * @param string $name  Field name.
	 * @param string $value Content.
	 * @param string $ph    Placeholder.
	 * @return string
	 */
	private static function area_field( string $label, string $name, string $value, string $ph = '' ): string {
		return sprintf(
			'<label class="estat-pocket-label" for="estat-pf-%1$s">%2$s</label>' .
			'<textarea class="estat-pocket-input" id="estat-pf-%1$s" name="%1$s" rows="3" placeholder="%3$s">%4$s</textarea>',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( $ph ),
			esc_textarea( $value )
		);
	}

	/* ---------------------------------------------------------------------
	 * The change sheet
	 * ------------------------------------------------------------------ */

	/**
	 * The four fields a person on the ground can confirm, plus the compulsory
	 * "how do you know". Same request shape the admin queue reviews.
	 *
	 * @param int $record_id Post ID.
	 * @return string|false
	 */
	private static function change( int $record_id ) {
		// No property chosen yet — pick one. Every change is asked for from
		// inside a record, so this is a doorway, not a second form.
		if ( $record_id <= 0 ) {
			$out  = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'more' ) ) . '">' . Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';
			$out .= '<p class="estat-pocket-lead">' . esc_html__( 'Which property is this about?', 'estat-os' ) . '</p>';

			$mine = Pocket::my_records( '', PostTypes::LISTING );
			if ( ! $mine ) {
				return $out . self::empty_state(
					__( 'No property to change', 'estat-os' ),
					__( 'Changes are asked for on a property already in the office records. Add the property first.', 'estat-os' ),
					Pocket::url( 'new' ),
					__( 'Add a property', 'estat-os' )
				);
			}

			$out .= '<div class="estat-pocket-sheet">';
			foreach ( $mine as $post ) {
				$out .= '<a class="estat-pocket-sheet-row" href="' . esc_url( Pocket::url( 'change', (int) $post->ID ) ) . '">' .
					'<span class="estat-pocket-well">' . Pocket::icon( 'pencil', 18 ) . '</span>' .
					'<span class="estat-pocket-rowmain"><b>' . esc_html( (string) $post->post_title ) . '</b><i>' . esc_html( Pocket::status_of( $post )[0] ) . '</i></span>' .
					Pocket::icon( 'chevron-right', 16 ) . '</a>';
			}
			$out .= '</div>';

			return $out;
		}

		$post = get_post( $record_id );
		if ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) || ! Pocket::can_see( $post ) ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$cur = Requests::current_values( $record_id );

		$out  = '<h1 class="estat-pocket-title">' . esc_html( get_the_title( $record_id ) ) . '</h1>';
		$out .= '<div class="estat-pocket-banner">' . Pocket::icon( 'lock', 14 ) .
			'<div>' . esc_html__( 'This listing belongs to the office records. Your edit goes to them first, and the website only moves when they say yes.', 'estat-os' ) . '</div></div>';

		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'change', $record_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="request">';
		$out .= '<input type="hidden" name="record_id" value="' . (int) $record_id . '">';

		$cur_price = isset( $cur['price'] ) ? (string) $cur['price'] : '';
		$cur_rent  = isset( $cur['rent'] ) ? (string) $cur['rent'] : '';
		$out .= self::field(
			__( 'Price — today ', 'estat-os' ) . ( '' !== $cur_price ? Format::money( (float) $cur_price ) : __( 'not set', 'estat-os' ) ),
			'changes[price]',
			'text',
			'',
			'' !== $cur_price ? $cur_price : __( 'new number', 'estat-os' )
		);
		$out .= self::field(
			__( 'Monthly rent — today ', 'estat-os' ) . ( '' !== $cur_rent ? Format::money( (float) $cur_rent ) : __( 'not set', 'estat-os' ) ),
			'changes[rent]',
			'text',
			'',
			'' !== $cur_rent ? $cur_rent : __( 'new number', 'estat-os' )
		);
		$out .= self::select_field(
			__( 'Is it still available?', 'estat-os' ),
			'changes[availability]',
			Vocabulary::availability(),
			isset( $cur['availability'] ) ? (string) $cur['availability'] : '',
			__( 'Leave as it is', 'estat-os' )
		);
		$out .= self::area_field(
			__( 'New description', 'estat-os' ),
			'changes[description]',
			'',
			__( 'Only if the words on the site are wrong.', 'estat-os' )
		);
		$out .= self::area_field(
			__( 'How do you know? (one line)', 'estat-os' ),
			'message',
			'',
			__( 'Owner agreed on call today.', 'estat-os' )
		);
		$out .= '<p class="estat-pocket-hint">' . esc_html__( 'The one line is not optional — it is what the office decides with.', 'estat-os' ) . '</p>';

		$out .= '<div class="estat-pocket-actions">' .
			'<a class="estat-pocket-btn" href="' . esc_url( Pocket::url( 'listing', $record_id ) ) . '">' . esc_html__( 'Cancel', 'estat-os' ) . '</a>' .
			'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Send to office', 'estat-os' ) . '</button></div>';
		$out .= '</form>';

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Inbox
	 * ------------------------------------------------------------------ */

	/**
	 * One enquiry: how to reach them, what was asked, and the small actions.
	 *
	 * @param int $lead_id Lead row ID.
	 * @return string|false
	 */
	private static function enquiry( int $lead_id ) {
		// .ics download?
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['estat_ics'] ) ) {
			$vid = absint( wp_unslash( (string) ( is_array($_GET['estat_ics']) ? '' : $_GET['estat_ics'] ) ) );
			if ( $vid > 0 ) {
				$visit = \EstatOS\Leads\Visits::get( $vid );
				if ( $visit && (int) $visit['lead_id'] === $lead_id ) {
					$lead = Leads::get( $lead_id );
					if ( $lead ) {
						$off   = Pocket::is_office();
						$agent = Pocket::agent_id();
						$mine  = $off || (int) $lead['agent_id'] === $agent || ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
						if ( $mine ) {
							$dt = (string) $visit['scheduled_at'];
							$ts = strtotime( $dt );
							if ( $ts ) {
								$start = gmdate( 'Ymd\THis\Z', $ts );
								$end   = gmdate( 'Ymd\THis\Z', $ts + 3600 );
								$summary = 'Visit: ' . (string) $lead['name'];
								$desc = 'Lead #' . $lead_id . ' ' . (string) $lead['phone'];
								header( 'Content-Type: text/calendar; charset=utf-8' );
								header( 'Content-Disposition: attachment; filename=visit-' . $vid . '.ics' );
								echo "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//EstatOS//Visit//EN\r\n";
								echo "BEGIN:VEVENT\r\nUID:visit-{$vid}@estatos\r\nDTSTAMP:" . gmdate('Ymd\THis\Z') . "\r\n";
								echo "DTSTART:{$start}\r\nDTEND:{$end}\r\nSUMMARY:" . str_replace(array("\r","\n"), " ", $summary) . "\r\nDESCRIPTION:" . str_replace(array("\r","\n"), " ", $desc) . "\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n";
								exit;
							}
						}
					}
				}
			}
		}

		$lead = Leads::get( $lead_id );
		if ( ! $lead ) {
			return Pocket::fail_to_today( 'gone' );
		}

		$off   = Pocket::is_office();
		$agent = Pocket::agent_id();
		$mine  = $off || (int) $lead['agent_id'] === $agent || ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent ) || ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
		if ( ! $mine ) {
			return Pocket::fail_to_today( 'nope' );
		}

		$out = '<h1 class="estat-pocket-title">' . esc_html( (string) $lead['name'] ) . '</h1>';
		$out .= '<p class="estat-pocket-sub">' .
			esc_html( sprintf( __( 'Enquiry #%d', 'estat-os' ), (int) $lead['id'] ) ) . ' · ' .
			esc_html( Format::date( (string) $lead['created_at'] ) ) . ' ' . esc_html( Format::time( (string) $lead['created_at'] ) ) .
			'</p>';

		if ( ! empty( $lead['message'] ) ) {
			$out .= '<div class="estat-pocket-card"><div class="estat-pocket-quote">' . esc_html( (string) $lead['message'] ) . '</div></div>';
		}

		// Meta strip
		$meta_bits = array();
		if ( ! empty( $lead['intent'] ) ) { $meta_bits[] = esc_html( Vocabulary::label( 'lead_intents', (string) $lead['intent'] ) ); }
		if ( ! empty( $lead['locality'] ) ) { $meta_bits[] = esc_html( (string) $lead['locality'] ); }
		if ( ! empty( $lead['budget_min'] ) || ! empty( $lead['budget_max'] ) ) {
			$meta_bits[] = Format::money( (int) ( $lead['budget_min'] ?? 0 ) ) . ' - ' . Format::money( (int) ( $lead['budget_max'] ?? 0 ) );
		}
		if ( ! empty( $lead['source'] ) ) { $meta_bits[] = esc_html( Vocabulary::label( 'lead_sources', (string) $lead['source'] ) ); }
		if ( ! empty( $lead['lost_reason'] ) ) { $meta_bits[] = esc_html__( 'Set aside:', 'estat-os' ) . ' ' . esc_html( (string) $lead['lost_reason'] ); }
		if ( ! empty( $lead['is_spam'] ) ) { $meta_bits[] = '🚩spam'; }
		if ( $meta_bits ) {
			$out .= '<p class="estat-pocket-hint">' . implode( ' · ', $meta_bits ) . '</p>';
		}

		$phone   = preg_replace( '/[^0-9+]/', '', (string) $lead['phone'] );
		$wa_raw  = preg_replace( '/\D/', '', (string) $lead['phone'] );
		$wa      = '';
		if ( '' !== $wa_raw ) {
			$wa = '0' === substr( $wa_raw, 0, 1 ) ? substr( $wa_raw, 1 ) : $wa_raw;
			if ( 10 === strlen( $wa ) ) {
				$wa = '91' . $wa;
			}
			if ( strlen( $wa ) < 10 ) {
				$wa = '';
			}
		}

		$out .= '<div class="estat-pocket-actions">';
		if ( '' !== $phone ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'tel:' . $phone ) . '">' . Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call', 'estat-os' ) . '</a>';
		}
		if ( '' !== $wa ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'https://wa.me/' . $wa ) . '">' . Pocket::icon( 'whatsapp', 14 ) . ' WhatsApp</a>';
		}
		if ( ! empty( $lead['email'] ) ) {
			$out .= '<a class="estat-pocket-btn" href="' . esc_attr( 'mailto:' . sanitize_email( (string) $lead['email'] ) ) . '">' . esc_html__( 'Email', 'estat-os' ) . '</a>';
		}
		$out .= '</div>';

		if ( ! empty( $lead['listing_id'] ) ) {
			$out .= self::record_row( (int) $lead['listing_id'] );
		}

		// Log a visit.
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'enquiry', $lead_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="log_visit">';
		$out .= '<input type="hidden" name="lead_id" value="' . (int) $lead_id . '">';
		$out .= '<label class="estat-pocket-label">' . esc_html__( 'Booked a visit? Write when.', 'estat-os' ) . '</label>';
		$out .= '<input class="estat-pocket-input" type="datetime-local" name="scheduled_at" required>';
		$out .= '<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Log a visit', 'estat-os' ) . '</button>';
		$out .= '</form>';

		// Status + note + followup + lost_reason — one form.
		$st = self::lead_steps_from( (string) $lead['status'] );
		$lost_reasons = Vocabulary::lead_lost_reasons();
		$intents = Vocabulary::lead_intents();
		$out .= '<form class="estat-pocket-card" method="post" action="' . esc_url( Pocket::url( 'enquiry', $lead_id ) ) . '">';
		$out .= '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">';
		$out .= '<input type="hidden" name="estat_pocket_action" value="lead_update">';
		$out .= '<input type="hidden" name="lead_id" value="' . (int) $lead_id . '">';
		$out .= self::select_field( __( 'Status', 'estat-os' ), 'status', $st, (string) $lead['status'] );
		$out .= self::select_field( __( 'Intent', 'estat-os' ), 'intent', $intents, (string) ( $lead['intent'] ?? '' ), __( 'Keep intent', 'estat-os' ) );
		$out .= self::select_field( __( 'Lost reason (if lost)', 'estat-os' ), 'lost_reason', $lost_reasons, (string) ( $lead['lost_reason'] ?? '' ), __( 'Not lost', 'estat-os' ) );
		$out .= self::field( __( 'Next follow-up', 'estat-os' ), 'followup_at', 'datetime-local', ! empty( $lead['followup_at'] ) ? substr( (string) $lead['followup_at'], 0, 16 ) : '', '', false );
		$out .= self::area_field( __( 'Your note', 'estat-os' ), 'notes', (string) $lead['notes'], __( 'Called back. Wants the 2BHK on the 8th.', 'estat-os' ) );
		$out .= '<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		$out .= '</form>';

		// Timeline
		$events = \EstatOS\Leads\LeadEvents::for_lead( $lead_id );
		if ( $events ) {
			$out .= '<h2 class="estat-pocket-h2">' . esc_html__( 'Timeline', 'estat-os' ) . '</h2>';
			foreach ( array_slice( $events, 0, 20 ) as $ev ) {
				$out .= '<div class="estat-pocket-row is-flat"><span class="estat-pocket-well">' . Pocket::icon( 'clock', 14 ) . '</span><span class="estat-pocket-rowmain"><b>' . esc_html( (string) $ev['event'] ) . '</b><i>' . esc_html( Format::date( (string) $ev['created_at'] ) . ' ' . Format::time( (string) $ev['created_at'] ) ) . '</i></span></div>';
			}
		}

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Approvals (office only)
	 * ------------------------------------------------------------------ */

	/**
	 * The queue from the phone: change requests and newly proposed listings,
	 * settled through the same paths wp-admin uses.
	 *
	 * @return string
	 */


	/* ---------------------------------------------------------------------
	 * Approvals (office only)
	 * ------------------------------------------------------------------ */

	/**
	 * The queue from the phone: change requests and newly proposed listings,
	 * settled through the same paths wp-admin uses.
	 *
	 * @return string
	 */
	private static function approvals(): string {
		$out = '<h2 class="estat-pocket-h2">' . esc_html__( 'Change requests', 'estat-os' ) . '</h2>';

		$pending = Requests::query( array( 'status' => 'pending', 'per_page' => 30 ) );
		if ( ! $pending['items'] ) {
			$out .= '<p class="estat-pocket-hint">' . esc_html__( 'No change is waiting. The office queue is empty.', 'estat-os' ) . '</p>';
		}

		foreach ( $pending['items'] as $req ) {
			$record = get_post( (int) $req['record_id'] );
			$who    = get_userdata( (int) $req['requested_by'] );
			$out   .= '<div class="estat-pocket-card">';
			$out   .= '<div class="estat-pocket-kv"><i>' . esc_html__( 'From', 'estat-os' ) . '</i><b>' .
				esc_html( $who ? $who->display_name : __( 'someone who left', 'estat-os' ) ) . ' · ' .
				esc_html( Format::date( (string) $req['created_at'] ) ) . '</b></div>';
			$out   .= '<div class="estat-pocket-kv"><i>' . esc_html__( 'Property', 'estat-os' ) . '</i><b>' .
				esc_html( $record ? get_the_title( $record ) : '#' . (int) $req['record_id'] ) . '</b></div>';
			$changes = json_decode( (string) $req['changes'], true );
			$defs    = Requests::editable_fields();
			if ( is_array( $changes ) ) {
				foreach ( $changes as $key => $value ) {
					if ( 'note' === $key ) {
						continue;
					}
					$word  = $defs[ $key ]['label'] ?? ucfirst( (string) $key );
					$now   = Requests::current_value( (int) $req['record_id'], (string) $key );
					$out  .= '<div class="estat-pocket-kv"><i>' . esc_html( (string) $word ) . '</i><b>' .
						( '' !== $now ? '<s>' . esc_html( (string) $now ) . '</s> ' : '' ) .
						esc_html( Requests::describe( (string) $key, (string) $value ) ) . '</b></div>';
				}
				if ( ! empty( $changes['note'] ) ) {
					$out .= '<div class="estat-pocket-quote">' . esc_html( (string) $changes['note'] ) . '</div>';
				}
			}

			$rid = (int) $req['id'];
			$out .= '<div class="estat-pocket-actions">' .
				'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
				'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
				'<input type="hidden" name="estat_pocket_action" value="request_approve">' .
				'<input type="hidden" name="request_id" value="' . (int) $rid . '">' .
				'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Yes, change it', 'estat-os' ) . '</button></form>' .
				'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
				'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
				'<input type="hidden" name="estat_pocket_action" value="request_decline">' .
				'<input type="hidden" name="request_id" value="' . (int) $rid . '">' .
				'<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Not now', 'estat-os' ) . '</button></form>' .
				'</div>';
			$out .= '</div>';
		}

		// Proposed new records. Two lists again: the office says "put it live"
		// the same way for both, but nobody should have to work out which row
		// is a flat and which is a whole society.
		foreach ( array(
			PostTypes::LISTING => __( 'New properties waiting', 'estat-os' ),
			PostTypes::PROJECT => __( 'New societies or projects waiting', 'estat-os' ),
		) as $kind => $heading ) {
			$proposed = get_posts(
				array(
					'post_type'   => $kind,
					'post_status' => 'pending',
					'numberposts' => 20,
				)
			);
			if ( ! $proposed ) {
				continue;
			}
			$out .= '<h2 class="estat-pocket-h2">' . esc_html( $heading ) . '</h2>';
			foreach ( $proposed as $post ) {
				$out .= self::record_row( (int) $post->ID );
				$pid  = (int) $post->ID;
				$out .= '<div class="estat-pocket-actions" style="margin-top:-2px;">' .
					'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
					'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
					'<input type="hidden" name="estat_pocket_action" value="listing_approve">' .
					'<input type="hidden" name="record_id" value="' . (int) $pid . '">' .
					'<button class="estat-pocket-btn is-go" type="submit">' . esc_html__( 'Put it live', 'estat-os' ) . '</button></form>' .
					'<form method="post" action="' . esc_url( Pocket::url( 'approvals' ) ) . '" class="estat-pocket-inlineform">' .
					'<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">' .
					'<input type="hidden" name="estat_pocket_action" value="listing_decline">' .
					'<input type="hidden" name="record_id" value="' . (int) $pid . '">' .
					'<button class="estat-pocket-btn" type="submit">' . esc_html__( 'Back to draft', 'estat-os' ) . '</button></form>' .
					'</div>';
			}
		}

		return $out;
	}
}
