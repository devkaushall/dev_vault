<?php
/**
 * The agent pocket: the office in a phone browser.
 *
 * Same link on any phone, same WordPress accounts, no app to install. The
 * pocket deliberately owns no business logic of its own — every read and
 * write goes through the same classes the wp-admin screens use, so what an
 * agent can do from a phone is exactly what they can do from the office
 * computer, never more, and the permission map has no second copy to drift.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Pocket;

use EstatOS\Data\Agents;
use EstatOS\Security\Roles;
use EstatOS\Support\Icon;
use WP_Query;

defined( 'ABSPATH' ) || exit;

/**
 * Routing, assets, the shared page shell, and the guards.
 */
final class Pocket {

	/**
	 * URL prefix. Yoursite.com/agent is the whole install story: send the
	 * link, people sign in with the account they already have.
	 */
	public const ROUTE = 'agent';

	/**
	 * The screens that exist. Anything outside this list is a 404, not a
	 * clever URL with an empty body.
	 *
	 * @return array<string,string>
	 */
	public static function views(): array {
		return array(
			''          => 'today',
			'login'     => 'login',
			'listings'  => 'listings',
			'new'       => 'form',
			'listing'   => 'listing',
			'change'    => 'change',
			'inbox'     => 'inbox',
			'enquiry'   => 'enquiry',
			'approvals' => 'approvals',
			'you'       => 'you',

			/*
			 * The app's own five doors, plus the two that stand beside them.
			 *
			 * The older addresses above stay exactly as they were: a link that
			 * was shared, or a phone with a screen open from before an update,
			 * must keep working. These are the same records seen a shorter way —
			 * "leads" is the enquiry list, "visits" is the visit list, "more" is
			 * everything that is not part of a normal day.
			 */
			'leads'     => 'leads',
			'visits'    => 'visits',
			'visit'     => 'visit',
			'more'      => 'more',
			'capture'   => 'capture',
			'capture-lead'  => 'capture-lead',
			'capture-want'  => 'capture-want',
			'capture-visit' => 'capture-visit',
			'capture-owner' => 'capture-owner',
			'search'    => 'search',
			// Pocket 2.2 — what this phone is still holding, waiting for a
			// network to send it up on.
			'queue'     => 'queue',
		);
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'init', array( __CLASS__, 'add_rewrites' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle' ), 5 );
		// Team members can sign in with the phone number saved on their record.
		add_filter( 'authenticate', array( __CLASS__, 'phone_auth' ), 20, 3 );
	}

	/**
	 * Phone login: if log looks like phone, find agent by phone and try password.
	 *
	 * @param \WP_User|\WP_Error|null $user User or error.
	 * @param string $username Username/phone.
	 * @param string $password Password.
	 * @return \WP_User|\WP_Error|null
	 */
	public static function phone_auth( $user, string $username, string $password ) {
		if ( $user instanceof \WP_User ) {
			return $user;
		}
		if ( '' === $username || '' === $password ) {
			return $user;
		}
		// Only attempt if username is mostly digits (phone).
		$digits = preg_replace( '/\D/', '', $username );
		if ( strlen( (string) $digits ) < 7 ) {
			return $user;
		}
		// Find agent post by phone meta.
		$agent_id = self::agent_by_phone( $username );
		if ( ! $agent_id ) {
			return $user;
		}
		$user_id = (int) get_post_meta( $agent_id, '_estat_user_id', true );
		if ( $user_id <= 0 ) {
			// Also try _estat_user_id via Agents::for_user reverse? Try user with meta.
			return $user;
		}
		$wp_user = get_user_by( 'id', $user_id );
		if ( ! $wp_user ) {
			return $user;
		}
		// Verify password against that user.
		if ( ! wp_check_password( $password, $wp_user->user_pass, $wp_user->ID ) ) {
			return $user;
		}
		return $wp_user;
	}

	private static function agent_by_phone( string $phone ): int {
		$digits = preg_replace( '/\D/', '', $phone );
		$digits = substr( (string) $digits, -10 ); // last 10 for India.
		if ( '' === $digits ) {
			return 0;
		}
		// Search agent posts.
		$q = new \WP_Query(
			array(
				'post_type'      => \EstatOS\Data\PostTypes::AGENT,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_query'     => array(
					'relation' => 'OR',
					array( 'key' => '_estat_phone', 'value' => $digits, 'compare' => 'LIKE' ),
					array( 'key' => '_estat_whatsapp', 'value' => $digits, 'compare' => 'LIKE' ),
					array( 'key' => '_estat_agent_phone', 'value' => $digits, 'compare' => 'LIKE' ),
					array( 'key' => '_estat_agent_whatsapp', 'value' => $digits, 'compare' => 'LIKE' ),
				),
				'fields' => 'ids',
			)
		);
		$ids = $q->posts;
		return ! empty( $ids ) ? (int) $ids[0] : 0;
	}

	/**
	 * The /agent routes.
	 *
	 * @return void
	 */
	public static function add_rewrites(): void {
		if ( ! function_exists( 'add_rewrite_rule' ) ) {
			return;
		}
		// Stable /agent routing — handles /agent, /agent/, /agent/listings, /agent/new/123, etc.
		add_rewrite_rule( '^' . self::ROUTE . '/?$', 'index.php?estat_pocket_view=', 'top' );
		add_rewrite_rule( '^' . self::ROUTE . '/([a-z-]+)/?$', 'index.php?estat_pocket_view=$matches[1]', 'top' );
		add_rewrite_rule( '^' . self::ROUTE . '/([a-z-]+)/([0-9]+)/?$', 'index.php?estat_pocket_view=$matches[1]&estat_pocket_id=$matches[2]', 'top' );

		// Flush once per version — ensures /agent never 404s after upgrade.
		if ( get_option( 'estat_pocket_flush' ) !== ESTAT_VERSION ) {
			update_option( 'estat_pocket_flush', ESTAT_VERSION, false );
			if ( function_exists( 'flush_rewrite_rules' ) ) {
				flush_rewrite_rules();
			}
		}
	}

	public static function query_vars( array $vars ): array {
		$vars[] = 'estat_pocket_view';
		$vars[] = 'estat_pocket_id';
		return $vars;
	}

	/**
	 * Is this request for the pocket? Now also detects /agent via REQUEST_URI
	 * if rewrite rules haven't flushed yet (common cause of "unstable").
	 */
	public static function serving(): bool {
		if ( isset( $GLOBALS['wp']->query_vars['estat_pocket_view'] ) ) {
			return true;
		}
		// Fallback: direct URI check — makes /agent work even if permalinks not saved.
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri = (string) $_SERVER['REQUEST_URI'];
			$uri = strtok( $uri, '?' ); // strip query
			$uri = trim( $uri, '/' );
			if ( '' !== $uri && ( $uri === self::ROUTE || 0 === strpos( $uri, self::ROUTE . '/' ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Parse view/id from URI when query_vars not set (fallback for stability).
	 */
	private static function parse_from_uri(): array {
		$view = (string) get_query_var( 'estat_pocket_view' );
		$id   = (int) get_query_var( 'estat_pocket_id' );
		if ( '' !== $view || $id > 0 ) {
			return array( $view, $id );
		}
		// Fallback parse
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		$uri = strtok( $uri, '?' );
		$uri = trim( $uri, '/' );
		// Remove leading agent - PHP 7.4 compatible (str_starts_with is PHP 8.0+)
		if ( 0 === strpos( $uri, self::ROUTE ) ) {
			$uri = substr( $uri, strlen( self::ROUTE ) );
			$uri = trim( $uri, '/' );
		}
		if ( '' === $uri ) {
			return array( '', 0 );
		}
		$parts = explode( '/', $uri );
		$view = isset( $parts[0] ) ? sanitize_key( $parts[0] ) : '';
		$id   = isset( $parts[1] ) ? absint( $parts[1] ) : 0;
		return array( $view, $id );
	}

	public static function handle(): void {
		if ( ! self::serving() ) {
			return;
		}
		list( $view, $id ) = self::parse_from_uri();

		if ( ! array_key_exists( $view, self::views() ) ) {
			status_header( 404 );
			echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . esc_html__( 'Not found', 'estat-os' ) . '</title>'
				. '<link rel="stylesheet" href="' . esc_url( ESTAT_URL . 'assets/css/tokens.css?ver=' . ESTAT_VERSION ) . '">'
				. '<link rel="stylesheet" href="' . esc_url( ESTAT_URL . 'assets/css/pocket.css?ver=' . ESTAT_VERSION ) . '">'
				. '</head><body class="estat-pocket"><div class="estat-pocket-screen" style="max-width:560px;margin:40px auto;padding:20px">'
				. '<div class="estat-pocket-card"><h1 style="margin:0 0 8px">' . esc_html__( 'That page does not exist', 'estat-os' ) . '</h1>'
				. '<p class="estat-pocket-hint">' . esc_html__( 'Try Today, Clients, Properties or More.', 'estat-os' ) . '</p>'
				. '<a class="estat-pocket-btn is-go" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Go to Today', 'estat-os' ) . '</a></div></div></body></html>';
			exit;
		}

		if ( 'POST' === strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( is_array($_SERVER['REQUEST_METHOD']) ? '' : $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			Actions::run( $view, $id );
		}

		Screens::render( $view, $id );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Who is allowed in.
	 * ------------------------------------------------------------------ */

	/**
	 * Can this person use the pocket at all?
	 *
	 * One office capability is enough. A WordPress subscriber with no office
	 * role gets the same answer as a stranger: the sign-in page, and after
	 * signing in, the refusal.
	 *
	 * @return bool
	 */
	public static function can_use(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		foreach ( Roles::agent_caps() as $cap ) {
			if ( current_user_can( $cap ) ) {
				return true;
			}
		}
		foreach ( array( 'estat_review_listings', 'estat_publish_listings', 'estat_manage_settings' ) as $cap ) {
			if ( current_user_can( $cap ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * May this person act as the office from the pocket? The approvals tab
	 * exists for exactly these people and nobody else.
	 *
	 * @return bool
	 */
	public static function is_office(): bool {
		return current_user_can( 'estat_manage_settings' )
			|| current_user_can( 'estat_publish_listings' )
			|| current_user_can( 'estat_review_listings' );
	}

	/**
	 * The agent record behind the current user, 0 when there is none.
	 *
	 * @return int
	 */
	public static function agent_id(): int {
		return Agents::for_user( get_current_user_id() );
	}

	/**
	 * Does the current person own (or is assigned to) this record?
	 *
	 * @param int $record_id Listing or project post ID.
	 * @return bool
	 */
	public static function owns( int $record_id ): bool {
		if ( $record_id <= 0 ) {
			return false;
		}
		$post = get_post( $record_id );
		if ( ! $post ) {
			return false;
		}
		if ( (int) $post->post_author === get_current_user_id() ) {
			return true;
		}
		return (int) get_post_meta( $record_id, '_estat_assigned_user', true ) === get_current_user_id();
	}

	/* ---------------------------------------------------------------------
	 * Shared helpers the screens and actions both use.
	 * ------------------------------------------------------------------ */

	/**
	 * Pocket URL for a view (and optional record).
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID.
	 * @return string
	 */
	public static function url( string $view = '', int $id = 0 ): string {
		$path = home_url( '/' . self::ROUTE . '/' );
		if ( '' !== $view ) {
			$path .= $view . '/';
		}
		if ( $id > 0 ) {
			$path .= $id . '/';
		}
		return $path;
	}

	/**
	 * The current record's listing page on the public site, if it has one.
	 *
	 * @param int $record_id Post ID.
	 * @return string
	 */
	public static function public_url( int $record_id ): string {
		$url = get_permalink( $record_id );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * Redirect back to a view with a flash key. Flash text is looked up from
	 * a fixed table on the next render — user text never travels through
	 * the URL.
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID.
	 * @param string $ok   Flash key.
	 * @return void
	 */
	public static function redirect( string $view, int $id = 0, string $ok = '' ): void {
		$url = self::url( $view, $id );
		if ( '' !== $ok ) {
			$url = add_query_arg( 'flash', rawurlencode( $ok ), $url );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Flash messages, from a fixed table. Keys only ever come from
	 * self::redirect(); nothing here prints anything that arrived from a
	 * request.
	 *
	 * @return string A sentence, or '' when there is no flash.
	 */
	public static function flash(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$key = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['flash']) ? '' : $_GET['flash'] ) ) ) : '';
		$out = '';

		$messages = array(
			'saved'         => __( 'Draft saved. Nothing is on the website until the office approves it.', 'estat-os' ),
			'sent'          => __( 'Sent to the office for approval. You will see it in your list.', 'estat-os' ),
			'requested'     => __( 'Your change is with the office. They see it the moment it lands.', 'estat-os' ),
			'request_on'    => __( 'This change request is already in the office queue. Nothing else was filed.', 'estat-os' ),
			'paused'        => __( 'The listing is paused. It is hidden from the website, not deleted.', 'estat-os' ),
			'resumed'       => __( 'The listing is live again.', 'estat-os' ),
			'trashed'       => __( 'Removed. It is off the website and waiting in the office bin, where it can be put back.', 'estat-os' ),
			'restored'      => __( 'It is back. Properties that were live are on the website again.', 'estat-os' ),
			'note'          => __( 'Your note is on the enquiry.', 'estat-os' ),
			'status'        => __( 'The enquiry status has moved.', 'estat-os' ),
			'visit'         => __( 'Visit logged. The office sees the same record.', 'estat-os' ),
			'approved'      => __( 'Approved and applied.', 'estat-os' ),
			'declined'      => __( 'Turned down, with your word attached.', 'estat-os' ),
			'listed'        => __( 'The listing is live on the website.', 'estat-os' ),
			'listed_back'   => __( 'The listing went back to the agent as a draft.', 'estat-os' ),
			'photos'         => __( 'Photographs added.', 'estat-os' ),
			'voice'          => __( 'Voice note saved with it. The office can hear it.', 'estat-os' ),
			'you_saved'     => __( 'Saved. Your details are up to date.', 'estat-os' ),
			'pass_changed'  => __( 'Password changed. Your other devices will ask you to sign in again.', 'estat-os' ),
			'auth'          => __( 'That sign-in did not work. Try again, or ask your office.', 'estat-os' ),
			'nope'          => __( 'You are not allowed to do that from here.', 'estat-os' ),
			'gone'          => __( 'That record is not here any more.', 'estat-os' ),
			'bad'           => __( 'Something was missing or unreadable. Nothing was changed.', 'estat-os' ),
			// Pocket 2.1 — the capture sheet and visit mode.
			'enquiry_new'   => __( 'Enquiry saved. It is on your list, and the office can see it too.', 'estat-os' ),
			'visit_new'     => __( 'Visit booked. It will show up in Today on the day.', 'estat-os' ),
			'visit_prep'    => __( 'Saved. The office can see what you checked before setting off.', 'estat-os' ),
			'visit_done'    => __( 'Visit completed and written down.', 'estat-os' ),
			'owner_ok'      => __( 'Thank you. The office can see the owner was checked today.', 'estat-os' ),
			'shared'        => __( 'Shared. It is on the client’s timeline.', 'estat-os' ),
		);

		if ( isset( $messages[ $key ] ) ) {
			$out = $messages[ $key ];
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$err = isset( $_GET['err'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['err']) ? '' : $_GET['err'] ) ) ) : '';
		if ( '' !== $err ) {
			$out = $err; // Set only by self::fail(); plain sentences, no markup.
		}

		return $out;
	}

	/**
	 * Straight to Today with a why-line. Used by the screens when a record
	 * vanished or the person may not see it — one exit path, one message
	 * shape, no half-rendered page.
	 *
	 * @param string $key Flash key from the fixed table.
	 * @return void
	 */
	public static function fail_to_today( string $key ): void {
		self::redirect( '', 0, $key );
	}

	/**
	 * Redirect back with a plain sentence of failure.
	 *
	 * @param string $view View slug.
	 * @param int    $id   Record ID.
	 * @param string $msg  A sentence (never a user value).
	 * @return void
	 */
	public static function fail( string $view, int $id, string $msg ): void {
		$url = add_query_arg( 'err', $msg, self::url( $view, $id ) ); // add_query_arg encodes once; rawurlencode here would encode twice.
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * An icon from the 98-set, never a hand-drawn path.
	 *
	 * @param string $name Icon name.
	 * @param int    $size Pixels.
	 * @return string
	 */
	public static function icon( string $name, int $size = 20 ): string {
		return Icon::render( $name, $size, 'estat-pocket-ico' );
	}

	/**
	 * A record's status in the pocket's words.
	 *
	 * @param \WP_Post|int $post Post or ID.
	 * @return array{0:string,1:string} [label, pill tone]
	 */
	public static function status_of( $post ): array {
		$post = is_object( $post ) ? $post : get_post( $post );
		if ( ! $post ) {
			return array( '', '' );
		}
		// The same words the office screens use — one vocabulary, no drift.
		return array(
			\EstatOS\Support\Status::label( \EstatOS\Support\Status::PUBLICATION, (string) $post->post_status ),
			\EstatOS\Support\Status::tone( \EstatOS\Support\Status::PUBLICATION, (string) $post->post_status ),
		);
	}

	/**
	 * Listings and projects the current person may see rows for.
	 *
	 * The office sees everything; an agent sees published records (read-only
	 * unless they are theirs) plus every record they own in any state. Two
	 * queries merged in memory is honest about that shape; pretending one
	 * query can say "public OR mine" is how clever code hides bugs.
	 *
	 * @param string $search Search text.
	 * @param string $kind   '' for everything, otherwise one post type. The
	 *                       phone keeps properties and societies/projects in
	 *                       separate lists; the kind is how a caller says
	 *                       which list it wants.
	 * @return \WP_Post[]
	 */
	public static function my_records( string $search = '', string $kind = '' ): array {
		$base = array(
			'post_type'      => '' !== $kind ? $kind : array( 'estat_listing', 'estat_project' ),
			'posts_per_page' => 40,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		);
		if ( '' !== trim( $search ) ) {
			$base['s'] = $search;
		}

		if ( self::is_office() ) {
			$base['post_status'] = array( 'publish', 'draft', 'pending', 'private' );
			return array_values( ( new WP_Query( $base ) )->posts );
		}

		$me   = get_current_user_id();
		$seen = array();
		$out  = array();

		$public = new WP_Query( array_merge( $base, array( 'post_status' => 'publish' ) ) );
		foreach ( $public->posts as $post ) {
			$seen[ (int) $post->ID ] = true;
			$out[] = $post;
		}

		$mine = new WP_Query(
			array_merge(
				$base,
				array(
					'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
					'author'      => $me,
				)
			)
		);
		foreach ( $mine->posts as $post ) {
			if ( ! isset( $seen[ (int) $post->ID ] ) ) {
				$seen[ (int) $post->ID ] = true;
				$out[] = $post;
			}
		}

		$assigned = new WP_Query(
			array_merge(
				$base,
				array(
					'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
					'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'   => '_estat_assigned_user',
							'value' => $me,
						),
					),
				)
			)
		);
		foreach ( $assigned->posts as $post ) {
			if ( ! isset( $seen[ (int) $post->ID ] ) ) {
				$seen[ (int) $post->ID ] = true;
				$out[] = $post;
			}
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return strcmp( (string) $b->post_modified, (string) $a->post_modified );
			}
		);

		return $out;
	}

	/**
	 * The records this person removed, waiting in the bin.
	 *
	 * Shown apart from the working list, because a binned property is not a
	 * property you are working on: it is one you can put back. The office
	 * sees every binned record; everybody else sees their own.
	 *
	 * @param string $kind '' for everything, otherwise one post type.
	 * @return array<int,\WP_Post>
	 */
	public static function binned_records( string $kind = '' ): array {
		$base = array(
			'post_type'      => '' !== $kind ? $kind : array( 'estat_listing', 'estat_project' ),
			'post_status'    => 'trash',
			'posts_per_page' => 40,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		);

		if ( self::is_office() ) {
			return array_values( ( new WP_Query( $base ) )->posts );
		}

		$me = get_current_user_id();
		$by_author = new WP_Query( array_merge( $base, array( 'author' => $me ) ) );
		$by_assign = new WP_Query(
			array_merge(
				$base,
				array(
					'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'   => '_estat_assigned_user',
							'value' => $me,
						),
					),
				)
			)
		);

		$seen = array();
		$out  = array();
		foreach ( array_merge( $by_author->posts, $by_assign->posts ) as $post ) {
			if ( ! isset( $seen[ (int) $post->ID ] ) ) {
				$seen[ (int) $post->ID ] = true;
				$out[] = $post;
			}
		}
		return $out;
	}

	/**
	 * Can this person see this record at all in the pocket?
	 *
	 * Published answers for everyone with a pocket account; anything else is
	 * only visible to the office and to whoever owns it.
	 *
	 * @param \WP_Post|int $post Post or ID.
	 * @return bool
	 */
	public static function can_see( $post ): bool {
		$post = is_object( $post ) ? $post : get_post( $post );
		if ( ! $post ) {
			return false;
		}
		if ( 'publish' === $post->post_status ) {
			return true;
		}
		return self::is_office() || self::owns( (int) $post->ID );
	}
}
