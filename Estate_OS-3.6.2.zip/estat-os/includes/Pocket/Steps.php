<?php
/**
 * The property form, step by step — as data, not as markup.
 *
 * Why this file exists
 * --------------------
 * The office editor (`Admin\Screens\ListingsScreen`) and the phone form
 * (`Pocket\Screens::form()`) used to keep two separate lists of fields. They
 * drifted: the phone could type eleven answers, the office editor asked
 * forty-six, and somebody in the office had to fill the gap by hand for every
 * property an agent added from the road.
 *
 * This is now the one place that says which questions a property asks and in
 * what order. The phone renders its steps from here; the office editor keeps
 * its own three chapters, but `wp_test/pocket_parity.php` renders both screens
 * and fails if the editor has a field the phone cannot type. Adding a field to
 * the schema and forgetting the phone is therefore a failing test, not a
 * support call.
 *
 * The order is the order of a real conversation with a client: what and where,
 * the money, the size, the photographs, the words, then a last look. The
 * office-only questions sit at the end, out of the way of anybody holding a
 * phone in a parking lot.
 *
 * @package EstatOS
 */

namespace EstatOS\Pocket;

use EstatOS\Data\Meta;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * The steps of the property form.
 */
class Steps {

	/**
	 * Every step, in order.
	 *
	 * @param bool $office Whether to include the office-only step.
	 * @return array<int,array<string,mixed>>
	 */
	public static function all( bool $office = false ): array {
		$steps = array(
			array(
				'key'    => 'place',
				'title'  => __( 'What and where', 'estat-os' ),
				'hint'   => __( 'Name it, say what it is, and say where it is.', 'estat-os' ),
				'fields' => array(
					array( 'name' => '_estat_offer', 'input' => 'select', 'vocab' => 'offers', 'required' => true ),
					array( 'name' => '_estat_property_type', 'input' => 'select', 'vocab' => 'property_types', 'required' => true, 'blank' => __( 'Choose a type', 'estat-os' ) ),
					array( 'name' => 'title', 'input' => 'text', 'required' => true, 'example' => __( '3 BHK apartment with a park view', 'estat-os' ) ),
					array( 'name' => '_estat_project_id', 'input' => 'project' ),
					array( 'name' => 'locality', 'input' => 'text', 'required' => true, 'help' => __( 'Separate several with commas.', 'estat-os' ), 'example' => 'Sector 48, Sohna Road' ),
					array( 'name' => '_estat_address', 'input' => 'textarea', 'help' => __( 'Only the locality is shown on the website.', 'estat-os' ) ),
					array( 'name' => '_estat_facing', 'input' => 'select', 'vocab' => 'facing' ),
					array( 'name' => '_estat_latitude', 'input' => 'text', 'example' => '28.6139', 'row' => 'map' ),
					array( 'name' => '_estat_longitude', 'input' => 'text', 'example' => '77.2090', 'row' => 'map' ),
				),
			),
			array(
				'key'    => 'money',
				'title'  => __( 'The price', 'estat-os' ),
				'hint'   => __( 'One money box. It is a price for a sale and a monthly rent for a rental.', 'estat-os' ),
				'fields' => array(
					array( 'name' => '_estat_price', 'input' => 'money' ),
					array( 'name' => '_estat_price_type', 'input' => 'select', 'vocab' => 'price_types', 'only' => 'rent' ),
					array( 'name' => '_estat_deposit', 'input' => 'number', 'only' => 'rent', 'example' => '100000' ),
					array( 'name' => '_estat_maintenance', 'input' => 'number', 'only' => 'rent', 'example' => '3000' ),
					array( 'name' => '_estat_investment', 'input' => 'checkbox', 'checkbox' => __( 'Mark this as a good investment opportunity', 'estat-os' ) ),
				),
			),
			array(
				'key'    => 'size',
				'title'  => __( 'Size and rooms', 'estat-os' ),
				'hint'   => __( 'How big it is and how many rooms. Leave what you do not know.', 'estat-os' ),
				'fields' => array(
					array( 'name' => '_estat_area', 'input' => 'number', 'example' => '1250' ),
					array( 'name' => '_estat_area_unit', 'input' => 'select', 'vocab' => 'area_units' ),
					array( 'name' => '_estat_area_type', 'input' => 'select', 'vocab' => 'area_types' ),
					array( 'name' => '_estat_bedrooms', 'input' => 'number', 'only' => 'home', 'example' => '3' ),
					array( 'name' => '_estat_bathrooms', 'input' => 'number', 'only' => 'home', 'example' => '2' ),
					array( 'name' => '_estat_balconies', 'input' => 'number', 'only' => 'home' ),
					array( 'name' => '_estat_parking', 'input' => 'number', 'only' => 'built' ),
					array( 'name' => '_estat_floor', 'input' => 'number', 'only' => 'built' ),
					array( 'name' => '_estat_total_floors', 'input' => 'number', 'only' => 'built' ),
					array( 'name' => '_estat_age', 'input' => 'number', 'only' => 'built' ),
					array( 'name' => '_estat_furnishing', 'input' => 'select', 'vocab' => 'furnishing' ),
					array( 'name' => '_estat_construction', 'input' => 'select', 'vocab' => 'construction', 'only' => 'built' ),
					array( 'name' => '_estat_developer', 'input' => 'text', 'only' => 'built' ),
					array( 'name' => '_estat_possession_date', 'input' => 'date' ),
				),
			),
			array(
				'key'    => 'media',
				'title'  => __( 'Photos and video', 'estat-os' ),
				'hint'   => __( 'The first photo is what people see first. Tap the star to move it there.', 'estat-os' ),
				'fields' => array(
					array(
					'name'   => '_estat_gallery',
					'input'  => 'photos',
					'upload' => 'estat_pocket_photos',
					'label'  => __( 'Photographs', 'estat-os' ),
					'hint'   => __( 'Tap to add from the camera. Up to 40.', 'estat-os' ),
					/*
					 * The shots that make a listing work, in the order they
					 * are worth taking. Not a demand — a prompt, for the
					 * person standing in a flat holding a phone.
					 */
					'shots'  => array(
						__( 'The front of the building', 'estat-os' ),
						__( 'The living room', 'estat-os' ),
						__( 'The kitchen', 'estat-os' ),
						__( 'Each bedroom', 'estat-os' ),
						__( 'The bathroom', 'estat-os' ),
						__( 'A balcony or a window view', 'estat-os' ),
						__( 'Parking, the lift, the gate', 'estat-os' ),
					),
				),
				array(
					'name'   => '_estat_voice_notes',
					'input'  => 'voice',
					'upload' => 'estat_pocket_voice',
					'label'  => __( 'A voice note', 'estat-os' ),
					'hint'   => __( 'Say what a buyer would want to know — thirty seconds is plenty. The office hears it with the property.', 'estat-os' ),
				),
					array( 'name' => '_estat_floor_plans', 'input' => 'photos', 'upload' => 'estat_pocket_floor_plans', 'label' => __( 'Floor plans', 'estat-os' ), 'hint' => __( 'A photo of the plan on paper is fine.', 'estat-os' ), 'group' => 'papers' ),
					array( 'name' => '_estat_brochures', 'input' => 'photos', 'upload' => 'estat_pocket_brochures', 'label' => __( 'Brochures and documents', 'estat-os' ), 'hint' => __( 'Pictures of the papers you were given.', 'estat-os' ), 'group' => 'papers' ),
					array( 'name' => '_estat_video_url', 'input' => 'url', 'example' => 'https://youtu.be/…' ),
					array( 'name' => '_estat_tour_url', 'input' => 'url' ),
				),
			),
			array(
				'key'    => 'words',
				'title'  => __( 'The description', 'estat-os' ),
				'hint'   => __( 'Write it the way you would tell a friend about it.', 'estat-os' ),
				'fields' => array(
					array( 'name' => 'description', 'input' => 'textarea', 'rows' => 6 ),
					array( 'name' => 'amenities', 'input' => 'text', 'help' => __( 'For example: lift, parking, power backup.', 'estat-os' ) ),
					array( 'name' => 'features', 'input' => 'text', 'help' => __( 'Anything that makes this one different.', 'estat-os' ) ),
				),
			),
			array(
				'key'    => 'check',
				'title'  => __( 'Look it over', 'estat-os' ),
				'hint'   => __( 'Everything you typed, in one place. Fix anything that looks wrong.', 'estat-os' ),
				'fields' => array(),
			),
		);

		if ( $office ) {
			$steps[] = self::office_step();
		}

		return $steps;
	}

	/**
	 * The last step: the questions only the office answers.
	 *
	 * Kept apart on purpose. An agent standing in a flat has no business
	 * deciding whether a property is featured on the home page, and hiding
	 * these behind one more step is friendlier than hiding them inside the
	 * ones he does need.
	 *
	 * @return array<string,mixed>
	 */
	private static function office_step(): array {
		$fields = array(
			array( 'name' => '_estat_availability', 'input' => 'select', 'vocab' => 'availability' ),
			array( 'name' => '_estat_freshness', 'input' => 'select', 'vocab' => 'freshness', 'blank' => __( '— No tag —', 'estat-os' ) ),
			array( 'name' => '_estat_agent_id', 'input' => 'agent' ),
		);

		if ( current_user_can( 'estat_verify_listings' ) ) {
			$fields[] = array( 'name' => '_estat_verification', 'input' => 'select', 'vocab' => 'verification' );
		}

		if ( Settings::get( 'show_regulatory' ) ) {
			$fields[] = array(
				'name'  => '_estat_regulatory_id',
				'input' => 'text',
				'label' => sprintf( /* translators: %s: regulatory label such as RERA */ __( '%s number', 'estat-os' ), (string) Settings::get( 'regulatory_label', 'RERA' ) ),
			);
		}

		$fields[] = array( 'name' => '_estat_expiry_date', 'input' => 'date' );
		$fields[] = array( 'name' => '_estat_external_id', 'input' => 'text' );
		$fields[] = array( 'name' => '_estat_featured', 'input' => 'checkbox', 'checkbox' => __( 'Show this property prominently on the website', 'estat-os' ) );
		$fields[] = array( 'name' => '_estat_internal_notes', 'input' => 'textarea', 'rows' => 4, 'help' => __( 'Only your office can see this. Never shown on the website.', 'estat-os' ) );

		return array(
			'key'    => 'office',
			'title'  => __( 'Office only', 'estat-os' ),
			'hint'   => __( 'Who is handling it, and what visitors never see.', 'estat-os' ),
			'office' => true,
			'fields' => $fields,
		);
	}

	/**
	 * One field definition, by name, across every step.
	 *
	 * @param string $name Field name.
	 * @param bool   $office Include the office step.
	 * @return array<string,mixed>|null
	 */
	public static function field( string $name, bool $office = true ): ?array {
		foreach ( self::all( $office ) as $step ) {
			foreach ( $step['fields'] as $field ) {
				if ( $field['name'] === $name ) {
					return $field;
				}
			}
		}
		return null;
	}

	/**
	 * Which step holds a field.
	 *
	 * @param string $name Field name.
	 * @return string Step key, or '' when nothing claims it.
	 */
	public static function step_key( string $name ): string {
		foreach ( self::all( true ) as $step ) {
			foreach ( $step['fields'] as $field ) {
				if ( $field['name'] === $name ) {
					return (string) $step['key'];
				}
			}
		}
		return '';
	}

	/**
	 * Every field name the form can post, uploads and controls excluded.
	 *
	 * @param bool $office Include the office step.
	 * @return string[]
	 */
	public static function names( bool $office = false ): array {
		$names = array();
		foreach ( self::all( $office ) as $step ) {
			foreach ( $step['fields'] as $field ) {
				$names[] = (string) $field['name'];
			}
		}
		return $names;
	}

	/**
	 * The label the office uses for a field.
	 *
	 * The schema already knows every label; the phone should never invent its
	 * own word for the same box. Where a field is not in the schema (the
	 * title, the description, the photographs) the name is spelled out here.
	 *
	 * @param string $name Field name.
	 * @return string
	 */
	public static function label( string $name ): string {
		$own = array(
			'title'       => __( 'Headline', 'estat-os' ),
			'locality'    => __( 'Locality', 'estat-os' ),
			'description' => __( 'Describe the property', 'estat-os' ),
			'amenities'   => __( 'Amenities', 'estat-os' ),
			'features'    => __( 'Special features', 'estat-os' ),
			'cover_id'    => __( 'Main photo', 'estat-os' ),
		);
		if ( isset( $own[ $name ] ) ) {
			return (string) $own[ $name ];
		}

		$schema = Meta::listing_schema();
		$key    = '_estat_' === substr( $name, 0, 7 ) ? $name : '_estat_' . $name;
		if ( isset( $schema[ $key ]['label'] ) ) {
			return (string) $schema[ $key ]['label'];
		}

		return ucwords( str_replace( '_', ' ', $name ) );
	}

	/**
	 * The words for one vocabulary, ready for a select box.
	 *
	 * @param string $vocab Vocabulary name.
	 * @return array<string,string>
	 */
	public static function options( string $vocab ): array {
		$keys    = Vocabulary::keys( $vocab );
		$options = array();
		foreach ( $keys as $key ) {
			if ( '' === (string) $key ) {
				continue;
			}
			$options[ (string) $key ] = Vocabulary::label( $vocab, (string) $key );
		}
		return $options;
	}

	/**
	 * The properties and societies a listing can belong to.
	 *
	 * @return array<int,string>
	 */
	public static function projects(): array {
		$posts = get_posts(
			array(
				'post_type'   => PostTypes::PROJECT,
				'numberposts' => 200,
				'post_status' => array( 'publish', 'draft', 'private' ),
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);
		$out = array();
		foreach ( $posts as $post ) {
			$out[ (int) $post->ID ] = (string) $post->post_title;
		}
		return $out;
	}

	/**
	 * The team members, for the office step.
	 *
	 * @return array<int,string>
	 */
	public static function agents(): array {
		$posts = get_posts(
			array(
				'post_type'   => PostTypes::AGENT,
				'numberposts' => 200,
				'post_status' => array( 'publish', 'draft', 'private' ),
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);
		$out = array();
		foreach ( $posts as $post ) {
			$out[ (int) $post->ID ] = (string) $post->post_title;
		}
		return $out;
	}
}
