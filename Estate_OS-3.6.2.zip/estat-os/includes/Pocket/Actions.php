<?php
/**
 * Every write the pocket can perform. One action per button, each one a thin
 * wrapper around the class that already owns that job in wp-admin — the
 * pocket never keeps a second copy of a rule, because second copies are how
 * the phone and the office start disagreeing about what a person may do.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Pocket;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Agents;
use EstatOS\Data\Bin;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Pocket\Steps;
use EstatOS\Field\Requests;
use EstatOS\Leads\LeadEvents;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Static dispatcher; see the cases for the grammar of each button.
 */
final class Actions {

	/**
	 * Actions a signed-in pocket user may reach for. Capability gates are
	 * inside each case, because "who may press this" is part of the job, not
	 * a coat of paint at the door.
	 *
	 * @var string[]
	 */
	public const ACTIONS = array(
		'save_draft',
		'send',
		'request',
		'pause',
		'resume',
		'trash_draft',
		'log_visit',
		'lead_update',
		'request_approve',
		'request_decline',
		'listing_approve',
		'listing_decline',
		'restore_listing',
		'save_you',
		'save_password',
		'quick_enquiry',
		'quick_visit',
		'visit_checks',
		'visit_finish',
		'owner_update',
	);

	/**
	 * Verify once, then route.
	 *
	 * @param string $view The screen that posted.
	 * @param int    $id   The record in the URL, when the view has one.
	 * @return void
	 */
	public static function run( string $view, int $id ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$nonce  = isset( $_POST['_estat_pocket'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['_estat_pocket']) ? '' : $_POST['_estat_pocket'] ) ) ) : '';
		$action = isset( $_POST['estat_pocket_action'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_pocket_action']) ? '' : $_POST['estat_pocket_action'] ) ) ) : '';
		// phpcs:enable

		if ( ! is_user_logged_in() || ! wp_verify_nonce( $nonce, 'estat_pocket' ) ) {
			Pocket::fail_to_today( 'bad' );
		}
		if ( ! Pocket::can_use() ) {
			Pocket::fail_to_today( 'nope' );
		}
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			Pocket::fail_to_today( 'bad' );
		}

		self::$view = $view;
		self::$id   = $id;

		switch ( $action ) {
			case 'save_draft':
				self::save_draft();
				break;
			case 'send':
				self::propose();
				break;
			case 'request':
				self::request_change();
				break;
			case 'pause':
			case 'resume':
				self::visibility( 'pause' === $action ? 'private' : 'publish' );
				break;
			case 'trash_draft':
				self::remove_draft();
				break;
			case 'restore_listing':
				self::restore_listing();
				break;
			case 'log_visit':
				self::log_visit();
				break;
			case 'lead_update':
				self::lead_update();
				break;
			case 'save_you':
				self::save_you();
				break;
			case 'save_password':
				self::save_password();
				break;
			case 'request_approve':
			case 'request_decline':
				self::settle_request( 'request_approve' === $action ? 'approve' : 'decline' );
				break;
			case 'listing_approve':
			case 'listing_decline':
				self::settle_proposal( 'listing_approve' === $action ? 'publish' : 'draft' );
				break;
			case 'quick_enquiry':
				self::quick_enquiry();
				break;
			case 'quick_visit':
				self::quick_visit();
				break;
			case 'visit_checks':
				self::visit_checks();
				break;
			case 'visit_finish':
				self::visit_finish();
				break;
			case 'owner_update':
				self::owner_update();
				break;
		}

		// Every case redirects; falling here means a case forgot to.
		Pocket::fail_to_today( 'bad' );
	}

	/* ---------------------------------------------------------------------
	 * Capture: an enquiry, a visit, an owner check — written down in the field
	 * ------------------------------------------------------------------ */

	/**
	 * One string from POST.
	 *
	 * @param string $key Field name.
	 * @return string
	 */
	private static function text_post( string $key ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? (string) wp_unslash( is_array( $_POST[ $key ] ) ? '' : $_POST[ $key ] ) : '';
	}

	/**
	 * One choice from POST, kept inside a known list.
	 *
	 * @param string   $key     Field name.
	 * @param string[] $allowed Permitted values.
	 * @param string   $default Value when nothing usable was posted.
	 * @return string
	 */
	private static function choice_post( string $key, array $allowed, string $default = '' ): string {
		$value = sanitize_key( self::text_post( $key ) );
		return in_array( $value, $allowed, true ) ? $value : $default;
	}

	/**
	 * Write an enquiry down while it is still fresh.
	 *
	 * The office's own add-a-lead screen asks for everything a lead may one
	 * day hold. A phone standing in a car park asks for the two things that
	 * make the record useful — who, and how to reach them — and lets the
	 * rest arrive later. The record itself is created by Leads::create(), so
	 * dedupe, consent and the timeline behave exactly as they do elsewhere.
	 *
	 * @return void
	 */
	private static function quick_enquiry(): void {
		if ( ! Screens::may_see_enquiries() ) {
			Pocket::fail_to_today( 'nope' );
		}

		$name     = Sanitize::title( self::text_post( 'name' ) );
		$phone    = Sanitize::phone( self::text_post( 'phone' ) );
		$locality = Sanitize::text( self::text_post( 'locality' ) );
		$message  = Sanitize::textarea( self::text_post( 'message' ) );
		$intent   = self::choice_post( 'intent', array_keys( Vocabulary::lead_intents() ) );
		$budget_min = Sanitize::float( self::text_post( 'budget_min' ) );
		$budget_max = Sanitize::float( self::text_post( 'budget_max' ) );
		$followup   = Sanitize::datetime( self::text_post( 'followup_at' ) );
		$agent      = Pocket::agent_id();

		if ( '' === $name ) {
			Pocket::fail( 'capture-lead', 0, __( 'A name is needed — it is how the office will look this person up.', 'estat-os' ) );
		}
		if ( '' === $phone ) {
			Pocket::fail( 'capture-lead', 0, __( 'A phone number is needed. That is the whole point of writing it down now.', 'estat-os' ) );
		}
		if ( '' !== $budget_min && '' !== $budget_max && $budget_max < $budget_min ) {
			Pocket::fail( 'capture-lead', 0, __( 'The budget “up to” is smaller than the budget “from”. Swap them round.', 'estat-os' ) );
		}

		$result = Leads::create(
			array(
				'name'              => $name,
				'phone'             => $phone,
				'intent'            => $intent,
				'locality'          => $locality,
				'budget_min'        => $budget_min,
				'budget_max'        => $budget_max,
				'message'           => $message,
				'source'            => 'manual',
				'agent_id'          => $agent > 0 ? $agent : 0,
				'assigned_agent_id' => $agent > 0 ? $agent : 0,
				'consent'           => true,
				'idempotency_key'   => 'pocket-enquiry-' . get_current_user_id() . '-' . md5( $name . $phone . $message ),
			)
		);

		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'capture-lead', 0, $result->get_error_message() );
		}

		$lead_id = (int) $result;

		if ( '' !== $followup ) {
			Leads::update( $lead_id, array( 'followup_at' => $followup ) );
		}
		AuditLog::record( 'lead.captured', 'lead', $lead_id, array( 'via' => 'pocket' ) );

		Pocket::redirect( 'enquiry', $lead_id, 'enquiry_new' );
	}

	/**
	 * Book a site visit from the field.
	 *
	 * A visit is booked for a client, so the enquiry has to exist first —
	 * that is why this screen, and not a free-floating calendar, is where a
	 * visit begins. If the enquiry is still brand new, the act of fixing a
	 * visit means somebody spoke to the client: the enquiry moves to
	 * Contacted first, in the order the pipeline allows, and then to
	 * Scheduled by the visit itself.
	 *
	 * @return void
	 */
	private static function quick_visit(): void {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$lead_id    = self::int_post( 'lead_id' );
		$listing_id = self::int_post( 'listing_id' );
		$when       = Sanitize::datetime( self::text_post( 'scheduled_at' ) );
		$notes      = Sanitize::textarea( self::text_post( 'notes' ) );

		if ( $lead_id <= 0 ) {
			Pocket::fail( 'capture-visit', 0, __( 'Choose the client this visit is for.', 'estat-os' ) );
		}
		if ( '' === $when ) {
			Pocket::fail( 'capture-visit', 0, __( 'Choose the day and time of the visit.', 'estat-os' ) );
		}

		$lead = Leads::get( $lead_id );
		if ( ! $lead || ! Screens::lead_is_mine( $lead ) ) {
			Pocket::fail_to_today( 'nope' );
		}
		if ( $listing_id > 0 && ! Pocket::can_see( get_post( $listing_id ) ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$agent = Pocket::agent_id();
		if ( $agent <= 0 ) {
			$agent = (int) $lead['agent_id'];
		}

		// New → Contacted is a step the pipeline allows; New → Scheduled is
		// not, and a visit booked by somebody who has just spoken to the
		// client is a contact that happened.
		if ( 'new' === (string) $lead['status'] ) {
			Leads::update( $lead_id, array( 'status' => 'contacted' ) );
		}

		$result = Visits::schedule(
			array(
				'lead_id'      => $lead_id,
				'listing_id'   => $listing_id,
				'agent_id'     => $agent,
				'scheduled_at' => $when,
				'notes'        => $notes,
			)
		);

		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'capture-visit', 0, $result->get_error_message() );
		}

		Pocket::redirect( 'visit', (int) $result, 'visit_new' );
	}

	/**
	 * The three things worth knowing before setting off.
	 *
	 * Nothing is enforced here. An unticked box is a question the agent
	 * answers for themselves — the office only needs to see that they looked.
	 *
	 * @return void
	 */
	private static function visit_checks(): void {
		$visit_id = self::int_post( 'visit_id' );
		$visit    = Visits::get( $visit_id );
		if ( ! $visit ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( ! Pocket::is_office() && (int) $visit['agent_id'] !== Pocket::agent_id() ) {
			Pocket::fail_to_today( 'nope' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$posted = isset( $_POST['checks'] ) && is_array( $_POST['checks'] ) ? (array) wp_unslash( $_POST['checks'] ) : array();
		// phpcs:enable
		$allowed = array( 'owner', 'client', 'access' );
		$checks  = array();
		foreach ( $posted as $box ) {
			$box = sanitize_key( (string) $box );
			if ( in_array( $box, $allowed, true ) ) {
				$checks[] = $box;
			}
		}
		$checks = array_values( array_unique( $checks ) );

		$lead_id = (int) $visit['lead_id'];
		if ( $lead_id > 0 ) {
			LeadEvents::add( $lead_id, 'visit_checks', array( 'visit_id' => $visit_id, 'checks' => $checks ) );
		}
		AuditLog::record( 'visit.checked', 'visit', $visit_id, array( 'checks' => $checks ) );

		Pocket::redirect( 'visit', $visit_id, 'visit_prep' );
	}

	/**
	 * Close a visit: what happened, what the client thought, what comes next.
	 *
	 * Three questions in one place because that is how a visit ends — in a
	 * car, in one go, before the details go soft. Anything the agent says
	 * about the client's mind is a move on the client's own record, taken
	 * through Leads::update(), so the pipeline rules hold here exactly as
	 * they do in the office.
	 *
	 * @return void
	 */
	private static function visit_finish(): void {
		$visit_id = self::int_post( 'visit_id' );
		$visit    = Visits::get( $visit_id );
		if ( ! $visit ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( ! Pocket::is_office() && (int) $visit['agent_id'] !== Pocket::agent_id() ) {
			Pocket::fail_to_today( 'nope' );
		}

		$outcome  = self::choice_post( 'outcome', array( 'done', 'no_show', 'cancelled' ) );
		$interest = self::choice_post( 'interest', array( 'yes', 'thinking', 'no' ) );
		$reason   = self::choice_post( 'reason', array_keys( Vocabulary::lead_lost_reasons() ) );
		$next     = self::choice_post( 'next_step', array( 'call', 'send', 'second', 'go_ahead' ) );
		$notes    = Sanitize::textarea( self::text_post( 'notes' ) );

		if ( '' === $outcome ) {
			Pocket::fail( 'visit', $visit_id, __( 'Say whether the visit happened. Everything else follows from that.', 'estat-os' ) );
		}
		if ( 'done' === $outcome && '' === $interest ) {
			Pocket::fail( 'visit', $visit_id, __( 'Say what the client thought — even “still thinking” is worth writing down.', 'estat-os' ) );
		}
		if ( 'no' === $interest && '' === $reason ) {
			Pocket::fail( 'visit', $visit_id, __( 'When a client says no, the office needs the reason. Choose one.', 'estat-os' ) );
		}

		$result = Visits::update(
			$visit_id,
			array(
				'outcome' => $outcome,
				'notes'   => $notes,
			)
		);
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'visit', $visit_id, $result->get_error_message() );
		}

		$lead_id = (int) $visit['lead_id'];

		if ( $lead_id > 0 ) {
			if ( 'done' === $outcome && 'no' === $interest ) {
				Leads::update(
					$lead_id,
					array(
						'status'      => 'lost',
						'lost_reason' => $reason,
					)
				);
			} elseif ( 'done' === $outcome && 'go_ahead' === $next ) {
				Leads::update( $lead_id, array( 'status' => 'won' ) );
			}

			$steps = array(
				'call'     => array( 1, __( 'Call them tomorrow', 'estat-os' ) ),
				'send'     => array( 2, __( 'Send other properties', 'estat-os' ) ),
				'second'   => array( 3, __( 'Fix a second visit', 'estat-os' ) ),
				'go_ahead' => array( 1, __( 'Paperwork — they want to go ahead', 'estat-os' ) ),
			);
			if ( isset( $steps[ $next ] ) && 'done' === $outcome ) {
				$when = current_time( 'timestamp', true ) + ( (int) $steps[ $next ][0] * DAY_IN_SECONDS );
				Leads::update( $lead_id, array( 'followup_at' => gmdate( 'Y-m-d 10:00:00', $when ) ) );
				LeadEvents::add(
					$lead_id,
					'visit_next',
					array(
						'visit_id' => $visit_id,
						'next'     => $steps[ $next ][1],
					)
				);
			}

			// A completed visit is already on the timeline — Visits::update()
			// writes it. The other two endings are not, so they are written
			// here, each in its own words.
			if ( 'no_show' === $outcome ) {
				LeadEvents::add( $lead_id, 'visit_no_show', array( 'visit_id' => $visit_id ) );
			} elseif ( 'cancelled' === $outcome ) {
				LeadEvents::add( $lead_id, 'visit_cancelled', array( 'visit_id' => $visit_id ) );
			}
		}

		AuditLog::record(
			'visit.finished',
			'visit',
			$visit_id,
			array(
				'outcome'  => $outcome,
				'interest' => $interest,
				'reason'   => $reason,
				'next'     => $next,
			)
		);

		Pocket::redirect( 'visit', $visit_id, 'visit_done' );
	}

	/**
	 * The owner has just been spoken to. Write it down.
	 *
	 * What an agent may do here is deliberately narrow: record that the
	 * check happened, and — if the owner said something changed — ask the
	 * office to change it. Money and availability on a live page are the
	 * office's call, so they travel as a change request through the same
	 * path every other pocket change takes, and the owner check itself is
	 * recorded immediately because it is a fact about today, not a wish.
	 *
	 * @return void
	 */
	private static function owner_update(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post || PostTypes::LISTING !== $post->post_type || ! Pocket::can_see( $post ) ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( ! Pocket::is_office() && ! Pocket::owns( $record_id ) ) {
			// Somebody else's property: the owner check is not this phone's job.
			Pocket::fail_to_today( 'nope' );
		}

		$price_ok     = self::choice_post( 'price_ok', array( 'yes', 'no' ) );
		$new_price    = Sanitize::float( self::text_post( 'price' ) );
		$availability = self::choice_post( 'availability', array_keys( Vocabulary::availability() ) );
		$notes        = Sanitize::textarea( self::text_post( 'notes' ) );

		if ( '' === $price_ok ) {
			Pocket::fail( 'capture-owner', $record_id, __( 'Answer the first question — is the money still right?', 'estat-os' ) );
		}
		if ( 'no' === $price_ok && $new_price <= 0 ) {
			Pocket::fail( 'capture-owner', $record_id, __( 'Write the new number the owner gave you, so the office has something to approve.', 'estat-os' ) );
		}

		$offer   = (string) get_post_meta( $record_id, '_estat_offer', true );
		$is_rent = in_array( $offer, array( 'rent', 'lease' ), true );

		$changes = array();
		if ( 'no' === $price_ok && $new_price > 0 ) {
			$changes[ $is_rent ? 'rent' : 'price' ] = (string) $new_price;
		}
		$current = (string) get_post_meta( $record_id, '_estat_availability', true );
		if ( '' !== $availability && $availability !== $current ) {
			$changes['availability'] = $availability;
		}
		if ( '' !== $notes ) {
			$changes['note'] = $notes;
		}

		$requested = false;
		if ( array_diff_key( $changes, array( 'note' => true ) ) ) {
			$result = Requests::create(
				array(
					'record_id' => $record_id,
					'changes'   => $changes,
					'message'   => '' !== $notes ? $notes : __( 'Owner checked on the phone from the pocket app.', 'estat-os' ),
				)
			);
			if ( is_wp_error( $result ) ) {
				Pocket::fail( 'capture-owner', $record_id, $result->get_error_message() );
			}
			$requested = true;
		}

		// The check itself, in the record's own words: “Checked by agent”.
		// The office's own “Verified by office” is never overwritten, and
		// nobody can lift a record up the ladder from a phone.
		$verification = (string) get_post_meta( $record_id, '_estat_verification', true );
		if ( in_array( $verification, array( '', 'unverified' ), true ) ) {
			update_post_meta( $record_id, '_estat_verification', 'self_verified' );
		}
		update_post_meta( $record_id, '_estat_owner_checked_at', current_time( 'mysql', true ) );

		AuditLog::record(
			'listing.owner_checked',
			'listing',
			$record_id,
			array(
				'price_ok'     => $price_ok,
				'availability' => '' !== $availability ? $availability : $current,
				'asked_office' => $requested ? implode( ', ', array_keys( $changes ) ) : '',
			)
		);

		Pocket::redirect( 'listing', $record_id, $requested ? 'requested' : 'owner_ok' );
	}

	/**
	 * Where to bounce back to after the action; set by the dispatcher.
	 *
	 * @var string
	 */
	private static string $view = '';

	/**
	 * The record the posted form was about; set by the dispatcher.
	 *
	 * @var int
	 */
	private static int $id = 0;

	/**
	 * A safe back-view for the current flow.
	 *
	 * @param string $fallback View slug when the action was not on a record.
	 * @return string
	 */
	private static function back( string $fallback = 'listings' ): string {
		return self::$id > 0 && '' === self::$view ? 'listing' : ( '' !== self::$view ? self::$view : $fallback );
	}

	/**
	 * One int from POST.
	 *
	 * @param string $key Field name.
	 * @return int
	 */
	private static function int_post( string $key ): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? absint( wp_unslash( is_array($_POST[ $key ]) ? '' : $_POST[ $key ] ) ) : 0;
	}

	/* ---------------------------------------------------------------------
	 * You: the agent's own details and password
	 * ------------------------------------------------------------------ */

	/**
	 * Save the agent's own name and numbers.
	 *
	 * When the office has linked this login to a team member, the details go
	 * on that team record — the same one the office edits and the website
	 * shows. When it has not, they stay with the login, so nothing is lost
	 * while the office gets round to it.
	 *
	 * @return void
	 */
	private static function save_you(): void {
		if ( ! Pocket::can_use() ) {
			Pocket::fail_to_today( 'nope' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$name     = isset( $_POST['name'] ) ? Sanitize::title( wp_unslash( (string) ( is_array( $_POST['name'] ) ? '' : $_POST['name'] ) ) ) : '';
		$phone    = isset( $_POST['phone'] ) ? Sanitize::phone( wp_unslash( (string) ( is_array( $_POST['phone'] ) ? '' : $_POST['phone'] ) ) ) : '';
		$whatsapp = isset( $_POST['whatsapp'] ) ? Sanitize::phone( wp_unslash( (string) ( is_array( $_POST['whatsapp'] ) ? '' : $_POST['whatsapp'] ) ) ) : '';
		$email    = isset( $_POST['email'] ) ? Sanitize::email( wp_unslash( (string) ( is_array( $_POST['email'] ) ? '' : $_POST['email'] ) ) ) : '';
		$raw_mail = isset( $_POST['email'] ) ? trim( wp_unslash( (string) ( is_array( $_POST['email'] ) ? '' : $_POST['email'] ) ) ) : '';
		// phpcs:enable

		if ( '' === $name ) {
			Pocket::fail( 'you', 0, __( 'A name is needed — it is the one line the office cannot fill in for you.', 'estat-os' ) );
		}
		if ( '' !== $raw_mail && '' === $email ) {
			Pocket::fail( 'you', 0, __( 'That email address does not look right. Example: name@example.com', 'estat-os' ) );
		}

		$user_id  = get_current_user_id();
		$agent_id = Pocket::agent_id();

		if ( $agent_id > 0 ) {
			$result = Agents::save(
				array(
					'title'    => $name,
					'phone'    => $phone,
					'whatsapp' => $whatsapp,
					'email'    => $email,
				),
				$agent_id
			);
			if ( is_wp_error( $result ) ) {
				Pocket::fail( 'you', 0, self::first_message( $result ) );
			}
		} else {
			update_user_meta(
				$user_id,
				'_estat_pocket_contact',
				array( 'name' => $name, 'phone' => $phone, 'whatsapp' => $whatsapp, 'email' => $email )
			);
		}

		// The name on screen follows the name they typed.
		if ( '' !== $name ) {
			wp_update_user( array( 'ID' => $user_id, 'display_name' => $name ) );
		}

		AuditLog::record( 'pocket.you_saved', 'agent', $agent_id > 0 ? $agent_id : $user_id, array( 'linked' => $agent_id > 0 ) );
		Pocket::redirect( 'you', 0, 'you_saved' );
	}

	/**
	 * Change the agent's own password.
	 *
	 * A wrong password is the one thing support cannot fix over the phone, and
	 * an agent locked out of their own account on a Saturday is a real cost.
	 * So: their own password, their own change, with the two checks that
	 * matter (long enough, typed the same twice).
	 *
	 * @return void
	 */
	private static function save_password(): void {
		if ( ! Pocket::can_use() ) {
			Pocket::fail_to_today( 'nope' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$new   = isset( $_POST['new_password'] ) ? (string) wp_unslash( is_array( $_POST['new_password'] ) ? '' : $_POST['new_password'] ) : '';
		$again = isset( $_POST['again_password'] ) ? (string) wp_unslash( is_array( $_POST['again_password'] ) ? '' : $_POST['again_password'] ) : '';
		// phpcs:enable

		if ( strlen( $new ) < 8 ) {
			Pocket::fail( 'you', 0, __( 'A password needs at least 8 letters or numbers.', 'estat-os' ) );
		}
		if ( $new !== $again ) {
			Pocket::fail( 'you', 0, __( 'The two passwords do not match. Type the same one twice.', 'estat-os' ) );
		}

		$user_id = get_current_user_id();
		$result  = wp_update_user( array( 'ID' => $user_id, 'user_pass' => $new ) );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'you', 0, self::first_message( $result ) );
		}

		// Everywhere else signs out; this phone stays signed in, because the
		// person doing this is holding it.
		if ( function_exists( 'wp_destroy_other_sessions' ) ) {
			wp_destroy_other_sessions();
		}

		AuditLog::record( 'pocket.password_changed', 'user', $user_id, array() );
		Pocket::redirect( 'you', 0, 'pass_changed' );
	}

	/**
	 * The plain sentence out of a WP_Error.
	 *
	 * @param \WP_Error $error Error.
	 * @return string
	 */
	private static function first_message( \WP_Error $error ): string {
		$messages = $error->get_error_messages();
		return $messages ? (string) $messages[0] : __( 'That did not save. Please try again.', 'estat-os' );
	}

	/* ---------------------------------------------------------------------
	 * Listings: draft, propose, request, visibility, removal
	 * ------------------------------------------------------------------ */

	/**
	 * Create or re-save an agent draft, then optionally walk it into the
	 * office's queue. Photos are handled here, not in a separate tab —
	 * whoever photographed the flat on the way out is the person who should
	 * be able to finish the listing in the same five minutes.
	 *
	 * @return void
	 */
	private static function save_draft(): void {
		$record_id = self::int_post( 'record_id' );

		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$post = $record_id > 0 ? get_post( $record_id ) : null;
		if ( $record_id > 0 && ( ! $post || ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) ) {
			Pocket::fail_to_today( 'gone' );
		}
		// The wizard on the phone saves property fields. A society is not a
		// property: refuse it at the door, whatever the screen did.
		if ( $post && PostTypes::PROJECT === $post->post_type ) {
			Pocket::fail( 'listing', $record_id, __( 'Societies and projects are edited on the office screens.', 'estat-os' ) );
		}
		if ( $post && ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail( self::back(), $record_id, __( 'That listing belongs to someone else. From the phone, you can ask the office to change it.', 'estat-os' ) );
		}
		$may_publish = current_user_can( 'estat_publish_listings' )
			|| (bool) \EstatOS\Settings\Settings::get( 'pocket_agents_edit_live', false );
		if ( $post && ! in_array( $post->post_status, array( 'draft', 'pending' ), true ) && ! $may_publish ) {
			// Live records move only through a request. This is the phone's
			// rule, and the pocket enforces it at the door instead of hoping
			// the screen hid the right buttons. The exception is the office
			// itself: somebody with publishing rights is allowed to correct a
			// live listing from the same screen the agent submitted it from.
			Pocket::fail( self::back(), $record_id, __( 'That listing is out of draft, so it has to go through the office queue.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		/*
		 * Every question the form asked, saved in one go.
		 *
		 * The list comes from Steps — the same list the screen renders and
		 * the parity test counts — so a box that appears on the phone can
		 * never be one the office has to fill in afterwards. The office-only
		 * step is read only when the person holding the phone may see it,
		 * so an agent's save cannot quietly wipe a colleague's answer.
		 */
		$names = Steps::names( Pocket::is_office() );
		$input = array( 'status' => 'draft' );

		$posted_status = isset( $_POST['estat_pocket_status'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_pocket_status']) ? '' : $_POST['estat_pocket_status'] ) ) ) : 'draft';
		$input['status'] = in_array( $posted_status, array( 'draft', 'pending' ), true ) ? $posted_status : 'draft';

		foreach ( $names as $name ) {
			$definition = Steps::field( $name, true );
			$is_checked = $definition && 'checkbox' === ( $definition['input'] ?? '' );

			if ( ! isset( $_POST[ $name ] ) ) {
				if ( $is_checked ) {
					$input[ $name ] = '0'; // An unticked box means no, not "leave it".
				}
				continue;
			}

			$raw = wp_unslash( $_POST[ $name ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by Meta/Sanitize inside Listings::save().
			if ( is_array( $raw ) ) {
				continue;
			}
			$input[ $name ] = (string) $raw;
		}
		$next = isset( $_POST['estat_pocket_next'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_pocket_next']) ? '' : $_POST['estat_pocket_next'] ) ) ) : 'draft';

		/*
		 * The phone's own name for this piece of work.
		 *
		 * In the field a save can be tried twice: the network drops, the
		 * phone keeps the form, and the same form goes up again when the
		 * bars come back. Without this, a listing that had already been
		 * created would be created a second time. The name travels with
		 * the form, is kept on the record, and a second arrival of the
		 * same name simply carries on with the same record.
		 */
		$client_id = isset( $_POST['estat_client_id'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['estat_client_id']) ? '' : $_POST['estat_client_id'] ) ) ) : '';
		$client_id = substr( $client_id, 0, 64 );
		// phpcs:enable

		if ( 0 === $record_id && '' !== $client_id ) {
			$already = get_posts(
				array(
					'post_type'      => PostTypes::LISTING,
					'post_status'    => array( 'draft', 'pending', 'publish', 'private' ),
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'author'         => get_current_user_id(),
					'meta_key'       => '_estat_client_id', // phpcs:ignore WordPress.DB.SlowDBQuery -- one lookup, by a name we generated.
					'meta_value'     => $client_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				)
			);
			if ( $already ) {
				$record_id = (int) $already[0];
			}
		}

		$result = Listings::save( $input, $record_id );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'new', $record_id, (string) $result->get_error_message() );
		}
		$listening = (int) $result;

		$photos = self::collect_photos( $listening );
		$voices = self::collect_voice( $listening );

		// The same note, written instead of spoken — for a phone that will
		// not lend its microphone, or a room too loud to talk in.
		if ( isset( $_POST['_estat_voice_text'] ) && ! is_array( $_POST['_estat_voice_text'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified at the door.
			$written = Sanitize::textarea( (string) wp_unslash( $_POST['_estat_voice_text'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised on this line.
			if ( '' !== $written ) {
				update_post_meta( $listening, '_estat_voice_text', $written );
			} else {
				// Cleared on purpose: the box was shown, and left empty.
				delete_post_meta( $listening, '_estat_voice_text' );
			}
		}

		// A brand-new listing belongs to the person who typed it; assign it
		// here because Listings::save only takes what the admin form passes,
		// and the pocket knows who is holding the phone.
		if ( '' !== $client_id ) {
			update_post_meta( $listening, '_estat_client_id', $client_id );
		}

		if ( 0 === $record_id ) {
			update_post_meta( $listening, '_estat_assigned_user', get_current_user_id() );
			$agent = Pocket::agent_id();
			if ( $agent > 0 ) {
				update_post_meta( $listening, '_estat_agent_id', $agent );
			}
		}

		if ( 'send' === $next ) {
			$too_thin = self::readiness_refusal( $listening );
			if ( '' !== $too_thin ) {
				Pocket::fail( self::back(), $listening, $too_thin );
			}
			self::move_status( $listening, 'pending', 'listing.submitted', __( 'Sent for approval from the pocket.', 'estat-os' ) );
			Pocket::redirect( 'listing', $listening, 'sent' );
		}

		// The answer names what actually arrived, in the order the office
		// cares about: pictures first, then the words spoken over them.
		if ( $photos > 0 ) {
			Pocket::redirect( 'listing', $listening, $voices > 0 ? 'voice' : 'photos' );
		}
		Pocket::redirect( 'listing', $listening, $voices > 0 ? 'voice' : 'saved' );
	}

	/**
	 * Can this draft go to the office yet?
	 *
	 * The office sets the bar under Settings → Staff app. The point is not to
	 * make life hard for the person on the phone: a property that arrives
	 * with no price and no description is one the office has to telephone
	 * about, which costs more than the two minutes it takes to fill it in.
	 *
	 * Only staff are held to the bar. The office can send whatever it likes.
	 *
	 * @param int $record_id Listing ID.
	 * @return string A plain sentence when the send must stop, '' to allow it.
	 */
	private static function readiness_refusal( int $record_id ): string {
		if ( Pocket::is_office() ) {
			return '';
		}
		$threshold = (int) \EstatOS\Settings\Settings::get( 'completeness_threshold', 70 );
		if ( $threshold <= 0 ) {
			return '';
		}
		$score = (int) get_post_meta( $record_id, '_estat_completeness', true );
		if ( $score >= $threshold ) {
			return '';
		}
		return sprintf(
			/* translators: %1$d: the office's readiness bar, %2$d: what this property scores now. */
			__( 'The office asks for at least %1$d out of 100 before a property is sent. This one is at %2$d — add a price, a description and a few photos and it will pass.', 'estat-os' ),
			$threshold,
			$score
		);
	}

	/**
	 * Save from the detail page: same draft rules, fewer fields to change.
	 * (Kept separate so the "send" button on a detail row can never create
	 * a half-listing.)
	 *
	 * @return void
	 */
	private static function propose(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || ! ( 'draft' === $post->post_status && ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) ) {
			Pocket::fail( 'listing', $record_id, __( 'Only your own drafts can be sent from here.', 'estat-os' ) );
		}
		if ( '' === trim( (string) $post->post_title ) ) {
			Pocket::fail( 'listing', $record_id, __( 'A title is the one thing a listing cannot be sent without.', 'estat-os' ) );
		}
		$too_thin = self::readiness_refusal( $record_id );
		if ( '' !== $too_thin ) {
			Pocket::fail( 'listing', $record_id, $too_thin );
		}
		self::move_status( $record_id, 'pending', 'listing.submitted', __( 'Sent for approval from the pocket.', 'estat-os' ) );
		Pocket::redirect( 'listing', $record_id, 'sent' );
	}

	/**
	 * File a change request. The same five inputs the office reviews on
	 * their screen, because the same class writes the row.
	 *
	 * @return void
	 */
	private static function request_change(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || ! Pocket::can_see( $post ) ) {
			Pocket::fail_to_today( 'gone' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		// Each box the agent filled arrives under its own name
		// (changes[price], changes[bedrooms]…), so this is a list by design.
		$changes = isset( $_POST['changes'] ) && is_array( $_POST['changes'] ) ? (array) wp_unslash( $_POST['changes'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Requests::clean_changes() saaf karta hai.
		$message = isset( $_POST['message'] ) ? Sanitize::textarea( wp_unslash( (string) ( is_array($_POST['message']) ? '' : $_POST['message'] ) ) ) : '';
		// phpcs:enable

		if ( '' === $message ) {
			Pocket::fail( 'change', $record_id, __( 'Add one line about how you know, so the office can decide without calling you.', 'estat-os' ) );
		}

		$changes['note'] = $message;

		$result = Requests::create(
			array(
				'record_id' => $record_id,
				'changes'   => $changes,
				'message'   => $message,
			)
		);
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'change', $record_id, $result->get_error_message() );
		}

		Pocket::redirect( 'listing', $record_id, 'requested' );
	}

	/**
	 * Pause and resume. Both are allowed straight from a phone because they
	 * only ever take the website down, never put anything up — the direction
	 * of travel is the safety argument, and it is written here so the next
	 * person who "improves" this file reads it first.
	 *
	 * @param string $status Target post_status.
	 * @return void
	 */
	private static function visibility( string $status ): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post || ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$from = 'private' === $status ? 'publish' : 'private';
		if ( $post->post_status !== $from ) {
			Pocket::fail( 'listing', $record_id, __( 'That listing is not in a state this button can act on. Refresh the page.', 'estat-os' ) );
		}

		self::move_status(
			$record_id,
			$status,
			'private' === $status ? 'listing.paused' : 'listing.resumed',
			'private' === $status ? __( 'Paused from the pocket.', 'estat-os' ) : __( 'Put back live from the pocket.', 'estat-os' )
		);

		Pocket::redirect( 'listing', $record_id, 'private' === $status ? 'paused' : 'resumed' );
	}

	/**
	 * Delete a property from the phone, and say plainly what delete means.
	 *
	 * "Delete" here is the office's own word for what this does: the property
	 * leaves the website and its details wait in the bin, where the office can
	 * put it back. Nothing is destroyed from a phone — that button lives on the
	 * office screen, behind typing DELETE, and it stays there.
	 *
	 * A live property may be binned by the person who looks after it, because
	 * a wrong page up for a week costs more than a click that is easily undone.
	 * Everybody else's records, and anybody without delete rights, are refused
	 * at the door — the same rule the office screen uses.
	 *
	 * @return void
	 */
	private static function remove_draft(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post ) {
			Pocket::fail_to_today( 'gone' );
		}
		if ( ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail( 'listing', $record_id, __( 'That is not your property to remove.', 'estat-os' ) );
		}
		if ( ! Bin::may_move( $post ) ) {
			Pocket::fail( 'listing', $record_id, __( 'Your account cannot move this one to the bin. The office can.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the nonce was checked in run().
		$confirm = isset( $_POST['estat_pocket_confirm'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_POST['estat_pocket_confirm'] ) ? '' : $_POST['estat_pocket_confirm'] ) ) ) : '';
		// phpcs:enable
		if ( 'bin' !== $confirm ) {
			Pocket::fail( 'listing', $record_id, __( 'Nothing was removed. Press Remove again and answer yes to the question.', 'estat-os' ) );
		}

		// One lifecycle for the whole plugin: the phone, the office list and
		// the WordPress post list all move a record to the bin through
		// Data\Bin, so "who moved it, when, and from what state" is answered
		// the same way whichever door was used.
		$moved = Bin::move( $record_id, 'moved from the phone' );
		if ( is_wp_error( $moved ) ) {
			Pocket::fail( 'listing', $record_id, $moved->get_error_message() );
		}

		Pocket::redirect( 'listings', 0, 'trashed' );
	}

	/**
	 * Put a binned property back where it belongs.
	 *
	 * The bin is only useful if the way out of it is as easy as the way in.
	 * A record that was live before it was binned goes back on the website;
	 * a draft goes back to being a draft.
	 *
	 * @return void
	 */
	private static function restore_listing(): void {
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );

		if ( ! $post || 'trash' !== $post->post_status ) {
			Pocket::fail( 'listings', 0, __( 'That one is not in the bin.', 'estat-os' ) );
		}
		if ( ! ( Pocket::owns( $record_id ) || Pocket::is_office() ) ) {
			Pocket::fail( 'listings', 0, __( 'That is not your property.', 'estat-os' ) );
		}

		// Back to the state it was in — Live comes back Live. Somebody who
		// may not put things on the website gets it back as Waiting for
		// approval, which Data\Bin decides so every door behaves the same.
		$back = Bin::restore( $record_id );
		if ( is_wp_error( $back ) ) {
			Pocket::fail( 'listings', 0, $back->get_error_message() );
		}

		Pocket::redirect( 'listing', $record_id, 'restored' );
	}

	/* ---------------------------------------------------------------------
	 * Enquiries
	 * ------------------------------------------------------------------ */

	/**
	 * Book the visit the agent just agreed on the phone call.
	 *
	 * @return void
	 */
	private static function log_visit(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::must_see_lead( $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$lead = Leads::get( $lead_id );
		// phpcs:enable

		$result = Visits::schedule(
			array(
				'lead_id'      => $lead_id,
				'listing_id'   => $lead ? (int) $lead['listing_id'] : 0,
				'agent_id'     => Pocket::agent_id(),
				'scheduled_at' => isset( $_POST['scheduled_at'] ) ? Sanitize::text( wp_unslash( (string) ( is_array($_POST['scheduled_at']) ? '' : $_POST['scheduled_at'] ) ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			)
		);

		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'enquiry', $lead_id, $result->get_error_message() );
		}

		Pocket::redirect( 'enquiry', $lead_id, 'visit' );
	}

	/**
	 * Move a lead's status and add a note, together, because the office
	 * reads notes with statuses in mind.
	 *
	 * @return void
	 */
	private static function lead_update(): void {
		$lead_id = self::int_post( 'lead_id' );
		self::must_see_lead( $lead_id );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['status']) ? '' : $_POST['status'] ) ) ) : '';
		$notes  = isset( $_POST['notes'] ) ? wp_unslash( (string) ( is_array($_POST['notes']) ? '' : $_POST['notes'] ) ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$intent = isset( $_POST['intent'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['intent']) ? '' : $_POST['intent'] ) ) ) : '';
		$lost_reason = isset( $_POST['lost_reason'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_POST['lost_reason']) ? '' : $_POST['lost_reason'] ) ) ) : '';
		$followup_at = isset( $_POST['followup_at'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_POST['followup_at']) ? '' : $_POST['followup_at'] ) ) ) : '';
		// phpcs:enable

		$allowed = array_keys( Vocabulary::lead_statuses_all() );
		$input   = array();
		if ( in_array( $status, $allowed, true ) ) {
			$input['status'] = $status;
		}
		if ( is_string( $notes ) ) {
			$input['notes'] = $notes;
		}
		if ( '' !== $intent && in_array( $intent, array_keys( Vocabulary::lead_intents() ), true ) ) {
			$input['intent'] = $intent;
		}
		if ( '' !== $lost_reason && in_array( $lost_reason, array_keys( Vocabulary::lead_lost_reasons() ), true ) ) {
			$input['lost_reason'] = $lost_reason;
		}
		if ( '' !== $followup_at ) {
			$input['followup_at'] = $followup_at;
		}
		if ( ! $input ) {
			Pocket::fail( 'enquiry', $lead_id, __( 'Nothing to save there.', 'estat-os' ) );
		}

		$result = Leads::update( $lead_id, $input );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'enquiry', $lead_id, $result->get_error_message() );
		}

		Pocket::redirect( 'enquiry', $lead_id, 'note' );
	}

	/**
	 * Leads are personal data; the pocket shares them exactly the way the
	 * office's screens do — mine, or all of them for the office.
	 *
	 * @param int $lead_id Lead row ID.
	 * @return void
	 */
	private static function must_see_lead( int $lead_id ): void {
		$lead = $lead_id > 0 ? Leads::get( $lead_id ) : null;
		if ( ! $lead ) {
			Pocket::fail_to_today( 'gone' );
		}
		$agent_id = Pocket::agent_id();
		$ok = Pocket::is_office()
			|| (int) $lead['agent_id'] === $agent_id
			|| ( ! empty( $lead['assigned_agent_id'] ) && (int) $lead['assigned_agent_id'] === $agent_id )
			|| ( ! empty( $lead['listing_id'] ) && Pocket::owns( (int) $lead['listing_id'] ) );
		if ( ! $ok ) {
			Pocket::fail_to_today( 'nope' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Office side
	 * ------------------------------------------------------------------ */

	/**
	 * Approve or turn down a change request — through the same
	 * Requests::approve() the admin screen uses, so applying a change from a
	 * phone writes the audit row, the undo snapshot and the index update.
	 *
	 * @param string $verb approve|decline.
	 * @return void
	 */
	private static function settle_request( string $verb ): void {
		if ( ! Pocket::is_office() ) {
			Pocket::fail_to_today( 'nope' );
		}
		$request_id = self::int_post( 'request_id' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason = isset( $_POST['reason'] ) ? Sanitize::textarea( wp_unslash( (string) ( is_array($_POST['reason']) ? '' : $_POST['reason'] ) ) ) : '';
		// phpcs:enable

		$result = 'approve' === $verb ? Requests::approve( $request_id ) : Requests::decline( $request_id, $reason );
		if ( is_wp_error( $result ) ) {
			Pocket::fail( 'approvals', 0, $result->get_error_message() );
		}
		Pocket::redirect( 'approvals', 0, 'approve' === $verb ? 'approved' : 'declined' );
	}

	/**
	 * Publish or return a proposed listing. Publish needs the same
	 * capability the admin screen asks for; there is no phone version of
	 * that permission, deliberately.
	 *
	 * @param string $status publish|draft.
	 * @return void
	 */
	private static function settle_proposal( string $status ): void {
		if ( ! current_user_can( 'estat_publish_listings' ) && ! current_user_can( 'estat_manage_settings' ) ) {
			Pocket::fail_to_today( 'nope' );
		}
		$record_id = self::int_post( 'record_id' );
		$post      = get_post( $record_id );
		if ( ! $post || 'pending' !== $post->post_status ) {
			Pocket::fail( 'approvals', 0, __( 'That proposal is not waiting any more. Refresh the list.', 'estat-os' ) );
		}

		self::move_status(
			$record_id,
			$status,
			'publish' === $status ? 'listing.published' : 'listing.returned',
			'publish' === $status ? __( 'Approved and published from the pocket.', 'estat-os' ) : __( 'Sent back to the agent as a draft, from the pocket.', 'estat-os' )
		);

		Pocket::redirect( 'approvals', 0, 'publish' === $status ? 'listed' : 'listed_back' );
	}

	/* ---------------------------------------------------------------------
	 * Shared moves
	 * ------------------------------------------------------------------ */

	/**
	 * One status move, one audit line, the saving class doing the writing.
	 *
	 * @param int    $record_id Post ID.
	 * @param string $status    Target post_status.
	 * @param string $action    Audit action word.
	 * @param string $note      Short human sentence for the audit row.
	 * @return void
	 */
	private static function move_status( int $record_id, string $status, string $action, string $note ): void {
		$post = get_post( $record_id );
		if ( ! $post ) {
			return;
		}
		wp_update_post(
			array(
				'ID'          => $record_id,
				'post_status' => $status,
			)
		);
		AuditLog::record( $action, $post->post_type, $record_id, array( 'channel' => 'pocket', 'note' => $note ) );

		// The office asked to hear about this one thing by email: a property
		// that has come in and is waiting for a yes or a no.
		if ( 'pending' === $status && PostTypes::LISTING === $post->post_type ) {
			do_action( 'estat_listing_needs_approval', $record_id );
		}
	}

	/**
	 * A voice note recorded on the phone, and the cross that takes one out.
	 *
	 * Kept apart from the photographs because it is a different kind of
	 * thing: an audio file the agent spoke, not a picture. Everything else
	 * is the same — it lands in the media library, attached to the record,
	 * and its id is kept in a list, so five notes can live on one property.
	 *
	 * @param int $listing_id Listing being saved.
	 * @return int How many notes arrived.
	 */
	private static function collect_voice( int $listing_id ): int {
		$added = self::upload_voice( $listing_id, '_estat_voice_notes', 'estat_pocket_voice' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$take_out = isset( $_POST['estat_pocket_remove_voice'] ) ? absint( wp_unslash( is_array( $_POST['estat_pocket_remove_voice'] ) ? '' : $_POST['estat_pocket_remove_voice'] ) ) : 0;
		// phpcs:enable

		if ( $take_out > 0 ) {
			$ids = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, '_estat_voice_notes', true ) ) ) );
			if ( in_array( $take_out, $ids, true ) ) {
				$ids = array_values( array_diff( $ids, array( $take_out ) ) );
				if ( $ids ) {
					update_post_meta( $listing_id, '_estat_voice_notes', $ids );
				} else {
					delete_post_meta( $listing_id, '_estat_voice_notes' );
				}
			}
		}

		return $added;
	}

	/**
	 * One voice file, into the record's list of notes.
	 *
	 * This does the saving itself instead of handing the file to WordPress's
	 * uploader, and here is why: a phone writes sound into an mp4 or a webm
	 * box, and WordPress's own guesser reads both of those as *film* —
	 * “Sorry, you are not allowed to upload this file type.” It is the same
	 * file either way; only the guess is wrong. So the first bytes are read
	 * here, the three shapes a phone actually records are recognised by
	 * name, and the file goes into the media library exactly like a
	 * photograph does. Anything that is not one of those three shapes is
	 * refused.
	 *
	 * @param int    $listing_id Listing being saved.
	 * @param string $meta_key   Meta key that holds the list.
	 * @param string $field      The input name the file arrived under.
	 * @return int
	 */
	private static function upload_voice( int $listing_id, string $meta_key, string $field ): int {
		$file = isset( $_FILES[ $field ] ) && is_array( $_FILES[ $field ] ) ? $_FILES[ $field ] : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verified.
		if ( ! $file || ! isset( $file['name'] ) || is_array( $file['name'] ) ) {
			return 0;
		}
		if ( 0 !== (int) ( $file['error'] ?? 1 ) || (int) ( $file['size'] ?? 0 ) <= 0 || (int) $file['size'] > 12 * 1024 * 1024 ) {
			return 0; // A voice note is a minute or two, not a recording session.
		}

		$tmp = (string) ( $file['tmp_name'] ?? '' );
		if ( '' === $tmp || ! is_uploaded_file( $tmp ) ) {
			return 0;
		}

		$head = (string) file_get_contents( $tmp, false, null, 0, 16 ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- a local temp file, not a remote request.
		$ext  = '';

		if ( 0 === strpos( $head, 'OggS' ) ) {
			$ext = 'ogg';
		} elseif ( "\x1a\x45\xdf\xa3" === substr( $head, 0, 4 ) ) {
			$ext = 'webm';
		} elseif ( 'ftyp' === substr( $head, 4, 4 ) ) {
			$ext = 'm4a';
		}

		if ( '' === $ext ) {
			return 0; // Not a shape a phone records.
		}

		$mime = array( 'ogg' => 'audio/ogg', 'webm' => 'audio/webm', 'm4a' => 'audio/mp4' );

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$allow = static function ( array $mimes ): array {
			$mimes['webm'] = 'audio/webm';
			$mimes['m4a']  = 'audio/mp4';
			$mimes['ogg']  = 'audio/ogg';

			return $mimes;
		};
		add_filter( 'upload_mimes', $allow, 99 );
		$bytes = (string) file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- the temp file of this very request.
		$up    = wp_upload_bits( 'voice-note-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 4, false, false ) . '.' . $ext, null, $bytes );
		remove_filter( 'upload_mimes', $allow, 99 );

		if ( ! empty( $up['error'] ) || empty( $up['file'] ) ) {
			return 0;
		}

		$attachment = wp_insert_attachment(
			array(
				'post_mime_type' => $mime[ $ext ],
				'post_title'     => __( 'Voice note from the phone', 'estat-os' ),
				'post_content'   => '',
				'post_status'    => 'inherit',
			),
			(string) $up['file'],
			$listing_id
		);

		if ( is_wp_error( $attachment ) || ! $attachment ) {
			return 0;
		}

		wp_update_attachment_metadata( (int) $attachment, wp_generate_attachment_metadata( (int) $attachment, (string) $up['file'] ) );

		$list = array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, $meta_key, true ) ) );
		$list = array_slice( array_merge( $list, array( (int) $attachment ) ), -5 );
		update_post_meta( $listing_id, $meta_key, array_values( $list ) );

		return 1;
	}

	/**
	 * Take in every photo box the form offered, then the star and the cross.
	 *
	 * Three lists arrive on one save — the photographs, the floor plans and
	 * the papers — and each is simply a list of attachment ids in post meta.
	 * The cover is not a separate thing to keep in step: it is the first
	 * photograph in the gallery, and starring one moves it there. That is
	 * why "make this the main photo" needs no new field anywhere.
	 *
	 * @param int $listing_id Listing being saved.
	 * @return int How many new files arrived.
	 */
	private static function collect_photos( int $listing_id ): int {
		$added = 0;

		foreach ( array( '_estat_gallery' => 'estat_pocket_photos', '_estat_floor_plans' => 'estat_pocket_floor_plans', '_estat_brochures' => 'estat_pocket_brochures' ) as $meta_key => $field ) {
			$added += self::upload_into( $listing_id, $meta_key, $field );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cover    = isset( $_POST['estat_pocket_cover'] ) ? absint( wp_unslash( is_array( $_POST['estat_pocket_cover'] ) ? '' : $_POST['estat_pocket_cover'] ) ) : 0;
		$take_out = isset( $_POST['estat_pocket_remove'] ) ? absint( wp_unslash( is_array( $_POST['estat_pocket_remove'] ) ? '' : $_POST['estat_pocket_remove'] ) ) : 0;
		// phpcs:enable

		if ( $take_out > 0 ) {
			foreach ( array( '_estat_gallery', '_estat_floor_plans', '_estat_brochures' ) as $meta_key ) {
				$ids = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, $meta_key, true ) ) ) );
				if ( ! in_array( $take_out, $ids, true ) ) {
					continue;
				}
				$ids = array_values( array_diff( $ids, array( $take_out ) ) );
				if ( $ids ) {
					update_post_meta( $listing_id, $meta_key, $ids );
				} else {
					delete_post_meta( $listing_id, $meta_key );
				}
				if ( '_estat_gallery' === $meta_key && (int) get_post_thumbnail_id( $listing_id ) === $take_out ) {
					// The main photo just left, so the next one steps up.
					if ( $ids ) {
						Listings::set_cover( $listing_id, (int) $ids[0] );
					} else {
						delete_post_meta( $listing_id, '_thumbnail_id' );
					}
				}
			}
		}

		if ( $cover > 0 ) {
			$ids = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, '_estat_gallery', true ) ) ) );
			if ( in_array( $cover, $ids, true ) ) {
				// Move it to the front of the list and make it the cover, so
				// the order in the office editor and on the website agree.
				$ids = array_values( array_diff( $ids, array( $cover ) ) );
				array_unshift( $ids, $cover );
				update_post_meta( $listing_id, '_estat_gallery', $ids );
				Listings::set_cover( $listing_id, $cover );
			}
		}

		return $added;
	}

	/**
	 * One photo box: every file it carried, into one list.
	 *
	 * @param int    $listing_id Listing being saved.
	 * @param string $meta_key   Meta key that holds the list.
	 * @param string $field      The input name the files arrived under.
	 * @return int Count of files stored.
	 */
	private static function upload_into( int $listing_id, string $meta_key, string $field ): int {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ]['name'] ) ) {
			return 0;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$files = $_FILES[ $field ]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- re-indexed by shape below, each piece validated.
		$added = array();

		foreach ( array_keys( (array) $files['name'] ) as $i ) {
			if ( 0 !== (int) $files['error'][ $i ] || '' === (string) $files['name'][ $i ] ) {
				continue;
			}
			if ( 0 !== strpos( (string) $files['type'][ $i ], 'image/' ) || (int) $files['size'][ $i ] > 8 * 1024 * 1024 ) {
				continue; // Images under eight megabytes; anything else is not a photo.
			}

			$_FILES['estat_pocket_one'] = array(
				'name'     => (string) $files['name'][ $i ],
				'type'     => (string) $files['type'][ $i ],
				'tmp_name' => (string) $files['tmp_name'][ $i ],
				'error'    => (int) $files['error'][ $i ],
				'size'     => (int) $files['size'][ $i ],
			);
			$attachment = media_handle_upload( 'estat_pocket_one', $listing_id );
			unset( $_FILES['estat_pocket_one'] );

			if ( ! is_wp_error( $attachment ) ) {
				$added[] = (int) $attachment;
			}
		}

		if ( ! $added ) {
			return 0;
		}

		$list = array_filter( array_map( 'intval', (array) get_post_meta( $listing_id, $meta_key, true ) ) );
		$list = array_slice( array_merge( $list, $added ), 0, 40 );
		update_post_meta( $listing_id, $meta_key, array_values( $list ) );

		if ( '_estat_gallery' === $meta_key && ! has_post_thumbnail( $listing_id ) ) {
			Listings::set_cover( $listing_id, (int) $added[0] );
		}

		return count( $added );
	}
}
