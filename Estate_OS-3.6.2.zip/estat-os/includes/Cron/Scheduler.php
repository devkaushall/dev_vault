<?php
/**
 * Scheduled housekeeping. Every job is safe to run twice.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Cron;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\PostTypes;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Notifications\Notifier;
use EstatOS\Install\Schema;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Housekeeping never deletes a business record. Expired listings are moved to
 * draft, old enquiries are anonymised, and the index is repaired, not rebuilt
 * destructively.
 */
final class Scheduler {

	/**
	 * Daily job hook.
	 */
	public const DAILY = 'estat_daily_maintenance';

	/**
	 * The morning summary, a little after eight.
	 */
	public const SUMMARY = 'estat_daily_summary';

	/**
	 * The weekly report, Monday morning.
	 */
	public const WEEKLY = 'estat_weekly_report';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( self::DAILY, array( __CLASS__, 'run_daily' ) );
		add_action( self::SUMMARY, array( __CLASS__, 'run_summary' ) );
		add_action( self::WEEKLY, array( __CLASS__, 'run_weekly' ) );
	}

	/**
	 * Schedule jobs idempotently.
	 *
	 * @return void
	 */
	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::DAILY ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::DAILY );
		}
		// The two emails the office asked for are also the two things that
		// need a clock: a summary it reads with its morning tea, and a report
		// it reads on Monday. Both are pinned to a real hour, not "24 hours
		// after whatever time the site was set up".
		if ( ! wp_next_scheduled( self::SUMMARY ) ) {
			wp_schedule_event( self::next_hour( 8 ), 'daily', self::SUMMARY );
		}
		if ( ! wp_next_scheduled( self::WEEKLY ) ) {
			wp_schedule_event( self::next_weekday_hour( 1, 8 ), 'weekly', self::WEEKLY );
		}
	}

	/**
	 * The next time the office's own clock reads this hour.
	 *
	 * @param int $hour Hour of the day, 0-23.
	 * @return int Timestamp.
	 */
	private static function next_hour( int $hour ): int {
		try {
			$zone = wp_timezone();
		} catch ( \Exception $e ) {
			return time() + DAY_IN_SECONDS;
		}
		$now  = new \DateTimeImmutable( 'now', $zone );
		$when = $now->setTime( $hour, 0, 0 );
		if ( $when <= $now ) {
			$when = $when->modify( '+1 day' );
		}
		return $when->getTimestamp();
	}

	/**
	 * The next time the office's clock reads this hour on this weekday.
	 *
	 * @param int $weekday 1 = Monday … 7 = Sunday (ISO).
	 * @param int $hour    Hour of the day.
	 * @return int Timestamp.
	 */
	private static function next_weekday_hour( int $weekday, int $hour ): int {
		$ts = self::next_hour( $hour );
		try {
			$zone = wp_timezone();
		} catch ( \Exception $e ) {
			return $ts;
		}
		$when = ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( $zone );
		$jump = ( 7 + $weekday - (int) $when->format( 'N' ) ) % 7;
		if ( $jump > 0 ) {
			$when = $when->modify( '+' . $jump . ' day' );
		}
		return $when->getTimestamp();
	}

	/**
	 * Remove scheduled jobs.
	 *
	 * @return void
	 */
	public static function unschedule(): void {
		foreach ( array( self::DAILY, self::SUMMARY, self::WEEKLY, 'estat_hourly_maintenance', \EstatOS\Webhooks\Webhooks::RETRY_HOOK ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
	}

	/**
	 * Daily housekeeping.
	 *
	 * @return void
	 */
	public static function run_daily(): void {
		// F6: continue running imports.
		self::process_import_jobs();

		$expired = self::expire_listings();

		$retention = (int) Settings::get( 'retention_days', 0 );
		if ( $retention > 0 ) {
			Leads::apply_retention( $retention );
			AuditLog::purge_older_than( max( $retention, 365 ) );
		}

		self::repair_index();

		AuditLog::record( 'maintenance.run', 'cron', 0, array( 'job' => 'daily', 'expired' => $expired ) );
	}

	/**
	 * The morning summary: what today looks like.
	 *
	 * @return void
	 */
	public static function run_summary(): void {
		if ( ! Settings::get( 'notify_daily_summary', true ) ) {
			return;
		}

		$visits   = Visits::counts();
		$counts   = Leads::counts();
		$listings = wp_count_posts( PostTypes::LISTING );

		Notifier::daily_summary(
			array(
				'visits_today'      => (int) $visits['today'],
				'enquiries_new'     => (int) Leads::query(
					array(
						'per_page'  => 1,
						'page'      => 1,
						'date_from' => gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ),
					)
				)['total'],
				'followups_due'     => (int) $counts['due'],
				'waiting_approval'  => (int) ( $listings->pending ?? 0 ),
				'drafts'            => (int) ( $listings->draft ?? 0 ),
			)
		);
	}

	/**
	 * The weekly report: the last seven days.
	 *
	 * @return void
	 */
	public static function run_weekly(): void {
		if ( ! Settings::get( 'notify_weekly_report', true ) ) {
			return;
		}

		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - ( 7 * DAY_IN_SECONDS ) );
		$table = Schema::table( 'estat_leads' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$moved = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT SUM(CASE WHEN status = 'won' THEN 1 ELSE 0 END) AS won, SUM(CASE WHEN status = 'lost' THEN 1 ELSE 0 END) AS lost
				 FROM {$table} WHERE updated_at >= %s AND erased = 0",
				$since
			),
			ARRAY_A
		);
		$top = (string) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT source FROM {$table} WHERE created_at >= %s AND erased = 0 GROUP BY source ORDER BY COUNT(*) DESC LIMIT 1",
				$since
			)
		);
		// phpcs:enable

		$visits = Visits::query(
			array(
				'per_page' => 1,
				'page'     => 1,
				'from'     => $since,
				'to'       => gmdate( 'Y-m-d H:i:s' ),
			)
		);

		Notifier::weekly_report(
			array(
				'enquiries'   => (int) Leads::query( array( 'per_page' => 1, 'page' => 1, 'date_from' => $since ) )['total'],
				'visits'      => (int) $visits['total'],
				'visits_done' => (int) Visits::query(
					array(
						'per_page' => 1,
						'page'     => 1,
						'from'     => $since,
						'to'       => gmdate( 'Y-m-d H:i:s' ),
						'outcome'  => 'done',
					)
				)['total'],
				'won'         => (int) ( $moved['won'] ?? 0 ),
				'lost'        => (int) ( $moved['lost'] ?? 0 ),
				'live'        => (int) ( wp_count_posts( PostTypes::LISTING )->publish ?? 0 ),
				'top_source'  => '' !== $top ? \EstatOS\Support\Vocabulary::label( 'lead_sources', $top ) : '',
			)
		);
	}


	/**
	 * F6: Continue processing import jobs that are still running.
	 *
	 * @return void
	 */
	private static function process_import_jobs(): void {
		if ( ! class_exists( '\\EstatOS\\Csv\\Spreadsheet' ) ) { return; }
		$jobs = \EstatOS\Csv\Spreadsheet::recent_jobs( 20 );
		foreach ( $jobs as $job ) {
			if ( 'running' === $job['state'] ) {
				\EstatOS\Csv\Spreadsheet::process_batch( (int) $job['id'] );
			}
		}
		}

	/**
	 * Move listings past their removal date back to draft.

	 *
	 * @return int Number of listings taken offline.
	 */
	public static function expire_listings(): int {
		$today = current_time( 'Y-m-d' );
		$ids   = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => '_estat_expiry_date',
						'value'   => $today,
						'compare' => '<',
						'type'    => 'DATE',
					),
				),
			)
		);

		/*
		 * The office can also say "every property comes off after N days",
		 * which is how most offices actually want to work — nobody wants to
		 * set a date on each of two hundred records. The number lived under
		 * Settings → Properties and no code ever read it; a listing would
		 * sit on the website for years.
		 *
		 * Only published listings are touched, the ones with their own date
		 * are left to that date, and a listing is taken back to draft
		 * rather than deleted — the record waits in the office's list.
		 */
		$window = (int) Settings::get( 'listing_expiry_days', 0 );
		if ( $window > 0 ) {
			$old = get_posts(
				array(
					'post_type'      => PostTypes::LISTING,
					'post_status'    => 'publish',
					'posts_per_page' => 100,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'date_query'     => array(
						array(
							'column' => 'post_date_gmt',
							'before' => gmdate( 'Y-m-d H:i:s', time() - ( $window * DAY_IN_SECONDS ) ),
						),
					),
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						'relation' => 'OR',
						array(
							'key'     => '_estat_expiry_date',
							'compare' => 'NOT EXISTS',
						),
						array(
							'key'     => '_estat_expiry_date',
							'value'   => '',
							'compare' => '=',
						),
					),
				)
			);
			$ids = array_values( array_unique( array_merge( $ids, $old ) ) );
		}

		foreach ( $ids as $id ) {
			wp_update_post( array( 'ID' => (int) $id, 'post_status' => 'draft' ) );
		}
		return count( $ids );
	}

	/**
	 * Repair a slice of the search index each day.
	 *
	 * @return void
	 */
	public static function repair_index(): void {
		$status = SearchIndex::status();
		if ( $status['in_sync'] ) {
			return;
		}
		$offset = (int) get_option( 'estat_index_repair_offset', 0 );
		$done   = SearchIndex::rebuild_batch( 200, $offset );
		update_option( 'estat_index_repair_offset', $done < 200 ? 0 : $offset + 200, false );
	}
}
