<?php
/**
 * Spreadsheet import and export — F6: preview+undo + bridge from old system.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Csv;

use EstatOS\Audit\AuditLog;
use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;

use EstatOS\Search\SearchIndex;
use EstatOS\Support\Sanitize;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Imports run in resumable batches and are duplicate safe: rows carrying a
 * reference number update the existing record instead of creating a second one,
 * so importing the same file twice changes nothing.
 *
 * F6: preview before import, undo after import, bridge from old portals.
 */
final class Spreadsheet {

	/**
	 * Rows handled per batch.
	 */
	public const BATCH = 50;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {}

	/**
	 * The documented column contract per record kind.
	 *
	 * @param string $kind listings|projects|agents|leads.
	 * @return array<string,string> Column => description.
	 */
	public static function columns( string $kind ): array {
		switch ( $kind ) {
			case 'projects':
				return array(
					'external_id'     => __( 'Your own reference number (used to avoid duplicates)', 'estat-os' ),
					'title'           => __( 'Name of the society or project', 'estat-os' ),
					'slug'            => __( 'Web address (leave empty to make one from the name)', 'estat-os' ),
					'description'     => __( 'Description', 'estat-os' ),
					'locality'        => __( 'Locality', 'estat-os' ),
					'developer'       => __( 'Builder or developer', 'estat-os' ),
					'project_type'    => __( 'What kind of homes or units, for example Apartment + Penthouse', 'estat-os' ),
					'category'        => __( 'residential, commercial, affordable, mixed or other', 'estat-os' ),
					'address'         => __( 'Where it is, as written on your sheet', 'estat-os' ),
					'city'            => __( 'City (added to the end of the address line)', 'estat-os' ),
					'highlights'      => __( 'Selling points, one per line', 'estat-os' ),
					'notes'           => __( 'Anything else your sheet says about the project', 'estat-os' ),
					'project_status'  => __( 'Stage: ready, construction, new_launch, completed', 'estat-os' ),
					'possession_date' => __( 'Possession date (YYYY-MM-DD)', 'estat-os' ),
					'price_min'       => __( 'Lowest price (numbers only)', 'estat-os' ),
					'price_max'       => __( 'Highest price (numbers only)', 'estat-os' ),
					'price_unit'      => __( 'rupees, lakh or cr — what those two price columns are in', 'estat-os' ),
					'currency'        => __( 'Currency — rupees, unless your sheet says otherwise', 'estat-os' ),
					'total_units'     => __( 'Total units', 'estat-os' ),
					'available_units' => __( 'Units still available', 'estat-os' ),
					'unit_types'      => __( 'Unit types, for example 2 BHK, 3 BHK', 'estat-os' ),
					'regulatory_id'   => __( 'Registration number', 'estat-os' ),
					'latitude'        => __( 'Map latitude', 'estat-os' ),
					'longitude'       => __( 'Map longitude', 'estat-os' ),
				);
			case 'agents':
				return array(
					'external_id' => __( 'Your own reference number', 'estat-os' ),
					'title'       => __( 'Full name', 'estat-os' ),
					'role'        => __( 'Role in the office', 'estat-os' ),
					'phone'       => __( 'Phone number', 'estat-os' ),
					'whatsapp'    => __( 'WhatsApp number', 'estat-os' ),
					'email'       => __( 'Email address', 'estat-os' ),
					'bio'         => __( 'Short biography', 'estat-os' ),
				);
			case 'leads':
				return array(
					'name'        => __( 'Name of the person', 'estat-os' ),
					'phone'       => __( 'Phone number', 'estat-os' ),
					'email'       => __( 'Email address', 'estat-os' ),
					'message'     => __( 'What they asked', 'estat-os' ),
					'source'      => __( 'Where it came from', 'estat-os' ),
					'listing_ref' => __( 'Reference number of the property they asked about', 'estat-os' ),
					'status'      => __( 'Status: new, contacted, qualified, visit_scheduled, converted, lost', 'estat-os' ),
				);
			case 'visits':
				return array(
					'scheduled_at' => __( 'When the visit is', 'estat-os' ),
					'name'         => __( 'Who is visiting', 'estat-os' ),
					'phone'        => __( 'Phone number', 'estat-os' ),
					'listing_ref'  => __( 'Reference number of the property', 'estat-os' ),
					'listing_name' => __( 'Name of the property', 'estat-os' ),
					'agent'        => __( 'Team member showing them round', 'estat-os' ),
					'outcome'      => __( 'How it went: pending, done, no_show, cancelled', 'estat-os' ),
					'notes'        => __( 'Notes', 'estat-os' ),
				);
			case 'listings':
			default:
				return array(
					'external_id'     => __( 'Your own reference number (used to avoid duplicates)', 'estat-os' ),
					'title'           => __( 'Headline for the property', 'estat-os' ),
					'description'     => __( 'Full description', 'estat-os' ),
					'offer'           => __( 'sale, rent or lease', 'estat-os' ),
					'property_type'   => __( 'apartment, villa, plot, office and so on', 'estat-os' ),
					'price'           => __( 'Price (numbers only)', 'estat-os' ),
					'price_type'      => __( 'fixed, negotiable, starting_from or on_request', 'estat-os' ),
					'rent'            => __( 'Monthly rent (numbers only)', 'estat-os' ),
					'deposit'         => __( 'Security deposit', 'estat-os' ),
					'maintenance'     => __( 'Monthly maintenance', 'estat-os' ),
					'area'            => __( 'Size (numbers only)', 'estat-os' ),
					'area_unit'       => __( 'sqft, sqyd or sqm', 'estat-os' ),
					'area_type'       => __( 'carpet, builtup, super or plot', 'estat-os' ),
					'bedrooms'        => __( 'Number of bedrooms', 'estat-os' ),
					'bathrooms'       => __( 'Number of bathrooms', 'estat-os' ),
					'balconies'       => __( 'Number of balconies', 'estat-os' ),
					'parking'         => __( 'Parking spaces', 'estat-os' ),
					'floor'           => __( 'Which floor', 'estat-os' ),
					'total_floors'    => __( 'Floors in the building', 'estat-os' ),
					'age'             => __( 'Age in years', 'estat-os' ),
					'facing'          => __( 'Direction it faces', 'estat-os' ),
					'furnishing'      => __( 'unfurnished, semi or furnished', 'estat-os' ),
					'address'         => __( 'Full address', 'estat-os' ),
					'locality'        => __( 'Locality (separate several with commas)', 'estat-os' ),
					'amenities'       => __( 'Amenities (separate several with commas)', 'estat-os' ),
					'latitude'        => __( 'Map latitude', 'estat-os' ),
					'longitude'       => __( 'Map longitude', 'estat-os' ),
					'availability'    => __( 'available, on_hold, booked or sold', 'estat-os' ),
					'freshness'       => __( 'just_listed, ready_to_move or blank', 'estat-os' ),
					'construction'    => __( 'ready, construction or new_launch', 'estat-os' ),
					'possession_date' => __( 'Possession date (YYYY-MM-DD)', 'estat-os' ),
					'project_ref'     => __( 'Reference number of the society/project', 'estat-os' ),
					'agent_ref'       => __( 'Reference number of the team member', 'estat-os' ),
					'developer'       => __( 'Builder or developer', 'estat-os' ),
					'regulatory_id'   => __( 'Registration number', 'estat-os' ),
					'featured'        => __( 'yes or no', 'estat-os' ),
					'investment'      => __( 'yes or no', 'estat-os' ),
					'status'          => __( 'draft or publish', 'estat-os' ),
				);
		}
	}

	/**
	 * F6: Bridge mappings from old portals to our columns.
	 * Each old header (lowercase, underscore) maps to our column.
	 *
	 * @param string $system System key.
	 * @return array<string,string> old_header_normalized => our_column
	 */
	public static function bridge_mappings( string $system = '' ): array {
		$common = array(
			'property_id'   => 'external_id',
			'prop_id'       => 'external_id',
			'ref'           => 'external_id',
			'reference'     => 'external_id',
			'id'            => 'external_id',
			'title'         => 'title',
			'property_title'=> 'title',
			'name'          => 'title',
			'property_name' => 'title',
			'description'   => 'description',
			'desc'          => 'description',
			'details'       => 'description',
			'price'         => 'price',
			'asking_price'  => 'price',
			'sale_price'    => 'price',
			'cost'          => 'price',
			'rent'          => 'rent',
			'monthly_rent'  => 'rent',
			'area'          => 'area',
			'size'          => 'area',
			'sqft'          => 'area',
			'built_up_area' => 'area',
			'carpet_area'   => 'area',
			'bedroom'       => 'bedrooms',
			'bedrooms'      => 'bedrooms',
			'bhk'           => 'bedrooms',
			'bathroom'      => 'bathrooms',
			'bathrooms'     => 'bathrooms',
			'address'       => 'address',
			'full_address'  => 'address',
			'location'      => 'locality',
			'locality'      => 'locality',
			'area_name'     => 'locality',
			'city'          => 'locality',
			'property_type' => 'property_type',
			'type'          => 'property_type',
			'offer'         => 'offer',
			'transaction'   => 'offer',
			'for'           => 'offer',
			'furnishing'    => 'furnishing',
			'furnished'     => 'furnishing',
			'facing'        => 'facing',
			'floor'         => 'floor',
			'floor_no'      => 'floor',
			'total_floor'   => 'total_floors',
			'total_floors'  => 'total_floors',
			'age'           => 'age',
			'property_age'  => 'age',
			'possession'    => 'possession_date',
			'possession_date'=> 'possession_date',
			'latitude'      => 'latitude',
			'lat'           => 'latitude',
			'longitude'     => 'longitude',
			'lng'           => 'longitude',
			'long'          => 'longitude',
			'agent'         => 'agent_ref',
			'agent_id'      => 'agent_ref',
			'project'       => 'project_ref',
			'society'       => 'project_ref',
		);

		$systems = array(
			'generic' => $common,
			'99acres' => array_merge( $common, array(
				'propid'        => 'external_id',
				'proptype'      => 'property_type',
				'transactiontype'=> 'offer',
				'locality_label'=> 'locality',
			) ),
			'magicbricks' => array_merge( $common, array(
				'propertyid'    => 'external_id',
				'propertytype'  => 'property_type',
				'transactiontype'=> 'offer',
			) ),
			'housing' => array_merge( $common, array(
				'housing_id'    => 'external_id',
			) ),
			'nobroker' => array_merge( $common, array(
				'nb_id'         => 'external_id',
			) ),
			/*
			 * A builder's or a broker's own master sheet. These are not portal
			 * exports: the columns are the trade's own words (micro market,
			 * corridor, price in Cr, RERA, possession) and one row is a whole
			 * project, not one flat.
			 */
			'developer_master' => array_merge( $common, array(
				'id'                 => 'external_id',
				'slug'               => 'slug',
				'project_name'       => 'title',
				'builder'            => 'developer',
				'micro_market'       => 'locality',
				'corridor'           => 'locality',
				'sector_corridor_raw'=> 'address',
				'sector_corridor'    => 'address',
				'project_type'       => 'project_type',
				'property_type'      => 'project_type',
				'category'           => 'category',
				'status'             => 'project_status',
				'stage'              => 'project_status',
				'bhk_config'         => 'unit_types',
				'bedrooms_bhk'       => 'unit_types',
				'bhk'                => 'unit_types',
				'unit_type'          => 'unit_types',
				// A second size column, when a sheet has one, is something worth
				// saying about the project rather than a column thrown away.
				'area_size'          => 'notes',
				'property_status'    => 'project_status',
				'price_min_cr'       => 'price_min',
				'price_max_cr'       => 'price_max',
				'price_cr'           => 'price_min',
				'price_display'      => 'notes',
				'price_unit_raw'     => 'price_unit',
				'currency_unit'      => 'price_unit',
				'rera_number'        => 'regulatory_id',
				'rera'               => 'regulatory_id',
				'possession_date'    => 'possession_date',
				'highlights'         => 'highlights',
				'city'               => 'city',
			) ),
			'makaan' => $common,			'commonfloor' => $common,
			'old_estat' => $common,
		);

		if ( '' !== $system && isset( $systems[ $system ] ) ) {
			return $systems[ $system ];
		}
		return $common;
	}

	/**
	 * List of bridge system keys.
	 *
	 * @return array<string,string> key => label
	 */
	public static function bridge_systems(): array {
		return array(
			'generic'     => __( 'Generic CSV', 'estat-os' ),
			'99acres'     => __( '99acres export', 'estat-os' ),
			'magicbricks' => __( 'MagicBricks export', 'estat-os' ),
			'housing'     => __( 'Housing.com export', 'estat-os' ),
			'nobroker'    => __( 'NoBroker export', 'estat-os' ),
			'makaan'      => __( 'Makaan export', 'estat-os' ),
			'commonfloor' => __( 'CommonFloor export', 'estat-os' ),
			'developer_master' => __( 'Developer / builder master sheet', 'estat-os' ),
			'old_estat'   => __( 'Old Estat-OS / custom', 'estat-os' ),
		);
	}

	/**
	 * Read the header row and a few sample rows from an uploaded file.
	 *
	 * @param string $path File path.
	 * @param int    $sample_rows Sample rows to read.
	 * @return array{headers:string[],rows:array<int,string[]>,total:int}|WP_Error
	 */
	public static function preview( string $path, int $sample_rows = 5 ) {
		$handle = self::open( $path );
		if ( is_wp_error( $handle ) ) {
			return $handle;
		}
		$headers = fgetcsv( $handle, 0, ',', '"', '' );
		if ( ! is_array( $headers ) ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new WP_Error( 'estat_bad_csv', __( 'We could not read the first line of this file. Please check that it is a CSV with column names.', 'estat-os' ) );
		}
		$headers = array_map( static fn( $h ) => Sanitize::text( (string) $h ), $headers );

		$rows  = array();
		$total = 0;
		while ( false !== ( $row = fgetcsv( $handle, 0, ',', '"', '' ) ) ) { // phpcs:ignore
			++$total;
			if ( count( $rows ) < $sample_rows ) {
				$rows[] = array_map( static fn( $v ) => Sanitize::text( (string) $v ), (array) $row );
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		return array( 'headers' => $headers, 'rows' => $rows, 'total' => $total );
	}

	/**
	 * One header, folded down to a name we can compare.
	 *
	 * "Total Units", "total-units" and "Total_Units" are the same column on
	 * three different sheets, and the office should not have to care.
	 *
	 * @param string $header File header.
	 * @return string
	 */
	private static function header_key( string $header ): string {
		$key = strtolower( trim( $header ) );
		$key = str_replace( array( ' ', '-', '/' ), '_', $key );
		return (string) preg_replace( '/[^a-z0-9_]/', '', $key );
	}

	/**
	 * Columns that mean one thing and not the other.
	 *
	 * Both a property sheet and a builder's master sheet have a "title". Only
	 * a property sheet has "Rent" and "Bedrooms"; only a society sheet has
	 * "Total units" and "Possession". Those are the words counted below —
	 * anything that could honestly be either ("status", "property_type",
	 * "address", "price") is deliberately left out.
	 *
	 * @return array<string,string[]>
	 */
	private static function kind_signals(): array {
		return array(
			'projects' => array(
				'developer',
				'developer_name',
				'builder',
				'builder_name',
				'project',
				'project_name',
				'project_status',
				'project_stage',
				'project_type',
				'stage',
				'possession',
				'possession_date',
				'possession_status',
				'total_units',
				'units_total',
				'no_of_units',
				'unit_types',
				'unit_type',
				'unit_config',
				'bhk_config',
				'bhk_configuration',
				'configuration',
				'category',
				'available_units',
				'units_available',
				'rera',
				'rera_number',
				'rera_no',
				'rera_id',
				'registration_number',
			),
			'listings' => array(
				'offer',
				'rent',
				'monthly_rent',
				'deposit',
				'security_deposit',
				'maintenance',
				'bedrooms',
				'bedroom',
				'bhk',
				'bathrooms',
				'bathroom',
				'balconies',
				'balcony',
				'furnishing',
				'furnished',
				'facing',
				'floor',
				'floor_no',
				'total_floors',
				'parking',
				'car_parking',
				'availability',
				'freshness',
				'area_type',
				'carpet_area',
				'super_area',
				'built_up_area',
				'video_url',
				'tour_url',
				'floor_plans',
				'brochures',
			),
			'agents'   => array(
				'role',
				'designation',
				'bio',
				'biography',
				'agent_role',
				'whatsapp_number',
			),
			'leads'    => array(
				'message',
				'requirement',
				'source',
				'listing_ref',
				'lead_status',
				'enquiry_status',
				'budget',
			),
		);
	}

	/**
	 * Which kind of records is this file?
	 *
	 * "What is in this file?" is a question the office answers once, at the
	 * upload box — and the wrong answer is expensive. A sheet of societies
	 * read as properties fills the property list with names like "DLF The
	 * Camellias", each of them wrong, and the office then has to undo an
	 * import to get rid of them.
	 *
	 * The columns usually say what the file is, so they are asked first. Only
	 * columns that mean one kind and not the other are counted, and a verdict
	 * is only given when one kind is clearly ahead — two signals at least,
	 * and two more than the next kind. Everything else returns '' and
	 * whatever the office chose stands.
	 *
	 * @param string[] $headers File headers.
	 * @return string 'listings', 'projects', 'agents', 'leads' or '' when unsure.
	 */
	public static function guess_kind( array $headers ): string {
		$found = array();
		foreach ( $headers as $header ) {
			$key = self::header_key( (string) $header );
			if ( '' !== $key ) {
				$found[ $key ] = true;
			}
		}

		$scores = array();
		foreach ( self::kind_signals() as $kind => $words ) {
			$score = 0;
			foreach ( $words as $word ) {
				if ( isset( $found[ $word ] ) ) {
					++$score;
				}
			}
			$scores[ $kind ] = $score;
		}

		arsort( $scores );
		$order = array_keys( $scores );
		$best  = (int) $scores[ $order[0] ];
		$next  = (int) ( $scores[ $order[1] ] ?? 0 );

		if ( $best < 2 || ( $best - $next ) < 2 ) {
			return '';
		}

		return (string) $order[0];
	}

	/**
	 * Guess a mapping from file headers to known columns, with bridge support.
	 *
	 * @param string[] $headers File headers.
	 * @param string   $kind    Record kind.
	 * @param string   $bridge  Bridge system key.
	 * @return array<string,string> Column => header.
	 */
	public static function guess_mapping( array $headers, string $kind, string $bridge = '' ): array {
		$mapping = array();
		$known   = array_keys( self::columns( $kind ) );
		$bridge_map = $bridge ? self::bridge_mappings( $bridge ) : array();

		// First try direct match.
		foreach ( $known as $column ) {
			foreach ( $headers as $header ) {
				$normalized = strtolower( str_replace( array( ' ', '-' ), '_', trim( $header ) ) );
				if ( $normalized === $column ) {
					$mapping[ $column ] = $header;
					break;
				}
			}
		}
		// Then try bridge map.
		if ( $bridge_map ) {
			foreach ( $headers as $header ) {
				$norm = strtolower( str_replace( array( ' ', '-' ), '_', trim( $header ) ) );
				$norm = preg_replace( '/[^a-z0-9_]/', '', $norm );
				if ( isset( $bridge_map[ $norm ] ) ) {
					$our_col = $bridge_map[ $norm ];
					if ( in_array( $our_col, $known, true ) && ! isset( $mapping[ $our_col ] ) ) {
						$mapping[ $our_col ] = $header;
					}
				}
			}
		}
		return $mapping;
	}

	/**
	 * Which bridge reads this file best.
	 *
	 * A builder's master sheet and a 99acres export both arrive as "a CSV", and
	 * the office should not have to name the thing they are holding. Every
	 * bridge is scored by how many of our columns it finds, and a named one is
	 * only chosen when it reads two columns more than the plain reading —
	 * one extra match is a coincidence, two is a pattern.
	 *
	 * @param string[] $headers File headers.
	 * @param string   $kind    Record kind.
	 * @return string Bridge key, or 'generic'.
	 */
	public static function guess_bridge( array $headers, string $kind = 'listings' ): string {
		$plain  = count( self::guess_mapping( $headers, $kind, 'generic' ) );
		$best   = 'generic';
		$best_n = $plain;

		foreach ( array_keys( self::bridge_systems() ) as $system ) {
			if ( 'generic' === $system ) {
				continue;
			}
			$found = count( self::guess_mapping( $headers, $kind, $system ) );
			if ( $found > $best_n ) {
				$best_n = $found;
				$best   = $system;
			}
		}

		return ( $best_n >= $plain + 2 ) ? $best : 'generic';
	}

	/**
	 * What will happen to every column in the file, in the order it is written.
	 *
	 * The office uploads a sheet with twenty-five columns and needs to know,
	 * before pressing the button, which of them the website will hold — and
	 * which ones we are leaving alone. Silence about a column reads as a bug
	 * later: "where did the RERA number go?"
	 *
	 * @param string[]             $headers File headers.
	 * @param array<string,string> $mapping Column => header.
	 * @param string               $kind    Record kind.
	 * @return array<int,array{header:string,label:string,why:string}>
	 */
	public static function column_plan( array $headers, array $mapping, string $kind ): array {
		$labels = self::columns( $kind );
		$taken  = array();
		foreach ( $mapping as $column => $header ) {
			if ( '' !== (string) $header ) {
				$taken[ (string) $header ] = (string) ( $labels[ $column ] ?? $column );
			}
		}

		$plan = array();
		foreach ( $headers as $header ) {
			$header = (string) $header;
			$plan[] = array(
				'header' => $header,
				'label'  => $taken[ $header ] ?? '',
				'why'    => isset( $taken[ $header ] ) ? '' : self::why_unused( $header ),
			);
		}
		return $plan;
	}

	/**
	 * Why a column was left alone.
	 *
	 * The trade's own words are listed here by hand, because "corridor" and
	 * "micro_market" being the same thing is knowledge, not a rule. Anything
	 * else gets an honest "we have no box for this".
	 *
	 * @param string $header File header.
	 * @return string
	 */
	private static function why_unused( string $header ): string {
		$key = strtolower( (string) preg_replace( '/[^a-z0-9_]/', '', str_replace( array( ' ', '-' ), '_', trim( $header ) ) ) );

		$known = array(
			'id'           => __( 'Read only when the name is missing — the name is our key.', 'estat-os' ),
			'sector'       => __( 'The sector is already inside the address column of the same sheet.', 'estat-os' ),
			'sector_no'    => __( 'The sector is already inside the address column of the same sheet.', 'estat-os' ),
			'corridor'     => __( 'A shorter name for the same area as the micro-market column, which we do read.', 'estat-os' ),
			'micro_market' => __( 'A second name for the area that is already read from another column.', 'estat-os' ),
			'status_group' => __( 'The short group name; the status column beside it says the same thing in more detail.', 'estat-os' ),
			'stage_group'  => __( 'The short group name; the status column beside it says the same thing in more detail.', 'estat-os' ),
			'size'         => __( 'The size is already written inside the BHK column of the same sheet.', 'estat-os' ),
			'state'        => __( 'The same on every row, and your office city already covers it.', 'estat-os' ),
			'country'      => __( 'The same on every row, and your office city already covers it.', 'estat-os' ),
			'thumbnail'    => __( 'A picture link we cannot fetch — add photos in the gallery after the import.', 'estat-os' ),
			'image'        => __( 'A picture link we cannot fetch — add photos in the gallery after the import.', 'estat-os' ),
		);

		return $known[ $key ] ?? __( 'We have no box for this yet — tell us what it means and we will add one.', 'estat-os' );
	}

	/**
	 * Put a mapped row into the words the records actually store.
	 *
	 * A sheet written by a builder says "₹40 Cr", "Ready to Move (OC)",
	 * "Poss. Mar 2030" and "a • b • c". The record stores paise-free rupee
	 * numbers, one stage word, a date, and one highlight per line. Doing that
	 * here — once, next to the mapping — means the importer, the export and the
	 * website all agree, and no spreadsheet can put a claim in a record that
	 * the office never made.
	 *
	 * @param string               $kind Record kind.
	 * @param array<string,string> $row  Mapped row — the file's own words.
	 * @return array<string,string>
	 */
	public static function translate_row( string $kind, array $row ): array {
		$row = array_map( static fn( $v ) => is_scalar( $v ) ? (string) $v : '', $row );

		// --- Prices: a number is only a price when we know its unit.
		$unit = strtolower( trim( (string) ( $row['price_unit'] ?? '' ) ) );
		$unit = preg_replace( '/[^a-z]/', '', $unit );
		$factor = 1.0;
		if ( in_array( $unit, array( 'cr', 'crore', 'crores' ), true ) ) {
			$factor = 10000000.0;
		} elseif ( in_array( $unit, array( 'lakh', 'lakhs', 'lac', 'lacs', 'l' ), true ) ) {
			$factor = 100000.0;
		} elseif ( in_array( $unit, array( 'k', 'thousand' ), true ) ) {
			$factor = 1000.0;
		} elseif ( '' !== $unit && ! in_array( $unit, array( 'rupees', 'rupee', 'rs', 'inr' ), true ) ) {
			/*
			 * "per_sqft" and anything else we do not know: these numbers are not
			 * a price, and guessing would put a wrong figure on the website.
			 */
			$row['price_min'] = '';
			$row['price_max'] = '';
		}

		if ( isset( $row['price_min'] ) && '' !== trim( (string) $row['price_min'] ) && $factor > 1.0 ) {
			$row['price_min'] = (string) ( (float) str_replace( ',', '', (string) $row['price_min'] ) * $factor );
		}
		if ( isset( $row['price_max'] ) && '' !== trim( (string) $row['price_max'] ) && $factor > 1.0 ) {
			$row['price_max'] = (string) ( (float) str_replace( ',', '', (string) $row['price_max'] ) * $factor );
		}

		// --- A currency we cannot show is a price we cannot show.
		$currency = strtoupper( trim( (string) ( $row['currency'] ?? '' ) ) );
		if ( '' !== $currency && ! in_array( $currency, array( 'INR', 'RS', 'RUPEE', 'RUPEES', '₹' ), true ) ) {
			$row['price_min'] = '';
			$row['price_max'] = '';
		}
		/*
		 * The "as written" price column is kept as loose text, not thrown away.
		 *
		 * Sheets put more than a price in it: "On request", "₹20k-40k/sq ft",
		 * "Poss. Oct 2027". When the two price boxes are empty, the rescue below
		 * reads a price out of it and a possession date out of it, and whatever
		 * is left over ("On request", a per-square-foot rate) is a fact about
		 * the project that the office wrote and the page should say.
		 */
		if ( ! empty( $row['price_display'] ) ) {
			$row['notes'] = trim( Sanitize::text( (string) $row['price_display'] ) . "\n" . (string) ( $row['notes'] ?? '' ) );
		}

		unset( $row['price_unit'], $row['currency'], $row['price_display'] );

		/*
		 * A builder's sheet is written by hand, and a cell often ends up in the
		 * wrong column: the stage in the unit-types column, the price in the
		 * status column, the possession date in the highlights. Nothing is
		 * thrown away — every value is put in the box it belongs in, and
		 * whatever is left over becomes a point about the project.
		 *
		 * This runs before the steps below, while the cells still say what the
		 * office wrote in them.
		 */
		if ( 'projects' === $kind ) {
			$row = self::rescue_project_row( $row );
		}

		// --- Stage, said as a word the record knows.
		if ( isset( $row['project_status'] ) ) {
			$row['project_status'] = self::stage_word( (string) $row['project_status'] );
		}


		// --- Category ("Residential", "Affordable / DDJAY", "Grade-A Office"…).
		if ( isset( $row['category'] ) ) {
			$row['category'] = self::category_word( (string) $row['category'] );
		}

		// --- Possession: "Poss. Mar 2030", "Poss. 2028", "OC received".
		if ( isset( $row['possession_date'] ) && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $row['possession_date'] ) ) {
			$said = Sanitize::text( (string) $row['possession_date'] );
			$when = self::read_date( $said );
			$row['possession_date'] = $when;
			if ( '' === $when && '' !== $said ) {
				// A sentence, not a date ("OC received"): it belongs with the
				// other points about the project rather than thrown away.
				$row['highlights'] = trim( $said . "\n" . (string) ( $row['highlights'] ?? '' ) );
			}
		}

		// --- One highlight per line.
		if ( isset( $row['highlights'] ) ) {
			$row['highlights'] = self::bullets( (string) $row['highlights'] );
		}

		// --- A registration number is a number. The rest of the cell, if any,
		// is something about the project and goes with the highlights.
		if ( ! empty( $row['regulatory_id'] ) ) {
			$parts = preg_split( '/[•|]/u', (string) $row['regulatory_id'] ) ?: array();
			$parts = array_values( array_filter( array_map( 'trim', $parts ), static fn( $p ) => '' !== $p ) );
			$id    = '';
			$extra = array();
			foreach ( $parts as $index => $part ) {
				if ( 0 === $index && preg_match( '/[0-9]/', $part ) ) {
					$id = $part;
					continue;
				}
				$extra[] = $part;
			}
			$row['regulatory_id'] = $id;
			if ( $extra ) {
				$row['highlights'] = self::bullets( implode( "\n", $extra ) . "\n" . (string) ( $row['highlights'] ?? '' ) );
			}
		}

		// --- The city belongs on the end of the address line, once.
		if ( ! empty( $row['city'] ) && isset( $row['address'] ) ) {
			$city    = Sanitize::text( (string) $row['city'] );
			$address = Sanitize::text( (string) $row['address'] );
			if ( '' !== $city && false === stripos( $address, $city ) ) {
				$row['address'] = trim( $address . ( '' === $address ? '' : ', ' ) . $city );
			}
		}
		unset( $row['city'] );

		// --- A web address has to be safe to put in a link.
		if ( isset( $row['slug'] ) ) {
			$row['slug'] = sanitize_title( (string) $row['slug'] );
		}

		if ( ! empty( $row['title'] ) ) {
			$row['title'] = Sanitize::text( (string) $row['title'] );
		}

		return $row;
	}

	/**
	 * Put the cells of a hand-written row where they belong.
	 *
	 * Nothing is thrown away: a stage found in the unit-types column is moved
	 * to the stage, a price found in the status column is moved to the price,
	 * a possession date found in the highlights is moved to the date, and
	 * whatever is left over in a box that has no home in the record becomes a
	 * point about the project.
	 *
	 * @param array<string,string> $row Translated row.
	 * @return array<string,string>
	 */
	private static function rescue_project_row( array $row ): array {
		// What every cell said before anything is moved.
		$said = array();
		foreach ( array( 'project_status', 'unit_types', 'notes', 'highlights' ) as $cell ) {
			$said[ $cell ] = (string) ( $row[ $cell ] ?? '' );
		}

		$extra      = array();
		$stage      = '';
		$stage_cell = '';

		// (1) The stage: the status box, or the box it was written in instead.
		$stage = self::stage_word( $said['project_status'] );
		if ( '' !== $stage ) {
			$stage_cell = 'project_status';
		} else {
			foreach ( array( 'unit_types', 'notes', 'highlights' ) as $cell ) {
				$word = self::stage_word( $said[ $cell ] );
				if ( '' !== $word ) {
					$stage      = $word;
					$stage_cell = $cell;
					break;
				}
			}
		}

		// (2) The price, when the two price boxes are empty and a cell holds one.
		if ( '' === (string) ( $row['price_min'] ?? '' ) && '' === (string) ( $row['price_max'] ?? '' ) ) {
			foreach ( array( 'project_status', 'notes', 'highlights', 'unit_types' ) as $cell ) {
				if ( $cell === $stage_cell ) {
					continue;
				}
				$found = self::price_out_of( $said[ $cell ] );
				if ( null === $found ) {
					continue;
				}
				$row['price_min'] = $found['min'];
				$row['price_max'] = $found['max'];
				$said[ $cell ]    = $found['left'];
				break;
			}
		}

		// (3) The possession date, when the date box is empty and a cell holds one.
		if ( '' === (string) ( $row['possession_date'] ?? '' ) ) {
			foreach ( array( 'notes', 'highlights', 'project_status' ) as $cell ) {
				if ( $cell === $stage_cell ) {
					continue;
				}
				$found = self::date_out_of( $said[ $cell ] );
				if ( null === $found ) {
					continue;
				}
				$row['possession_date'] = $found['date'];
				$said[ $cell ]          = $found['left'];
				break;
			}
		}

		/*
		 * (4) Say it all again. The stage box holds a stage and nothing else;
		 * whatever is left over anywhere becomes a point about the project, and a
		 * price the record already holds is not repeated as a selling point.
		 */
		$has_price = '' !== (string) ( $row['price_min'] ?? '' ) || '' !== (string) ( $row['price_max'] ?? '' );
		$has_date  = '' !== (string) ( $row['possession_date'] ?? '' );

		foreach ( array( 'project_status', 'notes', 'unit_types' ) as $cell ) {
			if ( $cell === $stage_cell ) {
				$said[ $cell ] = '';
				continue;
			}
			if ( '' === trim( $said[ $cell ] ) ) {
				continue;
			}
			/*
			 * The unit-types box is a real box with a real answer in it, so what is
			 * in it stays; only a stage or a date that landed there by mistake has
			 * been taken out above.
			 */
			if ( 'unit_types' === $cell && '' === self::stage_word( $said[ $cell ] ) ) {
				continue;
			}
			foreach ( self::cell_parts( $said[ $cell ] ) as $part ) {
				if ( $has_price && self::is_only_a_price( $part ) ) {
					continue;
				}
				$extra[] = $part;
			}
			if ( 'project_status' === $cell ) {
				$said[ $cell ] = '';
			}
		}

		/*
		 * Keep the project's own points, minus a bare year the date already
		 * says, and minus the words that turned out to be the stage (they are
		 * printed as the stage now, and saying both looks like a stutter).
		 */
		$points = array();
		foreach ( array_merge( $extra, self::cell_parts( (string) ( $row['highlights'] ?? '' ) ) ) as $part ) {
			if ( $has_date && preg_match( '/^(19|20)\d{2}\s*([–\-]\s*\d{2,4})?$/u', trim( $part ) ) ) {
				continue;
			}
			if ( '' !== $stage && self::is_stage_label( $part ) ) {
				continue;
			}
			$points[] = $part;
		}

		$row['project_status'] = $stage;
		if ( 'unit_types' === $stage_cell ) {
			$row['unit_types'] = '';
		}
		$row['notes']      = '';
		$row['highlights'] = self::bullets( implode( "\n", array_unique( $points ) ) );

		return $row;
	}

	/**
	 * Whether a point is nothing but the stage word again.
	 *
	 * "Ready" beside a stage of "Ready to Move" is a stutter; "OC received" is
	 * a fact in its own right and stays.
	 *
	 * @param string $part One part of a cell.
	 * @return bool
	 */
	private static function is_stage_label( string $part ): bool {
		$said = strtolower( trim( $part ) );
		$said = trim( (string) preg_replace( '/[^a-z ]/', '', $said ) );

		return in_array(
			$said,
			array( 'ready', 'ready to move', 'under construction', 'construction', 'uc', 'completed', 'complete', 'new launch', 'launch', 'upcoming', 'planning', 'operational' ),
			true
		);
	}

	/**
	 * Split a cell into its parts — on the bullet marks a sheet uses.
	 *
	 * @param string $cell Cell text.
	 * @return string[]
	 */
	private static function cell_parts( string $cell ): array {
		$cell  = str_replace( array( "\r\n", "\r" ), "\n", $cell );
		$parts = preg_split( '/\s*[•\x{2022}\x{25CF}\x{00B7}|]\s*|\s*\n\s*/u', $cell ) ?: array();

		return array_values( array_filter( array_map(
			static fn( $p ) => trim( preg_replace( '/\s+/u', ' ', (string) $p ) ?? '' ),
			$parts
		), static fn( $p ) => '' !== $p ) );
	}

	/**
	 * Whether a piece of text is nothing but a price.
	 *
	 * @param string $part One part of a cell.
	 * @return bool
	 */
	private static function is_only_a_price( string $part ): bool {
		// A rate, a yield or a rent is not a price: it says something.
		if ( preg_match( '/\/\s*sq|per\s*sq|sq\s?ft|sqyd|yield|rent|assured|frontage|acre/i', $part ) ) {
			return false;
		}
		$rest = preg_replace( '/[₹\d.,\s\-–—+]/u', '', $part ) ?? '';
		$rest = preg_replace( '/crores|crore|lakhs|lakh|lacs|lac|thousand|cr|rs|inr|from|onwards|onward|plus|k/i', '', $rest ) ?? '';

		return '' === trim( $rest );
	}

	/**
	 * Take a price out of a cell that was not meant for one.
	 *
	 * "Shops from ₹1 Cr" → lowest 10000000, and nothing left over.
	 * "₹20k–40k/sq ft • Shops from ₹1 Cr" → the rate is left alone (a rate is
	 * not a price), the lump sum is taken, and the rate stays behind as
	 * something worth saying about the project.
	 *
	 * @param string $cell Cell text.
	 * @return array{min:string,max:string,left:string}|null Null when there is no price in it.
	 */
	private static function price_out_of( string $cell ): ?array {
		if ( '' === trim( $cell ) || false === strpos( $cell, '₹' ) ) {
			return null;
		}

		$left = array();
		$min  = 0.0;
		$max  = 0.0;

		foreach ( self::cell_parts( $cell ) as $part ) {
			// A rate per square foot is not a price.
			if ( preg_match( '/\/\s*sq|per\s*sq|sq\.?\s?ft\s*rate/i', $part ) ) {
				$left[] = $part;
				continue;
			}
			if ( ! preg_match_all( '/₹\s*([\d.,]+)\s*(cr|crore|crores|lakh|lakhs|lac|lacs|k|thousand)?/iu', $part, $found, PREG_SET_ORDER ) ) {
				$left[] = $part;
				continue;
			}

			$values = array();
			foreach ( $found as $one ) {
				$number = (float) str_replace( ',', '', (string) $one[1] );
				$unit   = strtolower( (string) ( $one[2] ?? '' ) );
				if ( in_array( $unit, array( 'cr', 'crore', 'crores' ), true ) ) {
					$number *= 10000000.0;
				} elseif ( in_array( $unit, array( 'lakh', 'lakhs', 'lac', 'lacs' ), true ) ) {
					$number *= 100000.0;
				} elseif ( in_array( $unit, array( 'k', 'thousand' ), true ) ) {
					$number *= 1000.0;
				}
				if ( $number > 0 ) {
					$values[] = $number;
				}
			}
			if ( ! $values ) {
				$left[] = $part;
				continue;
			}

			sort( $values );
			if ( preg_match( '/\b(upto|up to|under|less than|below)\b/i', $part ) ) {
				$max = max( $max, (float) end( $values ) );
			} else {
				$min = $min > 0 ? min( $min, (float) reset( $values ) ) : (float) reset( $values );
				$max = max( $max, (float) end( $values ) );
			}
		}

		if ( $min <= 0 && $max <= 0 ) {
			return array( 'min' => '', 'max' => '', 'left' => $cell );
		}

		return array(
			'min'  => $min > 0 ? (string) round( $min ) : '',
			'max'  => $max > 0 && $max !== $min ? (string) round( $max ) : '',
			'left' => implode( ' • ', $left ),
		);
	}

	/**
	 * Take a possession date out of a cell that was not meant for one.
	 *
	 * @param string $cell Cell text.
	 * @return array{date:string,left:string}|null Null when there is no date in it.
	 */
	private static function date_out_of( string $cell ): ?array {
		if ( '' === trim( $cell ) ) {
			return null;
		}

		$left = array();
		$date = '';
		foreach ( self::cell_parts( $cell ) as $part ) {
			if ( '' === $date && ( 0 === stripos( $part, 'poss' ) || preg_match( '/^(19|20)\d{2}\s*([–\-]\s*\d{2,4})?$/u', trim( $part ) ) ) ) {
				$read = self::read_date( $part );
				if ( '' !== $read ) {
					$date = $read;
					continue;
				}
			}
			$left[] = $part;
		}

		if ( '' === $date ) {
			return null;
		}

		return array( 'date' => $date, 'left' => implode( ' • ', $left ) );
	}

	/**
	 * Which stage the office means, in the words a record stores.
	 *
	 * @param string $said What the sheet said.
	 * @return string
	 */
	private static function stage_word( string $said ): string {
		/*
		 * Dashes and underscores become spaces first: a sheet that says
		 * "Pre-launch" and a record that stores "new_launch" are the same
		 * thing, and reading our own word back must not turn it into nothing.
		 */
		$said = str_replace( array( '_', '-' ), ' ', strtolower( $said ) );
		if ( '' === trim( $said ) ) {
			return '';
		}

		$map = array(
			'completed'    => array( 'completed', 'handover', 'delivered' ),
			'ready'        => array( 'ready', 'oc received', 'oc', 'possession', 'resale', 'move in', 'operational' ),
			'construction' => array( 'construction', 'under construction', 'uc', 'building' ),
			'new_launch'   => array( 'launch', 'upcoming', 'pre launch', 'prelaunch', 'teaser', 'new launch', 'ddjay' ),
			'planning'     => array( 'planning', 'proposed', 'approval' ),
		);

		foreach ( $map as $stage => $words ) {
			foreach ( $words as $word ) {
				// Whole words only: "block" must not be read as "OC".
				if ( preg_match( '/\b' . preg_quote( $word, '/' ) . '\b/', $said ) ) {
					return (string) $stage;
				}
			}
		}

		// "On request" and anything else we do not know: a stage nobody stated
		// is better left unsaid than guessed at.
		return '';
	}

	/**
	 * Residential, commercial, affordable — in the words a record stores.
	 *
	 * @param string $said What the sheet said.
	 * @return string
	 */
	private static function category_word( string $said ): string {
		$said = strtolower( $said );
		if ( '' === trim( $said ) ) {
			return '';
		}
		$map = array(
			'commercial'  => array( 'commercial', 'office', 'retail', 'sco', 'shop', 'high street', 'high-street' ),
			'affordable'  => array( 'affordable', 'ddjay', 'economy', 'budget' ),
			'mixed'       => array( 'mixed', 'residential + commercial', 'residential and commercial' ),
			'residential' => array( 'residential', 'housing', 'homes', 'apartment', 'villa' ),
		);
		foreach ( $map as $key => $words ) {
			foreach ( $words as $word ) {
				if ( preg_match( '/\b' . preg_quote( $word, '/' ) . '\b/', $said ) ) {
					return (string) $key;
				}
			}
		}
		return 'other';
	}

	/**
	 * Read a date out of whatever the sheet wrote.
	 *
	 * "Poss. Mar 2030" → 2030-03-01. "Poss. 2028" → 2028-01-01, and the
	 * website prints that back as "2028" (see Format::month_year), so nobody
	 * is told a day the sheet never mentioned.
	 *
	 * @param string $said What the sheet said.
	 * @return string YYYY-MM-DD, or empty when there is no date in it.
	 */
	private static function read_date( string $said ): string {
		$said = trim( preg_replace( '/\b(poss\.?|possession|handover|by|around|expected|approx\.?|approximately)\b/i', ' ', $said ) ?? '' );
		if ( '' === $said ) {
			return '';
		}
		if ( ! preg_match( '/\b(19|20)\d{2}\b/', $said, $found ) ) {
			return '';
		}
		$year = (string) $found[0];

		$months = array(
			'jan' => '01', 'feb' => '02', 'mar' => '03', 'apr' => '04', 'may' => '05', 'jun' => '06',
			'jul' => '07', 'aug' => '08', 'sep' => '09', 'oct' => '10', 'nov' => '11', 'dec' => '12',
		);
		$month  = '';
		foreach ( $months as $word => $number ) {
			if ( preg_match( '/\b' . $word . '/i', $said ) ) {
				$month = $number;
				break;
			}
		}
		if ( '' === $month && preg_match( '/\b(0?[1-9]|1[0-2])\/' . $year . '\b/', str_replace( '-', '/', $said ), $found_month ) ) {
			$month = str_pad( $found_month[1], 2, '0', STR_PAD_LEFT );
		}

		if ( '' === $month ) {
			// A year only. Stored as the first of January so it sorts; printed
			// as a year on the website.
			return $year . '-01-01';
		}

		$day = '01';
		if ( preg_match( '/\b(\d{1,2})\s*(st|nd|rd|th)?\s+(' . implode( '|', array_keys( $months ) ) . ')/i', $said, $found_day ) ) {
			$day = str_pad( (string) min( 28, max( 1, (int) $found_day[1] ) ), 2, '0', STR_PAD_LEFT );
		}

		return $year . '-' . $month . '-' . $day;
	}

	/**
	 * Split a cell of bullet points into one point per line.
	 *
	 * @param string $said Cell text.
	 * @return string
	 */
	private static function bullets( string $said ): string {
		$said = str_replace( array( "\r\n", "\r" ), "\n", $said );
		$parts = preg_split( '/\s*[•\x{2022}\x{25CF}\x{00B7}|]\s*/u', $said ) ?: array();
		if ( count( $parts ) < 2 ) {
			$parts = preg_split( '/\s*[;\n]\s*/u', $said ) ?: array( $said );
		}
		$parts = array_values( array_filter( array_map(
			static fn( $p ) => trim( preg_replace( '/\s+/u', ' ', (string) $p ) ?? '' ),
			$parts
		), static fn( $p ) => '' !== $p ) );

		return implode( "\n", array_slice( $parts, 0, 12 ) );
	}

	/**
	 * Create an import job — F6 adds bridge_type.
	 *
	 * @param string               $path    Stored file path.
	 * @param string               $kind    Record kind.
	 * @param array<string,string> $mapping Column mapping.
	 * @param string               $bridge  Bridge system key.
	 * @return int|WP_Error Job ID.
	 */
	public static function create_job( string $path, string $kind, array $mapping, string $bridge = '' ) {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return new WP_Error( 'estat_no_storage', __( 'The office database is not ready yet.', 'estat-os' ) );
		}
		if ( ! is_readable( $path ) ) {
			return new WP_Error( 'estat_missing_file', __( 'The uploaded file could not be found. Please upload it again.', 'estat-os' ) );
		}
		$kind    = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads' ), 'listings' );
		$preview = self::preview( $path, 0 );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}

		$hash  = (string) hash_file( 'sha256', $path );
		$table = Schema::table( 'estat_import_jobs' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$table,
			array(
				'created_at'   => $now,
				'updated_at'   => $now,
				'user_id'      => get_current_user_id(),
				'kind'         => $kind,
				'file_path'    => $path,
				'mapping'      => (string) wp_json_encode( array_map( array( Sanitize::class, 'text' ), $mapping ) ),
				'state'        => 'running',
				'total_rows'   => (int) $preview['total'],
				'file_hash'    => $hash,
				'bridge_type'  => Sanitize::choice( $bridge, array_keys( self::bridge_systems() ), '' ),
				'created_ids'  => wp_json_encode( array() ),
				'undo_data'    => wp_json_encode( array() ),
			)
		);
		$job_id = (int) $wpdb->insert_id;
		AuditLog::record( 'import.started', 'import', $job_id, array( 'kind' => $kind, 'rows' => $preview['total'], 'bridge' => $bridge ) );
		return $job_id;
	}

	/**
	 * Process one batch of an import job — F6 records undo data.
	 *
	 * @param int  $job_id   Job ID.
	 * @param bool $dry_run  Validate without writing.
	 * @param int  $start_at Read from this row instead of the stored progress.
	 *                       A dry run writes no progress, so it has to be told
	 *                       where to carry on from.
	 * @return array<string,mixed>|WP_Error Progress summary.
	 */
	public static function process_batch( int $job_id, bool $dry_run = false, int $start_at = -1 ) {
		global $wpdb;
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $job ) {
			return new WP_Error( 'estat_not_found', __( 'That import could not be found.', 'estat-os' ) );
		}
		if ( 'done' === $job['state'] && ! $dry_run ) {
			return self::summary( $job );
		}

		$handle = self::open( (string) $job['file_path'] );
		if ( is_wp_error( $handle ) ) {
			return $handle;
		}

		$mapping = json_decode( (string) $job['mapping'], true );
		$mapping = is_array( $mapping ) ? $mapping : array();
		$headers = fgetcsv( $handle, 0, ',', '"', '' );
		$headers = is_array( $headers ) ? array_map( 'strval', $headers ) : array();

		$skip_to   = $start_at >= 0 ? $start_at : (int) $job['processed_rows'];
		$processed = 0;
		$counts    = array( 'created' => (int) $job['created_count'], 'updated' => (int) $job['updated_count'], 'skipped' => (int) $job['skipped_count'] );
		$errors    = json_decode( (string) $job['errors'], true );
		$errors    = is_array( $errors ) ? $errors : array();

		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		$created_ids = is_array( $created_ids ) ? $created_ids : array();
		$undo_data = json_decode( (string) ( $job['undo_data'] ?? '[]' ), true );
		$undo_data = is_array( $undo_data ) ? $undo_data : array();

		$row_number = 0;
		while ( false !== ( $raw = fgetcsv( $handle, 0, ',', '"', '' ) ) ) { // phpcs:ignore
			++$row_number;
			if ( $row_number <= $skip_to ) {
				continue;
			}
			if ( $processed >= self::BATCH ) {
				break;
			}
			++$processed;

			$assoc  = self::translate_row( (string) $job['kind'], self::map_row( $headers, (array) $raw, $mapping ) );
			$result = self::import_row( (string) $job['kind'], $assoc, $dry_run, $created_ids, $undo_data );

			if ( is_wp_error( $result ) ) {
				if ( count( $errors ) < 500 ) {
					$errors[] = array(
						'row'     => $row_number + 1,
						'message' => $result->get_error_message(),
						'data'    => $assoc,
					);
				}
				++$counts['skipped'];
				continue;
			}
			++$counts[ $result ];
		}

		$position = $skip_to + $processed;
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$done = $position >= (int) $job['total_rows'] || 0 === $processed;

		if ( ! $dry_run ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$table,
				array(
					'updated_at'     => current_time( 'mysql', true ),
					'processed_rows' => $position,
					'created_count'  => $counts['created'],
					'updated_count'  => $counts['updated'],
					'skipped_count'  => $counts['skipped'],
					'errors'         => (string) wp_json_encode( $errors ),
					'created_ids'    => (string) wp_json_encode( $created_ids ),
					'undo_data'      => (string) wp_json_encode( $undo_data ),
					'state'          => $done ? 'done' : 'running',
				),
				array( 'id' => $job_id )
			);

			if ( $done ) {
				AuditLog::record( 'import.completed', 'import', $job_id, $counts );
			}
		} else {
			// Dry run summary without saving.
			return array(
				'job_id'    => $job_id,
				'state'     => $done ? 'done' : 'running',
				'total'     => (int) $job['total_rows'],
				'processed' => $position,
				'created'   => $counts['created'],
				'updated'   => $counts['updated'],
				'skipped'   => $counts['skipped'],
				'errors'    => $errors,
				'dry_run'   => true,
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$fresh = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		return self::summary( is_array( $fresh ) ? $fresh : $job );
	}

	/**
	 * Run an import to the end while the request has time left.
	 *
	 * One batch is 50 rows, so a 171-row master sheet used to need four visits
	 * to the screen — and anything the office did not come back for waited a
	 * day for the maintenance job. A file this size imports in seconds, so we
	 * keep taking batches until the file is done or the clock says stop; what
	 * is left over still gets finished by the daily job.
	 *
	 * @param int   $job_id  Job ID.
	 * @param float $seconds How long this request may keep going.
	 * @param bool  $dry_run Only report what would happen; write nothing.
	 * @return array<string,mixed>|WP_Error Last progress summary.
	 */
	public static function run_job( int $job_id, float $seconds = 25.0, bool $dry_run = false ) {
		$start = microtime( true );
		$last  = array();
		$tally = array( 'created' => 0, 'updated' => 0, 'skipped' => 0 );
		$seen  = 0;

		for ( $round = 0; $round < 200; $round++ ) {
			/*
			 * A dry run keeps no progress in the database, so each round is
			 * told where the last one stopped and the numbers are added up
			 * here. Without this, a dry run reported on the first fifty rows
			 * of a two-hundred-row file and called that a preview.
			 */
			$step = self::process_batch( $job_id, $dry_run, $dry_run ? $seen : -1 );
			if ( is_wp_error( $step ) ) {
				return $step;
			}

			if ( $dry_run ) {
				$tally['created'] += (int) ( $step['created'] ?? 0 );
				$tally['updated'] += (int) ( $step['updated'] ?? 0 );
				$tally['skipped'] += (int) ( $step['skipped'] ?? 0 );
				$seen              = (int) ( $step['processed'] ?? 0 );
				$last              = array_merge( $step, $tally );
			} else {
				$last = $step;
			}

			$left = (int) ( $last['total'] ?? 0 ) - (int) ( $last['processed'] ?? 0 );
			if ( 'done' === ( $last['state'] ?? '' ) || $left <= 0 ) {
				break;
			}
			if ( ( microtime( true ) - $start ) > $seconds ) {
				break;
			}
		}

		if ( $dry_run && $last ) {
			$last['dry_run'] = true;
			$last['state']   = ( (int) ( $last['processed'] ?? 0 ) >= (int) ( $last['total'] ?? 0 ) ) ? 'done' : 'running';
		}

		return $last;
	}

	/**
	 * Undo an import job — trash created posts, restore updated from snapshot if available.
	 *
	 * @param int $job_id Job ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function undo_job( int $job_id ) {
		global $wpdb;
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $job ) {
			return new WP_Error( 'estat_not_found', __( 'That import could not be found.', 'estat-os' ) );
		}
		if ( 'undone' === $job['state'] ) {
			return new WP_Error( 'estat_already_undone', __( 'This import has already been undone.', 'estat-os' ) );
		}

		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		$created_ids = is_array( $created_ids ) ? $created_ids : array();
		$undo_data = json_decode( (string) ( $job['undo_data'] ?? '[]' ), true );
		$undo_data = is_array( $undo_data ) ? $undo_data : array();

		$trashed = 0;
		$restored = 0;

		foreach ( $created_ids as $pid ) {
			$pid = (int) $pid;
			if ( $pid > 0 && get_post( $pid ) ) {
				wp_trash_post( $pid );
				++$trashed;
			}
		}

		foreach ( $undo_data as $snap ) {
			if ( empty( $snap['post_id'] ) ) { continue; }
			$post_id = (int) $snap['post_id'];
			$post = get_post( $post_id );
			if ( ! $post ) { continue; }
			/*
			 * One record, counted once. A snapshot carries both the words and
			 * the fields, and counting each half separately made an undo of
			 * 171 rows report 342 records put back.
			 */
			$put_back = false;

			// Restore title/content if snapshot has them.
			if ( isset( $snap['post_title'] ) || isset( $snap['post_content'] ) ) {
				wp_update_post( array(
					'ID'           => $post_id,
					'post_title'   => $snap['post_title'] ?? $post->post_title,
					'post_content' => $snap['post_content'] ?? $post->post_content,
				) );
				$put_back = true;
			}
			// Restore meta snapshot.
			if ( ! empty( $snap['meta'] ) && is_array( $snap['meta'] ) ) {
				foreach ( $snap['meta'] as $k => $v ) {
					update_post_meta( $post_id, $k, $v );
				}
				$put_back = true;
			}

			if ( $put_back ) {
				++$restored;
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			$table,
			array(
				'updated_at' => current_time( 'mysql', true ),
				'state'      => 'undone',
			),
			array( 'id' => $job_id )
		);

		AuditLog::record( 'import.undone', 'import', $job_id, array( 'trashed' => $trashed, 'restored' => $restored ) );

		return array(
			'job_id'   => $job_id,
			'trashed'  => $trashed,
			'restored' => $restored,
			'state'    => 'undone',
		);
	}

	/**
	 * Build a progress summary — F6 includes undo info.
	 *
	 * @param array<string,mixed> $job Job row.
	 * @return array<string,mixed>
	 */
	private static function summary( array $job ): array {
		$errors = json_decode( (string) $job['errors'], true );
		$created_ids = json_decode( (string) ( $job['created_ids'] ?? '[]' ), true );
		return array(
			'job_id'       => (int) $job['id'],
			'state'        => (string) $job['state'],
			'total'        => (int) $job['total_rows'],
			'processed'    => (int) $job['processed_rows'],
			'created'      => (int) $job['created_count'],
			'updated'      => (int) $job['updated_count'],
			'skipped'      => (int) $job['skipped_count'],
			'errors'       => is_array( $errors ) ? $errors : array(),
			'created_ids'  => is_array( $created_ids ) ? $created_ids : array(),
			'bridge_type'  => $job['bridge_type'] ?? '',
			'can_undo'     => ! empty( $created_ids ) && 'undone' !== $job['state'] && 'done' === $job['state'],
		);
	}

	/**
	 * Turn a raw CSV row into a mapped associative array.
	 *
	 * @param string[]             $headers Header row.
	 * @param array<int,mixed>     $raw     Raw values.
	 * @param array<string,string> $mapping Column => header.
	 * @return array<string,string>
	 */
	private static function map_row( array $headers, array $raw, array $mapping ): array {
		$by_header = array();
		foreach ( $headers as $index => $header ) {
			$by_header[ $header ] = isset( $raw[ $index ] ) ? Sanitize::text( (string) $raw[ $index ] ) : '';
		}
		$out = array();
		foreach ( $mapping as $column => $header ) {
			$out[ $column ] = $by_header[ $header ] ?? '';
		}
		return $out;
	}

	/**
	 * Import one row — F6 records undo data.
	 *
	 * @param string                $kind    Record kind.
	 * @param array<string,string>  $row     Mapped row.
	 * @param bool                  $dry_run Validate only.
	 * @param array<int,int>        $created_ids Reference to created IDs array.
	 * @param array<int,array>      $undo_data Reference to undo snapshots.
	 * @return string|WP_Error 'created', 'updated' or an error.
	 */
	private static function import_row( string $kind, array $row, bool $dry_run, array &$created_ids = array(), array &$undo_data = array() ) {
		switch ( $kind ) {
			case 'projects':
				$existing = Projects::find_by_external_id( $row['external_id'] ?? '' );
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['title'] ?? '' ) ) && ! $existing
						? new WP_Error( 'estat_missing_title', __( 'This row has no project name.', 'estat-os' ) )
						: ( $existing ? 'updated' : 'created' );
				}
				if ( $existing ) {
					// Snapshot for undo.
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
							'meta'         => array(
								'_estat_external_id' => get_post_meta( $existing, '_estat_external_id', true ),
							),
						);
					}
				}
				$result = Projects::save( $row, $existing );
				if ( is_wp_error( $result ) ) { return $result; }
				if ( ! $existing ) { $created_ids[] = (int) $result; }
				return $existing ? 'updated' : 'created';

			case 'agents':
				$existing = self::find_agent( $row['external_id'] ?? '', $row['email'] ?? '' );
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['title'] ?? '' ) ) && ! $existing
						? new WP_Error( 'estat_missing_name', __( 'This row has no name.', 'estat-os' ) )
						: ( $existing ? 'updated' : 'created' );
				}
				if ( $existing ) {
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
						);
					}
				}
				$result = Agents::save( $row, $existing );
				if ( is_wp_error( $result ) ) { return $result; }
				if ( ! $existing ) { $created_ids[] = (int) $result; }
				return $existing ? 'updated' : 'created';

			case 'leads':
				if ( $dry_run ) {
					return '' === trim( (string) ( $row['name'] ?? '' ) )
						? new WP_Error( 'estat_missing_name', __( 'This row has no name.', 'estat-os' ) )
						: 'created';
				}
				$listing_id = Listings::find_by_external_id( $row['listing_ref'] ?? '' );
				$lead       = Leads::create(
					array(
						'name'            => $row['name'] ?? '',
						'phone'           => $row['phone'] ?? '',
						'email'           => $row['email'] ?? '',
						'message'         => $row['message'] ?? '',
						'source'          => 'import',
						'listing_id'      => $listing_id,
						'idempotency_key' => 'import|' . md5( wp_json_encode( $row ) ),
					)
				);
				return is_wp_error( $lead ) ? $lead : 'created';

			case 'listings':
			default:
				$existing = Listings::find_by_external_id( $row['external_id'] ?? '' );
				$input    = $row;
				if ( isset( $row['project_ref'] ) && '' !== $row['project_ref'] ) {
					$input['project_id'] = Projects::find_by_external_id( $row['project_ref'] );
				}
				if ( isset( $row['agent_ref'] ) && '' !== $row['agent_ref'] ) {
					$input['agent_id'] = self::find_agent( $row['agent_ref'], '' );
				}
				if ( isset( $row['featured'] ) ) {
					$input['featured'] = in_array( strtolower( $row['featured'] ), array( 'yes', '1', 'true', 'y' ), true );
				}
				if ( isset( $row['investment'] ) ) {
					$input['investment'] = in_array( strtolower( $row['investment'] ), array( 'yes', '1', 'true', 'y' ), true );
				}
				$input['status'] = Sanitize::choice( $row['status'] ?? 'draft', array( 'draft', 'publish' ), 'draft' );

				if ( $dry_run ) {
					$errors = Listings::validate( $input, $existing );
					if ( $errors ) {
						return new WP_Error( 'estat_invalid_row', implode( ' ', $errors ) );
					}
					return $existing ? 'updated' : 'created';
				}

				if ( $existing ) {
					$post = get_post( $existing );
					if ( $post ) {
						$undo_data[] = array(
							'post_id'      => $existing,
							'post_title'   => $post->post_title,
							'post_content' => $post->post_content,
							'meta'         => array(
								'_estat_price'       => get_post_meta( $existing, '_estat_price', true ),
								'_estat_external_id' => get_post_meta( $existing, '_estat_external_id', true ),
							),
						);
					}
				}

				$result = Listings::save( $input, $existing );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
				SearchIndex::index_listing( (int) $result );
				if ( ! $existing ) {
					$created_ids[] = (int) $result;
				}
				return $existing ? 'updated' : 'created';
		}
	}

	/**
	 * Find an agent by reference number or email.
	 *
	 * @param string $external_id Reference.
	 * @param string $email       Email.
	 * @return int
	 */
	private static function find_agent( string $external_id, string $email ): int {
		$external_id = Sanitize::text( $external_id );
		if ( '' !== $external_id ) {
			$found = get_posts(
				array(
					'post_type'     => PostTypes::AGENT,
					'numberposts'   => 1,
					'fields'        => 'ids',
					'meta_key'      => '_estat_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'    => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery
					'no_found_rows' => true,
				)
			);
			if ( $found ) {
				return (int) $found[0];
			}
		}
		$email = Sanitize::email( $email );
		if ( '' !== $email ) {
			$found = get_posts(
				array(
					'post_type'     => PostTypes::AGENT,
					'numberposts'   => 1,
					'fields'        => 'ids',
					'meta_key'      => '_estat_email', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'    => $email, // phpcs:ignore WordPress.DB.SlowDBQuery
					'no_found_rows' => true,
				)
			);
			if ( $found ) {
				return (int) $found[0];
			}
		}
		return 0;
	}

	/**
	 * Export records as CSV text.
	 *
	 * @param string $kind  Record kind.
	 * @param int    $limit Maximum rows.
	 * @return string CSV content.
	 */
	public static function export( string $kind, int $limit = 5000 ): string {
		$kind    = Sanitize::choice( $kind, array( 'listings', 'projects', 'agents', 'leads', 'visits' ), 'listings' );
		$columns = array_keys( self::columns( $kind ) );
		$rows    = array();

		if ( 'visits' === $kind ) {
			$visits = Visits::query( array( 'per_page' => max( 1, min( 500, $limit ) ), 'page' => 1 ) );

			foreach ( (array) $visits['items'] as $visit ) {
				$lead       = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
				$listing_id = (int) $visit['listing_id'];

				$rows[] = array(
					'scheduled_at' => (string) $visit['scheduled_at'],
					'name'         => $lead ? (string) $lead['name'] : '',
					'phone'        => $lead ? (string) $lead['phone'] : '',
					'listing_ref'  => $listing_id > 0 ? (string) get_post_meta( $listing_id, '_estat_external_id', true ) : '',
					'listing_name' => $listing_id > 0 ? (string) get_the_title( $listing_id ) : '',
					'agent'        => (int) $visit['agent_id'] > 0 ? (string) get_the_title( (int) $visit['agent_id'] ) : '',
					'outcome'      => (string) $visit['outcome'],
					'notes'        => (string) ( $visit['notes'] ?? '' ),
				);
			}
		} elseif ( 'leads' === $kind ) {
			$leads = Leads::query( array( 'per_page' => min( 100, $limit ), 'page' => 1 ) );
			foreach ( $leads['items'] as $lead ) {
				$rows[] = array(
					'name'        => $lead['name'],
					'phone'       => $lead['phone'],
					'email'       => $lead['email'],
					'message'     => $lead['message'],
					'source'      => $lead['source'],
					'listing_ref' => (int) $lead['listing_id'] > 0 ? (string) get_post_meta( (int) $lead['listing_id'], '_estat_external_id', true ) : '',
					'status'      => $lead['status'],
				);
			}
		} else {
			$map   = array( 'listings' => PostTypes::LISTING, 'projects' => PostTypes::PROJECT, 'agents' => PostTypes::AGENT );
			$posts = get_posts(
				array(
					'post_type'      => $map[ $kind ],
					'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page' => max( 1, min( 5000, $limit ) ),
					'no_found_rows'  => true,
					'orderby'        => 'ID',
					'order'          => 'ASC',
				)
			);
			foreach ( $posts as $post ) {
				$row = array();
				foreach ( $columns as $column ) {
					$row[ $column ] = self::export_value( $post, $column, $kind );
				}
				$rows[] = $row;
			}
		}

		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $handle ) {
			return '';
		}
		fputcsv( $handle, $columns, ',', '"', '' );
		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $column ) {
				$line[] = self::safe_cell( (string) ( $row[ $column ] ?? '' ) );
			}
			fputcsv( $handle, $line, ',', '"', '' );
		}
		rewind( $handle );
		$csv = (string) stream_get_contents( $handle );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $csv;
	}

	/**
	 * Export preview — first N rows without downloading.
	 *
	 * @param string $kind  Record kind.
	 * @param int    $limit Rows to preview.
	 * @return array{columns:string[],rows:array<int,array<string,string>>,total:int}
	 */
	public static function export_preview( string $kind, int $limit = 5 ): array {
		$csv = self::export( $kind, $limit );
		$lines = explode( "\n", trim( $csv ) );
		$columns = array();
		$rows = array();
		if ( $lines ) {
			$columns = str_getcsv( array_shift( $lines ) );
			foreach ( array_slice( $lines, 0, $limit ) as $line ) {
				if ( '' === trim( $line ) ) { continue; }
				$vals = str_getcsv( $line );
				$assoc = array();
				foreach ( $columns as $i => $col ) {
					$assoc[ $col ] = $vals[ $i ] ?? '';
				}
				$rows[] = $assoc;
			}
		}
		return array( 'columns' => $columns, 'rows' => $rows, 'total' => count( $rows ) );
	}

	/**
	 * Resolve one export cell.
	 *
	 * @param \WP_Post $post   Post.
	 * @param string   $column Column name.
	 * @param string   $kind   Record kind.
	 * @return string
	 */
	private static function export_value( \WP_Post $post, string $column, string $kind ): string {
		switch ( $column ) {
			case 'title':
				return $post->post_title;
			case 'description':
			case 'bio':
				return wp_strip_all_tags( $post->post_content );
			case 'status':
				return $post->post_status;
			case 'locality':
				$terms = wp_get_object_terms( $post->ID, \EstatOS\Data\Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); if (is_wp_error($terms)) $terms = array();
				return is_wp_error( $terms ) ? '' : implode( ', ', $terms );
			case 'amenities':
				$terms = wp_get_object_terms( $post->ID, \EstatOS\Data\Taxonomies::AMENITY, array( 'fields' => 'names' ) ); if (is_wp_error($terms)) $terms = array();
				return is_wp_error( $terms ) ? '' : implode( ', ', $terms );
			case 'project_ref':
				$project_id = (int) get_post_meta( $post->ID, '_estat_project_id', true );
				return $project_id ? (string) get_post_meta( $project_id, '_estat_external_id', true ) : '';
			case 'agent_ref':
				$agent_id = (int) get_post_meta( $post->ID, '_estat_agent_id', true );
				return $agent_id ? (string) get_post_meta( $agent_id, '_estat_external_id', true ) : '';
			case 'featured':
			case 'investment':
				return get_post_meta( $post->ID, '_estat_' . $column, true ) ? 'yes' : 'no';
			default:
				$value = get_post_meta( $post->ID, '_estat_' . $column, true );
				if ( is_array( $value ) ) {
					return implode( ',', array_map( 'strval', $value ) );
				}
				return (string) $value;
		}
	}

	/**
	 * Make one cell safe to open in a spreadsheet.
	 *
	 * @param string $value Raw cell value.
	 * @return string Safe cell value.
	 */
	private static function safe_cell( string $value ): string {
		if ( '' === $value ) {
			return $value;
		}
		if ( is_numeric( $value ) ) {
			return $value;
		}
		$first = substr( $value, 0, 1 );
		if ( in_array( $first, array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Open a CSV file safely.
	 *
	 * @param string $path Path.
	 * @return resource|WP_Error
	 */
	private static function open( string $path ) {
		$uploads = wp_get_upload_dir();
		$real    = realpath( $path );
		$base    = realpath( (string) $uploads['basedir'] );
		if ( ! $real || ! $base || 0 !== strpos( $real, $base ) ) {
			return new WP_Error( 'estat_bad_path', __( 'That file is not in the uploads folder, so we cannot read it.', 'estat-os' ) );
		}
		$handle = fopen( $real, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $handle ) {
			return new WP_Error( 'estat_unreadable', __( 'We could not open the file. Please upload it again.', 'estat-os' ) );
		}
		return $handle;
	}

	/**
	 * The most recent import jobs, newest first.
	 *
	 * @param int $limit Maximum rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function recent_jobs( int $limit = 10 ): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array();
		}
		$table = Schema::table( 'estat_import_jobs' );
		$limit = Sanitize::int( $limit, 1, 100 );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Get one job.
	 *
	 * @param int $job_id Job ID.
	 * @return array<string,mixed>|null
	 */
	public static function get_job( int $job_id ): ?array {
		global $wpdb;
		if ( ! Schema::healthy() ) { return null; }
		$table = Schema::table( 'estat_import_jobs' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Store an uploaded CSV in a private folder inside uploads.
	 *
	 * @param array<string,mixed> $file One entry from $_FILES.
	 * @return string|WP_Error Stored path.
	 */
	public static function store_upload( array $file ) {
		if ( ! isset( $file['tmp_name'], $file['name'] ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			return new WP_Error( 'estat_no_file', __( 'Please choose a CSV file to upload.', 'estat-os' ) );
		}
		$check = wp_check_filetype( (string) $file['name'], array( 'csv' => 'text/csv' ) );
		if ( 'csv' !== $check['ext'] ) {
			return new WP_Error( 'estat_bad_type', __( 'Only CSV files can be imported. Save your spreadsheet as CSV and try again.', 'estat-os' ) );
		}
		if ( (int) ( $file['size'] ?? 0 ) > 20 * MB_IN_BYTES ) {
			return new WP_Error( 'estat_too_big', __( 'That file is larger than 20 MB. Please split it into smaller files.', 'estat-os' ) );
		}

		$uploads = wp_get_upload_dir();
		$dir     = trailingslashit( $uploads['basedir'] ) . 'estat-imports';
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'estat_no_dir', __( 'We could not create a folder for imports.', 'estat-os' ) );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "Deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		$name = wp_unique_filename( $dir, 'import-' . gmdate( 'Ymd-His' ) . '.csv' );
		$path = trailingslashit( $dir ) . $name;
		if ( ! move_uploaded_file( (string) $file['tmp_name'], $path ) ) {
			return new WP_Error( 'estat_move_failed', __( 'We could not save the uploaded file.', 'estat-os' ) );
		}
		return $path;
	}
}
