<?php
/**
 * Plugin bootstrap and module registry.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS;

defined( 'ABSPATH' ) || exit;

/**
 * Central container. Deliberately tiny: an explicit list of modules, each with
 * a register() method. No magic, no service container, no reflection.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Registered modules keyed by short name.
	 *
	 * @var array<string,object>
	 */
	private array $modules = array();

	/**
	 * Whether boot() already ran.
	 *
	 * @var bool
	 */
	private bool $booted = false;

	/**
	 * Private constructor.
	 */
	private function __construct() {}

	/**
	 * Instance accessor.
	 *
	 * @return Plugin
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Boot the plugin.
	 *
	 * @return void
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		// Order matters: the language module registers the plugin_locale filter,
		// so it has to be in place *before* the translation file is chosen.
		// Loaded the other way round WordPress silently picks English and the
		// shipped Hinglish translation never gets used.
		add_action( 'plugins_loaded', array( $this, 'register_modules' ), 1 );
		// WordPress loads the site language again while it boots (and the theme
		// loads its own). Both of those reset the language of every plugin to
		// the site language, so the office language has to be put back twice:
		// right after the theme is ready, and once more at the very end of the
		// boot — otherwise the shipped Hinglish translation never shows up.
		add_action( 'after_setup_theme', array( $this, 'load_textdomain' ), 999 );
		add_action( 'wp_loaded', array( $this, 'load_textdomain' ), 999 );
		add_action( 'init', array( Install\Migrator::class, 'maybe_upgrade' ), 1 );
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain(): void {
		$locale = I18n\Language::resolve();
		$mofile = ESTAT_DIR . 'languages/estat-os-' . $locale . '.mo';

		if ( ! is_readable( $mofile ) ) {
			load_plugin_textdomain( 'estat-os', false, dirname( ESTAT_BASENAME ) . '/languages' );
			return;
		}

		// Something may already have loaded the English file for this domain
		// (WordPress loads it just in time). Clear it so the chosen language wins.
		if ( function_exists( 'unload_textdomain' ) ) {
			unload_textdomain( 'estat-os' );
		}

		load_textdomain( 'estat-os', $mofile, $locale );
	}

	/**
	 * Reload translations after the language was changed inside this request.
	 *
	 * @return void
	 */
	public static function reload_textdomain(): void {
		if ( method_exists( I18n\Language::class, 'reset' ) ) {
			I18n\Language::reset();
		}
		self::instance()->load_textdomain();
	}

	/**
	 * Instantiate and register every module.
	 *
	 * @return void
	 */
	public function register_modules(): void {
		$classes = array(
			'i18n'        => I18n\Language::class,
			'settings'    => Settings\Settings::class,
			'roles'       => Security\Roles::class,
			'post_types'  => Data\PostTypes::class,
			'taxonomies'  => Data\Taxonomies::class,
			'meta'        => Data\Meta::class,
			'listings'    => Data\Listings::class,
			'bin'         => Data\Bin::class,
			'projects'    => Data\Projects::class,
			'agents'      => Data\Agents::class,
			'leads'       => Leads\Leads::class,
			'lead_events' => Leads\LeadEvents::class,
			'visits'      => Leads\Visits::class,
			'forms'       => Forms\Forms::class,
			'submissions' => Forms\Submissions::class,
			'search'      => Search\SearchIndex::class,
			'query'       => Search\Query::class,
			'alerts'      => Search\Alerts::class,
			'templates'   => Data\Templates::class,
			'audit'       => Audit\AuditLog::class,
			'requests'    => Field\Requests::class,
			'webhooks'    => Webhooks\Webhooks::class,
			'notify'      => Notifications\Notifier::class,
			'csv'         => Csv\Spreadsheet::class,
			'rest'        => Rest\RestApi::class,
			'frontend'    => Frontend\Frontend::class,
			'shortcodes'  => Frontend\Shortcodes::class,
			'pages'       => Frontend\Pages::class,
			'seo'         => Frontend\Schema::class,
			'seo_contract' => Frontend\Seo::class,
			'share'       => Frontend\Share::class,
			'whatsapp'    => Frontend\WhatsApp::class,
			'cron'        => Cron\Scheduler::class,
			'privacy'     => Privacy\Privacy::class,
			'practice'    => Support\PracticeMode::class,
			'design_tokens' => Support\DesignTokens::class,
			'pocket'      => Pocket\Pocket::class,
			'office'      => Office\Dashboard::class,
			'elementor'   => Integrations\Elementor\Bridge::class,
		);

		if ( is_admin() ) {
			$classes['admin'] = Admin\Admin::class;
		}

		/**
		 * Filter the module class map before instantiation.
		 *
		 * @param array<string,string> $classes Module map.
		 */
		$classes = (array) apply_filters( 'estat_modules', $classes );

		foreach ( $classes as $key => $class_name ) {
			if ( ! class_exists( $class_name ) ) {
				continue;
			}
			$module = new $class_name();
			if ( method_exists( $module, 'register' ) ) {
				$module->register();
			}
			$this->modules[ $key ] = $module;
		}

		/**
		 * Fires once all modules are registered.
		 *
		 * @param Plugin $plugin Plugin instance.
		 */
		do_action( 'estat_loaded', $this );
	}

	/**
	 * Get a registered module.
	 *
	 * @param string $key Module key.
	 * @return object|null
	 */
	public function module( string $key ) {
		return $this->modules[ $key ] ?? null;
	}
}
