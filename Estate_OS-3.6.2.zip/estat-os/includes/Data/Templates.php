<?php
/**
 * Templates — drag-drop order of listing page blocks.
 *
 * the office requirement #7: Templates (listing page ke blocks ka order drag se).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Install\Schema;
use EstatOS\Support\Sanitize;

defined( 'ABSPATH' ) || exit;

final class Templates {

	/**
	 * Default blocks for a listing or project page — F7 supports both.
	 *
	 * @param string $type Type: listing|project.
	 * @return array<int,array<string,mixed>>
	 */
	public static function default_blocks( string $type = 'listing' ): array {
		if ( 'project' === $type ) {
			return array(
				array( 'id' => 'header',      'label' => __( 'Header — project name, locality, price range', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'cover',       'label' => __( 'Cover photo', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'facts',       'label' => __( 'Facts — builder, status, units', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'description', 'label' => __( 'Description', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'gallery',     'label' => __( 'Gallery', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'floor_plans', 'label' => __( 'Floor plans', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'amenities',   'label' => __( 'Amenities', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'location',    'label' => __( 'Location & Map', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'units',       'label' => __( 'Available units / listings in project', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'share',       'label' => __( 'Share row', 'estat-os' ), 'enabled' => true ),
				array( 'id' => 'enquiry',     'label' => __( 'Enquiry form', 'estat-os' ), 'enabled' => true ),
			);
		}
		return array(
			array( 'id' => 'header',      'label' => __( 'Header — title, locality, price', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'signals',     'label' => __( 'Verified badge + days listed', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'cover',       'label' => __( 'Cover photo', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'share',       'label' => __( 'Share row — WhatsApp, Copy, Print', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'facts',       'label' => __( 'Facts — type, size, bedrooms', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'costs',       'label' => __( 'Other costs — deposit, maintenance', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'emi',         'label' => __( 'EMI Calculator', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'description', 'label' => __( 'Description', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'gallery',     'label' => __( 'Gallery', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'video',       'label' => __( 'Video & 360 Tour', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'documents',   'label' => __( 'Floor plans & Brochures', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'map',         'label' => __( 'Map', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'agent',       'label' => __( 'Agent card', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'enquiry',     'label' => __( 'Enquiry form + privacy note', 'estat-os' ), 'enabled' => true ),
			array( 'id' => 'locality',    'label' => __( 'Locality info & nearby listings', 'estat-os' ), 'enabled' => false ),
		);
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {}

	/**
	 * Get active template blocks.
	 *
	 * @param string $type Template type.
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_blocks( string $type = 'listing' ): array {
		global $wpdb;
		$table = Schema::table( 'estat_templates' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE type = %s AND is_default = 1 LIMIT 1", $type ), ARRAY_A );
		if ( $row && ! empty( $row['blocks'] ) ) {
			$decoded = json_decode( (string) $row['blocks'], true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		return self::default_blocks( $type );
	}

	/**
	 * Save template blocks.
	 *
	 * @param array<int,array<string,mixed>> $blocks Blocks.
	 * @param string                         $type   Type.
	 * @return int Template ID.
	 */
	public static function save_blocks( array $blocks, string $type = 'listing' ): int {
		global $wpdb;
		$table = Schema::table( 'estat_templates' );
		$now   = current_time( 'mysql', true );

		// Sanitize blocks.
		$clean = array();
		foreach ( $blocks as $b ) {
			if ( ! isset( $b['id'] ) ) {
				continue;
			}
			$clean[] = array(
				'id'      => Sanitize::text( $b['id'] ),
				'label'   => Sanitize::text( $b['label'] ?? $b['id'] ),
				'enabled' => (bool) ( $b['enabled'] ?? true ),
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE type = %s AND is_default = 1 LIMIT 1", $type ) );

		if ( $existing ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$table,
				array(
					'blocks'     => wp_json_encode( $clean ),
					'updated_at' => $now,
				),
				array( 'id' => $existing )
			);
			return $existing;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$table,
			array(
				'created_at' => $now,
				'updated_at' => $now,
				'name'       => 'Default ' . ucfirst( $type ),
				'slug'       => 'default-' . $type,
				'type'       => $type,
				'blocks'     => wp_json_encode( $clean ),
				'is_default' => 1,
			)
		);
		return (int) $wpdb->insert_id;
	}
}
