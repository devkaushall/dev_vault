<?php
/**
 * Listing repository: create, update, read, completeness and cover sync.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Audit\AuditLog;
use EstatOS\Search\SearchIndex;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;
use WP_Error;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * All listing writes go through save() so validation, derived values, indexing
 * and audit logging can never be skipped by a different entry point.
 */
final class Listings {

	/**
	 * Meta key holding the office verification state.
	 *
	 * Writing it requires the `estat_verify_listings` capability, so that an
	 * agent cannot award their own listing the office's badge of trust.
	 *
	 * @var string
	 */
	/**
	 * The most any money field may hold.
	 *
	 * One hundred billion in the site's currency: far beyond any single
	 * property, and well inside what a float stores exactly.
	 */
	public const MAX_MONEY = 100000000000.0;

	/**
	 * Fields that count things, and the most each may hold.
	 *
	 * @return array<string,int>
	 */
	public static function counted_fields(): array {
		return array(
			'bedrooms'   => 50,
			'bathrooms'  => 50,
			'balconies'  => 30,
			'parking'    => 50,
			'floor'      => 200,
			'total_floors' => 200,
		);
	}

	public const VERIFICATION_KEY = '_estat_verification';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'save_post_' . PostTypes::LISTING, array( __CLASS__, 'on_save_post' ), 20, 3 );
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete' ), 10, 1 );
	}

	/**
	 * Create or update a listing from a raw input array.
	 *
	 * @param array<string,mixed> $input   Raw input (post fields plus meta keys without prefix or with).
	 * @param int                 $post_id Existing listing ID, 0 to create.
	 * @return int|WP_Error Listing ID or error.
	 */
	public static function save( array $input, int $post_id = 0 ) {
		$errors = self::validate( $input, $post_id );
		if ( ! empty( $errors ) ) {
			$error = new WP_Error();
			foreach ( $errors as $field => $message ) {
				$error->add( 'estat_invalid_' . $field, $message, array( 'field' => $field ) );
			}
			return $error;
		}

		/*
		 * One money box on the screen means the number can arrive under either
		 * name: the office types a price for a sale and a monthly rent for a
		 * rental, in the same field. The answer to "for sale or rent" decides
		 * where it belongs.
		 *
		 * Only folded when the form posted exactly one of the two, so a form
		 * that asks both questions — and a partial update from the REST API —
		 * is left exactly as it was.
		 */
		$offer = Sanitize::text( $input['offer'] ?? $input['_estat_offer'] ?? '' );
		$has_price = array_key_exists( '_estat_price', $input ) || array_key_exists( 'price', $input );
		$has_rent  = array_key_exists( '_estat_rent', $input ) || array_key_exists( 'rent', $input );

		/*
		 * Read the number under either name. A form may send the short name
		 * ("rent", "price") or the stored name ("_estat_rent"); reading only
		 * the stored one silently threw the figure away whenever a short name
		 * arrived - the rent box was filled in, saved, and the website then
		 * said "Price on request".
		 */
		$typed_price = $input['_estat_price'] ?? $input['price'] ?? '';
		$typed_rent  = $input['_estat_rent'] ?? $input['rent'] ?? '';

		if ( $has_price && ! $has_rent && in_array( $offer, array( 'rent', 'lease' ), true ) ) {
			$input['_estat_rent']  = $typed_price;
			$input['rent']         = $typed_price;
			$input['_estat_price'] = '';
			$input['price']        = '';
		} elseif ( $has_rent && ! $has_price ) {
			$input['_estat_price'] = $typed_rent;
			$input['price']        = $typed_rent;
			$input['_estat_rent']  = '';
			$input['rent']         = '';
		}

		$title = Sanitize::title( $input['title'] ?? '' );
		$status = Sanitize::choice( $input['status'] ?? 'draft', array( 'draft', 'publish', 'pending', 'private' ), 'draft' );
		if ( 'publish' === $status && ! current_user_can( 'estat_publish_listings' ) ) {
			$status = 'draft';
		}
		// F2: when verification_mode required, only office_verified may go live unless verifier.
		$mode = \EstatOS\Settings\Settings::get( 'verification_mode', 'optional' );
		if ( 'required' === $mode && 'publish' === $status ) {
			$ver = $input['verification'] ?? $input['_estat_verification'] ?? '';
			// If editing existing, check stored value if not in input.
			if ( '' === $ver && $post_id > 0 ) {
				$ver = (string) get_post_meta( $post_id, '_estat_verification', true );
			}
			if ( 'office_verified' !== $ver && ! current_user_can( 'estat_verify_listings' ) ) {
				// Agent trying to publish unverified while required → force pending for office review.
				$status = 'pending';
			}
		}

		$postarr = array(
			'post_type'    => PostTypes::LISTING,
			'post_title'   => $title,
			'post_content' => Sanitize::html( $input['description'] ?? '' ),
			'post_excerpt' => Sanitize::textarea( $input['summary'] ?? '' ),
			'post_status'  => $status,
		);

		if ( $post_id > 0 ) {
			$existing = get_post( $post_id );
			if ( ! $existing || PostTypes::LISTING !== $existing->post_type ) {
				return new WP_Error( 'estat_not_found', __( 'That listing could not be found.', 'estat-os' ) );
			}
			$postarr['ID'] = $post_id;

			// Snapshot what is there now, before any of it is overwritten.
			Undo::capture( $post_id );

			// Same partial-update rule as the text fields, learned the hard
			// way: approve() sends only the changed fields, and an absent
			// title used to fall through as an EMPTY one — which real
			// WordPress answers by inventing a title from the description.
			if ( ! isset( $input['title'] ) ) {
				unset( $postarr['post_title'] );
			}
			if ( ! isset( $input['description'] ) ) {
				unset( $postarr['post_content'] );
			}
			if ( ! isset( $input['summary'] ) ) {
				unset( $postarr['post_excerpt'] );
			}
			$result = wp_update_post( $postarr, true );
		} else {
			$result = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$listing_id = (int) $result;

		self::save_meta( $listing_id, $input );
		self::save_terms( $listing_id, $input );

		if ( isset( $input['cover_id'] ) ) {
			self::set_cover( $listing_id, Sanitize::int( $input['cover_id'] ) );
		}

		if ( Settings::get( 'practice_mode' ) && 0 === $post_id ) {
			update_post_meta( $listing_id, '_estat_practice', 1 );
		}

		self::refresh_derived( $listing_id );

		AuditLog::record(
			$post_id > 0 ? 'listing.updated' : 'listing.created',
			'listing',
			$listing_id,
			array( 'status' => $status )
		);
		// F2: audit verified badge "humne khud dekha"
		$ver_after = (string) get_post_meta( $listing_id, '_estat_verification', true );
		if ( 'office_verified' === $ver_after ) {
			$ver_before = $post_id > 0 ? (string) get_post_meta( $post_id, '_estat_verification', true ) : '';
			if ( 'office_verified' !== $ver_before || 0 === $post_id ) {
				AuditLog::record( 'listing.verified', 'listing', $listing_id, array( 'by' => get_current_user_id() ) );
				/**
				 * Fires when office marks verified — "humne khud dekha" tick.
				 *
				 * @param int $listing_id Listing ID.
				 */
				do_action( 'estat_listing_verified', $listing_id );
			}
		}
		if ( 'pending' === $status ) {
			AuditLog::record( 'listing.submitted', 'listing', $listing_id, array() );
			/**
			 * Fires when a listing is parked and is waiting for the office
			 * to approve it.
			 *
			 * @param int $listing_id Listing ID.
			 */
			do_action( 'estat_listing_needs_approval', $listing_id );
		}
		if ( 'publish' === $status ) {
			AuditLog::record( 'listing.published', 'listing', $listing_id, array() );
			/**
			 * the office v3: fire publish hook for search alerts and webhooks.
			 *
			 * @param int   $listing_id Listing ID.
			 * @param array $data       Listing array.
			 */
			do_action( 'estat_listing_published', $listing_id, array( 'title' => $title ) );
		}

		return $listing_id;
	}

	/**
	 * Validate raw listing input.
	 *
	 * @param array<string,mixed> $input   Raw input.
	 * @param int                 $post_id Existing ID.
	 * @return array<string,string> Field => friendly message.
	 */
	/**
	 * What the record already says, so editing one field does not wipe another.
	 *
	 * @param int    $post_id Record being saved; 0 for a new one.
	 * @param string $key     Meta key.
	 * @return bool
	 */
	private static function stored_text( int $post_id, string $key ): bool {
		if ( $post_id <= 0 ) {
			return false;
		}
		$value = get_post_meta( $post_id, $key, true );
		return is_scalar( $value ) && '' !== trim( (string) $value );
	}

	public static function validate( array $input, int $post_id = 0 ): array {
		$errors = array();

		$title = trim( Sanitize::text( $input['title'] ?? '' ) );
		if ( 0 === $post_id && '' === $title ) {
			$errors['title'] = __( 'Please give this property a short headline, for example "3 BHK apartment near the metro".', 'estat-os' );
		} elseif ( '' !== $title && mb_strlen( $title ) < 5 ) {
			$errors['title'] = __( 'The headline is very short. Add a few more words so buyers understand it.', 'estat-os' );
		}

		$offer = Sanitize::text( $input['offer'] ?? $input['_estat_offer'] ?? '' );
		if ( '' !== $offer && ! in_array( $offer, Vocabulary::keys( 'offers' ), true ) ) {
			$errors['offer'] = __( 'Please choose sale, rent or lease.', 'estat-os' );
		}

		$price_type = Sanitize::text( $input['price_type'] ?? $input['_estat_price_type'] ?? '' );
		$price      = isset( $input['price'] ) ? Sanitize::float( $input['price'] ) : ( isset( $input['_estat_price'] ) ? Sanitize::float( $input['_estat_price'] ) : null );
		$price_min  = isset( $input['price_min'] ) ? Sanitize::float( $input['price_min'] ) : ( isset( $input['_estat_price_min'] ) ? Sanitize::float( $input['_estat_price_min'] ) : null );
		$price_max  = isset( $input['price_max'] ) ? Sanitize::float( $input['price_max'] ) : ( isset( $input['_estat_price_max'] ) ? Sanitize::float( $input['_estat_price_max'] ) : null );
		$rent       = isset( $input['rent'] ) ? Sanitize::float( $input['rent'] ) : ( isset( $input['_estat_rent'] ) ? Sanitize::float( $input['_estat_rent'] ) : null );

		$publishing = 'publish' === ( $input['status'] ?? '' );

		/*
		 * A property that goes on the website has to say what it is. A plot
		 * left without a type is not an "Apartment" — it is a record nobody
		 * finished, and the website would either show a hole or a wrong
		 * claim. A draft is still free to be unfinished.
		 */
		if ( $publishing ) {
			if ( '' === Sanitize::text( $input['_estat_property_type'] ?? $input['property_type'] ?? '' ) && ! self::stored_text( $post_id, '_estat_property_type' ) ) {
				$errors['property_type'] = __( 'Choose what kind of property it is before putting it on the website.', 'estat-os' );
			}
			if ( '' === $offer && ! self::stored_text( $post_id, '_estat_offer' ) ) {
				$errors['offer'] = __( 'Say whether it is for sale, rent or lease before putting it on the website.', 'estat-os' );
			}
		}

		if ( $publishing && 'on_request' !== $price_type ) {
			if ( 'rent' === $offer || 'lease' === $offer ) {
				if ( ! $rent && ! $price && ! $price_min && ! $price_max ) {
					$errors['rent'] = __( 'Add the monthly rent, or choose "Price on request".', 'estat-os' );
				}
			} elseif ( ! $price && ! $price_min && ! $price_max ) {
				$errors['price'] = __( 'Add a price, or choose "Price on request".', 'estat-os' );
			}
		}

		/*
		 * Sanitize::float() floors at zero, so by this point a negative has
		 * already become 0 and a check on $price could never fire. Look at
		 * what was actually typed instead: turning "-500000" into "0" without
		 * a word is worse than refusing it.
		 */
		foreach ( array( 'price', 'rent', 'price_min', 'price_max' ) as $money_field ) {
			$typed = $input[ $money_field ] ?? $input[ '_estat_' . $money_field ] ?? null;

			if ( null === $typed || '' === $typed ) {
				continue;
			}

			if ( is_scalar( $typed ) && (float) str_replace( array( ',', ' ' ), '', (string) $typed ) < 0 ) {
				$errors[ $money_field ] = __( 'That cannot be a negative number.', 'estat-os' );
			}
		}

		/*
		 * Upper limits. These are not arbitrary tidiness: without them a
		 * mistyped price sorts above every real listing and breaks the price
		 * filter for everybody, and "999 bedrooms" reaches the public site.
		 * The ceilings are set far above any genuine property so a real,
		 * unusual entry is never blocked.
		 */
		foreach ( array( 'price' => $price, 'rent' => $rent, 'price_min' => $price_min, 'price_max' => $price_max ) as $money_field => $money ) {
			if ( null !== $money && $money > self::MAX_MONEY ) {
				$errors[ $money_field ] = __( 'That number looks too large. Please check it.', 'estat-os' );
			}
		}


		foreach ( self::counted_fields() as $count_field => $ceiling ) {
			$raw = $input[ $count_field ] ?? $input[ '_estat_' . $count_field ] ?? null;

			if ( null === $raw || '' === $raw ) {
				continue;
			}

			$value = Sanitize::int( $raw, 0 );

			if ( $value > $ceiling ) {
				$errors[ $count_field ] = sprintf(
					/* translators: 1: what is being counted, 2: the highest allowed number. */
					__( 'That is more %1$s than we can record. The most is %2$d.', 'estat-os' ),
					$count_field,
					$ceiling
				);
			}
		}

		$area = isset( $input['area'] ) ? Sanitize::float( $input['area'] ) : null;
		if ( null !== $area && $area > 100000000 ) {
			$errors['area'] = __( 'That size looks too large. Please check the number.', 'estat-os' );
		}

		$expiry = Sanitize::date( $input['expiry_date'] ?? $input['_estat_expiry_date'] ?? '' );
		if ( '' !== $expiry && strtotime( $expiry ) < strtotime( gmdate( 'Y-m-d' ) ) ) {
			$errors['expiry_date'] = __( 'The removal date is in the past. Please pick a future date.', 'estat-os' );
		}

		/**
		 * Filter listing validation errors.
		 *
		 * @param array<string,string> $errors Errors.
		 * @param array<string,mixed>  $input  Raw input.
		 */
		return (array) apply_filters( 'estat_validate_listing', $errors, $input );
	}

	/**
	 * Persist meta values present in the input.
	 *
	 * @param int                 $listing_id Listing ID.
	 * @param array<string,mixed> $input      Raw input.
	 * @return void
	 */
	private static function save_meta( int $listing_id, array $input ): void {
		$may_verify = current_user_can( 'estat_verify_listings' );
		$schema     = Meta::listing_schema();
		foreach ( $schema as $key => $field ) {
			if ( ! empty( $field['computed'] ) ) {
				continue;
			}
			if ( self::VERIFICATION_KEY === $key && ! $may_verify ) {
				// Only authorised staff may set the verification state. Anyone
				// else leaves whatever is already stored untouched.
				continue;
			}
			$short = substr( $key, strlen( '_estat_' ) );
			if ( array_key_exists( $key, $input ) ) {
				$raw = $input[ $key ];
			} elseif ( array_key_exists( $short, $input ) ) {
				$raw = $input[ $short ];
			} else {
				continue;
			}
			$value = Meta::sanitize_value( $raw, $field );
			if ( '' === $value || array() === $value ) {
				delete_post_meta( $listing_id, $key );
				continue;
			}
			update_post_meta( $listing_id, $key, $value );
		}

		if ( array_key_exists( 'highlights', $input ) || array_key_exists( Highlights::META_KEY, $input ) ) {
			$ticked = $input['highlights'] ?? $input[ Highlights::META_KEY ];
			Highlights::save( $listing_id, $ticked );
		}

	}

	/**
	 * Persist taxonomy selections.
	 *
	 * @param int                 $listing_id Listing ID.
	 * @param array<string,mixed> $input      Raw input.
	 * @return void
	 */
	private static function save_terms( int $listing_id, array $input ): void {
		$map = array(
			'locality'  => Taxonomies::LOCALITY,
			'features'  => Taxonomies::FEATURE,
			'amenities' => Taxonomies::AMENITY,
		);
		foreach ( $map as $input_key => $taxonomy ) {
			if ( ! array_key_exists( $input_key, $input ) ) {
				continue;
			}
			$value = $input[ $input_key ];
			if ( is_string( $value ) ) {
				// 3.0.7 fix: split by newline or pipe, not comma, to avoid breaking names like "Sohna Road (Sector 49, Uppal Southend)" which would become unbalanced brackets
				$value = preg_split( '/\s*[\r\n|]+\s*/', $value, -1, PREG_SPLIT_NO_EMPTY );
				// If still single string containing comma, treat as single locality name, not split
			}
			if ( ! is_array( $value ) ) {
				$value = array();
			}
			$terms = array();
			foreach ( $value as $item ) {
				if ( is_numeric( $item ) ) {
					$terms[] = (int) $item;
					continue;
				}
				$name = Sanitize::text( $item );
				if ( '' === $name ) {
					continue;
				}
				// 3.0.7 canonical: strip emojis, leading numbers like "5 Parking" -> "Parking", trim
				if ( $taxonomy === Taxonomies::AMENITY || $taxonomy === Taxonomies::FEATURE ) {
					// Remove emojis (basic ranges)
					$name = preg_replace('/[\x{1F300}-\x{1F9FF}\x{2600}-\x{27BF}]/u', '', $name);
					// Remove leading numbers + optional separator
					$name = preg_replace('/^\s*\d+\s*[\-\.:xX]*\s*/u', '', $name);
					$name = trim($name);
					// Canonicalize case: first letter uppercase rest lower for comparison, but keep as is for display? Use ucwords for amenity
					if ( '' !== $name ) {
						// Normalize multiple spaces
						$name = preg_replace('/\s+/', ' ', $name);
					}
				}
				if ( '' === $name ) {
					continue;
				}
				// Check existing by slug to avoid duplicates like Parking vs parking
				$existing = term_exists( $name, $taxonomy );
				if ( ! is_array( $existing ) ) {
					// Try case-insensitive lookup by slug
					$slug = sanitize_title( $name );
					$term_by_slug = get_term_by( 'slug', $slug, $taxonomy );
					if ( $term_by_slug instanceof \WP_Term ) {
						$existing = array( 'term_id' => (int) $term_by_slug->term_id );
					}
				}
				if ( is_array( $existing ) ) {
					$terms[] = (int) $existing['term_id'];
					continue;
				}
				$created = wp_insert_term( $name, $taxonomy );
				if ( ! is_wp_error( $created ) ) {
					$terms[] = (int) $created['term_id'];
				}
			}
			wp_set_object_terms( $listing_id, $terms, $taxonomy, false );
		}
	}

	/**
	 * Set the cover image and keep the WordPress featured image in sync.
	 *
	 * @param int $listing_id   Listing ID.
	 * @param int $attachment_id Attachment ID (0 clears).
	 * @return void
	 */
	public static function set_cover( int $listing_id, int $attachment_id ): void {
		if ( $attachment_id > 0 && 'attachment' === get_post_type( $attachment_id ) ) {
			set_post_thumbnail( $listing_id, $attachment_id );
		} else {
			delete_post_thumbnail( $listing_id );
		}
	}

	/**
	 * Recalculate derived values: sqft, completeness and the search index row.
	 *
	 * @param int $listing_id Listing ID.
	 * @return void
	 */
	public static function refresh_derived( int $listing_id ): void {
		$area = (float) get_post_meta( $listing_id, '_estat_area', true );
		$unit = (string) get_post_meta( $listing_id, '_estat_area_unit', true );
		if ( $area > 0 ) {
			update_post_meta( $listing_id, '_estat_area_sqft', Format::to_sqft( $area, $unit ?: 'sqft' ) );
		} else {
			delete_post_meta( $listing_id, '_estat_area_sqft' );
		}

		$score = self::completeness( $listing_id );
		update_post_meta( $listing_id, '_estat_completeness', $score['score'] );

		SearchIndex::index_listing( $listing_id );
		wp_cache_delete( 'estat_stats', 'estat' );
	}

	/**
	 * Calculate how ready a listing is, with a list of what is missing.
	 *
	 * @param int $listing_id Listing ID.
	 * @return array{score:int,missing:array<int,array{field:string,label:string}>}
	 */
	public static function completeness( int $listing_id ): array {
		$post = get_post( $listing_id );
		if ( ! $post ) {
			return array( 'score' => 0, 'missing' => array() );
		}

		$checks = array(
			array(
				'field'  => 'title',
				'label'  => __( 'A clear headline', 'estat-os' ),
				'weight' => 10,
				'ok'     => mb_strlen( trim( $post->post_title ) ) >= 5,
			),
			array(
				'field'  => 'description',
				'label'  => __( 'A description of the property', 'estat-os' ),
				'weight' => 10,
				'ok'     => mb_strlen( wp_strip_all_tags( $post->post_content ) ) >= 80,
			),
			array(
				'field'  => 'cover_id',
				'label'  => __( 'A main photo', 'estat-os' ),
				'weight' => 15,
				'ok'     => (bool) get_post_thumbnail_id( $listing_id ),
			),
			array(
				'field'  => 'gallery',
				'label'  => __( 'At least three photos', 'estat-os' ),
				'weight' => 10,
				'ok'     => count( (array) get_post_meta( $listing_id, '_estat_gallery', true ) ) >= 3,
			),
			array(
				'field'  => 'price',
				'label'  => __( 'A price (or price on request)', 'estat-os' ),
				'weight' => 15,
				'ok'     => 'on_request' === get_post_meta( $listing_id, '_estat_price_type', true )
					|| (float) get_post_meta( $listing_id, '_estat_price', true ) > 0
					|| (float) get_post_meta( $listing_id, '_estat_price_min', true ) > 0
					|| (float) get_post_meta( $listing_id, '_estat_price_max', true ) > 0
					|| (float) get_post_meta( $listing_id, '_estat_rent', true ) > 0,
			),
			array(
				'field'  => 'area',
				'label'  => __( 'The size of the property', 'estat-os' ),
				'weight' => 10,
				'ok'     => (float) get_post_meta( $listing_id, '_estat_area', true ) > 0,
			),
			array(
				'field'  => 'locality',
				'label'  => __( 'The locality', 'estat-os' ),
				'weight' => 15,
				'ok'     => ! empty( ( static function() use ( $listing_id ) { $t = wp_get_object_terms( $listing_id, Taxonomies::LOCALITY, array( 'fields' => 'ids' ) ); return is_wp_error($t) ? array() : $t; } )() ),
			),
			array(
				'field'  => 'agent_id',
				'label'  => __( 'A team member in charge', 'estat-os' ),
				'weight' => 5,
				'ok'     => (int) get_post_meta( $listing_id, '_estat_agent_id', true ) > 0,
			),
			array(
				'field'  => 'bedrooms',
				'label'  => __( 'Number of bedrooms', 'estat-os' ),
				'weight' => 5,
				'ok'     => (int) get_post_meta( $listing_id, '_estat_bedrooms', true ) > 0
					|| in_array( Vocabulary::normalise_property_type( (string) get_post_meta( $listing_id, '_estat_property_type', true ) ), array( 'plot', 'farm_house', 'warehouse', 'office', 'commercial_shop' ), true ),
			),
			array(
				'field'  => 'latitude',
				'label'  => __( 'A location on the map', 'estat-os' ),
				'weight' => 5,
				'ok'     => '' !== (string) get_post_meta( $listing_id, '_estat_latitude', true ),
			),
		);

		$total   = 0;
		$scored  = 0;
		$missing = array();
		foreach ( $checks as $check ) {
			$total += (int) $check['weight'];
			if ( $check['ok'] ) {
				$scored += (int) $check['weight'];
			} else {
				$missing[] = array( 'field' => (string) $check['field'], 'label' => (string) $check['label'] );
			}
		}

		$score = $total > 0 ? (int) round( ( $scored / $total ) * 100 ) : 0;
		return array( 'score' => $score, 'missing' => $missing );
	}

	/**
	 * Keep derived data fresh when a listing is saved through any route.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public static function on_save_post( int $post_id, WP_Post $post, bool $update ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( 'auto-draft' === $post->post_status ) {
			return;
		}
		self::refresh_derived( $post_id );
	}

	/**
	 * Clean up the index when a listing is deleted.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_delete( int $post_id ): void {
		if ( PostTypes::LISTING !== get_post_type( $post_id ) ) {
			return;
		}
		SearchIndex::remove( $post_id );
		AuditLog::record( 'listing.deleted', 'listing', $post_id, array() );
	}

	/**
	 * How many whole days a listing has been published.
	 *
	 * @param int $listing_id Listing ID.
	 * @return int Zero when it has never been published.
	 */
	public static function days_listed( int $listing_id ): int {
		$post = get_post( $listing_id );

		if ( ! $post || 'publish' !== $post->post_status ) {
			return 0;
		}

		// post_date_gmt is empty on some rows written directly by an import,
		// so fall back rather than treating 1970 as the listing date.
		$published = (string) ( $post->post_date_gmt ?? '' );

		if ( '' === $published || '0000-00-00 00:00:00' === $published ) {
			$published = (string) ( $post->post_date ?? '' );
		}

		if ( '' === $published ) {
			return 0;
		}

		$stamp = strtotime( $published );

		if ( ! $stamp ) {
			return 0;
		}

		$days = (int) floor( ( time() - $stamp ) / DAY_IN_SECONDS );

		// A clock skew or a future-dated post must not read as negative.
		return max( 0, $days );
	}

	/**
	 * Build a safe public representation of a listing.
	 *
	 * @param int  $listing_id Listing ID.
	 * @param bool $private    Include office-only information.
	 * @return array<string,mixed>
	 */
	public static function to_array( int $listing_id, bool $private = false ): array {
		$post = get_post( $listing_id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
			return array();
		}

		$price_type = (string) get_post_meta( $listing_id, '_estat_price_type', true );
		$price      = (float) get_post_meta( $listing_id, '_estat_price', true );
		$price_min  = get_post_meta( $listing_id, '_estat_price_min', true );
		$price_max  = get_post_meta( $listing_id, '_estat_price_max', true );
		$rent       = (float) get_post_meta( $listing_id, '_estat_rent', true );
		$on_request = 'on_request' === $price_type;

		// F0: min/max with legacy fallback.
		$min_raw = '' !== $price_min ? (float) $price_min : ( $price > 0 ? $price : $rent );
		$max_raw = '' !== $price_max ? (float) $price_max : ( $price > 0 ? $price : $rent );
		$offer_raw = (string) get_post_meta( $listing_id, '_estat_offer', true );

		$data = array(
			'id'            => $listing_id,
			'title'         => $post->post_title,
			'url'           => get_permalink( $listing_id ),
			'status'        => $post->post_status,
			'offer'         => $offer_raw,
			'property_type' => (string) get_post_meta( $listing_id, '_estat_property_type', true ),
			'price'         => $on_request ? null : $price,
			'price_min'     => $on_request ? null : ( '' !== $price_min ? (float) $price_min : null ),
			'price_max'     => $on_request ? null : ( '' !== $price_max ? (float) $price_max : null ),
			'rent'          => $on_request ? null : $rent,
			'price_type'    => $price_type,
			/*
			 * The words shown instead of a number are the office's own: a
			 * screen under Settings lets them ask for "Price on request",
			 * "Ask for price" or whatever suits, and nothing used to read
			 * that answer back.
			 */
			'price_display' => $on_request
				? (string) Settings::get( 'price_on_request_label', __( 'Price on request', 'estat-os' ) )
				: Format::price_range( $min_raw, $max_raw, $offer_raw, false ),
			'area'          => (float) get_post_meta( $listing_id, '_estat_area', true ),
			'area_unit'     => (string) get_post_meta( $listing_id, '_estat_area_unit', true ),
			'area_sqft'     => (float) get_post_meta( $listing_id, '_estat_area_sqft', true ),
			'bedrooms'      => (int) get_post_meta( $listing_id, '_estat_bedrooms', true ),
			'bathrooms'     => (int) get_post_meta( $listing_id, '_estat_bathrooms', true ),
			'parking'       => (int) get_post_meta( $listing_id, '_estat_parking', true ),
			'floor'         => (int) get_post_meta( $listing_id, '_estat_floor', true ),
			'furnishing'    => (string) get_post_meta( $listing_id, '_estat_furnishing', true ),
			'availability'  => (string) get_post_meta( $listing_id, '_estat_availability', true ),
			'construction'  => (string) get_post_meta( $listing_id, '_estat_construction', true ),
			'verification'  => (string) get_post_meta( $listing_id, '_estat_verification', true ),
			'featured'      => (bool) get_post_meta( $listing_id, '_estat_featured', true ),
			'investment'    => (bool) get_post_meta( $listing_id, '_estat_investment', true ),
			'practice'      => (bool) get_post_meta( $listing_id, '_estat_practice', true ),
			'locality'      => ( static function() use ( $listing_id ) { $terms = wp_get_object_terms( $listing_id, Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); return is_wp_error( $terms ) ? array() : (array) $terms; } )(),
			'amenities'     => ( static function() use ( $listing_id ) { $terms = wp_get_object_terms( $listing_id, Taxonomies::AMENITY, array( 'fields' => 'names' ) ); return is_wp_error( $terms ) ? array() : (array) $terms; } )(),

			/*
			 * Special features were collected, saved as terms and then never
			 * handed to anybody - the property page asked for them and got
			 * nothing, so an office that ticked "Park facing" and "Corner
			 * unit" saw neither on its own website. Same treatment as
			 * amenities, which is the shape every template already expects.
			 */
			'features'      => ( static function() use ( $listing_id ) { $terms = wp_get_object_terms( $listing_id, Taxonomies::FEATURE, array( 'fields' => 'names' ) ); return is_wp_error( $terms ) ? array() : (array) $terms; } )(),
			'cover'         => get_the_post_thumbnail_url( $listing_id, 'large' ) ?: '',

			/*
			 * The cover's real pixel size, so a template can write width and
			 * height onto the tag. Without them the browser does not know how
			 * tall the image will be, lays the page out without it, and then
			 * shoves everything down when it arrives - the jump Google counts
			 * against the site as layout shift.
			 *
			 * Zero when there is no cover, which templates read as "do not
			 * write dimensions".
			 */
			'cover_width'   => 0,
			'cover_height'  => 0,

			/*
			 * How long this has been on the website. A buyer reads a new
			 * listing as "go and see it this weekend" and an old one as
			 * "there may be room to negotiate" - both useful, and neither
			 * knowable today.
			 *
			 * Counted from when it was published, not when the office first
			 * created the draft, because a property sitting in drafts for a
			 * month has not been on the market for a month.
			 */
			'days_listed'   => self::days_listed( $listing_id ),
			'project_id'    => (int) get_post_meta( $listing_id, '_estat_project_id', true ),
			'agent_id'      => (int) get_post_meta( $listing_id, '_estat_agent_id', true ),
			'latitude'      => (string) get_post_meta( $listing_id, '_estat_latitude', true ),
			'longitude'     => (string) get_post_meta( $listing_id, '_estat_longitude', true ),
			'highlights'    => Highlights::get( $listing_id ),
			'chips'         => Highlights::for_card( $listing_id ),

			/*
			 * These were collected by the editor, validated and stored, and
			 * then never handed to anybody: absent from this array in both
			 * modes, absent from REST, and unread by the templates. The
			 * office typed a deposit, a video link and a possession date and
			 * no visitor could ever see them.
			 *
			 * They are public because a buyer legitimately wants all of them.
			 * The genuinely internal ones stay below, under $private.
			 */
			'deposit'       => (float) get_post_meta( $listing_id, '_estat_deposit', true ),
			'maintenance'   => (float) get_post_meta( $listing_id, '_estat_maintenance', true ),
			'balconies'     => (int) get_post_meta( $listing_id, '_estat_balconies', true ),
			'total_floors'  => (int) get_post_meta( $listing_id, '_estat_total_floors', true ),
			'age'           => (int) get_post_meta( $listing_id, '_estat_age', true ),
			'facing'        => (string) get_post_meta( $listing_id, '_estat_facing', true ),
			'area_type'     => (string) get_post_meta( $listing_id, '_estat_area_type', true ),
			'video_url'     => (string) get_post_meta( $listing_id, '_estat_video_url', true ),
			'tour_url'      => (string) get_post_meta( $listing_id, '_estat_tour_url', true ),
			'developer'     => (string) get_post_meta( $listing_id, '_estat_developer', true ),
			'possession_date' => (string) get_post_meta( $listing_id, '_estat_possession_date', true ),
			'floor_plans'   => array_values( array_filter( array_map( 'absint', (array) get_post_meta( $listing_id, '_estat_floor_plans', true ) ) ) ),
			'brochures'     => array_values( array_filter( array_map( 'absint', (array) get_post_meta( $listing_id, '_estat_brochures', true ) ) ) ),
		);

		/*
		 * Ask for the real dimensions once. get_the_post_thumbnail_url()
		 * above gives only a URL, and a second lookup here is cheap because
		 * the attachment is already in the object cache by this point.
		 */
		$cover_id = (int) get_post_thumbnail_id( $listing_id );

		if ( $cover_id > 0 ) {
			$measured = wp_get_attachment_image_src( $cover_id, 'large' );

			if ( is_array( $measured ) && ! empty( $measured[1] ) && ! empty( $measured[2] ) ) {
				$data['cover_width']  = (int) $measured[1];
				$data['cover_height'] = (int) $measured[2];
			}
		}

		/*
		 * A registration number is public information by law in most Indian
		 * states, but only when the office has chosen to display it.
		 */
		if ( Settings::get( 'show_regulatory' ) ) {
			$data['regulatory_id'] = (string) get_post_meta( $listing_id, '_estat_regulatory_id', true );
		}

		if ( $private ) {
			$data['internal_notes'] = (string) get_post_meta( $listing_id, '_estat_internal_notes', true );
			$data['external_id']    = (string) get_post_meta( $listing_id, '_estat_external_id', true );
			$data['address']        = (string) get_post_meta( $listing_id, '_estat_address', true );
			$data['completeness']   = (int) get_post_meta( $listing_id, '_estat_completeness', true );
			$data['expiry_date']    = (string) get_post_meta( $listing_id, '_estat_expiry_date', true );
		}

		/**
		 * Filter the listing representation.
		 *
		 * @param array<string,mixed> $data       Listing data.
		 * @param int                 $listing_id Listing ID.
		 * @param bool                $private    Whether private fields are included.
		 */
		return (array) apply_filters( 'estat_listing_data', $data, $listing_id, $private );
	}

	/**
	 * Find a listing by its office reference number.
	 *
	 * @param string $external_id Reference number.
	 * @return int Listing ID or 0.
	 */
	public static function find_by_external_id( string $external_id ): int {
		$external_id = Sanitize::text( $external_id );
		if ( '' === $external_id ) {
			return 0;
		}
		$found = get_posts(
			array(
				'post_type'        => PostTypes::LISTING,
				'post_status'      => array( 'any' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'meta_key'         => '_estat_external_id',
				'meta_value'       => $external_id,
				'suppress_filters' => false,
				'no_found_rows'    => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}
}
