<?php
/**
 * The bin: one lifecycle, one authority.
 *
 * A property has exactly three places it can be in this plugin's world:
 *
 *     Active  →  Bin  →  Restore (back to where it was)
 *                     →  Delete permanently (gone, with the record kept)
 *
 * "Active" is WordPress's own post status — Draft, Waiting for approval,
 * Live, Paused. The bin is WordPress's own trash. Nothing here invents a
 * second kind of deletion: `wp_trash_post()` moves a property to the bin and
 * takes it off the website in the same breath, and `wp_untrash_post()`
 * brings it back. This class adds the four things WordPress does not keep
 * on its own — who moved it, when, what it was before, and a permanent
 * delete that refuses to run until somebody with the right permission says
 * so twice.
 *
 * Two words that must never be confused, and are not, anywhere in this file:
 *
 *   Paused  — still an active office record, hidden from the website.
 *   In bin  — taken out of the working inventory, recoverable.
 *
 * Paused is a post status ('private'). The bin is 'trash'. One is a state of
 * the property; the other is a state of the office's catalogue.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Audit\AuditLog;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Status;

defined( 'ABSPATH' ) || exit;

/**
 * Everything that may happen to a property on its way out, and back.
 */
final class Bin {

	/**
	 * Which user moved this record to the bin.
	 */
	public const META_BY = '_estat_binned_by';

	/**
	 * When (UTC, MySQL format) it went in.
	 */
	public const META_AT = '_estat_binned_at';

	/**
	 * The state it was in before — 'publish', 'draft', 'pending', 'private'.
	 */
	public const META_FROM = '_estat_binned_from';

	/**
	 * Which batch it was binned in, so one press of Undo can put back the
	 * whole sweep and nothing else.
	 */
	public const META_BATCH = '_estat_bin_batch';

	/**
	 * How long an Undo stays on offer after a bulk move to the bin.
	 */
	public const UNDO_MINUTES = 30;

	/**
	 * The state a binned record held before it went in, in one word.
	 *
	 * Our own copy is written the moment the record is binned, because
	 * WordPress stores the same fact in `_wp_trash_meta_status` and the two
	 * must never be able to disagree: if ours is missing (a record binned by
	 * an older version, or by another plugin), that one is read instead.
	 *
	 * @param int $record_id Property ID.
	 * @return string Post status, '' when it cannot be worked out.
	 */
	public static function previous_state( int $record_id ): string {
		$ours = (string) get_post_meta( $record_id, self::META_FROM, true );
		if ( '' !== $ours ) {
			return $ours;
		}

		$core = (string) get_post_meta( $record_id, '_wp_trash_meta_status', true );
		return $core;
	}

	/**
	 * Who moved this record to the bin.
	 *
	 * @param int $record_id Property ID.
	 * @return int User ID, 0 when unknown (an import, a cron job, an older version).
	 */
	public static function binned_by( int $record_id ): int {
		return (int) get_post_meta( $record_id, self::META_BY, true );
	}

	/**
	 * When it went in, as a MySQL UTC stamp.
	 *
	 * @param int $record_id Property ID.
	 * @return string
	 */
	public static function binned_at( int $record_id ): string {
		$at = (string) get_post_meta( $record_id, self::META_AT, true );
		if ( '' !== $at ) {
			return $at;
		}

		// Older or externally binned records still have WordPress's own
		// stamp, which is a Unix time. Never show an empty date on the bin
		// screen when a real one exists.
		$core = (int) get_post_meta( $record_id, '_wp_trash_meta_time', true );
		return $core > 0 ? gmdate( 'Y-m-d H:i:s', $core ) : '';
	}

	/**
	 * The name to print under "Moved to bin by …".
	 *
	 * @param int $record_id Property ID.
	 * @return string
	 */
	public static function binned_by_name( int $record_id ): string {
		$user_id = self::binned_by( $record_id );
		if ( $user_id <= 0 ) {
			return '';
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return '';
		}

		return trim( (string) ( '' !== $user->display_name ? $user->display_name : $user->user_login ) );
	}

	/* ---------------------------------------------------------------------
	 * Register: keep our four facts true however the record is binned
	 * ------------------------------------------------------------------ */

	/**
	 * Hooks. Deliberately tied to the status change rather than to our own
	 * buttons: a property binned from the WordPress post list, by a REST
	 * call, by an import rollback or by an older version of the pocket must
	 * still land in the office's bin screen with a name and a date on it.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 10, 3 );
	}

	/**
	 * Record what a record was, and who did it, the moment it is binned.
	 *
	 * @param string   $new_status Status being moved to.
	 * @param string   $old_status Status being moved from.
	 * @param \WP_Post $post       The record.
	 * @return void
	 */
	public static function on_status_change( string $new_status, string $old_status, $post ): void {
		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, self::kinds(), true ) ) {
			return;
		}

		if ( 'trash' === $new_status && 'trash' !== $old_status ) {
			update_post_meta( $post->ID, self::META_FROM, $old_status );
			update_post_meta( $post->ID, self::META_AT, current_time( 'mysql', true ) );
			$by = get_current_user_id();
			if ( $by > 0 ) {
				update_post_meta( $post->ID, self::META_BY, $by );
			}
			return;
		}

		if ( 'trash' !== $new_status && 'trash' === $old_status ) {
			// Out of the bin — the record is a working record again, so the
			// bin's own notes about it are cleared rather than left to rot.
			delete_post_meta( $post->ID, self::META_BY );
			delete_post_meta( $post->ID, self::META_AT );
			delete_post_meta( $post->ID, self::META_FROM );
			delete_post_meta( $post->ID, self::META_BATCH );
		}
	}

	/**
	 * The record kinds the bin holds. Societies and projects travel with
	 * properties; team members and articles are not inventory and do not
	 * belong here.
	 *
	 * @return string[]
	 */
	public static function kinds(): array {
		return array( PostTypes::LISTING, PostTypes::PROJECT );
	}

	/* ---------------------------------------------------------------------
	 * Who may do what
	 * ------------------------------------------------------------------ */

	/**
	 * May this person take this record out of the working inventory?
	 *
	 * Deliberately not the same permission as permanent deletion. Moving
	 * something to the bin is recoverable, so an agent may do it for their
	 * own properties; destroying it is not, so they may not.
	 *
	 * @param \WP_Post|int|null $post Record.
	 * @return bool
	 */
	public static function may_move( $post ): bool {
		$post = $post instanceof \WP_Post ? $post : get_post( $post );
		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) ) {
			return false;
		}
		if ( 'trash' === $post->post_status ) {
			return false;
		}

		if ( current_user_can( 'estat_delete_listings' ) ) {
			return true;
		}
		if ( ! current_user_can( 'estat_bin_listings' ) ) {
			return false;
		}

		// Anybody holding only the recoverable permission works within their
		// own shelf: their own records, or ones the office handed to them.
		return self::mine( $post );
	}

	/**
	 * May this person bring this record back out of the bin?
	 *
	 * @param \WP_Post|int|null $post Record.
	 * @return bool
	 */
	public static function may_restore( $post ): bool {
		$post = $post instanceof \WP_Post ? $post : get_post( $post );
		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) || 'trash' !== $post->post_status ) {
			return false;
		}

		if ( current_user_can( 'estat_delete_listings' ) ) {
			return true;
		}
		if ( ! current_user_can( 'estat_restore_listings' ) ) {
			return false;
		}

		return self::mine( $post );
	}

	/**
	 * May this person destroy this record for good?
	 *
	 * Only ever while it is already in the bin, and only with the
	 * permanent-delete permission. This is the one door an agent may not
	 * open, by design.
	 *
	 * @param \WP_Post|int|null $post Record.
	 * @return bool
	 */
	public static function may_delete( $post ): bool {
		$post = $post instanceof \WP_Post ? $post : get_post( $post );
		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) || 'trash' !== $post->post_status ) {
			return false;
		}
		if ( PostTypes::AGENCY === $post->post_type ) {
			return false;
		}

		return current_user_can( 'estat_delete_listings' ) && current_user_can( 'delete_post', $post->ID );
	}

	/**
	 * May this person empty the whole bin in one press?
	 *
	 * @return bool
	 */
	public static function may_empty(): bool {
		return current_user_can( 'estat_empty_bin' ) && current_user_can( 'estat_delete_listings' );
	}

	/**
	 * Is this record on the signed-in person's own shelf?
	 *
	 * @param \WP_Post $post Record.
	 * @return bool
	 */
	private static function mine( \WP_Post $post ): bool {
		$me = get_current_user_id();
		if ( $me <= 0 ) {
			return false;
		}
		if ( (int) $post->post_author === $me ) {
			return true;
		}
		$assigned = (int) get_post_meta( (int) $post->ID, '_estat_assigned_user', true );
		if ( $assigned === $me ) {
			return true;
		}
		$agent = (int) get_post_meta( (int) $post->ID, '_estat_agent_id', true );
		if ( $agent > 0 ) {
			$linked = Agents::for_user( $me );
			if ( $linked > 0 && $linked === $agent ) {
				return true;
			}
		}

		return false;
	}

	/* ---------------------------------------------------------------------
	 * The three moves
	 * ------------------------------------------------------------------ */

	/**
	 * Move one record to the bin. Off the website at once, recoverable for
	 * as long as the office likes.
	 *
	 * @param int    $record_id Property or society ID.
	 * @param string $why       Optional plain-language reason, kept in the audit.
	 * @param string $batch     Batch token, when this is part of a sweep.
	 * @return true|\WP_Error
	 */
	public static function move( int $record_id, string $why = '', string $batch = '' ) {
		$post = get_post( $record_id );

		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) ) {
			return new \WP_Error( 'estat_bin_missing', __( 'That property could not be found.', 'estat-os' ) );
		}
		if ( 'trash' === $post->post_status ) {
			return new \WP_Error( 'estat_already_binned', __( 'It is already in the bin.', 'estat-os' ) );
		}
		if ( ! self::may_move( $post ) ) {
			return new \WP_Error(
				'estat_bin_forbidden',
				__( 'You are not allowed to move this one to the bin. Ask the office.', 'estat-os' )
			);
		}

		$was = (string) $post->post_status;

		if ( ! wp_trash_post( $record_id ) ) {
			return new \WP_Error( 'estat_bin_failed', __( 'That could not be moved to the bin. Please try again.', 'estat-os' ) );
		}

		if ( '' !== $batch ) {
			update_post_meta( $record_id, self::META_BATCH, $batch );
		}

		AuditLog::record(
			'listing.binned',
			$post->post_type,
			$record_id,
			array(
				'title' => $post->post_title,
				'from'  => $was,
				'why'   => $why,
				'batch' => $batch,
			)
		);

		/**
		 * Fires after a record lands in the bin.
		 *
		 * @param int    $record_id Record ID.
		 * @param string $was       The state it held before.
		 */
		do_action( 'estat_record_binned', $record_id, $was );

		return true;
	}

	/**
	 * Bring one record back — to exactly where it was, not to a fresh draft.
	 *
	 * Live → bin → restore → Live. Draft → bin → restore → Draft. Waiting
	 * for approval → bin → restore → Waiting for approval. Paused → bin →
	 * restore → Paused. The only exception is a person who may not publish:
	 * a live property comes back as Waiting for approval, so the website is
	 * never changed by somebody who is not allowed to change it.
	 *
	 * @param int $record_id Record ID.
	 * @return array{to:string,state:string}|\WP_Error Where it landed.
	 */
	public static function restore( int $record_id ) {
		$post = get_post( $record_id );

		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) ) {
			return new \WP_Error( 'estat_bin_missing', __( 'That record could not be found.', 'estat-os' ) );
		}
		if ( 'trash' !== $post->post_status ) {
			return new \WP_Error( 'estat_not_binned', __( 'That one is not in the bin.', 'estat-os' ) );
		}
		if ( ! self::may_restore( $post ) ) {
			return new \WP_Error( 'estat_restore_forbidden', __( 'This is not yours to bring back. Ask the office.', 'estat-os' ) );
		}

		$was = self::previous_state( $record_id );
		$to  = self::restore_target( $was );

		if ( ! wp_untrash_post( $record_id ) ) {
			return new \WP_Error( 'estat_restore_failed', __( 'That could not be restored. Please try again.', 'estat-os' ) );
		}

		$landed = get_post( $record_id );
		$now    = $landed ? (string) $landed->post_status : '';

		if ( '' !== $to && $now !== $to ) {
			// WordPress restores to the status it remembers; this covers the
			// cases where it does not (a status this site does not have, a
			// record binned by something else, a person who may not publish).
			$updated = wp_update_post(
				array(
					'ID'          => $record_id,
					'post_status' => $to,
				),
				true
			);
			if ( is_wp_error( $updated ) ) {
				return new \WP_Error( 'estat_restore_failed', __( 'It came out of the bin but the state could not be put back. Please check it.', 'estat-os' ) );
			}
			$now = $to;
		}

		AuditLog::record(
			'record.restored',
			$post->post_type,
			$record_id,
			array(
				'title' => $post->post_title,
				'from'  => 'trash',
				'to'    => $now,
				'was'   => $was,
			)
		);

		/**
		 * Fires after a record comes back out of the bin.
		 *
		 * @param int    $record_id Record ID.
		 * @param string $now       The state it came back as.
		 */
		do_action( 'estat_record_restored', $record_id, $now );

		return array( 'to' => $now, 'state' => $was );
	}

	/**
	 * Where a restore should land.
	 *
	 * @param string $was The state it held before.
	 * @return string Post status.
	 */
	private static function restore_target( string $was ): string {
		$known = array( 'publish', 'draft', 'pending', 'private' );
		$to    = in_array( $was, $known, true ) ? $was : 'draft';

		if ( 'publish' === $to && ! current_user_can( 'estat_publish_listings' ) ) {
			// Somebody who may not put a property on the website does not get
			// to put one back on it through the bin either.
			return 'pending';
		}

		return $to;
	}

	/**
	 * Destroy one record for good.
	 *
	 * What survives, on purpose:
	 *
	 *  - every enquiry about it, with a line added saying the property was
	 *    deleted permanently,
	 *  - every visit, note and quote,
	 *  - the whole audit trail, including the title, so the office can always
	 *    answer "what was that property called?".
	 *
	 * What goes: the property record itself, and only those photographs and
	 * documents that no other record is using. Shared media is never
	 * destroyed because one property was.
	 *
	 * @param int $record_id Record ID.
	 * @return array{media_removed:int,media_kept:int,enquiries:int}|\WP_Error
	 */
	public static function delete_forever( int $record_id ) {
		$post = get_post( $record_id );

		if ( ! $post || ! in_array( $post->post_type, self::kinds(), true ) ) {
			return new \WP_Error( 'estat_bin_missing', __( 'That record could not be found.', 'estat-os' ) );
		}
		if ( 'trash' !== $post->post_status ) {
			return new \WP_Error(
				'estat_not_binned',
				__( 'Move it to the bin first. Only things in the bin can be deleted permanently.', 'estat-os' )
			);
		}
		if ( ! self::may_delete( $post ) ) {
			return new \WP_Error(
				'estat_delete_forbidden',
				__( 'Your account cannot delete things permanently. Ask the office owner.', 'estat-os' )
			);
		}

		$title   = (string) $post->post_title;
		$kind    = (string) $post->post_type;
		$binned  = self::previous_state( $record_id );
		$by      = self::binned_by_name( $record_id );

		// The people side of the story is kept, and told.
		$enquiries = self::mark_enquiries( $record_id, $title );

		$media = Media::cleanup_for_record( $record_id );

		if ( ! wp_delete_post( $record_id, true ) ) {
			return new \WP_Error( 'estat_delete_failed', __( 'That could not be deleted. Please try again.', 'estat-os' ) );
		}

		/*
		 * WordPress caches what it has just been told, so the next count or
		 * lookup in this same request would still hand back the record we
		 * have only this second destroyed — and the screen would say
		 * "13 properties in the bin" right after emptying it. Clearing both
		 * memories is two lines and removes a whole class of "it didn't
		 * work" reports.
		 */
		clean_post_cache( $record_id );
		wp_cache_delete( $record_id, 'posts' );
		wp_cache_delete( PostTypes::LISTING, 'counts' );
		wp_cache_delete( PostTypes::PROJECT, 'counts' );

		AuditLog::record(
			'listing.deleted_permanently',
			$kind,
			$record_id,
			array(
				'title'         => $title,
				'was'           => $binned,
				'binned_by'     => $by,
				'media_removed' => (string) $media['removed'],
				'media_kept'    => (string) $media['kept'],
				'enquiries'     => (string) $enquiries,
			)
		);

		/**
		 * Fires after a record has been deleted permanently.
		 *
		 * @param int    $record_id Record ID.
		 * @param string $title     Its title, for anything that still needs it.
		 */
		do_action( 'estat_record_deleted_forever', $record_id, $title );

		return array(
			'media_removed' => (int) $media['removed'],
			'media_kept'    => (int) $media['kept'],
			'enquiries'     => $enquiries,
		);
	}

	/**
	 * Leave a line on every enquiry that was about this property.
	 *
	 * Nothing is deleted here. An enquiry is a person's record of having
	 * asked about something; the office may still need to ring them.
	 *
	 * @param int    $record_id Record ID.
	 * @param string $title     The title it had.
	 * @return int How many enquiries were touched.
	 */
	private static function mark_enquiries( int $record_id, string $title ): int {
		if ( ! class_exists( '\EstatOS\Leads\Leads' ) ) {
			return 0;
		}

		$found = \EstatOS\Leads\Leads::query(
			array(
				'listing_id' => $record_id,
				'per_page'   => 50,
			)
		);

		$count = 0;
		foreach ( (array) $found['items'] as $lead ) {
			\EstatOS\Leads\Leads::append_note(
				(int) $lead['id'],
				sprintf(
					/* translators: %s: the name the property had. */
					__( 'The property this enquiry was about (“%s”) was deleted permanently from the office records. The enquiry itself is kept.', 'estat-os' ),
					$title
				)
			);
			++$count;
		}

		return $count;
	}

	/* ---------------------------------------------------------------------
	 * Doing it to several at once
	 * ------------------------------------------------------------------ */

	/**
	 * Run one operation over a list of records, in one server-side pass.
	 *
	 * The browser sends one request, not one per record: shared hosting is
	 * where a hundred parallel requests go to die, and an office that has
	 * ticked forty properties deserves one honest answer rather than a
	 * half-finished sweep it cannot see.
	 *
	 * @param string $operation One of move|restore|delete.
	 * @param int[]  $ids       Record IDs.
	 * @param string $why       Optional reason (move only).
	 * @return array{done:int[],failed:array<int,string>,batch:string,states:array<int,string>}
	 */
	public static function batch( string $operation, array $ids, string $why = '' ): array {
		$ids   = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		$batch = ( 'move' === $operation ) ? self::new_batch() : '';

		$done   = array();
		$failed = array();
		$states = array();

		foreach ( $ids as $id ) {
			switch ( $operation ) {
				case 'move':
					$result = self::move( $id, $why, $batch );
					break;
				case 'restore':
					$result = self::restore( $id );
					break;
				case 'delete':
					$result = self::delete_forever( $id );
					break;
				default:
					$result = new \WP_Error( 'estat_bad_operation', __( 'That is not something that can be done.', 'estat-os' ) );
			}

			if ( is_wp_error( $result ) ) {
				$failed[ $id ] = $result->get_error_message();
				continue;
			}

			$done[] = $id;
			if ( 'restore' === $operation && is_array( $result ) ) {
				$states[ $id ] = (string) $result['to'];
			}
		}

		AuditLog::record(
			'bin.' . $operation,
			'bulk',
			0,
			array(
				'asked'   => count( $ids ),
				'changed' => count( $done ),
				'failed'  => count( $failed ),
				'records' => implode( ',', $done ),
				'batch'   => $batch,
			)
		);

		return array(
			'done'   => $done,
			'failed' => $failed,
			'batch'  => $batch,
			'states' => $states,
		);
	}

	/**
	 * A fresh batch token.
	 *
	 * @return string
	 */
	private static function new_batch(): string {
		return substr( md5( get_current_user_id() . '|' . microtime( true ) . '|' . wp_rand() ), 0, 12 );
	}

	/**
	 * One line a person can read, out of what actually happened.
	 *
	 * "45 moved · 3 failed" is the honest shape; "done" is not.
	 *
	 * @param array{done:int[],failed:array<int,string>} $result Batch result.
	 * @param string                                     $verb   'moved to the bin'|'restored'|'deleted permanently'.
	 * @return string
	 */
	/**
	 * What happened, said in one line.
	 *
	 * The word for the records belongs to the screen that asked: the office
	 * list works on properties, so it says "7 properties moved to the bin"
	 * rather than "7 records". The failure half repeats the same action, so
	 * a sweep that went half way reads "10 properties restored · 2 could not
	 * be restored" — the same verb as the button, never a second word for
	 * the same thing.
	 *
	 * @param array{done:int[],failed:array<int,string>} $result What happened.
	 * @param string                                     $verb   What was done, in the words of the button.
	 * @param array{one?:string,many?:string}            $names  What to call one and many. Defaults to "record"/"records".
	 * @return string
	 */
	public static function summary( array $result, string $verb, array $names = array() ): string {
		$done = count( (array) $result['done'] );
		$bad  = count( (array) $result['failed'] );

		if ( 0 === $done && 0 === $bad ) {
			return __( 'Nothing was chosen, so nothing was changed.', 'estat-os' );
		}

		$one  = isset( $names['one'] ) && '' !== (string) $names['one'] ? (string) $names['one'] : __( 'record', 'estat-os' );
		$many = isset( $names['many'] ) && '' !== (string) $names['many'] ? (string) $names['many'] : __( 'records', 'estat-os' );
		$what = 1 === $done ? $one : $many;

		if ( 0 === $bad ) {
			return sprintf(
				/* translators: 1: how many, 2: what they are called, 3: what was done (e.g. "moved to the bin"). */
				__( '%1$d %2$s %3$s.', 'estat-os' ),
				$done,
				$what,
				$verb
			);
		}

		return sprintf(
			/* translators: 1: how many were changed, 2: what they are called, 3: what was done, 4: how many failed, 5: what could not be done (e.g. "could not be restored"). */
			__( '%1$d %2$s %3$s · %4$d %5$s.', 'estat-os' ),
			$done,
			$what,
			$verb,
			$bad,
			sprintf(
				/* translators: %s: what could not be done (e.g. "restored"). */
				__( 'could not be %s', 'estat-os' ),
				$verb
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Reading the bin
	 * ------------------------------------------------------------------ */

	/**
	 * Does this person see the whole bin, or only their own shelf?
	 *
	 * The office (anybody who may delete permanently or empty the bin) sees
	 * everything. An agent sees what they could bring back — their own
	 * records and the ones the office handed to them — which is exactly the
	 * same rule the buttons use. Nothing here is a second opinion about
	 * permission.
	 *
	 * @return bool
	 */
	public static function sees_everything(): bool {
		return current_user_can( 'estat_delete_listings' ) || current_user_can( 'estat_empty_bin' );
	}

	/**
	 * The binned records this person may see, newest first, with the filters
	 * the screen asked for.
	 *
	 * A bin is a small list, so the permission sieve is done by reading each
	 * record and asking the same question the Restore button asks. The
	 * alternative — a clever database query that says who owns what — would
	 * be a second place where ownership is decided, and the two would drift.
	 *
	 * @param array<string,mixed> $filters Search and filter boxes.
	 * @return int[]
	 */
	private static function matching_ids( array $filters = array() ): array {
		$args = array(
			'post_type'      => self::kinds(),
			'post_status'    => 'trash',
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		// The bin's search looks inside the bin and nowhere else: a binned
		// property can never turn up in the working list's search, and a
		// working property can never turn up here.
		if ( ! empty( $filters['search'] ) ) {
			$args['s'] = (string) $filters['search'];
		}

		$meta = array();
		if ( ! empty( $filters['deleted_by'] ) ) {
			$meta[] = array(
				'key'     => self::META_BY,
				'value'   => (int) $filters['deleted_by'],
				'compare' => '=',
			);
		}
		if ( ! empty( $filters['previous'] ) ) {
			$meta[] = array(
				'key'     => self::META_FROM,
				'value'   => sanitize_key( (string) $filters['previous'] ),
				'compare' => '=',
			);
		}
		if ( ! empty( $filters['date_from'] ) ) {
			$meta[] = array(
				'key'     => self::META_AT,
				'value'   => sanitize_text_field( (string) $filters['date_from'] ) . ' 00:00:00',
				'compare' => '>=',
			);
		}
		if ( ! empty( $filters['date_to'] ) ) {
			$meta[] = array(
				'key'     => self::META_AT,
				'value'   => sanitize_text_field( (string) $filters['date_to'] ) . ' 23:59:59',
				'compare' => '<=',
			);
		}
		if ( $meta ) {
			$args['meta_query'] = $meta;
		}

		if ( ! empty( $filters['locality'] ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => Taxonomies::LOCALITY,
					'field'    => 'slug',
					'terms'    => sanitize_key( (string) $filters['locality'] ),
				),
			);
		}

		$type = ! empty( $filters['type'] ) ? sanitize_key( (string) $filters['type'] ) : '';
		$out  = array();

		foreach ( array_map( 'absint', (array) get_posts( $args ) ) as $id ) {
			if ( '' !== $type ) {
				$row_type = sanitize_key( (string) get_post_meta( $id, '_estat_property_type', true ) );
				if ( $type !== $row_type ) {
					continue;
				}
			}

			if ( self::sees_everything() ) {
				$out[] = $id;
				continue;
			}

			$post = get_post( $id );
			if ( $post && self::may_restore( $post ) ) {
				$out[] = $id;
			}
		}

		return $out;
	}

	/**
	 * The bin as a screen wants it: one page of records, the total, and how
	 * many pages there are.
	 *
	 * @param array<string,mixed> $filters See self::matching_ids().
	 * @return array{items:\WP_Post[],total:int,page:int,pages:int}
	 */
	public static function query( array $filters = array() ): array {
		$per_page = isset( $filters['per_page'] ) ? max( 1, (int) $filters['per_page'] ) : 20;
		$page     = isset( $filters['page'] ) ? max( 1, (int) $filters['page'] ) : 1;

		$ids   = self::matching_ids( $filters );
		$total = count( $ids );

		$items = array();
		foreach ( array_slice( $ids, ( $page - 1 ) * $per_page, $per_page ) as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				$items[] = $post;
			}
		}

		return array(
			'items' => $items,
			'total' => $total,
			'page'  => $page,
			'pages' => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * Every binned record that may be acted on right now, up to a ceiling.
	 *
	 * Used where a whole sweep has to be resolved without a screen: "empty
	 * the bin", and "everything this list is showing" for a batch press.
	 *
	 * @param int                 $limit Most records to hand back.
	 * @param array<string,mixed> $args  Same filters as query().
	 * @return int[]
	 */
	public static function all_ids( int $limit = 200, array $args = array() ): array {
		$ids = self::matching_ids( $args );

		return $limit > 0 ? array_slice( $ids, 0, $limit ) : $ids;
	}

	/**
	 * How many records are in the bin.
	 *
	 * Asked of the database every time on purpose: WordPress caches its
	 * post counts per request, and after a sweep that cache is one answer
	 * behind — the menu would say "Bin 7" for a bin that already holds
	 * eleven. A real query cannot be stale.
	 *
	 * @return int
	 */
	public static function count(): int {
		if ( ! self::sees_everything() ) {
			return count( self::matching_ids() );
		}

		$query = new \WP_Query(
			array(
				'post_type'      => self::kinds(),
				'post_status'    => 'trash',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			)
		);

		return (int) $query->found_posts;
	}

	/**
	 * One row of the bin screen, read from the record itself.
	 *
	 * The screen draws a binned property the way it was — its own title,
	 * price, locality and type — plus the four facts the bin adds: who moved
	 * it, when, what it was before, and in which sweep.
	 *
	 * @param int $record_id Record ID.
	 * @return array<string,mixed>
	 */
	public static function row( int $record_id ): array {
		$is_listing = PostTypes::LISTING === get_post_type( $record_id );
		$data       = $is_listing ? Listings::to_array( $record_id ) : array();

		$terms    = get_the_terms( $record_id, Taxonomies::LOCALITY );
		$locality = ( is_array( $terms ) && $terms && isset( $terms[0]->name ) ) ? (string) $terms[0]->name : '';

		return array(
			'id'              => $record_id,
			'title'           => (string) get_the_title( $record_id ),
			'type'            => $is_listing ? (string) get_post_meta( $record_id, '_estat_property_type', true ) : '',
			'offer'           => (string) ( $data['offer'] ?? '' ),
			'locality'        => $locality,
			'price'           => (string) ( $data['price_display'] ?? '' ),
			'deleted_by'      => self::binned_by( $record_id ),
			'deleted_by_name' => self::binned_by_name( $record_id ),
			'deleted_at'      => self::binned_at( $record_id ),
			'previous'        => self::previous_state( $record_id ),
			'previous_label'  => self::previous_state_label( $record_id ),
			'batch'           => (string) get_post_meta( $record_id, self::META_BATCH, true ),
		);
	}

	/**
	 * Who moved things to the bin, in the order they first appear — for the
	 * Deleted by filter. Only people whose records this person may see.
	 *
	 * @return array<int,string> User ID => name.
	 */
	public static function deleted_by_options(): array {
		$out = array();

		foreach ( self::all_ids( 500 ) as $id ) {
			$by = self::binned_by( (int) $id );
			if ( isset( $out[ $by ] ) ) {
				continue;
			}
			$out[ $by ] = self::binned_by_name( (int) $id );
		}

		return $out;
	}

	/**
	 * The localities the bin is actually holding, so the filter never offers
	 * an empty answer.
	 *
	 * @return array<string,string> Slug => name.
	 */
	public static function locality_options(): array {
		$out = array();

		foreach ( self::all_ids( 500 ) as $id ) {
			$terms = get_the_terms( (int) $id, Taxonomies::LOCALITY );
			if ( ! is_array( $terms ) || ! $terms ) {
				continue;
			}
			foreach ( $terms as $term ) {
				$out[ (string) $term->slug ] = (string) $term->name;
			}
		}

		return $out;
	}

	/**
	 * The property types the bin is holding.
	 *
	 * @return string[]
	 */
	public static function type_options(): array {
		$out = array();

		foreach ( self::all_ids( 500 ) as $id ) {
			$type = sanitize_key( (string) get_post_meta( (int) $id, '_estat_property_type', true ) );
			if ( '' === $type || in_array( $type, $out, true ) ) {
				continue;
			}
			$out[] = $type;
		}

		sort( $out );

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Undo: the one press that takes back the last sweep
	 * ------------------------------------------------------------------ */

	/**
	 * Remember a sweep so it can be taken back for the next half hour.
	 *
	 * Kept against the person who did it, not against the records: an Undo
	 * offered to one colleague must never be a button another one can press.
	 *
	 * @param int[] $ids Records that just went to the bin.
	 * @return string Token, '' when there is nothing to remember.
	 */
	public static function remember_undo( array $ids ): string {
		$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
		if ( ! $ids ) {
			return '';
		}

		$token = bin2hex( random_bytes( 8 ) );
		set_transient(
			'estat_bin_undo_' . $token,
			array(
				'user' => get_current_user_id(),
				'ids'  => $ids,
			),
			self::UNDO_MINUTES * MINUTE_IN_SECONDS
		);

		return $token;
	}

	/**
	 * Which records an Undo would bring back, or null when it has expired,
	 * was already used, or belongs to somebody else.
	 *
	 * @param string $token Token from remember_undo().
	 * @return int[]|null
	 */
	public static function undo_ids( string $token ): ?array {
		$token = preg_replace( '/[^a-f0-9]/', '', $token );
		if ( '' === (string) $token ) {
			return null;
		}

		$held = get_transient( 'estat_bin_undo_' . $token );
		if ( ! is_array( $held ) || empty( $held['ids'] ) ) {
			return null;
		}
		if ( (int) ( $held['user'] ?? 0 ) !== get_current_user_id() ) {
			return null;
		}

		return array_values( array_filter( array_map( 'absint', (array) $held['ids'] ) ) );
	}

	/**
	 * Take a sweep back. Each record returns to the state it was in, and the
	 * offer is spent — one Undo, one use.
	 *
	 * @param string $token Token from remember_undo().
	 * @return array{done:int[],failed:array<int,string>,batch:string,states:array<int,string>}
	 */
	public static function undo( string $token ): array {
		$ids = self::undo_ids( $token );
		if ( null === $ids ) {
			return array(
				'done'   => array(),
				'failed' => array(),
				'batch'  => '',
				'states' => array(),
			);
		}

		$clean = preg_replace( '/[^a-f0-9]/', '', $token );
		delete_transient( 'estat_bin_undo_' . $clean );

		return self::batch( 'restore', $ids, __( 'Undo', 'estat-os' ) );
	}

	public static function summary_counts(): array {
		$in_bin = self::count();

		if ( 0 === $in_bin ) {
			return array(
				'in_bin'      => 0,
				'today'       => 0,
				'week'        => 0,
				'oldest_days' => 0,
			);
		}

		$ids   = self::all_ids( 500 );
		$today = 0;
		$week  = 0;
		$oldest = 0;

		foreach ( $ids as $id ) {
			$at = self::binned_at( (int) $id );
			if ( '' === $at ) {
				continue;
			}
			$when = strtotime( $at );
			if ( ! $when ) {
				continue;
			}

			if ( gmdate( 'Y-m-d', $when ) === gmdate( 'Y-m-d' ) ) {
				++$today;
			}
			if ( $when >= time() - ( 7 * DAY_IN_SECONDS ) ) {
				++$week;
			}

			$days = (int) floor( ( time() - $when ) / DAY_IN_SECONDS );
			if ( $days > $oldest ) {
				$oldest = $days;
			}
		}

		return array(
			'in_bin'      => $in_bin,
			'today'       => $today,
			'week'        => $week,
			'oldest_days' => $oldest,
		);
	}

	/**
	 * Why the ones that failed, failed — said in words with the record's
	 * number, so somebody can go and look at the exact one. The first few
	 * are enough: a screen that lists twelve reasons is a screen nobody
	 * reads, and the rest are all in the record's own history anyway.
	 *
	 * @param array<int,string> $failed Record ID => reason.
	 * @return string
	 */
	public static function reasons( array $failed ): string {
		$out = array();

		foreach ( $failed as $id => $reason ) {
			$out[] = sprintf(
				/* translators: 1: record ID, 2: why it failed. */
				__( '#%1$d: %2$s', 'estat-os' ),
				(int) $id,
				(string) $reason
			);

			if ( count( $out ) >= 4 ) {
				break;
			}
		}

		return implode( ' ', $out );
	}

	/**
	 * The state of the record in the office's own words — the same words the
	 * rest of the product uses.
	 *
	 * @param int $record_id Record ID.
	 * @return string
	 */
	public static function previous_state_label( int $record_id ): string {
		$was = self::previous_state( $record_id );

		return '' !== $was ? Status::label( Status::PUBLICATION, $was ) : __( 'Not known', 'estat-os' );
	}
}
