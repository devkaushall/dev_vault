<?php
/**
 * What is missing from a record.
 *
 * The website, the search filters and the structured data all read the same
 * record, so a property with no size, no photo or a bedroom count that
 * disagrees with its own name does not just look untidy — it is the answer a
 * search engine gets. This class is the honest list of what still needs filling,
 * said the way the office says it, and it is used in three places: the editor
 * (this record), the listings screen (the worst offenders first) and a CSV the
 * office can fix in Excel and import back.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Missing or contradictory information on a listing.
 */
final class Health {

	/**
	 * The checks, with how much each one matters.
	 *
	 * "High" is a fact a visitor or a search engine is likely to notice; "medium"
	 * is a gap the office should close when it can.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function rules(): array {
		return array(
			'no_offer'           => array(
				'level' => 'high',
				'label' => __( 'Nothing says whether this is to buy or to rent', 'estat-os' ),
				'hint'  => __( 'Both the website and the search filters ask this first.', 'estat-os' ),
			),
			'no_type'            => array(
				'level' => 'high',
				'label' => __( 'Property type not chosen', 'estat-os' ),
				'hint'  => __( 'Apartment, builder floor, villa, plot, shop, office…', 'estat-os' ),
			),
			'no_locality'        => array(
				'level' => 'high',
				'label' => __( 'No area (locality) on this property', 'estat-os' ),
				'hint'  => __( 'Without it the property is missing from its own area page.', 'estat-os' ),
			),
			'no_price'           => array(
				'level' => 'high',
				'label' => __( 'No price filled in', 'estat-os' ),
				'hint'  => __( 'Fill it in, or tick "Price on request" in the price section.', 'estat-os' ),
			),
			'no_area'            => array(
				'level' => 'high',
				'label' => __( 'Size is empty or 0', 'estat-os' ),
				'hint'  => __( 'A size of 0 reaches the website and the structured data as a real number.', 'estat-os' ),
			),
			'no_bedrooms'        => array(
				'level' => 'high',
				'label' => __( 'No bedroom count on a home', 'estat-os' ),
				'hint'  => __( 'Buyers filter by this, and the property name usually needs it too.', 'estat-os' ),
			),
			'bedrooms_mismatch'  => array(
				'level' => 'high',
				'label' => __( 'The name and the bedroom count disagree', 'estat-os' ),
				'hint'  => __( 'Say one thing and mean it — the name has one number, the record has another.', 'estat-os' ),
			),
			'no_photos'          => array(
				'level' => 'high',
				'label' => __( 'Not one photo', 'estat-os' ),
				'hint'  => __( 'The first photo is what people see on the website and in search results.', 'estat-os' ),
			),
			'thin_description'   => array(
				'level' => 'medium',
				'label' => __( 'The description is very short', 'estat-os' ),
				'hint'  => __( 'Two or three sentences about the light, the neighbourhood and what is nearby.', 'estat-os' ),
			),
			'no_availability'    => array(
				'level' => 'medium',
				'label' => __( 'Availability not filled in', 'estat-os' ),
				'hint'  => __( 'Available / not available is shown on the website; blank is guesswork for a visitor.', 'estat-os' ),
			),
			'no_agent'           => array(
				'level' => 'medium',
				'label' => __( 'Nobody in the office is looking after it', 'estat-os' ),
				'hint'  => __( 'Nobody is answerable when a client calls about this property.', 'estat-os' ),
			),
			'not_verified'       => array(
				'level' => 'medium',
				'label' => __( 'The office has not verified it yet', 'estat-os' ),
				'hint'  => __( 'The website talks about verified properties; this one does not say that yet.', 'estat-os' ),
			),
		);
	}

	/**
	 * Property types that are a home, and so are expected to have bedrooms.
	 *
	 * @return string[]
	 */
	public static function home_types(): array {
		return array( 'apartment', 'builder_floor', 'villa', 'farm_house', 'flat', 'studio', 'penthouse', 'independent_house' );
	}

	/**
	 * Everything missing from one listing.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string[] Check keys, worst first.
	 */
	public static function of( int $listing_id ): array {
		$post = get_post( $listing_id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type || 'trash' === $post->post_status ) {
			return array();
		}

		$found = array();
		$meta  = static function ( string $key ) use ( $listing_id ): string {
			$value = get_post_meta( $listing_id, $key, true );
			return is_scalar( $value ) ? trim( (string) $value ) : '';
		};

		if ( '' === $meta( '_estat_offer' ) ) {
			$found[] = 'no_offer';
		}
		if ( '' === $meta( '_estat_property_type' ) ) {
			$found[] = 'no_type';
		}
		$localities = wp_get_post_terms( $listing_id, Taxonomies::LOCALITY );
		if ( is_wp_error( $localities ) || ! $localities ) {
			$found[] = 'no_locality';
		}
		$price_type = $meta( '_estat_price_type' );
		$price      = (float) $meta( '_estat_price' );
		$rent       = (float) $meta( '_estat_rent' );
		if ( 'on_request' !== $price_type && $price <= 0 && $rent <= 0 && '' === $meta( '_estat_price_min' ) ) {
			$found[] = 'no_price';
		}
		if ( (float) $meta( '_estat_area' ) <= 0 ) {
			$found[] = 'no_area';
		}

		$bedrooms = (int) $meta( '_estat_bedrooms' );
		$type     = $meta( '_estat_property_type' );
		if ( in_array( $type, self::home_types(), true ) && $bedrooms <= 0 ) {
			$found[] = 'no_bedrooms';
		}
		$in_name = self::bedrooms_in_title( (string) $post->post_title );
		if ( $in_name > 0 && $bedrooms > 0 && $in_name !== $bedrooms ) {
			$found[] = 'bedrooms_mismatch';
		}

		$gallery = (array) get_post_meta( $listing_id, '_estat_gallery', true );
		$gallery = array_filter( array_map( 'intval', $gallery ) );
		if ( ! $gallery && ! get_post_thumbnail_id( $listing_id ) ) {
			$found[] = 'no_photos';
		}

		if ( strlen( wp_strip_all_tags( (string) $post->post_content ) ) < 120 ) {
			$found[] = 'thin_description';
		}
		if ( '' === $meta( '_estat_availability' ) ) {
			$found[] = 'no_availability';
		}
		if ( (int) $meta( '_estat_agent_id' ) <= 0 && (int) $meta( '_estat_assigned_user' ) <= 0 ) {
			$found[] = 'no_agent';
		}
		if ( '' === $meta( '_estat_verification' ) || 'unverified' === $meta( '_estat_verification' ) ) {
			$found[] = 'not_verified';
		}

		return $found;
	}

	/**
	 * The bedroom count a property name claims, 0 when it does not say.
	 *
	 * "4 BHK with servant room" → 4. "3.5 BHK" → 3 (the whole number is what
	 * the record holds). "Studio" → 0, because it did not claim anything.
	 *
	 * @param string $title Property name.
	 * @return int
	 */
	public static function bedrooms_in_title( string $title ): int {
		if ( preg_match( '/(\d{1,2})(?:\.\d)?\s*(?:bhk|bed\s?room|bedroom)/i', $title, $match ) ) {
			return (int) $match[1];
		}
		return 0;
	}

	/**
	 * The worst level found in a set of checks.
	 *
	 * @param string[] $keys Check keys.
	 * @return string 'high', 'medium' or ''.
	 */
	public static function level( array $keys ): string {
		$rules = self::rules();
		foreach ( array( 'high', 'medium' ) as $level ) {
			foreach ( $keys as $key ) {
				if ( ( $rules[ $key ]['level'] ?? '' ) === $level ) {
					return $level;
				}
			}
		}
		return '';
	}

	/**
	 * Every property that needs attention, worst first.
	 *
	 * @param int $limit How many to return.
	 * @return array<int,array<string,mixed>> Rows: id, title, status, keys, level.
	 */
	public static function attention( int $limit = 50 ): array {
		$ids = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 300,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$rows  = array();
		$order = array( 'high' => 0, 'medium' => 1 );
		foreach ( $ids as $id ) {
			$keys = self::of( (int) $id );
			if ( ! $keys ) {
				continue;
			}
			$rows[] = array(
				'id'     => (int) $id,
				'title'  => (string) get_the_title( $id ),
				'status' => (string) get_post_status( $id ),
				'keys'   => $keys,
				'level'  => self::level( $keys ),
			);
		}

		usort(
			$rows,
			static function ( array $a, array $b ) use ( $order ): int {
				$level = ( $order[ $a['level'] ] ?? 2 ) <=> ( $order[ $b['level'] ] ?? 2 );
				if ( 0 !== $level ) {
					return $level;
				}
				return count( $b['keys'] ) <=> count( $a['keys'] );
			}
		);

		return array_slice( $rows, 0, $limit );
	}

	/**
	 * How many properties have a problem, and how many have a serious one.
	 *
	 * @return array<string,int>
	 */
	public static function summary(): array {
		$ids       = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 300,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$total     = count( $ids );
		$flagged   = 0;
		$serious   = 0;
		$per_check = array();
		foreach ( $ids as $id ) {
			$keys = self::of( (int) $id );
			if ( ! $keys ) {
				continue;
			}
			$flagged++;
			if ( 'high' === self::level( $keys ) ) {
				$serious++;
			}
			foreach ( $keys as $key ) {
				$per_check[ $key ] = ( $per_check[ $key ] ?? 0 ) + 1;
			}
		}
		arsort( $per_check );

		return array(
			'total'     => $total,
			'flagged'   => $flagged,
			'serious'   => $serious,
			'per_check' => $per_check,
		);
	}

	/**
	 * Terms whose name looks like it was cut in half by an import: an unclosed
	 * bracket, a stray one, or stray spaces.
	 *
	 * @param string $taxonomy Taxonomy to look at.
	 * @return array<int,array<string,mixed>> Rows: term, why.
	 */
	public static function suspect_terms( string $taxonomy ): array {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}

		$rows = array();
		foreach ( $terms as $term ) {
			$why = self::name_looks_wrong( (string) $term->name );
			if ( '' === $why ) {
				/*
				 * A name can be well formed and still be a second spelling of
				 * another one — "DLP Phase 5" next to "DLF Phase 5" is one area
				 * with two pages, and the properties are split between them.
				 */
				$why = self::name_looks_like_another( (string) $term->name, $terms, (int) $term->term_id );
			}
			if ( '' === $why ) {
				continue;
			}
			$rows[] = array(
				'term'    => $term,
				'why'     => $why,
				'count'   => (int) $term->count,
				'listing' => self::term_listing_count( (int) $term->term_id, (string) $term->taxonomy ),
			);
		}
		return $rows;
	}

	/**
	 * Why a name looks wrong, or '' when it is fine.
	 *
	 * @param string $name Term name.
	 * @return string
	 */
	public static function name_looks_wrong( string $name ): string {
		if ( '' === trim( $name ) ) {
			return __( 'The name is empty', 'estat-os' );
		}
		if ( trim( $name ) !== $name ) {
			return __( 'There is a space at the start or the end', 'estat-os' );
		}
		$open  = substr_count( $name, '(' );
		$close = substr_count( $name, ')' );
		if ( $open > $close ) {
			return __( 'A bracket is opened and never closed — the name was cut in half', 'estat-os' );
		}
		if ( $close > $open ) {
			return __( 'There is a closing bracket with nothing before it', 'estat-os' );
		}
		if ( preg_match( '/[,;|]$/', $name ) || preg_match( '/\s{2,}/', $name ) ) {
			return __( 'It ends in punctuation or has double spaces', 'estat-os' );
		}
		return '';
	}

	/**
	 * Whether a name is one letter away from another name in the same list.
	 *
	 * Only for names long enough that a single letter is a typo rather than a
	 * different place ("Sector 50" and "Sector 51" are two sectors, and their
	 * names differ by one letter, but a digit in the name is never treated as
	 * a slip).
	 *
	 * @param string       $name    Term name.
	 * @param array<object> $terms  Every term in the taxonomy.
	 * @param int          $skip_id The term itself.
	 * @return string Why it looks wrong, or ''.
	 */
	private static function name_looks_like_another( string $name, array $terms, int $skip_id ): string {
		/*
		 * Compare the words and the numbers apart from each other: "Sector 50"
		 * next to "Sector 51" is two sectors, and their numbers are what differ,
		 * while "DLP Phase 5" next to "DLF Phase 5" is the same sector with a
		 * letter mistyped.
		 */
		$words  = static fn( string $text ): string => (string) preg_replace( '/[^a-z]+/', '', strtolower( $text ) );
		$digits = static fn( string $text ): string => (string) preg_replace( '/[^0-9]+/', '', $text );

		$mine = $words( $name );
		if ( strlen( $mine ) < 6 ) {
			return '';
		}

		foreach ( $terms as $other ) {
			if ( (int) $other->term_id === $skip_id ) {
				continue;
			}
			$theirs = $words( (string) $other->name );
			if ( '' === $theirs || $theirs === $mine ) {
				continue;
			}
			if ( strlen( $theirs ) < 6 ) {
				continue;
			}
			// Same words one letter apart, and the same numbers: one place.
			if ( $digits( $name ) === $digits( (string) $other->name ) && strlen( $theirs ) === strlen( $mine ) && 1 === levenshtein( $mine, $theirs ) ) {
				return sprintf(
					/* translators: %s: the other name it looks like */
					__( 'It looks like the same place as "%s" — one letter apart', 'estat-os' ),
					(string) $other->name
				);
			}
		}

		return '';
	}

	/**
	 * How many published listings carry a term.
	 *
	 * @param int    $term_id  Term ID.
	 * @param string $taxonomy Taxonomy.
	 * @return int
	 */
	public static function term_listing_count( int $term_id, string $taxonomy ): int {
		$query = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => $taxonomy,
						'field'    => 'term_id',
						'terms'    => $term_id,
					),
				),
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * The attention list as a spreadsheet: one row per property, one column per
	 * check, so it can be sorted and worked through in Excel.
	 *
	 * @param array<int,array<string,mixed>> $rows Rows from attention().
	 * @return string CSV text.
	 */
	public static function csv( array $rows ): string {
		$rules = self::rules();
		$head  = array_merge(
			array( 'external_id', 'title', 'status', 'problems', 'severity', 'edit_link' ),
			array_keys( $rules )
		);
		$out   = array( self::csv_row( $head ) );
		foreach ( $rows as $row ) {
			$id    = (int) $row['id'];
			$flags = array();
			foreach ( array_keys( $rules ) as $key ) {
				$flags[] = in_array( $key, (array) $row['keys'], true ) ? 'yes' : '';
			}
			$labels = array();
			foreach ( (array) $row['keys'] as $key ) {
				$labels[] = (string) ( $rules[ $key ]['label'] ?? $key );
			}
			$line = array_merge(
				array(
					(string) get_post_meta( $id, '_estat_external_id', true ),
					(string) $row['title'],
					(string) $row['status'],
					implode( ' | ', $labels ),
					(string) $row['level'],
					admin_url( 'admin.php?page=estat-listings&edit=' . $id ),
				),
				$flags
			);
			$out[] = self::csv_row( $line );
		}
		return implode( "\n", $out ) . "\n";
	}

	/**
	 * One CSV line, quoted so commas in names survive Excel.
	 *
	 * @param string[] $cells Cells.
	 * @return string
	 */
	private static function csv_row( array $cells ): string {
		$safe = array();
		foreach ( $cells as $cell ) {
			$cell   = str_replace( '"', '""', (string) $cell );
			$safe[] = '"' . $cell . '"';
		}
		return implode( ',', $safe );
	}

	/**
	 * The city the office works in, for sentences that need it.
	 *
	 * @return string
	 */
	public static function city(): string {
		return (string) Settings::get( 'city', '' );
	}
}
