<?php
/**
 * Office admin: menu, assets and screen routing.
 * The single sidebar and screen list.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public const MENU = 'estat-today';

	/**
	 * The Settings menu, on its own at the top of the sidebar.
	 *
	 * Everything that changes how the office or the staff phone app behaves
	 * lives behind this one word, so nobody has to remember which screen a
	 * switch happens to be on.
	 */
	public const SETTINGS_MENU = 'estat-settings';

	public function register(): void {

		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( Actions::class, 'handle' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
		add_action( 'admin_head', array( $this, 'hide_clutter' ) );
		add_action( 'wp_ajax_estat_upload_file', array( __CLASS__, 'ajax_upload' ) );
		add_action( 'wp_ajax_estat_move_pipeline', array( __CLASS__, 'ajax_move_pipeline' ) );
		add_action( 'wp_ajax_estat_test_mail', array( __CLASS__, 'ajax_test_mail' ) );
		add_action( 'wp_ajax_estat_test_webhook', array( __CLASS__, 'ajax_test_webhook' ) );
		add_action( 'wp_ajax_estat_lead_timeline', array( __CLASS__, 'ajax_lead_timeline' ) );
		add_action( 'admin_notices', array( $this, 'setup_nudge' ) );
		add_action( 'admin_init', array( $this, 'maybe_greet' ), 5 );
	}

	public function maybe_greet(): void {
		if ( '1' !== (string) get_option( 'estat_show_setup', '' ) ) { return; }
		delete_option( 'estat_show_setup' );
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
		if ( ! current_user_can( 'estat_manage_settings' ) ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['activate-multi'] ) ) { return; }
		wp_safe_redirect( admin_url( 'admin.php?page=' . Screens\SetupScreen::SLUG ) );
		exit;
	}

	public function setup_nudge(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) || ! Screens\SetupScreen::needed() ) { return; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['page']) ? '' : $_GET['page'] ) ) ) : '';
		if ( 0 !== strpos( $page, 'estat-' ) || Screens\SetupScreen::SLUG === $page ) { return; }
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a class="button button-primary" href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Your website is not showing your properties yet.', 'estat-os' ),
			esc_html__( 'Answer four short questions and we will build the pages for you.', 'estat-os' ),
			esc_url( admin_url( 'admin.php?page=' . Screens\SetupScreen::SLUG ) ),
			esc_html__( 'Finish setup', 'estat-os' )
		);
	}

	/**
	 * Every screen the office has, written down once.
	 *
	 * The sidebar, the routing table and the page heading all read from this
	 * one list. Adding a screen means adding one entry here and nothing else,
	 * so a screen can never again be routed but not registered — which is how
	 * eight of them became unreachable in 3.0.7.
	 *
	 * 'menu'   => false keeps a screen out of the sidebar while still
	 *             registering it, so links inside other screens work.
	 * 'design' => which of the two looks the screen is drawn in. 'new' screens
	 *             draw their own heading; 'classic' ones use Partials::header().
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function pages(): array {
		$listings = 'estat_manage_listings';

		return array(
			'estat-today'         => array(
				'title'  => __( 'Today', 'estat-os' ),
				'cap'    => $listings,
				'menu'   => true,
				'design' => 'new',
				'class'  => Screens\TodayNew::class,
			),
			'estat-add-home'      => array(
				'title'  => __( 'Add a home', 'estat-os' ),
				'cap'    => $listings,
				'menu'   => true,
				'design' => 'new',
				'class'  => Screens\AddHomeNew::class,
			),
			'estat-listings'      => array(
				'title'  => __( 'Properties', 'estat-os' ),
				'cap'    => $listings,
				'menu'   => true,
				'design' => 'new',
				'class'  => Screens\ListingsNew::class,
			),
			/*
			 * The bin is its own screen, not a filter on the working list.
			 * What you do here (bring something back, or end it for good) is
			 * a different kind of decision from what you do to a live
			 * property, and mixing the two lists is how offices end up
			 * deleting something they meant to restore.
			 */
			'estat-bin'           => array(
				'title'  => __( 'Bin', 'estat-os' ),
				'cap'    => 'estat_bin_listings',
				'menu'   => true,
				'design' => 'new',
				'class'  => Screens\BinScreen::class,
			),
			'estat-enquiries'     => array(
				'title'  => __( 'Enquiries', 'estat-os' ),
				'cap'    => 'estat_manage_leads',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\Enquiries::class,
			),
			'estat-projects'      => array(
				'title'  => __( 'Societies / Projects', 'estat-os' ),
				'cap'    => 'estat_manage_projects',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\ProjectsScreen::class,
			),
			'estat-team'          => array(
				'title'  => __( 'Team', 'estat-os' ),
				'cap'    => 'estat_manage_team',
				'menu'   => true,
				'design' => 'new',
				'class'  => Screens\TeamNew::class,
			),
			'estat-spreadsheet'   => array(
				'title'  => __( 'Import & export', 'estat-os' ),
				'cap'    => 'estat_import_inventory',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\SpreadsheetScreen::class,
			),
			'estat-settings'      => array(
				'title'  => __( 'Settings', 'estat-os' ),
				'cap'    => 'estat_manage_settings',
				'menu'   => true,
				'parent' => self::SETTINGS_MENU,
				'design' => 'new',
				'class'  => Screens\SettingsNew::class,
			),

			// Everyday screens. These sit in the sidebar so nobody has to
			// remember a hidden link. Setup-only screens stay out (see below).
			'estat-pipeline'      => array(
				'title'  => __( 'Pipeline', 'estat-os' ),
				'cap'    => 'estat_manage_leads',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\PipelineScreen::class,
			),
			'estat-visits'        => array(
				'title'  => __( 'Site Visits', 'estat-os' ),
				'cap'    => 'estat_manage_visits',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\VisitsScreen::class,
			),
			'estat-requests'      => array(
				'title'  => __( 'Change Requests', 'estat-os' ),
				'cap'    => 'estat_request_listings',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\RequestsScreen::class,
			),
			'estat-forms'         => array(
				'title'  => __( 'Website forms', 'estat-os' ),
				'cap'    => 'estat_manage_forms',
				'menu'   => true,
				'parent' => self::SETTINGS_MENU,
				'design' => 'classic',
				'class'  => Screens\FormsScreen::class,
			),
			'estat-search-alerts' => array(
				'title'  => __( 'Search Alerts', 'estat-os' ),
				'cap'    => 'estat_manage_leads',
				'menu'   => false,
				'design' => 'classic',
				'class'  => Screens\SearchAlertsScreen::class,
			),
			'estat-reports'       => array(
				'title'  => __( 'Reports', 'estat-os' ),
				'cap'    => 'estat_view_reports',
				'menu'   => true,
				'design' => 'classic',
				'class'  => Screens\Reports::class,
			),
			'estat-gallery'       => array(
				'title'  => __( 'Gallery & Media', 'estat-os' ),
				'cap'    => $listings,
				'menu'   => false,
				'design' => 'classic',
				'class'  => Screens\GalleryScreen::class,
			),
			'estat-insights'      => array(
				'title'  => __( 'Insights', 'estat-os' ),
				'cap'    => 'estat_manage_insights',
				'menu'   => false,
				'design' => 'classic',
				'class'  => Screens\InsightsScreen::class,
			),
			/*
			 * Looks and words. These two are settings as much as the switches
			 * are — which colours the website uses, and what each page says —
			 * so they sit under Settings rather than being hidden links.
			 */
			'estat-templates'     => array(
				'title'  => __( 'Page blocks', 'estat-os' ),
				'cap'    => 'estat_manage_settings',
				'menu'   => true,
				'parent' => self::SETTINGS_MENU,
				'design' => 'classic',
				'class'  => Screens\TemplatesScreen::class,
			),
			'estat-design-tokens' => array(
				'title'  => __( 'Colours & fonts', 'estat-os' ),
				'cap'    => 'estat_manage_settings',
				'menu'   => true,
				'parent' => self::SETTINGS_MENU,
				'design' => 'classic',
				'class'  => Screens\DesignTokensScreen::class,
			),
			// Shown in the sidebar only until setup has been finished once.
			Screens\SetupScreen::SLUG => array(
				'title'  => __( 'Finish setup', 'estat-os' ),
				'cap'    => 'estat_manage_settings',
				'menu'   => Screens\SetupScreen::needed(),
				// This screen draws its own heading and its own help box.
				// Saying "classic" here made the shared header print as well, so
				// the page showed everything twice.
				'design' => 'new',
				'class'  => Screens\SetupScreen::class,
			),
		);
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'Office', 'estat-os' ),
			__( 'Office', 'estat-os' ),
			'estat_manage_listings',
			self::MENU,
			array( $this, 'route' ),
			'dashicons-building',
			3
		);

		add_menu_page(
			__( 'Settings', 'estat-os' ),
			__( 'Settings', 'estat-os' ),
			'estat_manage_settings',
			self::SETTINGS_MENU,
			array( $this, 'route' ),
			'dashicons-admin-settings',
			4
		);

		/*
		 * The settings screen holds its groups behind one address
		 * (?page=estat-settings&tab=...). Each group gets its own line in the
		 * sidebar, right under Settings, so nothing has to be hunted for — every
		 * line points at the same screen with a different tab.
		 */
		if ( current_user_can( 'estat_manage_settings' ) ) {
			foreach ( Screens\SettingsNew::groups() as $key => $group ) {
				if ( 'overview' === $key ) {
					continue; // The first line is the Settings line itself.
				}
				add_submenu_page(
					self::SETTINGS_MENU,
					(string) $group['label'],
					(string) $group['menu_label'],
					'estat_manage_settings',
					self::SETTINGS_MENU . '&tab=' . $key,
					array( $this, 'route' )
				);
			}
		}

		foreach ( self::pages() as $slug => $page ) {
			add_submenu_page(
				empty( $page['menu'] ) ? '' : ( $page['parent'] ?? self::MENU ),
				$page['title'],
				$page['title'],
				$page['cap'],
				$slug,
				array( $this, 'route' )
			);
		}

		/*
		 * WordPress names the first line of a menu after the menu itself, so the
		 * line under Settings read "Settings" — the same word twice in a row,
		 * and no hint that it is the page that summarises the rest. It is called
		 * Overview from here on.
		 */
		global $submenu;
		if ( ! empty( $submenu[ self::SETTINGS_MENU ] ) && is_array( $submenu[ self::SETTINGS_MENU ] ) ) {
			$items = $submenu[ self::SETTINGS_MENU ];
			$seen  = false;
			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) || self::SETTINGS_MENU !== ( $item[2] ?? '' ) ) {
					continue;
				}
				if ( $seen ) {
					unset( $items[ $index ] ); // WordPress ka apna duplicate.
					continue;
				}
				$items[ $index ][0] = __( 'Overview', 'estat-os' );
				$seen = true;
			}
			$submenu[ self::SETTINGS_MENU ] = array_values( $items );
		}

		/*
		 * How much is in each list, on the line that opens it.
		 *
		 * "Properties 128" and "Bin 7" answer the two questions the sidebar
		 * is asked all day — how much have we got, and has anything gone
		 * missing — without opening a screen. The numbers are permission
		 * aware: an agent sees what they may see, and a bin with nothing in
		 * it says 0 rather than nothing at all.
		 */
		if ( ! empty( $submenu[ self::MENU ] ) && is_array( $submenu[ self::MENU ] ) ) {
			$items = $submenu[ self::MENU ];

			$property_count = 0;
			if ( current_user_can( 'estat_manage_listings' ) ) {
				$counts = (array) wp_count_posts( \EstatOS\Data\PostTypes::LISTING );
				foreach ( array( 'publish', 'draft', 'pending', 'private', 'future' ) as $state ) {
					$property_count += (int) ( $counts[ $state ] ?? 0 );
				}
			}

			$bin_count = current_user_can( 'estat_bin_listings' ) ? \EstatOS\Data\Bin::count() : 0;

			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) || empty( $item[2] ) ) {
					continue;
				}

				if ( 'estat-listings' === $item[2] ) {
					$items[ $index ][0] = sprintf(
						'%1$s <span class="estat-menu-count">%2$s</span>',
						__( 'Properties', 'estat-os' ),
						esc_html( number_format_i18n( $property_count ) )
					);
				}

				if ( 'estat-bin' === $item[2] ) {
					$items[ $index ][0] = sprintf(
						'%1$s <span class="estat-menu-count%3$s">%2$s</span>',
						__( 'Bin', 'estat-os' ),
						esc_html( number_format_i18n( $bin_count ) ),
						0 === $bin_count ? ' is-empty' : ''
					);
				}
			}

			$submenu[ self::MENU ] = array_values( $items );
		}

		// WordPress puts its own copy of the parent item first in the submenu,
		// using the menu title ("Office") for it. That copy is the duplicate we
		// do not want — but on WordPress 6.5+ that copy is sometimes missing, so
		// removing whatever sits at position 0 would delete the real "Today"
		// entry and the screen would vanish from the sidebar (it did).
		// So: keep exactly one entry that points at this menu's own page, and
		// make sure it is the one titled "Today", sitting at the top.
		if ( ! empty( $submenu[ self::MENU ] ) && is_array( $submenu[ self::MENU ] ) ) {
			$items = $submenu[ self::MENU ];
			$keep  = null;

			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) || self::MENU !== ( $item[2] ?? '' ) ) {
					continue;
				}
				if ( null === $keep ) {
					$keep = $item; // Pehli hi asli "Today" hai — use rakho.
				}
				unset( $items[ $index ] );
			}

			if ( null !== $keep ) {
				// Hamesha ek hi entry, aur sabse upar.
				array_unshift( $items, $keep );
				$submenu[ self::MENU ] = array_values( $items );
			}
		}
	}

	public function route(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$requested = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array( $_GET['page'] ) ? '' : $_GET['page'] ) ) : self::MENU;

		$pages = self::pages();
		$page  = $requested;
		$entry = $pages[ $page ] ?? null;

		if ( null === $entry || ! class_exists( $entry['class'] ) ) {
			$page  = self::MENU;
			$entry = $pages[ self::MENU ];
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$editing_form = 'estat-forms' === $page && ! empty( $_GET['edit'] );
		$wrap_class   = $editing_form ? 'wrap estat-admin estat-wrap-wide' : 'wrap estat-admin';

		echo '<div class="' . esc_attr( $wrap_class ) . '">';

		if ( 'new' === $entry['design'] ) {
			// These screens draw their own heading. Showing the classic one as
			// well put two titles on the same page.
			Screens\Partials::notices();
		} else {
			Screens\Partials::header( $page, $editing_form );
		}

		$handler = array( $entry['class'], 'render' );
		if ( is_callable( $handler ) ) {
			call_user_func( $handler );
		}

		// One confirmation dialog for the whole page, so nothing destructive
		// happens from a single press anywhere in the office.
		Screens\Partials::confirm_panel();

		echo '</div>';
	}

	public function assets( string $hook ): void {
		if ( false === strpos( $hook, 'estat-' )
			&& 'toplevel_page_' . self::MENU !== $hook
			&& 'toplevel_page_' . self::SETTINGS_MENU !== $hook ) {
			return;
		}
		wp_enqueue_style( 'estat-tokens', ESTAT_URL . 'assets/css/tokens.css', array(), ESTAT_VERSION );
		wp_enqueue_style( 'estat-admin', ESTAT_URL . 'assets/css/admin.css', array( 'estat-tokens' ), ESTAT_VERSION );
		wp_enqueue_style( 'estat-admin-new', ESTAT_URL . 'assets/css/admin-new.css', array( 'estat-admin' ), ESTAT_VERSION );
		// Last word on the form fields and the line between one section and the
		// next, so it loads after both sheets above.
		wp_enqueue_style( 'estat-fields', ESTAT_URL . 'assets/css/fields.css', array( 'estat-admin-new' ), ESTAT_VERSION );
		wp_enqueue_script( 'estat-admin', ESTAT_URL . 'assets/js/admin.js', array( 'wp-i18n' ), ESTAT_VERSION, true );
		wp_enqueue_media();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 'estat-forms' === $page ) {
			wp_enqueue_style( 'estat-forms', ESTAT_URL . 'assets/css/forms.css', array(), ESTAT_VERSION );
			wp_enqueue_script( 'estat-form-builder', ESTAT_URL . 'assets/js/form-builder.js', array( 'estat-admin' ), ESTAT_VERSION, true );
			wp_localize_script(
				'estat-form-builder',
				'estatBuilder',
				array(
					'fieldTypes' => \EstatOS\Forms\FieldTypes::all(),
					'i18n'       => array(
						'newField'     => __( 'New field', 'estat-os' ),
						'confirmDelete'=> __( 'Remove this field?', 'estat-os' ),
						'label'        => __( 'Label', 'estat-os' ),
						'placeholder'  => __( 'Example text inside the box', 'estat-os' ),
						'help'         => __( 'Short explanation', 'estat-os' ),
						'required'     => __( 'This information is required', 'estat-os' ),
						'width'        => __( 'Width on a computer', 'estat-os' ),
						'widthTablet'  => __( 'Width on a tablet', 'estat-os' ),
						'widthMobile'  => __( 'Width on a phone', 'estat-os' ),
						'options'      => __( 'Choices (one per line)', 'estat-os' ),
						'remove'       => __( 'Remove', 'estat-os' ),
						'addRow'       => __( 'Add a row', 'estat-os' ),
						'addColumn'    => __( 'Add a column', 'estat-os' ),
						'dragHint'     => __( 'Drag to reorder', 'estat-os' ),
						'moveUp'       => __( 'Move up', 'estat-os' ),
						'moveDown'     => __( 'Move down', 'estat-os' ),
						'layout'       => __( 'Columns', 'estat-os' ),
						'gap'          => __( 'Spacing', 'estat-os' ),
						'align'        => __( 'Align', 'estat-os' ),
						'alignStretch' => __( 'Same height', 'estat-os' ),
						'alignStart'   => __( 'Top', 'estat-os' ),
						'alignCenter'  => __( 'Middle', 'estat-os' ),
						'alignEnd'     => __( 'Bottom', 'estat-os' ),
						'rowHeading'   => __( 'Optional heading for this row', 'estat-os' ),
						'columnWidth'  => __( 'Width', 'estat-os' ),
						'removeColumn' => __( 'Remove this column', 'estat-os' ),
						'confirmDeleteRow' => __( 'Remove this row and everything in it?', 'estat-os' ),
						'boxHeight'    => __( 'Box height', 'estat-os' ),
						'boxWidth'     => __( 'Box width', 'estat-os' ),
						'sizeSM'       => __( 'Small', 'estat-os' ),
						'sizeMD'       => __( 'Medium', 'estat-os' ),
						'sizeLG'       => __( 'Large', 'estat-os' ),
						'lines'        => __( 'Lines of space to type in', 'estat-os' ),
						'exactWidths'  => __( 'Exact widths', 'estat-os' ),
						'deviceBar'    => __( 'Show the layout as it appears on', 'estat-os' ),
						'deviceDesktop'=> __( 'Computer', 'estat-os' ),
						'deviceTablet' => __( 'Tablet', 'estat-os' ),
						'deviceMobile' => __( 'Phone', 'estat-os' ),
						'deviceHintDesktop' => __( 'Editing computer widths.', 'estat-os' ),
						'deviceHintTablet'  => __( 'Editing tablet widths only.', 'estat-os' ),
						'deviceHintMobile'  => __( 'Editing phone widths only.', 'estat-os' ),
						'conditionOn'  => __( 'Only shown sometimes', 'estat-os' ),
						'conditionOff' => __( 'Always shown', 'estat-os' ),
						'conditionWhen'=> __( 'Only show this box when', 'estat-os' ),
						'conditionIs'  => __( 'is', 'estat-os' ),
						'conditionAlways' => __( '— always show it —', 'estat-os' ),
						'conditionValue'  => __( 'has this answer', 'estat-os' ),
						'previewEmpty' => __( 'Add a field and it will appear here.', 'estat-os' ),
						'previewSend'  => __( 'Send', 'estat-os' ),
						'previewChoices' => __( 'Choices', 'estat-os' ),
						'previewHidden'  => __( 'Hidden on this device', 'estat-os' ),
					),
				)
			);
		}
		wp_localize_script(
			'estat-admin',
			'estatAdmin',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'estat/v1/' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'uploadNonce' => wp_create_nonce( 'estat_upload' ),
				'urls'          => array(
					'today'      => admin_url( 'admin.php?page=estat-today' ),
					'listings'   => admin_url( 'admin.php?page=estat-listings' ),
					'enquiries'  => admin_url( 'admin.php?page=estat-enquiries' ),
					'addHome'    => admin_url( 'admin.php?page=estat-add-home' ),
				),
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'i18n'     => array(
					'confirmDelete' => __( 'Are you sure? This cannot be undone.', 'estat-os' ),
					'typeDelete'    => __( 'Type DELETE in capital letters to confirm.', 'estat-os' ),
					'chooseImage'   => __( 'Choose an image', 'estat-os' ),
					'useImage'      => __( 'Use this image', 'estat-os' ),
					'tapToChoose'   => __( 'Tap to choose a photo', 'estat-os' ),
					'bulkOne'       => __( '1 selected', 'estat-os' ),
					'bulkMany'      => __( '%d selected', 'estat-os' ),
					'bulkConfirmTrash' => __( 'Move %d records to the bin? You can bring them back afterwards.', 'estat-os' ),
					'nothingChosen' => __( 'Tick something in the list first.', 'estat-os' ),
					'typeToConfirm' => __( 'Type DELETE in capital letters to confirm.', 'estat-os' ),
					'confirmGo'     => __( 'Yes, do it', 'estat-os' ),
					'binNote'       => __( 'They come off the website and can be restored later.', 'estat-os' ),
					'shortcutsTitle'   => __( 'Keyboard shortcuts', 'estat-os' ),
					'shortcutSearch'   => __( 'Jump to the search box', 'estat-os' ),
					'shortcutNew'      => __( 'Add a Home', 'estat-os' ),
					'shortcutToday'    => __( 'Go to Today', 'estat-os' ),
					'shortcutListings' => __( 'Go to Listings', 'estat-os' ),
					'shortcutEnquiries' => __( 'Go to Enquiries', 'estat-os' ),
					'shortcutSave'     => __( 'Save what you are editing', 'estat-os' ),
					'shortcutHelp'     => __( 'Show this list', 'estat-os' ),
					'shortcutClose'    => __( 'Close this list', 'estat-os' ),
					'shortcutCloseButton' => __( 'Close', 'estat-os' ),
					'saving'        => __( 'Saving…', 'estat-os' ),
					'copied'        => __( 'Copied.', 'estat-os' ),
					'uploading'     => __( 'Adding your files…', 'estat-os' ),
					'uploadDone'    => __( 'Done. Refreshing…', 'estat-os' ),
					'uploadFailed'  => __( 'Could not add this file:', 'estat-os' ),
					'tooBig'        => __( 'This file is too large to upload.', 'estat-os' ),
				),
			)
		);
	}

	public static function ajax_upload(): void {
		check_ajax_referer( 'estat_upload', 'nonce' );
		if ( ! current_user_can( 'estat_manage_listings' ) || ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to add files.', 'estat-os' ) ), 403 );
		}
		if ( empty( $_FILES['file'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file arrived. Please try again.', 'estat-os' ) ), 400 );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_handle_upload( 'file', 0 );
		if ( is_wp_error( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ), 400 );
		}
		$attachment_id = (int) $attachment_id;
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( is_array($_POST['kind']) ? '' : $_POST['kind'] ) ) : '';
		if ( '' !== $kind ) { \EstatOS\Data\Media::set_kind( $attachment_id, $kind ); }
		\EstatOS\Audit\AuditLog::record( 'media.uploaded', 'attachment', $attachment_id, array( 'kind' => $kind ) );
		wp_send_json_success( \EstatOS\Data\Media::to_array( $attachment_id ) );
	}

	public static function ajax_move_pipeline(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$lead_id = isset( $_POST['lead_id'] ) ? absint( wp_unslash( is_array($_POST['lead_id']) ? '' : $_POST['lead_id'] ) ) : 0;
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( is_array($_POST['status']) ? '' : $_POST['status'] ) ) : '';
		$allowed = \EstatOS\Support\Vocabulary::lead_pipeline_order();
		if ( ! in_array( $status, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid status', 'estat-os' ) ), 400 );
		}
		$result = \EstatOS\Leads\Leads::update( $lead_id, array( 'status' => $status ) );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 422 );
		}
		wp_send_json_success( array( 'lead_id' => $lead_id, 'status' => $status ) );
	}

	public static function ajax_test_mail(): void {
		check_ajax_referer( 'estat_test_mail', 'nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$email = Settings::notification_email();
		$sent = wp_mail( $email, __( 'Test email from your property website', 'estat-os' ), __( 'If you got this, your email settings are working.', 'estat-os' ) );
		if ( $sent ) {
			Settings::update( array( 'test_mail_last_sent' => current_time( 'mysql' ) ) );
			wp_send_json_success( array( 'message' => sprintf( __( 'Test email sent to %s', 'estat-os' ), $email ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Could not send email. Check your hosting mail setup.', 'estat-os' ) ), 500 );
		}
	}

	public static function ajax_test_webhook(): void {
		check_ajax_referer( 'estat_test_webhook', 'nonce' );
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$res = \EstatOS\Webhooks\Webhooks::test();
		if ( ( $res['ok'] ?? false ) ) {
			wp_send_json_success( array( 'message' => sprintf( __( 'Test message sent. The other program answered %1$d at %2$s.', 'estat-os' ), (int) $res['code'], $res['url'] ?? '' ), 'code' => $res['code'] ?? 0, 'url' => $res['url'] ?? '' ) );
		} else {
			wp_send_json_error( array( 'message' => sprintf( __( 'The test did not go through: %s', 'estat-os' ), $res['error'] ?? __( 'no reply', 'estat-os' ) ), 'code' => $res['code'] ?? 0 ), 500 );
		}
	}

	public static function ajax_lead_timeline(): void {
		check_ajax_referer( 'wp_rest', '_ajax_nonce' );
		if ( ! current_user_can( 'estat_manage_leads' ) && ! current_user_can( 'estat_agent' ) ) {
			wp_send_json_error( array( 'message' => __( 'No permission', 'estat-os' ) ), 403 );
		}
		$lead_id = isset( $_POST['lead_id'] ) ? absint( wp_unslash( is_array($_POST['lead_id']) ? '' : $_POST['lead_id'] ) ) : 0;
		$events = \EstatOS\Leads\LeadEvents::for_lead( $lead_id );
		wp_send_json_success( array( 'events' => $events, 'count' => count( $events ) ) );
	}

	public function body_class( string $classes ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( is_array($_GET['page']) ? '' : $_GET['page'] ) ) : '';
		if ( 0 === strpos( $page, 'estat-' ) ) {
			$classes .= ' estat-screen';
			$theme = (string) Settings::get( 'admin_theme' );
			if ( ! in_array( $theme, array( 'light', 'dark', 'auto' ), true ) ) { $theme = 'light'; }
			$classes .= ' estat-theme-' . $theme . ' estat-new-ui';
			if ( Settings::get( 'practice_mode' ) ) { $classes .= ' estat-practice'; }
		}
		return $classes;
	}

	public function hide_clutter(): void {
		if ( current_user_can( 'manage_options' ) ) { return; }
		remove_submenu_page( 'edit.php?post_type=' . PostTypes::LISTING, 'edit-tags.php?taxonomy=' . Taxonomies::FEATURE . '&post_type=' . PostTypes::LISTING );
	}
}
