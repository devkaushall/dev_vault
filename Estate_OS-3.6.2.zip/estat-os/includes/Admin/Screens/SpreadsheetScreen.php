<?php
/**
 * Import and export — F6: preview+undo + bridge.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Csv\Spreadsheet;

defined( 'ABSPATH' ) || exit;

/**
 * Bring inventory in from a spreadsheet and take it back out again.
 * F6: preview before import, undo after import, bridge from old portals, export preview.
 */
final class SpreadsheetScreen {

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_import_inventory' ) ) {
			wp_die( esc_html__( 'You do not have permission to import or export.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preview_key = isset( $_GET['estat_preview'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_preview']) ? '' : $_GET['estat_preview'] ) ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$export_preview_what = isset( $_GET['estat_export_preview'] ) ? sanitize_key( wp_unslash( (string) ( is_array($_GET['estat_export_preview']) ? '' : $_GET['estat_export_preview'] ) ) ) : '';

		if ( $preview_key ) {
			$data = get_transient( $preview_key );
			if ( $data ) {
				self::render_preview( $preview_key, $data );
				return;
			}
		}

		if ( $export_preview_what ) {
			$transient = 'estat_export_preview_' . $export_preview_what . '_' . get_current_user_id();
			$preview = get_transient( $transient );
			if ( $preview ) {
				self::render_export_preview( $export_preview_what, $preview );
				// Continue to show main screen below as well.
			}
		}

		Partials::card_open( __( 'Bring properties in from a spreadsheet', 'estat-os' ), __( 'Save your sheet as CSV first — Excel and Google Sheets both do this from the File menu. We show you what will happen before anything is saved, and you can undo an import afterwards.', 'estat-os' ) );
		?>
		<form method="post" enctype="multipart/form-data" class="estat-form-admin" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ); ?>">
			<?php wp_nonce_field( 'estat_import_csv', 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="preview_csv" />
			<div class="estat-field-row">
				<label class="estat-field-label" for="estat-csv"><?php esc_html_e( 'Choose your CSV file', 'estat-os' ); ?></label>
				<input type="file" id="estat-csv" name="estat_csv" accept=".csv,text/csv" required />
				<p class="description"><?php esc_html_e( 'Up to 20 MB. Large files are handled a few rows at a time so your website stays fast.', 'estat-os' ); ?></p>
			</div>
			<div class="estat-field-row">
				<label class="estat-field-label"><?php esc_html_e( 'What is in this file?', 'estat-os' ); ?></label>
				<select name="kind">
					<option value="listings"><?php esc_html_e( 'Properties (listings)', 'estat-os' ); ?></option>
					<option value="projects"><?php esc_html_e( 'Societies / Projects', 'estat-os' ); ?></option>
					<option value="agents"><?php esc_html_e( 'Team members', 'estat-os' ); ?></option>
					<option value="leads"><?php esc_html_e( 'Enquiries / Leads', 'estat-os' ); ?></option>
				</select>
				<p class="description"><?php esc_html_e( 'Not sure? Leave it as it is. We read the column names, and if they say something else we tell you on the next screen — before anything is saved.', 'estat-os' ); ?></p>
			</div>
			<div class="estat-field-row">
				<label class="estat-field-label" for="estat-bridge"><?php esc_html_e( 'Where did this file come from?', 'estat-os' ); ?></label>
				<select name="bridge_type" id="estat-bridge">
					<option value=""><?php esc_html_e( '— work it out from the column names —', 'estat-os' ); ?></option>
					<?php foreach ( Spreadsheet::bridge_systems() as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description"><?php esc_html_e( 'Leave this alone if you are not sure: we read the column names and pick the best match, and you can change every column on the next screen.', 'estat-os' ); ?></p>
			</div>
			<div class="estat-form-actions-admin">
				<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Preview & Map columns', 'estat-os' ); ?></button>
				<span class="estat-ui-quiet estat-sample-links"><?php esc_html_e( 'Sample file:', 'estat-os' ); ?>
					<?php foreach ( array(
						'listings' => __( 'properties', 'estat-os' ),
						'projects' => __( 'societies', 'estat-os' ),
						'agents'   => __( 'team', 'estat-os' ),
						'leads'    => __( 'enquiries', 'estat-os' ),
					) as $sample_kind => $sample_label ) : ?>
						<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=sample_csv&kind=' . $sample_kind ), 'estat_sample_csv', 'estat_nonce' ) ); ?>"><?php echo esc_html( (string) $sample_label ); ?></a>
					<?php endforeach; ?>
				</span>
			</div>
		</form>
		<?php
		Partials::card_close();

		Partials::card_open( __( 'What the columns mean', 'estat-os' ), __( 'Only the first column is required. Leave out any column you do not use. Bridge will auto-map common old headers.', 'estat-os' ) );
		echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Column heading', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'What to put in it', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( Spreadsheet::columns( 'listings' ) as $column => $description ) {
			echo '<tr><th scope="row" data-label="' . esc_attr__( 'Column heading', 'estat-os' ) . '"><code>' . esc_html( (string) $column ) . '</code></th>';
			echo '<td data-label="' . esc_attr__( 'What to put in it', 'estat-os' ) . '">' . esc_html( (string) $description ) . '</td></tr>';
		}
		echo '</tbody></table>';

		// A sheet of societies has its own columns, and they are asked about
		// far more often than the rest, so they sit open on the same card.
		echo '<h3 style="margin-top:20px">' . esc_html__( 'Societies and projects', 'estat-os' ) . '</h3>';
		echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Column heading', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'What to put in it', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( Spreadsheet::columns( 'projects' ) as $column => $description ) {
			echo '<tr><th scope="row" data-label="' . esc_attr__( 'Column heading', 'estat-os' ) . '"><code>' . esc_html( (string) $column ) . '</code></th>';
			echo '<td data-label="' . esc_attr__( 'What to put in it', 'estat-os' ) . '">' . esc_html( (string) $description ) . '</td></tr>';
		}
		echo '</tbody></table>';
		Partials::card_close();

		Partials::card_open( __( 'Take your information out', 'estat-os' ), __( 'Everything is exported as CSV you can open in Excel. Preview first 5 rows before download. Your data is always yours.', 'estat-os' ) );
		echo '<p class="estat-quick-actions" style="display:flex;gap:8px;flex-wrap:wrap">';
		foreach ( array(
			'listings' => __( 'Export properties', 'estat-os' ),
			'leads'    => __( 'Export enquiries', 'estat-os' ),
			'visits'   => __( 'Export site visits', 'estat-os' ),
			'projects' => __( 'Export societies', 'estat-os' ),
			'agents'   => __( 'Export the team', 'estat-os' ),
		) as $what => $label ) {
			$url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_csv&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
			$preview_url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_preview&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
			echo '<span style="display:inline-flex;gap:4px"><a class="button" href="' . esc_url( $url ) . '">' . esc_html( (string) $label ) . '</a> <a class="button button-secondary" href="' . esc_url( $preview_url ) . '">' . esc_html__( 'See it first', 'estat-os' ) . '</a></span> ';
		}
		echo '</p>';
		Partials::card_close();

		self::names_card();

		$jobs = Spreadsheet::recent_jobs( 15 );
		if ( $jobs ) {
			Partials::card_open( __( 'Recent imports', 'estat-os' ), __( 'Every import keeps a record of what it made and what it changed. You can undo a finished import — the listings it added go to the bin, and the ones it edited get their earlier words, price and photos back.', 'estat-os' ) );
			echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
			echo '<th scope="col">' . esc_html__( 'Import', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'What it was', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'File', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Progress', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Added', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Updated', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Skipped', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Result', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Actions', 'estat-os' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $jobs as $job ) {
				$total = max( 1, (int) $job['total_rows'] );
				$can_undo = ! empty( $job['created_ids'] ) && 'undone' !== $job['state'] && 'done' === $job['state'];
				$undo_url = $can_undo ? wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=undo_import&job_id=' . (int) $job['id'] ), 'estat_undo_import_' . (int) $job['id'], 'estat_nonce' ) : '';
				$what = 'import' === (string) $job['kind']
					? __( 'Import', 'estat-os' )
					: ucfirst( (string) $job['kind'] );
				if ( ! empty( $job['bridge_type'] ) ) {
					/* translators: %s: the portal the spreadsheet came from. */
					$what .= ' — ' . sprintf( __( 'from %s', 'estat-os' ), (string) $job['bridge_type'] );
				}

				echo '<tr>';
				echo '<th scope="row" data-label="' . esc_attr__( 'Import', 'estat-os' ) . '">#' . (int) $job['id'] . '</th>';
				echo '<td data-label="' . esc_attr__( 'What it was', 'estat-os' ) . '">' . esc_html( $what ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'File', 'estat-os' ) . '">' . esc_html( basename( (string) $job['file_path'] ) ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Progress', 'estat-os' ) . '">' . esc_html( sprintf( '%d%%', (int) round( ( (int) $job['processed_rows'] / $total ) * 100 ) ) ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Added', 'estat-os' ) . '">' . (int) $job['created_count'] . '</td>';
				echo '<td data-label="' . esc_attr__( 'Updated', 'estat-os' ) . '">' . (int) $job['updated_count'] . '</td>';
				echo '<td data-label="' . esc_attr__( 'Skipped', 'estat-os' ) . '">' . (int) $job['skipped_count'] . '</td>';
				$tone = ( 'done' === $job['state'] ) ? 'is-positive' : ( ( 'undone' === $job['state'] ) ? 'is-danger' : 'is-warning' );
				echo '<td data-label="' . esc_attr__( 'Result', 'estat-os' ) . '"><span class="estat-ui-chip ' . esc_attr( $tone ) . '">' . esc_html( self::job_state_label( (string) $job['state'] ) ) . '</span></td>';
				echo '<td data-label="' . esc_attr__( 'Actions', 'estat-os' ) . '">';
				if ( $can_undo ) {
					$kind_word = array(
						'listings' => __( 'Properties', 'estat-os' ),
						'projects' => __( 'Societies and projects', 'estat-os' ),
						'agents'   => __( 'Team members', 'estat-os' ),
						'leads'    => __( 'Enquiries', 'estat-os' ),
					)[ (string) $job['kind'] ] ?? __( 'Records', 'estat-os' );
					echo '<a class="button button-small" href="' . esc_url( $undo_url ) . '" onclick="return confirm(\'' . esc_js( sprintf( __( 'Undo this import? %s it added will go to the bin.', 'estat-os' ), $kind_word ) ) . '\')">' . esc_html__( 'Undo', 'estat-os' ) . '</a>';
				} else {
					echo '<span class="estat-ui-quiet">—</span>';
				}
				echo '</td>';
				echo '</tr>';
				if ( ! empty( $job['errors'] ) ) {
					$errs = json_decode( (string) $job['errors'], true );
					if ( is_array( $errs ) && $errs ) {
						echo '<tr><td colspan="9"><details><summary>' . esc_html( sprintf( _n( '%d error', '%d errors', count( $errs ), 'estat-os' ), count( $errs ) ) ) . '</summary><ul>';
						foreach ( array_slice( $errs, 0, 10 ) as $e ) {
							echo '<li>Row ' . (int) ( $e['row'] ?? 0 ) . ': ' . esc_html( (string) ( $e['message'] ?? '' ) ) . '</li>';
						}
						echo '</ul></details></td></tr>';
					}
				}
			}
			echo '</tbody></table>';
			Partials::card_close();
		}
	}

	/**
	 * Render preview screen after upload.
	 *
	 * @param string               $preview_key Transient key.
	 * @param array<string,mixed> $data Preview data.
	 * @return void
	 */
	/**
	 * Plain word for an import's state. The stored value is a machine word
	 * (done, undone, running), which is not something the office should read.
	 *
	 * @param string $state Stored state.
	 * @return string
	 */
	private static function job_state_label( string $state ): string {
		$words = array(
			'done'    => __( 'Finished', 'estat-os' ),
			'undone'  => __( 'Undone', 'estat-os' ),
			'running' => __( 'In progress', 'estat-os' ),
			'queued'  => __( 'Waiting its turn', 'estat-os' ),
			'failed'  => __( 'Failed', 'estat-os' ),
		);
		return $words[ $state ] ?? ucfirst( $state );
	}

	/**
	 * The four kinds of file, named the way the upload box names them.
	 *
	 * @return array<string,string>
	 */
	private static function kind_labels(): array {
		return array(
			'listings' => __( 'Properties (listings)', 'estat-os' ),
			'projects' => __( 'Societies / Projects', 'estat-os' ),
			'agents'   => __( 'Team members', 'estat-os' ),
			'leads'    => __( 'Enquiries / Leads', 'estat-os' ),
		);
	}

	private static function render_preview( string $preview_key, array $data ): void {
		$headers = $data['headers'] ?? array();
		$rows    = $data['rows'] ?? array();
		$total   = $data['total'] ?? 0;
		$mapping = $data['mapping'] ?? array();
		$kind    = $data['kind'] ?? 'listings';
		$bridge  = $data['bridge'] ?? '';

		$bridge_label = Spreadsheet::bridge_systems()[ $bridge ] ?? __( 'Generic CSV', 'estat-os' );
		Partials::card_open(
			/* translators: %d: how many rows are in the file */
			sprintf( __( 'Preview: %d rows — check the columns', 'estat-os' ), $total ),
			sprintf(
				/* translators: %s: the kind of file we think this is */
				__( 'We read this file as: %s. Every column is listed below before anything is written, and you can change any of them.', 'estat-os' ),
				$bridge_label
			)
		);

		echo '<p><strong>' . esc_html__( 'File headers found:', 'estat-os' ) . '</strong> ' . esc_html( implode( ', ', $headers ) ) . '</p>';
		echo '<p><strong>' . esc_html__( 'Total rows:', 'estat-os' ) . '</strong> ' . (int) $total . '</p>';

		/*
		 * What the file is going to be brought in as, in one sentence — and,
		 * when the columns would not agree with the box that was ticked, what
		 * changed and how to go back. A sheet of societies read as properties
		 * is the expensive mistake here: every row of it lands in the
		 * property list under a name that is not a property.
		 */
		$kind_labels = self::kind_labels();
		$switched_from = (string) ( $data['switched_from'] ?? '' );
		$as_kind = (string) ( $kind_labels[ $kind ] ?? $kind );
		if ( '' !== $switched_from ) {
			$was_kind = (string) ( $kind_labels[ $switched_from ] ?? $switched_from );
			echo '<div class="notice notice-warning inline" style="margin:12px 0"><p><strong>' .
				esc_html__( 'These columns are not a property sheet’s columns.', 'estat-os' ) . '</strong> ' .
				esc_html( sprintf(
					/* translators: 1: what the office picked, 2: what the columns say */
					__( 'You chose “%1$s”, but this file has the columns of a society or project list — so it is being brought in as “%2$s”. Nothing has been saved yet.', 'estat-os' ),
					$was_kind,
					$as_kind
				) ) . '</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '" style="margin:0 0 12px">';
			wp_nonce_field( 'estat_switch_kind', 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="switch_kind">';
			echo '<input type="hidden" name="preview_key" value="' . esc_attr( $preview_key ) . '">';
			echo '<input type="hidden" name="kind" value="' . esc_attr( $switched_from ) . '">';
			echo '<button type="submit" class="button">' . esc_html( sprintf(
				/* translators: %s: the kind of record the office had picked */
				__( 'No — bring it in as “%s”', 'estat-os' ),
				$was_kind
			) ) . '</button></form></div>';
		}
		echo '<p><strong>' . esc_html( sprintf(
			/* translators: %s: the kind of record this file will become */
			__( 'Being brought in as: %s', 'estat-os' ),
			$as_kind
		) ) . '</strong></p>';

		// What happens to each column, in the sheet's own order. A column we
		// leave alone is said out loud, with the reason.
		$plan    = Spreadsheet::column_plan( $headers, $mapping, $kind );
		$read    = 0;
		$left    = 0;
		echo '<h3 style="margin-top:20px">' . esc_html__( 'What we will do with each column', 'estat-os' ) . '</h3>';
		echo '<div class="estat-scroll-x"><table class="widefat estat-table estat-table-cards"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Column in your file', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Where it goes', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $plan as $line ) {
			if ( '' !== (string) $line['label'] ) {
				++$read;
				$where = '<span class="estat-ui-chip is-positive">' . esc_html__( 'Read', 'estat-os' ) . '</span> ' . esc_html( (string) $line['label'] );
			} else {
				++$left;
				$where = '<span class="estat-ui-chip is-warning">' . esc_html__( 'Not used', 'estat-os' ) . '</span> ' . esc_html( (string) $line['why'] );
			}
			echo '<tr><th scope="row" data-label="' . esc_attr__( 'Column in your file', 'estat-os' ) . '"><code>' . esc_html( (string) $line['header'] ) . '</code></th>';
			echo '<td data-label="' . esc_attr__( 'Where it goes', 'estat-os' ) . '">' . $where . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</tbody></table></div>';
		echo '<p class="description">' . esc_html( sprintf(
			/* translators: 1: columns read, 2: columns left alone */
			__( '%1$d of %2$d columns will be read. Nothing is deleted from your file, and the columns we leave alone are listed above with the reason.', 'estat-os' ),
			$read,
			$read + $left
		) ) . '</p>';

		if ( $rows ) {
			echo '<h3>' . esc_html__( 'Sample rows (first 5)', 'estat-os' ) . '</h3>';
			echo '<div class="estat-scroll-x"><table class="widefat"><thead><tr>';
			foreach ( $headers as $h ) { echo '<th>' . esc_html( $h ) . '</th>'; }
			echo '</tr></thead><tbody>';
			foreach ( $rows as $r ) {
				echo '<tr>';
				foreach ( $r as $cell ) { echo '<td>' . esc_html( mb_substr( $cell, 0, 80 ) ) . '</td>'; }
				echo '</tr>';
			}
			echo '</tbody></table></div>';
		}

		echo '<h3 style="margin-top:20px">' . esc_html__( 'Map your columns to our fields', 'estat-os' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'Choose which file header goes to which field. Leave empty to skip a field. external_id is used to avoid duplicates.', 'estat-os' ) . '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">';
		wp_nonce_field( 'estat_confirm_import', 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="confirm_import">';
		echo '<input type="hidden" name="preview_key" value="' . esc_attr( $preview_key ) . '">';

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Our field', 'estat-os' ) . '</th><th>' . esc_html__( 'File header', 'estat-os' ) . '</th><th>' . esc_html__( 'Description', 'estat-os' ) . '</th></tr></thead><tbody>';
		foreach ( Spreadsheet::columns( $kind ) as $col => $desc ) {
			$current = $mapping[ $col ] ?? '';
			echo '<tr>';
			echo '<th><code>' . esc_html( $col ) . '</code></th>';
			echo '<td><select name="mapping[' . esc_attr( $col ) . ']"><option value="">— ' . esc_html__( 'Skip', 'estat-os' ) . ' —</option>';
			foreach ( $headers as $h ) {
				echo '<option value="' . esc_attr( $h ) . '" ' . selected( $current, $h, false ) . '>' . esc_html( $h ) . '</option>';
			}
			echo '</select></td>';
			echo '<td class="estat-ui-quiet">' . esc_html( $desc ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<p style="margin-top:16px"><label><input type="checkbox" name="dry_run" value="1"> ' . esc_html__( 'Only check — read the file and count what would be created or updated, without saving anything', 'estat-os' ) . '</label></p>';

		echo '<div class="estat-form-actions-admin" style="margin-top:12px">';
		echo '<button type="submit" class="button button-primary button-hero">' . esc_html__( 'Confirm & Import', 'estat-os' ) . '</button> ';
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">' . esc_html__( 'Cancel', 'estat-os' ) . '</a>';
		echo '</div>';
		echo '</form>';

		Partials::card_close();
	}

	/**
	 * List names that an import cut in half, and a way to put them right.
	 *
	 * "Sohna Road (Sector 49" and "Uppal Southend)" are what a spreadsheet does
	 * to a name that had a bracket in it. Left alone they become their own
	 * locality pages, and the property, its area page and its internal links all
	 * quietly say something different. Merging moves every property onto the
	 * name that should stay, then removes the broken one.
	 *
	 * @return void
	 */
	private static function names_card(): void {
		$taxonomy = \EstatOS\Data\Taxonomies::LOCALITY;
		$suspects = \EstatOS\Data\Health::suspect_terms( $taxonomy );
		$all      = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
		$all      = is_wp_error( $all ) ? array() : $all;

		$thin = array();
		foreach ( $all as $term ) {
			if ( \EstatOS\Data\Health::term_listing_count( (int) $term->term_id, $taxonomy ) <= 0 ) {
				$thin[] = $term;
			}
		}

		// Nothing to say and nothing to tidy: keep the screen short.
		if ( ! $suspects && ! $thin ) {
			return;
		}

		Partials::card_open(
			__( 'Area names', 'estat-os' ),
			__( 'One area, one name. A name with a bracket cut in half makes its own area page, and the property then points somewhere else.', 'estat-os' )
		);

		if ( $suspects ) {
			echo '<h3>' . esc_html__( 'These look wrong', 'estat-os' ) . '</h3>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">';
			wp_nonce_field( 'estat_merge_terms', 'estat_nonce' );
			echo '<input type="hidden" name="estat_action" value="merge_terms">';
			echo '<input type="hidden" name="taxonomy" value="' . esc_attr( $taxonomy ) . '">';
			echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
			echo '<th scope="col">' . esc_html__( 'Name', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'What is wrong', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Properties', 'estat-os' ) . '</th>';
			echo '<th scope="col">' . esc_html__( 'Should be', 'estat-os' ) . '</th>';
			echo '<th scope="col"></th>';
			echo '</tr></thead><tbody>';
			foreach ( $suspects as $row ) {
				$term = $row['term'];
				echo '<tr>';
				echo '<th scope="row" data-label="' . esc_attr__( 'Name', 'estat-os' ) . '"><code>' . esc_html( (string) $term->name ) . '</code></th>';
				echo '<td data-label="' . esc_attr__( 'What is wrong', 'estat-os' ) . '">' . esc_html( (string) $row['why'] ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Properties', 'estat-os' ) . '">' . (int) $row['listing'] . '</td>';
				echo '<td data-label="' . esc_attr__( 'Should be', 'estat-os' ) . '"><select name="into[' . (int) $term->term_id . ']"><option value="">' . esc_html__( '— choose —', 'estat-os' ) . '</option>';
				foreach ( $all as $other ) {
					if ( (int) $other->term_id === (int) $term->term_id ) {
						continue;
					}
					echo '<option value="' . (int) $other->term_id . '">' . esc_html( (string) $other->name ) . '</option>';
				}
				echo '</select></td>';
				echo '<td><button class="button button-small" type="submit" name="merge_from" value="' . (int) $term->term_id . '">' . esc_html__( 'Merge', 'estat-os' ) . '</button></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
			echo '<p class="description">' . esc_html__( 'Merging moves every property onto the name that stays and removes the broken name. Nothing else is deleted.', 'estat-os' ) . '</p>';
			echo '</form>';
		}

		if ( $thin ) {
			$names = array();
			foreach ( array_slice( $thin, 0, 30 ) as $term ) {
				$names[] = '<code>' . esc_html( (string) $term->name ) . '</code>';
			}
			echo '<h3>' . esc_html__( 'Areas with no properties yet', 'estat-os' ) . '</h3>';
			echo '<p class="estat-ui-quiet">' . esc_html__( 'Their pages stay out of the search engines until something is listed there — nobody wants to land on an empty area page.', 'estat-os' ) . '</p>';
			echo '<p>' . implode( ' ', $names ) . '</p>';
		}

		Partials::card_close();
	}

	/**
	 * Render export preview.
	 *
	 * @param string               $what Kind.
	 * @param array<string,mixed> $preview Preview data.
	 * @return void
	 */
	private static function render_export_preview( string $what, array $preview ): void {
		Partials::card_open( sprintf( __( 'Export preview: %s (first %d rows)', 'estat-os' ), $what, count( $preview['rows'] ?? array() ) ), __( 'This is what your CSV will contain. Click Export to download full file.', 'estat-os' ) );
		$columns = $preview['columns'] ?? array();
		$rows = $preview['rows'] ?? array();
		if ( ! $columns ) {
			echo '<p>' . esc_html__( 'No data to export.', 'estat-os' ) . '</p>';
			Partials::card_close();
			return;
		}
		echo '<div class="estat-scroll-x"><table class="widefat"><thead><tr>';
		foreach ( $columns as $c ) { echo '<th><code>' . esc_html( $c ) . '</code></th>'; }
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr>';
			foreach ( $columns as $c ) {
				echo '<td>' . esc_html( mb_substr( (string) ( $r[ $c ] ?? '' ), 0, 100 ) ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table></div>';
		$download_url = wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_csv&what=' . $what ), 'estat_export_csv', 'estat_nonce' );
		echo '<p style="margin-top:12px"><a class="button button-primary" href="' . esc_url( $download_url ) . '">' . esc_html__( 'Download full CSV', 'estat-os' ) . '</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">' . esc_html__( 'Close preview', 'estat-os' ) . '</a></p>';
		Partials::card_close();
	}
}
