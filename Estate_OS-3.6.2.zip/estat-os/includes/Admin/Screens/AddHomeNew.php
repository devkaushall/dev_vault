<?php
/**
 * Add a Home — the office guided flow, 4 groups preserved (basics, price, photo, highlights).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class AddHomeNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to add listings.', 'estat-os' ) );
		}

		wp_enqueue_media();

		$localities = get_terms( array( 'taxonomy'=>Taxonomies::LOCALITY, 'hide_empty'=>false, 'number'=>300 ) );
		$localities = is_wp_error( $localities ) ? array() : $localities;
		$symbol = (string) Settings::get( 'currency_symbol', '₹' );
		$s = Settings::all();
		$unit_labels = array(
			'sqft' => __( 'sq ft', 'estat-os' ),
			'sqyd' => __( 'sq yd', 'estat-os' ),
			'sqm'  => __( 'sq m', 'estat-os' ),
		);
		$unit_label = $unit_labels[ (string) ( $s['default_area_unit'] ?? 'sqft' ) ] ?? $unit_labels['sqft'];
		$city = (string) ( $s['city'] ?? '' );

		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<span class="is-accent"><?php esc_html_e( 'Properties', 'estat-os' ); ?></span>
					<?php echo \EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ); ?>
					<span><?php esc_html_e( 'New listing creation', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php esc_html_e( 'Add a home', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php esc_html_e( 'Only a few details are needed. Save a draft now and finish the rest later.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<span class="estat-ui-ledger-id"><span class="estat-ui-dot-accent"></span> <?php esc_html_e( 'New property', 'estat-os' ); ?></span>
					</div>
				</div>
			</div>

			<div class="estat-ui-card-panel is-progress">
				<div class="estat-ui-progress-head">
					<span class="estat-ui-label-accent"><?php esc_html_e( 'Progress', 'estat-os' ); ?></span>
					<span class="estat-ui-muted">•</span>
					<span class="estat-ui-progress-title"><?php esc_html_e( '4 steps: basics, price, photo, highlights', 'estat-os' ); ?></span>
				</div>
			</div>

			<form method="post" class="estat-ui-form-grid" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>" id="estat-add-home-form">
				<?php wp_nonce_field( 'estat_add_home', 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="add_home" />

				<div class="estat-ui-form-main">
					<div class="estat-ui-card-panel" id="basics">
						<div class="estat-ui-panel-header"><span class="estat-ui-step-num is-active">1</span><div><h2><?php esc_html_e( 'The basics', 'estat-os' ); ?></h2><p class="estat-ui-panel-desc"><?php esc_html_e( 'What it is and where.', 'estat-os' ); ?></p></div><span class="estat-ui-badge"><?php esc_html_e( 'Start here', 'estat-os' ); ?></span></div>
						<div class="estat-ui-field-grid">
							<?php
							/*
							 * Sale or rent first — it is the one answer that
							 * changes the rest of the form, and the money box
							 * below is named after it.
							 */
							?>
							<div class="estat-ui-field"><label for="estat-offer"><?php esc_html_e( 'Is it for sale, rent or lease?', 'estat-os' ); ?></label><select id="estat-offer" name="offer"><?php foreach ( Vocabulary::offers() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select></div>
							<div class="estat-ui-field"><label for="estat-property_type"><?php esc_html_e( 'What kind of property is it?', 'estat-os' ); ?></label><select id="estat-property_type" name="property_type"><?php foreach ( Vocabulary::property_types() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select></div>
							<div class="estat-ui-field full"><label for="estat-title"><?php esc_html_e( 'Give it a short headline', 'estat-os' ); ?> <span class="required">*</span></label><input type="text" id="estat-title" name="title" required placeholder="<?php esc_attr_e( '3 BHK apartment with a park view', 'estat-os' ); ?>" /></div>
							<div class="estat-ui-field full"><label for="estat-locality"><?php esc_html_e( 'Which locality is it in?', 'estat-os' ); ?> <span class="required">*</span></label><input list="estat-locality-list" id="estat-locality" name="locality" required placeholder="<?php esc_attr_e( 'Start typing, or add a new one', 'estat-os' ); ?>" /><datalist id="estat-locality-list"><?php foreach ( $localities as $term ) : ?><option value="<?php echo esc_attr( $term->name ); ?>"></option><?php endforeach; ?></datalist><span class="estat-ui-help"><?php esc_html_e( 'If the locality is not in the list, just type it and we will add it.', 'estat-os' ); ?></span></div>
						</div>
					</div>

					<div class="estat-ui-card-panel" id="price">
						<div class="estat-ui-panel-header"><span class="estat-ui-step-num">2</span><div><h2><?php esc_html_e( 'Price and size', 'estat-os' ); ?></h2><p class="estat-ui-panel-desc"><?php esc_html_e( 'What it costs and how big it is.', 'estat-os' ); ?></p></div></div>
						<div class="estat-ui-field-grid">
							<div class="estat-ui-field full"><label for="estat-price"><span class="estat-money-label" data-sale="<?php echo esc_attr( sprintf( __( 'Price (%s)', 'estat-os' ), $symbol ) ); ?>" data-rent="<?php echo esc_attr( sprintf( __( 'Monthly rent (%s)', 'estat-os' ), $symbol ) ); ?>"><?php printf( esc_html__( 'Price (%s)', 'estat-os' ), esc_html( $symbol ) ); ?></span></label><div class="estat-ui-input-with-prefix"><span class="is-prefix"><?php echo esc_html( $symbol ); ?></span><input type="number" id="estat-price" name="price" min="0" step="1000" placeholder="8500000" data-sale="<?php echo esc_attr__( 'Price', 'estat-os' ); ?>" data-rent="<?php echo esc_attr__( 'Monthly rent', 'estat-os' ); ?>" data-sale-example="8500000" data-rent-example="32000" /></div><span class="estat-ui-help"><?php esc_html_e( 'Type only numbers, no commas or symbols. We will show it neatly on the website.', 'estat-os' ); ?></span></div>
							<div class="estat-ui-field"><label class="is-checkbox"><input type="checkbox" name="price_on_request" value="1" /> <?php esc_html_e( 'Show “Price on request” instead of the number', 'estat-os' ); ?></label></div>
							<div class="estat-ui-field"><label for="estat-area"><?php esc_html_e( 'How big is it?', 'estat-os' ); ?></label><input type="number" id="estat-area" name="area" min="0" step="1" placeholder="1250" /></div>
							<div class="estat-ui-field"><label for="estat-area_unit"><?php esc_html_e( 'Measured in', 'estat-os' ); ?></label><select id="estat-area_unit" name="area_unit"><?php foreach ( Vocabulary::area_units() as $k=>$v ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( Settings::get( 'default_area_unit', 'sqft' ), $k ); ?>><?php echo esc_html( $v ); ?></option><?php endforeach; ?></select></div>
							<div class="estat-ui-field estat-only-home"><label for="estat-bedrooms"><?php esc_html_e( 'How many bedrooms?', 'estat-os' ); ?></label><input type="number" id="estat-bedrooms" name="bedrooms" min="0" max="20" placeholder="3" /></div>
						</div>
					</div>

					<div class="estat-ui-card-panel" id="photo">
						<div class="estat-ui-panel-header"><span class="estat-ui-step-num">3</span><div><h2><?php esc_html_e( 'Photo', 'estat-os' ); ?></h2><p class="estat-ui-panel-desc"><?php esc_html_e( 'One good picture is enough to start.', 'estat-os' ); ?></p></div></div>
						<div class="estat-ui-photo-field">
							<div class="estat-ui-photo-preview" id="estat-cover-preview"><?php echo \EstatOS\Support\Icon::render( 'camera', 18, 'estat-ms' ); ?></div>
							<input type="hidden" name="cover_id" id="estat-cover-id" value="" />
							<div class="estat-ui-photo-actions"><button type="button" class="estat-ui-btn" id="estat-cover-select"><?php esc_html_e( 'Select photo', 'estat-os' ); ?></button><button type="button" class="estat-ui-btn is-ghost" id="estat-cover-remove"><?php esc_html_e( 'Remove', 'estat-os' ); ?></button></div>
							<span class="estat-ui-help"><?php esc_html_e( 'One good photo makes a big difference. You can add more later.', 'estat-os' ); ?></span>
						</div>
					</div>

					<div class="estat-ui-card-panel" id="highlights">
						<div class="estat-ui-panel-header"><span class="estat-ui-step-num">4</span><div><h2><?php esc_html_e( 'Highlights', 'estat-os' ); ?></h2><p class="estat-ui-panel-desc"><?php esc_html_e( 'What makes it worth buying.', 'estat-os' ); ?></p></div></div>
						<div class="estat-ui-field-grid">
							<div class="estat-ui-field full"><label for="estat-highlights"><?php esc_html_e( 'What makes it worth buying?', 'estat-os' ); ?></label><textarea id="estat-highlights" name="highlights" rows="3" placeholder="<?php esc_attr_e( 'Two or three short lines...', 'estat-os' ); ?>"></textarea></div>
						</div>
					</div>
				</div>

				<div class="estat-ui-form-side">
					<div class="estat-ui-card-panel is-preview">
						<div class="estat-ui-preview-media" id="estat-live-preview-media"><span class="estat-ui-preview-badge"><?php esc_html_e( 'How it will look', 'estat-os' ); ?></span><div class="estat-ui-preview-placeholder"><?php echo \EstatOS\Support\Icon::render( 'buildings', 18, 'estat-ms' ); ?></div><span class="estat-ui-card-price" id="estat-live-price">—</span></div>
						<div class="estat-ui-preview-body">
							<div class="estat-ui-preview-loc" id="estat-live-locality"><?php echo esc_html( '' !== $city ? $city : __( 'Your city', 'estat-os' ) ); ?></div>
							<h3 class="estat-ui-preview-title" id="estat-live-title"><?php esc_html_e( 'Your headline will appear here', 'estat-os' ); ?></h3>
							<div class="estat-ui-preview-specs"><span id="estat-live-beds">—</span> <span id="estat-live-area">—</span></div>
						</div>
					</div>

					<div class="estat-ui-card-panel">
						<div class="estat-ui-panel-header"><?php echo \EstatOS\Support\Icon::render( 'document', 18, 'estat-ms' ); ?><h2><?php esc_html_e( 'Office notes', 'estat-os' ); ?></h2></div>
												<div class="estat-ui-progress-mini"><div class="estat-ui-progress-mini-head"><span><?php esc_html_e( 'Ready to publish', 'estat-os' ); ?></span><span id="estat-readiness">0 / 4</span></div><div class="estat-ui-progress-bar"><div class="estat-ui-progress-fill" id="estat-progress-fill" style="width:0%"></div></div></div>
					</div>
				</div>
			</form>

			<div class="estat-ui-form-actions is-sticky">
				<span class="estat-ui-save-hint"><span class="estat-ui-dot-accent"></span> <?php esc_html_e( 'Saved as a draft — not on the website yet', 'estat-os' ); ?></span>
				<div class="estat-ui-actions">
					<button type="submit" form="estat-add-home-form" name="save" value="draft" class="estat-ui-btn"><?php esc_html_e( 'Save as draft', 'estat-os' ); ?></button>
					<button type="submit" form="estat-add-home-form" name="save" value="publish" class="estat-ui-btn-primary"><span><?php esc_html_e( 'Save and continue', 'estat-os' ); ?></span> <?php echo \EstatOS\Support\Icon::render( 'arrow-right', 18, 'estat-ms' ); ?></button>
				</div>
			</div>
		</div>

		<script>
		(function(){
			var title=document.getElementById('estat-title');
			var price=document.getElementById('estat-price');
			var area=document.getElementById('estat-area');
			var beds=document.getElementById('estat-bedrooms');
			var loc=document.getElementById('estat-locality');
			var liveTitle=document.getElementById('estat-live-title');
			var livePrice=document.getElementById('estat-live-price');
			var liveArea=document.getElementById('estat-live-area');
			var liveBeds=document.getElementById('estat-live-beds');
			var liveLoc=document.getElementById('estat-live-locality');
			var readiness=document.getElementById('estat-readiness');
			var fill=document.getElementById('estat-progress-fill');
			function upd(){
				if(title&&liveTitle){liveTitle.textContent=title.value||'<?php echo esc_js( __( 'Your headline will appear here', 'estat-os' ) ); ?>';}
				if(price&&livePrice){livePrice.textContent=price.value?('<?php echo esc_js( $symbol ); ?>'+price.value):'—';}
				if(area&&liveArea){liveArea.textContent=area.value?area.value+' '+'<?php echo esc_js( $unit_label ); ?>':'';}
				if(beds&&liveBeds){liveBeds.textContent=beds.value?beds.value+' '+'<?php echo esc_js( __( 'Beds', 'estat-os' ) ); ?>':'';}
				if(loc&&liveLoc){liveLoc.textContent=loc.value||'<?php echo esc_js( '' !== $city ? $city : '' ); ?>';}
				var c=0; if(title&&title.value) c++; if(price&&price.value) c++; if(area&&area.value) c++; if(beds&&beds.value) c++;
				if(readiness) readiness.textContent=c+' / 4';
				if(fill) fill.style.width=(c/4*100)+'%';
			}
			['input','change'].forEach(function(ev){ if(title) title.addEventListener(ev,upd); if(price) price.addEventListener(ev,upd); if(area) area.addEventListener(ev,upd); if(beds) beds.addEventListener(ev,upd); if(loc) loc.addEventListener(ev,upd); });
			// media
			var frame; var sel=document.getElementById('estat-cover-select'); var rem=document.getElementById('estat-cover-remove'); var input=document.getElementById('estat-cover-id'); var prev=document.getElementById('estat-cover-preview'); var liveMedia=document.getElementById('estat-live-preview-media');
			if(sel){ sel.addEventListener('click',function(e){ e.preventDefault(); if(frame){frame.open();return;} frame=wp.media({title:'<?php echo esc_js( __( 'Select photo', 'estat-os' ) ); ?>',button:{text:'<?php echo esc_js( __( 'Use this photo', 'estat-os' ) ); ?>'},multiple:false}); frame.on('select',function(){ var att=frame.state().get('selection').first().toJSON(); input.value=att.id; if(prev) prev.innerHTML='<img src="'+att.url+'" alt="" />'; if(liveMedia){ var img=liveMedia.querySelector('.estat-ui-preview-placeholder'); if(img) img.innerHTML='<img src="'+att.url+'" alt="" style="width:100%;height:100%;object-fit:cover" />'; } }); frame.open(); }); }
			if(rem){ rem.addEventListener('click',function(e){ e.preventDefault(); input.value=''; if(prev) prev.innerHTML='<?php echo \EstatOS\Support\Icon::render( 'camera', 18, 'estat-ms' ); ?>'; }); }
		})();
		</script>
		<?php
	}
}
