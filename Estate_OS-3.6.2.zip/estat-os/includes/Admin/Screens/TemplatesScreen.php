<?php
/**
 * Templates — drag-drop order of listing page blocks — F7 polished.
 *
 * the office #7: Templates (listing page ke blocks ka order drag se).
 * F7: supports listing + project, add custom HTML block, reset, live preview, grouped.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Templates;

defined( 'ABSPATH' ) || exit;

final class TemplatesScreen {

	/**
	 * Render.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$type = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( is_array($_GET['type']) ? '' : $_GET['type'] ) ) : 'listing';
		$type = in_array( $type, array( 'listing', 'project' ), true ) ? $type : 'listing';

		// Handle save.
		if ( isset( $_POST['estat_save_templates'] ) && check_admin_referer( 'estat_templates', 'estat_nonce' ) ) {
			$raw = isset( $_POST['blocks'] ) && is_array( $_POST['blocks'] ) ? $_POST['blocks'] : array();
			$blocks = array();
			foreach ( $raw as $b ) {
				if ( ! is_array( $b ) ) { continue; }
				$blocks[] = array(
					'id'      => sanitize_key( $b['id'] ?? '' ),
					'label'   => sanitize_text_field( $b['label'] ?? '' ),
					'enabled' => ! empty( $b['enabled'] ),
				);
			}
			Templates::save_blocks( $blocks, $type );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Saved. Your pages now show this order.', 'estat-os' ) . '</p></div>';
		}

		if ( isset( $_POST['estat_reset_templates'] ) && check_admin_referer( 'estat_templates', 'estat_nonce' ) ) {
			Templates::save_blocks( Templates::default_blocks( $type ), $type );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Template reset to defaults.', 'estat-os' ) . '</p></div>';
		}

		$blocks = Templates::get_blocks( $type );
		$default_blocks = Templates::default_blocks( $type );

		echo '<p class="estat-muted">' . esc_html__( 'Drag to reorder the blocks on a public page. Untick one to hide it.', 'estat-os' ) . '</p>';

		// Tabs.
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( array( 'listing' => __( 'Listing page', 'estat-os' ), 'project' => __( 'Project page', 'estat-os' ) ) as $k => $label ) {
			$active = $k === $type ? ' nav-tab-active' : '';
			echo '<a class="nav-tab' . $active . '" href="' . esc_url( add_query_arg( array( 'page' => 'estat-templates', 'type' => $k ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</h2>';

		echo '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:16px">';

		// Left: editor.
		echo '<div style="flex:1;min-width:320px;max-width:640px">';

		echo '<form method="post">';
		wp_nonce_field( 'estat_templates', 'estat_nonce' );
		echo '<div id="estat-templates-list" style="max-width:600px">';

		foreach ( $blocks as $i => $b ) {
			$id = esc_attr( $b['id'] );
			$label = esc_html( $b['label'] );
			$enabled = ! empty( $b['enabled'] ) ? 'checked' : '';
			$is_custom = ! in_array( $b['id'], array_column( $default_blocks, 'id' ), true );
			$custom_badge = $is_custom ? ' <span class="estat-ui-chip is-warning">custom</span>' : '';
			echo '<div class="estat-template-row" draggable="true" style="display:flex;align-items:center;gap:12px;padding:12px;border:1px solid var(--estat-line);border-radius:8px;margin-bottom:8px;background:var(--estat-card);cursor:grab">';
			echo '<span class="estat-drag-handle" style="cursor:grab">☰</span>';
			echo '<input type="hidden" name="blocks[' . $i . '][id]" value="' . $id . '">';
			echo '<input type="hidden" name="blocks[' . $i . '][label]" value="' . esc_attr( $b['label'] ) . '">';
			echo '<label style="flex:1"><input type="checkbox" name="blocks[' . $i . '][enabled]" value="1" ' . $enabled . '> ' . $label . $custom_badge . '</label>';
			echo '</div>';
		}
		echo '</div>';


		echo '<p style="display:flex;gap:8px;margin-top:16px"><button type="submit" name="estat_save_templates" value="1" class="button button-primary">' . esc_html__( 'Save template order', 'estat-os' ) . '</button> <button type="submit" name="estat_reset_templates" value="1" class="button" onclick="return confirm(\'Reset to defaults?\')">' . esc_html__( 'Reset to defaults', 'estat-os' ) . '</button></p>';
		echo '</form>';
		echo '</div>';

		echo '</div>'; // flex

		?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const list = document.getElementById('estat-templates-list');
			const preview = document.getElementById('estat-templates-preview');
			if(!list) return;
			let dragged=null;
			function reindex(){
				list.querySelectorAll('.estat-template-row').forEach((row, idx)=>{
					row.querySelectorAll('input').forEach(inp=>{
						inp.name = inp.name.replace(/blocks\[\d+\]/, 'blocks['+idx+']');
					});
				});
				// Update preview.
				if(preview){
					preview.innerHTML='';
					list.querySelectorAll('.estat-template-row').forEach(row=>{
						const cb = row.querySelector('input[type=checkbox]');
						const label = row.querySelector('label')?.textContent || '';
						if(cb && cb.checked){
							const li = document.createElement('li');
							li.style.margin='4px 0'; li.style.padding='4px 8px'; li.style.background='var(--estat-bg)'; li.style.borderRadius='6px'; li.style.fontSize='13px';
							li.textContent = label.trim();
							preview.appendChild(li);
						}
					});
				}
			}
			list.querySelectorAll('.estat-template-row').forEach(row=>{
				row.addEventListener('dragstart', e=>{ dragged=row; e.dataTransfer.effectAllowed='move'; setTimeout(()=>row.style.opacity='0.5',0); });
				row.addEventListener('dragend', ()=>{ row.style.opacity=''; dragged=null; reindex(); });
				const cb = row.querySelector('input[type=checkbox]');
				if(cb){ cb.addEventListener('change', reindex); }
			});
			list.addEventListener('dragover', e=>{ e.preventDefault(); const after = getDragAfterElement(list, e.clientY); if(!dragged) return; if(after==null){ list.appendChild(dragged);} else { list.insertBefore(dragged, after);} });
			function getDragAfterElement(container, y){
				const els = [...container.querySelectorAll('.estat-template-row:not([style*="opacity: 0.5"])')];
				return els.reduce((closest, child)=>{
					const box = child.getBoundingClientRect();
					const offset = y - box.top - box.height/2;
					if(offset<0 && offset>closest.offset){ return {offset:offset, element:child}; } else { return closest; }
				}, {offset:Number.NEGATIVE_INFINITY}).element;
			}
			list.addEventListener('drop', ()=>{ setTimeout(reindex,50); });
		});
		</script>
		<?php
	}
}
