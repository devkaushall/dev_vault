<?php
/**
 * Search Alerts admin screen — F4 upgraded.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Search\Alerts;

defined( 'ABSPATH' ) || exit;

final class SearchAlertsScreen {

	/**
	 * Render.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'estat-os' ) );
		}

		// Handle delete.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['estat_delete_alert'] ) ) {
			$id = absint( wp_unslash( is_array($_GET['estat_delete_alert']) ? '' : $_GET['estat_delete_alert'] ) );
			$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( is_array($_GET['source']) ? '' : $_GET['source'] ) ) : 'new';
			if ( $id ) {
				check_admin_referer( 'estat_delete_alert_' . $id );
				Alerts::delete( $id, 'legacy' === $source ? 'legacy' : 'new' );
				echo '<div class="notice notice-success"><p>' . esc_html__( 'Alert deleted.', 'estat-os' ) . '</p></div>';
			}
		}

		$data = Alerts::query();

		echo '<div class="wrap estat-admin">';
		echo '<div class="estat-ui-page-header">';
		echo '<div class="estat-ui-breadcrumb"><span>' . esc_html__( 'Office', 'estat-os' ) . '</span><span>/</span><span class="is-muted">' . esc_html__( 'Search alerts', 'estat-os' ) . '</span></div>';
		echo '<div class="estat-ui-header-row"><div>';
		echo '<h1 class="estat-ui-h1">' . esc_html__( 'Search alerts', 'estat-os' ) . '</h1>';
		echo '<p class="estat-ui-desc">' . esc_html__( 'A visitor saves a search, for example “3BHK under 2Cr”. When a matching property goes live we email them — straight away or as a daily summary. They confirm by email first, and can unsubscribe at any time.', 'estat-os' ) . '</p>';
		echo '</div></div>';
		echo '<div class="estat-ui-metrics">';
		echo '<div class="estat-ui-metric"><span class="estat-ui-metric-label">' . esc_html__( 'Watching a search', 'estat-os' ) . '</span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num">' . (int) $data['new_total'] . '</span></div></div>';
		echo '<div class="estat-ui-metric"><span class="estat-ui-metric-label">' . esc_html__( 'Still waiting to confirm', 'estat-os' ) . '</span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num">' . (int) $data['old_total'] . '</span></div></div>';
		echo '<div class="estat-ui-metric"><span class="estat-ui-metric-label">' . esc_html__( 'All alerts', 'estat-os' ) . '</span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num">' . (int) $data['total'] . '</span></div></div>';
		echo '</div>';
		echo '</div>';

		if ( ! $data['items'] ) {
			Partials::empty_state(
				array(
					'title'   => __( 'No alerts yet', 'estat-os' ),
					'message' => __( 'When visitors save a search, their alert appears here. You can see who is watching what.', 'estat-os' ),
					'icon'    => 'bell',
				)
			);
			echo '</div>';
			return;
		}

		echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
		echo '<th>' . esc_html__( 'Person', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'What they are watching', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'How often', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Last email', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Actions', 'estat-os' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $data['items'] as $row ) {
			$filters = json_decode( (string) $row['filters'], true );
			$summary = '';
			if ( is_array( $filters ) ) {
				$bits = array();
				foreach ( array( 'property_type', 'offer', 'bedrooms_min', 'bedrooms_max', 'price_min', 'price_max', 'locality', 'furnishing', 'verified', 'frequency' ) as $k ) {
					if ( isset( $filters[ $k ] ) && '' !== (string) $filters[ $k ] && array() !== $filters[ $k ] && 0 !== $filters[ $k ] && false !== $filters[ $k ] ) {
						$v = $filters[ $k ];
						if ( is_array( $v ) ) { $v = implode( '/', array_slice( $v, 0, 3 ) ); }
						if ( '' === (string) $v || '0' === (string) $v ) { continue; }
						$bits[] = self::filter_label( (string) $k ) . ': ' . mb_substr( (string) $v, 0, 30 );
					}
				}
				$summary = implode( ', ', $bits );
			}
			if ( ! empty( $row['unsubscribed'] ) ) {
				$confirm = '<span class="estat-ui-chip is-danger">' . esc_html__( 'Unsubscribed', 'estat-os' ) . '</span>';
			} elseif ( $row['confirmed'] ) {
				$confirm = '<span class="estat-ui-chip is-positive">' . esc_html__( 'Active', 'estat-os' ) . '</span>';
			} else {
				$confirm = '<span class="estat-ui-chip is-warning">' . esc_html__( 'Waiting to confirm', 'estat-os' ) . '</span>';
			}
			$del_url = wp_nonce_url( add_query_arg( array( 'page' => 'estat-search-alerts', 'estat_delete_alert' => $row['id'], 'source' => 'legacy' === $row['source'] ? 'legacy' : 'new' ), admin_url( 'admin.php' ) ), 'estat_delete_alert_' . $row['id'] );

			$how_often = 'daily' === ( $row['frequency'] ?? 'instant' )
				? __( 'One email a day', 'estat-os' )
				: __( 'As soon as one matches', 'estat-os' );

			$person = esc_html( (string) $row['email'] );
			if ( '' !== (string) $row['name'] || '' !== trim( (string) ( $row['phone'] ?? '' ) ) ) {
				$person .= '<br><span class="estat-ui-quiet">' . esc_html( trim( (string) $row['name'] . ( '' !== (string) ( $row['phone'] ?? '' ) ? ' · ' . (string) $row['phone'] : '' ) ) ) . '</span>';
			}

			echo '<tr>';
			echo '<td data-label="' . esc_attr__( 'Person', 'estat-os' ) . '">' . $person . '</td>';
			echo '<td data-label="' . esc_attr__( 'What they are watching', 'estat-os' ) . '">' . ( '' !== $summary ? esc_html( $summary ) : '<span class="estat-ui-quiet">' . esc_html__( 'Any property', 'estat-os' ) . '</span>' ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'How often', 'estat-os' ) . '">' . esc_html( $how_often ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Status', 'estat-os' ) . '">' . $confirm . '</td>';
			echo '<td data-label="' . esc_attr__( 'Last email', 'estat-os' ) . '">' . ( '' !== (string) ( $row['last_sent_at'] ?? '' ) ? esc_html( (string) $row['last_sent_at'] ) : '<span class="estat-ui-quiet">—</span>' ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Actions', 'estat-os' ) . '"><a href="' . esc_url( $del_url ) . '" onclick="return confirm(\'' . esc_js( __( 'Remove this alert?', 'estat-os' ) ) . '\')" class="button button-small">' . esc_html__( 'Remove', 'estat-os' ) . '</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<h2 style="margin-top:24px">' . esc_html__( 'How it works', 'estat-os' ) . '</h2>';
		echo '<ol>';
		echo '<li>' . esc_html__( 'A visitor browses your website and presses “Watch this search” on the results they like.', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'We save that search and email them a link to confirm it was really them.', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'Once they confirm, the search is active. Any email has a one-click unsubscribe link.', 'estat-os' ) . '</li>';
		echo '<li>' . esc_html__( 'When you publish a property that matches, they get an email straight away or in the next daily summary.', 'estat-os' ) . '</li>';
		echo '</ol>';

		echo '</div>';
	}

	/**
	 * The stored filter key (bedrooms_min, price_max …) put into words.
	 *
	 * @param string $key Stored key.
	 * @return string
	 */
	private static function filter_label( string $key ): string {
		$map = array(
			'bedrooms_min' => __( 'Bedrooms from', 'estat-os' ),
			'bedrooms_max' => __( 'Bedrooms up to', 'estat-os' ),
			'price_min'    => __( 'Budget from', 'estat-os' ),
			'price_max'    => __( 'Budget up to', 'estat-os' ),
		);
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		$all = \EstatOS\Support\Vocabulary::all_filters();
		if ( isset( $all[ $key ]['label'] ) ) {
			return (string) $all[ $key ]['label'];
		}
		return ucwords( str_replace( '_', ' ', $key ) );
	}
}
