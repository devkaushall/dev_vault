<?php
/**
 * Office Settings — the office the office grouped cards behind per-user switch.
 * 6 groups: Office overview, General, Listings & workflow, Leads & enquiries, Integrations, Advanced
 * All existing functionality accessible: Pages, Search filters, Emails, logo, tagline, cities.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Admin\Actions;
use EstatOS\Data\PostTypes;
use EstatOS\Office\Dashboard;
use EstatOS\Pocket\Pocket;
use EstatOS\Settings\Settings;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class SettingsNew {

	/**
	 * Every settings group, in the order they appear.
	 *
	 * The sidebar line uses 'menu_label' (short, so it fits), the page
	 * heading uses 'label'. Both are written here once so the menu, the
	 * group cards and the tab strip can never disagree about what a group
	 * is called.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function groups(): array {
		return array(
			'overview' => array(
				'label'      => __( 'Office overview', 'estat-os' ),
				'menu_label' => __( 'Overview', 'estat-os' ),
				'desc'       => __( 'Where your office stands: details, setup and handy links.', 'estat-os' ),
				'icon'       => 'office',
			),
			'general' => array(
				'label'      => __( 'Office details', 'estat-os' ),
				'menu_label' => __( 'Office details', 'estat-os' ),
				'desc'       => __( 'Office name, phone, address, currency and language.', 'estat-os' ),
				'icon'       => 'form',
			),
			'listings' => array(
				'label'      => __( 'Properties & workflow', 'estat-os' ),
				'menu_label' => __( 'Properties', 'estat-os' ),
				'desc'       => __( 'How properties behave: defaults, availability, expiry and verification.', 'estat-os' ),
				'icon'       => 'home',
			),
			'leads' => array(
				'label'      => __( 'Enquiries & emails', 'estat-os' ),
				'menu_label' => __( 'Enquiries & emails', 'estat-os' ),
				'desc'       => __( 'Where enquiries go, who gets the emails, and how forms behave.', 'estat-os' ),
				'icon'       => 'inbox',
			),
			'pocket' => array(
				'label'      => __( 'Staff phone app (Pocket)', 'estat-os' ),
				'menu_label' => __( 'Staff app (Pocket)', 'estat-os' ),
				'desc'       => __( 'The link to send your team, the code they scan, and what the app lets them do.', 'estat-os' ),
				'icon'       => 'phone',
			),
			'integrations' => array(
				'label'      => __( 'Integrations', 'estat-os' ),
				'menu_label' => __( 'Integrations', 'estat-os' ),
				'desc'       => __( 'Maps, and connections to other services.', 'estat-os' ),
				'icon'       => 'compass',
			),
			'advanced' => array(
				'label'      => __( 'Advanced & tools', 'estat-os' ),
				'menu_label' => __( 'Advanced & tools', 'estat-os' ),
				'desc'       => __( 'Practice mode, data retention, rebuild tools and other rarely used switches.', 'estat-os' ),
				'icon'       => 'filter',
			),
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to change office settings.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( is_array($_GET['tab']) ? '' : $_GET['tab'] ) ) : 'overview';
		$groups = self::groups();

		// Fix broken link: tab=tools should show Advanced with Tools section, not redirect to overview.
		if ( 'tools' === $tab ) {
			$tab = 'advanced';
			// Set flag to scroll to tools.
			$_GET['estat_scroll'] = 'tools';
		}

		if ( ! isset( $groups[ $tab ] ) ) {
			$tab = 'overview';
		}
		$s = Settings::all();


		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb"><span><?php esc_html_e( 'Settings', 'estat-os' ); ?></span><span>/</span><span class="is-muted"><?php echo esc_html( $groups[ $tab ]['label'] ); ?></span></div>
				<div class="estat-ui-header-row"><div><h1 class="estat-ui-h1"><?php esc_html_e( 'Settings', 'estat-os' ); ?></h1><p class="estat-ui-desc"><?php esc_html_e( 'Everything that changes how the office and the staff phone app behave, in one place.', 'estat-os' ); ?></p></div><div class="estat-ui-header-actions"><?php if ( 'overview' !== $tab ) : ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=overview' ) ); ?>" class="estat-ui-btn"><?php esc_html_e( 'All groups', 'estat-os' ); ?></a><?php endif; ?></div></div>
			</div>

		<?php if ( 'overview' === $tab ) : ?>
			<?php self::render_overview( $groups, $s ); ?>
		<?php else : ?>
			<div class="estat-settings-layout">
				<nav class="estat-settings-nav" aria-label="<?php esc_attr_e( 'Settings groups', 'estat-os' ); ?>">
					<?php foreach ( $groups as $key => $g ) : $active = $key === $tab; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $key ) ); ?>" class="<?php echo $active ? 'is-active' : ''; ?>">
						<span class="estat-settings-nav-item">
							<span class="estat-settings-nav-icon"><?php echo Icon::render( $g['icon'], 18 ); // phpcs:ignore ?></span>
							<span><?php echo esc_html( $g['label'] ); ?></span>
						</span>
					</a>
					<?php endforeach; ?>
				</nav>
				<div class="estat-settings-content">
					<div class="estat-settings-header">
						<div>
							<h2 class="estat-section-title"><?php echo esc_html( $groups[ $tab ]['label'] ); ?></h2>
							<p class="description"><?php echo esc_html( $groups[ $tab ]['desc'] ); ?></p>
						</div>
					</div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $tab ) ); ?>" class="estat-settings-form">
						<?php wp_nonce_field( 'estat_save_settings', 'estat_nonce' ); ?>
						<input type="hidden" name="estat_action" value="save_settings" />
						<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" />
						<?php
						/*
						 * The switches this page drew. A form that posts a subset (the
						 * Elementor switch on the Forms screen, say) leaves the rest of
						 * the settings exactly as they were.
						 */
						?>
						<input type="hidden" name="estat_flags" value="<?php echo esc_attr( implode( ',', Actions::tab_flags( (string) $tab ) ) ); ?>" />
						<?php
						switch ( $tab ) {
							case 'general': self::general( $s ); break;
							case 'listings': self::listings( $s ); break;
							case 'leads': self::leads( $s ); break;
							case 'pocket': self::pocket( $s ); break;
							case 'integrations': self::integrations( $s ); break;
							case 'advanced': self::advanced( $s ); break;
							default: self::overview_details( $s ); break;
						}
						?>
						<div class="estat-form-actions">
							<button type="submit" class="button button-primary"><?php esc_html_e( 'Save changes', 'estat-os' ); ?></button>
						</div>
					</form>
				</div>
			</div>
		<?php endif; ?>
		</div>
		<?php
	}

	private static function render_overview( array $groups, array $s ): void {
		$counts = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $counts['publish'] ?? 0 );
		$office_name = (string) ( $s['office_name'] ?? '' );
		$city = (string) ( $s['city'] ?? '' );
		if ( '' === $city && isset( $s['cities'][0] ) ) {
			$city = (string) $s['cities'][0];
		}
		$setup_needed = \EstatOS\Admin\Screens\SetupScreen::needed();
		?>
		<div class="estat-settings-overview">
			<div class="estat-settings-cards">
				<?php foreach ( $groups as $key => $g ) : if ( 'overview' === $key ) continue; ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=' . $key ) ); ?>" class="estat-settings-card-link">
					<div class="estat-card-panel estat-settings-card">
						<span class="estat-settings-card-icon"><?php echo Icon::render( $g['icon'], 20 ); // phpcs:ignore ?></span>
						<span class="estat-settings-card-body">
							<span class="estat-settings-card-title"><?php echo esc_html( $g['label'] ); ?></span>
							<span class="estat-settings-card-desc"><?php echo esc_html( $g['desc'] ); ?></span>
							<span class="estat-settings-card-open"><?php esc_html_e( 'Open', 'estat-os' ); ?> →</span>
						</span>
					</div>
				</a>
				<?php endforeach; ?>
			</div>
			<div class="estat-settings-overview-side">
				<div class="estat-card-panel">
					<h3 class="estat-section-title-sm"><?php esc_html_e( 'Office overview', 'estat-os' ); ?></h3>
					<div class="estat-overview-list">
						<?php if ( '' !== $office_name ) : ?><div><strong><?php esc_html_e( 'Office', 'estat-os' ); ?>:</strong> <?php echo esc_html( $office_name ); ?></div><?php endif; ?>
						<?php
						/*
						 * The lines the office typed about itself. They now print on the
						 * property sheet and under every email, so they belong where the
						 * office looks — not hidden three screens away.
						 */
						$tagline        = trim( (string) ( $s['tagline'] ?? '' ) );
						$contact_person = trim( (string) ( $s['contact_person'] ?? '' ) );
						$office_hours   = trim( (string) ( $s['office_hours'] ?? '' ) );
						?>
						<?php if ( '' !== $tagline ) : ?><div><?php echo esc_html( $tagline ); ?></div><?php endif; ?>
						<?php if ( '' !== $office_hours ) : ?><div><strong><?php esc_html_e( 'Open', 'estat-os' ); ?>:</strong> <?php echo esc_html( $office_hours ); ?></div><?php endif; ?>
						<?php if ( '' !== $contact_person ) : ?><div><strong><?php esc_html_e( 'Ask for', 'estat-os' ); ?>:</strong> <?php echo esc_html( $contact_person ); ?></div><?php endif; ?>
						<?php if ( '' !== $city ) : ?><div><strong><?php esc_html_e( 'City', 'estat-os' ); ?>:</strong> <?php echo esc_html( $city ); ?></div><?php endif; ?>
						<div><strong><?php esc_html_e( 'Live listings', 'estat-os' ); ?>:</strong> <?php echo esc_html( (string) $live ); ?></div>
						<div class="estat-overview-status">
							<?php if ( $setup_needed ) : ?>
								<span class="estat-pill is-warn"><?php esc_html_e( 'Setup needed', 'estat-os' ); ?></span>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-setup' ) ); ?>" class="button button-small"><?php esc_html_e( 'Finish setup', 'estat-os' ); ?></a>
							<?php else : ?>
								<span class="estat-pill is-good"><?php esc_html_e( 'Setup complete', 'estat-os' ); ?></span>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="estat-card-panel estat-mt">
					<h4 class="estat-section-title-sm"><?php esc_html_e( 'Quick links', 'estat-os' ); ?></h4>
					<ul class="estat-quick-links">
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>"><?php esc_html_e( 'Listings', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>"><?php esc_html_e( 'Enquiries', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-projects' ) ); ?>"><?php esc_html_e( 'Projects', 'estat-os' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ); ?>"><?php esc_html_e( 'Import & export', 'estat-os' ); ?></a></li>
					</ul>
					<h4 class="estat-section-title-sm" style="margin-top:16px"><?php esc_html_e( 'Other screens', 'estat-os' ); ?></h4>
					<p class="description" style="margin:4px 0 8px"><?php esc_html_e( 'The menu keeps the screens you open every day. These are quieter ones — you open them when you need them.', 'estat-os' ); ?></p>
					<ul class="estat-quick-links">
						<li><strong><?php esc_html_e( 'Enquiries', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>"><?php esc_html_e( 'Enquiries', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-pipeline' ) ); ?>"><?php esc_html_e( 'Pipeline', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-visits' ) ); ?>"><?php esc_html_e( 'Site visits', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-requests' ) ); ?>"><?php esc_html_e( 'Change requests', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-search-alerts' ) ); ?>"><?php esc_html_e( 'Search Alerts', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-forms' ) ); ?>"><?php esc_html_e( 'Forms', 'estat-os' ); ?></a></li>
						<li><strong><?php esc_html_e( 'Team & reports', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-reports' ) ); ?>"><?php esc_html_e( 'Reports', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-insights' ) ); ?>"><?php esc_html_e( 'Insights', 'estat-os' ); ?></a></li>
						<li><strong><?php esc_html_e( 'Staff phone app (Pocket)', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( Pocket::url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( Pocket::url() ); ?></a></li>
						<li><strong><?php esc_html_e( 'PC dashboard', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( Dashboard::url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( Dashboard::url() ); ?></a></li>
						<li><strong><?php esc_html_e( 'Media & design', 'estat-os' ); ?>:</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=general' ) ); ?>"><?php esc_html_e( 'Office details', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-gallery' ) ); ?>"><?php esc_html_e( 'Gallery & media', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-templates' ) ); ?>"><?php esc_html_e( 'Page blocks', 'estat-os' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-design-tokens' ) ); ?>"><?php esc_html_e( 'Colours and fonts', 'estat-os' ); ?></a></li>
					</ul>
				</div>
			</div>
		</div>

			<div class="estat-card-panel estat-mt">
				<h4 class="estat-section-title-sm"><?php esc_html_e( 'Scan a code instead of typing a link', 'estat-os' ); ?></h4>
				<p class="description" style="margin:4px 0 12px"><?php esc_html_e( 'Point a phone camera at a code and it opens by itself. Handy when a new staff member joins, or when a client asks for the office location.', 'estat-os' ); ?></p>
				<div style="display:flex;flex-wrap:wrap;gap:12px">
					<?php
					Partials::qr_card(
						__( 'Staff phone app (Pocket)', 'estat-os' ),
						Pocket::url(),
						__( 'A staff member scans this to open the app on their own phone.', 'estat-os' )
					);
					Partials::qr_card(
						__( 'PC dashboard', 'estat-os' ),
						Dashboard::url(),
						__( 'Opens your own dashboard on any computer or phone.', 'estat-os' )
					);
					Partials::qr_card(
						__( 'Office location', 'estat-os' ),
						self::office_map_url( $s ),
						__( 'Send this to a client — the camera opens the map.', 'estat-os' )
					);
					?>
				</div>
			</div>
		<?php
	}

	/**
	 * The staff phone app, in one place.
	 *
	 * The office asked for the settings of the phone app to sit with the
	 * settings of everything else: the link to send the team, the code they
	 * scan, and the switches that decide what a staff member may do from a
	 * phone. The switches below are read by the app itself (see
	 * Pocket\Actions), so nothing on this panel is decoration.
	 *
	 * @param array $s Settings.
	 * @return void
	 */
	private static function pocket( array $s ): void {
		$link    = Pocket::url();
		$pc      = Dashboard::url();
		$office  = (string) ( $s['office_name'] ?? '' );
		$message = sprintf(
			/* translators: 1: office name, 2: the web address of the staff app. */
			__( 'Hello! This is the office app for %1$s. Open this link on your phone and sign in with the username and password you were given: %2$s — save it to your home screen, then you can add a property, add photos and see your enquiries from anywhere.', 'estat-os' ),
			'' !== $office ? $office : __( 'our office', 'estat-os' ),
			$link
		);
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Send this to your team', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Copy this message and send it on WhatsApp. The office decides who gets a login — the app shows nothing to anybody who is not signed in.', 'estat-os' ); ?></p>
			<div class="estat-pocket-invite estat-copyable" title="<?php esc_attr_e( 'Click to copy', 'estat-os' ); ?>"><?php echo esc_html( $message ); ?></div>
			<p class="description"><?php esc_html_e( 'Click the box above to copy it.', 'estat-os' ); ?></p>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'The codes your team can scan', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Point a phone camera at a code and it opens by itself. Handy when a new staff member joins, or when a client asks for the office location.', 'estat-os' ); ?></p>
			<div style="display:flex;flex-wrap:wrap;gap:12px">
				<?php
				Partials::qr_card(
					__( 'Staff phone app (Pocket)', 'estat-os' ),
					$link,
					__( 'A staff member scans this to open the app on their own phone.', 'estat-os' )
				);
				Partials::qr_card(
					__( 'PC dashboard', 'estat-os' ),
					$pc,
					__( 'Opens your own dashboard on any computer or phone.', 'estat-os' )
				);
				?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'What a staff member may do from the phone', 'estat-os' ); ?></h3>
			<?php
			self::field_checkbox( 'pocket_show_enquiries', __( 'Let staff see the enquiries that come in for their own properties', 'estat-os' ), $s );
			self::field_checkbox( 'pocket_agents_edit_live', __( 'Let staff fix small details on a property that is already on the website, without waiting for the office', 'estat-os' ), $s );
			self::field(
				'completeness_threshold',
				__( 'How ready must a property be before staff can send it to you? (0–100)', 'estat-os' ),
				$s,
				'number'
			);
			?>
			<p class="description"><?php esc_html_e( 'Readiness is the score on the property screen: filling in the headline, the description, the price and a few photos gets it up. Below this number, a property waits in drafts until the office fills in the rest.', 'estat-os' ); ?></p>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'The phone app also follows these settings', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'They live on their own pages so there is only ever one place to change them. This is where to look when the app behaves in a way you did not expect.', 'estat-os' ); ?></p>
			<ul class="estat-quick-links">
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=listings' ) ); ?>"><?php esc_html_e( 'Whether a property needs checking before it goes live', 'estat-os' ); ?></a>
					— <?php esc_html_e( 'the office sees it in the queue first.', 'estat-os' ); ?>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=listings' ) ); ?>"><?php esc_html_e( 'How long a property stays on the website', 'estat-os' ); ?></a>
					— <?php esc_html_e( 'after that it comes off by itself and the office is told.', 'estat-os' ); ?>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=listings' ) ); ?>"><?php esc_html_e( 'What the website says when there is no price', 'estat-os' ); ?></a>
					— <?php esc_html_e( 'the words the phone shows too.', 'estat-os' ); ?>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-settings&tab=leads' ) ); ?>"><?php esc_html_e( 'The four emails the office gets', 'estat-os' ); ?></a>
					— <?php esc_html_e( 'new enquiry, approval waiting, morning summary, weekly report.', 'estat-os' ); ?>
				</li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Office ka pata map par — QR ke liye.
	 *
	 * @param array $s Settings.
	 * @return string Link, or '' when maps are switched off.
	 */
	private static function office_map_url( array $s ): string {
		$provider = (string) ( $s['map_provider'] ?? 'osm' );
		$address  = trim( (string) ( $s['address'] ?? '' ) );
		$city     = trim( (string) ( $s['city'] ?? '' ) );
		// City ko sirf tab jodo jab wo pate me pehle se na ho — warna "Gurugram, Gurugram" chhapta hai.
		if ( '' !== $city && false === stripos( $address, $city ) ) {
			$address = trim( $address . ', ' . $city, ' ,' );
		}
		if ( '' === $address || 'none' === $provider ) {
			return '';
		}
		if ( 'google' === $provider ) {
			return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
		}
		return 'https://www.openstreetmap.org/search?query=' . rawurlencode( $address );
	}

	private static function overview_details( array $s ): void {
		echo '<div class="estat-card-panel"><p class="description">' . esc_html__( 'Overview details are shown on the main groups page.', 'estat-os' ) . '</p></div>';
	}

	private static function general( array $s ): void {
		$cities_value = is_array( $s['cities'] ?? null ) ? implode( ', ', $s['cities'] ) : (string) ( $s['cities'] ?? '' );
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Office profile', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'office_name', __( 'Office name', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'tagline', __( 'Tagline / One line about the office', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'contact_person', __( 'Contact person', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'logo_id', __( 'Office logo', 'estat-os' ), $s, 'image' ); ?>
				<?php self::field( 'address', __( 'Office address', 'estat-os' ), $s, 'textarea' ); ?>
				<?php self::field( 'office_hours', __( 'Office hours', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'phone', __( 'Phone', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'whatsapp', __( 'WhatsApp', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'email', __( 'Contact email', 'estat-os' ), $s, 'email' ); ?>
				<?php self::field( 'cities', __( 'Cities you work in (comma separated)', 'estat-os' ), array( 'cities' => $cities_value ), 'text' ); ?>
			</div>
		</div>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Locale & format', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-3">
				<?php self::field( 'country', __( 'Country', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'city', __( 'Primary city', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'currency', __( 'Currency', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'currency_symbol', __( 'Currency symbol', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'price_format', __( 'How prices are written', 'estat-os' ), $s, 'select', array( 'indian' => __( 'Indian — ₹75 Lakh, ₹2.5 Cr', 'estat-os' ), 'international' => __( 'International — ₹750K, ₹2.5M', 'estat-os' ) ) ); ?>
				<?php self::field( 'default_area_unit', __( 'Default area unit', 'estat-os' ), $s, 'select', Vocabulary::area_units() ); ?>
				<?php self::field( 'language', __( 'Language for the office screens', 'estat-os' ), $s, 'select', \EstatOS\I18n\Language::choices() ); ?>
				<?php self::field( 'frontend_language', __( 'Language for the website', 'estat-os' ), $s, 'select', \EstatOS\I18n\Language::choices() ); ?>
				<?php self::field_checkbox( 'allow_visitor_lang', __( 'Let visitors switch language themselves', 'estat-os' ), $s ); ?>
			</div>
		</div>
		<?php
	}

	private static function listings( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Website & listings', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'listings_per_page', __( 'Listings per page', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field_checkbox( 'enable_favorites', __( 'Enable favorites', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'enable_compare', __( 'Enable compare', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'enable_schema', __( 'Add hidden details Google reads (price, area, photos, ratings)', 'estat-os' ), $s ); ?>
				<?php self::field( 'verification_mode', __( 'Verification mode', 'estat-os' ), $s, 'select', array( 'optional'=>__( 'Optional', 'estat-os' ), 'required'=>__( 'Required', 'estat-os' ), 'off'=>__( 'Off', 'estat-os' ) ) ); ?>
				<?php self::field( 'listing_expiry_days', __( 'Listing expiry days (0 = never)', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'regulatory_label', __( 'Regulatory label', 'estat-os' ), $s, 'text' ); ?>
				<?php
			self::field(
				'page_renderer',
				__( 'Who draws a property page', 'estat-os' ),
				$s,
				'select',
				array(
					'theme'  => __( 'My website — theme or Elementor (recommended)', 'estat-os' ),
					'plugin' => __( 'The plugin\'s own page', 'estat-os' ),
				)
			);
			?>
			<p class="description"><?php esc_html_e( 'Leave this on “My website” and the plugin will never replace a page you built in Elementor — a property page is drawn by your template, and the plugin only supplies the pieces (Property Details, Gallery, Map, EMI Calculator, WhatsApp Button and the rest, all under the Real Estate widgets). Switch to the plugin\'s own page only if your theme has no property template of its own.', 'estat-os' ); ?></p>
			<?php self::field_checkbox( 'show_regulatory', __( 'Show regulatory info', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'share_enabled', __( 'Share row (WhatsApp / Copy / Print)', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'print_enabled', __( 'Print page', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'emi_enabled', __( 'EMI calculator', 'estat-os' ), $s ); ?>
				<?php self::field( 'emi_default_rate', __( 'EMI default rate %', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'emi_default_years', __( 'EMI default years', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field_checkbox( 'locality_pages', __( 'Locality pages', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'search_alerts_enabled', __( 'Let visitors watch a search', 'estat-os' ), $s ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Helper pages', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Pages are created as drafts, so you can look at them before they go live.', 'estat-os' ); ?></p>
			<div class="estat-pages-list">
				<?php echo \EstatOS\Frontend\Pages::admin_list_html(); // phpcs:ignore ?>
			</div>
			<div class="estat-field-actions">
				<?php
				$url = admin_url( 'admin.php?page=estat-settings&tab=listings' );
				echo '<form method="post" class="estat-inline-form" action="' . esc_url( $url ) . '">';
				wp_nonce_field( 'estat_tool_create_public_pages', 'estat_nonce' );
				echo '<input type="hidden" name="estat_action" value="create_public_pages" />';
				echo '<button type="submit" class="button">' . esc_html__( 'Create helper pages as drafts', 'estat-os' ) . '</button>';
				echo '</form>';
				?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Search filters — which filters show on website', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Choose which filters appear and drag to reorder. Visitors only see enabled ones.', 'estat-os' ); ?></p>
			<?php self::filters_block( $s ); ?>
		</div>
		<?php
	}

	private static function filters_block( array $s ): void {
		$enabled = is_array( $s['enabled_filters'] ?? null ) ? $s['enabled_filters'] : array_keys( Vocabulary::all_filters() );
		$order   = is_array( $s['filter_order'] ?? null ) ? $s['filter_order'] : array_keys( Vocabulary::all_filters() );
		$all     = Vocabulary::all_filters();
		foreach ( array_keys( $all ) as $k ) {
			if ( ! in_array( $k, $order, true ) ) {
				$order[] = $k;
			}
		}
		$order = array_values( array_intersect( $order, array_keys( $all ) ) );
		?>
		<div class="estat-filters-toolbar">
			<button type="button" class="button" id="estat-filters-enable-all"><?php esc_html_e( 'Enable all', 'estat-os' ); ?></button>
			<button type="button" class="button" id="estat-filters-disable-all"><?php esc_html_e( 'Disable all', 'estat-os' ); ?></button>
			<button type="button" class="button" id="estat-filters-reset-order"><?php esc_html_e( 'Reset order', 'estat-os' ); ?></button>
		</div>
		<input type="hidden" name="settings[filter_order_csv]" id="estat-filter-order-csv" value="<?php echo esc_attr( implode( ',', $order ) ); ?>">
		<div id="estat-filters-list" class="estat-filters-list">
			<?php foreach ( $order as $key ) : if ( ! isset( $all[ $key ] ) ) continue; $info = $all[ $key ]; $checked = in_array( $key, $enabled, true ); $is_on = $checked ? 'is-on' : 'is-off'; ?>
			<div class="estat-filter-item <?php echo esc_attr( $is_on ); ?>" data-key="<?php echo esc_attr( $key ); ?>" draggable="true">
				<span class="estat-drag-handle">↕</span>
				<input type="checkbox" name="settings[enabled_filters][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $checked ); ?>>
				<span class="estat-filter-label"><strong><?php echo esc_html( $info['label'] ); ?></strong> <span class="estat-filter-meta"><?php echo esc_html( $key . ' · ' . $info['group'] ); ?></span></span>
				<span class="estat-filter-group"><?php echo esc_html( $info['group'] ); ?></span>
			</div>
			<?php endforeach; ?>
		</div>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const list = document.getElementById('estat-filters-list');
			const orderInput = document.getElementById('estat-filter-order-csv');
			if(!list || !orderInput) return;
			let dragEl = null;
			function updateOrder(){
				const keys = Array.from(list.querySelectorAll('.estat-filter-item')).map(el=>el.getAttribute('data-key'));
				orderInput.value = keys.join(',');
			}
			list.addEventListener('dragstart', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(!item) return;
				dragEl = item;
				e.dataTransfer.effectAllowed = 'move';
				item.style.opacity='0.5';
			});
			list.addEventListener('dragend', function(e){
				const item = e.target.closest('.estat-filter-item');
				if(item) item.style.opacity='1';
				dragEl=null;
				updateOrder();
			});
			list.addEventListener('dragover', function(e){
				e.preventDefault();
				const target = e.target.closest('.estat-filter-item');
				if(!target || target===dragEl) return;
				const rect = target.getBoundingClientRect();
				const next = (e.clientY - rect.top) / (rect.height) > 0.5;
				if(next){ target.parentNode.insertBefore(dragEl, target.nextSibling); }else{ target.parentNode.insertBefore(dragEl, target); }
			});
			list.addEventListener('drop', function(e){ e.preventDefault(); updateOrder(); });
			const enAll = document.getElementById('estat-filters-enable-all');
			const disAll = document.getElementById('estat-filters-disable-all');
			const resetBtn = document.getElementById('estat-filters-reset-order');
			if(enAll) enAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=true); });
			if(disAll) disAll.addEventListener('click', function(){ list.querySelectorAll('input[type=checkbox]').forEach(cb=>cb.checked=false); });
			if(resetBtn) resetBtn.addEventListener('click', function(){
				const defaults = <?php echo wp_json_encode( array_keys( Vocabulary::all_filters() ) ); ?>;
				orderInput.value = defaults.join(',');
				const map = {};
				list.querySelectorAll('.estat-filter-item').forEach(el=>{ map[el.getAttribute('data-key')] = el; });
				defaults.forEach(k=>{ if(map[k]) list.appendChild(map[k]); });
			});
			list.addEventListener('change', function(e){
				if(e.target.type==='checkbox'){
					const item = e.target.closest('.estat-filter-item');
					if(item){ item.classList.toggle('is-on', e.target.checked); item.classList.toggle('is-off', !e.target.checked); }
				}
			});
		});
		</script>
		<?php
	}

	private static function leads( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Lead pipeline & assignment', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'lead_fallback_agent', __( 'Fallback agent', 'estat-os' ), $s, 'select', \EstatOS\Data\Picker::options( \EstatOS\Data\PostTypes::AGENT, __( '— No auto-assign —', 'estat-os' ) )['options'] ); ?>
				<?php self::field( 'retention_days', __( 'Auto-erase personal data after days', 'estat-os' ), $s, 'number' ); ?>
				<?php self::field( 'consent_text', __( 'Consent text', 'estat-os' ), $s, 'textarea' ); ?>
				<?php self::field( 'privacy_url', __( 'Your privacy page (optional)', 'estat-os' ), $s, 'url' ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Where notifications go', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'notify_email', __( 'Notification email', 'estat-os' ), $s, 'email' ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Emails you receive', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Four emails, and no more. Everything else shows up on your Today screen and the screens in the menu.', 'estat-os' ); ?></p>
			<div class="estat-field-grid estat-field-grid-2">
				<?php
			self::field_checkbox( 'whatsapp_cta_enabled', __( 'Show a WhatsApp button on property and society pages', 'estat-os' ), $s );
			self::field( 'whatsapp_cta_text', __( 'The message it starts with (leave empty for the property\'s own name and link)', 'estat-os' ), $s, 'text' );
			?>
			<p class="description"><?php esc_html_e( 'The button sends the visitor to your WhatsApp number with the message already written — property name, price and link included — so the chat arrives without “which property?”. Taps are counted on the property itself, not written into Enquiries, because a tap has no name or number to call back on. Somewhere else on your site? Use [estat_whatsapp] or the WhatsApp Button widget.', 'estat-os' ); ?></p>
			<?php self::field_checkbox( 'notify_new_lead', __( 'When a new enquiry arrives', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_listing_approval', __( 'When a property is waiting for your approval', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_daily_summary', __( 'Every morning at 8, what today looks like', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'notify_weekly_report', __( 'Every Monday at 8, how last week went', 'estat-os' ), $s ); ?>
			</div>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Does email work?', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Press this and we send one short email right now, so you know whether the four emails above will actually reach you. Nothing on your website changes.', 'estat-os' ); ?></p>
			<?php
			$last_test = trim( (string) ( $s['test_mail_last_sent'] ?? '' ) );
			self::tool_button( 'test_mail', __( 'Send a test email to me', 'estat-os' ), admin_url( 'admin.php?page=estat-settings&tab=leads&estat_scroll=mail' ) );
			if ( '' !== $last_test ) :
				?>
				<p class="description"><?php
					/* translators: %s: date and time of the last test email. */
					echo esc_html( sprintf( __( 'Last test: %s', 'estat-os' ), $last_test ) );
				?></p>
				<?php
			endif;
			?>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'How your emails look', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'The name and address your emails come from, and a line at the bottom. Leave the address empty to use your website\'s own.', 'estat-os' ); ?></p>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'email_from_name', __( 'From name', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'email_from_address', __( 'From address', 'estat-os' ), $s, 'email' ); ?>
				<?php self::field( 'email_footer_text', __( 'Footer text', 'estat-os' ), $s, 'textarea' ); ?>
			</div>
		</div>
		<?php
	}

	private static function integrations( array $s ): void {
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Maps', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'map_provider', __( 'Map provider', 'estat-os' ), $s, 'select', array( 'osm'=>__( 'OpenStreetMap', 'estat-os' ), 'google'=>__( 'Google Maps', 'estat-os' ), 'none'=>__( 'None', 'estat-os' ) ) ); ?>
				<?php self::field( 'google_maps_key', __( 'Key from Google (only if you chose Google Maps above)', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_lat', __( 'Where your area is — latitude', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_lng', __( 'Where your area is — longitude', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'map_default_zoom', __( 'How close the map starts', 'estat-os' ), $s, 'number' ); ?>
			</div>
			<p class="description"><?php esc_html_e( 'A property with no pin of its own shows your area instead, so the page is never empty. Copy the two numbers from any map website — for example 28.4595 and 77.0266 — and the map will open around your office.', 'estat-os' ); ?></p>
		</div>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Forms on your website', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field_checkbox( 'elementor_forms_to_enquiries', __( 'Also collect messages sent through your website\'s other forms', 'estat-os' ), $s ); ?>
			</div>
			<p class="description"><?php esc_html_e( 'Messages sent through a form made in Elementor will appear in Enquiries next to everything else. Switch it off if you would rather keep them separate.', 'estat-os' ); ?></p>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Telling another program when something happens', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Some offices run a second program — a CRM, a spreadsheet, a chat group — and want it told the moment an enquiry arrives. Leave all of this empty if that is not you.', 'estat-os' ); ?></p>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field_checkbox( 'webhook_enabled', __( 'Tell the other program when something happens', 'estat-os' ), $s ); ?>
				<?php self::field( 'webhook_url', __( 'Where to send it (first address)', 'estat-os' ), $s, 'url' ); ?>
				<?php self::field( 'webhook_url_2', __( 'Where to send it (second address, optional)', 'estat-os' ), $s, 'url' ); ?>
				<?php self::field( 'webhook_secret', __( 'A shared password the other program must send', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field( 'webhook_version', __( 'Which version of the message to send', 'estat-os' ), $s, 'select', array( 'v1'=>__( 'Version 1 (older)', 'estat-os' ), 'v2'=>__( 'Version 2 (newer)', 'estat-os' ) ) ); ?>
				<?php self::field( 'inbound_secret', __( 'Password for messages coming in from outside', 'estat-os' ), $s, 'text' ); ?>
				<?php self::field_checkbox( 'webhook_retry', __( 'Try again three times if the first attempt fails', 'estat-os' ), $s ); ?>
			</div>
		</div>
		<?php
	}

	private static function advanced( array $s ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_tools = isset( $_GET['estat_scroll'] ) && 'tools' === sanitize_key( wp_unslash( (string) ( is_array( $_GET['estat_scroll'] ) ? '' : $_GET['estat_scroll'] ) ) );
		?>
		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Data & advanced', 'estat-os' ); ?></h3>
			<div class="estat-field-grid estat-field-grid-2">
				<?php self::field( 'admin_theme', __( 'Admin theme', 'estat-os' ), $s, 'select', array( 'light'=>__( 'Light', 'estat-os' ), 'dark'=>__( 'Dark', 'estat-os' ), 'auto'=>__( 'Auto', 'estat-os' ) ) ); ?>
				<?php self::field_checkbox( 'practice_mode', __( 'Practice mode', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'multi_agency', __( 'Multi-agency', 'estat-os' ), $s ); ?>
				<?php self::field_checkbox( 'delete_data_on_uninstall', __( 'Delete data on uninstall', 'estat-os' ), $s ); ?>
			</div>
		</div>

		<div id="estat-tools-section" class="estat-card-panel <?php echo $is_tools ? 'estat-highlight' : ''; ?>">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Tools — maintenance', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Housekeeping the plugin runs on its own. Press one of these when you do not want to wait for tonight.', 'estat-os' ); ?></p>
			<?php
			$purged = \EstatOS\Support\Cache::purged_at();
			if ( '' !== $purged ) :
				?>
				<p class="description"><?php
					/* translators: %s: date and time of the last cache clear. */
					echo esc_html( sprintf( __( 'The website\'s saved copy was last cleared on %s. Every update clears it by itself.', 'estat-os' ), $purged ) );
				?></p>
			<?php endif; ?>
			<div class="estat-tools-grid">
				<?php
				$url = admin_url( 'admin.php?page=estat-settings&tab=advanced&estat_scroll=tools' );
				self::tool_button( 'rebuild_index', __( 'Rebuild search list', 'estat-os' ), $url );
				self::tool_button( 'repair_tables', __( 'Repair database', 'estat-os' ), $url );
				self::tool_button( 'clear_cache', __( 'Clear temporary data', 'estat-os' ), $url );
				self::tool_button( 'purge_caches', __( 'Clear the website\'s saved copy', 'estat-os' ), $url );
				self::tool_button( 'tidy_public_pages', __( 'Tidy the pages the plugin made earlier', 'estat-os' ), $url );
				self::tool_button( 'run_housekeeping', __( 'Run daily jobs now', 'estat-os' ), $url );
				self::tool_button( 'repair_broken_data', __( 'Repair broken localities + draft pages (3.0.6 → 3.0.7)', 'estat-os' ), $url );
				self::tool_button( 'seed_practice', __( 'Add sample data', 'estat-os' ), $url );
				self::tool_button( 'clear_practice', __( 'Remove sample data', 'estat-os' ), $url );
				?>
			</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Which happenings to tell the other program about', 'estat-os' ); ?></h3>
			<?php
			$selected_events = array_map( 'strval', is_array( $s['webhook_events'] ?? null ) ? $s['webhook_events'] : array() );
			echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:8px">';
			foreach ( \EstatOS\Webhooks\Webhooks::events() as $event => $label ) {
				printf(
					'<label class="estat-inline-check" style="border:1px solid var(--estat-line);padding:6px 8px;border-radius:var(--estat-radius)"><input type="checkbox" name="settings[webhook_events][]" value="%1$s" %2$s /> %3$s</label>',
					esc_attr( (string) $event ),
					checked( in_array( (string) $event, $selected_events, true ), true, false ),
					esc_html( (string) $label )
				);
			}
			echo '</div>';
			?>
		</div>

		<div class="estat-card-panel">
			<h3 class="estat-section-title-sm"><?php esc_html_e( 'Auto-assign new enquiries', 'estat-os' ); ?></h3>
			<p class="description"><?php esc_html_e( 'When an enquiry arrives with an intent like Buy or Rent, hand it to this person automatically. Leave it on “No auto-assign” to sort them yourself.', 'estat-os' ); ?></p>
			<?php
			$assign_rules  = is_array( $s['lead_assign_rules'] ?? null ) ? $s['lead_assign_rules'] : array();
			$agent_options = \EstatOS\Data\Picker::options( \EstatOS\Data\PostTypes::AGENT, __( '— No auto-assign —', 'estat-os' ) );
			foreach ( \EstatOS\Support\Vocabulary::lead_intents() as $intent_key => $intent_label ) {
				$current = $assign_rules[ $intent_key ] ?? 0;
				echo '<div style="display:flex;gap:8px;align-items:center;margin:6px 0"><span style="min-width:110px">' . esc_html( $intent_label ) . '</span>';
				echo '<select name="settings[lead_assign_rules][' . esc_attr( $intent_key ) . ']">';
				foreach ( $agent_options['options'] as $opt_val => $opt_label ) {
					echo '<option value="' . esc_attr( (string) $opt_val ) . '" ' . selected( (string) $current, (string) $opt_val, false ) . '>' . esc_html( $opt_label ) . '</option>';
				}
				echo '</select></div>';
			}
			?>
		</div>
		<?php
	}

	/* helpers — no inline styles, all via admin-new.css classes */
	private static function field( string $key, string $label, array $s, string $type = 'text', array $options = array() ): void {
		$value = $s[ $key ] ?? '';
		$name = 'settings[' . $key . ']';
		echo '<div class="estat-field-row"><label class="estat-field-label">' . esc_html( $label ) . '</label>';
		if ( 'textarea' === $type ) {
			echo '<textarea name="' . esc_attr( $name ) . '" rows="3">' . esc_textarea( (string) $value ) . '</textarea>';
		} elseif ( 'select' === $type ) {
			echo '<select name="' . esc_attr( $name ) . '">';
			foreach ( $options as $opt_val => $opt_label ) {
				$opt_val = (string) $opt_val;
				echo '<option value="' . esc_attr( $opt_val ) . '" ' . selected( (string) $value, $opt_val, false ) . '>' . esc_html( (string) $opt_label ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'number' === $type ) {
			echo '<input type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		} elseif ( 'email' === $type || 'url' === $type ) {
			echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		} elseif ( 'image' === $type ) {
			$img_id = (int) $value;
			$img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : '';
			echo '<div class="estat-image-field">';
			if ( $img_url ) {
				echo '<img src="' . esc_url( $img_url ) . '" alt="" class="estat-image-preview" />';
			}
			echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
			echo '<button type="button" class="button estat-media-button">' . esc_html__( 'Select image', 'estat-os' ) . '</button>';
			if ( $img_id ) {
				echo '<button type="button" class="button estat-media-remove">' . esc_html__( 'Remove', 'estat-os' ) . '</button>';
			}
			echo '</div>';
		} else {
			echo '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		}
		echo '</div>';
	}

	private static function field_checkbox( string $key, string $label, array $s ): void {
		$value = ! empty( $s[ $key ] );
		$name = 'settings[' . $key . ']';
		// A ticked box posts, an unticked box posts nothing at all — so the
		// switch could never be turned off. The hidden 0 goes first and the
		// checkbox, when ticked, arrives last and wins.
		echo '<div class="estat-field-row estat-field-row-checkbox"><input type="hidden" name="' . esc_attr( $name ) . '" value="0"><label class="estat-field-label"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . ' /> ' . esc_html( $label ) . '</label></div>';
	}

	private static function tool_button( string $action, string $label, string $url ): void {
		echo '<form method="post" class="estat-inline-form" action="' . esc_url( $url ) . '">';
		wp_nonce_field( 'estat_tool_' . $action, 'estat_nonce' );
		echo '<input type="hidden" name="estat_action" value="' . esc_attr( $action ) . '" />';
		echo '<button type="submit" class="button">' . esc_html( $label ) . '</button>';
		echo '</form>';
	}
}
