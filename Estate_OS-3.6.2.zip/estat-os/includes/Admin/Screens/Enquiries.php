<?php
/**
 * The enquiry inbox — F1 Leads pipeline.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\PostTypes;
use EstatOS\Leads\Leads;
use EstatOS\Leads\LeadEvents;
use EstatOS\Leads\Visits;
use EstatOS\Support\Vocabulary;
use EstatOS\Data\Picker;

defined( 'ABSPATH' ) || exit;

/**
 * One row per enquiry with timeline, dedupe badge, visit .ics.
 */
final class Enquiries {

	/**
	 * One timeline row in plain words.
	 *
	 * The panel used to print the stored event type and its raw JSON payload,
	 * so an office user read `created {"source":"elementor","intent":"sell"}`.
	 *
	 * @param array<string,mixed> $event Event row.
	 * @return string
	 */
	private static function event_line( array $event ): string {
		$words = array(
			'created'      => __( 'Enquiry received', 'estat-os' ),
			'status'       => __( 'Status changed', 'estat-os' ),
			'note'         => __( 'Note added', 'estat-os' ),
			'call'         => __( 'Phone call', 'estat-os' ),
			'visit_booked' => __( 'Visit booked', 'estat-os' ),
			'visit_checks' => __( 'Visit prepared', 'estat-os' ),
			'visit_done'   => __( 'Visit finished', 'estat-os' ),
			'visit_no_show'   => __( 'Client did not come', 'estat-os' ),
			'visit_cancelled' => __( 'Visit cancelled', 'estat-os' ),
			'visit_next'      => __( 'Next step after the visit', 'estat-os' ),
			'assigned'     => __( 'Given to a team member', 'estat-os' ),
			'email_sent'   => __( 'Email sent', 'estat-os' ),
			'merged'       => __( 'Duplicate merged', 'estat-os' ),
		);

		$type = (string) ( $event['type'] ?? '' );
		$line = $words[ $type ] ?? __( 'Update', 'estat-os' );

		$payload = json_decode( (string) ( $event['payload'] ?? '' ), true );
		if ( ! is_array( $payload ) || array() === $payload ) {
			return $line;
		}

		// Har hissa ek poora vaakya hai, jodne ke liye nahi — is liye Hinglish me
		// shabd ka kram badla ja sakta hai ("from X" / "X se").
		$named = array(
			/* translators: %s: where the enquiry came from. */
			'source'  => __( 'from %s', 'estat-os' ),
			/* translators: %s: what the visitor wants. */
			'intent'  => __( 'about %s', 'estat-os' ),
			/* translators: %s: the new status. */
			'status'  => __( 'now %s', 'estat-os' ),
			/* translators: %s: the note text. */
			'note'    => __( 'note: %s', 'estat-os' ),
			/* translators: %s: the visitor name. */
			'name'    => __( 'name: %s', 'estat-os' ),
			/* translators: %s: the message the visitor wrote. */
			'message' => __( 'message: %s', 'estat-os' ),
		);

		$bits = array();
		foreach ( $payload as $key => $value ) {
			if ( is_array( $value ) ) {
				$value = implode( ', ', array_map( 'strval', $value ) );
			}
			if ( ! is_scalar( $value ) || '' === (string) $value ) {
				continue;
			}
			$value = (string) $value;
			if ( 'source' === $key ) {
				$value = Vocabulary::label( 'lead_sources', $value );
			} elseif ( 'status' === $key ) {
				$value = Vocabulary::label( 'lead_statuses', $value );
			} elseif ( 'intent' === $key ) {
				$value = __( 'rent', 'estat-os' ) === $value ? __( 'renting', 'estat-os' ) : $value;
			}
			$format = $named[ $key ] ?? ucfirst( str_replace( '_', ' ', (string) $key ) ) . ': %s';
			$bits[] = sprintf( $format, $value );
		}

		return array() === $bits ? $line : $line . ' — ' . implode( ', ', $bits );
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) && ! current_user_can( 'estat_agent' ) ) {
			wp_die( esc_html__( 'You do not have permission to see enquiries.', 'estat-os' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( is_array($_GET['status']) ? '' : $_GET['status'] ) ) : '';
		$filter = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( is_array($_GET['filter']) ? '' : $_GET['filter'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['s']) ? '' : $_GET['s'] ) ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		$intent = isset( $_GET['intent'] ) ? sanitize_key( wp_unslash( is_array($_GET['intent']) ? '' : $_GET['intent'] ) ) : '';
		// phpcs:enable

		$results = Leads::query(
			array(
				'status'  => $status,
				'intent'  => $intent,
				'search'  => $search,
				'page'    => $paged,
				'per_page'=> 20,
			)
		);

		$agents = self::agent_options();
		$counts = Leads::counts();
		?>
		<?php
		Partials::toolbar(
			array(
				'page'         => 'estat-enquiries',
				'search'       => $search,
				'search_label' => __( 'Search by name, phone or email', 'estat-os' ),
				'count'        => (int) $results['total'],
				'action'       => __( 'Export CSV', 'estat-os' ),
				'action_url'   => wp_nonce_url( admin_url( 'admin.php?page=estat-enquiries&estat_action=export_csv&what=leads' ), 'estat_export_csv', 'estat_nonce' ),
				'filters'      => array(
					array(
						'name'    => 'status',
						'label'   => __( 'Filter by status', 'estat-os' ),
						'value'   => $status,
						// Five stages, then the set-aside ones kept apart — a
						// spam record is not a stage of the sales process.
						'options' => array( '' => __( 'All enquiries', 'estat-os' ) ) + Vocabulary::lead_statuses() + array( 'spam' => __( 'Deleted (set aside)', 'estat-os' ) ),
					),
					array(
						'name'    => 'intent',
						'label'   => __( 'Intent', 'estat-os' ),
						'value'   => $intent,
						'options' => array( '' => __( 'All intents', 'estat-os' ) ) + Vocabulary::lead_intents(),
					),
				),
			)
		);
		?>
		<div class="estat-lead-stats" style="display:flex;gap:12px;margin:12px 0;flex-wrap:wrap">
			<?php foreach ( array_keys( Vocabulary::lead_statuses() ) as $k ) : ?>
				<span class="estat-ui-chip"><?php echo esc_html( Vocabulary::lead_label( $k ) ); ?>: <?php echo esc_html( (string) ( $counts[ $k ] ?? 0 ) ); ?></span>
			<?php endforeach; ?>
			<?php if ( ! empty( $counts['spam'] ) || ! empty( $counts['qualified'] ) || ! empty( $counts['visit_scheduled'] ) || ! empty( $counts['converted'] ) ) : ?>
				<span class="estat-ui-chip is-danger"><?php esc_html_e( 'Deleted', 'estat-os' ); ?>: <?php echo esc_html( (string) ( $counts['spam'] ?? 0 ) ); ?></span>
			<?php endif; ?>
		</div>
		<?php

		if ( ! $results['items'] ) {
			Partials::empty_state(
				array(
					'icon'       => 'inbox',
					'title'      => __( 'No enquiries yet', 'estat-os' ),
					'message'    => __( 'When someone fills in a form on your website, they appear here straight away — with timeline, visit booking and .ics.', 'estat-os' ),
					'reassuring' => true,
					'steps'      => array(
						__( 'Put a property on the website so people have something to enquire about.', 'estat-os' ),
						__( 'Place an enquiry form on that page.', 'estat-os' ),
						__( 'Every message that comes in lands on this screen.', 'estat-os' ),
					),
					'action'     => admin_url( 'admin.php?page=estat-forms' ),
					'label'      => __( 'Set up a form', 'estat-os' ),
					'hint'       => __( 'Nothing is broken — this screen is simply waiting for your first enquiry.', 'estat-os' ),
				)
			);
			return;
		}

		foreach ( $results['items'] as $lead ) {
			self::lead_card( $lead, $agents );
		}

		$links = paginate_links(
			array(
				'total'   => (int) $results['pages'],
				'current' => (int) $results['page'],
				'type'    => 'array',
				'base'    => add_query_arg( 'paged', '%#%' ),
				'format'  => '',
			)
		);
		if ( is_array( $links ) ) {
			echo '<nav class="estat-pagination" aria-label="' . esc_attr__( 'Enquiry pages', 'estat-os' ) . '"><ul>';
			foreach ( $links as $link ) {
				echo '<li>' . wp_kses_post( $link ) . '</li>';
			}
			echo '</ul></nav>';
		}
	}

	private static function lead_card( array $lead, array $agents ): void {
		$lead_id  = (int) $lead['id'];
		$phone    = (string) $lead['phone'];
		$email    = (string) $lead['email'];
		$digits   = preg_replace( '/\D/', '', $phone );
		$listing  = (int) $lead['listing_id'];
		$erased   = (bool) $lead['erased'];
		$events   = LeadEvents::for_lead( $lead_id );
		$event_count = LeadEvents::count( $lead_id );
		$visits   = Visits::query( array( 'lead_id' => $lead_id, 'per_page' => 5 ) );
		?>
		<article class="estat-lead-card estat-ui-panel-card" id="lead-<?php echo esc_attr( (string) $lead_id ); ?>">
			<header class="estat-lead-head" style="display:flex;justify-content:space-between;gap:12px">
				<div>
					<h2 style="margin:0 0 4px 0;font-size:16px"><?php echo esc_html( (string) $lead['name'] ); ?>
						<?php if ( $event_count > 1 ) : ?>
							<span class="estat-ui-chip is-warning"><?php echo esc_html( sprintf( __( '%d enquiries', 'estat-os' ), $event_count ) ); ?></span>
						<?php endif; ?>
						<?php if ( Vocabulary::lead_is_deleted( (string) $lead['status'] ) ) : ?>
							<span class="estat-ui-chip is-danger"><?php esc_html_e( 'Deleted (set aside)', 'estat-os' ); ?></span>
						<?php endif; ?>
					</h2>
					<p class="estat-ui-quiet">
						<?php
						echo esc_html(
							sprintf(
								__( 'Arrived %s ago', 'estat-os' ),
								human_time_diff( (int) strtotime( (string) $lead['created_at'] . ' UTC' ), time() )
							)
						);
						?>
						<?php if ( $listing > 0 ) : ?>
							· <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing ) ); ?>"><?php echo esc_html( (string) get_the_title( $listing ) ); ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $lead['intent'] ) ) : ?> · <?php echo esc_html( Vocabulary::label( 'lead_intents', (string) $lead['intent'] ) ); ?><?php endif; ?>
						<?php if ( ! empty( $lead['locality'] ) ) : ?> · <?php echo esc_html( (string) $lead['locality'] ); ?><?php endif; ?>
						<?php if ( ! empty( $lead['budget_min'] ) ) : ?> · ₹<?php echo esc_html( number_format_i18n( (float) $lead['budget_min'] ) ); ?><?php if ( ! empty( $lead['budget_max'] ) && $lead['budget_max'] != $lead['budget_min'] ) : ?>–<?php echo esc_html( number_format_i18n( (float) $lead['budget_max'] ) ); ?><?php endif; ?><?php endif; ?>
					</p>
					<p class="estat-ui-quiet">
						<?php if ( ! empty( $lead['source'] ) ) : ?><?php echo esc_html( Vocabulary::label( 'lead_sources', (string) $lead['source'] ) ); ?><?php endif; ?>
						<?php if ( ! empty( $lead['source_url'] ) ) : ?> · <a href="<?php echo esc_url( (string) $lead['source_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( parse_url( (string) $lead['source_url'], PHP_URL_HOST ) ?: $lead['source_url'] ); ?></a><?php endif; ?>
						<?php if ( ! empty( $lead['utm_source'] ) ) : ?> · utm: <?php echo esc_html( $lead['utm_source'] . '/' . $lead['utm_medium'] . '/' . $lead['utm_campaign'] ); ?><?php endif; ?>
					</p>
				</div>
				<span class="estat-ui-chip is-info"><?php echo esc_html( Vocabulary::lead_label( (string) $lead['status'] ) ); ?><?php if ( 'lost' === $lead['status'] && ! empty( $lead['lost_reason'] ) ) : ?> (<?php echo esc_html( Vocabulary::label( 'lead_lost_reasons', (string) $lead['lost_reason'] ) ); ?>)<?php endif; ?></span>
			</header>

			<?php if ( ! $erased ) : ?>
				<p class="estat-lead-contact" style="margin:10px 0">
					<?php if ( '' !== $phone ) : ?>
						<a class="button button-small" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( sprintf( __( 'Call %s', 'estat-os' ), $phone ) ); ?></a>
						<?php if ( '' !== (string) $digits ) : ?>
							<a class="button button-small" target="_blank" rel="noopener nofollow" href="https://wa.me/<?php echo esc_attr( (string) $digits ); ?>"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( '' !== $email ) : ?>
						<a class="button button-small" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
					<?php endif; ?>
				</p>
			<?php else : ?>
				<p class="estat-muted"><?php esc_html_e( 'The personal information for this enquiry has been erased.', 'estat-os' ); ?></p>
			<?php endif; ?>

			<?php if ( '' !== (string) $lead['message'] ) : ?>
				<blockquote class="estat-lead-message estat-ui-quote"><?php echo esc_html( (string) $lead['message'] ); ?></blockquote>
			<?php endif; ?>

			<?php if ( $events ) : ?>
				<details style="margin:8px 0"><summary><?php esc_html_e( 'Timeline', 'estat-os' ); ?> (<?php echo esc_html( (string) count( $events ) ); ?>)</summary>
					<ul style="list-style:disc;margin-left:20px;font-size:13px">
						<?php foreach ( $events as $ev ) : ?>
							<li><?php echo esc_html( self::event_line( $ev ) ); ?> <span class="estat-muted">— <?php echo esc_html( (string) $ev['created_at'] ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				</details>
			<?php endif; ?>

			<?php if ( ! empty( $visits['items'] ) ) : ?>
				<div style="margin:8px 0;font-size:13px">
					<strong><?php esc_html_e( 'Visits', 'estat-os' ); ?>:</strong>
					<?php foreach ( $visits['items'] as $v ) : ?>
						<span><?php echo esc_html( (string) $v['scheduled_at'] . ' ' . $v['outcome'] ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries&estat_action=download_ics&visit_id=' . (int) $v['id'] . '&_wpnonce=' . wp_create_nonce( 'estat_download_ics_' . (int) $v['id'] ) ) ); ?>"><?php esc_html_e( 'Add to calendar', 'estat-os' ); ?></a></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<form method="post" class="estat-lead-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>" style="margin-top:12px;display:grid;gap:8px">
				<?php wp_nonce_field( 'estat_update_lead_' . $lead_id, 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="update_lead" />
				<input type="hidden" name="lead_id" value="<?php echo esc_attr( (string) $lead_id ); ?>" />

				<div class="estat-lead-fields" style="display:flex;gap:12px;flex-wrap:wrap">
					<label><span><?php esc_html_e( 'Status', 'estat-os' ); ?></span>
						<select name="status" onchange="if(this.value==='lost'){this.form.querySelector('.estat-lost-reason').style.display='block'}else{this.form.querySelector('.estat-lost-reason').style.display='none'}">
							<?php
							$row_choices = Vocabulary::lead_statuses();
							$row_status  = (string) $lead['status'];
							if ( ! isset( $row_choices[ $row_status ] ) ) {
								$row_choices[ $row_status ] = Vocabulary::lead_label( $row_status );
							}
							foreach ( $row_choices as $value => $label ) :
								?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $lead['status'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="estat-lost-reason" style="<?php echo 'lost' === $lead['status'] ? '' : 'display:none'; ?>">
						<span><?php esc_html_e( 'Lost reason', 'estat-os' ); ?></span>
						<select name="lost_reason">
							<option value=""><?php esc_html_e( 'Select', 'estat-os' ); ?></option>
							<?php foreach ( Vocabulary::lead_lost_reasons() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $lead['lost_reason'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><span><?php esc_html_e( 'Intent', 'estat-os' ); ?></span>
						<select name="intent">
							<option value=""><?php esc_html_e( '—', 'estat-os' ); ?></option>
							<?php foreach ( Vocabulary::lead_intents() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $lead['intent'], $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<?php if ( current_user_can( 'estat_assign_leads' ) ) : ?>
						<label><span><?php esc_html_e( 'Who is handling it', 'estat-os' ); ?></span>
							<select name="agent_id">
								<?php foreach ( $agents as $value => $label ) : ?>
									<option value="<?php echo esc_attr( (string) $value ); ?>" <?php selected( (string) ( $lead['assigned_agent_id'] ?: $lead['agent_id'] ), (string) $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
					<?php endif; ?>
					<label><span><?php esc_html_e( 'Next follow-up', 'estat-os' ); ?></span>
						<input type="datetime-local" name="followup_at" value="<?php echo esc_attr( $lead['followup_at'] ? gmdate( 'Y-m-d\TH:i', (int) strtotime( (string) $lead['followup_at'] . ' UTC' ) ) : '' ); ?>" />
					</label>
				</div>

				<label class="estat-lead-note"><span><?php esc_html_e( 'Add a note', 'estat-os' ); ?></span>
					<textarea name="note" rows="2" placeholder="<?php esc_attr_e( 'For example: called, will visit on Sunday.', 'estat-os' ); ?>" style="width:100%"></textarea>
				</label>

				<?php if ( '' !== (string) $lead['notes'] ) : ?>
					<details class="estat-lead-history"><summary><?php esc_html_e( 'Earlier notes', 'estat-os' ); ?></summary><pre class="estat-ui-pre"><?php echo esc_html( (string) $lead['notes'] ); ?></pre></details>
				<?php endif; ?>

				<div class="estat-lead-actions"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'estat-os' ); ?></button></div>
			</form>

			<?php if ( current_user_can( 'estat_manage_visits' ) ) : ?>
				<form method="post" class="estat-visit-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>" style="margin-top:12px;display:flex;gap:8px;align-items:end;flex-wrap:wrap">
					<?php wp_nonce_field( 'estat_schedule_visit_' . $lead_id, 'estat_nonce' ); ?>
					<input type="hidden" name="estat_action" value="schedule_visit" />
					<input type="hidden" name="lead_id" value="<?php echo esc_attr( (string) $lead_id ); ?>" />
					<input type="hidden" name="listing_id" value="<?php echo esc_attr( (string) $listing ); ?>" />
					<label><span><?php esc_html_e( 'Book a site visit', 'estat-os' ); ?></span><input type="datetime-local" name="scheduled_at" required /></label>
					<button type="submit" class="button"><?php esc_html_e( 'Add visit (+ .ics)', 'estat-os' ); ?></button>
				</form>
			<?php endif; ?>

			<?php if ( current_user_can( 'estat_erase_leads' ) && ! $erased ) : ?>
				<form method="post" class="estat-erase-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'This permanently erases the name, phone and email. The record of the enquiry stays. Continue?', 'estat-os' ) ); ?>');" style="margin-top:8px">
					<?php wp_nonce_field( 'estat_erase_lead_' . $lead_id, 'estat_nonce' ); ?>
					<input type="hidden" name="estat_action" value="erase_lead" />
					<input type="hidden" name="lead_id" value="<?php echo esc_attr( (string) $lead_id ); ?>" />
					<button type="submit" class="button-link estat-danger-link"><?php esc_html_e( 'Erase personal information', 'estat-os' ); ?></button>
				</form>
			<?php endif; ?>
		</article>
		<?php
	}

	private static function agent_options(): array {
		$agents = Picker::options( PostTypes::AGENT, __( 'Nobody yet', 'estat-os' ) );
		return $agents['options'];
	}
}
