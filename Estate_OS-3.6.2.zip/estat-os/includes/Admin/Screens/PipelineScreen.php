<?php
/**
 * Pipeline — Kanban for the office: New → Contacted → Scheduled → Won / Lost
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Leads\Leads;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class PipelineScreen {

	/**
	 * Render screen.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			wp_die( esc_html__( 'You do not have permission to see the pipeline.', 'estat-os' ) );
		}

		$order = Vocabulary::lead_pipeline_order();
		$labels = Vocabulary::lead_statuses();

		echo '<div class="estat-pipeline-intro">';
		echo '<h1>' . esc_html__( 'Pipeline', 'estat-os' ) . '</h1>';
		echo '<p class="estat-muted">' . esc_html__( 'Drag cards between columns. Each column is a stage: New → Contacted → Scheduled → Won / Lost. Notes and visit booking stay on the card.', 'estat-os' ) . '</p>';
		echo '</div>';

		echo '<div class="estat-pipeline" style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;margin-top:20px">';

		foreach ( $order as $status ) {
			$results = Leads::query( array( 'status' => $status, 'per_page' => 50, 'page' => 1 ) );
			$label = $labels[ $status ] ?? $status;

			echo '<div class="estat-pipeline-col" data-status="' . esc_attr( $status ) . '" style="background:var(--estat-card);border:1px solid var(--estat-line);border-radius:12px;padding:12px;min-height:400px">';
			echo '<h3 style="margin:0 0 12px;font-size:14px;text-transform:uppercase;letter-spacing:.5px">' . esc_html( $label ) . ' <span style="background:var(--estat-sunken);padding:2px 8px;border-radius:999px;font-size:12px">' . (int) $results['total'] . '</span></h3>';

			if ( ! $results['items'] ) {
				echo '<p class="estat-muted" style="font-size:13px">' . esc_html__( 'Nothing here yet.', 'estat-os' ) . '</p>';
			} else {
				foreach ( $results['items'] as $lead ) {
					$phone = (string) $lead['phone'];
					echo '<article class="estat-pipeline-card" data-lead="' . (int) $lead['id'] . '" draggable="true" style="border:1px solid var(--estat-line);border-radius:8px;padding:10px;margin-bottom:10px;background:var(--estat-bg);cursor:grab">';
					echo '<strong>' . esc_html( (string) $lead['name'] ) . '</strong>';
					if ( '' !== $phone ) {
						echo '<div style="font-size:12px;margin-top:4px"><a href="tel:' . esc_attr( $phone ) . '">' . esc_html( $phone ) . '</a></div>';
					}
					if ( '' !== (string) $lead['message'] ) {
						echo '<div style="font-size:12px;margin-top:6px;color:var(--estat-muted)">' . esc_html( mb_substr( (string) $lead['message'], 0, 80 ) ) . '</div>';
					}
					$listing = (int) $lead['listing_id'];
					if ( $listing ) {
						echo '<div style="font-size:11px;margin-top:6px"><a href="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing ) ) . '">' . esc_html( get_the_title( $listing ) ?: 'Listing #' . $listing ) . '</a></div>';
					}
					echo '<div style="margin-top:8px;display:flex;gap:6px">';
					echo '<a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=estat-enquiries#lead-' . $lead['id'] ) ) . '">' . esc_html__( 'Open', 'estat-os' ) . '</a>';
					echo '</div>';
					echo '</article>';
				}
			}
			echo '</div>';
		}
		echo '</div>';

		// How many enquiries were set aside, for the quiet line at the bottom.
		$deleted = (int) Leads::query( array( 'status' => 'spam', 'per_page' => 1, 'page' => 1 ) )['total'];

		if ( $deleted > 0 ) {
			echo '<p class="estat-muted" style="margin-top:16px">';
			echo esc_html(
				sprintf(
					/* translators: %s: number of set-aside enquiries. */
					_n( '%s enquiry was set aside.', '%s enquiries were set aside.', $deleted, 'estat-os' ),
					number_format_i18n( $deleted )
				)
			);
			echo ' <a href="' . esc_url( admin_url( 'admin.php?page=estat-enquiries&status=spam' ) ) . '">' . esc_html__( 'See them in Enquiries', 'estat-os' ) . '</a>';
			echo '</p>';
		}

		// Inline JS for drag-drop (minimal, no external dep).
		?>
		<script>
		document.addEventListener('DOMContentLoaded', function(){
			const cols = document.querySelectorAll('.estat-pipeline-col');
			let dragged = null;
			document.querySelectorAll('.estat-pipeline-card').forEach(card=>{
				card.addEventListener('dragstart', e=>{ dragged=card; e.dataTransfer.effectAllowed='move'; });
				card.addEventListener('dragend', ()=>{ dragged=null; });
			});
			cols.forEach(col=>{
				col.addEventListener('dragover', e=>{ e.preventDefault(); col.style.outline='2px dashed var(--estat-accent)'; });
				col.addEventListener('dragleave', ()=>{ col.style.outline=''; });
				col.addEventListener('drop', e=>{
					e.preventDefault(); col.style.outline='';
					if(!dragged) return;
					const newStatus = col.getAttribute('data-status');
					const leadId = dragged.getAttribute('data-lead');
					// Optimistic move.
					col.appendChild(dragged);
					// AJAX update.
					fetch(estatAdmin.ajaxUrl, {
						method:'POST',
						headers:{'Content-Type':'application/x-www-form-urlencoded'},
						body: new URLSearchParams({
							action:'estat_move_pipeline',
							lead_id: leadId,
							status: newStatus,
							_ajax_nonce: estatAdmin.nonce
						})
					}).then(r=>r.json()).then(j=>{
						if(!j.success){ alert(j.data?.message || 'Could not move'); location.reload(); }
					});
				});
			});
		});
		</script>
		<style>
		.estat-pipeline-col.drag-over{ outline:2px dashed var(--estat-accent); }
		</style>
		<?php
	}
}
