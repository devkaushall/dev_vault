<?php
/**
 * Listings — the office the office Atelier redesign.
 * Real data only.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Agents;
use EstatOS\Data\Bin;
use EstatOS\Data\Health;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class ListingsNew {

	/**
	 * How many properties fit on one page. Kept in one place so the number in
	 * the footer can never disagree with the query.
	 */
	private const PER_PAGE = 20;

	/**
	 * Three separate things were being called "status". They are now shown
	 * separately and named for what they actually mean:
	 *
	 *   Website      — is it published? (WordPress post status)
	 *   Availability — is it still for sale? (the office's own answer)
	 *   (freshness)  — shown as a tag on the website, not here.
	 *
	 * @param string $status WordPress post status.
	 * @return string
	 */
	private static function website_label( string $status ): string {
		return Partials::record_status_label( $status );
	}

	/**
	 * The price written the way the office reads it — "₹75,000 per month",
	 * not "75000". The website already builds this line for every card; the
	 * office screens were reading a stored field that nothing ever writes, so
	 * they fell back to the raw number.
	 *
	 * @param int $id Listing id.
	 * @return string
	 */
	private static function price_line( int $id ): string {
		$data  = Listings::to_array( $id );
		$price = (string) ( $data['price_display'] ?? '' );

		if ( '' === $price ) {
			return '';
		}

		$offer = (string) ( $data['offer'] ?? '' );
		if ( in_array( $offer, array( 'rent', 'lease' ), true ) && false === strpos( $price, __( 'per month', 'estat-os' ) ) ) {
			$price .= ' ' . __( 'per month', 'estat-os' );
		}

		return $price;
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see listings.', 'estat-os' ) );
		}


		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		// Editing a property opens the full editor. Without this the pencil icon
		// reloaded the same table and no property could be edited at all.
		$edit_id = isset( $_GET['edit'] ) ? absint( wp_unslash( is_array($_GET['edit']) ? '' : $_GET['edit'] ) ) : 0;
		if ( $edit_id > 0 ) {
			ListingsScreen::editor( $edit_id );
			return;
		}
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( is_array($_GET['status']) ? '' : $_GET['status'] ) ) : 'any';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array($_GET['s']) ? '' : $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		// phpcs:enable

		$counts = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $counts['publish'] ?? 0 );
		$draft = (int) ( $counts['draft'] ?? 0 );
		$pending = (int) ( $counts['pending'] ?? 0 );
		$private = (int) ( $counts['private'] ?? 0 );
		$total = $live + $draft + $pending + $private;

		// The bin is its own place, counted on its own line, and never part
		// of the working totals: a property in the bin is not inventory.
		$in_bin = Bin::count();

		/*
		 * "Needs attention" is the same list the Today screen already works
		 * from — photos missing, price missing, a term nobody meant to type.
		 * It is a filter over the working list, not a separate screen, so
		 * whoever is fixing them never loses sight of the rest.
		 */
		$attention_rows = Health::attention( 300 );
		$attention      = array();
		foreach ( $attention_rows as $row ) {
			if ( ! empty( $row['id'] ) ) {
				$attention[] = (int) $row['id'];
			}
		}
		if ( $status === 'attention' && ! $attention ) {
			$attention = array( 0 ); // An empty post__in would mean "all".
		}
		$attention_count   = count( $attention );
		$attention_missing = $status !== 'attention' && ! $attention_count;

		$query_args = array(
			'post_type'      => PostTypes::LISTING,
			'post_status'    => in_array( $status, array( 'publish', 'draft', 'pending', 'private' ), true ) ? $status : array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => self::PER_PAGE,
			'paged'          => $paged,
			's'              => $search,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		);
		if ( 'attention' === $status ) {
			$query_args['post__in'] = $attention;
		}

		$query = new \WP_Query( $query_args );

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );
		$ref_prefix = (string) ( $s['ref_prefix'] ?? '' );
		$ref = ( '' !== $ref_prefix ) ? $ref_prefix . '-' : '';

		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<span><?php esc_html_e( 'Office', 'estat-os' ); ?></span>
					<span>/</span>
					<span><?php esc_html_e( 'Listings', 'estat-os' ); ?></span>
					<span>/</span>
					<span class="is-muted"><?php esc_html_e( 'All properties', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php esc_html_e( 'Listings', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php esc_html_e( 'Every property your office is handling — on the website, in draft, and kept off the market.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=estat-spreadsheet&estat_action=export_csv&what=listings' ), 'estat_export_csv', 'estat_nonce' ) ); ?>" class="estat-ui-btn"><?php echo \EstatOS\Support\Icon::render( 'download', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Export properties', 'estat-os' ); ?></a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>" class="estat-ui-btn-primary"><?php echo \EstatOS\Support\Icon::render( 'plus', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Add a home', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-ui-metrics is-5">
				<div class="estat-ui-metric"><span class="estat-ui-metric-label"><?php esc_html_e( 'Total properties', 'estat-os' ); ?></span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $total ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Everything you handle', 'estat-os' ); ?></span></div></div>
				<div class="estat-ui-metric"><span class="estat-ui-metric-label"><?php esc_html_e( 'On the website', 'estat-os' ); ?></span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $live ); ?></span><span class="estat-ui-badge"><?php esc_html_e( 'Visible to visitors', 'estat-os' ); ?></span></div></div>
				<div class="estat-ui-metric"><span class="estat-ui-metric-label"><?php esc_html_e( 'Waiting for approval', 'estat-os' ); ?></span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $pending ); ?></span><span class="estat-ui-metric-sub"><?php echo esc_html( $total > 0 ? sprintf( __( '%s of all properties', 'estat-os' ), round( $pending/$total*100, 1 ) . '%' ) : __( 'None at the moment', 'estat-os' ) ); ?></span></div></div>
				<div class="estat-ui-metric"><span class="estat-ui-metric-label"><?php esc_html_e( 'Paused', 'estat-os' ); ?></span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $private ); ?></span><span class="estat-ui-badge is-muted"><?php esc_html_e( 'Hidden from the website', 'estat-os' ); ?></span></div></div>
				<div class="estat-ui-metric"><span class="estat-ui-metric-label"><?php esc_html_e( 'Drafts', 'estat-os' ); ?></span><div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $draft ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Not finished yet', 'estat-os' ); ?></span></div></div>
			</div>

			<?php
			/*
			 * Drafts waiting on the website used to have a form of their own
			 * here. It ran a second, older way of changing many records at
			 * once, next to the tick boxes and the bar below — so "put all
			 * drafts live" could mean two slightly different things
			 * depending on which one was pressed. There is one way now: tick
			 * the rows, pick Live, and everything is checked, said out loud
			 * and recorded in the same place. This note only points at it.
			 */
			if ( $draft > 0 && current_user_can( 'estat_publish_listings' ) ) :
				?>
				<div class="estat-ui-note estat-ui-publish-all">
					<span>
						<?php
						printf(
							/* translators: %s: number of draft properties. */
							esc_html( _n( '%s draft is not on the website yet — tick it in the list and pick Live.', '%s drafts are not on the website yet — tick them in the list and pick Live.', $draft, 'estat-os' ) ),
							esc_html( number_format_i18n( $draft ) )
						);
						?>
					</span>
					<a class="estat-ui-btn" href="<?php echo esc_url( add_query_arg( array( 'page' => 'estat-listings', 'status' => 'draft' ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Show the drafts', 'estat-os' ); ?></a>
				</div>
			<?php endif; ?>

			<div class="estat-ui-controls">
				<div class="estat-ui-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-ui-search">
						<input type="hidden" name="page" value="estat-listings" />
						<?php echo \EstatOS\Support\Icon::render( 'search', 18, 'estat-ms' ); ?>
						<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search address, street, reference code...', 'estat-os' ); ?>" />
					</form>
					<div class="estat-ui-view-toggle">
						<button type="button" class="is-active" id="estat-view-list"><?php echo \EstatOS\Support\Icon::render( 'list', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Table', 'estat-os' ); ?></button>
						<button type="button" id="estat-view-grid"><?php echo \EstatOS\Support\Icon::render( 'columns', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Cards', 'estat-os' ); ?></button>
					</div>
				</div>
				<div class="estat-ui-filters estat-ui-ia">
					<?php
					/*
					 * The list in one line: everything, what needs fixing,
					 * then each state a property can be in — and the bin,
					 * set apart from the rest, because it is not a state of
					 * the property at all.
					 */
					$chips = array(
						'any'       => array( __( 'All', 'estat-os' ), $total ),
						'attention' => array( __( 'Needs attention', 'estat-os' ), $attention_count ),
						'publish'   => array( __( 'Live', 'estat-os' ), $live ),
						'draft'     => array( __( 'Drafts', 'estat-os' ), $draft ),
						'pending'   => array( __( 'Waiting for approval', 'estat-os' ), $pending ),
						'private'   => array( __( 'Paused', 'estat-os' ), $private ),
					);
					foreach ( $chips as $key => $chip ) :
						?>
						<a class="estat-ui-chip<?php echo $status === $key ? ' is-active' : ''; ?>"
							href="<?php echo esc_url( add_query_arg( array( 'page' => 'estat-listings', 'status' => $key, 's' => $search ), admin_url( 'admin.php' ) ) ); ?>">
							<?php echo esc_html( $chip[0] ); ?>
							<span class="estat-ui-chip-count"><?php echo esc_html( number_format_i18n( (int) $chip[1] ) ); ?></span>
						</a>
					<?php endforeach; ?>

					<a class="estat-ui-chip estat-ui-chip-bin" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-bin' ) ); ?>">
						<?php echo \EstatOS\Support\Icon::render( 'bin', 16, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Bin', 'estat-os' ); ?>
						<span class="estat-ui-chip-count"><?php echo esc_html( number_format_i18n( $in_bin ) ); ?></span>
					</a>
				</div>
			</div>

			<?php
			/*
			 * Everything that acts on more than one property at a time goes
			 * through this one form: the ticks, the bar, and the record of
			 * which records were asked for. One press, one request — the
			 * office never watches twelve page loads happen one by one.
			 */
			Partials::bulk_open(
				'estat-listings',
				array(
					'word'     => __( 'properties', 'estat-os' ),
					'word_one' => __( 'property', 'estat-os' ),
					'mode'  => 'active',
					'nonce' => 'estat_bulk_records',
					'action' => 'bin_records',
				)
			);
			?>

			<div class="estat-ui-table-wrap" id="estat-ledger-table">
				<div class="estat-ui-table-scroll">
					<table class="estat-ui-table estat-table-cards">
						<thead>
							<tr>
								<?php Partials::bulk_header(); ?>
								<th><?php esc_html_e( 'Property', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Specs & Layout', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Price', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Locality', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Website', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Availability', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Freshness', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Agent', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Updated', 'estat-os' ); ?></th>
								<th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! $query->have_posts() ) : ?>
								<tr><td colspan="11" class="estat-ui-empty"><?php esc_html_e( 'No properties found.', 'estat-os' ); ?></td></tr>
							<?php else : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $price = get_post_meta( $id, '_estat_price', true ); $price_display = self::price_line( $id ); $area = get_post_meta( $id, '_estat_area', true ); $beds = get_post_meta( $id, '_estat_bedrooms', true ); $baths = get_post_meta( $id, '_estat_bathrooms', true ); $type = get_post_meta( $id, '_estat_property_type', true ); $agent_id = (int) get_post_meta( $id, '_estat_agent_id', true ); $agent = $agent_id ? Agents::to_array( $agent_id ) : null; $locality_terms = get_the_terms( $id, 'estat_locality' ); $locality_name = $locality_terms && ! is_wp_error( $locality_terms ) && ! empty( $locality_terms[0]->name ) ? $locality_terms[0]->name : ''; $offer = (string) get_post_meta( $id, '_estat_offer', true ); $status = get_post_status( $id ); $availability = (string) get_post_meta( $id, '_estat_availability', true ); $freshness = (string) get_post_meta( $id, '_estat_freshness', true ); ?>
							<tr>
								<?php Partials::bulk_cell( (int) $id, (string) get_the_title() ); ?>
								<td data-label="<?php esc_attr_e( 'Property', 'estat-os' ); ?>">
									<div class="estat-ui-member">
										<div class="estat-ui-avatar is-property"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(48,48), array('class'=>'estat-ui-avatar-img') ) : \EstatOS\Support\Icon::render( 'buildings', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built in Support\Icon. ?></div>
										<div class="estat-ui-member-info">
											<span class="estat-ui-member-name"><?php echo esc_html( get_the_title() ); ?></span>
											<span class="estat-ui-member-meta"><span class="estat-ui-ref"><?php echo esc_html( sprintf( __( 'Ref: %s', 'estat-os' ), $ref . $id ) ); ?></span><?php if ( $type ) : ?><span class="estat-ui-dot"></span> <?php echo esc_html( Vocabulary::label( 'property_types', $type ) ); ?><?php endif; ?></span>
										</div>
									</div>
								</td>
								<td data-label="<?php esc_attr_e( 'Layout', 'estat-os' ); ?>"><div class="estat-ui-specs"><span class="is-type"><?php echo esc_html( '' !== $type ? Vocabulary::label( 'property_types', $type ) : __( 'Property', 'estat-os' ) ); ?></span><span class="is-meta"><?php echo esc_html( trim( ( $area ? \EstatOS\Support\Format::area( (float) $area, (string) ( $s['default_area_unit'] ?? 'sqft' ) ) . ' • ' : '' ) . ( $beds ? sprintf( /* translators: %d: number of bedrooms. */ _n( '%d Bed', '%d Beds', (int) $beds, 'estat-os' ), (int) $beds ) . ', ' : '' ) . ( $baths ? sprintf( /* translators: %d: number of bathrooms. */ _n( '%d Bath', '%d Baths', (int) $baths, 'estat-os' ), (int) $baths ) : '' ), ' • ' ) ?: '—' ); ?></span></div></td>
								<td data-label="<?php esc_attr_e( 'Price', 'estat-os' ); ?>"><div class="estat-ui-price"><span class="is-price"><?php echo esc_html( $price_display ? (string) $price_display : '—' ); ?></span><span class="is-sub"><?php echo esc_html( '' !== $offer ? Vocabulary::label( 'offers', $offer ) : '' ); ?></span></div></td>
								<td data-label="<?php esc_attr_e( 'Locality', 'estat-os' ); ?>"><div class="estat-ui-locality"><span><?php echo esc_html( $locality_name ?: $city ); ?></span></div></td>
								<td data-label="<?php esc_attr_e( 'Website', 'estat-os' ); ?>"><span class="estat-ui-status is-<?php echo esc_attr( $status ); ?>"><span class="estat-ui-dot"></span> <?php echo esc_html( self::website_label( (string) $status ) ); ?></span></td>
								<td data-label="<?php esc_attr_e( 'Availability', 'estat-os' ); ?>"><?php echo esc_html( '' !== $availability ? Vocabulary::label( 'availability', $availability ) : '—' ); ?></td>
								<td data-label="<?php esc_attr_e( 'Freshness', 'estat-os' ); ?>"><?php echo esc_html( '' !== $freshness ? Vocabulary::label( 'freshness', $freshness ) : '—' ); ?></td>
								<td data-label="<?php esc_attr_e( 'Agent', 'estat-os' ); ?>"><?php echo esc_html( $agent['name'] ?? __( 'Unassigned', 'estat-os' ) ); ?></td>
								<td class="estat-ui-date" data-label="<?php esc_attr_e( 'Updated', 'estat-os' ); ?>"><?php echo esc_html( get_the_modified_date( 'M j, Y' ) ); ?></td>
								<td class="text-right" data-label="<?php esc_attr_e( 'Actions', 'estat-os' ); ?>"><div class="estat-ui-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'Edit this property', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'pencil', 18, 'estat-ms' ); ?></a><a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'View on website', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'eye', 18, 'estat-ms' ); ?></a><?php Partials::move_to_bin_button( (int) $id, 'estat-listings' ); ?></div></td>
							</tr>
							<?php endwhile; wp_reset_postdata(); endif; ?>
						</tbody>
					</table>
				</div>
				<div class="estat-ui-pagination">
					<span><?php echo esc_html( sprintf( __( 'Showing %1$d to %2$d of %3$d properties', 'estat-os' ), ( $paged-1)*self::PER_PAGE+1, min( $paged*self::PER_PAGE, $query->found_posts ), $query->found_posts ) ); ?> • <?php echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'estat-os' ), $paged, max(1, (int) $query->max_num_pages) ) ); ?></span>
					<div class="estat-ui-pager"><?php echo paginate_links( array( 'base'=>add_query_arg('paged','%#%'), 'format'=>'', 'current'=>$paged, 'total'=>max(1,(int)$query->max_num_pages), 'prev_text'=>\EstatOS\Support\Icon::render( 'chevron-left', 18, 'estat-ms' ).' '.__( 'Previous', 'estat-os' ),
							'next_text'=>__('Next', 'estat-os' ).' '.\EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ),
						) ); ?>
				</div>
			</div>

			<div class="estat-ui-cards hidden" id="estat-cards-grid">
				<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $price_display = self::price_line( $id ); $card_type = (string) get_post_meta( $id, '_estat_property_type', true ); ?>
				<div class="estat-ui-card">
					<div class="estat-ui-card-media"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, 'medium_large' ) : ''; ?><span class="estat-ui-card-price"><?php echo esc_html( $price_display ? (string) $price_display : '' ); ?></span><span class="estat-ui-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><span class="estat-ui-dot"></span> <?php echo esc_html( self::website_label( (string) get_post_status( $id ) ) ); ?></span></div>
					<div class="estat-ui-card-body"><div class="estat-ui-card-meta"><span><?php echo esc_html( $ref . $id ); ?></span><span><?php echo esc_html( $city ); ?></span></div><h3 class="estat-ui-card-name"><?php echo esc_html( get_the_title() ); ?></h3></div>
					<div class="estat-ui-card-foot"><span><?php echo esc_html( $card_type ? Vocabulary::label( 'property_types', $card_type ) : '' ); ?></span><div class="estat-ui-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>" class="estat-ui-icon-btn"><?php echo \EstatOS\Support\Icon::render( 'pencil', 18, 'estat-ms' ); ?></a></div></div>
				</div>
				<?php endwhile; wp_reset_postdata(); endif; ?>
			</div>

			<?php Partials::bulk_close(); ?>

			<div class="estat-ui-footer"><span><?php echo \EstatOS\Support\Icon::render( 'verified', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Records kept by your office.', 'estat-os' ); ?></span><span><?php echo esc_html( sprintf( /* translators: %s: number of properties. */ _n( '%s property shown', '%s properties shown', (int) $query->post_count, 'estat-os' ), number_format_i18n( (int) $query->post_count ) ) ); ?></span></div>
		</div>

		<script>
		(function(){
			var listBtn=document.getElementById('estat-view-list');
			var gridBtn=document.getElementById('estat-view-grid');
			var table=document.getElementById('estat-ledger-table');
			var grid=document.getElementById('estat-cards-grid');
			if(listBtn&&gridBtn&&table&&grid){
				listBtn.addEventListener('click',function(){table.classList.remove('hidden');grid.classList.add('hidden');listBtn.classList.add('is-active');gridBtn.classList.remove('is-active');});
				gridBtn.addEventListener('click',function(){grid.classList.remove('hidden');table.classList.add('hidden');gridBtn.classList.add('is-active');listBtn.classList.remove('is-active');});
			}

		})();
		</script>
		<?php
	}
}
