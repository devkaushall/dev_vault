<?php
/**
 * Team — the office the office redesign — UI/UX only.
 * Preserves all backend logic: Agents::save, listing_count, for_user, on_delete, to_array, permissions, photo handling, user linking.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Agents;
use EstatOS\Data\PostTypes;
use EstatOS\Pocket\Pocket;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

	final class TeamNew {

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_team' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the team.', 'estat-os' ) );
		}

		// the office design system fonts — same as reference
		wp_enqueue_media();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$edit_id = isset( $_GET['edit'] ) ? absint( wp_unslash( is_array( $_GET['edit'] ) ? '' : $_GET['edit'] ) ) : -1;
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( is_array( $_GET['s'] ) ? '' : $_GET['s'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array( $_GET['paged'] ) ? '' : $_GET['paged'] ) ) ) : 1;
		$role_filter = isset( $_GET['role'] ) ? sanitize_text_field( wp_unslash( is_array( $_GET['role'] ) ? '' : $_GET['role'] ) ) : '';
		$qr_id  = isset( $_GET['qr'] ) ? absint( wp_unslash( is_array( $_GET['qr'] ) ? '' : $_GET['qr'] ) ) : -1;
		// phpcs:enable

		$s = Settings::all();
		$city = (string) ( $s['city'] ?? $s['cities'][0] ?? '' );

		// QR screen — one member's codes, ready to print.
		if ( $qr_id >= 0 && $edit_id < 0 ) {
			self::render_qr( $qr_id );
			return;
		}

		// Edit mode — show form, preserve all original fields
		if ( $edit_id >= 0 ) {
			self::render_form( $edit_id );
			return;
		}

		$args = array(
			'post_type'      => PostTypes::AGENT,
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 25,
			'paged'          => $paged,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		if ( '' !== $role_filter ) {
			$args['meta_query'] = array(
				array( 'key'=>'_estat_role', 'value'=>$role_filter, 'compare'=>'LIKE' ),
			);
		}
		$query = new \WP_Query( $args );
		$total = (int) $query->found_posts;

		// Metrics — real counts only
		$all_agents = get_posts( array( 'post_type'=>PostTypes::AGENT, 'post_status'=>array('publish','draft'), 'numberposts'=>-1, 'fields'=>'ids' ) );
		$active = 0; $with_login = 0; $total_listings = 0;
		$roles = array();
		foreach ( $all_agents as $aid ) {
			if ( 'publish' === get_post_status( $aid ) ) { $active++; }
			if ( get_post_meta( $aid, '_estat_user_id', true ) ) { $with_login++; }
			$total_listings += Agents::listing_count( (int) $aid );
			$r = (string) get_post_meta( $aid, '_estat_role', true );
			if ( '' !== $r ) { $roles[ $r ] = true; }
		}

		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<span><?php esc_html_e( 'Office', 'estat-os' ); ?></span>
					<?php echo \EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ); ?>
					<span><?php esc_html_e( 'Team', 'estat-os' ); ?></span>
					<span>/</span>
					<span class="is-muted"><?php esc_html_e( 'Team', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php esc_html_e( 'Team', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php esc_html_e( 'Your colleagues, who handles what, and who can sign in.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=0' ) ); ?>" class="estat-ui-btn-primary"><?php echo \EstatOS\Support\Icon::render( 'plus', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Add team member', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-ui-subnav" style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px 0">
				<?php $sub = array('estat-team'=>__( 'Team', 'estat-os' ),'estat-reports'=>__( 'Reports', 'estat-os' ),'estat-insights'=>__( 'Insights', 'estat-os' )); foreach ( $sub as $slug=>$label ) { $is_active = 'estat-team' === $slug; $url = admin_url( 'admin.php?page=' . $slug ); echo '<a href="' . esc_url( $url ) . '" class="estat-ui-btn' . ( $is_active ? ' is-active' : '' ) . '" style="' . ( $is_active ? 'background:var(--estat-ink);color:var(--estat-panel);border-color:var(--estat-ink)' : '' ) . '">' . esc_html( $label ) . '</a>'; } ?>
			</div>

			<!-- Metrics Strip -->
			<div class="estat-ui-metrics">
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Total members', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) count( $all_agents ) ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Full register', 'estat-os' ); ?></span></div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Active', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $active ); ?></span><span class="estat-ui-badge"><?php esc_html_e( 'On website', 'estat-os' ); ?></span></div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'With login', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $with_login ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Pocket access', 'estat-os' ); ?></span></div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Properties handled', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num is-accent"><?php echo esc_html( (string) $total_listings ); ?></span><?php echo \EstatOS\Support\Icon::render( 'trend-up', 18, 'estat-ms' ); ?></div>
				</div>
			</div>

			<!-- Search & Filter Controls -->
			<div class="estat-ui-controls">
				<div class="estat-ui-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-ui-search">
						<input type="hidden" name="page" value="estat-team" />
						<?php echo \EstatOS\Support\Icon::render( 'search', 18, 'estat-ms' ); ?>
						<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search by name, role, phone, email...', 'estat-os' ); ?>" />
						<?php if ( '' !== $role_filter ) : ?><input type="hidden" name="role" value="<?php echo esc_attr( $role_filter ); ?>" /><?php endif; ?>
					</form>
					<div class="estat-ui-view-toggle">
						<button type="button" class="is-active" id="estat-view-list"><?php echo \EstatOS\Support\Icon::render( 'list', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Table', 'estat-os' ); ?></button>
						<button type="button" id="estat-view-grid"><?php echo \EstatOS\Support\Icon::render( 'columns', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Cards', 'estat-os' ); ?></button>
					</div>
				</div>
				<div class="estat-ui-filters">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-ui-filters-form">
						<input type="hidden" name="page" value="estat-team" />
						<?php if ( '' !== $search ) : ?><input type="hidden" name="s" value="<?php echo esc_attr( $search ); ?>" /><?php endif; ?>
						<select name="role">
							<option value=""><?php esc_html_e( 'All roles', 'estat-os' ); ?></option>
							<?php foreach ( array_keys( $roles ) as $r ) : ?>
							<option value="<?php echo esc_attr( $r ); ?>" <?php selected( $role_filter, $r ); ?>><?php echo esc_html( $r ); ?></option>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="estat-ui-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>" class="estat-ui-link"><?php echo \EstatOS\Support\Icon::render( 'refresh', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Reset', 'estat-os' ); ?></a>
					</form>
				</div>
			</div>

			<!-- Ledger Table -->
			<div class="estat-ui-table-wrap" id="estat-ledger-table">
				<div class="estat-ui-table-scroll">
					<table class="estat-ui-table estat-table-cards">
						<thead>
							<tr>
								<th class="w-10"><input type="checkbox" id="estat-select-all" /></th>
								<th><?php esc_html_e( 'Member', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Contact', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Listings', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Login', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Status', 'estat-os' ); ?></th>
								<th><?php esc_html_e( 'Updated', 'estat-os' ); ?></th>
								<th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! $query->have_posts() ) : ?>
								<tr><td colspan="8" class="estat-ui-empty"><?php esc_html_e( 'No team members found.', 'estat-os' ); ?></td></tr>
							<?php else : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $agent = Agents::to_array( $id ); $role = get_post_meta( $id, '_estat_role', true ); $phone = get_post_meta( $id, '_estat_phone', true ); $email = get_post_meta( $id, '_estat_email', true ); $whatsapp = get_post_meta( $id, '_estat_whatsapp', true ); $user_id = (int) get_post_meta( $id, '_estat_user_id', true ); $user = $user_id ? get_userdata( $user_id ) : null; $status = get_post_status( $id ); ?>
							<tr>
								<td><input type="checkbox" class="estat-row-check" value="<?php echo esc_attr( (string) $id ); ?>" /></td>
								<td>
									<div class="estat-ui-member">
										<div class="estat-ui-avatar"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(48,48), array('class'=>'estat-ui-avatar-img') ) : '<span class="estat-ui-avatar-fallback">' . esc_html( mb_substr( get_the_title(), 0, 1 ) ) . '</span>'; ?></div>
										<div class="estat-ui-member-info">
											<span class="estat-ui-member-name"><?php echo esc_html( get_the_title() ); ?></span>
											<span class="estat-ui-member-meta"><span class="estat-ui-ref">Ref: #<?php echo esc_html( (string) $id ); ?></span><?php if ( $role ) : ?> <span class="estat-ui-dot"></span> <?php echo esc_html( $role ); ?><?php endif; ?></span>
										</div>
									</div>
								</td>
								<td>
									<div class="estat-ui-contact">
										<?php if ( $phone ) : ?><span><?php echo \EstatOS\Support\Icon::render( 'phone', 18, 'estat-ms' ); ?> <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone ); ?></a></span><?php endif; ?>
										<?php if ( $email ) : ?><span><?php echo \EstatOS\Support\Icon::render( 'envelope', 18, 'estat-ms' ); ?> <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></span><?php endif; ?>
										<?php if ( $whatsapp && $whatsapp !== $phone ) : ?><span class="is-whatsapp"><?php echo \EstatOS\Support\Icon::render( 'whatsapp', 18, 'estat-ms' ); ?> <?php echo esc_html( $whatsapp ); ?></span><?php endif; ?>
									</div>
								</td>
								<td><span class="estat-ui-num"><?php echo esc_html( (string) $agent['listings'] ); ?></span></td>
								<td><?php if ( $user ) : ?><span class="estat-ui-login"><?php echo esc_html( $user->display_name ); ?></span><?php else : ?><span class="estat-ui-muted"><?php esc_html_e( 'No login', 'estat-os' ); ?></span><?php endif; ?></td>
								<td><span class="estat-ui-status is-<?php echo esc_attr( $status ); ?>"><span class="estat-ui-dot"></span> <?php echo esc_html( Partials::record_status_label( (string) $status ) ); ?></span></td>
								<td class="estat-ui-date"><?php echo esc_html( get_the_modified_date( 'M j, Y' ) ); ?></td>
								<td class="text-right">
									<div class="estat-ui-actions">
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&qr=' . $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'QR code', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'qr-code', 18, 'estat-ms' ); ?></a>
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=' . $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'Edit', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'pencil', 18, 'estat-ms' ); ?></a>
										<a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'View', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'eye', 18, 'estat-ms' ); ?></a>
																			</div>
								</td>
							</tr>
							<?php endwhile; wp_reset_postdata(); endif; ?>
						</tbody>
					</table>
				</div>
				<div class="estat-ui-pagination">
					<span><?php echo esc_html( sprintf( __( 'Showing %1$d to %2$d of %3$d members', 'estat-os' ), ( $paged-1)*25+1, min( $paged*25, $total ), $total ) ); ?> • <?php echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'estat-os' ), $paged, max(1, (int) $query->max_num_pages) ) ); ?></span>
					<div class="estat-ui-pager">
						<?php
						echo paginate_links( array(
							'base'=>add_query_arg( 'paged', '%#%' ),
							'format'=>'',
							'current'=>$paged,
							'total'=>max(1, (int) $query->max_num_pages),
							'prev_text'=>\EstatOS\Support\Icon::render( 'chevron-left', 18, 'estat-ms' ).' '.__( 'Previous', 'estat-os' ),
							'next_text'=>__('Next', 'estat-os' ).' '.\EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ),
						) );
						?>
					</div>
				</div>
			</div>

			<!-- Cards Grid -->
			<div class="estat-ui-cards hidden" id="estat-cards-grid">
				<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); $id = get_the_ID(); $agent = Agents::to_array( $id ); $role = get_post_meta( $id, '_estat_role', true ); $phone = get_post_meta( $id, '_estat_phone', true ); $email = get_post_meta( $id, '_estat_email', true ); ?>
				<div class="estat-ui-card">
					<div class="estat-ui-card-top">
						<div class="estat-ui-avatar large"><?php echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array(64,64), array('class'=>'estat-ui-avatar-img') ) : '<span class="estat-ui-avatar-fallback">' . esc_html( mb_substr( get_the_title(), 0, 1 ) ) . '</span>'; ?></div>
						<span class="estat-ui-status is-<?php echo esc_attr( get_post_status( $id ) ); ?>"><span class="estat-ui-dot"></span> <?php echo esc_html( Partials::record_status_label( (string) get_post_status( $id ) ) ); ?></span>
					</div>
					<div class="estat-ui-card-body">
						<div class="estat-ui-card-meta"><span>Ref: #<?php echo esc_html( (string) $id ); ?></span><?php if ( '' !== $city ) : ?><span><?php echo esc_html( $city ); ?></span><?php endif; ?></div>
						<h3 class="estat-ui-card-name"><?php echo esc_html( get_the_title() ); ?></h3>
						<p class="estat-ui-card-role"><?php echo esc_html( $role ?: __( 'Team member', 'estat-os' ) ); ?></p>
						<div class="estat-ui-card-contact">
							<?php if ( $phone ) : ?><span><?php echo \EstatOS\Support\Icon::render( 'phone', 18, 'estat-ms' ); ?> <?php echo esc_html( $phone ); ?></span><?php endif; ?>
							<?php if ( $email ) : ?><span><?php echo \EstatOS\Support\Icon::render( 'envelope', 18, 'estat-ms' ); ?> <?php echo esc_html( $email ); ?></span><?php endif; ?>
						</div>
					</div>
					<div class="estat-ui-card-foot">
						<span><?php echo esc_html( sprintf( __( '%d listings', 'estat-os' ), $agent['listings'] ) ); ?></span>
						<div class="estat-ui-actions">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=' . $id ) ); ?>" class="estat-ui-icon-btn"><?php echo \EstatOS\Support\Icon::render( 'pencil', 18, 'estat-ms' ); ?></a>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&qr=' . $id ) ); ?>" class="estat-ui-icon-btn" title="<?php esc_attr_e( 'QR code', 'estat-os' ); ?>"><?php echo \EstatOS\Support\Icon::render( 'qr-code', 18, 'estat-ms' ); ?></a>
							<a href="<?php echo esc_url( get_permalink( $id ) ); ?>" class="estat-ui-icon-btn"><?php echo \EstatOS\Support\Icon::render( 'eye', 18, 'estat-ms' ); ?></a>
						</div>
					</div>
				</div>
				<?php endwhile; wp_reset_postdata(); endif; ?>
			</div>

			<div class="estat-ui-footer">
				<span><?php echo \EstatOS\Support\Icon::render( 'verified', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Your office team.', 'estat-os' ); ?></span>
				<span><?php echo esc_html( sprintf( /* translators: %s: number of people. */ _n( '%s person', '%s people', (int) $query->post_count, 'estat-os' ), number_format_i18n( (int) $query->post_count ) ) ); ?></span>
			</div>
		</div>

		<script>
		(function(){
			var listBtn=document.getElementById('estat-view-list');
			var gridBtn=document.getElementById('estat-view-grid');
			var table=document.getElementById('estat-ledger-table');
			var grid=document.getElementById('estat-cards-grid');
			if(listBtn&&gridBtn&&table&&grid){
				listBtn.addEventListener('click',function(){table.classList.remove('hidden');grid.classList.add('hidden');listBtn.classList.add('is-active');gridBtn.classList.remove('is-active');});
				gridBtn.addEventListener('click',function(){grid.classList.remove('hidden');table.classList.add('hidden');gridBtn.classList.add('is-active');listBtn.classList.remove('is-active');});
			}
			var selAll=document.getElementById('estat-select-all');
			if(selAll){selAll.addEventListener('change',function(){document.querySelectorAll('.estat-row-check').forEach(function(c){c.checked=selAll.checked;});});}
		})();
		</script>
		<?php
	}

	/**
	 * One member's QR codes, on a sheet you can print.
	 *
	 * Two codes, because a member needs two things: the app on his own phone,
	 * and the page a client should open. Both are drawn inside the plugin
	 * (Support\Qr) — no outside image service, so they still work with no
	 * internet at the desk.
	 *
	 * @param int $id Agent post ID.
	 * @return void
	 */
	private static function render_qr( int $id ): void {
		$post = get_post( $id );
		if ( ! $post || PostTypes::AGENT !== $post->post_type ) {
			echo '<div class="estat-ui-note">' . esc_html__( 'That team member was not found.', 'estat-os' ) . '</div>';
			return;
		}

		$agent  = Agents::to_array( $id );
		$role   = (string) ( $agent['role'] ?? '' );
		$public = (string) ( $agent['url'] ?? '' );
		$pocket = Pocket::url();
		$office = (string) Settings::get( 'office_name', get_bloginfo( 'name' ) );

		?>
		<div class="estat-ui-team estat-qr-sheet">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<span><?php esc_html_e( 'Office', 'estat-os' ); ?></span>
					<?php echo \EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ); ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a>
					<?php echo \EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ); ?>
					<span class="is-muted"><?php esc_html_e( 'QR code', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php echo esc_html( get_the_title( $id ) ); ?></h1>
						<p class="estat-ui-desc">
							<?php echo esc_html( '' !== $role ? $role : __( 'Team member', 'estat-os' ) ); ?>
							<?php if ( '' !== $office ) : ?> · <?php echo esc_html( $office ); ?><?php endif; ?>
						</p>
					</div>
					<div class="estat-ui-header-actions no-print">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team&edit=' . $id ) ); ?>" class="estat-ui-btn"><?php echo \EstatOS\Support\Icon::render( 'pencil', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Edit member', 'estat-os' ); ?></a>
						<button type="button" class="estat-ui-btn-primary" id="estat-qr-print"><?php echo \EstatOS\Support\Icon::render( 'document', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Print this sheet', 'estat-os' ); ?></button>
					</div>
				</div>
			</div>

			<p class="description no-print" style="max-width:640px">
				<?php esc_html_e( 'Point a phone camera at a code and it opens by itself. Print this sheet and keep it at the desk, or hand it to the member — no typing long links.', 'estat-os' ); ?>
			</p>

			<div class="estat-qr-row">
				<?php
				Partials::qr_card(
					__( 'Staff phone app', 'estat-os' ),
					$pocket,
					__( 'The member scans this on his own phone, then signs in with his phone number. From there he can see today\'s work, his visits and enquiries.', 'estat-os' )
				);
				Partials::qr_card(
					__( 'His page on your website', 'estat-os' ),
					$public,
					__( 'A client scans this to see his photo, phone number and the properties he handles.', 'estat-os' )
				);
				?>
			</div>

			<p class="estat-qr-foot">
				<?php
				echo esc_html( sprintf(
					/* translators: %s: office name. */
					__( 'Printed from %s', 'estat-os' ),
					'' !== $office ? $office : get_bloginfo( 'name' )
				) );
				?>
			</p>
		</div>
		<script>
		(function(){
			var b=document.getElementById('estat-qr-print');
			if(b){b.addEventListener('click',function(){window.print();});}
		})();
		</script>
		<?php
	}

	private static function render_form( int $edit_id ): void {
		$post = $edit_id > 0 ? get_post( $edit_id ) : null;
		$meta = static function( string $key ) use ( $edit_id ): string {
			return $edit_id > 0 ? (string) get_post_meta( $edit_id, $key, true ) : '';
		};
		$photo_id = $edit_id > 0 ? (int) get_post_thumbnail_id( $edit_id ) : 0;
		$photo_url = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
		$user_options = self::user_options();
		$s = Settings::all();
		$city = (string) ( $s['city'] ?? '' );

		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>"><?php esc_html_e( 'Team', 'estat-os' ); ?></a>
					<?php echo \EstatOS\Support\Icon::render( 'chevron-right', 18, 'estat-ms' ); ?>
					<span><?php echo $post ? esc_html__( 'Edit member', 'estat-os' ) : esc_html__( 'New member', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php echo $post ? esc_html( $post->post_title ) : esc_html__( 'Add someone to the team', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php esc_html_e( 'Add your colleagues using the form below. Once someone is here you can hand them an enquiry or put them in charge of a property.', 'estat-os' ); ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>" class="estat-ui-btn"><?php echo \EstatOS\Support\Icon::render( 'arrow-left', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Back to team', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<form method="post" class="estat-ui-form" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-team' ) ); ?>">
				<?php wp_nonce_field( 'estat_save_agent', 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="save_agent" />
				<input type="hidden" name="agent_id" value="<?php echo esc_attr( (string) $edit_id ); ?>" />

				<div class="estat-ui-form-grid">
					<div class="estat-ui-form-main">
						<!-- Essential -->
						<div class="estat-ui-card-panel">
							<div class="estat-ui-panel-header">
								<?php echo \EstatOS\Support\Icon::render( 'person', 18, 'estat-ms' ); ?>
								<h2><?php esc_html_e( 'Essential', 'estat-os' ); ?></h2>
								<span class="estat-ui-panel-sub"><?php esc_html_e( 'Core identity', 'estat-os' ); ?></span>
							</div>
							<div class="estat-ui-field-grid">
								<div class="estat-ui-field full">
									<label for="estat-title"><?php esc_html_e( 'Full name', 'estat-os' ); ?> <span class="required">*</span></label>
									<input type="text" id="estat-title" name="title" value="<?php echo esc_attr( $post ? $post->post_title : '' ); ?>" required placeholder="<?php esc_attr_e( 'Priya Sharma', 'estat-os' ); ?>" />
								</div>
								<div class="estat-ui-field">
									<label for="estat-role"><?php esc_html_e( 'Role in the office', 'estat-os' ); ?></label>
									<input type="text" id="estat-role" name="role" value="<?php echo esc_attr( $meta( '_estat_role' ) ); ?>" placeholder="<?php esc_attr_e( 'Sales Manager', 'estat-os' ); ?>" />
								</div>
								<div class="estat-ui-field">
									<label for="estat-external_id"><?php esc_html_e( 'Your own reference number', 'estat-os' ); ?></label>
									<input type="text" id="estat-external_id" name="external_id" value="<?php echo esc_attr( $meta( '_estat_external_id' ) ); ?>" />
								</div>
								<div class="estat-ui-field full">
									<label for="estat-bio"><?php esc_html_e( 'A few words about them', 'estat-os' ); ?></label>
									<textarea id="estat-bio" name="bio" rows="4" placeholder="<?php esc_attr_e( 'Bio...', 'estat-os' ); ?>"><?php echo esc_textarea( $post ? $post->post_content : '' ); ?></textarea>
								</div>
							</div>
						</div>

						<!-- Contact -->
						<div class="estat-ui-card-panel">
							<div class="estat-ui-panel-header">
								<?php echo \EstatOS\Support\Icon::render( 'phone', 18, 'estat-ms' ); ?>
								<h2><?php esc_html_e( 'Contact', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-ui-field-grid">
								<div class="estat-ui-field">
									<label for="estat-phone"><?php esc_html_e( 'Phone number', 'estat-os' ); ?></label>
									<input type="tel" id="estat-phone" name="phone" value="<?php echo esc_attr( $meta( '_estat_phone' ) ); ?>" placeholder="+91 98765 43210" />
								</div>
								<div class="estat-ui-field">
									<label for="estat-whatsapp"><?php esc_html_e( 'WhatsApp number', 'estat-os' ); ?></label>
									<input type="tel" id="estat-whatsapp" name="whatsapp" value="<?php echo esc_attr( $meta( '_estat_whatsapp' ) ); ?>" />
									<span class="estat-ui-help"><?php esc_html_e( 'Leave empty if it is the same as the phone number.', 'estat-os' ); ?></span>
								</div>
								<div class="estat-ui-field full">
									<label for="estat-email"><?php esc_html_e( 'Email address', 'estat-os' ); ?></label>
									<input type="email" id="estat-email" name="email" value="<?php echo esc_attr( $meta( '_estat_email' ) ); ?>" placeholder="name@example.com" />
								</div>
							</div>
						</div>

						<!-- Office -->
						<div class="estat-ui-card-panel">
							<div class="estat-ui-panel-header">
								<?php echo \EstatOS\Support\Icon::render( 'shield', 18, 'estat-ms' ); ?>
								<h2><?php esc_html_e( 'Office & access', 'estat-os' ); ?></h2>
								<span class="estat-ui-panel-sub"><?php esc_html_e( 'Confidential', 'estat-os' ); ?></span>
							</div>
							<div class="estat-ui-field-grid">
								<div class="estat-ui-field full">
									<label for="estat-user_id"><?php esc_html_e( 'Website login', 'estat-os' ); ?></label>
									<select id="estat-user_id" name="user_id">
										<?php foreach ( $user_options as $uid => $label ) : ?>
										<option value="<?php echo esc_attr( (string) $uid ); ?>" <?php selected( (string) $meta( '_estat_user_id' ), (string) $uid ); ?>><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
									<span class="estat-ui-help"><?php esc_html_e( 'Link this person to a login so they can sign in — here, and in the staff phone app (Pocket). The address is in Office Settings.', 'estat-os' ); ?></span>
								</div>
							</div>
						</div>
					</div>

					<div class="estat-ui-form-side">
						<div class="estat-ui-card-panel">
							<div class="estat-ui-panel-header">
								<?php echo \EstatOS\Support\Icon::render( 'camera', 18, 'estat-ms' ); ?>
								<h2><?php esc_html_e( 'Photo', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-ui-photo-field">
								<div class="estat-ui-photo-preview" id="estat-photo-preview">
									<?php if ( $photo_url ) : ?>
										<img src="<?php echo esc_url( $photo_url ); ?>" alt="" />
									<?php else : ?>
										<?php echo \EstatOS\Support\Icon::render( 'person', 18, 'estat-ms' ); ?>
									<?php endif; ?>
								</div>
								<input type="hidden" name="photo_id" id="estat-photo-id" value="<?php echo esc_attr( (string) $photo_id ); ?>" />
								<div class="estat-ui-photo-actions">
									<button type="button" class="estat-ui-btn" id="estat-photo-select"><?php esc_html_e( 'Select photo', 'estat-os' ); ?></button>
									<button type="button" class="estat-ui-btn is-ghost" id="estat-photo-remove"><?php esc_html_e( 'Remove', 'estat-os' ); ?></button>
								</div>
								<span class="estat-ui-help"><?php esc_html_e( 'Square photo works best. This is shown on the website and in the team list.', 'estat-os' ); ?></span>
							</div>
						</div>

						<?php if ( $edit_id > 0 ) : $agent = Agents::to_array( $edit_id ); ?>
						<div class="estat-ui-card-panel is-muted">
							<div class="estat-ui-panel-header">
								<?php echo \EstatOS\Support\Icon::render( 'person', 18, 'estat-ms' ); ?>
								<h2><?php esc_html_e( 'Workload', 'estat-os' ); ?></h2>
							</div>
							<div class="estat-ui-metric small">
								<span class="estat-ui-metric-label"><?php esc_html_e( 'Listings in charge', 'estat-os' ); ?></span>
								<span class="estat-ui-metric-num"><?php echo esc_html( (string) $agent['listings'] ); ?></span>
							</div>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&agent=' . $edit_id ) ); ?>" class="estat-ui-link"><?php echo \EstatOS\Support\Icon::render( 'arrow-right', 18, 'estat-ms' ); ?> <?php esc_html_e( 'View listings', 'estat-os' ); ?></a>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="estat-ui-form-actions">
					<span class="estat-ui-save-hint"><?php echo \EstatOS\Support\Icon::render( 'info', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Changes show on the website straight away.', 'estat-os' ); ?></span>
					<button type="submit" class="estat-ui-btn-primary large"><?php echo \EstatOS\Support\Icon::render( 'check-circle', 18, 'estat-ms' ); ?> <?php echo $post ? esc_html__( 'Save changes', 'estat-os' ) : esc_html__( 'Add them', 'estat-os' ); ?></button>
				</div>
			</form>
		</div>

		<script>
		(function(){
			var frame;
			var sel=document.getElementById('estat-photo-select');
			var rem=document.getElementById('estat-photo-remove');
			var input=document.getElementById('estat-photo-id');
			var preview=document.getElementById('estat-photo-preview');
			if(sel){
				sel.addEventListener('click',function(e){
					e.preventDefault();
					if(frame){frame.open();return;}
					frame=wp.media({title:'<?php echo esc_js( __( 'Select photo', 'estat-os' ) ); ?>',button:{text:'<?php echo esc_js( __( 'Use this photo', 'estat-os' ) ); ?>'},multiple:false});
					frame.on('select',function(){
						var att=frame.state().get('selection').first().toJSON();
						input.value=att.id;
						preview.innerHTML='<img src="'+att.url+'" alt="" />';
					});
					frame.open();
				});
			}
			if(rem){
				rem.addEventListener('click',function(e){
					e.preventDefault();
					input.value='';
					preview.innerHTML='<?php echo \EstatOS\Support\Icon::render( 'person', 18, 'estat-ms' ); ?>';
				});
			}
		})();
		</script>
		<?php
	}

	private static function user_options(): array {
		$options = array( '0' => __( 'No login', 'estat-os' ) );
		$users   = get_users( array( 'number'=>200, 'fields'=>array( 'ID', 'display_name' ) ) );
		foreach ( $users as $user ) {
			$options[ (string) $user->ID ] = (string) $user->display_name;
		}
		return $options;
	}
}
