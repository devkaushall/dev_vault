<?php
/**
 * The Recycle bin.
 *
 * The one screen in the office that is about what has been taken out of the
 * working list rather than what is in it. Two things matter here and nothing
 * else: bringing something back, and — rarely, deliberately — ending it for
 * good. So the screen says both plainly, shows who moved each record and
 * what state it was in, and keeps the permanent press behind a typed word.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Bin;
use EstatOS\Settings\Settings;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class BinScreen {

	/**
	 * How many binned records fit on one page — the same number the working
	 * list uses, because twenty is the number this office has read a hundred
	 * times.
	 */
	private const PER_PAGE = 20;

	/**
	 * The filters, read from the address bar.
	 *
	 * Everything a filter needs to survive a page turn travels in the URL, so
	 * a filtered bin can be bookmarked, mailed to a colleague, or reloaded
	 * without losing the question that was asked.
	 *
	 * @return array<string,mixed>
	 */
	private static function filters(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$get = function ( string $key, string $default = '' ): string {
			if ( ! isset( $_GET[ $key ] ) || is_array( $_GET[ $key ] ) ) {
				return $default;
			}

			return sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) );
		};

		$filters = array(
			'deleted_by' => (int) $get( 'deleted_by' ),
			'previous'   => sanitize_key( $get( 'previous' ) ),
			'date_from'  => $get( 'from' ),
			'date_to'    => $get( 'to' ),
			'type'       => sanitize_key( $get( 'type' ) ),
			'locality'   => sanitize_key( $get( 'locality' ) ),
			'search'     => $get( 's' ),
			'page'       => max( 1, (int) $get( 'paged', '1' ) ),
			'per_page'   => self::PER_PAGE,
		);
		// phpcs:enable

		// The quick date choices write themselves into the two boxes, so the
		// office can see what it just asked for instead of trusting a label.
		$quick = sanitize_key( $get( 'moved' ) );
		if ( 'week' === $quick || 'month' === $quick ) {
			$days = 'week' === $quick ? 7 : 30;
			if ( '' === $filters['date_from'] ) {
				$filters['date_from'] = gmdate( 'Y-m-d', time() - ( $days * DAY_IN_SECONDS ) );
			}
		}

		return $filters;
	}

	/**
	 * The address for this screen with a set of filters, ready to link to.
	 *
	 * @param array<string,mixed> $args Filters.
	 * @return string
	 */
	private static function url( array $args = array() ): string {
		$args = array_filter(
			$args,
			static function ( $value ): bool {
				return '' !== $value && 0 !== $value && '0' !== (string) $value;
			}
		);

		return add_query_arg( array_merge( array( 'page' => 'estat-bin' ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Is this screen being asked to show something at all, or the plain bin?
	 *
	 * @param array<string,mixed> $filters Current filters.
	 * @return bool
	 */
	private static function filtered( array $filters ): bool {
		foreach ( array( 'deleted_by', 'previous', 'date_from', 'date_to', 'type', 'locality', 'search' ) as $key ) {
			if ( ! empty( $filters[ $key ] ) ) {
				return true;
			}
		}

		return false;
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) && ! current_user_can( 'estat_bin_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see the bin.', 'estat-os' ) );
		}

		$filters = self::filters();
		$found   = Bin::query( $filters );
		$counts  = Bin::summary_counts();

		$settings = Settings::all();
		$city     = (string) ( $settings['city'] ?? '' );
		$ref      = '' !== (string) ( $settings['ref_prefix'] ?? '' ) ? (string) $settings['ref_prefix'] . '-' : '';

		$scope = array(
			'kind'       => 'bin',
			'deleted_by' => $filters['deleted_by'],
			'previous'   => $filters['previous'],
			'from'       => $filters['date_from'],
			'to'         => $filters['date_to'],
			'type'       => $filters['type'],
			'locality'   => $filters['locality'],
			's'          => $filters['search'],
		);

		$showing_any = $filters['search'] || $filters['type'] || $filters['locality'] || $filters['previous'] || $filters['deleted_by'] || $filters['date_from'] || $filters['date_to'];
		?>
		<div class="estat-ui-team estat-bin-screen">
			<div class="estat-ui-page-header">
				<div class="estat-ui-breadcrumb">
					<span><?php esc_html_e( 'Office', 'estat-os' ); ?></span>
					<span>/</span>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>"><?php esc_html_e( 'Properties', 'estat-os' ); ?></a>
					<span>/</span>
					<span class="is-muted"><?php esc_html_e( 'Bin', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php esc_html_e( 'Recycle bin', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php esc_html_e( 'Properties moved out of your working list. They are off the website, and nothing here is gone for good until you say so.', 'estat-os' ); ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-ui-btn">
							<?php echo Icon::render( 'arrow-left', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php esc_html_e( 'Back to properties', 'estat-os' ); ?>
						</a>
						<?php if ( $counts['in_bin'] > 0 && Bin::may_empty() ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-bin' ) ); ?>" class="estat-empty-bin">
								<?php wp_nonce_field( 'estat_empty_bin', 'estat_nonce' ); ?>
								<input type="hidden" name="estat_action" value="empty_bin" />
								<input type="hidden" name="confirm_word" value="" class="estat-confirm-word-field" />
								<button type="submit" class="estat-ui-btn estat-ui-btn-danger estat-bulk-do"
									data-estat-ask="<?php echo esc_attr( sprintf( /* translators: %s: number of properties in the bin. */ _n( 'Delete %s property permanently?', 'Delete %s properties permanently?', $counts['in_bin'], 'estat-os' ), number_format_i18n( $counts['in_bin'] ) ) ); ?>"
									data-estat-ask-note="<?php echo esc_attr__( 'This cannot be undone. Everything in the bin goes for good.', 'estat-os' ); ?>"
									data-estat-ask-word="DELETE"
									data-estat-ask-label="<?php esc_attr_e( 'Empty bin', 'estat-os' ); ?>">
									<?php echo Icon::render( 'broom', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<?php esc_html_e( 'Empty bin', 'estat-os' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</div>
				</div>
			</div>

			<div class="estat-ui-metrics is-4">
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'In bin', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value">
						<span class="estat-ui-metric-num"><?php echo esc_html( number_format_i18n( $counts['in_bin'] ) ); ?></span>
						<span class="estat-ui-metric-sub"><?php esc_html_e( 'Off the website, kept safely', 'estat-os' ); ?></span>
					</div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Moved here today', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value">
						<span class="estat-ui-metric-num"><?php echo esc_html( number_format_i18n( $counts['today'] ) ); ?></span>
						<span class="estat-ui-metric-sub"><?php esc_html_e( 'Since midnight', 'estat-os' ); ?></span>
					</div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Moved this week', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value">
						<span class="estat-ui-metric-num"><?php echo esc_html( number_format_i18n( $counts['week'] ) ); ?></span>
						<span class="estat-ui-metric-sub"><?php esc_html_e( 'Last 7 days', 'estat-os' ); ?></span>
					</div>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Oldest', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value">
						<span class="estat-ui-metric-num"><?php echo esc_html( $counts['oldest_days'] > 0 ? number_format_i18n( $counts['oldest_days'] ) : '0' ); ?></span>
						<span class="estat-ui-metric-sub"><?php esc_html_e( 'Days in the bin', 'estat-os' ); ?></span>
					</div>
				</div>
			</div>

			<div class="estat-ui-controls estat-bin-controls">
				<div class="estat-ui-controls-top">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-ui-search">
						<input type="hidden" name="page" value="estat-bin" />
						<?php foreach ( $scope as $keep => $held ) : ?>
							<?php if ( 'kind' !== $keep && ! empty( $held ) ) : ?>
								<input type="hidden" name="<?php echo esc_attr( (string) $keep ); ?>" value="<?php echo esc_attr( (string) $held ); ?>" />
							<?php endif; ?>
						<?php endforeach; ?>
						<?php echo Icon::render( 'search', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<input type="search" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Search the bin by address, street or reference…', 'estat-os' ); ?>" />
					</form>
				</div>

				<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="estat-ui-filters-form estat-bin-filters">
					<input type="hidden" name="page" value="estat-bin" />
					<?php if ( '' !== $filters['search'] ) : ?>
						<input type="hidden" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" />
					<?php endif; ?>

					<label class="estat-bin-filter">
						<span><?php esc_html_e( 'Deleted by', 'estat-os' ); ?></span>
						<select name="deleted_by">
							<option value=""><?php esc_html_e( 'Anyone', 'estat-os' ); ?></option>
							<?php foreach ( Bin::deleted_by_options() as $user_id => $name ) : ?>
								<option value="<?php echo esc_attr( (string) $user_id ); ?>" <?php selected( $filters['deleted_by'], $user_id ); ?>><?php echo esc_html( $name ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label class="estat-bin-filter">
						<span><?php esc_html_e( 'Deleted between', 'estat-os' ); ?></span>
						<span class="estat-bin-dates">
							<input type="date" name="from" value="<?php echo esc_attr( $filters['date_from'] ); ?>" />
							<input type="date" name="to" value="<?php echo esc_attr( $filters['date_to'] ); ?>" />
						</span>
					</label>

					<label class="estat-bin-filter">
						<span><?php esc_html_e( 'Locality', 'estat-os' ); ?></span>
						<select name="locality">
							<option value=""><?php esc_html_e( 'All localities', 'estat-os' ); ?></option>
							<?php foreach ( Bin::locality_options() as $slug => $name ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filters['locality'], $slug ); ?>><?php echo esc_html( $name ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label class="estat-bin-filter">
						<span><?php esc_html_e( 'Property type', 'estat-os' ); ?></span>
						<select name="type">
							<option value=""><?php esc_html_e( 'All types', 'estat-os' ); ?></option>
							<?php foreach ( Bin::type_options() as $type ) : ?>
								<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $filters['type'], $type ); ?>><?php echo esc_html( Vocabulary::label( 'property_types', $type ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label class="estat-bin-filter">
						<span><?php esc_html_e( 'Previous state', 'estat-os' ); ?></span>
						<select name="previous">
							<option value=""><?php esc_html_e( 'Any state', 'estat-os' ); ?></option>
							<option value="publish" <?php selected( $filters['previous'], 'publish' ); ?>><?php esc_html_e( 'Live', 'estat-os' ); ?></option>
							<option value="draft" <?php selected( $filters['previous'], 'draft' ); ?>><?php esc_html_e( 'Draft', 'estat-os' ); ?></option>
							<option value="pending" <?php selected( $filters['previous'], 'pending' ); ?>><?php esc_html_e( 'Waiting for approval', 'estat-os' ); ?></option>
							<option value="private" <?php selected( $filters['previous'], 'private' ); ?>><?php esc_html_e( 'Paused', 'estat-os' ); ?></option>
						</select>
					</label>

					<button type="submit" class="estat-ui-btn"><?php esc_html_e( 'Filter', 'estat-os' ); ?></button>
					<?php if ( self::filtered( $filters ) ) : ?>
						<a href="<?php echo esc_url( self::url() ); ?>" class="estat-ui-link">
							<?php echo Icon::render( 'refresh', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php esc_html_e( 'Reset filters', 'estat-os' ); ?>
						</a>
					<?php endif; ?>
				</form>
			</div>

			<?php if ( 0 === (int) $found['total'] ) : ?>
				<?php
				Partials::empty_state(
					array(
						'icon'       => 'bin',
						'title'      => __( 'Recycle bin is empty', 'estat-os' ),
						'message'    => $showing_any
							? __( 'Nothing in the bin matches this filter. Try Reset filters to see everything.', 'estat-os' )
							: __( 'No properties have been moved here.', 'estat-os' ),
						'reassuring' => true,
						'action'     => $showing_any ? self::url() : admin_url( 'admin.php?page=estat-listings' ),
						'label'      => $showing_any ? __( 'Reset filters', 'estat-os' ) : __( 'Back to properties', 'estat-os' ),
					)
				);
				?>
			<?php else : ?>

				<?php
				Partials::bulk_open(
					'estat-bin',
					array(
						'word'     => __( 'properties', 'estat-os' ),
					'word_one' => __( 'property', 'estat-os' ),
						'mode'   => 'bin',
						'nonce'  => 'estat_bulk_records',
						'action' => 'restore_records',
						'scope'  => $scope,
					)
				);
				?>

				<div class="estat-ui-table-wrap">
					<div class="estat-ui-table-scroll">
						<table class="estat-ui-table estat-table-cards">
							<thead>
								<tr>
									<?php Partials::bulk_header(); ?>
									<th><?php esc_html_e( 'Property', 'estat-os' ); ?></th>
									<th><?php esc_html_e( 'Locality', 'estat-os' ); ?></th>
									<th><?php esc_html_e( 'Price', 'estat-os' ); ?></th>
									<th><?php esc_html_e( 'Deleted by', 'estat-os' ); ?></th>
									<th><?php esc_html_e( 'Deleted on', 'estat-os' ); ?></th>
									<th><?php esc_html_e( 'Original status', 'estat-os' ); ?></th>
									<th class="text-right"><?php esc_html_e( 'Actions', 'estat-os' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $found['items'] as $post ) : ?>
									<?php
									$id  = (int) $post->ID;
									$row = Bin::row( $id );
									$price_line = (string) $row['price'];
									if ( in_array( (string) $row['offer'], array( 'rent', 'lease' ), true ) && '' !== $price_line && false === strpos( $price_line, __( 'per month', 'estat-os' ) ) ) {
										$price_line .= ' ' . __( 'per month', 'estat-os' );
									}
									?>
									<tr class="estat-bin-row">
										<?php Partials::bulk_cell( $id, (string) $row['title'] ); ?>
										<td data-label="<?php esc_attr_e( 'Property', 'estat-os' ); ?>">
											<div class="estat-ui-member">
												<div class="estat-ui-avatar is-property">
													<?php
													if ( has_post_thumbnail( $id ) ) {
														echo get_the_post_thumbnail( $id, array( 48, 48 ), array( 'class' => 'estat-ui-avatar-img' ) );
													} else {
														echo Icon::render( 'buildings', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
													}
													?>
												</div>
												<div class="estat-ui-member-info">
													<span class="estat-ui-member-name"><?php echo esc_html( (string) $row['title'] ); ?></span>
													<span class="estat-ui-member-meta">
														<span class="estat-ui-ref"><?php echo esc_html( sprintf( /* translators: %s: reference code. */ __( 'Ref: %s', 'estat-os' ), $ref . $id ) ); ?></span>
														<?php if ( '' !== (string) $row['type'] ) : ?>
															<span class="estat-ui-dot"></span> <?php echo esc_html( Vocabulary::label( 'property_types', (string) $row['type'] ) ); ?>
														<?php endif; ?>
													</span>
												</div>
											</div>
										</td>
										<td data-label="<?php esc_attr_e( 'Locality', 'estat-os' ); ?>"><div class="estat-ui-locality"><span><?php echo esc_html( '' !== (string) $row['locality'] ? (string) $row['locality'] : $city ); ?></span></div></td>
										<td data-label="<?php esc_attr_e( 'Price', 'estat-os' ); ?>"><div class="estat-ui-price"><span class="is-price"><?php echo esc_html( '' !== $price_line ? $price_line : '—' ); ?></span></div></td>
										<td data-label="<?php esc_attr_e( 'Deleted by', 'estat-os' ); ?>">
											<div class="estat-bin-by">
												<span><?php echo esc_html( (string) $row['deleted_by_name'] ); ?></span>
											</div>
										</td>
										<td class="estat-ui-date" data-label="<?php esc_attr_e( 'Deleted on', 'estat-os' ); ?>">
											<?php
											$when = '' !== (string) $row['deleted_at'] ? strtotime( (string) $row['deleted_at'] ) : 0;
											echo esc_html(
												$when
													? sprintf(
														/* translators: 1: date, 2: how long ago. */
														__( '%1$s · %2$s', 'estat-os' ),
														date_i18n( 'j M Y', $when ),
														sprintf(
															/* translators: %s: how long ago, e.g. "2 days". */
															__( '%s ago', 'estat-os' ),
															human_time_diff( $when, time() )
														)
													)
													: '—'
											);
											?>
										</td>
										<td data-label="<?php esc_attr_e( 'Original status', 'estat-os' ); ?>">
											<span class="estat-ui-status is-was">
												<span class="estat-ui-dot"></span> <?php echo esc_html( (string) $row['previous_label'] ); ?>
											</span>
										</td>
										<td class="text-right" data-label="<?php esc_attr_e( 'Actions', 'estat-os' ); ?>">
											<div class="estat-ui-actions estat-bin-actions">
												<?php Partials::bin_row_actions( $id ); ?>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<div class="estat-ui-pagination">
						<span>
							<?php
							printf(
								/* translators: 1: first record number, 2: last record number, 3: total in the bin. */
								esc_html__( 'Showing %1$d to %2$d of %3$d in the bin', 'estat-os' ),
								esc_html( number_format_i18n( ( ( (int) $found['page'] - 1 ) * self::PER_PAGE ) + 1 ) ),
								esc_html( number_format_i18n( min( (int) $found['page'] * self::PER_PAGE, (int) $found['total'] ) ) ),
								esc_html( number_format_i18n( (int) $found['total'] ) )
							);
							?>
							·
							<?php
							printf(
								/* translators: 1: page number, 2: number of pages. */
								esc_html__( 'Page %1$d of %2$d', 'estat-os' ),
								esc_html( number_format_i18n( (int) $found['page'] ) ),
								esc_html( number_format_i18n( max( 1, (int) $found['pages'] ) ) )
							);
							?>
						</span>
						<div class="estat-ui-pager">
							<?php
							$query_args = array(
								'deleted_by' => $filters['deleted_by'] ?: '',
								'previous'   => $filters['previous'],
								'from'       => $filters['date_from'],
								'to'         => $filters['date_to'],
								'type'       => $filters['type'],
								'locality'   => $filters['locality'],
								's'          => $filters['search'],
							);
							echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress builds these links; the arrows are inline SVG.
								array(
										'base'      => add_query_arg( array_merge( array( 'page' => 'estat-bin' ), $query_args ), admin_url( 'admin.php' ) ) . '&paged=%#%',
										'format'    => '',
										'current'   => (int) $found['page'],
										'total'     => max( 1, (int) $found['pages'] ),
										'prev_text' => Icon::render( 'chevron-left', 18, 'estat-ms' ) . ' ' . __( 'Previous', 'estat-os' ),
										'next_text' => __( 'Next', 'estat-os' ) . ' ' . Icon::render( 'chevron-right', 18, 'estat-ms' ),
									)
							);
							?>
						</div>
					</div>
				</div>

				<?php Partials::bulk_close(); ?>

				<div class="estat-ui-footer estat-bin-footer">
					<span><?php echo Icon::render( 'lock', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php esc_html_e( 'Nothing in the bin is deleted for good until somebody types DELETE.', 'estat-os' ); ?></span>
					<span><?php esc_html_e( 'Every move, restore and delete is written into the office log.', 'estat-os' ); ?></span>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
