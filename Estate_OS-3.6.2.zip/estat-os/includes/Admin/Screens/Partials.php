<?php
/**
 * Shared admin UI pieces: header, cards, help, notices, fields.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Highlights;
use EstatOS\Settings\Settings;
use EstatOS\Support\Icon;
use EstatOS\Admin\Actions;
use EstatOS\Data\Undo;

defined( 'ABSPATH' ) || exit;

/**
 * Small, explicit helpers. Everything is escaped at the point of output.
 */
final class Partials {

	/**
	 * One QR card: caption, code, one plain-English line, the link in text.
	 *
	 * The code is drawn by Support\Qr — inside the plugin, never an outside
	 * image service. If the text cannot be encoded (too long), the card is
	 * simply not drawn; a blank box would be worse than nothing.
	 *
	 * @param string $title Caption above the code.
	 * @param string $url   What the code opens.
	 * @param string $note  One line saying what the code is for.
	 * @return void
	 */
	public static function qr_card( string $title, string $url, string $note ): void {
		if ( '' === $url ) {
			return;
		}
		$svg = \EstatOS\Support\Qr::svg( $url, array( 'size' => 190, 'title' => $title ) );
		if ( '' === $svg ) {
			return;
		}
		echo '<div class="estat-qr-card">';
		echo '<h3 class="estat-qr-title">' . esc_html( $title ) . '</h3>';
		echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Qr::svg() escapes its own output.
		echo '<p class="estat-qr-note">' . esc_html( $note ) . '</p>';
		echo '<p class="estat-qr-url">' . esc_html( $url ) . '</p>';
		echo '</div>';
	}

	/**
	 * Screen header with title, version and help.
	 *
	 * @param string $page Current page slug.
	 * @return void
	 */
	public static function header( string $page, bool $wide = false ): void {
		$titles = array(
			'estat-setup'       => array( __( 'Welcome to your office', 'estat-os' ), __( 'Four short questions, and your website will be ready for visitors.', 'estat-os' ) ),
			'estat-today'       => array( __( 'Today', 'estat-os' ), __( 'What needs your attention right now.', 'estat-os' ) ),
			'estat-add-home'    => array( __( 'Add a Home', 'estat-os' ), __( 'Just the basics. You can add more later.', 'estat-os' ) ),
			'estat-listings'    => array( __( 'Listings', 'estat-os' ), __( 'Every property your office is handling.', 'estat-os' ) ),
			'estat-enquiries'   => array( __( 'Enquiries', 'estat-os' ), __( 'People who have asked about your properties.', 'estat-os' ) ),
			'estat-visits'      => array( __( 'Site Visits', 'estat-os' ), __( 'Visits your team has arranged.', 'estat-os' ) ),
			'estat-requests'    => array( __( 'Change Requests', 'estat-os' ), __( 'Things your team saw on the ground that the website has wrong.', 'estat-os' ) ),
			'estat-projects'    => array( __( 'Societies & Projects', 'estat-os' ), __( 'Buildings and developments you work with.', 'estat-os' ) ),
			'estat-team'        => array( __( 'Team', 'estat-os' ), __( 'The people in your office.', 'estat-os' ) ),
			'estat-forms'       => array( __( 'Forms', 'estat-os' ), __( 'Design the forms visitors fill in on your website.', 'estat-os' ) ),
			'estat-spreadsheet' => array( __( 'Import & export', 'estat-os' ), __( 'Bring information in from a spreadsheet, or take it out.', 'estat-os' ) ),
			'estat-reports'     => array( __( 'Reports', 'estat-os' ), __( 'How your office is doing.', 'estat-os' ) ),
			'estat-settings'    => array( __( 'Office', 'estat-os' ), __( 'Your office details and how the system behaves.', 'estat-os' ) ),
			'estat-pipeline'    => array( __( 'Pipeline', 'estat-os' ), __( 'Enquiries by stage, moved as they progress.', 'estat-os' ) ),
			'estat-reports'     => array( __( 'Reports', 'estat-os' ), __( 'How your office is doing.', 'estat-os' ) ),
			'estat-gallery'     => array( __( 'Gallery & media', 'estat-os' ), __( 'Photos and files on your website.', 'estat-os' ) ),
			'estat-insights'    => array( __( 'Insights', 'estat-os' ), __( 'Blog posts, articles and market notes you have written.', 'estat-os' ) ),
			'estat-search-alerts' => array( __( 'Search alerts', 'estat-os' ), __( 'Visitors watching a search.', 'estat-os' ) ),
			'estat-templates'   => array( __( 'Page blocks', 'estat-os' ), __( 'Arrange the blocks on a public page.', 'estat-os' ) ),
			'estat-design-tokens' => array( __( 'Colours and fonts', 'estat-os' ), __( 'The one place colours and fonts are set.', 'estat-os' ) ),
		);
		$current = $titles[ $page ] ?? $titles['estat-today'];
		?>
		<div class="estat-page-head<?php echo $wide ? ' estat-wrap-wide' : ''; ?>">
			<div class="estat-ui-breadcrumb">
				<span><?php esc_html_e( 'Office', 'estat-os' ); ?></span>
				<span>/</span>
				<span class="is-muted"><?php echo esc_html( $current[0] ); ?></span>
			</div>
			<div class="estat-ui-header-row">
				<div>
					<h1 class="wp-heading-inline estat-ui-h1"><?php echo esc_html( $current[0] ); ?></h1>
					<p class="estat-subtitle estat-ui-desc"><?php echo esc_html( $current[1] ); ?></p>
				</div>
				<div class="estat-page-head-actions estat-ui-header-actions">
					<?php if ( 'estat-add-home' !== $page && current_user_can( 'estat_manage_listings' ) ) : ?>
						<a class="estat-ui-btn-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>"><?php echo \EstatOS\Support\Icon::render( 'plus', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Add a home', 'estat-os' ); ?></a>
					<?php endif; ?>
					<button type="button" class="estat-ui-btn estat-help-toggle" aria-expanded="false" aria-controls="estat-help"><?php esc_html_e( 'Need help?', 'estat-os' ); ?></button>
				</div>
			</div>
		</div>
		<?php
		self::help_panel( $page );
		self::notices();
	}

	/**
	 * Contextual help drawer.
	 *
	 * @param string $page Page slug.
	 * @return void
	 */
	private static function help_panel( string $page ): void {
		/**
		 * Plain-language help for every screen.
		 *
		 * Each entry answers the same three questions a person actually has:
		 * what is this screen for, what should I do here, and what catches
		 * people out. No jargon, and never a reference to a manual the office
		 * has not got open.
		 */
		$help = array(
			'estat-setup'       => array(
				__( 'This is the quickest way to get started. Answer the questions and we will build your website pages for you.', 'estat-os' ),
				__( 'Nothing here is permanent. Every answer can be changed later in Office Settings, and the pages are ordinary pages you can edit or delete.', 'estat-os' ),
				__( 'If you would rather build everything yourself, click "Skip this" — the plugin works exactly the same either way.', 'estat-os' ),
			),
			'estat-today'       => array(
				__( 'This screen shows what happened recently and what is waiting for you.', 'estat-os' ),
				__( 'Start your day here, then click through to whatever needs attention.', 'estat-os' ),
				__( 'The list at the top is in order of urgency: overdue follow-ups first, then today\'s visits, then new enquiries.', 'estat-os' ),
			),
			'estat-add-home'    => array(
				__( 'Fill in a few basics and save. Nothing goes on the website until you choose "Put it on the website".', 'estat-os' ),
				__( 'A common mistake is typing the price as text. Type only numbers, for example 8500000.', 'estat-os' ),
				__( 'You only need four things to start: what it is, the price, the size and the locality. Everything else can wait.', 'estat-os' ),
			),
			'estat-listings'    => array(
				__( 'Every property your office is handling, whether it is on the website or not.', 'estat-os' ),
				__( '"On the website" means visitors can see it. "Draft" means only your office can. Use the filter at the top to switch between them.', 'estat-os' ),
				__( 'Remove puts a property in the bin and takes it off your website. Nothing is destroyed — you can put it back from the "In the bin" filter.', 'estat-os' ),
				__( 'The readiness score is a hint, not a rule. A listing with photos, a price and a locality gets far more enquiries than one without.', 'estat-os' ),
			),
			'estat-enquiries'   => array(
				__( 'Everyone who has contacted you through the website, newest first.', 'estat-os' ),
				__( 'Give each enquiry to a team member so it does not get forgotten, and set a follow-up date — it will then appear on Today when it is due.', 'estat-os' ),
				__( 'If the same person asks about the same property twice in a day we keep it as one enquiry and add their second message as a note, so you do not chase them twice.', 'estat-os' ),
				__( '"Erase personal details" permanently removes the name, phone and email if someone asks you to. The enquiry itself stays in your records.', 'estat-os' ),
			),
			'estat-visits'      => array(
				__( 'Site visits your team has arranged, so nobody turns up at the wrong time.', 'estat-os' ),
				__( 'A visit booked for today appears on the Today screen automatically.', 'estat-os' ),
				__( 'Mark a visit as done afterwards. That is what makes your reports meaningful.', 'estat-os' ),
			),
			'estat-projects'    => array(
				__( 'Societies, apartment complexes and builder projects that several of your listings belong to.', 'estat-os' ),
				__( 'Add the society once here, then pick it on each property. The shared details are then only typed once.', 'estat-os' ),
				__( 'This is optional. A standalone house does not need to belong to anything.', 'estat-os' ),
			),
			'estat-team'        => array(
				__( 'The people in your office. Their name and phone number can be shown on your website.', 'estat-os' ),
				__( 'Adding someone here does not give them a login. That is done in the normal WordPress Users screen.', 'estat-os' ),
				__( 'Once you have added people you can hand each enquiry to whoever is dealing with it.', 'estat-os' ),
			),
			'estat-forms'       => array(
				__( 'Build a form once here, then place it on any page — including pages you design with Elementor.', 'estat-os' ),
				__( 'Changing the look of a form never changes what it does with the information.', 'estat-os' ),
				__( 'Start from one of the ready-made forms. They already ask for the right things and are set up correctly.', 'estat-os' ),
				__( 'Every form sends what it collects to your Enquiries screen. You never have to check a separate inbox.', 'estat-os' ),
			),
			'estat-gallery'     => array(
				__( 'Every photo and document you have uploaded, in one place.', 'estat-os' ),
				__( 'Drag files straight onto the page to upload them. Sort them by kind using the tabs.', 'estat-os' ),
				__( 'Deleting a file here removes it for good, and any property using it will lose that photo. Check before you delete.', 'estat-os' ),
			),
			'estat-insights'    => array(
				__( 'Blogs, articles and market insights — three kinds of writing, all on this one screen.', 'estat-os' ),
				__( 'Use the tabs to switch between them. Each kind can have its own topics.', 'estat-os' ),
				__( 'Writing about your area is one of the cheapest ways to get found on Google.', 'estat-os' ),
			),
			'estat-spreadsheet' => array(
				__( 'Always run a test first. It checks your file without changing anything.', 'estat-os' ),
				__( 'Give each row a reference number so importing the same file twice does not create copies.', 'estat-os' ),
				__( 'Imported properties always arrive as drafts, so you can check them before anything appears on your website.', 'estat-os' ),
				__( 'Download a sample file first and fill that in. It already has the right column names.', 'estat-os' ),
			),
			'estat-reports'     => array(
				__( 'How your office is doing: enquiries coming in, visits arranged, and which team member is handling what.', 'estat-os' ),
				__( 'These numbers only reflect what has been recorded. If visits are not marked as done, they will not show here.', 'estat-os' ),
			),
			'estat-settings'    => array(
				__( 'You get four emails: a new enquiry, a property waiting for your approval, a summary every morning and a report every Monday. Every other heads-up appears on the Today screen instead.', 'estat-os' ),
				__( 'Fill in your office details first: name, phone and currency.', 'estat-os' ),
				__( 'Nothing here is deleted when you deactivate the plugin.', 'estat-os' ),
				__( 'The Tools tab has the buttons for fixing things: rebuilding the property search, clearing stored copies, and creating practice records to experiment with.', 'estat-os' ),
				__( 'Your data is only ever deleted if you explicitly tick the box on the Tools tab. By default, uninstalling keeps everything.', 'estat-os' ),
			),
			'estat-requests'    => array(
				__( 'Changes your team has asked for — a price, a photo, a correction — wait here for the office to say yes or no.', 'estat-os' ),
				__( 'Open one to see what was asked, then approve it or send it back with a reason. The person who asked sees your answer.', 'estat-os' ),
				__( 'Nothing on your website changes until a request is approved.', 'estat-os' ),
			),
			'estat-pipeline'    => array(
				__( 'The same enquiries as the Enquiries screen, laid out by stage, so you can see what is moving and what has gone quiet.', 'estat-os' ),
				__( 'Drag a card to the next column when the buyer moves forward.', 'estat-os' ),
				__( 'The columns are: New, Contacted, Visit scheduled, Won and Lost. Enquiries you set aside are not shown here — they are still in Enquiries under "Deleted".', 'estat-os' ),
			),
			'estat-search-alerts' => array(
				__( 'Searches you want to hear about. Save a search on the website, then choose how often we should email you the new matches.', 'estat-os' ),
				__( 'An alert only watches. It never changes your listings and it never writes to anyone.', 'estat-os' ),
				__( 'If the emails stop arriving, check the address and whether your hosting can send mail.', 'estat-os' ),
			),
			'estat-templates'   => array(
				__( 'Ready-made blocks for your website pages — a headline area, a row of properties, a contact strip and so on.', 'estat-os' ),
				__( 'Design a block once here, then place it on any page. Changing it here updates every page that uses it.', 'estat-os' ),
				__( 'If you build your pages with Elementor you can carry on doing that. These blocks are for the pages this plugin builds.', 'estat-os' ),
			),
			'estat-design-tokens' => array(
				__( 'The colours and fonts used by your website and by these screens, all in one place.', 'estat-os' ),
				__( 'Change a colour here and it changes everywhere it is used, including the property cards on your website.', 'estat-os' ),
				__( 'Leave everything empty to follow your own theme, so the site matches whatever your web designer set up.', 'estat-os' ),
			),
		);
		$items = $help[ $page ] ?? array( __( 'Every field on this screen has a short explanation below it.', 'estat-os' ) );
		?>
		<div class="estat-help" id="estat-help" hidden>
			<h2><?php esc_html_e( 'About this screen', 'estat-os' ); ?></h2>
			<ul>
				<?php foreach ( $items as $item ) : ?>
					<li><?php echo esc_html( $item ); ?></li>
				<?php endforeach; ?>
			</ul>
			<details class="estat-help-support">
				<summary><?php esc_html_e( 'Asking someone for help?', 'estat-os' ); ?></summary>
				<p class="description"><?php esc_html_e( 'Copy this line of facts and send it with your question. It holds no passwords and no customer details.', 'estat-os' ); ?></p>
				<textarea class="estat-diagnostics" rows="5" readonly><?php echo esc_textarea( self::diagnostics() ); ?></textarea>
				<button type="button" class="button estat-copy-diagnostics"><?php esc_html_e( 'Copy', 'estat-os' ); ?></button>
			</details>
		</div>
		<?php
	}

	/**
	 * Safe diagnostics text (never includes secrets).
	 *
	 * @return string
	 */
	public static function diagnostics(): string {
		global $wp_version;
		$index = \EstatOS\Search\SearchIndex::status();
		return implode(
			"\n",
			array(
				'Estat.OS: ' . ESTAT_VERSION,
				'Data version: ' . (string) get_option( 'estat_db_version', '0' ),
				'WordPress: ' . (string) $wp_version,
				'PHP: ' . PHP_VERSION,
				'Elementor: ' . ( \EstatOS\Integrations\Elementor\Bridge::active() ? 'active' : 'not active' ),
				'Listings: ' . (string) $index['listings'],
				'Indexed: ' . (string) $index['indexed'],
				'Language: ' . \EstatOS\I18n\Language::resolve(),
				'Practice mode: ' . ( Settings::get( 'practice_mode' ) ? 'on' : 'off' ),
			)
		);
	}

	/**
	 * Show a message passed back after an action.
	 *
	 * @return void
	 */
	public static function notices(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$notice = isset( $_GET['estat_notice'] ) ? sanitize_key( wp_unslash( is_array($_GET['estat_notice']) ? '' : $_GET['estat_notice'] ) ) : '';
		$detail = isset( $_GET['estat_detail'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['estat_detail']) ? '' : $_GET['estat_detail'] ) ) ) : '';
		// phpcs:enable
		if ( '' === $notice ) {
			return;
		}
		$messages = array(
			// Say what was saved and what happens next, not just "Saved".
			'saved'            => array( 'success', __( 'Saved. Your changes are stored.', 'estat-os' ) ),
			'published'        => array( 'success', __( 'Property is now live. Anyone can see it on your website.', 'estat-os' ) ),
			'draft'            => array( 'success', __( 'Saved as a draft. Only your office can see it — nobody on the website can.', 'estat-os' ) ),
			'deleted'          => array( 'success', '' !== $detail ? $detail : __( 'Deleted permanently. It cannot be restored.', 'estat-os' ) ),
			'trashed'          => array( 'success', __( 'Moved to the bin. It is off your website, and you can put it back any time.', 'estat-os' ) ),
			'binned'           => array( 'success', '' !== $detail ? $detail : __( 'Moved to the bin. You can bring it back any time.', 'estat-os' ) ),
			'restored'         => array( 'success', '' !== $detail ? $detail : __( 'Brought back. It is exactly as it was before it went into the bin.', 'estat-os' ) ),
			'undone'           => array( 'success', __( 'Undone. The details are back to how they were before the last save. Whether it is on the website was left as it is.', 'estat-os' ) ),
			'setup_done'       => array( 'success', __( 'All set. Your website pages are live — have a look at them below.', 'estat-os' ) ),
			'assigned'         => array( 'success', __( 'Done. That team member is now responsible for this enquiry.', 'estat-os' ) ),
			'visit_scheduled'  => array( 'success', __( 'Site visit booked. It will appear on your Today screen on the day.', 'estat-os' ) ),
			'erased'           => array( 'success', __( 'The name, phone and email have been erased for good. The record of the enquiry itself is kept.', 'estat-os' ) ),
			'imported'         => array( 'success', __( 'Import finished. The new properties were saved as drafts so you can check them before publishing.', 'estat-os' ) ),
			'requested'        => array( 'success', __( 'Sent to the office for approval. Nothing on the website has changed yet.', 'estat-os' ) ),
			'request_approved' => array( 'success', __( 'Request approved and applied. The website now shows the change.', 'estat-os' ) ),
			'request_declined' => array( 'success', __( 'Declined. The property was left exactly as it is, and the agent sees why.', 'estat-os' ) ),
			'practice_seeded'  => array( 'success', __( 'Practice records have been created for you to try.', 'estat-os' ) ),
			'practice_cleared' => array( 'success', __( 'All practice records have been removed.', 'estat-os' ) ),
			'index_rebuilt'    => array( 'success', __( 'The property search has been refreshed.', 'estat-os' ) ),
			'merged'           => array( 'success', '' !== $detail ? $detail : __( 'Merged. The records moved to the name that stayed.', 'estat-os' ) ),
			'error'            => array( 'error', '' !== $detail ? $detail : __( 'Something went wrong. Please check and try again.', 'estat-os' ) ),
			'forbidden'        => array( 'error', __( 'You do not have permission to do that.', 'estat-os' ) ),
		);
		$message = $messages[ $notice ] ?? null;
		if ( ! $message ) {
			return;
		}

		/*
		 * "Mistake?" needs an answer within reach, not a walk to another
		 * screen. When a sweep has just gone to the bin, this is the Undo —
		 * and it only appears while the offer is still open to this person.
		 */
		$undo = '';
		$token = isset( $_GET['estat_undo'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( is_array( $_GET['estat_undo'] ) ? '' : $_GET['estat_undo'] ) ) : '';
		if ( '' !== (string) $token && null !== \EstatOS\Data\Bin::undo_ids( (string) $token ) ) {
			$undo = sprintf(
				' <a class="button button-small" href="%1$s">%2$s</a>',
				esc_url(
					wp_nonce_url(
						add_query_arg(
							array(
								'estat_action' => 'undo_bin',
								'token'        => (string) $token,
							),
							admin_url( 'admin.php' )
						),
						'estat_undo_bin_' . (string) $token,
						'estat_nonce'
					)
				),
				esc_html__( 'Undo', 'estat-os' )
			);
		}

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s%3$s</p></div>',
			esc_attr( $message[0] ),
			esc_html( $message[1] ),
			$undo // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped pieces above.
		);
	}

	/**
	 * Open a card.
	 *
	 * @param string $title    Card title.
	 * @param string $subtitle Optional subtitle.
	 * @return void
	 */
	/**
	 * Begin a fold-away group of fields nobody needs on an ordinary day.
	 *
	 * Most properties are added with a name, a price and a locality. The rest
	 * of the fields exist for the one listing in twenty that needs them, and
	 * showing all of them at once is what makes the screen feel heavy. This
	 * tucks them behind a single line the office can open when they want it.
	 *
	 * @param string $title Plain-language summary of what is inside.
	 * @param string $note  Optional reassurance that skipping it is fine.
	 * @return void
	 */
	public static function extras_open( string $title, string $note = '', bool $open = false, int $fields = 0 ): void {
		if ( '' === $note ) {
			$note = __( 'You can leave all of this empty. It only changes what shows on the property page.', 'estat-os' );
		}
		/*
		 * The count says out loud how many boxes live behind the line. Without
		 * it the office cannot tell a group of two from a group of nine, and
		 * "where did the rest go?" is the first thing anyone asks a form that
		 * has just been made shorter.
		 */
		$count = $fields > 0
			? '<span class="estat-extras-count">' . esc_html( sprintf(
				/* translators: %d: number of fields inside this group. */
				_n( '%d field', '%d fields', $fields, 'estat-os' ),
				$fields
			) ) . '</span>'
			: '';
		printf(
			'<details class="estat-extras"%1$s><summary><span class="estat-extras-title">%2$s</span><span class="estat-extras-note">%3$s</span>%4$s</summary><div class="estat-extras-body">',
			$open ? ' open' : '',
			esc_html( $title ),
			esc_html( $note ),
			$count // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped pieces above.
		);
	}

	/**
	 * Is any of these fields already filled in?
	 *
	 * A group that holds real information must open by itself, otherwise the
	 * office reopens a listing, sees a short form, and reasonably concludes
	 * that the details they typed have been lost.
	 *
	 * @param array<int,mixed> $values Current values.
	 * @return bool
	 */
	public static function has_content( array $values ): bool {
		foreach ( $values as $value ) {
			if ( is_array( $value ) ) {
				if ( array() !== $value ) {
					return true;
				}
				continue;
			}
			$value = (string) $value;
			if ( '' !== $value && '0' !== $value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Close a fold-away group.
	 *
	 * @return void
	 */
	public static function extras_close(): void {
		echo '</div></details>';
	}

	public static function card_open( string $title = '', string $subtitle = '' ): void {
		echo '<section class="estat-card-panel">';
		if ( '' !== $title ) {
			echo '<h2>' . esc_html( $title ) . '</h2>';
		}
		if ( '' !== $subtitle ) {
			echo '<p class="description">' . esc_html( $subtitle ) . '</p>';
		}
	}

	/**
	 * Close a card.
	 *
	 * @return void
	 */
	public static function card_close(): void {
		echo '</section>';
	}

	/**
	 * A statistic tile.
	 *
	 * @param string $label    Label.
	 * @param string $value    Value.
	 * @param string $url      Optional link.
	 * @param string $tone     good|warn|plain.
	 * @return void
	 */
	public static function stat( string $label, string $value, string $url = '', string $tone = 'plain' ): void {
		$inner = '<span class="estat-stat-value">' . esc_html( $value ) . '</span><span class="estat-stat-label">' . esc_html( $label ) . '</span>';
		if ( '' !== $url ) {
			echo '<a class="estat-stat estat-stat-' . esc_attr( $tone ) . '" href="' . esc_url( $url ) . '">' . $inner . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}
		echo '<div class="estat-stat estat-stat-' . esc_attr( $tone ) . '">' . $inner . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * A labelled form field with help text and validation slot.
	 *
	 * @param array<string,mixed> $args name, label, type, value, help, example, required, options, rows.
	 * @return void
	 */
	public static function field( array $args ): void {
		$name     = (string) ( $args['name'] ?? '' );
		$id       = 'estat-' . sanitize_html_class( $name );
		$type     = (string) ( $args['type'] ?? 'text' );
		$value    = $args['value'] ?? '';
		$required = ! empty( $args['required'] );
		$help     = (string) ( $args['help'] ?? '' );
		$example  = (string) ( $args['example'] ?? '' );
		$options  = (array) ( $args['options'] ?? array() );

		/*
		 * A row can carry extra classes so a screen can hide it when it does
		 * not apply — a plot has no bedrooms, a sale has no deposit. The field
		 * still posts (hidden, not removed), so nothing is ever lost by
		 * answering one question differently.
		 */
		$wrap = 'estat-field-row';
		foreach ( array_filter( explode( ' ', (string) ( $args['wrap_class'] ?? '' ) ) ) as $extra_class ) {
			$wrap .= ' ' . sanitize_html_class( $extra_class );
		}
		?>
		<div class="<?php echo esc_attr( $wrap ); ?>">
			<label class="estat-field-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( (string) ( $args['label'] ?? '' ) ); ?>
				<?php if ( $required ) : ?>
					<span class="estat-required"><?php esc_html_e( 'required', 'estat-os' ); ?></span>
				<?php else : ?>
					<span class="estat-optional"><?php esc_html_e( 'optional', 'estat-os' ); ?></span>
				<?php endif; ?>
			</label>
			<?php
			switch ( $type ) {
				case 'textarea':
					?>
					<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="<?php echo esc_attr( (string) (int) ( $args['rows'] ?? 4 ) ); ?>" <?php echo $required ? 'required' : ''; ?> placeholder="<?php echo esc_attr( $example ); ?>"><?php echo esc_textarea( (string) $value ); ?></textarea>
					<?php
					break;
				case 'select':
					?>
					<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" <?php echo $required ? 'required' : ''; ?>>
						<?php foreach ( $options as $option_value => $option_label ) : ?>
							<option value="<?php echo esc_attr( (string) $option_value ); ?>" <?php selected( (string) $value, (string) $option_value ); ?>><?php echo esc_html( (string) $option_label ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php
					break;
				case 'checkbox':
					?>
					<label class="estat-inline-check">
						<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( (bool) $value ); ?> />
						<span><?php echo esc_html( (string) ( $args['checkbox_label'] ?? __( 'Yes', 'estat-os' ) ) ); ?></span>
					</label>
					<?php
					break;
				case 'image':
					$attachment_id = (int) $value;
					?>
					<?php $target = '#' . $id; ?>
					<div class="estat-image-picker" data-target="<?php echo esc_attr( $target ); ?>">
						<button
							type="button"
							class="estat-image-preview estat-pick-image"
							data-target="<?php echo esc_attr( $target ); ?>"
							aria-label="<?php esc_attr_e( 'Choose a photo', 'estat-os' ); ?>"
						>
							<?php if ( $attachment_id > 0 ) : ?>
								<?php echo wp_get_attachment_image( $attachment_id, 'medium' ); ?>
							<?php else : ?>
								<span class="estat-image-empty"><?php esc_html_e( 'Tap to choose a photo', 'estat-os' ); ?></span>
							<?php endif; ?>
						</button>
						<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $attachment_id ); ?>" />
						<button type="button" class="button estat-pick-image" data-target="<?php echo esc_attr( $target ); ?>"><?php esc_html_e( 'Choose a photo', 'estat-os' ); ?></button>
						<button type="button" class="button-link estat-clear-image" data-target="<?php echo esc_attr( $target ); ?>"><?php esc_html_e( 'Remove', 'estat-os' ); ?></button>
					</div>
					<?php
					break;
				case 'gallery':
					$ids = array_map( 'absint', (array) $value );
					?>
					<?php
					$target    = '#' . $id;
					$list_id   = $id . '-list';
					$list_href = '#' . $list_id;
					?>
					<div class="estat-gallery-picker" data-target="<?php echo esc_attr( $target ); ?>" data-list="<?php echo esc_attr( $list_href ); ?>">
						<ul class="estat-gallery-list" id="<?php echo esc_attr( $list_id ); ?>" data-target="<?php echo esc_attr( $target ); ?>">
							<?php foreach ( $ids as $attachment_id ) : ?>
								<li data-id="<?php echo esc_attr( (string) $attachment_id ); ?>" draggable="true" tabindex="0">
									<?php echo wp_get_attachment_image( (int) $attachment_id, 'thumbnail' ); ?>
									<button type="button" class="estat-gallery-remove" aria-label="<?php esc_attr_e( 'Remove this photo', 'estat-os' ); ?>">×</button>
								</li>
							<?php endforeach; ?>
						</ul>
						<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>" />
						<button type="button" class="button estat-pick-gallery" data-list="<?php echo esc_attr( $list_href ); ?>" data-target="<?php echo esc_attr( $target ); ?>"><?php esc_html_e( 'Add photos', 'estat-os' ); ?></button>
						<p class="description"><?php esc_html_e( 'Drag the photos to change their order. The first one is used as the main photo if you have not chosen one.', 'estat-os' ); ?></p>
					</div>
					<?php
					break;
				default:
					?>
					<input
						type="<?php echo esc_attr( $type ); ?>"
						id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( $name ); ?>"
						value="<?php echo esc_attr( (string) $value ); ?>"
						placeholder="<?php echo esc_attr( $example ); ?>"
						<?php echo $required ? 'required' : ''; ?>
						<?php echo isset( $args['min'] ) ? 'min="' . esc_attr( (string) $args['min'] ) . '"' : ''; ?>
						<?php echo isset( $args['max'] ) ? 'max="' . esc_attr( (string) $args['max'] ) . '"' : ''; ?>
						<?php echo isset( $args['step'] ) ? 'step="' . esc_attr( (string) $args['step'] ) . '"' : ''; ?>
					/>
					<?php
					break;
			}
			?>
			<?php if ( '' !== $help ) : ?>
				<p class="description"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
			<?php if ( '' !== $example && in_array( $type, array( 'select', 'checkbox' ), true ) ) : ?>
				<p class="description"><?php echo esc_html( sprintf( /* translators: %s: example value */ __( 'For example: %s', 'estat-os' ), $example ) ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * The highlight tick-boxes, grouped, with a live preview of what will end
	 * up on the property card.
	 *
	 * @param string[] $selected Slugs already ticked.
	 * @return void
	 */
	public static function highlights( array $selected = array() ): void {
		$groups = Highlights::by_group();
		$labels = Highlights::groups();
		?>
		<div class="estat-highlights" data-card-limit="<?php echo esc_attr( (string) Highlights::CARD_LIMIT ); ?>">
			<div class="estat-highlights-intro">
				<h3><?php esc_html_e( 'Highlights', 'estat-os' ); ?></h3>
				<p class="description">
					<?php
					printf(
						/* translators: %d: how many highlights appear on a card. */
						esc_html__( 'Tick whatever is true for this property. The first %d appear as small tags on the property card, so tick the strongest selling points first.', 'estat-os' ),
						(int) Highlights::CARD_LIMIT
					);
					?>
				</p>
			</div>

			<div class="estat-highlights-preview" aria-live="polite">
				<span class="estat-highlights-preview-label"><?php esc_html_e( 'On the card:', 'estat-os' ); ?></span>
				<span class="estat-highlights-preview-chips"></span>
			</div>

			<?php foreach ( $groups as $group => $items ) : ?>
				<fieldset class="estat-highlight-group">
					<legend><?php echo esc_html( $labels[ $group ] ?? ucfirst( $group ) ); ?></legend>
					<div class="estat-highlight-grid">
						<?php foreach ( $items as $slug => $item ) : ?>
							<label class="estat-highlight<?php echo in_array( $slug, $selected, true ) ? ' is-on' : ''; ?>">
								<input
									type="checkbox"
									name="highlights[]"
									value="<?php echo esc_attr( $slug ); ?>"
									data-label="<?php echo esc_attr( (string) $item['label'] ); ?>"
									data-icon="<?php echo esc_attr( (string) $item['icon'] ); ?>"
									<?php checked( in_array( $slug, $selected, true ) ); ?>
								/>
								<span class="estat-highlight-icon"><?php echo Icon::render( (string) $item['icon'], 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<span class="estat-highlight-text"><?php echo esc_html( (string) $item['label'] ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</fieldset>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Empty state block.
	 *
	 * @param string $message Message.
	 * @param string $action  Optional action URL.
	 * @param string $label   Action label.
	 * @return void
	 */
	/**
	 * The standard search-and-filter bar used by every list screen.
	 *
	 * Screens used to hand-write this row, which is why Listings, Enquiries and
	 * Site Visits all looked slightly different. They now describe what they
	 * need and get an identical bar.
	 *
	 * @param array<string,mixed> $args page, search, search_label, filters, count, action, action_url.
	 * @return void
	 */
	/**
	 * Open a form that wraps a list so its tick boxes can be acted on.
	 *
	 * @param string $page Page slug to return to.
	 * @return void
	 */
	/**
	 * The ticks, and the bar that acts on them, for a list of records.
	 *
	 * Everything a list of records can do in bulk lives inside one form:
	 * the row ticks, the bar, and the record of what was asked. The bar says
	 * what it will do in words ("Move 8 properties to bin?"), it appears only
	 * when something is ticked, and destructive choices are never the first
	 * thing a hand lands on.
	 *
	 * Two shapes, one markup:
	 *   active  a working list — Move to bin, and Change status where it applies
	 *   bin     the recycle bin — Restore, and Delete permanently
	 *
	 * @param string               $page Screen the form posts back to.
	 * @param array<string,mixed>  $args See self::bulk_defaults().
	 * @return void
	 */
	public static function bulk_open( string $page, array $args = array() ): void {
		self::$bulk = wp_parse_args( $args, self::bulk_defaults( $page ) );

		/*
		 * The form itself is printed at the end of the list (bulk_close),
		 * and the tick boxes point at it by name.
		 *
		 * Why not wrap the list in the form, as it used to: a list has row
		 * buttons of its own — Move to bin on every row — and those are
		 * little forms too. A form inside a form is not allowed in HTML:
		 * the browser throws the inner one away and quietly adopts its
		 * fields into the outer one, so pressing one row's Delete while
		 * anything else was ticked sent the ticked records along with it.
		 * One row, one press, one record — separated forms, and the ticks
		 * say where they belong with the form attribute.
		 */
	}

	/**
	 * The name the tick boxes use to find the bar's form.
	 *
	 * @return string
	 */
	private static function bulk_form_id(): string {
		$page = self::$bulk ? (string) ( self::$bulk['page'] ?? '' ) : '';

		return 'estat-bulk-' . ( '' !== $page ? $page : 'list' );
	}

	/**
	 * What a bulk form needs, in one place, with sensible defaults.
	 *
	 * @param string $page Screen slug.
	 * @return array<string,mixed>
	 */
	private static function bulk_defaults( string $page = '' ): array {
		return array(
			'page'     => $page,
			'word'     => __( 'records', 'estat-os' ),
			/*
			 * Ek record ke liye alag shabd. "Move 1 properties to bin?"
			 * galat angrezi hai — aur office ka banda isi sawaal par haan
			 * dabata hai, is liye jumla saaf hona chahiye.
			 */
			'word_one' => __( 'record', 'estat-os' ),
			'most'     => 100,
			'mode'     => 'active',
			'nonce'    => 'estat_bulk_records',
			'action'   => 'bin_records',
			'scope'    => array(),
			'can_bin'  => current_user_can( 'estat_bin_listings' ),
			'can_restore' => current_user_can( 'estat_restore_listings' ),
			'can_delete'  => current_user_can( 'estat_delete_listings' ),
			'can_status'  => current_user_can( 'estat_publish_listings' ),
		);
	}

	/**
	 * The bar, the confirmations, and the end of the form.
	 *
	 * @return void
	 */
	public static function bulk_close(): void {
		$bulk = self::$bulk ? self::$bulk : self::bulk_defaults();
		$is_bin = 'bin' === (string) $bulk['mode'];
		?>
		<form method="post" id="<?php echo esc_attr( self::bulk_form_id() ); ?>" class="estat-bulk-form"
			action="<?php echo esc_url( admin_url( 'admin.php?page=' . (string) $bulk['page'] ) ); ?>"
			data-estat-word="<?php echo esc_attr( (string) $bulk['word'] ); ?>"
			data-estat-word-one="<?php echo esc_attr( (string) ( $bulk['word_one'] ?? $bulk['word'] ) ); ?>"
			data-estat-most="<?php echo esc_attr( (string) (int) ( $bulk['most'] ?? 100 ) ); ?>"
			data-estat-mode="<?php echo esc_attr( (string) $bulk['mode'] ); ?>">
			<?php wp_nonce_field( (string) $bulk['nonce'], 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="<?php echo esc_attr( (string) $bulk['action'] ); ?>" class="estat-bulk-action" />
			<input type="hidden" name="back_page" value="<?php echo esc_attr( (string) $bulk['page'] ); ?>" />
			<input type="hidden" name="confirm_word" value="" class="estat-confirm-word-field" />
			<?php
			/*
			 * No "and all 240 of them" switch any more.
			 *
			 * It was honest — the server worked the list out from the same
			 * filters the screen drew — but it acted on records nobody
			 * could see, and that is the part that made the bar hard to
			 * trust. The bar now touches only what is ticked.
			 */
			?>
			<div class="estat-bulk-bar" hidden role="toolbar" aria-label="<?php esc_attr_e( 'What to do with the ticked ones', 'estat-os' ); ?>">
				<span class="estat-bulk-count" role="status" aria-live="polite"></span>
				<span class="estat-bulk-limit" hidden><?php esc_html_e( 'One press can move up to 100 at a time.', 'estat-os' ); ?></span>

				<div class="estat-bulk-actions">
					<?php if ( $is_bin ) : ?>
						<?php if ( $bulk['can_restore'] ) : ?>
							<button type="submit" class="estat-ui-btn-primary estat-bulk-do" name="estat_action" value="restore_records"
								data-estat-ask="<?php echo esc_attr__( 'Restore %1$d %2$s?', 'estat-os' ); ?>"
								data-estat-ask-note="<?php echo esc_attr__( 'They are in the bin. Each one goes back to the state it was in.', 'estat-os' ); ?>"
								data-estat-ask-label="<?php esc_attr_e( 'Restore', 'estat-os' ); ?>">
								<?php echo Icon::render( 'arrow-counter-clockwise', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Restore', 'estat-os' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</button>
						<?php endif; ?>
						<?php if ( $bulk['can_delete'] ) : ?>
							<button type="submit" class="estat-ui-btn estat-bulk-danger estat-bulk-do" name="estat_action" value="delete_forever"
								data-estat-ask="<?php echo esc_attr__( 'Delete %1$d %2$s permanently?', 'estat-os' ); ?>"
								data-estat-ask-note="<?php echo esc_attr__( 'This cannot be undone.', 'estat-os' ); ?>"
								data-estat-ask-word="DELETE"
								data-estat-ask-label="<?php esc_attr_e( 'Delete permanently', 'estat-os' ); ?>">
								<?php esc_html_e( 'Delete permanently', 'estat-os' ); ?>
							</button>
						<?php endif; ?>
					<?php else : ?>
						<?php if ( $bulk['can_bin'] ) : ?>
							<button type="submit" class="estat-ui-btn estat-bulk-do" name="estat_action" value="bin_records"
								data-estat-ask="<?php echo esc_attr__( 'Move %1$d %2$s to bin?', 'estat-os' ); ?>"
								data-estat-ask-note="<?php echo esc_attr__( 'They come off the website and can be restored from the bin.', 'estat-os' ); ?>"
								data-estat-ask-label="<?php esc_attr_e( 'Move to bin', 'estat-os' ); ?>">
								<?php esc_html_e( 'Move to bin', 'estat-os' ); ?>
							</button>
						<?php endif; ?>
					<?php endif; ?>

					<?php
					/*
					 * Changing the state of several records at once is the one
					 * bulk choice that is not about the bin, and it is kept
					 * behind a select so it cannot be pressed by accident.
					 */
					if ( ! $is_bin && $bulk['can_status'] ) :
						?>
						<span class="estat-bulk-status">
							<label class="screen-reader-text" for="estat-bulk-action"><?php esc_html_e( 'Which state to put them in', 'estat-os' ); ?></label>
							<select id="estat-bulk-action" name="bulk_action">
								<option value=""><?php esc_html_e( 'Change status…', 'estat-os' ); ?></option>
								<?php foreach ( Actions::bulk_operations() as $key => $operation ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $operation['label'] ); ?></option>
								<?php endforeach; ?>
							</select>
							<button type="submit" class="estat-ui-btn" name="estat_action" value="bulk_records"><?php esc_html_e( 'Apply', 'estat-os' ); ?></button>
						</span>
					<?php endif; ?>

					<button type="button" class="estat-ui-btn estat-bulk-clear"><?php esc_html_e( 'Cancel', 'estat-os' ); ?></button>
				</div>
			</div>
		</form>
		<?php
	}

	/** The choices the open bulk form was built with. */
	private static $bulk = array();

	/**
	 * The tick box in a table heading that selects every row on the page.
	 *
	 * It only ever means "this page". The wider choice — every property the
	 * filter is showing — is offered in the bar, in words, with the number
	 * in it. Silently ticking 240 rows because somebody ticked the top box
	 * is exactly the kind of surprise this feature must not have.
	 *
	 * @return void
	 */
	public static function bulk_header(): void {
		?>
		<th scope="col" class="estat-bulk-cell">
			<label class="screen-reader-text" for="estat-bulk-all"><?php esc_html_e( 'Tick every row on this page', 'estat-os' ); ?></label>
			<input type="checkbox" id="estat-bulk-all" class="estat-bulk-all"<?php echo self::$bulk ? ' form="' . esc_attr( self::bulk_form_id() ) . '"' : ''; ?> />
		</th>
		<?php
	}

	/**
	 * The tick box for one row. It carries the record's own ID, which is
	 * what the server acts on — the browser never decides which records
	 * exist or who may change them.
	 *
	 * @param int    $record_id Record ID.
	 * @param string $title     Record title, for the accessible name.
	 * @return void
	 */
	public static function bulk_cell( int $record_id, string $title ): void {
		$id = 'estat-tick-' . $record_id;
		?>
		<td class="estat-bulk-cell" data-label="<?php esc_attr_e( 'Tick', 'estat-os' ); ?>">
			<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>">
				<?php
				printf(
					/* translators: %s: the name of the record. */
					esc_html__( 'Tick %s', 'estat-os' ),
					esc_html( '' !== trim( $title ) ? $title : (string) $record_id )
				);
				?>
			</label>
			<input
				type="checkbox"
				id="<?php echo esc_attr( $id ); ?>"
				class="estat-bulk-tick"
				name="record_ids[]"
				value="<?php echo esc_attr( (string) $record_id ); ?>"
				<?php echo self::$bulk ? 'form="' . esc_attr( self::bulk_form_id() ) . '"' : ''; ?>
			/>
		</td>
		<?php
	}

	/**
	 * Page links under a list.
	 *
	 * Projects, Team and Spreadsheet each capped their list at a fixed number
	 * and showed nothing beyond it. An office with sixty projects saw fifty
	 * and had no way to reach the rest, and nothing on screen said so.
	 *
	 * @param int    $pages   Total number of pages.
	 * @param int    $current Current page.
	 * @param string $label   Accessible name for the navigation.
	 * @return void
	 */
	public static function pagination( int $pages, int $current, string $label ): void {
		if ( $pages < 2 ) {
			return;
		}

		$links = paginate_links(
			array(
				'total'   => $pages,
				'current' => max( 1, $current ),
				'type'    => 'array',
				'base'    => add_query_arg( 'paged', '%#%' ),
				'format'  => '',
			)
		);

		if ( ! is_array( $links ) ) {
			return;
		}

		echo '<nav class="estat-pagination" aria-label="' . esc_attr( $label ) . '"><ul>';
		foreach ( $links as $link ) {
			echo '<li>' . wp_kses_post( $link ) . '</li>';
		}
		echo '</ul></nav>';
	}

	public static function toolbar( array $args ): void {
		$page         = isset( $args['page'] ) ? (string) $args['page'] : '';
		$search       = isset( $args['search'] ) ? (string) $args['search'] : '';
		$search_label = isset( $args['search_label'] ) ? (string) $args['search_label'] : __( 'Search', 'estat-os' );
		$filters      = isset( $args['filters'] ) && is_array( $args['filters'] ) ? $args['filters'] : array();
		$hidden       = isset( $args['hidden'] ) && is_array( $args['hidden'] ) ? $args['hidden'] : array();
		$count        = isset( $args['count'] ) ? (int) $args['count'] : -1;
		$count_label  = isset( $args['count_label'] ) ? (string) $args['count_label'] : '';
		$action       = isset( $args['action'] ) ? (string) $args['action'] : '';
		$action_url   = isset( $args['action_url'] ) ? (string) $args['action_url'] : '';

		$id = 'estat-toolbar-' . sanitize_key( $page );
		?>
		<form method="get" class="estat-filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( $page ); ?>" />
			<?php foreach ( $hidden as $key => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( (string) $key ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" />
			<?php endforeach; ?>

			<?php if ( false !== ( $args['show_search'] ?? true ) ) : ?>
				<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>-s"><?php echo esc_html( $search_label ); ?></label>
				<input
					type="search"
					id="<?php echo esc_attr( $id ); ?>-s"
					name="s"
					value="<?php echo esc_attr( $search ); ?>"
					placeholder="<?php echo esc_attr( $search_label ); ?>"
				/>
			<?php endif; ?>

			<?php foreach ( $filters as $filter ) : ?>
				<?php
				$name    = (string) ( $filter['name'] ?? '' );
				$options = is_array( $filter['options'] ?? null ) ? $filter['options'] : array();
				$value   = (string) ( $filter['value'] ?? '' );
				$label   = (string) ( $filter['label'] ?? $name );

				if ( '' === $name || ! $options ) {
					continue;
				}
				?>
				<label class="screen-reader-text" for="<?php echo esc_attr( $id . '-' . $name ); ?>"><?php echo esc_html( $label ); ?></label>
				<select id="<?php echo esc_attr( $id . '-' . $name ); ?>" name="<?php echo esc_attr( $name ); ?>">
					<?php foreach ( $options as $option_value => $option_label ) : ?>
						<option value="<?php echo esc_attr( (string) $option_value ); ?>" <?php selected( $value, (string) $option_value ); ?>>
							<?php echo esc_html( (string) $option_label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			<?php endforeach; ?>

			<button type="submit" class="button"><?php esc_html_e( 'Show', 'estat-os' ); ?></button>

			<?php if ( '' !== $action && '' !== $action_url ) : ?>
				<a class="button button-primary" href="<?php echo esc_url( $action_url ); ?>"><?php echo esc_html( $action ); ?></a>
			<?php endif; ?>

			<?php if ( $count >= 0 ) : ?>
				<span class="estat-filter-count">
					<?php
					echo esc_html(
						'' !== $count_label
							? $count_label
							: sprintf(
								/* translators: %s: number of results. */
								_n( '%s result', '%s results', $count, 'estat-os' ),
								number_format_i18n( $count )
							)
					);
					?>
				</span>
			<?php endif; ?>
		</form>
		<?php
	}

	/**
	 * WordPress post status in the words the office uses.
	 *
	 * Screens were printing the raw value ("publish") next to other screens
	 * that printed "Live", so the same record looked like two different things.
	 *
	 * @param string $status WordPress post status.
	 * @return string
	 */
	public static function record_status_label( string $status ): string {
		// One word per state, decided in one place (Support\Status), so the
		// office, the phone, the emails and the website can never disagree.
		return \EstatOS\Support\Status::label( \EstatOS\Support\Status::PUBLICATION, $status );
	}

	/**
	 * The ways to bring a record back, or to end it for good.
	 *
	 * Both are forms rather than links: a permanent delete asks for the word
	 * DELETE to be typed, and a word cannot be typed into a link. Nothing
	 * here is offered to somebody who is not allowed to do it, and the
	 * server checks again when the press arrives.
	 *
	 * @param int $record_id Record ID.
	 * @return void
	 */
	public static function bin_row_actions( int $record_id ): void {
		$post = get_post( $record_id );
		if ( ! $post ) {
			return;
		}

		$page = self::$bulk ? (string) ( self::$bulk['page'] ?? 'estat-bin' ) : 'estat-bin';

		if ( \EstatOS\Data\Bin::may_restore( $post ) ) {
			?>
			<form method="post" class="estat-row-form" action="<?php echo esc_url( admin_url( 'admin.php?page=' . $page ) ); ?>">
				<?php wp_nonce_field( 'estat_restore_records', 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="restore_records" />
				<input type="hidden" name="record_id" value="<?php echo esc_attr( (string) $record_id ); ?>" />
				<?php
				/*
				 * Where to come back to, said out loud. WordPress refuses a
				 * referer that is the same address as the request, and these
				 * forms post back to the screen they were pressed on — so
				 * without this the office was thrown to the Properties list
				 * after restoring something from the bin.
				 */
				?>
				<input type="hidden" name="back_page" value="<?php echo esc_attr( $page ); ?>" />
				<button type="submit" class="estat-ui-btn estat-ui-btn-tiny estat-bulk-do"
					data-estat-ask="<?php echo esc_attr__( 'Restore this property?', 'estat-os' ); ?>"
					data-estat-ask-note="<?php echo esc_attr__( 'It is in the bin. Restoring it returns it to the state it was in.', 'estat-os' ); ?>"
					data-estat-ask-label="<?php esc_attr_e( 'Restore', 'estat-os' ); ?>">
					<?php esc_html_e( 'Restore', 'estat-os' ); ?>
				</button>
			</form>
			<?php
		}

		if ( \EstatOS\Data\Bin::may_delete( $post ) ) {
			?>
			<form method="post" class="estat-row-form" action="<?php echo esc_url( admin_url( 'admin.php?page=' . $page ) ); ?>">
				<?php wp_nonce_field( 'estat_delete_forever', 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="delete_forever" />
				<input type="hidden" name="record_id" value="<?php echo esc_attr( (string) $record_id ); ?>" />
				<input type="hidden" name="back_page" value="<?php echo esc_attr( $page ); ?>" />
				<input type="hidden" name="confirm_word" value="" class="estat-confirm-word-field" />
				<button type="submit" class="estat-ui-btn estat-ui-btn-tiny estat-bulk-danger estat-bulk-do"
					data-estat-ask="<?php echo esc_attr__( 'Delete this property permanently?', 'estat-os' ); ?>"
					data-estat-ask-note="<?php echo esc_attr__( 'This cannot be undone.', 'estat-os' ); ?>"
					data-estat-ask-word="DELETE"
					data-estat-ask-label="<?php esc_attr_e( 'Delete permanently', 'estat-os' ); ?>">
					<?php esc_html_e( 'Delete permanently', 'estat-os' ); ?>
				</button>
			</form>
			<?php
		}
	}

	/**
	 * The Move to bin press for one record.
	 *
	 * The word the agent presses says what happens and nothing more: the
	 * property leaves the website and waits in the bin. It is never called
	 * Delete, because it is not one.
	 *
	 * @param int    $record_id Record ID.
	 * @param string $page      Screen to come back to.
	 * @return void
	 */
	public static function move_to_bin_button( int $record_id, string $page = '' ): void {
		$post = get_post( $record_id );
		if ( ! $post || ! \EstatOS\Data\Bin::may_move( $post ) ) {
			return;
		}

		if ( '' === $page ) {
			$page = self::$bulk ? (string) ( self::$bulk['page'] ?? 'estat-listings' ) : 'estat-listings';
		}

		$restore = \EstatOS\Data\Bin::may_restore( $post );
		?>
		<form method="post" class="estat-row-form" action="<?php echo esc_url( admin_url( 'admin.php?page=' . $page ) ); ?>">
			<?php wp_nonce_field( 'estat_bin_records', 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="bin_records" />
			<input type="hidden" name="record_id" value="<?php echo esc_attr( (string) $record_id ); ?>" />
			<input type="hidden" name="back_page" value="<?php echo esc_attr( $page ); ?>" />
			<button type="submit" class="estat-ui-icon-btn estat-bulk-do"
				title="<?php esc_attr_e( 'Move to bin', 'estat-os' ); ?>"
				aria-label="<?php esc_attr_e( 'Move to bin', 'estat-os' ); ?>"
				data-estat-ask="<?php echo esc_attr__( 'Move this property to bin?', 'estat-os' ); ?>"
				data-estat-ask-note="<?php echo esc_attr( $restore
					? __( 'It comes off the website and waits in the bin. You can bring it back.', 'estat-os' )
					: __( 'It comes off the website and waits in the bin.', 'estat-os' ) ); ?>"
				data-estat-ask-label="<?php esc_attr_e( 'Move to bin', 'estat-os' ); ?>">
				<?php echo Icon::render( 'archive-box', 18, 'estat-ms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built in Support\Icon. ?>
			</button>
		</form>
		<?php
	}

	/**
	 * The actions on a row of the working list: edit, view, and move to bin.
	 *
	 * A record already in the bin is not shown here at all — it lives on the
	 * Bin screen, where bringing it back and deleting it for good are the two
	 * things on offer.
	 *
	 * @param int    $record_id Record ID.
	 * @param string $status    Current post status.
	 * @return void
	 */
	public static function record_actions( int $record_id, string $status ): void {
		if ( 'trash' === $status ) {
			self::bin_row_actions( $record_id );
			return;
		}

		// Only offered when there is genuinely something to go back to, so the
		// button never promises something it cannot do.
		if ( Undo::available( $record_id ) ) {
			$undo = wp_nonce_url(
				admin_url( 'admin.php?estat_action=undo_record&record_id=' . $record_id ),
				'estat_undo_record_' . $record_id,
				'estat_nonce'
			);
			printf(
				'<a class="button button-small" href="%1$s" data-estat-confirm="%2$s">%3$s</a> ',
				esc_url( $undo ),
				esc_attr__( 'This puts the details back to how they were before the last save. Carry on?', 'estat-os' ),
				esc_html__( 'Undo last edit', 'estat-os' )
			);
		}

		self::move_to_bin_button( $record_id );
	}

	/**
	 * The one confirmation dialog a page needs.
	 *
	 * Drawn once, outside every form, so any button on the screen can ask a
	 * question that names what is about to happen and how many records it
	 * touches. Nothing destructive in this plugin happens from a single
	 * press: the question is asked, in the office's own words, and for
	 * permanent deletion it asks for the word DELETE to be typed out.
	 *
	 * @return void
	 */
	public static function confirm_panel(): void {
		?>
		<div class="estat-confirm" data-estat-confirm hidden>
			<div class="estat-confirm-card" role="dialog" aria-modal="true" aria-labelledby="estat-confirm-title">
				<h2 class="estat-confirm-title" id="estat-confirm-title"></h2>
				<p class="estat-confirm-text"></p>
				<div class="estat-confirm-typed" hidden>
					<label class="estat-confirm-word" for="estat-confirm-word"></label>
					<input type="text" id="estat-confirm-word" autocomplete="off" spellcheck="false" />
					<p class="estat-confirm-typed-error" hidden><?php esc_html_e( 'That is not the word. Nothing has been deleted.', 'estat-os' ); ?></p>
				</div>
				<div class="estat-confirm-buttons">
					<button type="button" class="estat-ui-btn-primary estat-confirm-go"></button>
					<button type="button" class="estat-ui-btn estat-confirm-stop"><?php esc_html_e( 'Cancel', 'estat-os' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}

	public static function empty_state( $message, string $action = '', string $label = '' ): void {
		// Screens may pass a plain sentence (the original form) or a fuller
		// description. Both are supported so no screen had to change.
		$args = is_array( $message ) ? $message : array( 'message' => (string) $message );

		$title   = isset( $args['title'] ) ? (string) $args['title'] : '';
		$text    = isset( $args['message'] ) ? (string) $args['message'] : '';
		$icon    = isset( $args['icon'] ) ? (string) $args['icon'] : '';
		$action  = isset( $args['action'] ) ? (string) $args['action'] : $action;
		$label   = isset( $args['label'] ) ? (string) $args['label'] : $label;
		$hint    = isset( $args['hint'] ) ? (string) $args['hint'] : '';
		$steps   = isset( $args['steps'] ) && is_array( $args['steps'] ) ? $args['steps'] : array();
		$is_fine = ! empty( $args['reassuring'] );

		echo '<div class="estat-empty-state' . ( $is_fine ? ' is-reassuring' : '' ) . '">';

		if ( '' !== $icon ) {
			echo '<span class="estat-empty-icon">' . Icon::render( $icon, 40 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( '' !== $title ) {
			echo '<p class="estat-empty-title">' . esc_html( $title ) . '</p>';
		}

		if ( '' !== $text ) {
			echo '<p class="estat-empty-text">' . esc_html( $text ) . '</p>';
		}

		// A short numbered path out of the empty screen beats a dead end.
		if ( $steps ) {
			echo '<ol class="estat-empty-steps">';
			foreach ( $steps as $step ) {
				echo '<li>' . esc_html( (string) $step ) . '</li>';
			}
			echo '</ol>';
		}

		if ( '' !== $action && '' !== $label ) {
			echo '<a class="button button-primary" href="' . esc_url( $action ) . '">' . esc_html( $label ) . '</a>';
		}

		if ( '' !== $hint ) {
			echo '<p class="estat-empty-hint">' . esc_html( $hint ) . '</p>';
		}

		echo '</div>';
	}
}
