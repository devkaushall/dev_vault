<?php
/**
 * Today — the office the office Atelier redesign.
 * Real data only, no fake portfolio volume.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Worklist;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class TodayNew {

	private static function greeting_name( $user ): string {
		$first = isset( $user->first_name ) ? trim( (string) $user->first_name ) : '';
		if ( '' !== $first ) { return $first; }
		$display = isset( $user->display_name ) ? trim( (string) $user->display_name ) : '';
		return '' !== $display ? $display : __( 'there', 'estat-os' );
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see the office dashboard.', 'estat-os' ) );
		}


		$user = wp_get_current_user();
		$listings = (array) wp_count_posts( PostTypes::LISTING );
		$live = (int) ( $listings['publish'] ?? 0 );
		$drafts = (int) ( $listings['draft'] ?? 0 );
		$leads_counts = Leads::counts();
		$visits_counts = Visits::counts();
		$new_enquiries = (int) ( $leads_counts['new'] ?? 0 );
		$visits_today = (int) ( $visits_counts['today'] ?? 0 );
		$s = Settings::all();
		$city = (string) ( $s['city'] ?? $s['cities'][0] ?? '' );
		$office_name = (string) ( $s['office_name'] ?? '' );

		$worklist = Worklist::tasks();
		$recent_leads = Leads::query( array( 'per_page'=>2, 'page'=>1, 'status'=>'new' ) );
		$today_visits = Visits::query( array( 'per_page'=>3, 'page'=>1, 'date'=>'today' ) );
		$recent_listings_q = new \WP_Query( array( 'post_type'=>PostTypes::LISTING, 'post_status'=>array('publish','draft'), 'posts_per_page'=>3, 'orderby'=>'modified', 'order'=>'DESC' ) );

		?>
		<div class="estat-ui-team">
			<div class="estat-ui-page-header is-today">
				<div class="estat-ui-breadcrumb">
					<span class="estat-ui-dot-accent"></span>
					<?php esc_html_e( "Today's overview", 'estat-os' ); ?>
				</div>
				<div class="estat-ui-header-row">
					<div>
						<h1 class="estat-ui-h1"><?php esc_html_e( 'Today', 'estat-os' ); ?></h1>
						<p class="estat-ui-desc"><?php printf( esc_html__( 'Good day, %s. Here is what needs your attention today.', 'estat-os' ), esc_html( self::greeting_name( $user ) ) ); ?><?php if ( '' !== $office_name ) { echo ' ' . esc_html( $office_name ); } ?><?php if ( '' !== $city ) { echo ' — ' . esc_html( $city ); } ?></p>
					</div>
					<div class="estat-ui-header-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-ui-btn"><?php echo \EstatOS\Support\Icon::render( 'filter', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Filter view', 'estat-os' ); ?></a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-add-home' ) ); ?>" class="estat-ui-btn-primary"><?php echo \EstatOS\Support\Icon::render( 'plus', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Add a home', 'estat-os' ); ?></a>
					</div>
				</div>
			</div>

			<div class="estat-ui-metrics">
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Live properties', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $live ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Live on website', 'estat-os' ); ?></span></div>
					<span class="estat-ui-metric-hint"><?php esc_html_e( 'Everything in one place', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Scheduled today', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $visits_today ); ?></span><span class="estat-ui-badge"><?php esc_html_e( 'Site visits', 'estat-os' ); ?></span></div>
					<span class="estat-ui-metric-hint"><?php esc_html_e( 'Next visits', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Enquiries awaiting', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $new_enquiries ); ?></span><span class="estat-ui-badge is-alert"><?php esc_html_e( 'New', 'estat-os' ); ?></span></div>
					<span class="estat-ui-metric-hint"><?php esc_html_e( 'Not assigned yet', 'estat-os' ); ?></span>
				</div>
				<div class="estat-ui-metric">
					<span class="estat-ui-metric-label"><?php esc_html_e( 'Pending review', 'estat-os' ); ?></span>
					<div class="estat-ui-metric-value"><span class="estat-ui-metric-num"><?php echo esc_html( (string) $drafts ); ?></span><span class="estat-ui-metric-sub"><?php esc_html_e( 'Draft listings', 'estat-os' ); ?></span></div>
					<span class="estat-ui-metric-hint"><?php esc_html_e( 'Waiting for your OK', 'estat-os' ); ?></span>
				</div>
			</div>

			<div class="estat-ui-today-grid">
				<div class="estat-ui-today-main">
					<?php if ( ! empty( $worklist ) ) : ?>
					<div class="estat-ui-card-panel">
						<div class="estat-ui-panel-header">
							<?php echo \EstatOS\Support\Icon::render( 'alert', 18, 'estat-ms' ); ?>
							<h2><?php esc_html_e( 'Needs attention', 'estat-os' ); ?></h2>
							<span class="estat-ui-badge"><?php echo esc_html( sprintf( __( '%d need attention', 'estat-os' ), count( $worklist ) ) ); ?></span>
						</div>
						<div class="estat-ui-list">
							<?php foreach ( $worklist as $item ) : ?>
							<div class="estat-ui-list-item">
								<span class="estat-ui-list-icon"><?php echo \EstatOS\Support\Icon::render( 'document', 18, 'estat-ms' ); ?></span>
								<div class="estat-ui-list-body">
									<h3><?php echo esc_html( $item['title'] ?? '' ); ?></h3>
									<p><?php echo esc_html( $item['detail'] ?? '' ); ?></p>
								</div>
								<a href="<?php echo esc_url( $item['url'] ?? '#' ); ?>" class="estat-ui-btn"><?php echo esc_html( $item['action'] ?? __( 'Open', 'estat-os' ) ); ?></a>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
					<?php endif; ?>

					<div class="estat-ui-card-panel">
						<div class="estat-ui-panel-header">
							<?php echo \EstatOS\Support\Icon::render( 'calendar', 18, 'estat-ms' ); ?>
							<h2><?php esc_html_e( "Today's visits", 'estat-os' ); ?></h2>
							<span class="estat-ui-muted"><?php echo esc_html( sprintf( __( '%d remaining', 'estat-os' ), $visits_today ) ); ?></span>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-visits' ) ); ?>" class="estat-ui-link"><?php esc_html_e( 'See all site visits', 'estat-os' ); ?> <?php echo \EstatOS\Support\Icon::render( 'arrow-right', 18, 'estat-ms' ); ?></a>
						</div>
						<div class="estat-ui-list">
							<?php if ( empty( $today_visits['items'] ) ) : ?>
								<p class="estat-ui-muted" style="padding:16px"><?php esc_html_e( 'No visits scheduled for today.', 'estat-os' ); ?></p>
							<?php else : foreach ( $today_visits['items'] as $visit ) : ?>
							<div class="estat-ui-list-item is-visit">
								<div class="estat-ui-time"><span class="estat-ui-time-h"><?php echo esc_html( substr( (string) ( $visit['scheduled_at'] ?? '' ), 11, 5 ) ?: '—' ); ?></span></div>
								<div class="estat-ui-list-body">
									<h3><?php echo esc_html( $visit['listing_title'] ?? (string) ( $visit['listing_id'] ?? '' ) ); ?></h3>
									<div class="estat-ui-visit-meta"><span><?php esc_html_e( 'Visitor:', 'estat-os' ); ?> <?php echo esc_html( $visit['lead_name'] ?? '' ); ?></span><span><?php esc_html_e( 'Team member:', 'estat-os' ); ?> <?php echo esc_html( $visit['agent_name'] ?? '' ); ?></span></div>
								</div>
								<span class="estat-ui-status is-publish"><span class="estat-ui-dot"></span> <?php echo esc_html( $visit['outcome'] ?? __( 'Confirmed', 'estat-os' ) ); ?></span>
							</div>
							<?php endforeach; endif; ?>
						</div>
					</div>
				</div>

				<div class="estat-ui-today-side">
					<div class="estat-ui-card-panel">
						<div class="estat-ui-panel-header">
							<?php echo \EstatOS\Support\Icon::render( 'inbox', 18, 'estat-ms' ); ?>
							<h2><?php esc_html_e( 'Recent enquiries', 'estat-os' ); ?></h2>
							<span class="estat-ui-muted"><?php echo esc_html( sprintf( __( '%d pending', 'estat-os' ), $new_enquiries ) ); ?></span>
						</div>
						<div class="estat-ui-list">
							<?php if ( empty( $recent_leads['items'] ) ) : ?>
								<p class="estat-ui-muted" style="padding:16px"><?php esc_html_e( 'No recent enquiries.', 'estat-os' ); ?></p>
							<?php else : foreach ( $recent_leads['items'] as $lead ) : ?>
							<div class="estat-ui-enquiry">
								<div class="estat-ui-enquiry-head"><span class="estat-ui-enquiry-name"><?php echo esc_html( $lead['name'] ?? '' ); ?></span><span class="estat-ui-muted"><?php echo esc_html( $lead['created_at'] ?? '' ); ?></span></div>
								<div class="estat-ui-enquiry-prop"><?php echo \EstatOS\Support\Icon::render( 'buildings', 18, 'estat-ms' ); ?> <?php echo esc_html( $lead['listing_title'] ?? '' ); ?></div>
								<?php if ( ! empty( $lead['message'] ) ) : ?><div class="estat-ui-enquiry-msg">“<?php echo esc_html( mb_substr( (string) $lead['message'], 0, 80 ) ); ?>”</div><?php endif; ?>
								<div class="estat-ui-enquiry-actions"><a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-enquiries&lead_id=' . $lead['id'] ) ); ?>" class="estat-ui-btn small"><?php echo \EstatOS\Support\Icon::render( 'eye', 18, 'estat-ms' ); ?> <?php esc_html_e( 'Review', 'estat-os' ); ?></a></div>
							</div>
							<?php endforeach; endif; ?>
						</div>
					</div>

					<div class="estat-ui-card-panel">
						<div class="estat-ui-panel-header">
							<?php echo \EstatOS\Support\Icon::render( 'clock', 18, 'estat-ms' ); ?>
							<h2><?php esc_html_e( 'Recently updated listings', 'estat-os' ); ?></h2>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>" class="estat-ui-link"><?php esc_html_e( 'All listings', 'estat-os' ); ?></a>
						</div>
						<div class="estat-ui-list">
							<?php while ( $recent_listings_q->have_posts() ) : $recent_listings_q->the_post(); $id = get_the_ID(); ?>
							<div class="estat-ui-list-item small">
								<div class="estat-ui-list-body">
									<h3><?php echo esc_html( get_the_title() ); ?></h3>
									<p><?php esc_html_e( 'Updated', 'estat-os' ); ?> <?php echo esc_html( get_the_modified_date() ); ?></p>
								</div>
								<span class="estat-ui-badge"><?php echo esc_html( Partials::record_status_label( (string) get_post_status() ) ); ?></span>
							</div>
							<?php endwhile; wp_reset_postdata(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
