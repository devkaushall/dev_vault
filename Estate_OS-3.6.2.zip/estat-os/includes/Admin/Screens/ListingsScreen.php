<?php
/**
 * Listings: the list, and the advanced editor organised into three chapters.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Screens;

use EstatOS\Data\Listings;
use EstatOS\Data\Meta;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Field\Requests;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;
use EstatOS\Data\Picker;

defined( 'ABSPATH' ) || exit;

/**
 * The list is a plain table with mobile-friendly stacking; the editor uses
 * three chapters rather than a wall of tabs.
 */
final class ListingsScreen {

	/**
	 * Render either the list or the editor.
	 *
	 * @return void
	 */
	public static function render(): void {
		// The editor below checks per-record permission; the list itself was
		// checking nothing at all and relied on the menu capability.
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			wp_die( esc_html__( 'You do not have permission to see listings.', 'estat-os' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$edit_id = isset( $_GET['edit'] ) ? absint( wp_unslash( is_array($_GET['edit']) ? '' : $_GET['edit'] ) ) : 0;
		if ( $edit_id > 0 ) {
			self::editor( $edit_id );
			return;
		}
		self::listing_table();
	}

	/**
	 * What still needs filling, on the screen the office opens anyway.
	 *
	 * The website, the filters and the search engines all read the same record,
	 * so the gaps are listed here rather than discovered by a visitor. The list
	 * can be downloaded, fixed in Excel and imported back — the reference
	 * number makes that an update rather than a second property.
	 *
	 * @return void
	 */
	private static function attention_card(): void {
		$summary = \EstatOS\Data\Health::summary();
		if ( 0 === (int) $summary['flagged'] ) {
			return;
		}
		$rows = \EstatOS\Data\Health::attention( 12 );

		Partials::card_open(
			sprintf(
				/* translators: 1: how many properties need filling, 2: how many of those are serious */
				_n( '%1$d property needs filling in (%2$d of them matter)', '%1$d properties need filling in (%2$d of them matter)', (int) $summary['flagged'], 'estat-os' ),
				(int) $summary['flagged'],
				(int) $summary['serious']
			),
			__( 'The website, the property filters and the search engines all read this record. What is missing here is missing everywhere.', 'estat-os' )
		);

		$rules = \EstatOS\Data\Health::rules();
		echo '<table class="widefat estat-table estat-table-cards"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Property', 'estat-os' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'What is missing', 'estat-os' ) . '</th>';
		echo '<th scope="col"></th>';
		echo '</tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$chips = array();
			foreach ( (array) $row['keys'] as $key ) {
				$rule    = $rules[ $key ] ?? array( 'label' => (string) $key, 'level' => 'medium' );
				$classes = 'high' === (string) $rule['level'] ? 'estat-ui-chip is-danger' : 'estat-ui-chip is-warning';
				$chips[] = '<span class="' . esc_attr( $classes ) . '" title="' . esc_attr( (string) ( $rule['hint'] ?? '' ) ) . '">' . esc_html( (string) $rule['label'] ) . '</span>';
			}
			echo '<tr>';
			echo '<th scope="row" data-label="' . esc_attr__( 'Property', 'estat-os' ) . '"><a href="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . (int) $row['id'] ) ) . '">' . esc_html( (string) $row['title'] ) . '</a>';
			if ( 'publish' !== $row['status'] ) {
				echo '<br><span class="estat-ui-quiet">' . esc_html( Partials::record_status_label( (string) $row['status'] ) ) . '</span>';
			}
			echo '</th>';
			echo '<td data-label="' . esc_attr__( 'What is missing', 'estat-os' ) . '">' . implode( ' ', $chips ) . '</td>';
			echo '<td><a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . (int) $row['id'] ) ) . '">' . esc_html__( 'Fill it in', 'estat-os' ) . '</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		if ( (int) $summary['flagged'] > count( $rows ) ) {
			echo '<p class="estat-ui-quiet">' . esc_html( sprintf( /* translators: %d: how many are not shown */ __( '…and %d more. Download the list to see every one.', 'estat-os' ), (int) $summary['flagged'] - count( $rows ) ) ) . '</p>';
		}

		$csv = wp_nonce_url( admin_url( 'admin.php?page=estat-listings&estat_action=health_csv' ), 'estat_health_csv', 'estat_nonce' );
		echo '<p class="estat-ui-actions">';
		echo '<a class="button" href="' . esc_url( $csv ) . '">' . esc_html__( 'Download this list (CSV)', 'estat-os' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=estat-spreadsheet' ) ) . '">' . esc_html__( 'Fix it in Excel and import it back', 'estat-os' ) . '</a>';
		echo '</p>';
		Partials::card_close();
	}

	/**
	 * The same list, for one record, inside its own editor.
	 *
	 * @param int $listing_id Listing ID.
	 * @return void
	 */
	private static function attention_note( int $listing_id ): void {
		$keys = \EstatOS\Data\Health::of( $listing_id );
		if ( ! $keys ) {
			return;
		}
		$rules = \EstatOS\Data\Health::rules();
		echo '<ul class="estat-ui-quiet-list">';
		foreach ( $keys as $key ) {
			$rule = $rules[ $key ] ?? null;
			if ( ! $rule ) {
				continue;
			}
			echo '<li><strong>' . esc_html( (string) $rule['label'] ) . '</strong> — ' . esc_html( (string) $rule['hint'] ) . '</li>';
		}
		echo '</ul>';
	}

	/**
	 * The listing table with simple filters.
	 *
	 * @return void
	 */
	private static function listing_table(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( is_array($_GET['status']) ? '' : $_GET['status'] ) ) : 'any';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array($_GET['s']) ? '' : $_GET['s'] ) ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( is_array($_GET['paged']) ? '' : $_GET['paged'] ) ) ) : 1;
		// phpcs:enable

		self::attention_card();

		$query = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				// The normal list never shows the bin. A binned property is not a
				// state of a working property; it has its own screen.
				'post_status'    => in_array( $status, array( 'publish', 'draft', 'pending', 'private' ), true ) ? $status : array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 20,
				'paged'          => $paged,
				's'              => $search,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		?>
		<?php
		Partials::toolbar(
			array(
				'page'         => 'estat-listings',
				'search'       => $search,
				'search_label' => __( 'Search by name or locality', 'estat-os' ),
				'count'        => (int) $query->found_posts,
				'action'       => __( 'Add a Home', 'estat-os' ),
				'action_url'   => admin_url( 'admin.php?page=estat-add-home' ),
				'filters'      => array(
					array(
						'name'    => 'status',
						'label'   => __( 'Filter by state', 'estat-os' ),
						'value'   => $status,
						'options' => array(
							'any'     => __( 'All properties', 'estat-os' ),
							'publish' => __( 'Live', 'estat-os' ),
							'draft'   => __( 'Drafts', 'estat-os' ),
							'pending' => __( 'Waiting for approval', 'estat-os' ),
							'private' => __( 'Paused', 'estat-os' ),
						),
					),
				),
			)
		);
		?>
		<?php

		if ( ! $query->have_posts() ) {
			// A search that found nothing is a very different problem from
			// having no properties at all, and needs a different way out.
			$searching = '' !== $search || 'any' !== $status;

			Partials::empty_state(
				$searching
					? array(
						'icon'    => 'search',
						'title'   => __( 'Nothing matched', 'estat-os' ),
						'message' => __( 'No property matches what you searched for. Try a shorter word, or clear the filters to see everything.', 'estat-os' ),
						'action'  => admin_url( 'admin.php?page=estat-listings' ),
						'label'   => __( 'Clear the filters', 'estat-os' ),
					)
					: array(
						'icon'       => 'home',
						'title'      => __( 'No properties yet', 'estat-os' ),
						'message'    => __( 'This is where every property in your office will live. Adding the first one takes about a minute.', 'estat-os' ),
						'reassuring' => true,
						'steps'      => array(
							__( 'Add a home with its headline, price and locality.', 'estat-os' ),
							__( 'Add a photo or two so it looks inviting.', 'estat-os' ),
							__( 'Publish it when you are happy with it.', 'estat-os' ),
						),
						'action'     => admin_url( 'admin.php?page=estat-add-home' ),
						'label'      => __( 'Add a Home', 'estat-os' ),
						'hint'       => __( 'Already have a spreadsheet of properties? You can import it instead.', 'estat-os' ),
					)
			);
			return;
		}

		// Whose list is this? Somebody who may move properties to the bin may
		// tick rows; the buttons in the bar are decided again inside it, and
		// again on the server for every record.
		$may_bulk = current_user_can( 'estat_bin_listings' );

		if ( $may_bulk ) {
			Partials::bulk_open(
				'estat-listings',
				array(
					'word'     => __( 'properties', 'estat-os' ),
					'word_one' => __( 'property', 'estat-os' ),
					'mode'   => 'active',
					'nonce'  => 'estat_bulk_records',
					'action' => 'bin_records',
				)
			);
		}
		?>
		<table class="widefat estat-table estat-table-cards">
			<caption class="screen-reader-text"><?php esc_html_e( 'Your listings', 'estat-os' ); ?></caption>
			<thead>
				<tr>
					<?php
					if ( $may_bulk ) {
						Partials::bulk_header();
					}
					?>
					<th scope="col"><?php esc_html_e( 'Property', 'estat-os' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Price', 'estat-os' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Where', 'estat-os' ); ?></th>
					<th scope="col"><?php esc_html_e( 'State', 'estat-os' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Readiness', 'estat-os' ); ?></th>
					<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'estat-os' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();
					$id       = (int) get_the_ID();
					$data     = Listings::to_array( $id, true );
					$locality = ! empty( $data['locality'] ) ? implode( ', ', (array) $data['locality'] ) : '—';
					$score    = (int) $data['completeness'];
					?>
					<tr>
						<?php
						if ( $may_bulk ) {
							Partials::bulk_cell( $id, (string) get_the_title() );
						}
						?>
						<th scope="row" data-label="<?php esc_attr_e( 'Property', 'estat-os' ); ?>">
							<a class="row-title" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>"><?php echo esc_html( get_the_title() ); ?></a>
							<div class="estat-muted"><?php echo esc_html( Vocabulary::label( 'property_types', (string) $data['property_type'] ) . ' · ' . Vocabulary::label( 'offers', (string) $data['offer'] ) ); ?>
							<?php if ( 'office_verified' === (string) $data['verification'] ) : ?> <span class="estat-ui-chip is-positive" title="<?php esc_attr_e( 'humne khud dekha', 'estat-os' ); ?>">✓ <?php esc_html_e( 'Verified — humne khud dekha', 'estat-os' ); ?></span><?php endif; ?>
							</div>
						</th>
						<td data-label="<?php esc_attr_e( 'Price', 'estat-os' ); ?>"><?php echo esc_html( (string) $data['price_display'] ); ?></td>
						<td data-label="<?php esc_attr_e( 'Where', 'estat-os' ); ?>"><?php echo esc_html( $locality ); ?></td>
						<td data-label="<?php esc_attr_e( 'State', 'estat-os' ); ?>">
							<?php
							echo esc_html( \EstatOS\Support\Status::label( \EstatOS\Support\Status::PUBLICATION, (string) get_post_status() ) );
							?>
							<div class="estat-muted"><?php echo esc_html( Vocabulary::label( 'availability', (string) $data['availability'] ) ); ?></div>
						</td>
						<td data-label="<?php esc_attr_e( 'Readiness', 'estat-os' ); ?>">
							<span class="estat-pill <?php echo $score >= 70 ? 'is-good' : 'is-warn'; ?>"><?php echo esc_html( $score . '%' ); ?></span>
						</td>
						<td data-label="<?php esc_attr_e( 'Actions', 'estat-os' ); ?>">
							<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $id ) ); ?>"><?php esc_html_e( 'Edit', 'estat-os' ); ?></a>
							<a class="button button-small" href="<?php echo esc_url( (string) get_permalink( $id ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'estat-os' ); ?></a>
							<?php
							if ( current_user_can( 'estat_bin_listings' ) ) {
								Partials::record_actions( $id, (string) get_post_status() );
							}
							?>
						</td>
					</tr>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</tbody>
		</table>
		<?php
		if ( $may_bulk ) {
			Partials::bulk_close();
		}

		$links = paginate_links(
			array(
				'total'     => (int) $query->max_num_pages,
				'current'   => $paged,
				'type'      => 'array',
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
			)
		);
		if ( is_array( $links ) ) {
			echo '<nav class="estat-pagination" aria-label="' . esc_attr__( 'Listing pages', 'estat-os' ) . '"><ul>';
			foreach ( $links as $link ) {
				echo '<li>' . wp_kses_post( $link ) . '</li>';
			}
			echo '</ul></nav>';
		}
	}

	/**
	 * The three-chapter editor.
	 *
	 * @param int $listing_id Listing ID.
	 * @return void
	 */
	public static function editor( int $listing_id ): void {
		$post = get_post( $listing_id );
		if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
			Partials::empty_state(
				array(
					'icon'    => 'search',
					'title'   => __( 'That property could not be found', 'estat-os' ),
					'message' => __( 'It may have been deleted, or the link you followed may be out of date.', 'estat-os' ),
					'action'  => admin_url( 'admin.php?page=estat-listings' ),
					'label'   => __( 'Back to listings', 'estat-os' ),
				)
			);
			return;
		}
		if ( ! Requests::may_edit_directly( $listing_id ) ) {
			// One screen, one honest path: what they cannot do is not offered,
			// and what they can do is right there rather than behind a wall.
			self::propose( $listing_id );
			return;
		}

		$schema     = Meta::listing_schema();
		$meta       = static fn( string $key ) => get_post_meta( $listing_id, $key, true );
		$readiness  = Listings::completeness( $listing_id );
		$localities = wp_get_object_terms( $listing_id, Taxonomies::LOCALITY, array( 'fields' => 'names' ) ); if (is_wp_error($localities)) $localities = array();
		$amenities  = wp_get_object_terms( $listing_id, Taxonomies::AMENITY, array( 'fields' => 'names' ) ); if (is_wp_error($amenities)) $amenities = array();
		$features   = wp_get_object_terms( $listing_id, Taxonomies::FEATURE, array( 'fields' => 'names' ) ); if (is_wp_error($features)) $features = array();
		$symbol     = (string) Settings::get( 'currency_symbol', '₹' );

		?>
		<div class="estat-editor-layout">
			<form method="post" class="estat-form-admin estat-editor" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ) ); ?>">
				<?php wp_nonce_field( 'estat_save_listing_' . $listing_id, 'estat_nonce' ); ?>
				<input type="hidden" name="estat_action" value="save_listing" />
				<input type="hidden" name="listing_id" value="<?php echo esc_attr( (string) $listing_id ); ?>" />

				<p class="estat-editor-note"><?php esc_html_e( 'The everyday answers are open. Everything else sits in the grey lines — nothing has been taken away, and a line opens by itself if you have already filled it in.', 'estat-os' ); ?></p>

				<details class="estat-chapter" open>
					<summary><h2><?php esc_html_e( 'Part 1 of 3 — The basics', 'estat-os' ); ?></h2><p><?php esc_html_e( 'The handful of answers every property needs.', 'estat-os' ); ?></p></summary>
					<div class="estat-chapter-body">
						<?php
						/*
						 * The first question is the one that decides the rest of
						 * the form: a sale and a rent are different deals. It is
						 * asked before anything else, and the money box below
						 * changes its name to match the answer.
						 */
						Partials::field(
							array(
								'name'    => '_estat_offer',
								'type'    => 'select',
								'label'    => (string) $schema['_estat_offer']['label'],
								'help'     => (string) ( $schema['_estat_offer']['help'] ?? '' ),
								'options'  => Vocabulary::offers(),
								'value'    => $meta( '_estat_offer' ),
								'required' => ! empty( $schema['_estat_offer']['required'] ),
							)
						);

						Partials::field(
							array(
								'name'    => '_estat_property_type',
								'type'    => 'select',
								'label'    => (string) $schema['_estat_property_type']['label'],
								'help'     => (string) ( $schema['_estat_property_type']['help'] ?? '' ),
								'options'  => Vocabulary::for_select( 'property_types', (string) $meta( '_estat_property_type' ) ),
								'value'    => $meta( '_estat_property_type' ),
								'required' => ! empty( $schema['_estat_property_type']['required'] ),
							)
						);

						Partials::field( array( 'name' => 'title', 'label' => __( 'Headline', 'estat-os' ), 'value' => $post->post_title, 'required' => true, 'help' => __( 'Say what it is and where, in a few words.', 'estat-os' ), 'example' => __( '3 BHK apartment with a park view', 'estat-os' ) ) );

						Partials::field( array( 'name' => 'locality', 'label' => __( 'Locality', 'estat-os' ), 'value' => is_wp_error( $localities ) ? '' : implode( ', ', $localities ), 'help' => __( 'Separate several with commas.', 'estat-os' ), 'required' => true ) );

						$projects = Picker::options( PostTypes::PROJECT, __( 'Not part of one', 'estat-os' ), (int) $meta( '_estat_project_id' ) );
						Partials::field(
							array(
								'name'    => '_estat_project_id',
								'type'    => 'select',
								'label'   => __( 'Society or project', 'estat-os' ),
								'options' => $projects['options'],
								'value'   => $meta( '_estat_project_id' ),
								'help'    => Picker::notice( $projects ),
							)
						);

						/*
						 * One money box, not two. A rental's figure lives in
						 * _estat_rent and a sale's in _estat_price; which one the
						 * office is looking at is decided by the "for sale / rent"
						 * answer above, so the box shows whichever is filled and
						 * the label follows the answer. Saving folds it back
						 * (Data\Listings::save()).
						 */
						$money_value = (string) $meta( '_estat_price' );
						if ( '' === $money_value ) {
							$money_value = (string) $meta( '_estat_rent' );
						}
						$is_rental = in_array( (string) $meta( '_estat_offer' ), array( 'rent', 'lease' ), true );
						Partials::field(
							array(
								'name'       => '_estat_price',
								'type'       => 'number',
								'label'      => $is_rental
									? sprintf( /* translators: %s: currency symbol */ __( 'Monthly rent (%s)', 'estat-os' ), $symbol )
									: sprintf( /* translators: %s: currency symbol */ __( 'Price (%s)', 'estat-os' ), $symbol ),
								'value'      => $money_value,
								'help'       => $is_rental
									? __( 'Numbers only. This is what the tenant pays each month.', 'estat-os' )
									: (string) $schema['_estat_price']['help'],
								'example'    => $is_rental ? '32000' : '8500000',
								'min'        => 0,
								'step'       => $is_rental ? 500 : 1000,
								'wrap_class' => 'estat-money-row',
							)
						);
						/*
						 * Both names this box can carry, in the page, so the
						 * label changes the moment the first answer changes.
						 * Rendered server-side too, so with JavaScript switched
						 * off the label is still right for what was saved.
						 */
						printf(
							'<span hidden class="estat-money-texts" data-sale-label="%1$s" data-rent-label="%2$s" data-sale-help="%3$s" data-rent-help="%4$s" data-sale-example="8500000" data-rent-example="32000"></span>',
							esc_attr( sprintf( /* translators: %s: currency symbol */ __( 'Price (%s)', 'estat-os' ), $symbol ) ),
							esc_attr( sprintf( /* translators: %s: currency symbol */ __( 'Monthly rent (%s)', 'estat-os' ), $symbol ) ),
							esc_attr( (string) $schema['_estat_price']['help'] ),
							esc_attr__( 'Numbers only. This is what the tenant pays each month.', 'estat-os' )
						);

						Partials::field( array( 'name' => '_estat_area', 'type' => 'number', 'label' => __( 'Size', 'estat-os' ), 'value' => $meta( '_estat_area' ), 'help' => __( 'Numbers only.', 'estat-os' ), 'example' => '1250', 'min' => 0 ) );
						Partials::field( array( 'name' => '_estat_area_unit', 'type' => 'select', 'label' => __( 'Measured in', 'estat-os' ), 'options' => Vocabulary::area_units(), 'value' => $meta( '_estat_area_unit' ) ) );

						// A plot has no bedrooms, and a shop has no balconies.
						foreach ( array( '_estat_bedrooms' => __( 'Bedrooms', 'estat-os' ), '_estat_bathrooms' => __( 'Bathrooms', 'estat-os' ) ) as $key => $label ) {
							Partials::field( array( 'name' => $key, 'type' => 'number', 'label' => $label, 'value' => $meta( $key ), 'min' => 0, 'max' => 500, 'wrap_class' => 'estat-only-home' ) );
						}

						/*
						 * Money that only some deals involve. Hidden for a sale
						 * rather than removed: the numbers stay in the record and
						 * come back the moment the first answer changes.
						 */
						Partials::extras_open(
							__( 'Rent, deposit and maintenance', 'estat-os' ),
							__( 'Only needed if this is a rental. Skip it for a sale.', 'estat-os' ),
							Partials::has_content( array( $meta( '_estat_deposit' ), $meta( '_estat_maintenance' ), $meta( '_estat_price_type' ) ) ),
							3
						);
						Partials::field(
							array(
								'name'       => '_estat_price_type',
								'type'       => 'select',
								'label'      => (string) $schema['_estat_price_type']['label'],
								'help'       => (string) ( $schema['_estat_price_type']['help'] ?? '' ),
								'options'    => Vocabulary::price_types(),
								'value'      => $meta( '_estat_price_type' ),
								'wrap_class' => 'estat-only-rent',
							)
						);
						Partials::field( array( 'name' => '_estat_deposit', 'type' => 'number', 'label' => __( 'Security deposit', 'estat-os' ), 'value' => $meta( '_estat_deposit' ), 'min' => 0, 'wrap_class' => 'estat-only-rent' ) );
						Partials::field( array( 'name' => '_estat_maintenance', 'type' => 'number', 'label' => __( 'Monthly maintenance', 'estat-os' ), 'value' => $meta( '_estat_maintenance' ), 'min' => 0, 'wrap_class' => 'estat-only-rent' ) );
						Partials::extras_close();

						// Numbers a buyer asks about later, never on the first call.
						echo '<div class="estat-only-built">';
						Partials::extras_open(
							__( 'More details about the building', 'estat-os' ),
							'',
							Partials::has_content( array( $meta( '_estat_area_type' ), $meta( '_estat_balconies' ), $meta( '_estat_parking' ), $meta( '_estat_floor' ), $meta( '_estat_total_floors' ), $meta( '_estat_age' ) ) ),
							5
						);
						Partials::field( array( 'name' => '_estat_area_type', 'type' => 'select', 'label' => __( 'Which area is this?', 'estat-os' ), 'options' => Vocabulary::area_types(), 'value' => $meta( '_estat_area_type' ) ) );
						Partials::field( array( 'name' => '_estat_balconies', 'type' => 'number', 'label' => __( 'Balconies', 'estat-os' ), 'value' => $meta( '_estat_balconies' ), 'min' => 0, 'max' => 500, 'wrap_class' => 'estat-only-home' ) );
						foreach ( array( '_estat_parking' => __( 'Parking spaces', 'estat-os' ), '_estat_floor' => __( 'Which floor', 'estat-os' ), '_estat_total_floors' => __( 'Floors in the building', 'estat-os' ), '_estat_age' => __( 'Age in years', 'estat-os' ) ) as $key => $label ) {
							Partials::field( array( 'name' => $key, 'type' => 'number', 'label' => $label, 'value' => $meta( $key ), 'min' => 0, 'max' => 500 ) );
						}
						Partials::extras_close();
						echo '</div>';

						// A new launch carries a builder's promises, not a flat's history.
						echo '<div class="estat-only-built">';
						Partials::extras_open(
							__( 'Builder, possession and your own reference', 'estat-os' ),
							__( 'Useful for new projects and for matching this listing to your own records.', 'estat-os' ),
							Partials::has_content( array( $meta( '_estat_developer' ), $meta( '_estat_possession_date' ), $meta( '_estat_construction' ), $meta( '_estat_investment' ), $meta( '_estat_expiry_date' ), $meta( '_estat_external_id' ) ) ),
							6
						);
						Partials::field( array( 'name' => '_estat_construction', 'type' => 'select', 'label' => __( 'Construction stage', 'estat-os' ), 'options' => Vocabulary::construction(), 'value' => $meta( '_estat_construction' ) ) );
						Partials::field( array( 'name' => '_estat_developer', 'label' => __( 'Builder or developer', 'estat-os' ), 'value' => $meta( '_estat_developer' ) ) );
						Partials::field( array( 'name' => '_estat_possession_date', 'type' => 'date', 'label' => __( 'Possession date', 'estat-os' ), 'value' => $meta( '_estat_possession_date' ) ) );
						Partials::field( array( 'name' => '_estat_investment', 'type' => 'checkbox', 'label' => __( 'Investment', 'estat-os' ), 'checkbox_label' => __( 'Mark this as a good investment opportunity', 'estat-os' ), 'value' => $meta( '_estat_investment' ) ) );
						Partials::field( array( 'name' => '_estat_expiry_date', 'type' => 'date', 'label' => __( 'Take it off the website on', 'estat-os' ), 'value' => $meta( '_estat_expiry_date' ), 'help' => __( 'Leave empty to keep it live. On this date it becomes a draft again — nothing is deleted.', 'estat-os' ) ) );
						Partials::field( array( 'name' => '_estat_external_id', 'label' => __( 'Your own reference number', 'estat-os' ), 'value' => $meta( '_estat_external_id' ), 'help' => (string) $schema['_estat_external_id']['help'] ) );
						Partials::extras_close();
						echo '</div>';
						?>
					</div>
				</details>

				<?php
				/*
				 * A part that already holds writing or photos opens by itself —
				 * a shorter form must never look like a form that has lost
				 * something.
				 */
				$has_story = '' !== trim( (string) $post->post_content )
					|| (int) get_post_thumbnail_id( $listing_id ) > 0
					|| array() !== (array) $meta( '_estat_gallery' )
					|| ( is_array( $amenities ) && array() !== $amenities )
					|| ( is_array( $features ) && array() !== $features )
					// A voice note or a written one is something the office
					// came to read or hear: the part opens by itself.
					|| array() !== (array) $meta( '_estat_voice_notes' )
					|| '' !== (string) $meta( '_estat_voice_text' );
				?>
				<details class="estat-chapter"<?php echo $has_story ? ' open' : ''; ?>>
					<summary><h2><?php esc_html_e( 'Part 2 of 3 — Photos and words', 'estat-os' ); ?></h2><p><?php esc_html_e( 'Photos, the description, and what makes it special.', 'estat-os' ); ?></p></summary>
					<div class="estat-chapter-body">
						<?php
						Partials::field( array( 'name' => 'cover_id', 'type' => 'image', 'label' => __( 'Main photo', 'estat-os' ), 'value' => get_post_thumbnail_id( $listing_id ), 'help' => __( 'This is the photo people see first.', 'estat-os' ) ) );
						Partials::field( array( 'name' => '_estat_gallery', 'type' => 'gallery', 'label' => __( 'Photo gallery', 'estat-os' ), 'value' => (array) $meta( '_estat_gallery' ) ) );
						Partials::field( array( 'name' => 'description', 'type' => 'textarea', 'rows' => 8, 'label' => __( 'Describe the property', 'estat-os' ), 'value' => $post->post_content, 'help' => __( 'Write as if you were telling a friend about it. Mention the neighbourhood, the light, what is nearby.', 'estat-os' ) ) );
$voice_notes = array_values( array_filter( array_map( 'intval', (array) $meta( '_estat_voice_notes' ) ) ) );
						$voice_text  = (string) $meta( '_estat_voice_text' );
						if ( $voice_notes || '' !== $voice_text ) {
							echo '<div class="estat-voice-notes">';
							echo '<span class="estat-field-label">' . esc_html( sprintf(
								/* translators: %d: how many voice notes. */
								_n( 'A voice note from the field', '%d voice notes from the field', count( $voice_notes ), 'estat-os' ),
								count( $voice_notes )
							) ) . '</span>';
							echo '<p class="estat-field-help">' . esc_html__( 'Recorded on the phone while looking at the property. Press play to hear it.', 'estat-os' ) . '</p>';
							if ( '' !== $voice_text ) {
								echo '<p class="estat-voice-written">' . esc_html( $voice_text ) . '</p>';
							}
							foreach ( $voice_notes as $voice_id ) {
								$voice_src = wp_get_attachment_url( (int) $voice_id );
								if ( ! $voice_src ) {
									continue;
								}
								echo '<div class="estat-voice-row">'
									. \EstatOS\Support\Icon::render( 'speaker-high', 18, 'estat-ms' )
									. '<audio controls preload="metadata" src="' . esc_url( $voice_src ) . '"></audio>'
									. '<span class="estat-voice-when">' . esc_html( (string) get_the_date( 'j M Y', (int) $voice_id ) ) . '</span>'
									. '</div>';
							}
							echo '</div>';
						}
						Partials::field( array( 'name' => 'amenities', 'label' => __( 'Amenities', 'estat-os' ), 'value' => is_wp_error( $amenities ) ? '' : implode( ', ', $amenities ), 'help' => __( 'For example: lift, parking, power backup.', 'estat-os' ) ) );
						Partials::field( array( 'name' => 'features', 'label' => __( 'Special features', 'estat-os' ), 'value' => is_wp_error( $features ) ? '' : implode( ', ', $features ), 'help' => __( 'Anything that makes this one different.', 'estat-os' ) ) );

						Partials::extras_open(
							__( 'Floor plans, brochures, video and 360° tour', 'estat-os' ),
							'',
							Partials::has_content( array( $meta( '_estat_floor_plans' ), $meta( '_estat_brochures' ), $meta( '_estat_video_url' ), $meta( '_estat_tour_url' ) ) ),
							4
						);
						Partials::field( array( 'name' => '_estat_floor_plans', 'type' => 'gallery', 'label' => __( 'Floor plans', 'estat-os' ), 'value' => (array) $meta( '_estat_floor_plans' ) ) );
						Partials::field( array( 'name' => '_estat_brochures', 'type' => 'gallery', 'label' => __( 'Brochures and documents', 'estat-os' ), 'value' => (array) $meta( '_estat_brochures' ) ) );
						Partials::field( array( 'name' => '_estat_video_url', 'type' => 'url', 'label' => __( 'Video link', 'estat-os' ), 'value' => $meta( '_estat_video_url' ), 'example' => 'https://youtu.be/…' ) );
						Partials::field( array( 'name' => '_estat_tour_url', 'type' => 'url', 'label' => __( '360° tour link', 'estat-os' ), 'value' => $meta( '_estat_tour_url' ) ) );
						Partials::extras_close();

						Partials::extras_open(
							__( 'Exact address and map position', 'estat-os' ),
							__( 'The locality above is enough for most listings. Add this to show a map on the property page.', 'estat-os' ),
							Partials::has_content( array( $meta( '_estat_address' ), $meta( '_estat_facing' ), $meta( '_estat_furnishing' ), $meta( '_estat_latitude' ), $meta( '_estat_longitude' ) ) ),
							5
						);
						Partials::field( array( 'name' => '_estat_address', 'type' => 'textarea', 'label' => __( 'Full address', 'estat-os' ), 'value' => $meta( '_estat_address' ), 'help' => (string) $schema['_estat_address']['help'] ) );
						Partials::field( array( 'name' => '_estat_facing', 'type' => 'select', 'label' => __( 'Which way does it face?', 'estat-os' ), 'options' => Vocabulary::facing(), 'value' => $meta( '_estat_facing' ) ) );
						Partials::field( array( 'name' => '_estat_furnishing', 'type' => 'select', 'label' => __( 'Furnishing', 'estat-os' ), 'options' => Vocabulary::furnishing(), 'value' => $meta( '_estat_furnishing' ) ) );
						Partials::field( array( 'name' => '_estat_latitude', 'label' => __( 'Map latitude', 'estat-os' ), 'value' => $meta( '_estat_latitude' ), 'example' => '28.6139', 'help' => __( 'Optional. Adding this shows a map on the property page.', 'estat-os' ) ) );
						Partials::field( array( 'name' => '_estat_longitude', 'label' => __( 'Map longitude', 'estat-os' ), 'value' => $meta( '_estat_longitude' ), 'example' => '77.2090' ) );
						Partials::extras_close();
						?>
					</div>
				</details>

				<?php
				/*
				 * Office-only answers. This part opens by itself only when the
				 * office has actually put something in it, so an untouched
				 * listing still reads as short.
				 */
				$has_office = '' !== (string) $meta( '_estat_internal_notes' )
					|| '' !== (string) $meta( '_estat_verification' )
					|| '' !== (string) $meta( '_estat_agent_id' )
					|| '' !== (string) $meta( '_estat_regulatory_id' )
					|| (bool) $meta( '_estat_featured' )
					|| ! in_array( (string) $meta( '_estat_availability' ), array( '', 'available' ), true )
					|| '' !== (string) $meta( '_estat_freshness' );
				?>
				<details class="estat-chapter"<?php echo $has_office ? ' open' : ''; ?>>
					<summary><h2><?php esc_html_e( 'Part 3 of 3 — Office only', 'estat-os' ); ?></h2><p><?php esc_html_e( 'Who is handling it, and what visitors never see.', 'estat-os' ); ?></p></summary>
					<div class="estat-chapter-body">
						<?php
						Partials::field( array( 'name' => '_estat_availability', 'type' => 'select', 'label' => __( 'Is it still available?', 'estat-os' ), 'options' => Vocabulary::availability(), 'value' => $meta( '_estat_availability' ) ) );
						Partials::field( array( 'name' => '_estat_freshness', 'type' => 'select', 'label' => __( 'Which tag should the website show?', 'estat-os' ), 'options' => array( '' => __( '— No tag —', 'estat-os' ) ) + Vocabulary::freshness(), 'value' => $meta( '_estat_freshness' ), 'help' => __( 'Just listed or Ready to move.', 'estat-os' ) ) );

						if ( current_user_can( 'estat_verify_listings' ) ) {
							Partials::field( array( 'name' => '_estat_verification', 'type' => 'select', 'label' => __( 'Have we checked this property?', 'estat-os' ), 'options' => Vocabulary::verification(), 'value' => $meta( '_estat_verification' ) ) );
						}

						$agents = Picker::options( PostTypes::AGENT, __( 'Nobody yet', 'estat-os' ), (int) $meta( '_estat_agent_id' ) );
						Partials::field(
							array(
								'name'    => '_estat_agent_id',
								'type'    => 'select',
								'label'   => __( 'Who is handling it?', 'estat-os' ),
								'options' => $agents['options'],
								'value'   => $meta( '_estat_agent_id' ),
								'help'    => Picker::notice( $agents ),
							)
						);

						/*
						 * Only one company in the office? Then there is nothing to
						 * choose between, and the question is not asked at all. An
						 * office that runs more than one wants the property to say
						 * which company it belongs to.
						 */
						if ( Settings::get( 'multi_agency' ) ) {
							$companies = Picker::options( PostTypes::AGENCY, __( 'Not said', 'estat-os' ), (int) $meta( '_estat_agency_id' ) );
							Partials::field(
								array(
									'name'    => '_estat_agency_id',
									'type'    => 'select',
									'label'   => __( 'Company', 'estat-os' ),
									'help'    => Picker::notice( $companies ),
									'options' => $companies['options'],
									'value'   => $meta( '_estat_agency_id' ),
								)
							);
						}

						if ( Settings::get( 'show_regulatory' ) ) {
							Partials::field(
								array(
									'name'  => '_estat_regulatory_id',
									'label' => sprintf( /* translators: %s: regulatory label such as RERA */ __( '%s number', 'estat-os' ), (string) Settings::get( 'regulatory_label', 'RERA' ) ),
									'value' => $meta( '_estat_regulatory_id' ),
									'help'  => __( 'The official registration number, if this property has one.', 'estat-os' ),
								)
							);
						}

						Partials::field( array( 'name' => '_estat_featured', 'type' => 'checkbox', 'label' => __( 'Featured', 'estat-os' ), 'checkbox_label' => __( 'Show this property prominently on the website', 'estat-os' ), 'value' => $meta( '_estat_featured' ) ) );
						Partials::field( array( 'name' => '_estat_internal_notes', 'type' => 'textarea', 'label' => __( 'Private office notes', 'estat-os' ), 'value' => $meta( '_estat_internal_notes' ), 'help' => (string) $schema['_estat_internal_notes']['help'] ) );
						?>
					</div>
				</details>

				<div class="estat-form-actions-admin estat-sticky-actions">
					<button type="submit" name="estat_save_mode" value="draft" class="button button-secondary"><?php esc_html_e( 'Save as draft', 'estat-os' ); ?></button>
					<?php if ( current_user_can( 'estat_publish_listings' ) ) : ?>
						<button type="submit" name="estat_save_mode" value="publish" class="button button-primary"><?php echo 'publish' === $post->post_status ? esc_html__( 'Save changes', 'estat-os' ) : esc_html__( 'Put it on the website', 'estat-os' ); ?></button>
					<?php endif; ?>
					<a class="button-link" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>"><?php esc_html_e( 'Back to listings', 'estat-os' ); ?></a>
				</div>
			</form>

			<aside class="estat-editor-side">
				<?php
				Partials::card_open( __( 'How ready is this listing?', 'estat-os' ) );
				?>
				<div class="estat-progress" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: percentage */ __( '%d percent complete', 'estat-os' ), (int) $readiness['score'] ) ); ?>">
					<div class="estat-progress-bar" style="width:<?php echo esc_attr( (string) (int) $readiness['score'] ); ?>%"></div>
				</div>
				<p class="estat-progress-value"><?php echo esc_html( $readiness['score'] . '%' ); ?></p>
				<?php if ( $readiness['missing'] ) : ?>
					<p class="description"><?php esc_html_e( 'Still missing:', 'estat-os' ); ?></p>
					<ul class="estat-missing">
						<?php foreach ( $readiness['missing'] as $missing ) : ?>
							<li><a href="#estat-<?php echo esc_attr( sanitize_html_class( (string) $missing['field'] ) ); ?>"><?php echo esc_html( (string) $missing['label'] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="estat-good"><?php esc_html_e( 'Everything important is filled in.', 'estat-os' ); ?></p>
				<?php endif; ?>
				<?php
				Partials::card_close();

				Partials::card_open( __( 'How it looks on the website', 'estat-os' ) );
				echo '<div class="estat-preview">';
				echo \EstatOS\Frontend\Components::card( $listing_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '</div>';
				echo '<p><a href="' . esc_url( (string) get_permalink( $listing_id ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open the property page', 'estat-os' ) . '</a></p>';
				Partials::card_close();

				/*
				 * Managing one property, in one place. Edit is the page this
				 * sits on; here is where it goes when it should no longer be
				 * on the website, and where it comes back from. The buttons
				 * are the same ones the list uses, so there is one delete in
				 * this plugin and not two.
				 */
				if ( current_user_can( 'estat_delete_listings' ) ) {
					$missing = \EstatOS\Data\Health::of( $listing_id );
					if ( $missing ) {
						Partials::card_open(
							__( 'What still needs filling in', 'estat-os' ),
							__( 'The website, the filters and the search engines read all of this. Fix what you can while you are here.', 'estat-os' )
						);
						self::attention_note( $listing_id );
						Partials::card_close();
					}

					Partials::card_open(
						__( 'Manage this property', 'estat-os' ),
						'trash' === (string) $post->post_status
							? __( 'It is in the bin. Restoring brings it back as it was; deleting it permanently cannot be undone.', 'estat-os' )
							: __( 'Moving it to the bin takes it off the website and keeps it there, where it can be restored. Deleting it permanently is a second, separate step.', 'estat-os' )
					);
					echo '<div class="estat-ui-actions">';
					Partials::record_actions( $listing_id, (string) $post->post_status );
					echo '</div>';
					Partials::card_close();
				}
				?>
			</aside>
		</div>
		<?php
	}

	/**
	 * The one thing an agent can do with a property that is not theirs.
	 *
	 * Refusing them outright is the wrong answer. Standing in a flat that has
	 * just changed hands, they know something the website has wrong, and a
	 * locked screen means the website stays wrong until a colleague gets back.
	 * So the record is shown as it is, and the handful of facts a person on the
	 * spot can genuinely confirm are offered as a request.
	 *
	 * @param int $listing_id The listing being looked at.
	 * @return void
	 */
	private static function propose( int $listing_id ): void {
		$post = get_post( $listing_id );
		$data = Listings::to_array( $listing_id, true );

		Partials::card_open(
			/* translators: %s: property name. */
			sprintf( __( '%s belongs to somebody else', 'estat-os' ), (string) ( $post ? $post->post_title : __( 'That property', 'estat-os' ) ) ),
			__( 'You can read it, and you can ask for a correction. Nothing changes until the office says yes.', 'estat-os' )
		);

		echo '<dl class="estat-record-facts">';
		foreach (
			array(
				__( 'Price', 'estat-os' )            => (string) $data['price_display'],
				__( 'Still available?', 'estat-os' ) => (string) Vocabulary::label( 'availability', (string) $data['availability'] ),
				__( 'Size', 'estat-os' )             => (float) $data['area_sqft'] > 0 ? Format::area( (float) $data['area_sqft'], 'sqft' ) : '',
				__( 'Bedrooms', 'estat-os' )         => (int) $data['bedrooms'] > 0 ? (string) (int) $data['bedrooms'] : '',
				__( 'On the website', 'estat-os' )   => 'publish' === (string) $data['status'] ? __( 'Yes', 'estat-os' ) : __( 'Not yet', 'estat-os' ),
			) as $label => $value
		) {
			echo '<dt>' . esc_html( (string) $label ) . '</dt><dd>' . esc_html( '' !== trim( (string) $value ) ? (string) $value : '—' ) . '</dd>';
		}

		$desc = trim( (string) wp_strip_all_tags( (string) ( $post ? $post->post_content : '' ) ) );
		if ( '' !== $desc ) {
			echo '<dt>' . esc_html__( 'Description', 'estat-os' ) . '</dt><dd>' . esc_html( 400 < strlen( $desc ) ? substr( $desc, 0, 397 ) . '…' : $desc ) . '</dd>';
		}
		echo '</dl>';

		Partials::card_close();

		self::propose_form( $listing_id );
	}

	/**
	 * The short form that sends a correction to the office.
	 *
	 * Deliberately four fields, not the forty the editor has. Somebody on a
	 * phone in a lobby wants to fix a price and say "it is sold", not meet a
	 * form. Anything beyond that is office work.
	 *
	 * @param int $listing_id The listing being corrected.
	 * @return void
	 */
	private static function propose_form( int $listing_id ): void {
		$symbol = (string) Settings::get( 'currency_symbol', '₹' );

		Partials::card_open(
			__( 'Suggest a change', 'estat-os' ),
			__( 'Fill in only what is wrong. Leave a field alone and it stays as it is.', 'estat-os' )
		);
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings&edit=' . $listing_id ) ); ?>" class="estat-request-form">
			<?php wp_nonce_field( 'estat_propose_request_' . $listing_id, 'estat_nonce' ); ?>
			<input type="hidden" name="estat_action" value="propose_listing" />
			<input type="hidden" name="listing_id" value="<?php echo esc_attr( (string) $listing_id ); ?>" />

			<?php
			foreach ( Requests::editable_fields() as $field => $meta ) {
				if ( 'note' === $field ) {
					continue;
				}

				self::propose_field( (string) $field, (string) $meta['type'], (string) ( $meta['label'] ?? '' ), $listing_id, $symbol );
			}
			?>

			<div class="estat-field-row">
				<label class="estat-field-label" for="estat-request-note">
					<?php esc_html_e( 'A note for the office', 'estat-os' ); ?>
					<span class="estat-required"><?php esc_html_e( 'required', 'estat-os' ); ?></span>
				</label>
				<textarea id="estat-request-note" name="message" rows="3" required maxlength="600" placeholder="<?php esc_attr_e( 'The owner told me this morning…', 'estat-os' ); ?>"></textarea>
				<p class="description"><?php esc_html_e( 'One line about how you know, so they can decide without calling you.', 'estat-os' ); ?></p>
			</div>

			<p class="estat-request-form-foot">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Send to the office', 'estat-os' ); ?></button>
				<a class="button-link" href="<?php echo esc_url( admin_url( 'admin.php?page=estat-listings' ) ); ?>"><?php esc_html_e( 'Back to listings', 'estat-os' ); ?></a>
			</p>
		</form>
		<?php
		Partials::card_close();
	}

	/**
	 * One proposed field, with what the record says today written under it.
	 *
	 * @param string $field      Field name.
	 * @param string $type       Field kind.
	 * @param string $label      Human label.
	 * @param int    $listing_id The listing.
	 * @param string $symbol     Currency symbol.
	 * @return void
	 */
	private static function propose_field( string $field, string $type, string $label, int $listing_id, string $symbol ): void {
		$id  = 'estat-request-' . sanitize_html_class( $field );
		$raw = Requests::current_value( $listing_id, $field );
		$now = Requests::describe( $field, $raw );

		$today  = 'Nothing entered' !== trim( $now ) ? $now : '';
		?>
		<div class="estat-field-row">
			<label class="estat-field-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
				<span class="estat-optional"><?php esc_html_e( 'only if it is wrong', 'estat-os' ); ?></span>
			</label>
			<?php if ( 'availability' === $type ) : ?>
				<select id="<?php echo esc_attr( $id ); ?>" name="changes[<?php echo esc_attr( $field ); ?>]">
					<option value=""><?php esc_html_e( 'Leave as it is', 'estat-os' ); ?></option>
					<?php
					foreach ( Vocabulary::availability() as $value => $text ) {
						if ( $value === $raw ) {
							continue; // No point proposing what it already says.
						}
						echo '<option value="' . esc_attr( (string) $value ) . '">' . esc_html( (string) $text ) . '</option>';
					}
					?>
				</select>
			<?php elseif ( 'textarea' === $type ) : ?>
				<textarea id="<?php echo esc_attr( $id ); ?>" name="changes[<?php echo esc_attr( $field ); ?>]" rows="3" placeholder="<?php esc_attr_e( 'Type the whole new description, as plain text…', 'estat-os' ); ?>"></textarea>
			<?php else : ?>
				<input type="number" id="<?php echo esc_attr( $id ); ?>" name="changes[<?php echo esc_attr( $field ); ?>]" min="0" step="1000" inputmode="numeric" placeholder="<?php echo esc_attr( $symbol ); ?>" />
			<?php endif; ?>
			<p class="description">
				<?php
				printf(
					/* translators: %s: what the website shows today. */
					esc_html__( 'Today it says: %s', 'estat-os' ),
					esc_html( '' !== trim( $today ) ? $today : __( 'nothing yet', 'estat-os' ) )
				);
				?>
			</p>
		</div>
		<?php
	}

}
