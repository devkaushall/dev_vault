<?php
/**
 * Optional outgoing CRM connection with HMAC signing and retries.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Webhooks;

use EstatOS\Audit\AuditLog;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Payloads contain only what an integration needs. The shared secret never
 * leaves the server and is never printed anywhere.
 */
final class Webhooks {

	/**
	 * Cron hook used for retries.
	 */
	public const RETRY_HOOK = 'estat_webhook_retry';

	/**
	 * Maximum delivery attempts.
	 */
	private const MAX_ATTEMPTS = 3;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'estat_lead_created', array( __CLASS__, 'on_lead_created' ), 20, 1 );
		add_action( 'estat_lead_updated', array( __CLASS__, 'on_lead_updated' ), 20, 2 );
		add_action( 'estat_lead_status_changed', array( __CLASS__, 'on_lead_status_changed' ), 20, 3 );
		add_action( 'estat_lead_assigned', array( __CLASS__, 'on_lead_assigned' ), 20, 2 );
		add_action( 'estat_visit_scheduled', array( __CLASS__, 'on_visit_scheduled' ), 20, 1 );
		add_action( 'estat_visit_completed', array( __CLASS__, 'on_visit_completed' ), 20, 1 );
		add_action( 'estat_listing_published', array( __CLASS__, 'on_listing_published' ), 20, 2 );
		add_action( 'estat_listing_verified', array( __CLASS__, 'on_listing_verified' ), 20, 1 );
		add_action( 'estat_project_stage_changed', array( __CLASS__, 'on_project_stage_changed' ), 20, 3 );
		add_action( 'estat_form_submitted', array( __CLASS__, 'on_form_submitted' ), 20, 4 );
		add_action( 'estat_alert_created', array( __CLASS__, 'on_alert_created' ), 20, 2 );
		add_action( 'estat_share_logged', array( __CLASS__, 'on_share_logged' ), 20, 2 );
		add_action( self::RETRY_HOOK, array( __CLASS__, 'deliver' ), 10, 3 );
	}

	/**
	 * Whether an event is enabled.
	 *
	 * @param string $event Event key.
	 * @return bool
	 */
	private static function enabled( string $event ): bool {
		if ( ! Settings::get( 'webhook_enabled' ) ) {
			return false;
		}
		$u1 = (string) Settings::get( 'webhook_url' );
		$u2 = (string) Settings::get( 'webhook_url_2' );
		if ( '' === $u1 && '' === $u2 ) {
			return false;
		}
		return in_array( $event, (array) Settings::get( 'webhook_events', array() ), true );
	}

	/**
	 * Events an office can subscribe to, in plain language.
	 *
	 * @return array<string,string>
	 */
	public static function events(): array {
		return array(
			'lead.created'         => __( 'A new enquiry arrives', 'estat-os' ),
			'lead.updated'         => __( 'An enquiry changes (any field)', 'estat-os' ),
			'lead.status_changed'  => __( 'Enquiry status changes (New→Contacted→Scheduled→Won/Lost)', 'estat-os' ),
			'lead.assigned'        => __( 'Enquiry assigned to team member', 'estat-os' ),
			'visit.scheduled'      => __( 'A site visit is arranged', 'estat-os' ),
			'visit.completed'      => __( 'A site visit is marked as done / no-show', 'estat-os' ),
			'listing.published'    => __( 'A property goes live on the website', 'estat-os' ),
			'listing.verified'     => __( 'Property verified — humne khud dekha tick', 'estat-os' ),
			'project.stage_changed'=> __( 'Project stage changes (Planning/UC/Ready)', 'estat-os' ),
			'form.submitted'       => __( 'Any form is submitted', 'estat-os' ),
			'alert.created'        => __( 'Visitor creates a search alert', 'estat-os' ),
			'share.logged'         => __( 'Property shared via WhatsApp / copy link', 'estat-os' ),
		);
	}

	/**
	 * Forward a new enquiry.
	 *
	 * @param int $lead_id Lead ID.
	 * @return void
	 */
	public static function on_lead_created( int $lead_id ): void {
		if ( ! self::enabled( 'lead.created' ) ) {
			return;
		}
		$lead = Leads::get( $lead_id );
		if ( ! $lead ) {
			return;
		}
		self::deliver(
			'lead.created',
			array(
				'lead_id'    => $lead_id,
				'created_at' => $lead['created_at'],
				'name'       => $lead['name'],
				'phone'      => $lead['phone'],
				'email'      => $lead['email'],
				'message'    => $lead['message'],
				'listing_id' => (int) $lead['listing_id'],
				'listing'    => (int) $lead['listing_id'] > 0 ? get_the_title( (int) $lead['listing_id'] ) : '',
				'source'     => $lead['source'],
			),
			1
		);
	}

	/**
	 * Forward a scheduled visit (no personal data beyond the reference).
	 *
	 * @param int $visit_id Visit ID.
	 * @return void
	 */
	public static function on_visit_scheduled( int $visit_id ): void {
		if ( ! self::enabled( 'visit.scheduled' ) ) {
			return;
		}
		$visit = \EstatOS\Leads\Visits::get( $visit_id );
		if ( ! $visit ) {
			return;
		}
		self::deliver(
			'visit.scheduled',
			array(
				'visit_id'     => $visit_id,
				'lead_id'      => (int) $visit['lead_id'],
				'listing_id'   => (int) $visit['listing_id'],
				'scheduled_at' => $visit['scheduled_at'],
			),
			1
		);
	}

	public static function on_lead_updated( int $lead_id, array $changes = array() ): void {
		if ( ! self::enabled( 'lead.updated' ) ) { return; }
		$lead = Leads::get( $lead_id );
		if ( ! $lead ) { return; }
		self::deliver( 'lead.updated', array( 'lead_id' => $lead_id, 'changes' => $changes, 'status' => $lead['status'] ?? '', 'assigned' => $lead['assigned_agent_id'] ?? 0 ), 1 );
	}

	public static function on_lead_status_changed( int $lead_id, string $old_status, string $new_status ): void {
		if ( ! self::enabled( 'lead.status_changed' ) ) { return; }
		self::deliver( 'lead.status_changed', array( 'lead_id' => $lead_id, 'old_status' => $old_status, 'new_status' => $new_status ), 1 );
	}

	public static function on_lead_assigned( int $lead_id, int $agent_id ): void {
		if ( ! self::enabled( 'lead.assigned' ) ) { return; }
		self::deliver( 'lead.assigned', array( 'lead_id' => $lead_id, 'agent_id' => $agent_id, 'agent_name' => $agent_id ? get_the_title( $agent_id ) : '' ), 1 );
	}

	public static function on_visit_completed( int $visit_id ): void {
		if ( ! self::enabled( 'visit.completed' ) ) { return; }
		$visit = \EstatOS\Leads\Visits::get( $visit_id );
		if ( ! $visit ) { return; }
		self::deliver( 'visit.completed', array( 'visit_id' => $visit_id, 'lead_id' => (int) $visit['lead_id'], 'outcome' => $visit['outcome'] ?? '' ), 1 );
	}

	public static function on_listing_published( int $listing_id, array $data = array() ): void {
		if ( ! self::enabled( 'listing.published' ) ) { return; }
		self::deliver( 'listing.published', array( 'listing_id' => $listing_id, 'title' => get_the_title( $listing_id ), 'url' => get_permalink( $listing_id ), 'price' => get_post_meta( $listing_id, '_estat_price', true ) ), 1 );
	}

	public static function on_listing_verified( int $listing_id ): void {
		if ( ! self::enabled( 'listing.verified' ) ) { return; }
		self::deliver( 'listing.verified', array( 'listing_id' => $listing_id, 'title' => get_the_title( $listing_id ), 'verified' => true ), 1 );
	}

	public static function on_project_stage_changed( int $project_id, string $old_stage, string $new_stage ): void {
		if ( ! self::enabled( 'project.stage_changed' ) ) { return; }
		self::deliver( 'project.stage_changed', array( 'project_id' => $project_id, 'old_stage' => $old_stage, 'new_stage' => $new_stage, 'title' => get_the_title( $project_id ) ), 1 );
	}

	public static function on_form_submitted( int $form_id, int $lead_id, array $values, int $submission_id ): void {
		if ( ! self::enabled( 'form.submitted' ) ) { return; }
		self::deliver( 'form.submitted', array( 'form_id' => $form_id, 'lead_id' => $lead_id, 'submission_id' => $submission_id, 'values_keys' => array_keys( $values ) ), 1 );
	}

	public static function on_alert_created( int $alert_id, array $data = array() ): void {
		if ( ! self::enabled( 'alert.created' ) ) { return; }
		self::deliver( 'alert.created', array( 'alert_id' => $alert_id, 'email' => $data['email'] ?? '', 'filters' => $data['filters'] ?? array() ), 1 );
	}

	public static function on_share_logged( int $listing_id, string $channel ): void {
		if ( ! self::enabled( 'share.logged' ) ) { return; }
		self::deliver( 'share.logged', array( 'listing_id' => $listing_id, 'channel' => $channel, 'url' => get_permalink( $listing_id ) ), 1 );
	}

	/**
	 * Deliver a signed payload, retrying transient failures.
	 *
	 * @param string              $event   Event key.
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $attempt Attempt number.
	 * @return void
	 */
	public static function deliver( string $event, array $payload, int $attempt = 1 ): void {
		$urls = array_filter( array( (string) Settings::get( 'webhook_url' ), (string) Settings::get( 'webhook_url_2' ) ) );
		$secret = (string) Settings::get( 'webhook_secret' );
		$version = (string) Settings::get( 'webhook_version', 'v2' );
		if ( ! $urls ) {
			return;
		}
		$body_data = array(
			'event'     => $event,
			'version'   => $version,
			'sent_at'   => gmdate( 'c' ),
			'office'    => Settings::office_name(),
			'data'      => $payload,
		);
		// v2 adds more context
		if ( 'v2' === $version ) {
			$body_data['office_url'] = home_url( '/' );
			$body_data['estat_version'] = defined( 'ESTAT_VERSION' ) ? ESTAT_VERSION : '3.0.1';
		}
		$body      = (string) wp_json_encode( $body_data );
		$timestamp = (string) time();
		$signature = self::sign( $timestamp . '.' . $body, $secret );

		$last_code = 0;
		$last_error = '';
		$overall_success = false;

		foreach ( $urls as $url ) {
			$response = wp_remote_post(
				$url,
				array(
					'timeout'  => 10,
					'blocking' => true,
					'headers'  => array(
						'Content-Type'      => 'application/json',
						'X-Estat-Event'      => $event,
						'X-Estat-Version'    => $version,
						'X-Estat-Timestamp'  => $timestamp,
						'X-Estat-Signature'  => 'sha256=' . $signature,
						'User-Agent'        => 'EstatOS/' . ESTAT_VERSION,
					),
					'body'     => $body,
				)
			);

			$code    = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$error   = is_wp_error( $response ) ? $response->get_error_message() : '';
			$success = $code >= 200 && $code < 300;

			self::log( $event, (int) ( $payload['lead_id'] ?? $payload['visit_id'] ?? $payload['listing_id'] ?? $payload['project_id'] ?? $payload['form_id'] ?? $payload['alert_id'] ?? 0 ), $code, $success, $attempt, $error . ' url=' . $url );
			AuditLog::record( 'webhook.attempt', 'webhook', 0, array( 'event' => $event, 'status' => $code, 'attempt' => $attempt, 'url' => $url ) );

			$last_code = $code;
			$last_error = $error;
			if ( $success ) { $overall_success = true; }
		}

		if ( $overall_success ) {
			return;
		}
		$retry_enabled = Settings::get( 'webhook_retry', true );
		if ( $retry_enabled && $attempt < self::MAX_ATTEMPTS ) {
			wp_schedule_single_event( time() + ( 300 * $attempt ), self::RETRY_HOOK, array( $event, $payload, $attempt + 1 ) );
			return;
		}
		// No email here any more: a failed connection shows on the Webhooks
		// screen with its status code, and the office asked for four emails
		// and no more. The audit line above still records every attempt.
		AuditLog::record( 'webhook.gave_up', 'webhook', 0, array( 'event' => $event, 'status' => $last_code, 'attempts' => self::MAX_ATTEMPTS ) );
	}

	/**
	 * Test webhook — sends ping event to configured URLs.
	 *
	 * @return array{ok:bool,code:int,error:string}
	 */
	public static function test(): array {
		$urls = array_filter( array( (string) Settings::get( 'webhook_url' ), (string) Settings::get( 'webhook_url_2' ) ) );
		if ( ! $urls ) {
			return array( 'ok' => false, 'code' => 0, 'error' => __( 'No address saved for the other program', 'estat-os' ), 'url' => '' );
		}
		$payload = array( 'test' => true, 'message' => 'Estat.OS webhook test', 'time' => gmdate( 'c' ) );
		$event = 'test.ping';
		// Deliver once synchronously for test feedback.
		$url = $urls[0];
		$secret = (string) Settings::get( 'webhook_secret' );
		$version = (string) Settings::get( 'webhook_version', 'v2' );
		$body = wp_json_encode( array( 'event' => $event, 'version' => $version, 'sent_at' => gmdate( 'c' ), 'office' => Settings::office_name(), 'office_url' => home_url('/'), 'estat_version' => ESTAT_VERSION, 'data' => $payload ) );
		$timestamp = (string) time();
		$signature = self::sign( $timestamp . '.' . $body, $secret );
		$response = wp_remote_post( $url, array( 'timeout' => 10, 'blocking' => true, 'headers' => array( 'Content-Type' => 'application/json', 'X-Estat-Event' => $event, 'X-Estat-Version' => $version, 'X-Estat-Timestamp' => $timestamp, 'X-Estat-Signature' => 'sha256=' . $signature, 'User-Agent' => 'EstatOS/' . ESTAT_VERSION ), 'body' => $body ) );
		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		$error = is_wp_error( $response ) ? $response->get_error_message() : '';
		$ok = $code >= 200 && $code < 300;
		return array( 'ok' => $ok, 'code' => $code, 'error' => $error, 'url' => $url );
	}

	/**
	 * Compute the HMAC signature for a payload.
	 *
	 * @param string $message Message to sign.
	 * @param string $secret  Shared secret.
	 * @return string Hex signature.
	 */
	public static function sign( string $message, string $secret ): string {
		return hash_hmac( 'sha256', $message, $secret );
	}

	/**
	 * Constant-time signature verification helper for integrators.
	 *
	 * @param string $message   Message.
	 * @param string $secret    Secret.
	 * @param string $signature Provided signature (hex, no prefix).
	 * @return bool
	 */
	public static function verify( string $message, string $secret, string $signature ): bool {
		return hash_equals( self::sign( $message, $secret ), $signature );
	}

	/**
	 * Record a delivery attempt.
	 *
	 * @param string $event     Event.
	 * @param int    $object_id Object ID.
	 * @param int    $code      HTTP status.
	 * @param bool   $success   Success.
	 * @param int    $attempt   Attempt number.
	 * @param string $error     Error message.
	 * @return void
	 */
	private static function log( string $event, int $object_id, int $code, bool $success, int $attempt, string $error ): void {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			Schema::table( 'estat_webhook_log' ),
			array(
				'created_at'  => current_time( 'mysql', true ),
				'event'       => $event,
				'object_id'   => $object_id,
				'status_code' => $code,
				'success'     => $success ? 1 : 0,
				'attempt'     => $attempt,
				'error'       => mb_substr( $error, 0, 255 ),
			),
			array( '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
		);
	}

	/**
	 * Recent delivery attempts for the settings screen.
	 *
	 * @param int $limit Rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function recent( int $limit = 20 ): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array();
		}
		$table = Schema::table( 'estat_webhook_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", max( 1, min( 100, $limit ) ) ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}
}
