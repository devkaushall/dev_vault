<?php
/**
 * What needs doing next — for one person, or for the whole office.
 *
 * This is the answer to the question a field agent actually has: "ab mujhe
 * kya karna hai?" Saving a record is not the point of the product; finishing
 * the work is. Everything that can be said about a record being unfinished —
 * a follow-up that has passed, a visit today, an enquiry nobody has called, a
 * listing the office sent back, a property whose owner has not been checked
 * for a fortnight — is gathered here, in one shape, with one reason.
 *
 * The office's own to-do list (Data\Worklist) reads from this too, so the
 * phone and the dashboard can never disagree about what is overdue.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Work;

use EstatOS\Data\Agents;
use EstatOS\Data\Health;
use EstatOS\Data\PostTypes;
use EstatOS\Field\Requests;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Status;

defined( 'ABSPATH' ) || exit;

final class MyDay {

	/**
	 * A visit is worth a reminder from this many minutes before it starts.
	 */
	public const VISIT_SOON_MINUTES = 90;

	/**
	 * A property whose owner nobody has checked for this long is stale.
	 */
	public const STALE_DAYS = 14;

	/**
	 * Everything waiting on one person, most urgent first.
	 *
	 * @param int $agent_id Agent record id; 0 for "whoever is signed in".
	 * @param int $limit    How many to return.
	 * @return array<int,array<string,mixed>>
	 */
	public static function tasks( int $agent_id = 0, int $limit = 12 ): array {
		$limit = max( 1, min( 50, $limit ) );

		$tasks = array_merge(
			self::visits_soon(),
			self::overdue_followups( $agent_id ),
			self::new_enquiries( $agent_id ),
			self::sent_back( $agent_id ),
			self::unchecked_properties( $agent_id ),
			self::stale_properties( $agent_id )
		);

		/*
		 * Urgency first, and only then the within-the-hour tiebreaker.
		 *
		 * The old comparator multiplied urgency by a million and added the
		 * order on top — but some jobs carry an epoch as their order, and an
		 * epoch is bigger than a million, so a "check this some day" job
		 * could outrank a visit happening this afternoon. Two separate
		 * comparisons cannot disagree.
		 */
		usort(
			$tasks,
			static function ( array $a, array $b ): int {
				$by_urgency = (int) $a['urgency'] <=> (int) $b['urgency'];
				if ( 0 !== $by_urgency ) {
					return $by_urgency;
				}
				return (int) ( $a['order'] ?? 0 ) <=> (int) ( $b['order'] ?? 0 );
			}
		);

		/*
		 * One person, one job. A brand-new enquiry from somebody whose
		 * follow-up has also passed is one call, not two cards — so after
		 * sorting (most urgent first) the first task about a record is kept
		 * and the rest are dropped.
		 */
		$seen  = array();
		$dedup = array();
		foreach ( $tasks as $task ) {
			$kind = (string) ( $task['kind'] ?? '' );
			$id   = (int) ( $task['id'] ?? 0 );
			if ( '' === $kind ) {
				$dedup[] = $task; // Not about one record — a summary line.
				continue;
			}
			$key = $kind . ':' . $id;
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$dedup[]      = $task;
		}
		$tasks = $dedup;

		/**
		 * Filters the next-action list.
		 *
		 * @param array<int,array<string,mixed>> $tasks Jobs, most urgent first.
		 * @param int                            $agent_id Agent record id.
		 */
		$tasks = (array) apply_filters( 'estat_my_day', $tasks, $agent_id );

		return array_slice( $tasks, 0, $limit );
	}

	/**
	 * The single most useful thing to do next, or null when nothing is
	 * waiting. Every task already carries its own reason; this is just the
	 * first one.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<string,mixed>|null
	 */
	public static function next_action( int $agent_id = 0 ): ?array {
		$tasks = self::tasks( $agent_id, 1 );
		return $tasks ? $tasks[0] : null;
	}

	/**
	 * The four counts the My Day screen opens with.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<string,int>
	 */
	public static function summary( int $agent_id = 0 ): array {
		$scope = self::lead_scope( $agent_id );

		$new = Leads::query( array_merge( $scope, array( 'status' => 'new', 'per_page' => 1 ) ) );

		$due = Leads::query( array_merge( $scope, array( 'due_followup' => true, 'per_page' => 1 ) ) );

		$soon = Visits::query(
			array_merge(
				self::visit_scope( $agent_id ),
				array(
					'from'     => current_time( 'mysql', true ),
					'to'       => gmdate( 'Y-m-d 23:59:59', current_time( 'timestamp', true ) ),
					'per_page' => 1,
				)
			)
		);

		$attention = count( self::unchecked_properties( $agent_id ) ) + count( self::sent_back( $agent_id ) );

		return array(
			'enquiries' => (int) $new['total'],
			'followups' => (int) $due['total'],
			'visits'    => (int) $soon['total'],
			'listings'  => $attention,
		);
	}

	/* ---------------------------------------------------------------------
	 * The jobs themselves
	 * ------------------------------------------------------------------ */

	/**
	 * A visit happening soon — the one thing in this list that is on a clock.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function visits_soon(): array {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			return array();
		}

		$agent_id = Agents::for_user( get_current_user_id() );
		$now      = current_time( 'timestamp', true );

		$found = Visits::query(
			array_merge(
				self::visit_scope(),
				array(
					'from'     => gmdate( 'Y-m-d H:i:s', $now - 2 * HOUR_IN_SECONDS ),
					'to'       => gmdate( 'Y-m-d H:i:s', $now + DAY_IN_SECONDS ),
					'per_page' => 5,
				)
			)
		);

		$out = array();
		foreach ( $found['items'] as $visit ) {
			if ( 'pending' !== (string) $visit['outcome'] ) {
				continue;
			}
			$when  = (int) strtotime( (string) $visit['scheduled_at'] . ' UTC' );
			$lead  = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
			$name  = $lead ? (string) $lead['name'] : __( 'A client', 'estat-os' );
			$soon  = $when - $now <= self::VISIT_SOON_MINUTES * MINUTE_IN_SECONDS && $when >= $now;

			$out[] = self::task(
				array(
					'urgency' => $soon ? 0 : 2,
					'order'   => $when,
					'icon'    => 'calendar',
					'tone'    => $soon ? 'warn' : '',
					'title'   => $soon
						? sprintf(
							/* translators: %s: person's name. */
							__( 'Visit %s in a little while', 'estat-os' ),
							$name
						)
						: sprintf(
							/* translators: %s: person's name. */
							__( 'Visit %s today', 'estat-os' ),
							$name
						),
					/* translators: %s: time of the visit. */
					'detail'  => sprintf( __( 'You are showing a property at %s.', 'estat-os' ), Format::time( (string) $visit['scheduled_at'] ) ),
					'action'  => __( 'Open the visit', 'estat-os' ),
					'url'     => self::visit_url( (int) $visit['id'] ),
					'kind'    => 'visit',
					'id'      => (int) $visit['id'],
				)
			);
		}

		return $out;
	}

	/**
	 * Follow-ups whose day has passed. The most expensive thing to forget.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<int,array<string,mixed>>
	 */
	private static function overdue_followups( int $agent_id = 0 ): array {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			return array();
		}

		$found = Leads::query( array_merge( self::lead_scope( $agent_id ), array( 'due_followup' => true, 'per_page' => 5 ) ) );

		$out = array();
		foreach ( $found['items'] as $lead ) {
			$due = (string) ( $lead['followup_at'] ?? '' );
			$out[] = self::task(
				array(
					'urgency' => 1,
					'icon'    => 'phone',
					'tone'    => 'danger',
					'title'   => sprintf(
						/* translators: %s: person's name. */
						__( 'Call %s', 'estat-os' ),
						self::name_of( $lead )
					),
					'detail'  => '' !== $due
						? sprintf(
							/* translators: %s: date of the follow-up. */
							__( 'The follow-up was set for %s and has passed.', 'estat-os' ),
							Format::date( $due )
						)
						: __( 'The follow-up date has passed.', 'estat-os' ),
					'action'  => __( 'Call now', 'estat-os' ),
					'url'     => self::lead_url( (int) $lead['id'] ),
					'kind'    => 'lead',
					'id'      => (int) $lead['id'],
					'phone'   => (string) $lead['phone'],
				)
			);
		}

		return $out;
	}

	/**
	 * An enquiry nobody has spoken to yet.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<int,array<string,mixed>>
	 */
	private static function new_enquiries( int $agent_id = 0 ): array {
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			return array();
		}

		$found = Leads::query( array_merge( self::lead_scope( $agent_id ), array( 'status' => 'new', 'per_page' => 4 ) ) );

		$out = array();
		foreach ( $found['items'] as $lead ) {
			$wants = self::requirement_line( $lead );
			$out[] = self::task(
				array(
					'urgency' => 2,
					'order'   => -(int) strtotime( (string) $lead['created_at'] . ' UTC' ),
					'icon'    => 'inbox',
					'tone'    => 'warn',
					'title'   => sprintf(
						/* translators: %s: person's name. */
						__( 'Say hello to %s', 'estat-os' ),
						self::name_of( $lead )
					),
					'detail'  => '' !== $wants
						? $wants
						: __( 'A new enquiry nobody has answered yet.', 'estat-os' ),
					'action'  => __( 'Open enquiry', 'estat-os' ),
					'url'     => self::lead_url( (int) $lead['id'] ),
					'kind'    => 'lead',
					'id'      => (int) $lead['id'],
					'phone'   => (string) $lead['phone'],
				)
			);
		}

		return $out;
	}

	/**
	 * A property the office sent back for changes — the agent cannot move it
	 * on until they have done what was asked.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<int,array<string,mixed>>
	 */
	private static function sent_back( int $agent_id = 0 ): array {
		$mine = self::my_records( $agent_id );

		$out = array();
		foreach ( $mine as $post ) {
			if ( 'draft' !== $post->post_status ) {
				continue;
			}
			$asked = (string) get_post_meta( (int) $post->ID, '_estat_changes_asked', true );
			if ( '' === $asked ) {
				continue;
			}
			$out[] = self::task(
				array(
					'urgency' => 1,
					'order'   => -(int) strtotime( (string) $post->post_modified_gmt . ' UTC' ),
					'icon'    => 'pencil',
					'tone'    => 'danger',
					'title'   => sprintf(
						/* translators: %s: property name. */
						__( 'Needs changes: %s', 'estat-os' ),
						(string) $post->post_title
					),
					'detail'  => __( 'The office asked for something to be put right before this can go live.', 'estat-os' ),
					'action'  => __( 'Open property', 'estat-os' ),
					'url'     => self::record_url( (int) $post->ID ),
					'kind'    => 'listing',
					'id'      => (int) $post->ID,
				)
			);
		}

		return $out;
	}

	/**
	 * A live property nobody has checked — no owner confirmation, no office
	 * verification. What the agent tells a client has to be true.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<int,array<string,mixed>>
	 */
	private static function unchecked_properties( int $agent_id = 0 ): array {
		$mine = self::my_records( $agent_id );

		$out = array();
		foreach ( $mine as $post ) {
			if ( 'publish' !== $post->post_status ) {
				continue;
			}
			$verification = (string) get_post_meta( (int) $post->ID, '_estat_verification', true );
			if ( '' !== $verification && 'unverified' !== $verification ) {
				continue;
			}
			$out[] = self::task(
				array(
					'urgency' => 3,
					'order'   => -(int) strtotime( (string) $post->post_modified_gmt . ' UTC' ),
					'icon'    => 'check-circle',
					'tone'    => 'warn',
					'title'   => sprintf(
						/* translators: %s: property name. */
						__( 'Check with the owner: %s', 'estat-os' ),
						(string) $post->post_title
					),
					'detail'  => __( 'Nobody has confirmed this one with the owner yet. A wrong price on a live page costs a client.', 'estat-os' ),
					'action'  => __( 'Confirm with owner', 'estat-os' ),
					'url'     => self::owner_url( (int) $post->ID ),
					'kind'    => 'listing',
					'id'      => (int) $post->ID,
				)
			);
		}

		return $out;
	}

	/**
	 * Live inventory whose owner-check has gone stale.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<int,array<string,mixed>>
	 */
	private static function stale_properties( int $agent_id = 0 ): array {
		$mine  = self::my_records( $agent_id );
		$now   = current_time( 'timestamp', true );
		$count = 0;

		foreach ( $mine as $post ) {
			if ( 'publish' !== $post->post_status ) {
				continue;
			}
			$checked = (string) get_post_meta( (int) $post->ID, '_estat_owner_checked_at', true );
			$when    = '' !== $checked ? (int) strtotime( $checked . ' UTC' ) : 0;
			if ( $when > 0 && ( $now - $when ) < self::STALE_DAYS * DAY_IN_SECONDS ) {
				continue;
			}
			if ( 0 === $when && ( $now - (int) strtotime( (string) $post->post_modified_gmt . ' UTC' ) ) < self::STALE_DAYS * DAY_IN_SECONDS ) {
				continue; // Freshly written; not stale yet.
			}
			++$count;
		}

		if ( 0 === $count ) {
			return array();
		}

		return array(
			self::task(
				array(
					'urgency' => 4,
					'icon'    => 'clock',
					'tone'    => '',
					'title'   => sprintf(
						/* translators: %d: how many properties. */
						_n( '%d property has not been checked lately', '%d properties have not been checked lately', $count, 'estat-os' ),
						$count
					),
					/* translators: %d: how many days. */
					'detail'  => sprintf( __( 'Nothing has confirmed the price or that they are still available for %d days. Ring round the owners when you have a quiet hour.', 'estat-os' ), self::STALE_DAYS ),
					'action'  => __( 'Check one now', 'estat-os' ),
					'url'     => self::owner_url( $mine ? (int) $mine[0]->ID : 0 ),
					'kind'    => 'listing',
					'id'      => 0,
				)
			),
		);
	}

	/**
	 * One job, with every field present so callers never have to guess.
	 *
	 * @param array<string,mixed> $data Job.
	 * @return array<string,mixed>
	 */
	private static function task( array $data ): array {
		return array_merge(
			array(
				'urgency' => 5,
				'order'   => 0,
				'icon'    => 'menu',
				'tone'    => '',
				'kind'    => '',
				'id'      => 0,
				'phone'   => '',
				'title'   => '',
				'detail'  => '',
				'action'  => __( 'Open', 'estat-os' ),
				'url'     => '',
			),
			$data
		);
	}

	private static function name_of( array $lead ): string {
		$name = trim( (string) ( $lead['name'] ?? '' ) );
		return '' !== $name ? $name : __( 'This client', 'estat-os' );
	}

	/**
	 * What the client asked for, in one line — the thing an agent needs before
	 * dialling, without opening anything.
	 *
	 * @param array<string,mixed> $lead Lead row.
	 * @return string
	 */
	public static function requirement_line( array $lead ): string {
		$bits = array();

		$intent = (string) ( $lead['intent'] ?? '' );
		if ( '' !== $intent ) {
			$bits[] = \EstatOS\Support\Vocabulary::label( 'lead_intents', $intent );
		}
		$locality = trim( (string) ( $lead['locality'] ?? '' ) );
		if ( '' !== $locality ) {
			$bits[] = $locality;
		}
		$min = (int) ( $lead['budget_min'] ?? 0 );
		$max = (int) ( $lead['budget_max'] ?? 0 );
		if ( $min > 0 || $max > 0 ) {
			$bits[] = $min > 0 && $max > 0
				? Format::money( $min ) . ' – ' . Format::money( $max )
				: Format::money( $min > 0 ? $min : $max );
		}

		return implode( ' · ', array_filter( $bits ) );
	}

	/**
	 * Which enquiries this person may see, as a Leads query fragment.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<string,mixed>
	 */
	private static function lead_scope( int $agent_id = 0 ): array {
		if ( \EstatOS\Pocket\Pocket::is_office() ) {
			return array();
		}
		$agent_id = $agent_id > 0 ? $agent_id : (int) Agents::for_user( get_current_user_id() );
		return array( 'agent_id' => $agent_id );
	}

	/**
	 * Visits: agents see their own, the office sees all.
	 *
	 * @param int $agent_id Agent record id.
	 * @return array<string,mixed>
	 */
	private static function visit_scope( int $agent_id = 0 ): array {
		if ( \EstatOS\Pocket\Pocket::is_office() ) {
			return array();
		}
		$agent_id = $agent_id > 0 ? $agent_id : (int) Agents::for_user( get_current_user_id() );
		return array( 'agent_id' => $agent_id );
	}

	private static function may_see_lead( array $lead, int $agent_id = 0 ): bool {
		if ( \EstatOS\Pocket\Pocket::is_office() ) {
			return true;
		}
		$agent_id = $agent_id > 0 ? $agent_id : (int) Agents::for_user( get_current_user_id() );
		return (int) ( $lead['assigned_agent_id'] ?? 0 ) === $agent_id
			|| (int) ( $lead['agent_id'] ?? 0 ) === $agent_id
			|| ( ! empty( $lead['listing_id'] ) && \EstatOS\Pocket\Pocket::owns( (int) $lead['listing_id'] ) );
	}

	/**
	 * The records this person is responsible for.
	 *
	 * @param int $agent_id Agent record id.
	 * @return \WP_Post[]
	 */
	private static function my_records( int $agent_id = 0 ): array {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			return array();
		}
		$posts = \EstatOS\Pocket\Pocket::my_records( '', PostTypes::LISTING );
		return is_array( $posts ) ? $posts : array();
	}

	/* --------------------------------------------------------- links */

	private static function lead_url( int $lead_id ): string {
		return \EstatOS\Pocket\Pocket::url( 'enquiry', $lead_id );
	}

	private static function visit_url( int $visit_id ): string {
		return \EstatOS\Pocket\Pocket::url( 'visit', $visit_id );
	}

	/**
	 * The owner update screen for one property.
	 *
	 * Checking with the owner is three questions on one screen, not a form —
	 * so every "the owner has not been asked" task points at that screen
	 * with the property already chosen.
	 *
	 * @param int $record_id Listing ID; 0 opens the picker.
	 * @return string
	 */
	private static function owner_url( int $record_id = 0 ): string {
		$url = \EstatOS\Pocket\Pocket::url( 'capture-owner' );
		return $record_id > 0 ? add_query_arg( 'record', $record_id, $url ) : $url;
	}

	private static function record_url( int $record_id, int $fallback = 0 ): string {
		$id = $record_id > 0 ? $record_id : $fallback;
		return $id > 0 ? \EstatOS\Pocket\Pocket::url( 'listing', $id ) : \EstatOS\Pocket\Pocket::url( 'listings' );
	}

	/**
	 * Health rules for one property, said in plain words. Used by the phone
	 * before anything is sent to the office.
	 *
	 * @param int $record_id Listing id.
	 * @return array<int,string>
	 */
	public static function worries( int $record_id ): array {
		$data = \EstatOS\Data\Listings::to_array( $record_id );
		if ( ! $data ) {
			return array();
		}

		$out = array();

		// The title is a promise: "4 BHK" and three bedrooms is a call that
		// ends badly.
		$said = Health::bedrooms_in_title( (string) ( $data['title'] ?? '' ) );
		$real = (int) ( $data['bedrooms'] ?? 0 );
		if ( $said > 0 && $real > 0 && $said !== $real ) {
			$out[] = sprintf(
				/* translators: 1: number said in the title, 2: number filled in the bedrooms box. */
				__( 'The title says %1$d bedrooms, but the bedrooms box says %2$d.', 'estat-os' ),
				$said,
				$real
			);
		}

		if ( (int) ( $data['price'] ?? 0 ) <= 0 && (int) ( $data['rent'] ?? 0 ) <= 0 ) {
			$out[] = __( 'There is no price or rent filled in.', 'estat-os' );
		}

		if ( (int) ( $data['area'] ?? 0 ) <= 0 ) {
			$out[] = __( 'The size is missing.', 'estat-os' );
		}

		if ( '' === (string) get_post_meta( $record_id, '_estat_owner_checked_at', true ) ) {
			$out[] = __( 'Nobody has confirmed the price and availability with the owner yet.', 'estat-os' );
		}

		$photos = (int) ( $data['gallery_count'] ?? 0 );
		if ( $photos <= 0 ) {
			$out[] = __( 'No photograph has been added yet.', 'estat-os' );
		}

		return $out;
	}
}
