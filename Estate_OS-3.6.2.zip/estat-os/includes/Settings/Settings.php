<?php
/**
 * Office settings: schema, defaults, sanitising and access.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Settings;

use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * All office configuration lives in one option row, sanitised through one
 * function so that corrupt or partial data can never break the plugin.
 */
final class Settings {

	/**
	 * Option key. Part of the public data contract.
	 */
	public const OPTION = 'estat_settings';

	/**
	 * Notification switches the office retired.
	 *
	 * Four emails remain (a new enquiry, a property waiting for approval, the
	 * morning summary, the weekly report). These fifteen used to exist, are on
	 * no screen, and are read by no code — they are listed here only so a
	 * saved settings record from an older version can be cleaned up rather
	 * than left carrying switches that do nothing.
	 */
	private const RETIRED_NOTIFY_KEYS = array(
		'notify_lead_status', 'notify_lead_assigned', 'notify_new_visit', 'notify_visit_completed',
		'notify_change_request', 'notify_listing_published', 'notify_listing_verified', 'notify_project_stage',
		'notify_form_submitted', 'notify_alert_created', 'notify_followup', 'notify_expiry',
		'notify_import', 'notify_webhook_fail', 'notify_share',
	);

	/**
	 * Runtime cache.
	 *
	 * @var array<string,mixed>|null
	 */
	private static ?array $cache = null;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'add_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
	}

	/**
	 * Default settings.
	 *
	 * @return array<string,mixed>
	 */
	public static function defaults(): array {
		return array(
			// Office identity.
			'office_name'        => 'Mayfair Properties & Developers',
			'tagline'            => 'Developer and channel partner in Gurugram',
			'contact_person'     => '',
			// Shown in front of each property's reference number, e.g. "MPD-42".
			// Kept as a setting so a new office does not need code changes.
			'ref_prefix'         => '',
			'phone'              => '+91 98737 12902',
			'whatsapp'           => '+91 98737 12902',
			'email'              => 'mayfairpropertiesofficial@gmail.com',
			'address'            => 'P-106, Sohna-Gurgaon Road, Sector 48, Gurugram',
			'office_hours'       => 'Mon to Sun, 10 am to 6 pm',
			'logo_id'            => 0,

			// Locale and money.
			'country'            => 'IN',
			'currency'           => 'INR',
			'currency_symbol'    => '₹',
			'price_format'       => 'indian',
			'default_area_unit'  => 'sqft',
			'cities'             => array( 'Gurugram' ),
			// The one city the office works in. Everything on screen reads this.
			'city'               => 'Gurugram',

			// Maps.
			'map_provider'       => 'osm',
			'google_maps_key'    => '',
			'map_default_lat'    => '',
			'map_default_lng'    => '',
			'map_default_zoom'   => 11,

			// Regulatory.
			'regulatory_label'   => 'RERA',
			'show_regulatory'    => true,

			// Language.
			'language'           => 'auto',
			'frontend_language'  => 'auto',
			'allow_visitor_lang' => true,

			// Operations.
			'verification_mode'  => 'optional',
			'listing_expiry_days'=> 0,
			'retention_days'     => 0,
			'practice_mode'      => false,
			'admin_theme'        => 'light',
			'inbound_secret'  => '',
			'multi_agency'       => false,

			// Website pages the plugin built for this office, as key => post ID.
			'pages'              => array(),
			'setup_done'         => false,

			// Website features.
			'enable_favorites'   => true,
			'enable_compare'     => true,
			'enable_schema'      => true,
			'listings_per_page'  => 12,

			// Integrations — F11 enhanced.
			'webhook_enabled'    => false,
			// Forms built in Elementor: their messages also come into Enquiries.
			'elementor_forms_to_enquiries' => true,
			'webhook_url'        => '',
			'webhook_url_2'      => '',
			'webhook_secret'     => '',
			'webhook_version'    => 'v2',
			'webhook_retry'      => true,
			'webhook_events'     => array( 'lead.created', 'lead.updated', 'visit.scheduled' ),

			// The four emails the office asked for, and the ones it retired.
			// Retired keys are kept in the option so nothing is lost if one
			// comes back, but sanitize() pins them off for good.
			'notify_email'       => '',
			'email_from_name'    => '',
			'email_from_address' => '',
			'email_footer_text'  => '',
			'notify_new_lead'    => true,
			'notify_listing_approval' => true,
			'notify_daily_summary'    => true,
			'notify_weekly_report'    => true,

			// the office v3 additions — F0, B7, etc.
			'enabled_filters'      => array_keys( \EstatOS\Support\Vocabulary::all_filters() ),
			'filter_order'         => array_keys( \EstatOS\Support\Vocabulary::all_filters() ),
			'design_tokens'        => array(),
			// 3.0.7: hide behind setting default OFF until double opt-in works (item 11).
			'search_alerts_enabled'=> false,
			'share_enabled'        => true,
			'print_enabled'        => true,
			'emi_enabled'          => true,

			/*
			 * Who draws a single property page.
			 *
			 * 'theme'  — the website keeps doing what it does today: the theme,
			 *            or an Elementor template, draws the page and the plugin
			 *            only supplies the pieces (widgets, shortcodes).
			 * 'plugin' — the plugin's own template draws it, for sites without
			 *            a theme template of their own.
			 *
			 * The default is 'theme' on purpose: Elementor is the office's own
			 * choice of tool, and a plugin that quietly replaces a page
			 * somebody designed is a plugin people learn to fear.
			 */
			'page_renderer'        => 'theme',

			// A WhatsApp button that starts a chat about one property, with
			// the property's name and link already written for the visitor.
			'whatsapp_cta_enabled' => true,
			'whatsapp_cta_text'    => '',
			'emi_default_rate'     => 8.5,
			'emi_default_years'    => 20,
			'locality_pages'       => true,
			'test_mail_last_sent'  => '',
			'just_listed_days'     => 7,
			'completeness_threshold'=> 70,
			/*
			 * The staff phone app. Both default to the way the app behaved
			 * before these switches existed, so nothing changes for an office
			 * that never opens the Settings page.
			 */
			'pocket_show_enquiries'  => true,
			'pocket_agents_edit_live'=> false,
			'consent_text'         => 'I agree to be contacted about this enquiry.',
			'privacy_url'          => '',
			'price_on_request_label'=> 'Price on request',
			// F1 Leads.
			'lead_assign_rules'    => array(),
			'lead_fallback_agent'  => 0,

			// Public pages — 3.0.7 draft only via button

			// Danger zone.
			'delete_data_on_uninstall' => false,
		);
	}

	/**
	 * Get all settings merged over defaults.
	 *
	 * @return array<string,mixed>
	 */
	public static function all(): array {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION, array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$cache = self::sanitize( array_merge( self::defaults(), $stored ) );
		}
		return self::$cache;
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback when unknown.
	 * @return mixed
	 */
	public static function get( string $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Persist a partial update (merged over current values).
	 *
	 * @param array<string,mixed> $values Values to update.
	 * @return array<string,mixed> Saved settings.
	 */
	public static function update( array $values ): array {
		$merged = self::sanitize( array_merge( self::all(), $values ) );
		update_option( self::OPTION, $merged, false );
		self::$cache = $merged;
		return $merged;
	}

	/**
	 * Flush the runtime cache.
	 *
	 * @return void
	 */
	public static function flush(): void {
		self::$cache = null;
	}

	/**
	 * Sanitize a full settings array. Unknown keys are dropped.
	 *
	 * @param array<string,mixed> $input Raw values.
	 * @return array<string,mixed>
	 */
	public static function sanitize( array $input ): array {
		$d   = self::defaults();
		$out = $d;

		$text_keys = array( 'office_name', 'tagline', 'contact_person', 'office_hours', 'currency', 'currency_symbol', 'regulatory_label', 'country', 'ref_prefix', 'city', 'email_from_name' );

		// Reference prefix becomes part of a printed code, so keep it short and
		// free of anything that would look odd in "ABC-42". Empty means no
		// prefix is shown at all.
		if ( isset( $out['ref_prefix'] ) ) {
			$out['ref_prefix'] = substr( preg_replace( '/[^A-Za-z0-9]/', '', (string) $out['ref_prefix'] ), 0, 8 );
		}
		foreach ( $text_keys as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$out[ $key ] = Sanitize::text( $input[ $key ] );
			}
		}

		$out['phone']    = isset( $input['phone'] ) ? Sanitize::phone( $input['phone'] ) : $d['phone'];
		$out['whatsapp'] = isset( $input['whatsapp'] ) ? Sanitize::phone( $input['whatsapp'] ) : $d['whatsapp'];
		$out['email']    = isset( $input['email'] ) ? Sanitize::email( $input['email'] ) : $d['email'];
		$out['address']  = isset( $input['address'] ) ? Sanitize::textarea( $input['address'] ) : $d['address'];
		$out['logo_id']  = isset( $input['logo_id'] ) ? Sanitize::int( $input['logo_id'] ) : 0;

		$out['price_format']      = Sanitize::choice( $input['price_format'] ?? '', array( 'indian', 'international' ), $d['price_format'] );
		$out['default_area_unit'] = Sanitize::choice( $input['default_area_unit'] ?? '', Vocabulary::keys( 'area_units' ), $d['default_area_unit'] );
		$out['map_provider']      = Sanitize::choice( $input['map_provider'] ?? '', array( 'osm', 'google', 'none' ), $d['map_provider'] );
		$out['verification_mode'] = Sanitize::choice( $input['verification_mode'] ?? '', array( 'optional', 'required' ), $d['verification_mode'] );
		$out['page_renderer']     = Sanitize::choice( $input['page_renderer'] ?? '', array( 'theme', 'plugin' ), $d['page_renderer'] ?? 'theme' );
		$out['whatsapp_cta_text'] = Sanitize::text( $input['whatsapp_cta_text'] ?? $d['whatsapp_cta_text'] ?? '' );
		// The allowed values come from the language module itself, so a new
		// language can never be offered in the form and then thrown away here.
		$language_choices         = array_keys( \EstatOS\I18n\Language::choices() );
		$out['language']          = Sanitize::choice( $input['language'] ?? '', $language_choices, $d['language'] );
		$out['frontend_language'] = Sanitize::choice( $input['frontend_language'] ?? '', $language_choices, $d['frontend_language'] );

		if ( isset( $input['cities'] ) ) {
			$cities = is_string( $input['cities'] ) ? preg_split( '/[\r\n,]+/', $input['cities'] ) : $input['cities'];
			$cities = is_array( $cities ) ? $cities : array();
			$cities = array_values( array_filter( array_map( array( Sanitize::class, 'text' ), $cities ) ) );
			$out['cities'] = array_slice( $cities, 0, 200 );
		}

		$out['google_maps_key']  = isset( $input['google_maps_key'] ) ? Sanitize::text( $input['google_maps_key'] ) : $d['google_maps_key'];
		$out['map_default_lat']  = isset( $input['map_default_lat'] ) ? Sanitize::latitude( $input['map_default_lat'] ) : '';
		$out['map_default_lng']  = isset( $input['map_default_lng'] ) ? Sanitize::longitude( $input['map_default_lng'] ) : '';
		$out['map_default_zoom'] = Sanitize::int( $input['map_default_zoom'] ?? $d['map_default_zoom'], 1, 20 );

		$out['admin_theme'] = Sanitize::choice(
			$input['admin_theme'] ?? $d['admin_theme'],
			array( 'light', 'dark', 'auto' ),
			'light'
		);

		// The shared key that lets an outside form tool post an enquiry in.
		$out['inbound_secret'] = Sanitize::text( $input['inbound_secret'] ?? $d['inbound_secret'] );

		$out['listing_expiry_days'] = Sanitize::int( $input['listing_expiry_days'] ?? 0, 0, 3650 );
		$out['retention_days']      = Sanitize::int( $input['retention_days'] ?? 0, 0, 3650 );
		$out['listings_per_page']   = Sanitize::int( $input['listings_per_page'] ?? $d['listings_per_page'], 1, 60 );

		$bools = array(
			'show_regulatory', 'allow_visitor_lang', 'practice_mode', 'multi_agency',
			'whatsapp_cta_enabled',
			'enable_favorites', 'enable_compare', 'enable_schema', 'webhook_enabled', 'webhook_retry',
			'notify_new_lead', 'notify_listing_approval', 'notify_daily_summary', 'notify_weekly_report',
			'delete_data_on_uninstall',
			'search_alerts_enabled', 'share_enabled', 'print_enabled', 'emi_enabled', 'locality_pages',
			'elementor_forms_to_enquiries',
			'pocket_show_enquiries', 'pocket_agents_edit_live',
		);
		foreach ( $bools as $key ) {
			$out[ $key ] = array_key_exists( $key, $input ) ? Sanitize::bool( $input[ $key ] ) : (bool) $d[ $key ];
		}

		/*
		 * The office asked for four emails and no more. Fifteen switches that
		 * used to mail about every small thing still sat in the saved
		 * settings — invisible, doing nothing, and impossible for the office
		 * to be rid of. They are taken out of the option here, so what is
		 * stored matches what the screens show.
		 */
		foreach ( self::RETIRED_NOTIFY_KEYS as $retired ) {
			unset( $out[ $retired ] );
		}

		// Enabled filters — 23 toggles.
		if ( isset( $input['enabled_filters'] ) && is_array( $input['enabled_filters'] ) ) {
			$allowed = array_keys( Vocabulary::all_filters() );
			$out['enabled_filters'] = array_values( array_intersect( array_map( 'sanitize_key', $input['enabled_filters'] ), $allowed ) );
			if ( ! $out['enabled_filters'] ) {
				$out['enabled_filters'] = $allowed;
			}
		}
		// F9: filter order — full 23 in custom order.
		if ( isset( $input['filter_order'] ) && is_array( $input['filter_order'] ) ) {
			$allowed = array_keys( Vocabulary::all_filters() );
			$ordered = array_values( array_intersect( array_map( 'sanitize_key', $input['filter_order'] ), $allowed ) );
			// Add any missing to preserve completeness.
			foreach ( $allowed as $k ) {
				if ( ! in_array( $k, $ordered, true ) ) {
					$ordered[] = $k;
				}
			}
			$out['filter_order'] = $ordered;
		}
		if ( isset( $input['filter_order_csv'] ) && is_string( $input['filter_order_csv'] ) ) {
			$parts = array_filter( array_map( 'sanitize_key', explode( ',', $input['filter_order_csv'] ) ) );
			$allowed = array_keys( Vocabulary::all_filters() );
			$ordered = array_values( array_intersect( $parts, $allowed ) );
			foreach ( $allowed as $k ) {
				if ( ! in_array( $k, $ordered, true ) ) {
					$ordered[] = $k;
				}
			}
			$out['filter_order'] = $ordered;
		}

		// Design tokens — freeform but sanitized.
		if ( isset( $input['design_tokens'] ) && is_array( $input['design_tokens'] ) ) {
			$tokens = array();
			foreach ( $input['design_tokens'] as $k => $v ) {
				$k = sanitize_key( (string) $k );
				$v = Sanitize::text( $v );
				if ( '' !== $k && '' !== $v ) {
					$tokens[ $k ] = $v;
				}
			}
			$out['design_tokens'] = $tokens;
		}

		$out['test_mail_last_sent'] = isset( $input['test_mail_last_sent'] ) ? Sanitize::text( $input['test_mail_last_sent'] ) : '';
		$out['emi_default_rate'] = isset( $input['emi_default_rate'] ) ? Sanitize::float( $input['emi_default_rate'] ) : (float) $d['emi_default_rate'];
		$out['emi_default_years'] = isset( $input['emi_default_years'] ) ? Sanitize::int( $input['emi_default_years'], 1, 40 ) : (int) $d['emi_default_years'];
		$out['just_listed_days'] = Sanitize::int( $input['just_listed_days'] ?? $d['just_listed_days'], 1, 90 );
		$out['completeness_threshold'] = Sanitize::int( $input['completeness_threshold'] ?? $d['completeness_threshold'], 0, 100 );
		$out['consent_text'] = isset( $input['consent_text'] ) ? Sanitize::textarea( $input['consent_text'] ) : $d['consent_text'];
		$out['privacy_url'] = isset( $input['privacy_url'] ) ? Sanitize::url( $input['privacy_url'] ) : '';
		$out['price_on_request_label'] = isset( $input['price_on_request_label'] ) ? Sanitize::text( $input['price_on_request_label'] ) : $d['price_on_request_label'];

		// F1: lead auto-assign rules intent => agent_id.
		$out['lead_fallback_agent'] = isset( $input['lead_fallback_agent'] ) ? Sanitize::int( $input['lead_fallback_agent'] ) : 0;
		if ( isset( $input['lead_assign_rules'] ) && is_array( $input['lead_assign_rules'] ) ) {
			$rules = array();
			foreach ( $input['lead_assign_rules'] as $intent => $agent ) {
				$intent = sanitize_key( (string) $intent );
				$agent  = Sanitize::int( $agent );
				if ( '' !== $intent && $agent >= 0 ) {
					$rules[ $intent ] = $agent;
				}
			}
			$out['lead_assign_rules'] = $rules;
		}

		// The office's website pages: a small map of known key => post ID.
		$pages     = isset( $input['pages'] ) && is_array( $input['pages'] ) ? $input['pages'] : array();
		$out['pages'] = array();
		foreach ( $pages as $page_key => $page_id ) {
			$page_key = sanitize_key( (string) $page_key );
			$page_id  = Sanitize::int( $page_id );
			if ( '' !== $page_key && $page_id > 0 ) {
				$out['pages'][ $page_key ] = $page_id;
			}
		}
		$out['setup_done'] = array_key_exists( 'setup_done', $input ) ? Sanitize::bool( $input['setup_done'] ) : (bool) $d['setup_done'];

		$out['webhook_url']    = isset( $input['webhook_url'] ) ? Sanitize::url( $input['webhook_url'] ) : '';
		$out['webhook_url_2']  = isset( $input['webhook_url_2'] ) ? Sanitize::url( $input['webhook_url_2'] ) : '';
		$out['webhook_secret'] = isset( $input['webhook_secret'] ) ? Sanitize::text( $input['webhook_secret'] ) : '';
		$out['webhook_version'] = Sanitize::choice( $input['webhook_version'] ?? $d['webhook_version'], array( 'v1', 'v2' ), $d['webhook_version'] );
		if ( 0 === strpos( $out['webhook_url'], 'http://' ) ) {
			$out['webhook_url'] = '';
		}
		if ( 0 === strpos( $out['webhook_url_2'], 'http://' ) ) {
			$out['webhook_url_2'] = '';
		}

		$allowed_events        = array( 'lead.created', 'lead.updated', 'lead.status_changed', 'lead.assigned', 'visit.scheduled', 'visit.completed', 'listing.published', 'listing.verified', 'project.stage_changed', 'form.submitted', 'alert.created', 'share.logged' );
		$events                = isset( $input['webhook_events'] ) && is_array( $input['webhook_events'] ) ? $input['webhook_events'] : $d['webhook_events'];
		$out['webhook_events'] = array_values( array_intersect( array_map( array( Sanitize::class, 'text' ), $events ), $allowed_events ) );

		$out['notify_email'] = isset( $input['notify_email'] ) ? Sanitize::email( $input['notify_email'] ) : '';

		// Who our emails appear to come from, and the line at the bottom.
		// Empty means WordPress decides, which is what happened before.
		$out['email_from_address'] = isset( $input['email_from_address'] ) ? Sanitize::email( $input['email_from_address'] ) : '';
		$out['email_footer_text']  = isset( $input['email_footer_text'] ) ? Sanitize::textarea( $input['email_footer_text'] ) : '';

		/**
		 * Filter sanitised settings, e.g. to add settings from an add-on.
		 *
		 * @param array<string,mixed> $out   Sanitised values.
		 * @param array<string,mixed> $input Raw values.
		 */
		return (array) apply_filters( 'estat_sanitize_settings', $out, $input );
	}

	/**
	 * The notification recipient, falling back to the site admin.
	 *
	 * @return string
	 */
	public static function notification_email(): string {
		$email = (string) self::get( 'notify_email', '' );
		if ( '' === $email ) {
			$email = (string) get_option( 'admin_email', '' );
		}
		return $email;
	}

	/**
	 * Office display name with a safe fallback.
	 *
	 * @return string
	 */
	public static function office_name(): string {
		$name = (string) self::get( 'office_name', '' );
		return '' !== $name ? $name : (string) get_bloginfo( 'name' );
	}
}
