<?php
/**
 * Enquiry (lead) repository — F1 Leads pipeline (the office Beta).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Leads;

use EstatOS\Audit\AuditLog;
use EstatOS\Install\Schema;
use EstatOS\Settings\Settings;
use EstatOS\Support\Sanitize;
use EstatOS\Support\Vocabulary;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * F1: every form submission becomes a Lead, with timeline, dedupe 30d, auto-assign, spam handling.
 */
final class Leads {

	/**
	 * Dedupe window: same phone/email within 30 days → merge.
	 */
	public const DEDUPE_WINDOW = 2592000; // 30 * DAY_IN_SECONDS

	public const PHONE_IDENTITY_DIGITS = 10;

	public function register(): void {}

	/**
	 * Normalize phone to E.164-ish (India focused).
	 *
	 * @param string $phone Raw phone.
	 * @return string Normalized.
	 */
	public static function normalize_phone( string $phone ): string {
		$digits = preg_replace( '/\D/', '', $phone );
		$digits = (string) $digits;
		if ( '' === $digits ) {
			return '';
		}
		// Indian 10-digit → +91.
		if ( 10 === strlen( $digits ) ) {
			return '+91' . $digits;
		}
		// 12 digits starting with 91 → +91...
		if ( 12 === strlen( $digits ) && 0 === strpos( $digits, '91' ) ) {
			return '+' . $digits;
		}
		// 11 digits starting with 0 → strip 0, then +91 if 10 left.
		if ( 11 === strlen( $digits ) && '0' === $digits[0] ) {
			$rest = substr( $digits, 1 );
			if ( 10 === strlen( $rest ) ) {
				return '+91' . $rest;
			}
		}
		// Already with +? Keep digits with +.
		if ( '' !== $phone && '+' === $phone[0] ) {
			return '+' . $digits;
		}
		return $digits;
	}

	private static function phone_identity( string $phone ): string {
		$digits = (string) preg_replace( '/\D/', '', $phone );
		if ( strlen( $digits ) <= self::PHONE_IDENTITY_DIGITS ) {
			return $digits;
		}
		return substr( $digits, -self::PHONE_IDENTITY_DIGITS );
	}

	/**
	 * Prepare raw input to stored shape — F1 spec.
	 *
	 * @param array<string,mixed> $input Raw.
	 * @return array<string,mixed>
	 */
	private static function prepare( array $input ): array {
		$name    = Sanitize::text( $input['name'] ?? '' );
		$phone_raw = Sanitize::phone( $input['phone'] ?? '' );
		$phone   = self::normalize_phone( $phone_raw );
		$email   = Sanitize::email( $input['email'] ?? '' );
		$listing = Sanitize::int( $input['listing_id'] ?? 0 );
		$project = Sanitize::int( $input['project_id'] ?? 0 );

		$identity = strtolower( $email ) . '|' . self::phone_identity( $phone_raw );
		$hash     = hash( 'sha256', $identity . '|' . $listing . '|' . $project );

		$key = Sanitize::text( $input['idempotency_key'] ?? '' );
		$key = '' !== $key ? hash( 'sha256', $key ) : '';

		// Intent detection from fields or explicit.
		$intent = Sanitize::choice( $input['intent'] ?? '', array_keys( Vocabulary::lead_intents() ), '' );
		if ( '' === $intent && isset( $input['message'] ) ) {
			$msg = strtolower( (string) $input['message'] );
			if ( false !== strpos( $msg, 'rent' ) ) {
				$intent = 'rent';
			} elseif ( false !== strpos( $msg, 'buy' ) ) {
				$intent = 'buy';
			} elseif ( false !== strpos( $msg, 'sell' ) ) {
				$intent = 'sell';
			}
		}

		// Source handling: form:{id}|whatsapp|call|manual|import
		$source_raw = Sanitize::text( $input['source'] ?? 'website' );
		$source = $source_raw;
		if ( isset( $input['form_id'] ) && (int) $input['form_id'] > 0 ) {
			$source = 'form:' . (int) $input['form_id'];
		}

		// Budget may come as budget_min/max or single budget.
		$budget_min = isset( $input['budget_min'] ) ? Sanitize::float( $input['budget_min'] ) : ( isset( $input['_estat_budget_min'] ) ? Sanitize::float( $input['_estat_budget_min'] ) : 0 );
		$budget_max = isset( $input['budget_max'] ) ? Sanitize::float( $input['budget_max'] ) : ( isset( $input['_estat_budget_max'] ) ? Sanitize::float( $input['_estat_budget_max'] ) : 0 );
		if ( 0 === $budget_min && 0 === $budget_max && isset( $input['budget'] ) ) {
			$budget_min = Sanitize::float( $input['budget'] );
			$budget_max = $budget_min;
		}

		return array(
			'name'                 => $name,
			'phone'                => $phone,
			'phone_raw'            => $phone_raw,
			'email'                => $email,
			'message'              => Sanitize::textarea( $input['message'] ?? '' ),
			'intent'               => $intent,
			'locality'             => Sanitize::text( $input['locality'] ?? '' ),
			'budget_min'           => $budget_min,
			'budget_max'           => $budget_max,
			'source'               => Sanitize::choice( $source_raw, array( 'website', 'form', 'elementor', 'whatsapp', 'call', 'manual', 'import', 'api', 'other' ), 'website' ),
			'source_full'          => $source, // form:xx kept separately.
			'source_url'           => mb_substr( Sanitize::url( $input['source_url'] ?? $input['submission_source'] ?? $input['page_url'] ?? '' ), 0, 255 ),
			'submission_source'    => mb_substr( Sanitize::url( $input['submission_source'] ?? $input['source_url'] ?? '' ), 0, 191 ),
			'utm_source'           => Sanitize::text( $input['utm_source'] ?? '' ),
			'utm_medium'           => Sanitize::text( $input['utm_medium'] ?? '' ),
			'utm_campaign'         => Sanitize::text( $input['utm_campaign'] ?? '' ),
			'listing_id'           => $listing,
			'project_id'           => $project,
			'agent_id'             => Sanitize::int( $input['agent_id'] ?? $input['assigned_agent_id'] ?? 0 ),
			'assigned_agent_id'    => Sanitize::int( $input['assigned_agent_id'] ?? $input['agent_id'] ?? 0 ),
			'form_id'              => Sanitize::int( $input['form_id'] ?? 0 ),
			'consent'              => Sanitize::bool( $input['consent'] ?? false ),
			'consent_text_version' => Sanitize::text( $input['consent_text_version'] ?? 'v1' ),
			'ip_hash'              => Sanitize::text( $input['ip_hash'] ?? '' ),
			'user_agent'           => mb_substr( Sanitize::text( $input['user_agent'] ?? '' ), 0, 255 ),
			'dedupe_hash'          => $hash,
			'idempotency_key'      => $key,
			'status'               => Sanitize::choice( $input['status'] ?? 'new', array_keys( Vocabulary::lead_statuses_all() ), 'new' ),
			'lost_reason'          => Sanitize::choice( $input['lost_reason'] ?? '', array_keys( Vocabulary::lead_lost_reasons() ), '' ),
		);
	}

	public static function validate( array $data ): array {
		$errors = array();
		if ( '' === trim( (string) $data['name'] ) ) {
			$errors['name'] = __( 'Please tell us your name.', 'estat-os' );
		}
		$digits = preg_replace( '/\D/', '', (string) $data['phone'] );
		if ( '' === (string) $data['phone'] && '' === (string) $data['email'] ) {
			$errors['phone'] = __( 'Please add a phone number or an email address so we can reply.', 'estat-os' );
		} elseif ( '' !== (string) $data['phone'] && strlen( (string) $digits ) < 7 ) {
			$errors['phone'] = __( 'That phone number looks too short. Please check it.', 'estat-os' );
		}
		if ( mb_strlen( (string) $data['message'] ) > 5000 ) {
			$errors['message'] = __( 'Your message is very long. Please shorten it a little.', 'estat-os' );
		}
		// Lost without reason rejected.
		if ( 'lost' === $data['status'] && '' === $data['lost_reason'] ) {
			$errors['lost_reason'] = __( 'Please choose a reason for lost.', 'estat-os' );
		}
		return $errors;
	}

	/**
	 * Auto-assign agent by intent or listing's agent.
	 *
	 * @param array $data Prepared data.
	 * @return int Agent post ID.
	 */
	private static function auto_agent( array $data ): int {
		// If already assigned, keep.
		if ( (int) $data['assigned_agent_id'] > 0 ) {
			return (int) $data['assigned_agent_id'];
		}
		if ( (int) $data['agent_id'] > 0 ) {
			return (int) $data['agent_id'];
		}
		// By listing's agent.
		if ( (int) $data['listing_id'] > 0 ) {
			$agent = (int) get_post_meta( (int) $data['listing_id'], '_estat_agent_id', true );
			if ( $agent > 0 ) {
				return $agent;
			}
		}
		// By intent rule in Settings: e.g. buy/sell → agent A, rent → agent B.
		$rules = Settings::get( 'lead_assign_rules', array() );
		if ( is_array( $rules ) && '' !== $data['intent'] && isset( $rules[ $data['intent'] ] ) ) {
			$rule_agent = (int) $rules[ $data['intent'] ];
			if ( $rule_agent > 0 ) {
				return $rule_agent;
			}
		}
		// Fallback office: first agent or 0.
		$fallback = (int) Settings::get( 'lead_fallback_agent', 0 );
		return $fallback;
	}

	/**
	 * Create or merge — F1 dedupe 30 days by phone OR email.
	 *
	 * @param array<string,mixed> $input Raw.
	 * @return int|WP_Error
	 */
	public static function create( array $input ) {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return new \WP_Error( 'estat_no_storage', __( 'The office database is not ready yet. Please try again shortly.', 'estat-os' ) );
		}

		$data = self::prepare( $input );
		// Allow spam status to bypass validation of name? But keep basic.
		if ( 'spam' !== $data['status'] ) {
			$errors = self::validate( $data );
			if ( $errors ) {
				$error = new \WP_Error();
				foreach ( $errors as $field => $message ) {
					$error->add( 'estat_invalid_' . $field, $message, array( 'field' => $field ) );
				}
				return $error;
			}
		}

		$table = Schema::table( 'estat_leads' );

		// Layer 1: idempotency.
		if ( '' !== $data['idempotency_key'] ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE idempotency_key = %s", $data['idempotency_key'] ) );
			if ( $existing ) {
				return $existing;
			}
		}

		// Layer 2: dedupe same phone OR same email within 30 days → merge as event.
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - self::DEDUPE_WINDOW );
		$recent = 0;
		if ( '' !== $data['phone'] ) {
			// Search by normalized phone or identity digits.
			$identity = self::phone_identity( $data['phone_raw'] ?: $data['phone'] );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$recent = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE phone LIKE %s AND created_at >= %s AND erased = 0 ORDER BY id DESC LIMIT 1", '%' . $wpdb->esc_like( $identity ) . '%', $cutoff ) );
		}
		if ( 0 === $recent && '' !== $data['email'] ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$recent = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE email = %s AND created_at >= %s AND erased = 0 ORDER BY id DESC LIMIT 1", $data['email'], $cutoff ) );
		}

		if ( $recent ) {
			// Append as event, don't create second.
			LeadEvents::add( $recent, 'merged', array( 'message' => $data['message'], 'source' => $data['source_full'], 'source_url' => $data['source_url'] ) );
			if ( '' !== trim( $data['message'] ) ) {
				self::append_note( $recent, sprintf( __( 'Asked again: %s', 'estat-os' ), $data['message'] ) );
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $table, array( 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $recent ), array( '%s' ), array( '%d' ) );
			return $recent;
		}

		// Auto-assign.
		$auto_agent = self::auto_agent( $data );
		$assigned = $auto_agent > 0 ? $auto_agent : $data['assigned_agent_id'];

		$now = current_time( 'mysql', true );
		$row = array(
			'created_at'           => $now,
			'updated_at'           => $now,
			'name'                 => $data['name'],
			'phone'                => $data['phone'],
			'email'                => $data['email'],
			'message'              => $data['message'],
			'intent'               => $data['intent'],
			'locality'             => $data['locality'],
			'budget_min'           => $data['budget_min'],
			'budget_max'           => $data['budget_max'],
			'source'               => $data['source'],
			'source_url'           => $data['source_url'],
			'submission_source'    => $data['submission_source'],
			'utm_source'           => $data['utm_source'],
			'utm_medium'           => $data['utm_medium'],
			'utm_campaign'         => $data['utm_campaign'],
			'listing_id'           => $data['listing_id'],
			'project_id'           => $data['project_id'],
			'agent_id'             => $assigned,
			'assigned_agent_id'    => $assigned,
			'form_id'              => $data['form_id'],
			'status'               => $data['status'],
			'lost_reason'          => $data['lost_reason'],
			'consent'              => $data['consent'] ? 1 : 0,
			'consent_text_version' => $data['consent_text_version'],
			'ip_hash'              => $data['ip_hash'],
			'user_agent'           => $data['user_agent'],
			'practice'             => Settings::get( 'practice_mode' ) ? 1 : 0,
			'dedupe_hash'          => $data['dedupe_hash'],
			'idempotency_key'      => $data['idempotency_key'],
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$inserted = $wpdb->insert( $table, $row );
		if ( ! $inserted ) {
			if ( '' !== $data['idempotency_key'] ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE idempotency_key = %s", $data['idempotency_key'] ) );
				if ( $existing ) {
					return $existing;
				}
			}
			return new \WP_Error( 'estat_save_failed', __( 'We could not save this enquiry. Please try again.', 'estat-os' ) );
		}

		$lead_id = (int) $wpdb->insert_id;

		// Events.
		LeadEvents::add( $lead_id, 'created', array( 'source' => $data['source_full'], 'intent' => $data['intent'] ) );
		if ( $assigned > 0 ) {
			LeadEvents::add( $lead_id, 'assigned', array( 'agent_id' => $assigned ) );
		}

		AuditLog::record( 'lead.created', 'lead', $lead_id, array( 'listing_id' => $data['listing_id'], 'source' => $data['source'] ) );

		/**
		 * Fires after a new enquiry is stored.
		 *
		 * @param int   $lead_id Lead ID.
		 * @param array $row     Stored row.
		 */
		do_action( 'estat_lead_created', $lead_id, $row );

		// Notifications: new lead email to office + assigned agent.
		if ( class_exists( \EstatOS\Notifications\Notifier::class ) ) {
			\EstatOS\Notifications\Notifier::new_lead( $lead_id );
		}

		return $lead_id;
	}

	public static function get( int $lead_id ): ?array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return null;
		}
		$table = Schema::table( 'estat_leads' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $lead_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Query with filters — F1: search by name/phone, filter by agent, source, intent, date, status.
	 *
	 * @param array<string,mixed> $args Filters.
	 * @return array{items:array<int,array<string,mixed>>,total:int,pages:int,page:int}
	 */
	public static function query( array $args = array() ): array {
		global $wpdb;
		$out = array( 'items' => array(), 'total' => 0, 'pages' => 0, 'page' => 1 );
		if ( ! Schema::healthy() ) {
			return $out;
		}
		$table    = Schema::table( 'estat_leads' );
		$per_page = Sanitize::int( $args['per_page'] ?? 20, 1, 100 );
		$page     = Sanitize::int( $args['page'] ?? 1, 1, 10000 );
		$offset   = ( $page - 1 ) * $per_page;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = Sanitize::choice( $args['status'], array_keys( Vocabulary::lead_statuses_all() ), 'new' );
		}
		if ( ! empty( $args['agent_id'] ) || ! empty( $args['assigned_agent_id'] ) ) {
			$aid = Sanitize::int( $args['agent_id'] ?? $args['assigned_agent_id'] );
			$where[]  = '(agent_id = %d OR assigned_agent_id = %d)';
			$params[] = $aid;
			$params[] = $aid;
		}
		if ( ! empty( $args['listing_id'] ) ) {
			$where[]  = 'listing_id = %d';
			$params[] = Sanitize::int( $args['listing_id'] );
		}
		if ( ! empty( $args['intent'] ) ) {
			$where[]  = 'intent = %s';
			$params[] = Sanitize::choice( $args['intent'], array_keys( Vocabulary::lead_intents() ), '' );
		}
		if ( ! empty( $args['source'] ) ) {
			$where[]  = 'source = %s';
			$params[] = Sanitize::text( $args['source'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( Sanitize::text( $args['search'] ) ) . '%';
			$where[]  = '(name LIKE %s OR phone LIKE %s OR email LIKE %s)';
			$params   = array_merge( $params, array( $like, $like, $like ) );
		}
		if ( ! empty( $args['due_followup'] ) ) {
			// A follow-up whose day has passed. Until this was written, the
			// callers that asked for it were quietly handed the newest
			// enquiries instead — the office to-do list said "the follow-up
			// date has passed" about people nobody had promised to ring.
			$where[]  = '(followup_at IS NOT NULL AND followup_at <> \'0000-00-00 00:00:00\' AND followup_at <= %s)';
			$params[] = current_time( 'mysql', true );
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = Sanitize::datetime( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = Sanitize::datetime( $args['date_to'] );
		}
		if ( isset( $args['consent'] ) ) {
			$where[]  = 'consent = %d';
			$params[] = $args['consent'] ? 1 : 0;
		}

		// Agent role: only own leads.
		$current_user = get_current_user_id();
		if ( $current_user && ! current_user_can( 'estat_manage_leads' ) && current_user_can( 'estat_agent' ) ) {
			// Find agent post linked to user.
			$agent_post = \EstatOS\Data\Agents::for_user( $current_user );
			if ( $agent_post ) {
				$where[]  = '(assigned_agent_id = %d OR agent_id = %d)';
				$params[] = $agent_post;
				$params[] = $agent_post;
			} else {
				// No agent link, no leads.
				$where[] = '1=0';
			}
		}

		$where_sql = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );
		$items     = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per_page, $offset ) ) ),
			ARRAY_A
		);
		// phpcs:enable

		return array(
			'items' => is_array( $items ) ? $items : array(),
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
			'page'  => $page,
		);
	}

	public static function update( int $lead_id, array $input ) {
		global $wpdb;
		$lead = self::get( $lead_id );
		if ( ! $lead ) {
			return new \WP_Error( 'estat_not_found', __( 'That enquiry could not be found.', 'estat-os' ) );
		}

		// Permission check: agent can only update own leads.
		if ( ! current_user_can( 'estat_manage_leads' ) ) {
			$current_user = get_current_user_id();
			$agent_post = \EstatOS\Data\Agents::for_user( $current_user );
			if ( ! $agent_post || ( (int) $lead['assigned_agent_id'] !== $agent_post && (int) $lead['agent_id'] !== $agent_post ) ) {
				return new \WP_Error( 'estat_forbidden', __( 'You cannot update this lead.', 'estat-os' ), array( 'status' => 403 ) );
			}
			// Agent cannot export or delete.
			if ( isset( $input['delete'] ) ) {
				return new \WP_Error( 'estat_forbidden', __( 'You are not allowed to delete leads.', 'estat-os' ), array( 'status' => 403 ) );
			}
		}

		$fields = array( 'updated_at' => current_time( 'mysql', true ) );

		if ( isset( $input['status'] ) ) {
			$new_status = Sanitize::choice( $input['status'], array_keys( Vocabulary::lead_statuses_all() ), (string) $lead['status'] );

			/*
			 * The enquiry journey is New → Contacted → Scheduled → Won/Lost, and
			 * the step has to be taken in that order. Until now the only thing
			 * stopping a jump was the list of choices on each screen — anybody
			 * posting the form by hand could mark a brand-new enquiry "Won"
			 * without ever speaking to the client. The office (the person the
			 * whole office answers to) may still put a record back on track by
			 * hand; a field agent may only take a legal step.
			 */
			if ( ! \EstatOS\Support\Status::actor_is_office()
				&& $new_status !== (string) $lead['status']
				&& ! \EstatOS\Support\Status::can( \EstatOS\Support\Status::LEAD, (string) $lead['status'], $new_status ) ) {
				return new \WP_Error(
					'estat_bad_transition',
					sprintf(
						/* translators: 1: current state, 2: wanted state */
						__( 'An enquiry reading “%1$s” cannot be moved straight to “%2$s”. Move it one step at a time.', 'estat-os' ),
						Vocabulary::lead_label( (string) $lead['status'] ),
						Vocabulary::lead_label( $new_status )
					),
					array( 'status' => 422 )
				);
			}

			// Lost requires reason.
			if ( 'lost' === $new_status ) {
				$reason = Sanitize::choice( $input['lost_reason'] ?? $lead['lost_reason'] ?? '', array_keys( Vocabulary::lead_lost_reasons() ), '' );
				if ( '' === $reason ) {
					return new \WP_Error( 'estat_lost_reason_required', __( 'Please choose a reason for lost.', 'estat-os' ), array( 'status' => 422 ) );
				}
				$fields['lost_reason'] = $reason;
			}
			if ( $new_status !== $lead['status'] ) {
				$fields['status'] = $new_status;
				LeadEvents::add( $lead_id, 'status', array( 'from' => $lead['status'], 'to' => $new_status, 'reason' => $fields['lost_reason'] ?? '' ) );
			}
		}
		if ( isset( $input['agent_id'] ) || isset( $input['assigned_agent_id'] ) ) {
			$aid = Sanitize::int( $input['assigned_agent_id'] ?? $input['agent_id'] ?? 0 );
			if ( $aid !== (int) $lead['assigned_agent_id'] ) {
				$fields['assigned_agent_id'] = $aid;
				$fields['agent_id'] = $aid;
				LeadEvents::add( $lead_id, 'assigned', array( 'agent_id' => $aid ) );
			}
		}
		if ( isset( $input['followup_at'] ) ) {
			$date                  = Sanitize::datetime( $input['followup_at'] );
			$fields['followup_at'] = '' !== $date ? $date : null;
		}
		if ( isset( $input['listing_id'] ) ) {
			$fields['listing_id'] = Sanitize::int( $input['listing_id'] );
		}
		if ( isset( $input['notes'] ) ) {
			$fields['notes'] = Sanitize::textarea( $input['notes'] );
		}
		if ( isset( $input['intent'] ) ) {
			$fields['intent'] = Sanitize::choice( $input['intent'], array_keys( Vocabulary::lead_intents() ), '' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update( Schema::table( 'estat_leads' ), $fields, array( 'id' => $lead_id ) );
		AuditLog::record( 'lead.updated', 'lead', $lead_id, array( 'status' => $fields['status'] ?? $lead['status'] ) );

		do_action( 'estat_lead_updated', $lead_id, $fields );
		if ( isset( $fields['status'] ) ) {
			do_action( 'estat_lead_status_changed', $lead_id, $lead['status'], $fields['status'], $fields );
		}
		if ( isset( $fields['assigned_agent_id'] ) ) {
			do_action( 'estat_lead_assigned', $lead_id, (int) $fields['assigned_agent_id'], $lead );
		}
		return true;
	}

	public static function assign( int $lead_id, int $agent_id, bool $log = true ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			Schema::table( 'estat_leads' ),
			array( 'agent_id' => $agent_id, 'assigned_agent_id' => $agent_id, 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => $lead_id ),
			array( '%d', '%d', '%s' ),
			array( '%d' )
		);
		LeadEvents::add( $lead_id, 'assigned', array( 'agent_id' => $agent_id ) );
		if ( $log ) {
			AuditLog::record( 'lead.assigned', 'lead', $lead_id, array( 'agent_id' => $agent_id ) );
		}
		do_action( 'estat_lead_assigned', $lead_id, $agent_id, self::get( $lead_id ) );
		return true;
	}

	public static function append_note( int $lead_id, string $note ): void {
		global $wpdb;
		$lead = self::get( $lead_id );
		if ( ! $lead ) {
			return;
		}
		$line  = '[' . current_time( 'mysql' ) . '] ' . Sanitize::textarea( $note );
		$notes = trim( (string) $lead['notes'] . "\n" . $line );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update( Schema::table( 'estat_leads' ), array( 'notes' => $notes, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $lead_id ), array( '%s', '%s' ), array( '%d' ) );
		LeadEvents::add( $lead_id, 'note', array( 'note' => $note ) );
	}

	public static function erase( int $lead_id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			Schema::table( 'estat_leads' ),
			array(
				'name'        => __( 'Erased', 'estat-os' ),
				'phone'       => '',
				'email'       => '',
				'message'     => '',
				'notes'       => '',
				'erased'      => 1,
				'dedupe_hash' => '',
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $lead_id ),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ),
			array( '%d' )
		);
		AuditLog::record( 'lead.erased', 'lead', $lead_id, array() );
		return true;
	}

	public static function counts(): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array( 'new' => 0, 'contacted' => 0, 'scheduled' => 0, 'won' => 0, 'lost' => 0, 'spam' => 0, 'due' => 0, 'total' => 0 );
		}
		$table = Schema::table( 'estat_leads' );
		$now   = current_time( 'mysql', true );
		$day_ago = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$counts = array(
			'new'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'new'" ),
			'contacted' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'contacted'" ),
			'scheduled' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'scheduled'" ),
			'won'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'won'" ),
			'lost'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'lost'" ),
			'spam'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'spam'" ),
			'due'       => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = 'new' AND created_at <= %s", $day_ago ) ),
			'total'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
		);
		// phpcs:enable
		return $counts;
	}

	public static function apply_retention( int $days ): int {
		if ( $days <= 0 ) {
			return 0;
		}
		global $wpdb;
		$table  = Schema::table( 'estat_leads' );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$table} WHERE created_at < %s AND erased = 0 LIMIT 500", $cutoff ) );
		foreach ( $ids as $id ) {
			self::erase( (int) $id );
		}
		return count( $ids );
	}

	/**
	 * Export CSV of filtered leads — respects consent flag.
	 *
	 * @param array<string,mixed> $filters Filters.
	 * @param bool                $consent_only Only consent=1.
	 * @return string CSV content.
	 */
	public static function export_csv( array $filters = array(), bool $consent_only = false ): string {
		$query = self::query( array_merge( $filters, array( 'per_page' => 1000, 'page' => 1 ) ) );
		$items = $query['items'];
		if ( $consent_only ) {
			$items = array_filter( $items, fn( $r ) => ! empty( $r['consent'] ) );
		}

		$fh = fopen( 'php://temp', 'r+' );
		// BOM for Excel.
		fputs( $fh, "\xEF\xBB\xBF" );
		$headers = array( 'id', 'created_at', 'status', 'name', 'phone', 'email', 'intent', 'locality', 'budget_min', 'budget_max', 'listing_id', 'project_id', 'source', 'source_url', 'assigned_agent_id', 'consent', 'message' );
		fputcsv( $fh, $headers );
		foreach ( $items as $row ) {
			$line = array();
			foreach ( $headers as $h ) {
				$line[] = $row[ $h ] ?? '';
			}
			// Prevent CSV injection.
			foreach ( $line as &$cell ) {
				if ( is_string( $cell ) && preg_match( '/^[=+\-@\t\r]/', $cell ) ) {
					$cell = "'" . $cell;
				}
			}
			fputcsv( $fh, $line );
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return $csv;
	}
}
