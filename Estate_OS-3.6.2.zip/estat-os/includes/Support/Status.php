<?php
/**
 * The state of a record, said once.
 *
 * A property does not have "a status". It has four separate facts: is it on
 * the website (publication), can it still be offered (availability), has
 * anybody checked it (verification), and is it built yet (construction). A
 * client enquiry has its own journey, a site visit has its own, and an office
 * request has its own again. Collapsing any two of these into one word called
 * "status" is how two screens end up describing the same record differently.
 *
 * This class is the one place that decides:
 *   - which family a stored value belongs to,
 *   - the word the office reads for it,
 *   - how loud it should look (tone),
 *   - and which moves are legal (transitions).
 *
 * The stored values are never renamed here — `publish`, `pending`, `private`,
 * `rented` and the rest stay exactly what they were in the database, so old
 * records, exports, the website and the REST contract keep working.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

final class Status {

	/**
	 * The families of state that must never be substituted for one another.
	 */
	public const PUBLICATION  = 'publication';
	public const AVAILABILITY = 'availability';
	public const VERIFICATION = 'verification';
	public const CONSTRUCTION = 'construction';
	public const LEAD         = 'lead';
	public const VISIT        = 'visit';
	public const REQUEST      = 'request';

	/**
	 * The word to show for one stored value in one family.
	 *
	 * @param string $family Family key (see the constants).
	 * @param string $value  Stored value.
	 * @return string
	 */
	public static function label( string $family, string $value ): string {
		$map = self::labels( $family );
		if ( isset( $map[ $value ] ) ) {
			return (string) $map[ $value ];
		}

		// An enquiry may still carry one of the older words (Qualified,
		// Converted, Visit scheduled). Those are understood, and read as the
		// canonical word they always meant.
		if ( self::LEAD === $family ) {
			return Vocabulary::lead_label( $value );
		}

		return '' === $value ? '' : ucfirst( str_replace( '_', ' ', $value ) );
	}

	/**
	 * Every stored value and its word, for one family.
	 *
	 * @param string $family Family key.
	 * @return array<string,string>
	 */
	public static function labels( string $family ): array {
		switch ( $family ) {
			case self::PUBLICATION:
				return Vocabulary::publication();
			case self::AVAILABILITY:
				return Vocabulary::availability();
			case self::VERIFICATION:
				return Vocabulary::verification();
			case self::CONSTRUCTION:
				return Vocabulary::construction();
			case self::LEAD:
				return Vocabulary::lead_statuses();
			case self::VISIT:
				return Vocabulary::visit_outcomes();
			case self::REQUEST:
				return Vocabulary::request_states();
		}

		return array();
	}

	/**
	 * How loud the word should look. Tone is about attention, never about
	 * meaning — the same state reads the same word whether it is printed in
	 * colour or in plain text.
	 *
	 * @param string $family Family key.
	 * @param string $value  Stored value.
	 * @return string 'good', 'warn', 'danger', 'quiet' or ''.
	 */
	public static function tone( string $family, string $value ): string {
		switch ( $family ) {
			case self::PUBLICATION:
				switch ( $value ) {
					case 'publish':
						return 'good';
					case 'pending':
						return 'warn';
					case 'trash':
						return 'danger';
					default:
						return 'quiet';
				}

			case self::AVAILABILITY:
				return 'available' === $value ? 'good' : 'quiet';

			case self::VERIFICATION:
				return 'office_verified' === $value ? 'good' : ( 'self_verified' === $value ? 'quiet' : 'warn' );

			case self::LEAD:
				switch ( $value ) {
					case 'won':
						return 'good';
					case 'lost':
					case 'spam':
						return 'quiet';
					case 'new':
						return 'warn';
					default:
						return 'quiet';
				}

			case self::VISIT:
				switch ( $value ) {
					case 'done':
						return 'good';
					case 'no_show':
						return 'danger';
					case 'cancelled':
						return 'quiet';
					default:
						return 'warn';
				}

			case self::REQUEST:
				return 'approved' === $value ? 'good' : ( 'declined' === $value ? 'danger' : 'warn' );
		}

		return '';
	}

	/**
	 * The legal moves out of one state.
	 *
	 * These are the moves the product offers. The office — the person the
	 * whole office answers to — may always override by hand in the office
	 * screens; a field agent may only take the steps written here, and that
	 * is enforced on the server, not just hidden in the interface.
	 *
	 * @param string $family Family key.
	 * @param string $from   Current stored value.
	 * @return string[]
	 */
	public static function transitions( string $family, string $from ): array {
		switch ( $family ) {
			case self::PUBLICATION:
				switch ( $from ) {
					case 'draft':
						// Sent up for approval, or parked straight away.
						return array( 'pending', 'trash' );
					case 'pending':
						// The agent may pull it back while it waits; the office
						// says yes (publish) or sends it back for changes
						// (draft) — see Requests, which records that decision.
						return array( 'publish', 'draft', 'trash' );
					case 'publish':
						return array( 'private', 'trash' );
					case 'private':
						return array( 'publish', 'trash' );
					case 'trash':
						return array( 'draft', 'publish' );
				}
				return array();

			case self::LEAD:
				switch ( $from ) {
					// Spoken to the client first, then the visit, then the answer.
					// A client can go cold at any point — that is the one step back
					// that is always honest.
					case 'new':
						return array( 'contacted', 'lost' );
					case 'contacted':
						return array( 'scheduled', 'lost' );
					case 'scheduled':
						return array( 'won', 'lost' );
					case 'won':
					case 'lost':
						// A closed enquiry may be reopened; life is not tidy.
						return array( 'contacted', 'won', 'lost' );
					case 'qualified':
						return self::transitions( self::LEAD, 'contacted' );
					case 'visit_scheduled':
						return self::transitions( self::LEAD, 'scheduled' );
					case 'converted':
						return self::transitions( self::LEAD, 'won' );
				}
				return array();

			case self::VISIT:
				switch ( $from ) {
					case 'pending':
						return array( 'done', 'no_show', 'cancelled' );
					case 'done':
					case 'no_show':
					case 'cancelled':
						// Moved by mistake? The office can put it right; a
						// field agent asks them to.
						return array();
				}
				return array();

			case self::REQUEST:
				return 'pending' === $from ? array( 'approved', 'declined' ) : array();
		}

		return array();
	}

	/**
	 * May this move be made?
	 *
	 * @param string $family Family key.
	 * @param string $from   Current stored value.
	 * @param string $to     Wanted stored value.
	 * @return bool
	 */
	public static function can( string $family, string $from, string $to ): bool {
		if ( $from === $to ) {
			return true; // Saving a record without touching this answer.
		}
		return in_array( $to, self::transitions( $family, $from ), true );
	}

	/**
	 * The natural next step out of a state, for a button that offers one.
	 * Empty when there is nothing to do but look.
	 *
	 * @param string $family Family key.
	 * @param string $from   Current stored value.
	 * @return string
	 */
	public static function next( string $family, string $from ): string {
		$moves = self::transitions( $family, $from );
		return $moves ? (string) $moves[0] : '';
	}

	/**
	 * Is the person doing this the office itself?
	 *
	 * The office — the person the whole office answers to — may put any record
	 * into any state by hand: it is their business, and a workshop needs a
	 * workbench. A field agent may only take the steps the product offers.
	 *
	 * The office is recognised by the capabilities only it holds (publishing
	 * to the website, changing settings, reviewing submissions), not by
	 * "can they edit leads" — an agent can edit their own leads, and that is
	 * exactly who these rules are for.
	 *
	 * @return bool
	 */
	public static function actor_is_office(): bool {
		return current_user_can( 'estat_manage_settings' )
			|| current_user_can( 'estat_publish_listings' )
			|| current_user_can( 'estat_review_listings' );
	}

	/**
	 * The publication word with its one-line explanation, where there is room.
	 *
	 * @param string $value Stored post status.
	 * @return string
	 */
	public static function publication_note( string $value ): string {
		$notes = Vocabulary::publication_note();
		return (string) ( $notes[ $value ] ?? '' );
	}
}
