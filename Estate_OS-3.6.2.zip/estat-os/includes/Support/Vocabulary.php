<?php
/**
 * Canonical business vocabularies (status models, types, units).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Single source of truth for every controlled list in the system.
 *
 * Keys are stable data-contract values and must not be renamed.
 * Labels are translated at call time, never stored.
 */
final class Vocabulary {

	/**
	 * Property types.
	 *
	 * @return array<string,string>
	 */
	public static function property_types(): array {
		return array(
			'apartment'       => __( 'Apartment', 'estat-os' ),
			'builder_floor'   => __( 'Builder Floor', 'estat-os' ),
			'villa'           => __( 'Villa', 'estat-os' ),
			'plot'            => __( 'Plot', 'estat-os' ),
			'commercial_shop' => __( 'Shop', 'estat-os' ),
			'office'          => __( 'Office', 'estat-os' ),
			'warehouse'       => __( 'Warehouse', 'estat-os' ),
			'farm_house'      => __( 'Farm House', 'estat-os' ),
			'other'           => __( 'Other', 'estat-os' ),
		);
	}

	/**
	 * Types that older records still carry.
	 *
	 * The list above is what an office picks from, and it is deliberately
	 * short: nobody should have to choose between "Apartment" and "Flat".
	 * Records saved before that decision keep their old value, so the label
	 * has to survive — normalise_property_type() maps them on to the short
	 * list, and the upgrade step rewrites what is already stored.
	 *
	 * @return array<string,string>
	 */
	public static function property_types_legacy(): array {
		return array(
			'flat'              => __( 'Flat', 'estat-os' ),
			'independent_house' => __( 'Independent House', 'estat-os' ),
			'studio'            => __( 'Studio', 'estat-os' ),
			'penthouse'         => __( 'Penthouse', 'estat-os' ),
			'industrial'        => __( 'Industrial Property', 'estat-os' ),
			'farm_land'         => __( 'Farm Land', 'estat-os' ),
		);
	}

	/**
	 * Every type a stored record may hold — the short list plus the old names.
	 *
	 * @return array<string,string>
	 */
	public static function property_types_all(): array {
		return self::property_types() + self::property_types_legacy();
	}

	/**
	 * The choices to show, always including the answer the record already has.
	 *
	 * A select can only show what is in it. A record saved before the list was
	 * shortened — or imported from somewhere else with a word this list has
	 * never heard of — would otherwise open on some other answer, and the next
	 * save would quietly agree with it. The record's own answer is added to the
	 * list instead, so nothing is ever lost by opening a form.
	 *
	 * @param string $name    Vocabulary method name, e.g. 'property_types'.
	 * @param string $current What the record says, if anything.
	 * @return array<string,string>
	 */
	public static function for_select( string $name, string $current = '' ): array {
		if ( ! method_exists( __CLASS__, $name ) ) {
			return array();
		}
		/** @var array<string,string> $list */
		$list = call_user_func( array( __CLASS__, $name ) );
		$current = trim( $current );
		if ( '' === $current || isset( $list[ $current ] ) ) {
			return $list;
		}

		/* translators: %s: an older or imported name for this choice. */
		$label = sprintf( __( '%s (as written before)', 'estat-os' ), self::label( $name, $current ) );
		return array( $current => $label ) + $list;
	}

	/**
	 * Fold an old type on to the short list.
	 *
	 * @param string $key Stored value.
	 * @return string
	 */
	public static function normalise_property_type( string $key ): string {
		$map = array(
			'flat'              => 'apartment',
			'studio'            => 'apartment',
			'penthouse'         => 'apartment',
			'independent_house' => 'villa',
			'industrial'        => 'warehouse',
			'farm_land'         => 'farm_house',
		);

		return $map[ $key ] ?? $key;
	}

	/**
	 * Offer types (what the office is doing with the property).
	 *
	 * @return array<string,string>
	 */
	public static function offers(): array {
		return array(
			'sale'  => __( 'For Sale', 'estat-os' ),
			'rent'  => __( 'For Rent', 'estat-os' ),
			'lease' => __( 'For Lease', 'estat-os' ),
		);
	}

	/**
	 * Availability states.
	 *
	 * @return array<string,string>
	 */
	public static function availability(): array {
		return array(
			'available' => __( 'Available', 'estat-os' ),
			'on_hold'   => __( 'Under offer', 'estat-os' ),
			'rented'    => __( 'Rented', 'estat-os' ),
			'sold'      => __( 'Sold', 'estat-os' ),
		);
	}

	/**
	 * Freshness — what tag the website shows on the card.
	 *
	 * @return array<string,string>
	 */
	public static function freshness(): array {
		return array(
			'just_listed'   => __( 'Just listed', 'estat-os' ),
			'ready_to_move' => __( 'Ready to move', 'estat-os' ),
		);
	}

	/**
	 * Construction states.
	 *
	 * @return array<string,string>
	 */
	public static function construction(): array {
		return array(
			'ready'        => __( 'Ready to move', 'estat-os' ),
			'construction' => __( 'Under construction', 'estat-os' ),
			'new_launch'   => __( 'New launch', 'estat-os' ),
		);
	}

	/**
	 * Verification states.
	 *
	 * @return array<string,string>
	 */
	public static function verification(): array {
		return array(
			'unverified'      => __( 'Not checked yet', 'estat-os' ),
			'self_verified'   => __( 'Checked by agent', 'estat-os' ),
			'office_verified' => __( 'Verified by office', 'estat-os' ),
		);
	}

	/**
	 * Where a property stands on the website.
	 *
	 * This is one fact about a property, not "the status". A property is
	 * separately available or not, checked or not, and ready or under
	 * construction — four facts, four words, never squeezed into one badge.
	 *
	 * The stored keys are WordPress's own (publish, pending, private…) and are
	 * left exactly as they are; only the words the office reads are decided
	 * here, once, so the phone, the office, the emails and the website can
	 * never drift apart.
	 *
	 * @return array<string,string>
	 */
	public static function publication(): array {
		return array(
			'draft'   => __( 'Draft', 'estat-os' ),
			'pending' => __( 'Waiting for approval', 'estat-os' ),
			'publish' => __( 'Live', 'estat-os' ),
			'private' => __( 'Paused', 'estat-os' ),
			'future'  => __( 'Scheduled', 'estat-os' ),
			'trash'   => __( 'In bin', 'estat-os' ),
		);
	}

	/**
	 * One line of plain English under a publication word, where there is room.
	 *
	 * @return array<string,string>
	 */
	public static function publication_note(): array {
		return array(
			'draft'   => __( 'Still being written. Not on the website.', 'estat-os' ),
			'pending' => __( 'Sent to the office. Nothing is on the website until they say yes.', 'estat-os' ),
			'publish' => __( 'On the website for anyone to see.', 'estat-os' ),
			'private' => __( 'Paused — kept in the office, hidden from the website.', 'estat-os' ),
			'future'  => __( 'Goes on the website by itself at the time set.', 'estat-os' ),
			'trash'   => __( 'In the bin. It can be restored.', 'estat-os' ),
		);
	}

	/**
	 * Where an office request stands. Separate from publication: a request can
	 * be approved while the property is still waiting for something else.
	 *
	 * @return array<string,string>
	 */
	public static function request_states(): array {
		return array(
			'pending'  => __( 'Waiting for office', 'estat-os' ),
			'approved' => __( 'Approved', 'estat-os' ),
			'declined' => __( 'Declined', 'estat-os' ),
		);
	}

	/**
	 * Price types.
	 *
	 * @return array<string,string>
	 */
	public static function price_types(): array {
		return array(
			'fixed'         => __( 'Fixed price', 'estat-os' ),
			'negotiable'    => __( 'Negotiable', 'estat-os' ),
			'starting_from' => __( 'Starting from', 'estat-os' ),
			'on_request'    => __( 'Price on request', 'estat-os' ),
		);
	}

	/**
	 * Area measurement types.
	 *
	 * @return array<string,string>
	 */
	public static function area_types(): array {
		return array(
			'carpet'  => __( 'Carpet area', 'estat-os' ),
			'builtup' => __( 'Built-up area', 'estat-os' ),
			'super'   => __( 'Super built-up area', 'estat-os' ),
			'plot'    => __( 'Plot area', 'estat-os' ),
		);
	}

	/**
	 * Area units.
	 *
	 * @return array<string,string>
	 */
	public static function area_units(): array {
		return array(
			'sqft' => __( 'Square feet', 'estat-os' ),
			'sqyd' => __( 'Square yards', 'estat-os' ),
			'sqm'  => __( 'Square metres', 'estat-os' ),
		);
	}

	/**
	 * Furnishing options.
	 *
	 * @return array<string,string>
	 */
	public static function furnishing(): array {
		return array(
			''             => __( 'Not specified', 'estat-os' ),
			'unfurnished'  => __( 'Unfurnished', 'estat-os' ),
			'semi'         => __( 'Semi furnished', 'estat-os' ),
			'furnished'    => __( 'Fully furnished', 'estat-os' ),
		);
	}

	/**
	 * Facing directions.
	 *
	 * @return array<string,string>
	 */
	public static function facing(): array {
		return array(
			''           => __( 'Not specified', 'estat-os' ),
			'north'      => __( 'North', 'estat-os' ),
			'south'      => __( 'South', 'estat-os' ),
			'east'       => __( 'East', 'estat-os' ),
			'west'       => __( 'West', 'estat-os' ),
			'north_east' => __( 'North East', 'estat-os' ),
			'north_west' => __( 'North West', 'estat-os' ),
			'south_east' => __( 'South East', 'estat-os' ),
			'south_west' => __( 'South West', 'estat-os' ),
		);
	}

	/**
	 * Lead statuses — the office pipeline: New → Contacted → Scheduled → Won / Lost / Spam.
	 * Legacy keys kept for backward compatibility.
	 *
	 * @return array<string,string>
	 */
	public static function lead_sources(): array {
		return array(
			'website'  => __( 'Website', 'estat-os' ),
			'form'     => __( 'Website form', 'estat-os' ),
			'elementor'=> __( 'Website form', 'estat-os' ),
			'whatsapp' => __( 'WhatsApp', 'estat-os' ),
			'call'     => __( 'Phone call', 'estat-os' ),
			'manual'   => __( 'Added by hand', 'estat-os' ),
			'import'   => __( 'Spreadsheet import', 'estat-os' ),
			'api'      => __( 'Connected app', 'estat-os' ),
			'other'    => __( 'Other', 'estat-os' ),
		);
	}

	public static function lead_statuses(): array {
		return array(
			'new'       => __( 'New', 'estat-os' ),
			'contacted' => __( 'Contacted', 'estat-os' ),
			'scheduled' => __( 'Scheduled', 'estat-os' ),
			'won'       => __( 'Won', 'estat-os' ),
			'lost'      => __( 'Lost', 'estat-os' ),
		);
	}

	/**
	 * Every value an enquiry may carry, including the ones the office is no
	 * longer offered.
	 *
	 * The old list had nine choices and three of them were near-duplicates of
	 * others (Qualified next to Contacted, Visit scheduled next to Scheduled,
	 * Converted next to Won), which left everyone guessing. The screens now
	 * offer five; these extra values are still understood, so records saved
	 * earlier keep working.
	 *
	 * @return array<string,string>
	 */
	public static function lead_statuses_all(): array {
		return self::lead_statuses() + array(
			'qualified'       => __( 'Contacted', 'estat-os' ),
			'visit_scheduled' => __( 'Scheduled', 'estat-os' ),
			'converted'       => __( 'Won', 'estat-os' ),
			'spam'            => __( 'Deleted', 'estat-os' ),
		);
	}

	/**
	 * The word to show for any stored value.
	 *
	 * @param string $status Stored value.
	 * @return string
	 */
	public static function lead_label( string $status ): string {
		$all = self::lead_statuses_all();
		return $all[ $status ] ?? $status;
	}

	/**
	 * Is this enquiry set aside (spam)?
	 *
	 * @param string $status Stored value.
	 * @return bool
	 */
	public static function lead_is_deleted( string $status ): bool {
		return 'spam' === $status;
	}

	/**
	 * Canonical pipeline order for Kanban.
	 *
	 * @return string[]
	 */
	public static function lead_pipeline_order(): array {
		return array( 'new', 'contacted', 'scheduled', 'won', 'lost' );
	}

	/**
	 * Lost reasons required when status=lost.
	 *
	 * @return array<string,string>
	 */
	public static function lead_lost_reasons(): array {
		return array(
			'budget'          => __( 'Budget', 'estat-os' ),
			'location'        => __( 'Location', 'estat-os' ),
			'bought_elsewhere'=> __( 'Bought elsewhere', 'estat-os' ),
			'no_response'     => __( 'No response', 'estat-os' ),
			'other'           => __( 'Other', 'estat-os' ),
		);
	}

	/**
	 * Lead intents.
	 *
	 * @return array<string,string>
	 */
	public static function lead_intents(): array {
		return array(
			'buy'     => __( 'Buy', 'estat-os' ),
			'rent'    => __( 'Rent', 'estat-os' ),
			'sell'    => __( 'Sell', 'estat-os' ),
			'invest'  => __( 'Invest', 'estat-os' ),
			'consult' => __( 'Consult', 'estat-os' ),
		);
	}

	/**
	 * Map legacy statuses to new pipeline.
	 *
	 * @param string $status Old status.
	 * @return string
	 */
	public static function normalize_lead_status( string $status ): string {
		$map = array(
			'qualified'       => 'contacted',
			'visit_scheduled' => 'scheduled',
			'converted'       => 'won',
		);
		return $map[ $status ] ?? $status;
	}

	/**
	 * Visit outcomes.
	 *
	 * @return array<string,string>
	 */
	public static function visit_outcomes(): array {
		return array(
			'pending'   => __( 'Scheduled', 'estat-os' ),
			'done'      => __( 'Completed', 'estat-os' ),
			'no_show'   => __( 'No-show', 'estat-os' ),
			'cancelled' => __( 'Cancelled', 'estat-os' ),
		);
	}

	/**
	 * What kind of project it is. A builder's master sheet says this in one
	 * word — Residential, Commercial, Affordable — and the website repeats it,
	 * so the words are kept exactly as the trade uses them.
	 *
	 * @return array<string,string>
	 */
	public static function project_categories(): array {
		return array(
			'residential' => __( 'Residential', 'estat-os' ),
			'commercial'  => __( 'Commercial', 'estat-os' ),
			'affordable'  => __( 'Affordable housing', 'estat-os' ),
			'mixed'       => __( 'Mixed use', 'estat-os' ),
			'other'       => __( 'Other', 'estat-os' ),
		);
	}

	/**
	 * Project statuses — the office stages.
	 *
	 * @return array<string,string>
	 */
	public static function project_statuses(): array {
		return array(
			'planning'     => __( 'Planning', 'estat-os' ),
			'new_launch'   => __( 'New Launch', 'estat-os' ),
			'construction' => __( 'Under Construction', 'estat-os' ),
			'ready'        => __( 'Ready to Move', 'estat-os' ),
			'completed'    => __( 'Completed', 'estat-os' ),
		);
	}

	/**
	 * Ordered stages for timeline — Planning → UC → Ready.
	 *
	 * @return string[]
	 */
	public static function project_stage_order(): array {
		return array( 'planning', 'new_launch', 'construction', 'ready', 'completed' );
	}

	/**
	 * Progress percentage for each stage (for timeline bar).
	 *
	 * @return array<string,int>
	 */
	public static function project_stage_progress(): array {
		return array(
			'planning'     => 10,
			'new_launch'   => 25,
			'construction' => 60,
			'ready'        => 90,
			'completed'    => 100,
		);
	}

	/**
	 * Label for stage with emoji for frontend.
	 *
	 * @param string $stage Stage key.
	 * @return string
	 */
	public static function project_stage_label( string $stage ): string {
		$map = array(
			'planning'     => __( '📝 Planning', 'estat-os' ),
			'new_launch'   => __( '🚀 New Launch', 'estat-os' ),
			'construction' => __('Under Construction', 'estat-os'),
			'ready'        => __('Ready to Move', 'estat-os'),
			'completed'    => __( '✅ Completed', 'estat-os' ),
		);
		return $map[ $stage ] ?? $stage;
	}

	/**
	 * Possession timeline.
	 *
	 * @return array<string,string>
	 */
	public static function possession_timeline(): array {
		return array(
			''           => __( 'Any time', 'estat-os' ),
			'immediate'  => __( 'Immediate', 'estat-os' ),
			'3_months'   => __( 'Within 3 months', 'estat-os' ),
			'6_months'   => __( 'Within 6 months', 'estat-os' ),
			'1_year'     => __( 'Within 1 year', 'estat-os' ),
			'2_years'    => __( 'Within 2 years', 'estat-os' ),
		);
	}

	/**
	 * All 23 searchable filters for the office — toggleable in settings.
	 *
	 * @return array<string,array{label:string,group:string}>
	 */
	public static function all_filters(): array {
		return array(
			'locality'       => array( 'label' => __( 'Locality', 'estat-os' ), 'group' => 'location' ),
			'property_type'  => array( 'label' => __( 'Property Type', 'estat-os' ), 'group' => 'basic' ),
			'offer'          => array( 'label' => __( 'For Sale / Rent', 'estat-os' ), 'group' => 'basic' ),
			'bedrooms'       => array( 'label' => __( 'Bedrooms', 'estat-os' ), 'group' => 'basic' ),
			'bathrooms'      => array( 'label' => __( 'Bathrooms', 'estat-os' ), 'group' => 'basic' ),
			'price'          => array( 'label' => __( 'Price / Budget', 'estat-os' ), 'group' => 'basic' ),
			'area'           => array( 'label' => __( 'Area (sqft)', 'estat-os' ), 'group' => 'basic' ),
			'furnishing'     => array( 'label' => __( 'Furnishing', 'estat-os' ), 'group' => 'details' ),
			'facing'         => array( 'label' => __( 'Facing', 'estat-os' ), 'group' => 'details' ),
			'floor'          => array( 'label' => __( 'Floor', 'estat-os' ), 'group' => 'details' ),
			'total_floors'   => array( 'label' => __( 'Total Floors', 'estat-os' ), 'group' => 'details' ),
			'construction'   => array( 'label' => __( 'Construction Stage', 'estat-os' ), 'group' => 'details' ),
			'availability'   => array( 'label' => __( 'Availability', 'estat-os' ), 'group' => 'details' ),
			'possession'     => array( 'label' => __( 'Possession Date', 'estat-os' ), 'group' => 'details' ),
			'age'            => array( 'label' => __( 'Property Age', 'estat-os' ), 'group' => 'details' ),
			'parking'        => array( 'label' => __( 'Parking', 'estat-os' ), 'group' => 'amenities' ),
			'balconies'      => array( 'label' => __( 'Balconies', 'estat-os' ), 'group' => 'amenities' ),
			'amenities'      => array( 'label' => __( 'Amenities', 'estat-os' ), 'group' => 'amenities' ),
			'features'       => array( 'label' => __( 'Features / Highlights', 'estat-os' ), 'group' => 'amenities' ),
			'verified'       => array( 'label' => __( 'Verified Only', 'estat-os' ), 'group' => 'trust' ),
			'featured'       => array( 'label' => __( 'Featured', 'estat-os' ), 'group' => 'trust' ),
			'project'        => array( 'label' => __( 'Society / Project', 'estat-os' ), 'group' => 'location' ),
			'investment'     => array( 'label' => __( 'Investment', 'estat-os' ), 'group' => 'trust' ),
		);
	}

	/**
	 * Share channels.
	 *
	 * @return array<string,string>
	 */
	public static function share_channels(): array {
		return array(
			'whatsapp' => __( 'WhatsApp', 'estat-os' ),
			'copy'     => __( 'Copy Link', 'estat-os' ),
			'email'    => __( 'Email', 'estat-os' ),
			'facebook' => __( 'Facebook', 'estat-os' ),
			'twitter'  => __( 'X (Twitter)', 'estat-os' ),
		);
	}

	/**
	 * Helper: the keys of a vocabulary.
	 *
	 * @param string $name Vocabulary method name.
	 * @return string[]
	 */
	public static function keys( string $name ): array {
		if ( ! method_exists( __CLASS__, $name ) ) {
			return array();
		}
		/** @var array<string,string> $list */
		$list = call_user_func( array( __CLASS__, $name ) );
		return array_map( 'strval', array_keys( $list ) );
	}

	/**
	 * Helper: label for a key.
	 *
	 * @param string $name Vocabulary method name.
	 * @param string $key  Key.
	 * @return string
	 */
	public static function label( string $name, string $key ): string {
		if ( ! method_exists( __CLASS__, $name ) ) {
			return $key;
		}
		/** @var array<string,string> $list */
		$list = call_user_func( array( __CLASS__, $name ) );

		if ( isset( $list[ $key ] ) ) {
			return (string) $list[ $key ];
		}

		// A record saved before the type list was shortened keeps its old key.
		if ( 'property_types' === $name ) {
			$legacy = self::property_types_legacy();
			if ( isset( $legacy[ $key ] ) ) {
				return (string) $legacy[ $key ];
			}
		}

		return $key;
	}
}
