<?php
/**
 * A QR code, made inside the plugin.
 *
 * Why it lives here: the print page used to ask `api.qrserver.com` for a picture
 * of the QR. That meant every printed listing told a stranger's server which
 * property page was being printed, and if that service was slow, blocked or
 * gone, the QR came out broken. This class needs no internet, no GD and no
 * library — it hands back an SVG you can drop straight into the page.
 *
 * It writes byte mode at error correction level M, versions 1 to 10, which
 * covers 213 characters — many times longer than any URL here.
 *
 * @package EstatOS
 */

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

/**
 * QR code builder.
 */
final class Qr {

	/**
	 * Data and error-correction codewords for level M, versions 1–10.
	 *
	 * Each row is a list of groups: { blocks, ecc codewords per block, data codewords per block }.
	 * Numbers come from the QR standard; `verify_qr.php` checks them against an
	 * independent encoder so a typo cannot slip through.
	 */
	private const BLOCKS = array(
		1  => array( array( 1, 10, 16 ) ),
		2  => array( array( 1, 16, 28 ) ),
		3  => array( array( 1, 26, 44 ) ),
		4  => array( array( 2, 18, 32 ) ),
		5  => array( array( 2, 24, 43 ) ),
		6  => array( array( 4, 16, 27 ) ),
		7  => array( array( 4, 18, 31 ) ),
		8  => array( array( 2, 22, 38 ), array( 2, 22, 39 ) ),
		9  => array( array( 3, 22, 36 ), array( 2, 22, 37 ) ),
		10 => array( array( 4, 26, 43 ), array( 1, 26, 44 ) ),
	);

	/**
	 * Where the alignment squares sit, per version (1 has none).
	 */
	private const ALIGN = array(
		2  => array( 6, 18 ),
		3  => array( 6, 22 ),
		4  => array( 6, 26 ),
		5  => array( 6, 30 ),
		6  => array( 6, 34 ),
		7  => array( 6, 22, 38 ),
		8  => array( 6, 24, 42 ),
		9  => array( 6, 26, 46 ),
		10 => array( 6, 28, 50 ),
	);

	/** Format information for level M is 00 in the top two bits. */
	private const ECC_M_BITS = 0;

	private static $exp = null;
	private static $log = null;

	/**
	 * How many bytes fit in each version at level M.
	 *
	 * @param int $version Version 1–10.
	 * @return int
	 */
	private static function capacity( int $version ): int {
		$data = 0;
		foreach ( self::BLOCKS[ $version ] as $group ) {
			$data += $group[0] * $group[2];
		}
		// 4 bits of mode + 8 or 16 bits of "how long is this" + terminator slack.
		$overhead = $version < 10 ? 12 : 20;
		return (int) floor( ( $data * 8 - $overhead ) / 8 );
	}

	/**
	 * Choose the smallest version that fits the text.
	 *
	 * @param string $text Text to encode (bytes, usually UTF-8).
	 * @return int Version, or 0 when the text is too long.
	 */
	private static function fit( string $text ): int {
		$need = strlen( $text );
		for ( $version = 1; $version <= 10; $version++ ) {
			if ( self::capacity( $version ) >= $need ) {
				return $version;
			}
		}
		return 0;
	}

	/**
	 * Galois field tables for Reed–Solomon (polynomial 0x11D).
	 *
	 * @return void
	 */
	private static function tables(): void {
		if ( null !== self::$exp ) {
			return;
		}
		self::$exp = array_fill( 0, 512, 0 );
		self::$log = array_fill( 0, 256, 0 );
		$x = 1;
		for ( $i = 0; $i < 255; $i++ ) {
			self::$exp[ $i ] = $x;
			self::$log[ $x ] = $i;
			$x <<= 1;
			if ( $x & 0x100 ) {
				$x ^= 0x11D;
			}
		}
		for ( $i = 255; $i < 512; $i++ ) {
			self::$exp[ $i ] = self::$exp[ $i - 255 ];
		}
	}

	/**
	 * Multiply two field elements.
	 *
	 * @param int $a First.
	 * @param int $b Second.
	 * @return int
	 */
	private static function mul( int $a, int $b ): int {
		if ( 0 === $a || 0 === $b ) {
			return 0;
		}
		return self::$exp[ self::$log[ $a ] + self::$log[ $b ] ];
	}

	/**
	 * Error correction codewords for one block.
	 *
	 * @param int[] $data Data codewords.
	 * @param int   $ecc  How many correction codewords to make.
	 * @return int[]
	 */
	private static function rs( array $data, int $ecc ): array {
		self::tables();

		// Generator polynomial: (x - a^0)(x - a^1)...(x - a^(ecc-1)).
		$gen = array( 1 );
		for ( $i = 0; $i < $ecc; $i++ ) {
			$next = array_fill( 0, count( $gen ) + 1, 0 );
			foreach ( $gen as $j => $coef ) {
				$next[ $j ]     ^= self::mul( $coef, self::$exp[ $i ] );
				$next[ $j + 1 ] ^= $coef;
			}
			$gen = $next;
		}

		// The loop below works highest power first, so the generator goes the
		// same way: its x^ecc coefficient (a 1) leads.
		$gen = array_reverse( $gen );

		$rem = array_merge( $data, array_fill( 0, $ecc, 0 ) );
		$n   = count( $data );
		for ( $i = 0; $i < $n; $i++ ) {
			$factor = $rem[ $i ];
			if ( 0 === $factor ) {
				continue;
			}
			foreach ( $gen as $j => $coef ) {
				$rem[ $i + $j ] ^= self::mul( $coef, $factor );
			}
		}

		return array_slice( $rem, $n, $ecc );
	}

	/**
	 * Text to codewords: mode, length, the bytes, terminator and padding.
	 *
	 * @param string $text    Text.
	 * @param int    $version Version.
	 * @return int[]
	 */
	private static function codewords( string $text, int $version ): array {
		$bits = array();
		$push = static function ( $value, $length ) use ( &$bits ) {
			for ( $i = $length - 1; $i >= 0; $i-- ) {
				$bits[] = ( $value >> $i ) & 1;
			}
		};

		$push( 0b0100, 4 );                            // Byte mode.
		$push( strlen( $text ), $version < 10 ? 8 : 16 ); // How long.
		foreach ( str_split( $text ) as $char ) {
			$push( ord( $char ), 8 );
		}

		$data = 0;
		foreach ( self::BLOCKS[ $version ] as $group ) {
			$data += $group[0] * $group[2];
		}
		$total = $data * 8;

		// Terminator (up to four zeroes), then pad to a whole codeword.
		$push( 0, min( 4, $total - count( $bits ) ) );
		while ( count( $bits ) % 8 !== 0 ) {
			$bits[] = 0;
		}

		$words = array();
		for ( $i = 0; $i < count( $bits ); $i += 8 ) {
			$byte = 0;
			for ( $j = 0; $j < 8; $j++ ) {
				$byte = ( $byte << 1 ) | $bits[ $i + $j ];
			}
			$words[] = $byte;
		}

		// 0xEC and 0x11 take turns filling the rest.
		$pad = array( 0xEC, 0x11 );
		$k   = 0;
		while ( count( $words ) < $data ) {
			$words[] = $pad[ $k % 2 ];
			$k++;
		}

		return $words;
	}

	/**
	 * Split into blocks, add correction, and interleave in the order the
	 * standard wants (shorter blocks last, codewords taken round robin).
	 *
	 * @param int[] $words   Data codewords.
	 * @param int   $version Version.
	 * @return int[] Final codeword stream.
	 */
	private static function interleave( array $words, int $version ): array {
		$data_blocks = array();
		$ecc_blocks  = array();
		$offset      = 0;

		foreach ( self::BLOCKS[ $version ] as $group ) {
			for ( $b = 0; $b < $group[0]; $b++ ) {
				$chunk          = array_slice( $words, $offset, $group[2] );
				$offset        += $group[2];
				$data_blocks[]  = $chunk;
				$ecc_blocks[]   = self::rs( $chunk, $group[1] );
			}
		}

		$out = array();
		$max = 0;
		foreach ( $data_blocks as $block ) {
			$max = max( $max, count( $block ) );
		}
		for ( $i = 0; $i < $max; $i++ ) {
			foreach ( $data_blocks as $block ) {
				if ( isset( $block[ $i ] ) ) {
					$out[] = $block[ $i ];
				}
			}
		}

		$max_ecc = 0;
		foreach ( $ecc_blocks as $block ) {
			$max_ecc = max( $max_ecc, count( $block ) );
		}
		for ( $i = 0; $i < $max_ecc; $i++ ) {
			foreach ( $ecc_blocks as $block ) {
				if ( isset( $block[ $i ] ) ) {
					$out[] = $block[ $i ];
				}
			}
		}

		return $out;
	}

	/**
	 * The matrix, before and after masking.
	 *
	 * @param string $text    Text to encode.
	 * @param int    $version Version, or 0 to pick the smallest that fits.
	 * @param int    $mask    Mask 0–7 to force, or -1 to let the standard rules choose.
	 * @return array{version:int,mask:int,size:int,modules:bool[][]}|array{}
	 */
	public static function matrix( string $text, int $version = 0, int $mask = -1 ): array {
		if ( 0 === $version ) {
			$version = self::fit( $text );
		}
		if ( $version < 1 || $version > 10 || strlen( $text ) > self::capacity( $version ) ) {
			return array();
		}

		// Every fixed pattern comes from one place, so the two paths below
		// (a forced mask and the "try all eight" path) cannot drift apart.
		$template = self::template( $version );
		$size     = 17 + 4 * $version;
		$matrix   = $template['modules'];
		$func     = $template['func'];

		// Data, bottom-right corner first, two columns at a time, snaking up and down.
		$stream = self::interleave( self::codewords( $text, $version ), $version );
		$bits   = array();
		foreach ( $stream as $word ) {
			for ( $i = 7; $i >= 0; $i-- ) {
				$bits[] = ( $word >> $i ) & 1;
			}
		}

		$place = static function ( $mask_choice ) use ( &$matrix, &$func, $size, $bits ) {
			$index = 0;
			$row   = $size - 1;
			$up    = true;
			for ( $col = $size - 1; $col > 0; $col -= 2 ) {
				if ( 6 === $col ) {
					$col = 5;
				}
				while ( true ) {
					for ( $k = 0; $k < 2; $k++ ) {
						$c = $col - $k;
						if ( $func[ $row ][ $c ] ) {
							continue;
						}
						$bit = isset( $bits[ $index ] ) ? $bits[ $index ] : 0;
						$index++;
						if ( self::mask_bit( $mask_choice, $row, $c ) ) {
							$bit ^= 1;
						}
						$matrix[ $row ][ $c ] = (bool) $bit;
					}
					$row += $up ? -1 : 1;
					if ( $row < 0 || $row >= $size ) {
						$row -= $up ? -1 : 1;
						$up   = ! $up;
						break;
					}
				}
			}
		};

		// Format information, written twice, plus the version blocks on the bigger codes.
		$write_format = static function ( $mask_choice ) use ( &$matrix, $size, $version ) {
			$format = self::format_bits( $mask_choice );
			for ( $i = 0; $i <= 5; $i++ ) {
				$matrix[ $i ][ 8 ] = (bool) ( ( $format >> $i ) & 1 );
			}
			$matrix[ 7 ][ 8 ] = (bool) ( ( $format >> 6 ) & 1 );
			$matrix[ 8 ][ 8 ] = (bool) ( ( $format >> 7 ) & 1 );
			$matrix[ 8 ][ 7 ] = (bool) ( ( $format >> 8 ) & 1 );
			for ( $i = 9; $i <= 14; $i++ ) {
				$matrix[ 8 ][ 14 - $i ] = (bool) ( ( $format >> $i ) & 1 );
			}
			// The second copy runs the other way round: the first eight bits
			// sit in row 8 next to the top-right finder, the rest climb column 8
			// up to the bottom-left finder.
			for ( $i = 0; $i < 8; $i++ ) {
				$matrix[ 8 ][ $size - 1 - $i ] = (bool) ( ( $format >> $i ) & 1 );
			}
			for ( $i = 8; $i < 15; $i++ ) {
				$matrix[ $size - 15 + $i ][ 8 ] = (bool) ( ( $format >> $i ) & 1 );
			}

			if ( $version >= 7 ) {
				$info = self::version_bits( $version );
				for ( $i = 0; $i < 18; $i++ ) {
					$bit = ( $info >> $i ) & 1;
					$row = (int) ( $i / 3 );
					$col = $size - 11 + ( $i % 3 );
					$matrix[ $row ][ $col ] = (bool) $bit;
					$matrix[ $col ][ $row ] = (bool) $bit;
				}
			}
		};

		if ( $mask >= 0 && $mask <= 7 ) {
			$place( $mask );
			$write_format( $mask );
			return array(
				'version' => $version,
				'mask'    => $mask,
				'size'    => $size,
				'modules' => $matrix,
			);
		}

		// Try all eight masks, keep the one the standard scores lowest.
		$best      = 0;
		$best_pen  = PHP_INT_MAX;
		$best_grid = null;
		for ( $choice = 0; $choice < 8; $choice++ ) {
			$matrix = array();
			for ( $r = 0; $r < $size; $r++ ) {
				$matrix[ $r ] = array_fill( 0, $size, false );
			}
			// Re-draw the fixed patterns, then lay the data in again.
			$template = self::template( $version );
			$matrix   = $template['modules'];
			$func     = $template['func'];
			$place( $choice );
			$write_format( $choice );
			$penalty = self::penalty( $matrix, $size );
			if ( $penalty < $best_pen ) {
				$best_pen  = $penalty;
				$best      = $choice;
				$best_grid = $matrix;
			}
		}

		return array(
			'version' => $version,
			'mask'    => $best,
			'size'    => $size,
			'modules' => $best_grid,
		);
	}

	/**
	 * A blank matrix with all the fixed patterns already drawn.
	 *
	 * @param int $version Version.
	 * @return array{modules:bool[][],func:bool[][]}
	 */
	private static function template( int $version ): array {
		$size   = 17 + 4 * $version;
		$matrix = array();
		$func   = array();
		for ( $r = 0; $r < $size; $r++ ) {
			$matrix[ $r ] = array_fill( 0, $size, false );
			$func[ $r ]   = array_fill( 0, $size, false );
		}

		$mark = static function ( $r, $c, $dark ) use ( &$matrix, &$func ) {
			$matrix[ $r ][ $c ] = (bool) $dark;
			$func[ $r ][ $c ]   = true;
		};

		foreach ( array( array( 0, 0 ), array( 0, $size - 7 ), array( $size - 7, 0 ) ) as $corner ) {
			list( $top, $left ) = $corner;
			for ( $r = -1; $r <= 7; $r++ ) {
				for ( $c = -1; $c <= 7; $c++ ) {
					$rr = $top + $r;
					$cc = $left + $c;
					if ( $rr < 0 || $rr >= $size || $cc < 0 || $cc >= $size ) {
						continue;
					}
					$dark = ( $r >= 0 && $r <= 6 && $c >= 0 && $c <= 6 )
						&& ( 0 === $r || 6 === $r || 0 === $c || 6 === $c || ( $r >= 2 && $r <= 4 && $c >= 2 && $c <= 4 ) );
					$mark( $rr, $cc, $dark );
				}
			}
		}

		for ( $i = 8; $i < $size - 8; $i++ ) {
			$mark( 6, $i, 0 === $i % 2 );
			$mark( $i, 6, 0 === $i % 2 );
		}

		$spots = self::ALIGN[ $version ] ?? array();
		foreach ( $spots as $row ) {
			foreach ( $spots as $col ) {
				$on_finder = ( $row < 9 && $col < 9 )
					|| ( $row < 9 && $col > $size - 9 )
					|| ( $row > $size - 9 && $col < 9 );
				if ( $on_finder ) {
					continue;
				}
				for ( $r = -2; $r <= 2; $r++ ) {
					for ( $c = -2; $c <= 2; $c++ ) {
						$dark = 2 === max( abs( $r ), abs( $c ) ) || ( 0 === $r && 0 === $c );
						$mark( $row + $r, $col + $c, $dark );
					}
				}
			}
		}

		$mark( $size - 8, 8, true );

		for ( $i = 0; $i <= 8; $i++ ) {
			if ( ! $func[ 8 ][ $i ] ) {
				$mark( 8, $i, false );
			}
			if ( ! $func[ $i ][ 8 ] ) {
				$mark( $i, 8, false );
			}
		}
		for ( $i = 0; $i < 8; $i++ ) {
			$mark( 8, $size - 1 - $i, false );
		}
		for ( $i = 0; $i < 7; $i++ ) {
			$mark( $size - 1 - $i, 8, false );
		}
		// This one is dark in every QR code ever made — reserved last so
		// nothing can paint over it.
		$mark( $size - 8, 8, true );
		if ( $version >= 7 ) {
			for ( $i = 0; $i < 6; $i++ ) {
				for ( $j = 0; $j < 3; $j++ ) {
					$mark( $size - 11 + $j, $i, false );
					$mark( $i, $size - 11 + $j, false );
				}
			}
		}

		return array(
			'modules' => $matrix,
			'func'    => $func,
		);
	}

	/**
	 * Is this module flipped by the mask?
	 *
	 * @param int $mask Mask number.
	 * @param int $row  Row.
	 * @param int $col  Column.
	 * @return bool
	 */
	private static function mask_bit( int $mask, int $row, int $col ): bool {
		switch ( $mask ) {
			case 0:
				return 0 === ( $row + $col ) % 2;
			case 1:
				return 0 === $row % 2;
			case 2:
				return 0 === $col % 3;
			case 3:
				return 0 === ( $row + $col ) % 3;
			case 4:
				return 0 === ( (int) floor( $row / 2 ) + (int) floor( $col / 3 ) ) % 2;
			case 5:
				return 0 === ( ( $row * $col ) % 2 ) + ( ( $row * $col ) % 3 );
			case 6:
				return 0 === ( ( ( $row * $col ) % 2 ) + ( ( $row * $col ) % 3 ) ) % 2;
			default:
				return 0 === ( ( ( $row + $col ) % 2 ) + ( ( $row * $col ) % 3 ) ) % 2;
		}
	}

	/**
	 * Format information: ECC level, mask, and a BCH check, then the standard mask.
	 *
	 * @param int $mask Mask number.
	 * @return int 15 bits.
	 */
	private static function format_bits( int $mask ): int {
		$data = ( self::ECC_M_BITS << 3 ) | $mask;
		$bits = $data << 10;
		for ( $i = 14; $i >= 10; $i-- ) {
			if ( ( $bits >> $i ) & 1 ) {
				$bits ^= 0x537 << ( $i - 10 );
			}
		}
		return ( ( $data << 10 ) | $bits ) ^ 0x5412;
	}

	/**
	 * Version information for versions 7 and up: a BCH check on the version number.
	 *
	 * @param int $version Version.
	 * @return int 18 bits.
	 */
	private static function version_bits( int $version ): int {
		$bits = $version << 12;
		for ( $i = 17; $i >= 12; $i-- ) {
			if ( ( $bits >> $i ) & 1 ) {
				$bits ^= 0x1F25 << ( $i - 12 );
			}
		}
		return ( $version << 12 ) | $bits;
	}

	/**
	 * The four penalty rules from the standard — lower is better.
	 *
	 * @param bool[][] $matrix Modules.
	 * @param int      $size   Side length.
	 * @return int
	 */
	private static function penalty( array $matrix, int $size ): int {
		$score = 0;

		// Rule 1: runs of five or more of the same colour.
		for ( $r = 0; $r < $size; $r++ ) {
			$run  = 1;
			$prev = $matrix[ $r ][0];
			for ( $c = 1; $c < $size; $c++ ) {
				if ( $matrix[ $r ][ $c ] === $prev ) {
					$run++;
				} else {
					if ( $run >= 5 ) {
						$score += 3 + ( $run - 5 );
					}
					$run  = 1;
					$prev = $matrix[ $r ][ $c ];
				}
			}
			if ( $run >= 5 ) {
				$score += 3 + ( $run - 5 );
			}
		}
		for ( $c = 0; $c < $size; $c++ ) {
			$run  = 1;
			$prev = $matrix[0][ $c ];
			for ( $r = 1; $r < $size; $r++ ) {
				if ( $matrix[ $r ][ $c ] === $prev ) {
					$run++;
				} else {
					if ( $run >= 5 ) {
						$score += 3 + ( $run - 5 );
					}
					$run  = 1;
					$prev = $matrix[ $r ][ $c ];
				}
			}
			if ( $run >= 5 ) {
				$score += 3 + ( $run - 5 );
			}
		}

		// Rule 2: 2x2 blocks of one colour.
		for ( $r = 0; $r < $size - 1; $r++ ) {
			for ( $c = 0; $c < $size - 1; $c++ ) {
				$v = $matrix[ $r ][ $c ];
				if ( $v === $matrix[ $r ][ $c + 1 ] && $v === $matrix[ $r + 1 ][ $c ] && $v === $matrix[ $r + 1 ][ $c + 1 ] ) {
					$score += 3;
				}
			}
		}

		// Rule 3: a finder-like pattern (dark, light, dark x3, light, dark) with a
		// run of at least four light modules on one side and at least one on the
		// other. The quiet zone outside the code counts as light, the way the
		// reference encoders treat it.
		$core = array( true, false, true, true, true, false, true );
		$lines = array();
		foreach ( $matrix as $row ) {
			$lines[] = $row;
		}
		for ( $c = 0; $c < $size; $c++ ) {
			$column = array();
			for ( $r = 0; $r < $size; $r++ ) {
				$column[] = $matrix[ $r ][ $c ];
			}
			$lines[] = $column;
		}
		foreach ( $lines as $line ) {
			for ( $start = 0; $start <= $size - 7; $start++ ) {
				if ( ! self::slice_is( $line, $start, $core ) ) {
					continue;
				}
				$before = 0;
				for ( $i = $start - 1; $i >= 0 && ! $line[ $i ]; $i-- ) {
					$before++;
				}
				if ( 0 === $start ) {
					$before = $size;
				}
				$after = 0;
				for ( $i = $start + 7; $i < $size && ! $line[ $i ]; $i++ ) {
					$after++;
				}
				if ( $start + 7 === $size ) {
					$after = $size;
				}
				if ( $before >= 4 && $after >= 1 ) {
					$score += 40;
				}
				if ( $after >= 4 && $before >= 1 ) {
					$score += 40;
				}
			}
		}

		// Rule 4: how far the dark share strays from half.
		$dark = 0;
		foreach ( $matrix as $row ) {
			foreach ( $row as $cell ) {
				if ( $cell ) {
					$dark++;
				}
			}
		}
		$percent = $dark * 100 / ( $size * $size );
		$score  += 10 * (int) floor( abs( $percent - 50 ) / 5 );

		return $score;
	}

	/**
	 * Does the pattern sit at this spot?
	 *
	 * @param bool[] $line   Row or column.
	 * @param int    $start  Where to look.
	 * @param bool[] $needle Pattern.
	 * @return bool
	 */
	private static function slice_is( array $line, int $start, array $needle ): bool {
		foreach ( $needle as $i => $bit ) {
			if ( ! isset( $line[ $start + $i ] ) || $line[ $start + $i ] !== $bit ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * An SVG of the QR code, ready to drop into a page.
	 *
	 * @param string $text Text to encode, usually a link.
	 * @param array  $args {
	 *     Optional. size (px, default 140), quiet (modules of white edge, default 4),
	 *     dark, light, class, title.
	 * }
	 * @return string SVG markup, or '' when the text is too long to encode.
	 */
	public static function svg( string $text, array $args = array() ): string {
		$args = array_merge(
			array(
				'size'  => 140,
				'quiet' => 4,
				'dark'  => '#111111',
				'light' => '#ffffff',
				'class' => '',
				'title' => '',
			),
			$args
		);

		$code = self::matrix( $text );
		if ( array() === $code ) {
			return '';
		}

		$quiet = max( 0, (int) $args['quiet'] );
		$span  = $code['size'] + $quiet * 2;
		$path  = array();

		foreach ( $code['modules'] as $r => $row ) {
			$c = 0;
			while ( $c < $code['size'] ) {
				if ( ! $row[ $c ] ) {
					$c++;
					continue;
				}
				$run = 1;
				while ( $c + $run < $code['size'] && $row[ $c + $run ] ) {
					$run++;
				}
				$path[] = 'M' . ( $c + $quiet ) . ' ' . ( $r + $quiet ) . 'h' . $run . 'v1h-' . $run . 'z';
				$c     += $run;
			}
		}

		$size  = max( 40, (int) $args['size'] );
		$class = '' !== $args['class'] ? ' class="' . esc_attr( $args['class'] ) . '"' : '';
		$label = '' !== $args['title']
			? '<title>' . esc_html( $args['title'] ) . '</title>'
			: '';

		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $span . ' ' . $span . '"'
			. ' width="' . $size . '" height="' . $size . '"'
			. ' shape-rendering="crispEdges" role="img"' . $class . '>'
			. $label
			. '<rect width="' . $span . '" height="' . $span . '" fill="' . esc_attr( $args['light'] ) . '"/>'
			. '<path d="' . implode( '', $path ) . '" fill="' . esc_attr( $args['dark'] ) . '"/>'
			. '</svg>';
	}
}
