<?php
/**
 * Cache clearing, done by the plugin so nobody has to remember.
 *
 * Why this exists: after an update, the new CSS and JavaScript have new file
 * names, but the pages a visitor is served may still come from a cache built
 * before the update. The plugin cannot see any of those caches directly — each
 * one has its own switch — so this asks every common one politely, and always
 * does the things that are ours (transients, object cache, rewrite rules).
 *
 * Nothing here is required: if no cache plugin is installed, the calls below
 * simply do nothing.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

defined( 'ABSPATH' ) || exit;

final class Cache {

	/**
	 * Purge everything, everywhere, best effort.
	 *
	 * @param string $why A short reason, for the log and for other plugins.
	 * @return void
	 */
	public static function purge_all( string $why = 'Estat.OS' ): void {
		// Ours first: our own temporary data can never be stale after this.
		delete_transient( 'estat_stats' );
		delete_transient( 'estat_search_counts' );
		delete_transient( 'estat_terms_locality' );
		delete_transient( 'estat_terms_amenity' );
		delete_transient( 'estat_terms_feature' );
		delete_transient( 'estat_projects_ids' );

		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}

		// Page caches, one by one. Every call is guarded; a site with none of
		// these plugins runs this method in microseconds.
		if ( function_exists( 'rocket_clean_domain' ) ) {          // WP Rocket.
			rocket_clean_domain();
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {                 // W3 Total Cache.
			w3tc_flush_all();
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {           // WP Super Cache.
			wp_cache_clear_cache();
		}
		if ( function_exists( 'wpfc_clear_all_cache' ) ) {           // WP Fastest Cache.
			wpfc_clear_all_cache( true );
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {      // SiteGround.
			sg_cachepress_purge_cache();
		}
		if ( function_exists( 'swcfpc_purge_cache' ) ) {             // Super Page Cache.
			swcfpc_purge_cache();
		}
		if ( class_exists( '\LiteSpeed\Purge' ) && method_exists( '\LiteSpeed\Purge', 'purge_all' ) ) {
			\LiteSpeed\Purge::purge_all( $why );
		}
		if ( class_exists( '\Cache_Lite' ) === false && class_exists( '\WP_Optimize' ) && method_exists( '\WP_Optimize', 'get_page_cache' ) ) {
			$page_cache = \WP_Optimize::get_page_cache();
			if ( is_object( $page_cache ) && method_exists( $page_cache, 'purge' ) ) {
				$page_cache->purge();
			}
		}

		/**
		 * Hooks other caches listen on. LiteSpeed, Cloudflare and a few others
		 * watch these, and a site using something we have never heard of can
		 * still be served by a small plugin that hooks the same name.
		 */
		do_action( 'litespeed_purge_all', $why );
		do_action( 'cloudflare_purge_everything' );
		do_action( 'autoptimize_action_cachepurged' );
		do_action( 'estat_caches_purged', $why );

		update_option( 'estat_cache_purged_at', current_time( 'mysql', true ), false );
	}

	/**
	 * When the plugin last cleared the caches, in the site's own time.
	 *
	 * @return string Empty when it has never run.
	 */
	public static function purged_at(): string {
		$stored = (string) get_option( 'estat_cache_purged_at', '' );
		if ( '' === $stored ) {
			return '';
		}
		$local = get_date_from_gmt( $stored, 'Y-m-d H:i' );
		return '' !== $local ? $local : $stored;
	}
}
