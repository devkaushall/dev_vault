<?php
/**
 * Public website: asset registration and template fallbacks.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\PostTypes;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Assets are registered globally but only enqueued by the component that needs
 * them, so a page without a property widget loads no plugin CSS or JavaScript.
 */
final class Frontend {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_filter( 'template_include', array( __CLASS__, 'template_fallback' ) );
		add_filter( 'pre_get_posts', array( __CLASS__, 'archive_query' ) );
		add_filter( 'script_loader_tag', array( __CLASS__, 'defer_public' ), 10, 3 );
		// B10: Ensure Rank Math sitemap includes plugin post types.
		add_filter( 'rank_math/sitemap/post_type', array( __CLASS__, 'rank_math_sitemap' ), 10, 2 );
		add_filter( 'rank_math/sitemap/enable_caching', '__return_false' ); // Ensure fresh during dev.
	}

	/**
	 * Add defer to public.js per brief (≤20KB defer).
	 */
	public static function defer_public( string $tag, string $handle, string $src ): string {
		if ( 'estat-public' === $handle ) {
			if ( false === strpos( $tag, ' defer' ) ) {
				$tag = str_replace( '<script ', '<script defer ', $tag );
			}
		}
		return $tag;
	}

	/**
	 * Register (not enqueue) every public asset.
	 *
	 * @return void
	 */
	public static function register_assets(): void {
		/*
		 * tokens.css comes first and everything on the website depends on it.
		 *
		 * It was only ever loaded in the office and in Pocket, so every
		 * var(--estat-…) in public.css and forms.css was pointing at nothing:
		 * the website got its colours and sizes from browser defaults and from
		 * whatever the theme happened to set. Registering it here is what makes
		 * "Colours and fonts" in Office Settings change the website as well —
		 * and it is the one place a colour is written down.
		 */
		wp_register_style( 'estat-tokens', ESTAT_URL . 'assets/css/tokens.css', array(), ESTAT_VERSION );
		wp_register_style( 'estat-public', ESTAT_URL . 'assets/css/public.css', array( 'estat-tokens' ), ESTAT_VERSION );
		wp_register_style( 'estat-forms', ESTAT_URL . 'assets/css/forms.css', array( 'estat-tokens' ), ESTAT_VERSION );

		wp_register_script( 'estat-forms', ESTAT_URL . 'assets/js/forms.js', array(), ESTAT_VERSION, true );
		wp_register_script( 'estat-public', ESTAT_URL . 'assets/js/public.js', array(), ESTAT_VERSION, true );

		$strings = array(
			'sending'      => __( 'Sending…', 'estat-os' ),
			'genericError' => __( 'Something went wrong. Please try again.', 'estat-os' ),
			'required'     => __( 'This information is needed.', 'estat-os' ),
			'saved'        => __( 'Saved.', 'estat-os' ),
			'compareFull'  => __( 'You can compare up to four properties at a time.', 'estat-os' ),
			'added'        => __( 'Added', 'estat-os' ),
			'removed'      => __( 'Removed', 'estat-os' ),

			// Used by the repayment estimate.
			'crore'        => __( 'Cr', 'estat-os' ),
			'lakh'         => __( 'Lakh', 'estat-os' ),
			'thousand'     => __( 'K', 'estat-os' ),
			/* translators: %s: total amount repaid over the whole loan. */
			'emiTotal'     => __( '%s repaid in total', 'estat-os' ),
			'emiCheck'     => __( 'Please check the numbers.', 'estat-os' ),
		);

		wp_localize_script(
			'estat-forms',
			'estatForms',
			array(
				'restUrl' => esc_url_raw( rest_url( 'estat/v1/' ) ),
				'i18n'    => $strings,
			)
		);
		wp_localize_script(
			'estat-public',
			'estatPublic',
			array(
				'restUrl'   => esc_url_raw( rest_url( 'estat/v1/' ) ),
				'favorites' => (bool) Settings::get( 'enable_favorites' ),
				'compare'   => (bool) Settings::get( 'enable_compare' ),

				/*
				 * The repayment estimate formats its answer in the browser, so
				 * it needs the same currency settings the server uses. Without
				 * these the calculator would print a raw number beside prices
				 * written as "45 Lakh", which reads as two different websites.
				 */
				'currency'  => (string) Settings::get( 'currency_symbol' ),
				'priceStyle' => (string) Settings::get( 'price_format' ),
				'i18n'      => $strings,
			)
		);
	}

	/**
	 * Provide simple templates when the theme has none, so the website works
	 * with or without Elementor and with any theme.
	 *
	 * @param string $template Resolved template.
	 * @return string
	 */
	public static function template_fallback( $template ) {
		/*
		 * Choosing a template is the one place on the website where a mistake
		 * shows up as "this website is broken" on every page at once. So the
		 * work happens in choose_template() and any surprise at all — a theme,
		 * a page builder, another plugin — ends with WordPress drawing the page
		 * the normal way instead of a fatal error.
		 */
		try {
			return self::choose_template( $template );
		} catch ( \Throwable $e ) {
			if ( function_exists( 'error_log' ) ) {
				error_log( 'Estat OS: template choice failed, using the theme — ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			}
			return $template;
		}
	}

	/**
	 * Which file draws this page?
	 *
	 * @param string $template Resolved template.
	 * @return string
	 */
	private static function choose_template( $template ) {
		$types = array(
			PostTypes::LISTING => 'listing',
			PostTypes::PROJECT => 'project',
			PostTypes::AGENT   => 'agent',
		);

		/*
		 * Who draws a single property page: the website or the plugin?
		 *
		 * The office builds its pages in Elementor, so by default the plugin
		 * keeps its hands off a page that is already drawn — by the theme, or
		 * by an Elementor template. The setting is for the other kind of site:
		 * a plain theme with no template of its own.
		 */
		$renderer = (string) Settings::get( 'page_renderer', 'theme' );

		foreach ( $types as $post_type => $slug ) {
			if ( is_singular( $post_type ) ) {
				$theme = locate_template( array( "single-{$post_type}.php" ) );
				if ( $theme ) {
					return $theme;
				}
				/*
				 * Elementor is only asked on a page it could actually be
				 * drawing, and only when the plugin's own template is allowed
				 * to yield. Asking on every request was what broke the site.
				 */
				if ( 'plugin' !== $renderer && \EstatOS\Integrations\Elementor\Bridge::has_template( 'single' ) ) {
					return $template; // Elementor's template is the page.
				}
				$fallback = ESTAT_DIR . "includes/Frontend/templates/single-{$slug}.php";
				if ( is_readable( $fallback ) ) {
					return $fallback;
				}
			}
				if ( is_post_type_archive( $post_type ) ) {
				$theme = locate_template( array( "archive-{$post_type}.php" ) );
				if ( $theme ) {
					return $theme;
				}
				if ( 'plugin' !== $renderer && \EstatOS\Integrations\Elementor\Bridge::has_template( 'archive' ) ) {
					return $template; // Elementor's archive template is the page.
				}
				$fallback = ESTAT_DIR . "includes/Frontend/templates/archive-{$slug}.php";
				if ( is_readable( $fallback ) ) {
					return $fallback;
				}
			}
		}

		// F10: taxonomy fallbacks for locality, amenity, feature — fixed F12: was shadowed by archive check above.
		$tax_map = array(
			\EstatOS\Data\Taxonomies::LOCALITY => 'estat_locality',
			\EstatOS\Data\Taxonomies::AMENITY  => 'estat_amenity',
			\EstatOS\Data\Taxonomies::FEATURE  => 'estat_feature',
		);
		foreach ( $tax_map as $tax => $tmpl ) {
			if ( is_tax( $tax ) ) {
				$theme = locate_template( array( "taxonomy-{$tax}.php", "taxonomy-{$tmpl}.php" ) );
				if ( $theme ) {
					return $theme;
				}
				$fallback = ESTAT_DIR . "includes/Frontend/templates/taxonomy-{$tmpl}.php";
				if ( is_readable( $fallback ) ) {
					return $fallback;
				}
			}
		}

		return $template;
	}

	/**
	 * Apply the configured page size to plugin archives (never unbounded).
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public static function archive_query( $query ): void {
		if ( is_admin() || ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return;
		}
		if ( $query->is_post_type_archive( PostTypes::LISTING ) || $query->is_tax( array( \EstatOS\Data\Taxonomies::LOCALITY, \EstatOS\Data\Taxonomies::AMENITY, \EstatOS\Data\Taxonomies::FEATURE ) ) ) {
			$query->set( 'posts_per_page', (int) Settings::get( 'listings_per_page', 12 ) );
		}
	}

	/**
	 * B10: Ensure Rank Math includes our post types in sitemap.
	 *
	 * @param bool   $is_included Whether post type is included.
	 * @param string $post_type   Post type name.
	 * @return bool
	 */
	public static function rank_math_sitemap( $is_included, $post_type ) {
		$our_types = array( PostTypes::LISTING, PostTypes::PROJECT, PostTypes::AGENT, PostTypes::INSIGHT );
		if ( in_array( $post_type, $our_types, true ) ) {
			return true;
		}
		return $is_included;
	}
}
