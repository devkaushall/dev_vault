<?php
/**
 * Share Row + Print Page — F5 polished.
 *
 * - WhatsApp / Copy link / Email / Facebook / Twitter / Native Share + Print
 * - ?print=1 gives clean summary (no external CSS, inline styles, verified badge, gallery, agent, facts, QR, EMI, disclaimer)
 * - Share events logged for analytics (estat_share_log)
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Listings;
use EstatOS\Install\Schema;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class Share {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp', array( __CLASS__, 'maybe_print' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rest_routes' ) );
	}

	/**
	 * Enqueue share JS + inline CSS.
	 *
	 * @return void
	 */
	public static function assets(): void {
		wp_register_script( 'estat-share', ESTAT_URL . 'assets/js/share.js', array(), ESTAT_VERSION, true );
		wp_enqueue_script( 'estat-share' );
		/*
		 * One small block, and every colour in it comes from tokens.css —
		 * the same file the rest of the site and the office use. The WhatsApp
		 * green is the one deliberate exception: it is WhatsApp's colour, not
		 * ours, and it must not change when the office changes the palette.
		 */
		$css = '.estat-share-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:12px;border:1px solid var(--estat-line);border-radius:12px;background:var(--estat-surface);margin:16px 0}'
			. '.estat-share-label{font-size:13px;color:var(--estat-ink-3);margin-right:4px}'
			. '.estat-share-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:8px;border:1px solid var(--estat-line);background:var(--estat-surface);color:var(--estat-ink);text-decoration:none;font-size:13px;cursor:pointer;line-height:1}'
			. '.estat-share-btn:hover{background:var(--estat-raised)}'
			. '.estat-share-whatsapp{background:#25D366;color:#fff;border-color:#25D366}'
			. '.estat-share-whatsapp:hover{background:#128C7E;border-color:#128C7E;color:#fff}'
			. '.estat-share-copy.is-copied{background:var(--estat-ink);color:var(--estat-surface)}';
		if ( ! wp_style_is( 'estat-tokens', 'registered' ) ) {
			wp_register_style( 'estat-tokens', ESTAT_URL . 'assets/css/tokens.css', array(), ESTAT_VERSION );
		}
		if ( ! wp_style_is( 'estat-share', 'registered' ) ) {
			wp_register_style( 'estat-share', false, array( 'estat-tokens' ), ESTAT_VERSION );
		}
		wp_enqueue_style( 'estat-share' );
		wp_add_inline_style( 'estat-share', $css );
	}

	/**
	 * REST route for share logging.
	 *
	 * @return void
	 */
	public static function rest_routes(): void {
		register_rest_route(
			'estat/v1',
			'/share',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_share' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Log share event.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function rest_share( \WP_REST_Request $request ) {
		$listing_id = (int) $request->get_param( 'listing_id' );
		$channel    = sanitize_key( (string) $request->get_param( 'channel' ) );

		if ( $listing_id > 0 && in_array( $channel, array_keys( Vocabulary::share_channels() ), true ) ) {
			global $wpdb;
			$table = Schema::table( 'estat_share_log' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->insert(
				$table,
				array(
					'created_at' => current_time( 'mysql', true ),
					'listing_id' => $listing_id,
					'channel'    => $channel,
					'ip_hash'    => hash( 'sha256', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) . '|' . wp_salt() ),
				)
			);
			do_action( 'estat_share_logged', $listing_id, $channel );
		}

		return new \WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * If ?print=1, render clean print template for listing or project.
	 *
	 * @return void
	 */
	public static function maybe_print(): void {
		if ( ! isset( $_GET['print'] ) || '1' !== (string) ( is_array($_GET['print']) ? '' : $_GET['print'] ) ) {
			return;
		}
		if ( ! is_singular( array( 'estat_listing', 'estat_project' ) ) ) {
			return;
		}
		$listing_id = get_the_ID();
		if ( ! $listing_id ) {
			return;
		}
		// Only if print_enabled.
		if ( ! Settings::get( 'print_enabled', true ) ) {
			return;
		}

		// Load print template.
		$template = ESTAT_DIR . 'includes/Frontend/templates/print-listing.php';
		if ( is_readable( $template ) ) {
			include $template;
			exit;
		}
	}

	/**
	 * Render share row for a listing — F5 polished with WhatsApp prefilled, copy, email, social, native share, print.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function render_row( int $listing_id ): string {
		$url   = get_permalink( $listing_id );
		$title = get_the_title( $listing_id );
		if ( ! $url ) {
			return '';
		}

		$listing = Listings::to_array( $listing_id, false );
		$price_display = $listing['price_display'] ?? '';
		$address = $listing['address'] ?? ( $listing['locality'][0] ?? '' );
		$verified = 'office_verified' === (string) ( $listing['verification'] ?? '' );

		// WhatsApp message: Title + Price + Address + URL + verified note.
		$wa_text = sprintf(
			"%s — %s\n%s\n%s%s",
			$title,
			$price_display ?: 'Property',
			$address ? "{$address}" : '',
			$url,
			$verified ? "\nVerified" : ''
		);
		$encoded_url   = rawurlencode( $url );
		$encoded_title = rawurlencode( $title );
		$encoded_wa    = rawurlencode( $wa_text );

		$whatsapp = 'https://wa.me/?text=' . $encoded_wa;
		$facebook = 'https://www.facebook.com/sharer/sharer.php?u=' . $encoded_url;
		$twitter  = 'https://twitter.com/intent/tweet?url=' . $encoded_url . '&text=' . $encoded_title;
		$email_subject = rawurlencode( sprintf( __( 'Property: %s', 'estat-os' ), $title ) );
		$email_body = rawurlencode( sprintf( "%s\n%s\n\n%s\n\n%s", $title, $price_display, $address, $url ) );
		$mailto = 'mailto:?subject=' . $email_subject . '&body=' . $email_body;

		$print_url = add_query_arg( 'print', '1', $url );

		ob_start();
		?>
		<div class="estat-share-row" data-listing="<?php echo esc_attr( (string) $listing_id ); ?>">
			<span class="estat-share-label"><?php esc_html_e( 'Share this home:', 'estat-os' ); ?></span>
			<a class="estat-share-btn estat-share-whatsapp" href="<?php echo esc_url( $whatsapp ); ?>" target="_blank" rel="noopener" data-channel="whatsapp" aria-label="WhatsApp">
				<?php echo \EstatOS\Support\Icon::render( 'whatsapp', 16 ); ?> <?php esc_html_e( 'WhatsApp', 'estat-os' ); ?>
			</a>
			<button class="estat-share-btn estat-share-copy" type="button" data-channel="copy" data-url="<?php echo esc_attr( $url ); ?>" aria-label="<?php esc_attr_e( 'Copy link', 'estat-os' ); ?>">
				<?php echo \EstatOS\Support\Icon::render( 'share', 16 ); ?> <?php esc_html_e( 'Copy link', 'estat-os' ); ?>
			</button>
			<a class="estat-share-btn" href="<?php echo esc_url( $mailto ); ?>" data-channel="email" aria-label="Email">
				<?php echo \EstatOS\Support\Icon::render( 'inbox', 16 ); ?> <?php esc_html_e( 'Email', 'estat-os' ); ?>
			</a>
			<button class="estat-share-btn estat-share-native" type="button" data-channel="native" data-url="<?php echo esc_attr( $url ); ?>" data-title="<?php echo esc_attr( $title ); ?>" style="display:none">
				<?php echo \EstatOS\Support\Icon::render( 'share', 16 ); ?> <?php esc_html_e( 'Share', 'estat-os' ); ?>
			</button>
			<a class="estat-share-btn" href="<?php echo esc_url( $facebook ); ?>" target="_blank" rel="noopener" data-channel="facebook" aria-label="Facebook">f Facebook</a>
			<a class="estat-share-btn" href="<?php echo esc_url( $twitter ); ?>" target="_blank" rel="noopener" data-channel="twitter" aria-label="X">X</a>
			<a class="estat-share-btn estat-share-print" href="<?php echo esc_url( $print_url ); ?>" target="_blank" rel="noopener" data-channel="print">
				<?php echo \EstatOS\Support\Icon::render( 'document', 16 ); ?> <?php esc_html_e( 'Print', 'estat-os' ); ?>
			</a>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
