<?php
/**
 * The search-engine contract.
 *
 * One place decides what a search engine is told about every page the plugin
 * puts on the website: may this be indexed, what is the one true address, what
 * is the title, and what is the one-line description. The SEO plugin (Rank
 * Math, Yoast) keeps the last word when the office has written something by
 * hand; otherwise these answers come from the office's own records, so a
 * property, a locality page and the properties list can never drift apart from
 * the data in Estat.OS.
 *
 * Rules, in plain words:
 *   - A published property, and a locality/amenity/feature page that actually
 *     holds something, may be indexed.
 *   - A filter or search result (`?offer=rent&bedrooms=3`) may not: it points
 *     at the clean address instead. Google is spared thousands of combinations.
 *   - A page that would show nothing (no projects, an empty locality, search,
 *     saved properties, compare, thank you) is kept out of the index until it
 *     has something to say.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Listings;
use EstatOS\Data\Projects;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Support\Format;
use EstatOS\Settings\Settings;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * Indexing, titles, descriptions and canonical addresses.
 */
final class Seo {

	/**
	 * Address parameters that make a page a filtered view rather than a page.
	 *
	 * These are the ones the properties shortcode accepts, so the list is not a
	 * guess: it is the same list the form puts in the address bar.
	 *
	 * @var string[]
	 */
	public const FILTER_PARAMS = array(
		'keyword',
		'offer',
		'property_type',
		'locality',
		'bedrooms_min',
		'bedrooms_max',
		'bathrooms_min',
		'price_min',
		'price_max',
		'area_min',
		'area_max',
		'furnishing',
		'facing',
		'floor_min',
		'floor_max',
		'total_floors_min',
		'parking_min',
		'balconies_min',
		'age_max',
		'possession',
		'construction',
		'availability',
		'verified',
		'featured',
		'investment',
		'project_id',
		'agent_id',
		'amenities',
		'features',
		'orderby',
		'estat_page',
	);

	/**
	 * Public pages of ours that are tools or personal, never a landing page.
	 *
	 * @var string[]
	 */
	public const NOINDEX_PAGES = array(
		'search',
		'alerts',
		'favorites',
		'compare',
		'thank-you',
	);

	/**
	 * Public pages that are worth indexing only while they hold something.
	 *
	 * @var string[]
	 */
	public const INVENTORY_PAGES = array(
		'properties',
		'projects',
		'projects-by-stage',
		'localities',
		'locality-map',
		'amenities',
		'features',
		'team',
	);

	/**
	 * Register the hooks. The SEO plugin's own filters are used when it is
	 * there; core hooks cover a site that runs without one.
	 *
	 * @return void
	 */
	public function register(): void {
		// The head is watched rather than trusted: an SEO plugin may decide to
		// say nothing at all, and then the page goes out with no description.
		add_action( 'wp_head', array( __CLASS__, 'head_start' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'head_end' ), 1000000 );
		add_filter( 'document_title_parts', array( __CLASS__, 'title_parts' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'core_robots' ) );

		if ( defined( 'RANK_MATH_VERSION' ) ) {
			add_filter( 'rank_math/frontend/title', array( __CLASS__, 'rank_math_title' ) );
			add_filter( 'rank_math/frontend/description', array( __CLASS__, 'rank_math_description' ) );
			add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'rank_math_robots' ) );
			add_filter( 'rank_math/frontend/canonical', array( __CLASS__, 'rank_math_canonical' ) );
		}
		if ( defined( 'WPSEO_VERSION' ) ) {
			add_filter( 'wpseo_title', array( __CLASS__, 'rank_math_title' ) );
			add_filter( 'wpseo_metadesc', array( __CLASS__, 'rank_math_description' ) );
			add_filter( 'wpseo_robots', array( __CLASS__, 'yoast_robots' ) );
			add_filter( 'wpseo_canonical', array( __CLASS__, 'rank_math_canonical' ) );
		}

		/*
		 * A page we keep out of Google does not belong in the sitemap either.
		 *
		 * The sitemap on the live site was listing /search/, /alerts/,
		 * /favorites/, /compare/ and /thank-you/ — pages we ourselves mark
		 * noindex. Handing Google a list of pages and then telling it to keep
		 * out of them is the sort of thing Search Console reports back as a
		 * mistake, and it wastes the crawl it does have.
		 */
		add_filter( 'rank_math/sitemap/exclude_posts', array( __CLASS__, 'sitemap_exclude' ) );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'core_sitemap_args' ), 10, 2 );
	}

	/**
	 * Our noindex pages, by ID, for the sitemap that the SEO plugin builds.
	 *
	 * @param array<int,int> $ids IDs already excluded.
	 * @return array<int,int>
	 */
	public static function sitemap_exclude( $ids ): array {
		return array_values( array_unique( array_merge( (array) $ids, self::noindex_ids() ) ) );
	}

	/**
	 * Same for WordPress's own sitemap, when no SEO plugin is running.
	 *
	 * @param array<string,mixed> $args      Query arguments.
	 * @param string              $post_type Post type being listed.
	 * @return array<string,mixed>
	 */
	public static function core_sitemap_args( $args, $post_type = '' ): array {
		if ( 'page' !== $post_type ) {
			return (array) $args;
		}
		$ids = self::noindex_ids();
		if ( ! $ids ) {
			return (array) $args;
		}
		$args = (array) $args;
		$args['post__not_in'] = array_values( array_unique( array_merge( (array) ( $args['post__not_in'] ?? array() ), $ids ) ) );
		return $args;
	}

	/**
	 * The IDs of our pages that are kept out of search engines.
	 *
	 * @return array<int,int>
	 */
	private static function noindex_ids(): array {
		if ( ! self::NOINDEX_PAGES ) {
			return array();
		}
		$posts = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'publish',
				'posts_per_page'   => 200,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);
		if ( ! is_array( $posts ) ) {
			return array();
		}
		// Compared here rather than in the query: a slug WordPress has had to
		// make unique ('search-2') is not the page we mean.
		$wanted = array_map( 'strval', self::NOINDEX_PAGES );
		$ids    = array();
		foreach ( $posts as $pid ) {
			if ( in_array( (string) get_post_field( 'post_name', (int) $pid ), $wanted, true ) ) {
				$ids[] = (int) $pid;
			}
		}
		return $ids;
	}

	/* ------------------------------------------------------------------ plan */

	/**
	 * What should be said about the page being looked at.
	 *
	 * @return array<string,mixed>
	 */
	public static function plan(): array {
		return self::decide( self::context() );
	}

	/**
	 * The decision itself, from a plain description of the page. Kept separate
	 * from the live query so it can be tested and read on its own.
	 *
	 * @param array<string,mixed> $context {
	 *     @type string    $kind   'listing'|'taxonomy'|'page'|'archive'|'other'.
	 *     @type int       $id     Record or page id.
	 *     @type \WP_Term  $term   Term for taxonomy pages.
	 *     @type string    $slug   Public page slug.
	 *     @type array     $params Query parameters in the address bar.
	 *     @type string    $url    The address being looked at.
	 * }
	 * @return array<string,mixed> index, canonical, title, description, why.
	 */
	public static function decide( array $context ): array {
		$out = array(
			'index'       => null,
			'canonical'   => '',
			'title'       => '',
			'description' => '',
			'why'         => '',
		);

		$kind   = (string) ( $context['kind'] ?? 'other' );
		$params = array_values( array_intersect( self::FILTER_PARAMS, array_keys( (array) ( $context['params'] ?? array() ) ) ) );

		if ( 'listing' === $kind ) {
			$id = (int) ( $context['id'] ?? 0 );
			$out['index']       = $id > 0 && 'publish' === get_post_status( $id );
			$out['description'] = self::describe_listing( $id );
			$out['title']       = self::title_listing( $id );
			$out['why']         = $out['index'] ? 'published property' : 'not published';
			return $out;
		}

		if ( 'project' === $kind ) {
			$id = (int) ( $context['id'] ?? 0 );
			$out['index']       = $id > 0 && 'publish' === get_post_status( $id );
			$out['description'] = self::describe_project( $id );
			$out['title']       = self::title_project( $id );
			$out['why']         = $out['index'] ? 'published project' : 'not published';
			return $out;
		}

		if ( 'taxonomy' === $kind ) {
			$term  = $context['term'] ?? null;
			$count = $term instanceof \WP_Term ? self::term_count( $term ) : 0;
			$out['index']       = $count > 0;
			$out['description'] = $term instanceof \WP_Term ? self::describe_term( $term, $count ) : '';
			$out['title']       = $term instanceof \WP_Term ? self::title_term( $term ) : '';
			$out['why']         = $count > 0 ? $count . ' properties' : 'nothing listed here yet';
			return $out;
		}

		if ( 'page' === $kind ) {
			$slug = (string) ( $context['slug'] ?? '' );

			if ( in_array( $slug, self::NOINDEX_PAGES, true ) ) {
				$out['index'] = false;
				$out['why']   = 'a tool page, not a landing page';
				return $out;
			}

			if ( $params ) {
				$out['index']     = false;
				$out['canonical'] = self::clean_url( (string) ( $context['url'] ?? '' ), $params );
				$out['why']       = 'a filtered view of ' . $slug;
				return $out;
			}

			$held = self::page_inventory( $slug );
			if ( null !== $held ) {
				$out['index'] = $held > 0;
				$out['why']   = $held > 0 ? $held . ' records' : 'nothing to show yet';
			}

			$out['description'] = self::describe_page( $slug );
			$out['title']       = self::title_page( $slug );
			return $out;
		}

		if ( 'archive' === $kind ) {
			$out['description'] = self::describe_page( 'properties' );
			$out['title']       = self::title_page( 'properties' );
		}

		return $out;
	}

	/**
	 * Describe the page the visitor is on right now.
	 *
	 * @return array<string,mixed>
	 */
	private static function context(): array {
		$args = array(
			'kind'   => 'other',
			'id'     => 0,
			'term'   => null,
			'slug'   => '',
			'params' => self::query_params(),
			'url'    => self::current_url(),
		);

		if ( is_singular( PostTypes::LISTING ) ) {
			$args['kind'] = 'listing';
			$args['id']   = (int) get_queried_object_id();
			return $args;
		}
		if ( is_singular( PostTypes::PROJECT ) ) {
			$args['kind'] = 'project';
			$args['id']   = (int) get_queried_object_id();
			return $args;
		}
		if ( is_tax( array( Taxonomies::LOCALITY, Taxonomies::AMENITY, Taxonomies::FEATURE ) ) ) {
			$args['kind'] = 'taxonomy';
			$term         = get_queried_object();
			$args['term'] = $term instanceof \WP_Term ? $term : null;
			return $args;
		}
		if ( is_post_type_archive( PostTypes::LISTING ) || is_post_type_archive( PostTypes::PROJECT ) ) {
			$args['kind'] = is_post_type_archive( PostTypes::LISTING ) ? 'archive' : 'page';
			$args['slug'] = is_post_type_archive( PostTypes::LISTING ) ? 'properties' : 'projects';
			return $args;
		}
		if ( is_page() ) {
			$page_id      = (int) get_queried_object_id();
			$args['kind'] = 'page';
			$args['id']   = $page_id;
			$args['slug'] = (string) get_post_field( 'post_name', $page_id );
		}

		return $args;
	}

	/**
	 * Our own address parameters, taken from the live query string.
	 *
	 * @return array<string,string>
	 */
	public static function query_params(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only, page is public.
		$raw = $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		// phpcs:enable
		$out = array();
		foreach ( self::FILTER_PARAMS as $key ) {
			if ( ! isset( $raw[ $key ] ) ) {
				continue;
			}
			$value = $raw[ $key ];
			if ( is_array( $value ) ) {
				$value = implode( ',', array_map( 'sanitize_text_field', array_map( 'strval', $value ) ) );
			}
			if ( '' === (string) $value ) {
				continue;
			}
			$out[ $key ] = (string) $value;
		}
		return $out;
	}

	/* ------------------------------------------------------------- printing */

	/** What the output buffer level was when we started watching. */
	private static int $head_level = 0;

	/**
	 * Start watching the head.
	 *
	 * @return void
	 */
	public static function head_start(): void {
		ob_start();
		self::$head_level = ob_get_level();
	}

	/**
	 * Hand the head back, plus anything the page forgot to say.
	 *
	 * If something else closed our buffer in between, the head is left exactly
	 * as it is — guessing at what was printed is worse than saying nothing.
	 *
	 * @return void
	 */
	public static function head_end(): void {
		if ( self::$head_level <= 0 || ob_get_level() < self::$head_level ) {
			return;
		}
		$head         = (string) ob_get_clean(); // phpcs:ignore WordPress.WP.AlternativeFunctions
		self::$head_level = 0;
		echo $head . self::head_extras( $head, self::plan() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * What still has to be added, given what is already there.
	 *
	 * Rank Math stops early when it has no description to print, and its empty
	 * answer never reaches a filter — so "fill it in when the SEO plugin says
	 * nothing" cannot be a filter alone. Reading the finished head answers the
	 * real question: did anything print one? On a page the office wrote by hand
	 * the SEO plugin's answer is found and nothing is added.
	 *
	 * @param string              $head Finished head HTML.
	 * @param array<string,mixed> $plan Decision for this page.
	 * @return string Tags to append (may be empty).
	 */
	public static function head_extras( string $head, array $plan ): string {
		$out = '';

		$has_description = (bool) preg_match( '/<meta[^>]+name=["\']description["\']/i', $head );
		if ( ! $has_description && '' !== (string) $plan['description'] ) {
			$out .= '<meta name="description" content="' . esc_attr( (string) $plan['description'] ) . '">' . "\n";
		}

		$has_canonical = (bool) preg_match( '/<link[^>]+rel=["\']canonical["\']/i', $head );
		$canonical     = '' !== (string) $plan['canonical'] ? (string) $plan['canonical'] : '';
		if ( ! $has_canonical && '' !== $canonical ) {
			$out .= '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
		}

		// A page that must not be indexed, when nobody else said so. Search
		// engines take the strictest of two robots tags, so this can only ever
		// keep a page out rather than let one in.
		$has_noindex = (bool) preg_match( '/<meta[^>]+name=["\']robots["\'][^>]*noindex/i', $head );
		if ( false === $plan['index'] && ! $has_noindex ) {
			$out .= '<meta name="robots" content="noindex, follow">' . "\n";
		}

		return $out;
	}

	/**
	 * Add noindex to the core robots tag (WordPress prints it for us).
	 *
	 * @param array<string,mixed> $robots Directives.
	 * @return array<string,mixed>
	 */
	public static function core_robots( $robots ) {
		if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) ) {
			return $robots; // The SEO plugin prints its own tag; ours goes through its filter.
		}
		$plan = self::plan();
		if ( false === $plan['index'] ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}
		return $robots;
	}

	/**
	 * Rank Math hands over its directives as a map, not a list.
	 *
	 * @param array<string,string> $robots Directives.
	 * @return array<string,string>
	 */
	public static function rank_math_robots( $robots ) {
		$robots = is_array( $robots ) ? $robots : array();
		$plan   = self::plan();
		if ( false === $plan['index'] ) {
			unset( $robots['index'] );
			$robots['noindex'] = 'noindex';
		}
		return $robots;
	}

	/**
	 * Yoast wants a plain sentence.
	 *
	 * @param string $robots Robots line.
	 * @return string
	 */
	public static function yoast_robots( $robots ) {
		$plan = self::plan();
		if ( false !== $plan['index'] ) {
			return (string) $robots;
		}
		$robots = (string) $robots;
		foreach ( array( 'index', 'noindex' ) as $word ) {
			$robots = trim( (string) preg_replace( '/\b' . $word . '\b,?/', '', $robots ), " ," );
		}
		return trim( 'noindex, follow, ' . $robots, ' ,' );
	}

	/**
	 * A filtered view points at the clean address; everything else points at
	 * itself.
	 *
	 * @param string $canonical Address from the SEO plugin.
	 * @return string
	 */
	public static function rank_math_canonical( $canonical ) {
		$plan = self::plan();
		if ( '' !== (string) $plan['canonical'] ) {
			return (string) $plan['canonical'];
		}
		return (string) $canonical;
	}

	/**
	 * The one address for the page being looked at.
	 *
	 * @param array<string,mixed> $plan Decision.
	 * @return string
	 */
	public static function canonical_now( array $plan ): string {
		if ( '' !== (string) $plan['canonical'] ) {
			return (string) $plan['canonical'];
		}
		if ( is_singular() ) {
			$id = (int) get_queried_object_id();
			return $id > 0 ? (string) get_permalink( $id ) : '';
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			if ( $term instanceof \WP_Term ) {
				$link = get_term_link( $term );
				return is_wp_error( $link ) ? '' : (string) $link;
			}
		}
		if ( is_post_type_archive( PostTypes::LISTING ) ) {
			return (string) get_post_type_archive_link( PostTypes::LISTING );
		}
		return '';
	}

	/**
	 * Strip our filter parameters, keep everything else (path, other params).
	 *
	 * @param string   $url    Address.
	 * @param string[] $params Parameters to remove.
	 * @return string
	 */
	public static function clean_url( string $url, array $params ): string {
		$url = remove_query_arg( $params, $url );
		return (string) preg_replace( '/\?$/', '', (string) $url );
	}

	/* ---------------------------------------------------------------- words */

	/**
	 * Titles from the records themselves.
	 *
	 * @param string $title Title the SEO plugin built.
	 * @return string
	 */
	public static function rank_math_title( $title ) {
		$plan = self::plan();
		if ( '' === (string) $plan['title'] || self::has_own_title() ) {
			return (string) $title;
		}
		return (string) $plan['title'];
	}

	/**
	 * Descriptions from the records themselves.
	 *
	 * @param string $description Description the SEO plugin built.
	 * @return string
	 */
	public static function rank_math_description( $description ) {
		$plan = self::plan();
		if ( '' === (string) $plan['description'] || self::has_own_description() ) {
			return (string) $description;
		}
		$built = trim( (string) $description );
		if ( '' !== $built && false === strpos( $built, '[estat_' ) ) {
			/*
			 * The SEO plugin had something of its own — unless that something is
			 * only the page's own name. "Notes" is not a description of the
			 * notes page; it is the title again, in the place Google reads.
			 */
			$heading = trim( wp_strip_all_tags( (string) get_the_title() ) );
			if ( '' === $heading || $built !== $heading ) {
				return (string) $description;
			}
		}
		return (string) $plan['description'];
	}

	/**
	 * The office, or the SEO plugin, may already have written a title for this
	 * exact page. If so, that wins.
	 *
	 * @return bool
	 */
	public static function has_own_title(): bool {
		return self::has_own( array( 'rank_math_title', '_yoast_wpseo_title' ) );
	}

	/**
	 * Same for the one-line description.
	 *
	 * @return bool
	 */
	public static function has_own_description(): bool {
		return self::has_own( array( 'rank_math_description', '_yoast_wpseo_metadesc' ) );
	}

	/**
	 * Does the record carry a hand-written SEO title or description?
	 *
	 * @param string[] $keys Meta keys to look for.
	 * @return bool
	 */
	private static function has_own( array $keys ): bool {
		$id = is_singular() ? (int) get_queried_object_id() : ( is_page() ? (int) get_queried_object_id() : 0 );
		if ( $id <= 0 ) {
			return false;
		}
		foreach ( $keys as $key ) {
			if ( '' !== trim( (string) get_post_meta( $id, $key, true ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Fallback document title parts for a site without an SEO plugin.
	 *
	 * @param array<string,string> $parts Title parts.
	 * @return array<string,string>
	 */
	public static function title_parts( $parts ) {
		if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) ) {
			return $parts;
		}
		$plan = self::plan();
		if ( '' === (string) $plan['title'] ) {
			return $parts;
		}
		$site = (string) ( $parts['site'] ?? get_bloginfo( 'name' ) );
		$own  = (string) $plan['title'];
		// Keep the site name out of our own sentence; WordPress appends it.
		$own = trim( (string) preg_replace( '/\s*[|\-–—]\s*' . preg_quote( $site, '/' ) . '\s*$/', '', $own ) );
		$parts['title'] = $own;
		return $parts;
	}

	/* ------------------------------------------------------------- listings */

	/**
	 * One line about a property, built only from answers it actually has.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function describe_listing( int $listing_id ): string {
		if ( $listing_id <= 0 ) {
			return '';
		}
		$listing = Listings::to_array( $listing_id, false );
		if ( ! $listing ) {
			return '';
		}
		$title   = (string) ( $listing['title'] ?? '' );
		$beds    = (int) ( $listing['bedrooms'] ?? 0 );
		$type    = (string) ( $listing['property_type'] ?? '' );
		$offer   = (string) ( $listing['offer'] ?? '' );
		$city    = (string) Settings::get( 'city', '' );
		$areas   = (array) ( $listing['locality'] ?? array() );
		$area    = $areas ? (string) $areas[0] : '';
		$size    = (float) ( $listing['area_sqft'] ?? 0 );
		$symbol  = (string) Settings::get( 'currency_symbol', '₹' );
		$price   = isset( $listing['price'] ) && null !== $listing['price'] ? (float) $listing['price'] : 0.0;
		if ( $price <= 0 && isset( $listing['rent'] ) && null !== $listing['rent'] ) {
			$price = (float) $listing['rent']; // A rental's figure lives in the rent field.
		}

		$head = array();
		if ( $beds > 0 ) {
			/* translators: %s: number of bedrooms */
			$head[] = sprintf( _n( '%s BHK', '%s BHK', $beds, 'estat-os' ), number_format_i18n( $beds ) );
		}
		if ( '' !== $type ) {
			$head[] = strtolower( $type );
		}
		$opening = trim( implode( ' ', $head ) );
		$where   = $area;
		if ( '' !== $city && ( '' === $where || false === stripos( $where, $city ) ) ) {
			$where = '' !== $where ? $where . ', ' . $city : $city;
		}

		$offer_words = array(
			'rent'  => __( 'for rent', 'estat-os' ),
			'lease' => __( 'for lease', 'estat-os' ),
			'sale'  => __( 'for sale', 'estat-os' ),
		);
		$for = (string) ( $offer_words[ $offer ] ?? '' );

		// A sentence needs a shape to it. With nothing but an area name the
		// honest line is the record's own name, not "in Sector 48." on its own.
		$sentence = '';
		if ( '' !== $opening && '' !== $where ) {
			/* translators: 1: "3 BHK apartment", 2: "for sale", 3: "Sector 48, Gurugram" */
			$sentence = trim( sprintf( __( '%1$s %2$s in %3$s', 'estat-os' ), $opening, $for, $where ) );
			$sentence = trim( (string) preg_replace( '/\s+/', ' ', $sentence ) ) . '.';
		}
		if ( '' === $sentence && '' !== $title ) {
			$sentence = trim( (string) preg_replace( '/\s+/', ' ', $title ) ) . '.';
		}
		if ( '' === $sentence ) {
			return '';
		}

		$facts = array();
		if ( $size > 0 ) {
			$facts[] = Format::area( $size, (string) ( $listing['area_unit'] ?? 'sqft' ) );
		}
		if ( $price > 0 ) {
			$money = $symbol . Format::number_indian( $price );
			if ( in_array( $offer, array( 'rent', 'lease' ), true ) ) {
				/* translators: %s: price */
				$money = sprintf( __( '%s a month', 'estat-os' ), $money );
			}
			$facts[] = $money;
		} else {
			$facts[] = __( 'price on request', 'estat-os' );
		}

		$tail = $facts ? ' ' . implode( ' · ', $facts ) . '.' : '';

		/* translators: what a visitor gets on the property page */
		$promise = ' ' . __( 'Photos, floor plan and the full details.', 'estat-os' );
		return self::fit( $sentence . $tail . $promise, 158 );
	}

	/**
	 * Title for a property page: the record's own name, plus the locality when
	 * the name does not already carry it.
	 *
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function title_listing( int $listing_id ): string {
		if ( $listing_id <= 0 ) {
			return '';
		}
		$post = get_post( $listing_id );
		if ( ! $post ) {
			return '';
		}
		$title   = (string) $post->post_title;
		$listing = Listings::to_array( $listing_id, false );
		$areas   = (array) ( $listing['locality'] ?? array() );
		$area    = $areas ? (string) $areas[0] : '';
		if ( '' === $area || false !== stripos( $title, $area ) ) {
			return $title;
		}
		return $title . ' — ' . $area;
	}

	/**
	 * What a project page is about, in one line a search engine can print.
	 *
	 * Built from the record and nothing else: a fact the office never entered
	 * is a fact the line does not contain. "Apartment + Penthouse project by
	 * DLF in Golf Course Road, Gurugram. 4/5 BHK 7,350–16,000 sq ft · ₹40 – 100
	 * Cr. Homes still available."
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	public static function describe_project( int $project_id ): string {
		if ( $project_id <= 0 ) {
			return '';
		}
		$project = Projects::to_array( $project_id );
		if ( ! $project ) {
			return '';
		}

		$name      = (string) ( $project['title'] ?? '' );
		$type      = (string) ( $project['project_type'] ?? '' );
		$developer = (string) ( $project['developer'] ?? '' );
		$category  = (string) ( $project['category'] ?? '' );
		$city      = (string) Settings::get( 'city', '' );
		$areas     = array_filter( (array) ( $project['locality'] ?? array() ) );
		$area      = $areas ? (string) reset( $areas ) : '';
		$address   = (string) ( $project['address'] ?? '' );

		$where = $area;
		if ( '' !== $city && ( '' === $where || false === stripos( $where, $city ) ) ) {
			$where = '' !== $where ? $where . ', ' . $city : $city;
		}
		if ( '' === $where ) {
			$where = $address;
		}

		$head = array();
		if ( '' !== $type ) {
			$head[] = $type;
		} elseif ( '' !== $category ) {
			$head[] = Vocabulary::label( 'project_categories', $category );
		}

		$sentence = '';
		if ( '' !== $name && '' !== $where ) {
			if ( $head ) {
				/* translators: 1: project name, 2: what kind of project it is, 3: the area it is in */
				$sentence = sprintf( __( '%1$s is a %2$s project in %3$s', 'estat-os' ), $name, implode( ' ', $head ), $where );
			} else {
				/* translators: 1: project name, 2: the area it is in */
				$sentence = sprintf( __( '%1$s is in %2$s', 'estat-os' ), $name, $where );
			}
		} elseif ( $head && '' !== $where ) {
			/* translators: 1: what kind of project it is, 2: the area it is in */
			$sentence = sprintf( __( '%1$s project in %2$s', 'estat-os' ), implode( ' ', $head ), $where );
		} elseif ( '' !== $name ) {
			$sentence = $name;
		}

		if ( '' !== $developer ) {
			/* translators: %s: builder or developer */
			$sentence = trim( $sentence . ' ' . sprintf( __( 'by %s.', 'estat-os' ), $developer ) );
		} elseif ( '' !== $sentence ) {
			$sentence .= '.';
		}

		if ( '' === $sentence ) {
			return '';
		}

		$facts = array();
		if ( ! empty( $project['unit_types'] ) ) {
			$facts[] = (string) $project['unit_types'];
		}
		if ( ! empty( $project['price_display'] ) ) {
			$facts[] = (string) $project['price_display'];
		}
		if ( ! empty( $project['possession_date'] ) ) {
			/* translators: %s: a month and a year, or just a year */
			$facts[] = sprintf( __( 'possession %s', 'estat-os' ), Format::month_year( (string) $project['possession_date'] ) );
		}

		$tail = $facts ? ' ' . implode( ' · ', $facts ) . '.' : '';

		/* translators: what a visitor gets on the project page */
		$promise = ' ' . __( 'Photos, floor plan and the full details.', 'estat-os' );

		return self::fit( $sentence . $tail . $promise, 158 );
	}

	/**
	 * Title for a project page: its own name, plus the area when the name does
	 * not already carry it.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	public static function title_project( int $project_id ): string {
		if ( $project_id <= 0 ) {
			return '';
		}
		$post = get_post( $project_id );
		if ( ! $post ) {
			return '';
		}
		$title = (string) $post->post_title;
		$areas = (array) ( Projects::to_array( $project_id )['locality'] ?? array() );
		$area  = $areas ? (string) reset( $areas ) : '';
		if ( '' === $area || false !== stripos( $title, $area ) ) {
			return $title;
		}
		return $title . ' — ' . $area;
	}

	/* ------------------------------------------------------------ taxonomies */

	/**
	 * How many published properties sit in a term.
	 *
	 * @param \WP_Term $term Term.
	 * @return int
	 */
	public static function term_count( \WP_Term $term ): int {
		$query = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => $term->taxonomy,
						'field'    => 'term_id',
						'terms'    => (int) $term->term_id,
					),
				),
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * One line about a locality, amenity or feature page.
	 *
	 * @param \WP_Term $term  Term.
	 * @param int      $count Properties listed.
	 * @return string
	 */
	public static function describe_term( \WP_Term $term, int $count ): string {
		if ( $count <= 0 ) {
			return '';
		}
		$city = (string) Settings::get( 'city', '' );
		$kind = array(
			Taxonomies::LOCALITY => __( 'properties in', 'estat-os' ),
			Taxonomies::AMENITY  => __( 'properties with', 'estat-os' ),
			Taxonomies::FEATURE  => __( 'properties with', 'estat-os' ),
		);
		$words = (string) ( $kind[ $term->taxonomy ] ?? __( 'properties in', 'estat-os' ) );

		/* translators: 1: number of properties, 2: "properties in", 3: "Sohna Road", 4: city */
		$line = sprintf( _n( '%1$d %2$s %3$s', '%1$d %2$s %3$s', $count, 'estat-os' ), $count, $words, $term->name );
		if ( '' !== $city && false === stripos( $term->name, $city ) && Taxonomies::LOCALITY === $term->taxonomy ) {
			$line .= ', ' . $city;
		}

		$range = self::term_price_range( $term );
		$tail  = '';
		if ( '' !== $range ) {
			/* translators: %s: a price or a price range */
			$tail = ' ' . sprintf( __( 'From %s.', 'estat-os' ), $range );
		}
		return self::fit( $line . '.' . $tail . ' ' . __( 'Photos and full details on every one.', 'estat-os' ), 158 );
	}

	/**
	 * Title for a taxonomy page.
	 *
	 * @param \WP_Term $term Term.
	 * @return string
	 */
	public static function title_term( \WP_Term $term ): string {
		$labels = array(
			Taxonomies::LOCALITY => __( 'Properties in %s', 'estat-os' ),
			Taxonomies::AMENITY  => __( 'Properties with %s', 'estat-os' ),
			Taxonomies::FEATURE  => __( 'Properties with %s', 'estat-os' ),
		);
		$pattern = (string) ( $labels[ $term->taxonomy ] ?? __( 'Properties in %s', 'estat-os' ) );
		return (string) sprintf( $pattern, $term->name );
	}

	/**
	 * The cheapest property in a term, said the way the website says prices.
	 *
	 * @param \WP_Term $term Term.
	 * @return string
	 */
	private static function term_price_range( \WP_Term $term ): string {
		$query = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => '_estat_price', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'        => 'meta_value_num',
				'order'          => 'ASC',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => $term->taxonomy,
						'field'    => 'term_id',
						'terms'    => (int) $term->term_id,
					),
				),
			)
		);
		if ( ! $query->posts ) {
			return '';
		}
		$price = (float) get_post_meta( (int) $query->posts[0], '_estat_price', true );
		if ( $price <= 0 ) {
			return '';
		}
		$symbol = (string) Settings::get( 'currency_symbol', '₹' );
		return $symbol . Format::number_indian( $price );
	}

	/* ---------------------------------------------------------------- pages */

	/**
	 * One line about one of our public pages.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	public static function describe_page( string $slug ): string {
		if ( 'properties' === $slug || '' === $slug ) {
			$counts = self::listing_counts();
			if ( $counts['total'] <= 0 ) {
				return '';
			}
			$city  = (string) Settings::get( 'city', '' );
			$parts = array();
			if ( $counts['sale'] > 0 ) {
				/* translators: %d: number of properties for sale */
				$parts[] = sprintf( _n( '%d for sale', '%d for sale', $counts['sale'], 'estat-os' ), $counts['sale'] );
			}
			if ( $counts['rent'] > 0 ) {
				/* translators: %d: number of rental properties */
				$parts[] = sprintf( _n( '%d to rent', '%d to rent', $counts['rent'], 'estat-os' ), $counts['rent'] );
			}
			$split = $parts ? ' (' . implode( ', ', $parts ) . ')' : '';
			/* translators: 1: number of properties, 2: city, 3: "(12 for sale, 8 to rent)" */
			$line = sprintf( __( '%1$d properties in %2$s%3$s', 'estat-os' ), $counts['total'], $city, $split );
			/* translators: what the properties page holds */
			$line  = trim( $line . '. ' . __( 'Flats, builder floors, villas and plots, with photos and the full details of each.', 'estat-os' ) );
			return self::fit( $line, 158 );
		}

		$map = array(
			'localities' => __( 'Every area we work in, and how many properties are in each one.', 'estat-os' ),
			'amenities'  => __( 'The amenities our properties have, with a page for each.', 'estat-os' ),
			'features'   => __( 'The features our properties have, with a page for each.', 'estat-os' ),
			'team'       => __( 'The people in our office, with their phone numbers.', 'estat-os' ),
			'projects'   => __( 'The societies and new buildings we work with.', 'estat-os' ),
			'notes'      => __( 'Short, plain pieces on buying, selling and renting here, written by the people who sit in the office.', 'estat-os' ),
			'blog'       => __( 'Short, plain pieces on buying, selling and renting here, written by the people who sit in the office.', 'estat-os' ),
		);
		return (string) ( $map[ $slug ] ?? '' );
	}

	/**
	 * Title for one of our public pages.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	public static function title_page( string $slug ): string {
		$city = (string) Settings::get( 'city', '' );
		if ( 'properties' === $slug || '' === $slug ) {
			return '' !== $city
				/* translators: %s: city name */
				? sprintf( __( 'Properties for sale and rent in %s', 'estat-os' ), $city )
				: __( 'Properties for sale and rent', 'estat-os' );
		}
		$map = array(
			'localities' => __( 'Areas we work in', 'estat-os' ),
			'amenities'  => __( 'Amenities', 'estat-os' ),
			'features'   => __( 'Features', 'estat-os' ),
			'projects'   => __( 'Societies and projects', 'estat-os' ),
			'team'       => __( 'Our team', 'estat-os' ),
		);
		return (string) ( $map[ $slug ] ?? '' );
	}

	/**
	 * How many published properties there are, split by what they are for.
	 *
	 * @return array<string,int>
	 */
	public static function listing_counts(): array {
		$counts = wp_count_posts( PostTypes::LISTING );
		$total  = (int) ( $counts->publish ?? 0 );

		$sale = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'OR',
					array(
						'key'     => '_estat_offer',
						'value'   => 'sale',
						'compare' => '=',
					),
					array(
						'key'     => '_estat_offer',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
		$rent = new \WP_Query(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'key'     => '_estat_offer',
					'value'   => array( 'rent', 'lease' ),
					'compare' => 'IN',
				),
			)
		);

		return array(
			'total' => $total,
			'sale'  => (int) $sale->found_posts,
			'rent'  => (int) $rent->found_posts,
		);
	}

	/**
	 * Does one of our "only while it holds something" pages hold anything?
	 * Answers null for a page this question does not apply to.
	 *
	 * @param string $slug Page slug.
	 * @return int|null
	 */
	public static function page_inventory( string $slug ): ?int {
		if ( ! in_array( $slug, self::INVENTORY_PAGES, true ) ) {
			return null;
		}

		switch ( $slug ) {
			case 'properties':
				return self::listing_counts()['total'];
			case 'team':
				return (int) ( wp_count_posts( PostTypes::AGENT )->publish ?? 0 );
			case 'projects':
			case 'projects-by-stage':
				// Only what a visitor can actually see counts as something to show.
				return (int) ( wp_count_posts( PostTypes::PROJECT )->publish ?? 0 );
			case 'localities':
			case 'locality-map':
				return self::terms_with_listings( Taxonomies::LOCALITY );
			case 'amenities':
				return self::terms_with_listings( Taxonomies::AMENITY );
			case 'features':
				return self::terms_with_listings( Taxonomies::FEATURE );
		}
		return null;
	}

	/**
	 * How many terms of a taxonomy actually carry at least one published property.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return int
	 */
	public static function terms_with_listings( string $taxonomy ): int {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'fields'     => 'ids',
			)
		);
		return is_wp_error( $terms ) ? 0 : count( $terms );
	}

	/* --------------------------------------------------------------- helpers */

	/**
	 * The address being looked at.
	 *
	 * @return string
	 */
	private static function current_url(): string {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $path ) {
			return home_url( '/' );
		}
		return home_url( $path );
	}

	/**
	 * Keep a description inside what a search engine shows.
	 *
	 * @param string $text Sentence.
	 * @param int    $limit Soft limit.
	 * @return string
	 */
	public static function fit( string $text, int $limit ): string {
		$text = trim( (string) preg_replace( '/\s+/', ' ', wp_strip_all_tags( $text ) ) );
		if ( strlen( $text ) <= $limit ) {
			return $text;
		}
		$cut = substr( $text, 0, $limit );
		$end = strrpos( $cut, ' ' );
		if ( false !== $end ) {
			$cut = substr( $cut, 0, $end );
		}
		return rtrim( $cut, ' .,' ) . '…';
	}
}
