<?php
/**
 * The WhatsApp button: one tap, and the visitor is already talking about the
 * right property.
 *
 * Why it is built this way: on a phone, "fill the form and wait for a call
 * back" loses to "send a message now". A WhatsApp button that says nothing
 * makes the office ask "which property?", so the message travels with the
 * property's name and link already written.
 *
 * The button is a plain link — no JavaScript is needed for it to work — and a
 * small, quiet request logs the tap as an enquiry so the office can see how
 * many people chose this door instead of the form.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Audit\AuditLog;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;

defined( 'ABSPATH' ) || exit;

final class WhatsApp {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_shortcode( 'estat_whatsapp', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_nopriv_estat_whatsapp_tap', array( __CLASS__, 'tap' ) );
		add_action( 'wp_ajax_estat_whatsapp_tap', array( __CLASS__, 'tap' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * A tiny script, and only on a page that has the button.
	 *
	 * @return void
	 */
	public static function enqueue(): void {
		if ( ! self::enabled() ) {
			return;
		}
		wp_register_script( 'estat-whatsapp', ESTAT_URL . 'assets/js/whatsapp.js', array(), ESTAT_VERSION, true );
		wp_localize_script(
			'estat-whatsapp',
			'estatWhatsApp',
			array(
				'endpoint' => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
				'nonce'    => wp_create_nonce( 'estat_whatsapp' ),
			)
		);
	}

	/**
	 * Is the button switched on, and do we have somewhere to send it?
	 *
	 * @return bool
	 */
	public static function enabled(): bool {
		if ( ! (bool) Settings::get( 'whatsapp_cta_enabled', true ) ) {
			return false;
		}
		return '' !== self::number();
	}

	/**
	 * The office number, digits only, as wa.me wants it.
	 *
	 * @return string
	 */
	public static function number(): string {
		$raw = (string) Settings::get( 'whatsapp', '' );
		if ( '' === trim( $raw ) ) {
			$raw = (string) Settings::get( 'phone', '' );
		}
		$digits = preg_replace( '/\D+/', '', $raw );
		return is_string( $digits ) ? $digits : '';
	}

	/**
	 * The message that arrives in the office's WhatsApp.
	 *
	 * @param int $listing_id Property the visitor is looking at, or 0.
	 * @return string
	 */
	public static function message( int $listing_id = 0 ): string {
		$custom = trim( (string) Settings::get( 'whatsapp_cta_text', '' ) );
		if ( '' !== $custom ) {
			return $custom;
		}
		if ( $listing_id > 0 ) {
			$title = (string) get_the_title( $listing_id );
			$link  = (string) get_permalink( $listing_id );
			$price = (string) get_post_meta( $listing_id, '_estat_price', true );
			$rent  = (string) get_post_meta( $listing_id, '_estat_rent', true );
			$money = '' !== $rent && '' === $price ? Format::money( (float) $rent ) : ( '' !== $price ? Format::money( (float) $price ) : '' );

			return trim(
				sprintf(
					/* translators: 1: property name, 2: price or blank, 3: link */
					__( 'Hello, I would like to know more about %1$s%2$s — %3$s', 'estat-os' ),
					$title,
					'' !== $money ? ' (' . $money . ')' : '',
					$link
				)
			);
		}
		return __( 'Hello, I would like to enquire about a property.', 'estat-os' );
	}

	/**
	 * The link itself.
	 *
	 * @param int    $listing_id Property, or 0.
	 * @param string $label      Words on the button.
	 * @return string Empty when the button is off.
	 */
	public static function button( int $listing_id = 0, string $label = '' ): string {
		if ( ! self::enabled() ) {
			return '';
		}
		if ( '' === $label ) {
			$label = $listing_id > 0
				? __( 'Ask about this property on WhatsApp', 'estat-os' )
				: __( 'Message us on WhatsApp', 'estat-os' );
		}

		wp_enqueue_script( 'estat-whatsapp' );

		$url = 'https://wa.me/' . self::number() . '?text=' . rawurlencode( self::message( $listing_id ) );

		return sprintf(
			'<a class="estat-whatsapp" href="%1$s" target="_blank" rel="nofollow noopener" data-estat-whatsapp="%2$d">' .
			'<span class="estat-whatsapp-mark" aria-hidden="true">%3$s</span><span class="estat-whatsapp-text">%4$s</span></a>',
			esc_url( $url ),
			(int) $listing_id,
			self::icon(),
			esc_html( $label )
		);
	}

	/**
	 * The WhatsApp glyph, inline so no outside file is needed.
	 *
	 * @return string
	 */
	private static function icon(): string {
		return '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true" focusable="false">'
			. '<path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.27-.47-2.42-1.49-.9-.8-1.5-1.78-1.67-2.08-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.65-1.57-.89-2.15-.23-.56-.47-.49-.65-.5h-.55c-.2 0-.5.07-.77.37-.27.3-1.02 1-1.02 2.42 0 1.42 1.04 2.8 1.19 2.99.15.2 2.05 3.13 4.98 4.39.69.3 1.24.48 1.66.61.7.22 1.33.19 1.83.12.56-.08 1.72-.7 1.97-1.38.24-.68.24-1.26.17-1.38-.07-.12-.27-.2-.57-.35ZM12.05 21.5h-.01a9.4 9.4 0 0 1-4.79-1.31l-.34-.2-3.56.93.95-3.47-.22-.36a9.38 9.38 0 0 1-1.44-5.01c0-5.19 4.23-9.41 9.42-9.41 2.51 0 4.88.98 6.65 2.76a9.34 9.34 0 0 1 2.76 6.66c0 5.19-4.23 9.41-9.42 9.41Zm8.02-17.43A11.32 11.32 0 0 0 12.05.75C5.8.75.72 5.83.72 12.07c0 1.99.52 3.94 1.51 5.66L.63 23.25l5.65-1.48a11.31 11.31 0 0 0 5.77 1.58h.01c6.24 0 11.32-5.08 11.32-11.32 0-3.03-1.18-5.87-3.31-8Z"/></svg>';
	}

	/**
	 * The shortcode the office can drop into Elementor (or any page).
	 *
	 * @param array<string,mixed> $atts Attributes.
	 * @return string
	 */
	public static function shortcode( $atts ): string {
		$atts = shortcode_atts(
			array(
				'id'    => 0,
				'label' => '',
			),
			(array) $atts,
			'estat_whatsapp'
		);

		$id = (int) $atts['id'];
		if ( $id <= 0 && is_singular( array( 'estat_listing', 'estat_project' ) ) ) {
			$id = (int) get_the_ID();
		}

		return self::button( $id, (string) $atts['label'] );
	}

	/**
	 * Note that somebody tapped, without inventing an enquiry.
	 *
	 * The visitor has already left for WhatsApp by the time this runs, so it
	 * answers in one word and never blocks. A tap within the last half hour on
	 * the same property from the same visitor is the same visit, not a new one
	 * — the office asked for four emails, not four hundred.
	 *
	 * @return void
	 */
	public static function tap(): void {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['nonce'] ) ? '' : $_POST['nonce'] ) ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'estat_whatsapp' ) ) {
			wp_send_json_success( array( 'logged' => false ) );
		}

		$listing_id = isset( $_POST['id'] ) ? absint( wp_unslash( is_array( $_POST['id'] ) ? 0 : $_POST['id'] ) ) : 0;
		if ( $listing_id <= 0 ) {
			wp_send_json_success( array( 'logged' => false ) );
		}

		$recent = get_transient( 'estat_wa_tap_' . md5( self::visitor() . '|' . $listing_id ) );
		if ( false !== $recent ) {
			wp_send_json_success( array( 'logged' => false, 'reason' => 'same visit' ) );
		}
		set_transient( 'estat_wa_tap_' . md5( self::visitor() . '|' . $listing_id ), 1, 30 * MINUTE_IN_SECONDS );

		/*
		 * A tap is counted, not turned into a fake enquiry.
		 *
		 * The visitor has not told us their name or number — they went to
		 * WhatsApp to do that. Writing an enquiry row with an empty name would
		 * put a stranger with no contact details in the office's inbox and make
		 * the count of real enquiries wrong. What the office actually wants to
		 * know is "how many people chose this door", so that is what is kept.
		 */
		$taps = (int) get_post_meta( $listing_id, '_estat_whatsapp_taps', true );
		update_post_meta( $listing_id, '_estat_whatsapp_taps', $taps + 1 );
		update_post_meta( $listing_id, '_estat_whatsapp_last', current_time( 'mysql', true ) );

		AuditLog::record( 'whatsapp.tap', 'listing', $listing_id, array( 'taps' => $taps + 1 ) );

		/**
		 * Let anything else react to a WhatsApp tap.
		 *
		 * @param int $listing_id Property.
		 */
		do_action( 'estat_whatsapp_tap', $listing_id );

		wp_send_json_success( array( 'logged' => true ) );
	}

	/**
	 * A visitor fingerprint that is not a tracker: hashed, salted, thrown away
	 * the moment the half hour is over.
	 *
	 * @return string
	 */
	private static function visitor(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
		return wp_hash( $ip . '|' . (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) );
	}
}
