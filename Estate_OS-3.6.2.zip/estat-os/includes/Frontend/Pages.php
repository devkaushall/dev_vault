<?php
/**
 * Public Pages without Elementor — F12 the office Edition
 *
 * Creates real WP pages with shortcodes so the site works out of the box
 * with any theme, no Elementor, no page builder needed.
 *
 * - 14 public pages: properties, search, projects, projects-by-stage,
 *   team, localities, amenities, features, favorites, compare, emi,
 *   alerts, locality-map, office
 * - Auto-create on activation, manual recreate via Tools
 * - Settings toggle: enable/disable auto-create
 * - Theme compatibility: template_include fallback to plugin's page-public.php
 *   if theme has no page.php (rare) or if page is ours and theme is block theme
 * - URLs: uses normal page permalinks, so SEO friendly
 * - Shortcodes are the same as [estat_properties] etc, so Elementor widgets
 *   and shortcodes never drift
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

final class Pages {

	/**
	 * Option key storing created page IDs: slug => ID
	 */
	public const OPTION = 'estat_public_pages';

	/**
	 * All public pages the plugin can create.
	 *
	 * @var array<string,array{title:string,shortcode:string,desc:string,icon:string}>
	 */
	public const PAGES = array(
		'properties' => array(
			'title'     => 'Properties',
			'shortcode' => '[estat_properties per_page="12"]',
			'desc'      => 'All properties directory with pagination',
			'icon'      => 'home',
		),
		'search' => array(
			'title'     => 'Search Properties',
			'shortcode' => '[estat_search]',
			'desc'      => 'Search form with filters',
			'icon'      => 'search',
		),
		'projects' => array(
			'title'     => 'Projects',
			'shortcode' => '[estat_projects per_page="12"]',
			'desc'      => 'All projects grid with stage and progress',
			'icon'      => 'buildings',
		),
		'projects-by-stage' => array(
			'title'     => 'Projects by Stage',
			'shortcode' => '[estat_projects_by_stage]',
			'desc'      => 'Projects grouped by stage',
			'icon'      => 'chart',
		),
		'team' => array(
			'title'     => 'Our Team',
			'shortcode' => '[estat_team limit="24"]',
			'desc'      => 'Team directory',
			'icon'      => 'team',
		),
		'localities' => array(
			'title'     => 'Localities',
			'shortcode' => '[estat_localities]',
			'desc'      => 'Locality pages with counts',
			'icon'      => 'map-pin',
		),
		'locality-map' => array(
			'title'     => 'Locality Map',
			'shortcode' => '[estat_locality_map]',
			'desc'      => 'Explore by locality',
			'icon'      => 'compass',
		),
		'amenities' => array(
			'title'     => 'Amenities',
			'shortcode' => '[estat_amenities]',
			'desc'      => 'Amenity pages with counts',
			'icon'      => 'star',
		),
		'features' => array(
			'title'     => 'Features',
			'shortcode' => '[estat_features]',
			'desc'      => 'Feature pages with counts',
			'icon'      => 'sparkle',
		),
		'favorites' => array(
			'title'     => 'Saved Properties',
			'shortcode' => '[estat_favorites]',
			'desc'      => 'Saved properties',
			'icon'      => 'heart',
		),
		'compare' => array(
			'title'     => 'Compare Properties',
			'shortcode' => '[estat_compare]',
			'desc'      => 'Compare properties side by side',
			'icon'      => 'compare',
		),
		'emi' => array(
			'title'     => 'EMI Calculator',
			'shortcode' => '[estat_emi price="5000000"]',
			'desc'      => 'EMI calculator',
			'icon'      => 'calculator',
		),
		'alerts' => array(
			'title'     => 'Search Alerts',
			'shortcode' => '[estat_alerts]',
			'desc'      => 'Search alerts',
			'icon'      => 'bell',
		),
	);

	/**
	 * Pages an older version made that no longer have a job.
	 *
	 * Written out by hand rather than guessed: a page is only ever put aside if
	 * it is on this list and the plugin's own signature is on it. Anything else
	 * the office has is left exactly as it is.
	 *
	 * @var array<int,string>
	 */
	public const RETIRED = array( 'office', 'insights', 'agents' );

	/**
	 * Page names and one-line descriptions, in the office's language.
	 *
	 * The structure (slugs, shortcodes, icons) lives in PAGES. The words live
	 * here, so the office language setting reaches the setup screen, the page
	 * list on the website and the public page header.
	 *
	 * @return array<string,array{0:string,1:string}> slug => [title, desc].
	 */
	public static function wording(): array {
		return array(
			'properties'         => array( __( 'Properties', 'estat-os' ), __( 'All the properties in one place.', 'estat-os' ) ),
			'search'             => array( __( 'Search Properties', 'estat-os' ), __( 'Search by area, budget and size.', 'estat-os' ) ),
			'projects'           => array( __( 'Projects', 'estat-os' ), __( 'New buildings and societies we work with.', 'estat-os' ) ),
			'projects-by-stage'  => array( __( 'Projects by Stage', 'estat-os' ), __( 'Grouped by how far the work has reached.', 'estat-os' ) ),
			'team'               => array( __( 'Our team', 'estat-os' ), __( 'The people in our office, with their numbers.', 'estat-os' ) ),
			'localities'         => array( __( 'Localities', 'estat-os' ), __( 'Areas we work in, and how many properties are there.', 'estat-os' ) ),
			'locality-map'       => array( __( 'Locality Map', 'estat-os' ), __( 'Explore by locality', 'estat-os' ) ),
			'amenities'          => array( __( 'Amenities', 'estat-os' ), __( 'Amenities you can filter by.', 'estat-os' ) ),
			'features'           => array( __( 'Features', 'estat-os' ), __( 'Features you can filter by.', 'estat-os' ) ),
			'favorites'          => array( __( 'Saved Properties', 'estat-os' ), __( 'Saved properties', 'estat-os' ) ),
			'compare'            => array( __( 'Compare Properties', 'estat-os' ), __( 'Compare properties side by side', 'estat-os' ) ),
			'emi'                => array( __( 'EMI Calculator', 'estat-os' ), __( 'EMI calculator', 'estat-os' ) ),
			'alerts'             => array( __( 'Search Alerts', 'estat-os' ), __( 'Search alerts', 'estat-os' ) ),
		);
	}

	/**
	 * The line a visitor reads at the top of one of our pages.
	 *
	 * Older versions of the plugin wrote the office's own note ("Team directory
	 * — agents with phone, WhatsApp, listings count", "...year-wise
	 * amortization (F10)") straight into the page. Those notes are for the
	 * office, not for a buyer, and a search engine was printing them under the
	 * site in Google. Every page now carries one plain sentence for the person
	 * reading it, and this is where those sentences live.
	 *
	 * @param string $slug Page slug.
	 * @return string Empty when we have nothing worth saying.
	 */
	public static function intro( string $slug ): string {
		$map = array(
			'properties'        => __( 'Every home, floor, plot and shop we are handling at the moment — photos, size, price and the full details on each page.', 'estat-os' ),
			'search'            => __( 'Tell us the sector, the size and the budget, and we will show only the ones that fit.', 'estat-os' ),
			'projects'          => __( 'The societies and new buildings we work with, and what is still open in each one.', 'estat-os' ),
			'projects-by-stage' => __( 'What is ready to move into, what is still being built, and what has just been announced.', 'estat-os' ),
			'team'              => __( 'The people in this office, with their phone numbers — the same people you meet at the property and at the registry.', 'estat-os' ),
			'localities'        => __( 'Every area we work in, and how many properties are open in each one.', 'estat-os' ),
			'locality-map'      => __( 'Pick an area and see what we have there.', 'estat-os' ),
			'amenities'         => __( 'What our properties come with — a page for each, and the properties that have it.', 'estat-os' ),
			'features'          => __( 'The things that make one property better than another, with the properties that have them.', 'estat-os' ),
			'favorites'         => __( 'The ones you liked, kept on this phone or computer. Nothing to log in to.', 'estat-os' ),
			'compare'           => __( 'Put two or three side by side and compare size, price and area at a glance.', 'estat-os' ),
			'emi'               => __( 'Work out the monthly payment before you visit. Change the down payment and watch it move.', 'estat-os' ),
			'alerts'            => __( 'Tell us what you are looking for and we will email you the moment a match goes live.', 'estat-os' ),
		);
		return (string) ( $map[ $slug ] ?? '' );
	}

	/**
	 * Tidy the pages an older version of the plugin made.
	 *
	 * Two things went wrong in 3.0.x and are still sitting on the website:
	 *
	 *   1. Each page was created with the office's internal note printed on it
	 *      ("Team directory — agents with phone...", "Advanced EMI — ... (F10)").
	 *      Google was reading those lines and showing them under the site.
	 *   2. A page called "office" was made that no longer has any purpose.
	 *
	 * This walks only the pages the plugin itself created and signed
	 * (`_estat_public_page`), swaps the note for the visitor's line, and puts
	 * aside any page that is no longer part of the set. A page the office has
	 * written itself is never touched.
	 *
	 * @return array{checked:int,tidied:int,aside:int,names:array<int,string>}
	 */
	public static function tidy_old_pages(): array {
		$report = array(
			'checked' => 0,
			'tidied'  => 0,
			'aside'   => 0,
			'names'   => array(),
		);

		$ids = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page'   => 200,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_key'         => '_estat_public_page',
			)
		);
		if ( ! is_array( $ids ) ) {
			return $report;
		}

		$all          = self::all();
		$front_page   = (int) get_option( 'page_on_front' );

		foreach ( $ids as $id ) {
			$id   = (int) $id;
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$report['checked']++;
			$slug = (string) get_post_meta( $id, '_estat_public_page', true );

			// A page from an older list that no longer has a job.
			if ( '' === $slug || ! isset( $all[ $slug ] ) ) {
				if ( ! in_array( $slug, self::RETIRED, true ) ) {
					continue; // Not ours to decide about.
				}
				if ( 'publish' === $post->post_status && $front_page !== $id ) {
					wp_update_post(
						array(
							'ID'          => $id,
							'post_status' => 'draft',
						)
					);
					$report['aside']++;
					$report['names'][] = (string) $post->post_title;
				}
				continue;
			}

			$content = (string) $post->post_content;
			$note    = isset( self::PAGES[ $slug ]['desc'] ) ? (string) self::PAGES[ $slug ]['desc'] : '';
			$intro   = self::intro( $slug );
			$short   = isset( $all[ $slug ]['shortcode'] ) ? (string) $all[ $slug ]['shortcode'] : '';
			$fresh   = $content;

			// The note, wrapped in a paragraph or standing on its own.
			if ( '' !== $note ) {
				foreach ( array(
					'<p class="wp-block-paragraph">' . $note . '</p>',
					'<p>' . $note . '</p>',
					$note,
				) as $needle ) {
					if ( false !== strpos( $content, $needle ) ) {
						$fresh = str_replace( $needle, '', $content );
						break;
					}
				}
			}

			if ( $fresh !== $content ) {
				$report['tidied']++;
			} elseif ( trim( $content ) === trim( $short ) && '' !== $intro ) {
				// Nothing but the shortcode: the page has no words for a reader.
				$report['tidied']++;
			} else {
				continue; // The office has written this page; leave it alone.
			}

			$body = trim( (string) preg_replace( '/\n{3,}/', "\n\n", $fresh ) );
			if ( '' !== $intro && false === strpos( $body, $intro ) ) {
				$body = $intro . "\n\n" . $body;
			}
			$body = trim( $body );

			wp_update_post(
				array(
					'ID'           => $id,
					'post_content' => $body,
				)
			);
			update_post_meta( $id, '_estat_public_page_version', ESTAT_VERSION );
		}

		return $report;
	}

	/**
	 * PAGES with its words put through the office language.
	 *
	 * @return array<string,array{title:string,shortcode:string,desc:string,icon:string}>
	 */
	private static function translated_pages(): array {
		$pages = self::PAGES;
		foreach ( self::wording() as $slug => $pair ) {
			if ( ! isset( $pages[ $slug ] ) ) {
				continue;
			}
			$pages[ $slug ]['title'] = $pair[0];
			$pages[ $slug ]['desc']  = $pair[1];
		}
		return $pages;
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'init', array( __CLASS__, 'maybe_create_on_init' ), 20 );
		add_filter( 'template_include', array( __CLASS__, 'template_fallback' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register settings UI hint — actual setting lives in Settings::defaults().
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		// No-op, settings are in main Settings class. This exists so future
		// extensions can hook.
	}

	/**
	 * All defined pages.
	 *
	 * @return array<string,array{title:string,shortcode:string,desc:string,icon:string}>
	 */
	public static function all(): array {
		/**
		 * Filter public pages list.
		 *
		 * @param array $pages Pages.
		 */
		return (array) apply_filters( 'estat_public_pages', self::translated_pages() );
	}

	/**
	 * Get stored page IDs.
	 *
	 * @return array<string,int>
	 */
	public static function stored(): array {
		$stored = get_option( self::OPTION, array() );
		return is_array( $stored ) ? array_map( 'absint', $stored ) : array();
	}

	/**
	 * Get URL for a public page slug, or empty if not created.
	 *
	 * @param string $slug Slug.
	 * @return string
	 */
	public static function get_url( string $slug ): string {
		$stored = self::stored();
		$id = $stored[ $slug ] ?? 0;
		if ( $id > 0 ) {
			$url = get_permalink( $id );
			if ( $url ) {
				return $url;
			}
		}
		// Fallback to archive if properties page missing.
		if ( 'properties' === $slug ) {
			$archive = get_post_type_archive_link( \EstatOS\Data\PostTypes::LISTING );
			return $archive ?: '';
		}
		return '';
	}

	/**
	 * Maybe auto-create pages on init if enabled and not yet done.
	 *
	 * @return void
	 */
	public static function maybe_create_on_init(): void {
		// Never auto-create on frontend or upgrade. Only via Settings → Pages button.
		// This prevents 13 pages auto-published on 28 Sep.
		return;
	}

	/**
	 * Create all public pages as drafts — skips existing slugs, only shortcode.
	 *
	 * @param bool $force Force recreate even if exists.
	 * @return array<string,int> Created IDs.
	 */
	public static function create_all( bool $force = false ): array {
		$all = self::all();
		$stored = self::stored();
		$created = array();

		foreach ( $all as $slug => $def ) {
			$existing_id = $stored[ $slug ] ?? 0;
			if ( ! $force && $existing_id > 0 && get_post_status( $existing_id ) ) {
				$created[ $slug ] = $existing_id;
				continue;
			}
			// Check by slug if page already exists (user may have created manually).
			$page = get_page_by_path( $slug, OBJECT, 'page' );
			if ( ! $force && $page instanceof \WP_Post ) {
				$created[ $slug ] = $page->ID;
				continue;
			}
			$id = self::create_one( $slug, $def );
			if ( $id > 0 ) {
				$created[ $slug ] = $id;
			}
		}

		// Merge with existing stored, prefer new.
		$merged = array_merge( $stored, $created );
		update_option( self::OPTION, $merged, false );

		return $created;
	}

	/**
	 * Create one public page.
	 *
	 * @param string $slug Slug.
	 * @param array  $def  Definition.
	 * @return int Page ID or 0.
	 */
	public static function create_one( string $slug, array $def = array() ): int {
		if ( '' === $slug ) {
			return 0;
		}
		if ( ! $def ) {
			$all = self::all();
			$def = $all[ $slug ] ?? array();
		}
		if ( ! $def ) {
			return 0;
		}
		$title = $def['title'] ?? ucfirst( $slug );
		$shortcode = $def['shortcode'] ?? '';

		// One plain sentence for the visitor, then the shortcode. Never the
		// office's internal note — a search engine was printing those.
		$intro   = self::intro( $slug );
		$content = '' !== $intro ? $intro . "\n\n" . $shortcode : $shortcode;

		$postarr = array(
			'post_title'   => $title,
			'post_name'    => sanitize_title( $slug ),
			'post_content' => $content,
			'post_status'  => 'draft',
			'post_type'    => 'page',
			'comment_status' => 'closed',
		);

		// Check again by path to avoid duplicate on race.
		$existing = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $existing instanceof \WP_Post ) {
			// Update content if it still has our marker? Keep user edits if they removed shortcode? We update only if forced.
			return $existing->ID;
		}

		$id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $id ) ) {
			return 0;
		}
		// Mark as ours.
		update_post_meta( (int) $id, '_estat_public_page', $slug );
		update_post_meta( (int) $id, '_estat_public_page_version', ESTAT_VERSION );

		return (int) $id;
	}

	/**
	 * Delete all public pages (for testing / reset).
	 *
	 * @return int Number deleted.
	 */
	public static function delete_all(): int {
		$stored = self::stored();
		$count = 0;
		foreach ( $stored as $id ) {
			if ( $id > 0 && get_post_type( $id ) === 'page' ) {
				wp_trash_post( $id );
				$count++;
			}
		}
		delete_option( self::OPTION );
		delete_option( 'estat_public_pages_created' );
		return $count;
	}

	/**
	 * Template fallback for public pages when theme is missing page.php
	 * or is a block theme that doesn't render shortcodes well in some edge.
	 *
	 * We only intervene if:
	 * - is_page() and page is one of ours
	 * - theme has no page.php and no singular.php and no index.php? Actually
	 *   WordPress always has index.php, but block themes may have templates
	 *   that don't call the_content in a way we expect. So we provide a minimal
	 *   fallback that still shows header/footer if available, else bare HTML.
	 *
	 * @param string $template Current template.
	 * @return string
	 */
	public static function template_fallback( $template ) {
		if ( ! is_page() ) {
			return $template;
		}
		$page_id = get_queried_object_id();
		if ( ! $page_id ) {
			return $template;
		}
		$slug = get_post_meta( $page_id, '_estat_public_page', true );
		if ( '' === $slug ) {
			// Also check if ID is in stored list.
			$stored = self::stored();
			$slug = array_search( $page_id, $stored, true );
			if ( false === $slug ) {
				return $template;
			}
		}

		// If theme has page.php, let it handle — shortcodes work fine.
		// But if theme is block theme and template is block template that
		// doesn't include post content? WordPress block templates do include
		// post content via template part. So we don't need to override unless
		// template is empty or user explicitly wants our wrapper.
		// For F12, we provide opt-in via filter 'estat_use_public_page_template'.

		/**
		 * Filter whether to use plugin's public page template for our pages.
		 *
		 * @param bool   $use      Whether to use plugin template.
		 * @param int    $page_id  Page ID.
		 * @param string $slug     Public page slug.
		 */
		$use = (bool) apply_filters( 'estat_use_public_page_template', false, $page_id, $slug );

		// Also auto-use if theme has no page.php and is not block theme — very old theme edge.
		if ( ! $use ) {
			$has_page = locate_template( array( 'page.php', 'singular.php' ) );
			if ( '' === $has_page && ! function_exists( 'wp_is_block_theme' ) ) {
				$use = true;
			} elseif ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
				// Block theme: check if template is block template with no content? We stay false by default
				// to respect FSE. Only use ours if filter says so.
				$use = false;
			}
		}

		if ( ! $use ) {
			return $template;
		}

		$fallback = ESTAT_DIR . 'includes/Frontend/templates/page-public.php';
		if ( is_readable( $fallback ) ) {
			return $fallback;
		}
		return $template;
	}

	/**
	 * Render a public page list for admin.
	 *
	 * @return string HTML
	 */
	public static function admin_list_html(): string {
		$all = self::all();
		$stored = self::stored();
		ob_start();
		echo '<table class="widefat striped"><thead><tr>'
                . '<th>' . esc_html__( 'Page', 'estat-os' ) . '</th>'
                . '<th>' . esc_html__( 'Web address', 'estat-os' ) . '</th>'
                . '<th>' . esc_html__( 'Code to paste', 'estat-os' ) . '</th>'
                . '<th>' . esc_html__( 'Status', 'estat-os' ) . '</th>'
                . '<th>' . esc_html__( 'Open', 'estat-os' ) . '</th>'
                . '</tr></thead><tbody>';
		foreach ( $all as $slug => $def ) {
			$id = $stored[ $slug ] ?? 0;
			$exists = $id > 0 && get_post_status( $id );
			$url = $exists ? get_permalink( $id ) : '';
			$edit = $exists ? get_edit_post_link( $id ) : '';
			echo '<tr>';
			echo '<td>' . \EstatOS\Support\Icon::render( (string) $def['icon'], 16, 'estat-ms' ) . ' ' . esc_html( $def['title'] ) . '<br><small>' . esc_html( $def['desc'] ) . '</small></td>';
			echo '<td><code>' . esc_html( $slug ) . '</code></td>';
			echo '<td><code class="estat-copyable">' . esc_html( $def['shortcode'] ) . '</code></td>';
			echo '<td>' . ( $exists ? '✓ ' . esc_html( __( 'Created', 'estat-os' ) ) : '— ' . esc_html__( 'Not created', 'estat-os' ) ) . '</td>';
			echo '<td>' . ( $url ? '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html__( 'Open', 'estat-os' ) . '</a>' . ( $edit ? ' | <a href="' . esc_url( $edit ) . '">' . esc_html__( 'Edit', 'estat-os' ) . '</a>' : '' ) : '<em>—</em>' ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		return (string) ob_get_clean();
	}
}
