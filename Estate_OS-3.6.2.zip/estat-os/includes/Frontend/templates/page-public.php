<?php
/**
 * Fallback public page template — works with any theme, no builder required.
 * If theme is classic, we still call get_header/get_footer so site branding stays.
 * If header/footer missing, we output minimal HTML wrapper.
 *
 * @package EstatOS
 */

defined( 'ABSPATH' ) || exit;

$page_id = get_queried_object_id();
$slug = $page_id ? get_post_meta( $page_id, '_estat_public_page', true ) : '';
$title = $page_id ? get_the_title( $page_id ) : 'Page';

// Try classic header.
$has_header = false;
ob_start();
get_header();
$header_html = ob_get_clean();
if ( '' !== trim( $header_html ) ) {
	$has_header = true;
	echo $header_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
} else {
	// Minimal HTML if no header.
	?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $title ); ?> — <?php bloginfo( 'name' ); ?></title>
<?php wp_head(); ?>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,sans-serif;margin:0;background:var(--estat-raised);color:var(--estat-ink)}
.estat-public-wrap{max-width:1120px;margin:0 auto;padding:24px 16px}
.estat-public-header{margin-bottom:24px;border-bottom:1px solid var(--estat-line);padding-bottom:16px}
.estat-public-title{font-size:28px;margin:0}
.estat-public-desc{color:var(--estat-ink-3);font-size:14px;margin:6px 0 0}
</style>
</head>
<body <?php body_class(); ?>>
<div class="estat-public-wrap">
	<?php
}

?>
<main id="main" class="estat-public-main">
	<header class="estat-public-header">
		<h1 class="estat-public-title"><?php echo esc_html( $title ); ?></h1>
		<?php if ( $slug ) : ?>
		<p class="estat-public-desc"><?php echo esc_html( \EstatOS\Frontend\Pages::all()[ $slug ]['desc'] ?? '' ); ?></p>
		<?php endif; ?>
	</header>
	<div class="estat-public-content">
		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>
	</div>
</main>
<?php
// Footer.
ob_start();
get_footer();
$footer_html = ob_get_clean();
if ( '' !== trim( $footer_html ) ) {
	echo $footer_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
} else {
	wp_footer();
	echo '</div></body></html>';
}
