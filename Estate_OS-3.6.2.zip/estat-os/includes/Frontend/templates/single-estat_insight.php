<?php
/**
 * Single insight — /insight/{slug}/ — the office the office
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) : the_post();
	?>
<main class="estat-public estat-insight" id="main">
<div class="estat-container">
	<header class="estat-single-header">
		<h1 class="estat-single-title"><?php the_title(); ?></h1>
		<p class="estat-page-subtitle"><?php echo esc_html( get_the_date() ); ?></p>
	</header>

	<article class="estat-article">
		<?php the_content(); ?>
	</article>
</div>
</main>
<?php endwhile;
get_footer();
