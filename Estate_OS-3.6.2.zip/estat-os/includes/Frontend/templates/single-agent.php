<?php
/**
 * Fallback template for a team member profile.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Agents;
use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );

get_header();

while ( have_posts() ) :
	the_post();
	$agent_id = (int) get_the_ID();
	$agent    = Agents::to_array( $agent_id );
	?>
	<main class="estat-single" id="main">
		<?php
		/*
		 * This page used to be a name, a role and two links — the record holds
		 * a photo, a line about the person and a WhatsApp number, and none of
		 * it was reaching the website. A team page that shows nothing about
		 * the person is the page a search engine has nothing to read on.
		 */
		$photo    = (string) ( $agent['photo'] ?? '' );
		$whatsapp = (string) ( $agent['whatsapp'] ?? '' );
		if ( '' === $whatsapp ) {
			$whatsapp = (string) $agent['phone'];
		}
		?>
		<div class="estat-agent-head">
			<?php if ( '' !== $photo ) : ?>
				<img class="estat-agent-photo" src="<?php echo esc_url( $photo ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" width="320" height="320" loading="lazy" />
			<?php endif; ?>
			<div>
				<h1><?php the_title(); ?></h1>
				<?php if ( '' !== (string) $agent['role'] ) : ?>
					<p class="estat-agent-role"><?php echo esc_html( (string) $agent['role'] ); ?></p>
				<?php endif; ?>
				<div class="estat-single-description"><?php the_content(); ?></div>
				<p class="estat-agent-contact">
					<?php if ( '' !== (string) $agent['phone'] ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $agent['phone'] ) ); ?>"><?php esc_html_e( 'Call', 'estat-os' ); ?></a>
					<?php endif; ?>
					<?php
					$wa_number = (string) preg_replace( '/\D+/', '', $whatsapp );
					if ( '' !== $wa_number ) :
						?>
						<a class="estat-whatsapp-inline" href="<?php echo esc_url( 'https://wa.me/' . $wa_number ); ?>" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== (string) $agent['email'] ) : ?>
						<a href="mailto:<?php echo esc_attr( (string) $agent['email'] ); ?>"><?php esc_html_e( 'Email', 'estat-os' ); ?></a>
					<?php endif; ?>
				</p>
			</div>
		</div>
		<h2><?php esc_html_e( 'Properties handled', 'estat-os' ); ?></h2>
		<?php echo Components::directory( array( 'agent_id' => $agent_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</main>
	<?php
endwhile;

get_footer();
