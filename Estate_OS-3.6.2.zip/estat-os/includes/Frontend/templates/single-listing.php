<?php
/**
 * Single property — /property/{slug}/ — everything the office knows.
 *
 * The office fills in forty-odd answers about a property: photos, floor plans,
 * a video, the deposit, the facing, what is nearby, the floor it sits on, when
 * the owner can hand it over. This template is where all of it arrives. Read
 * the record first, then print — never the other way round: nothing is written
 * here that `Listings::to_array()` did not carry.
 *
 * The order is the order a buyer asks in: what is it, what does it cost, where
 * is it, what does it look like, what is inside it, and who do I call.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Highlights;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Frontend\Components;
use EstatOS\Frontend\Share;
use EstatOS\Frontend\Shortcodes;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Icon;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) :
	the_post();
	$id      = (int) get_the_ID();
	$listing = Listings::to_array( $id, false );
	if ( ! $listing ) {
		continue;
	}

	/**
	 * One fact, printed only when the office answered it.
	 *
	 * @param string $label Fact name.
	 * @param string $value Fact value.
	 * @return void
	 */
	$fact = static function ( string $label, string $value ): void {
		if ( '' === trim( $value ) ) {
			return;
		}
		echo '<div class="estat-fact"><div class="estat-fact-label">' . esc_html( $label ) . '</div>';
		echo '<div class="estat-fact-value is-normal">' . esc_html( $value ) . '</div></div>';
	};

	$gallery_ids = array_values( array_filter( array_map( 'absint', (array) get_post_meta( $id, '_estat_gallery', true ) ) ) );
	$photos      = array();
	foreach ( $gallery_ids as $photo_id ) {
		$full = wp_get_attachment_image_src( $photo_id, 'large' );
		if ( is_array( $full ) && ! empty( $full[0] ) ) {
			$photos[] = array( 'id' => $photo_id, 'url' => (string) $full[0] );
		}
	}
	$documents = array();
	foreach ( array_values( array_filter( array_map( 'absint', (array) ( $listing['brochures'] ?? array() ) ) ) ) as $doc_id ) {
		$documents[] = array( 'id' => $doc_id, 'title' => get_the_title( $doc_id ), 'url' => (string) wp_get_attachment_url( $doc_id ) );
	}
	$plans = array();
	foreach ( array_values( array_filter( array_map( 'absint', (array) ( $listing['floor_plans'] ?? array() ) ) ) ) as $plan_id ) {
		$plan_src = wp_get_attachment_image_src( $plan_id, 'large' );
		if ( is_array( $plan_src ) && ! empty( $plan_src[0] ) ) {
			$plans[] = array( 'id' => $plan_id, 'url' => (string) $plan_src[0] );
		}
	}

	$localities = array_filter( (array) ( $listing['locality'] ?? array() ) );
	$is_rent    = 'rent' === (string) ( $listing['offer'] ?? '' );
	?>
<main class="estat-public estat-property" id="main">
<div class="estat-container">

	<?php if ( $localities ) : ?>
		<nav class="estat-crumbs" aria-label="<?php esc_attr_e( 'Where you are', 'estat-os' ); ?>">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'estat-os' ); ?></a>
			<?php foreach ( $localities as $area ) : $term = get_term_by( 'name', (string) $area, 'estat_locality' ); ?>
				<span aria-hidden="true">/</span>
				<?php if ( $term && ! is_wp_error( $term ) ) : ?>
					<a href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( (string) $area ); ?></a>
				<?php else : ?>
					<span><?php echo esc_html( (string) $area ); ?></span>
				<?php endif; ?>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>

	<div class="estat-detail">
		<div>
			<header class="estat-detail-head">
				<h1><?php the_title(); ?></h1>
				<?php if ( $localities ) : ?>
					<p class="estat-page-subtitle"><?php echo esc_html( implode( ', ', array_map( 'strval', $localities ) ) ); ?></p>
				<?php endif; ?>

				<div class="estat-detail-price">
					<strong><?php echo esc_html( (string) ( $listing['price_display'] ?? '' ) ); ?></strong>
					<?php
					if ( ! empty( $listing['area'] ) && ! empty( $listing['area_sqft'] ) && ! $is_rent && (float) $listing['area_sqft'] > 0 ) :
						$per_sqft = (float) ( $listing['price_min'] ?? 0 ) / (float) $listing['area_sqft'];
						if ( $per_sqft > 0 ) :
							?>
							<span><?php printf( esc_html__( '%s per sqft', 'estat-os' ), esc_html( Format::money( $per_sqft ) ) ); ?></span>
							<?php
						endif;
					endif;
					if ( ! empty( $listing['days_listed'] ) ) :
						?>
						<span><?php printf( esc_html( _n( 'On the website for %d day', 'On the website for %d days', (int) $listing['days_listed'], 'estat-os' ) ), (int) $listing['days_listed'] ); ?></span>
					<?php endif; ?>
				</div>

				<?php
				$chips = (array) ( $listing['chips'] ?? array() );
				if ( $chips ) :
					?>
					<div class="estat-chips">
						<?php foreach ( $chips as $chip ) : ?>
							<span class="estat-chip"><?php echo esc_html( is_array( $chip ) ? (string) ( $chip['label'] ?? '' ) : (string) $chip ); ?></span>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</header>

			<?php if ( $photos ) : ?>
				<section class="estat-section" style="margin-top:var(--sp-5)">
					<div class="estat-gallery" data-estat-gallery>
						<div class="estat-gallery-main">
							<?php
							$first = $photos[0];
							echo wp_get_attachment_image( (int) $first['id'], 'large', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => esc_attr( get_the_title() ) ) );
							?>
						</div>
						<?php if ( count( $photos ) > 1 ) : ?>
							<div class="estat-gallery-strip">
								<?php foreach ( $photos as $index => $photo ) : ?>
									<button type="button" class="estat-gallery-thumb<?php echo 0 === $index ? ' is-current' : ''; ?>" data-estat-photo="<?php echo esc_url( $photo['url'] ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Photo %d', 'estat-os' ), $index + 1 ) ); ?>">
										<?php echo wp_get_attachment_image( (int) $photo['id'], 'thumbnail', false, array( 'alt' => '' ) ); ?>
									</button>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				</section>
			<?php elseif ( has_post_thumbnail( $id ) ) : ?>
				<figure class="estat-card-media" style="margin-top:var(--sp-5)"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></figure>
			<?php endif; ?>

			<div class="estat-facts" style="margin-top:var(--sp-6)">
				<?php
				$fact( __( 'Type', 'estat-os' ), (string) Vocabulary::label( 'property_types', (string) ( $listing['property_type'] ?? '' ) ) );
				$fact( __( 'Offer', 'estat-os' ), (string) Vocabulary::label( 'offers', (string) ( $listing['offer'] ?? '' ) ) );
				$fact( __( 'Area', 'estat-os' ), ! empty( $listing['area'] ) ? ( (string) $listing['area'] . ' ' . (string) ( $listing['area_unit'] ?? '' ) ) : '' );
				$fact( __( 'Which area is this', 'estat-os' ), (string) Vocabulary::label( 'area_types', (string) ( $listing['area_type'] ?? '' ) ) );
				$fact( __( 'Bedrooms', 'estat-os' ), ! empty( $listing['bedrooms'] ) ? (string) $listing['bedrooms'] : '' );
				$fact( __( 'Bathrooms', 'estat-os' ), ! empty( $listing['bathrooms'] ) ? (string) $listing['bathrooms'] : '' );
				$fact( __( 'Balconies', 'estat-os' ), ! empty( $listing['balconies'] ) ? (string) $listing['balconies'] : '' );
				$fact( __( 'Floor', 'estat-os' ), ( ! empty( $listing['floor'] ) || ! empty( $listing['total_floors'] ) )
					? trim( (string) $listing['floor'] . ( ! empty( $listing['total_floors'] ) ? ' / ' . (string) $listing['total_floors'] : '' ) )
					: '' );
				$fact( __( 'Facing', 'estat-os' ), (string) Vocabulary::label( 'facing', (string) ( $listing['facing'] ?? '' ) ) );
				$fact( __( 'Furnishing', 'estat-os' ), (string) Vocabulary::label( 'furnishing', (string) ( $listing['furnishing'] ?? '' ) ) );
				$fact( __( 'Parking', 'estat-os' ), ! empty( $listing['parking'] ) ? (string) $listing['parking'] : '' );
				$fact( __( 'Age of the property', 'estat-os' ), ! empty( $listing['age'] ) ? sprintf( _n( '%d year', '%d years', (int) $listing['age'], 'estat-os' ), (int) $listing['age'] ) : '' );
				$fact( __( 'Builder or developer', 'estat-os' ), (string) ( $listing['developer'] ?? '' ) );
				$fact( __( 'Construction stage', 'estat-os' ), (string) Vocabulary::label( 'construction', (string) ( $listing['construction'] ?? '' ) ) );
				$fact( __( 'Possession', 'estat-os' ), ! empty( $listing['possession_date'] ) ? Format::month_year( (string) $listing['possession_date'] ) : '' );
				$fact( __( 'Is it still available?', 'estat-os' ), (string) Vocabulary::label( 'availability', (string) ( $listing['availability'] ?? '' ) ) );
				if ( Settings::get( 'show_regulatory' ) ) {
					$fact( (string) Settings::get( 'regulatory_label', 'RERA' ), (string) ( $listing['regulatory_id'] ?? '' ) );
				}
				if ( $is_rent ) {
					$fact( __( 'Security deposit', 'estat-os' ), ! empty( $listing['deposit'] ) ? Format::money( (float) $listing['deposit'] ) : '' );
					$fact( __( 'Monthly maintenance', 'estat-os' ), ! empty( $listing['maintenance'] ) ? Format::money( (float) $listing['maintenance'] ) : '' );
				}
				?>
			</div>

			<?php if ( get_the_content() ) : ?>
				<section class="estat-section">
					<div class="estat-section-head"><h2><?php esc_html_e( 'About this property', 'estat-os' ); ?></h2></div>
					<div class="estat-prose"><?php the_content(); ?></div>
				</section>
			<?php endif; ?>

			<?php
			/*
			 * Two shapes arrive under this name. The office ticks boxes, and
			 * a tick is stored as a code ("corner_plot") - printing the code
			 * would put a developer's word in front of a buyer, so every code
			 * is turned back into words here. A record written by an import
			 * can instead hold plain lines of text; those are kept as typed.
			 */
			$raw_points = $listing['highlights'] ?? '';
			$raw_points = is_array( $raw_points ) ? array_map( 'strval', $raw_points ) : explode( "\n", (string) $raw_points );
			$catalogue  = Highlights::all();
			$points     = array();
			foreach ( $raw_points as $raw_point ) {
				$raw_point = trim( $raw_point );
				if ( '' === $raw_point ) {
					continue;
				}
				$points[] = isset( $catalogue[ $raw_point ] ) ? (string) $catalogue[ $raw_point ]['label'] : $raw_point;
			}
			$amenities = array_filter( (array) ( $listing['amenities'] ?? array() ) );
			$features  = array_filter( (array) ( $listing['features'] ?? array() ) );
			if ( $points || $amenities || $features ) :
				?>
				<section class="estat-section">
					<div class="estat-section-head"><h2><?php esc_html_e( 'What stands out', 'estat-os' ); ?></h2></div>
					<?php if ( $points ) : ?>
						<ul class="estat-prose" style="padding-left:20px">
							<?php foreach ( $points as $point ) : ?>
								<li><?php echo esc_html( (string) $point ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					<?php if ( $features ) : ?>
						<h3 style="font-size:var(--fs-card);margin:var(--sp-5) 0 var(--sp-2)"><?php esc_html_e( 'Special features', 'estat-os' ); ?></h3>
						<div class="estat-chips" style="border-top:0;padding-top:0;margin-top:0">
							<?php foreach ( $features as $feature ) : ?>
								<span class="estat-chip"><?php echo esc_html( (string) $feature ); ?></span>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<?php if ( $amenities ) : ?>
						<h3 style="font-size:var(--fs-card);margin:var(--sp-5) 0 var(--sp-2)"><?php esc_html_e( 'Amenities', 'estat-os' ); ?></h3>
						<div class="estat-checkgrid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr));display:grid">
							<?php foreach ( $amenities as $amenity ) : ?>
								<span class="estat-check"><?php echo Icon::render( 'check', 15 ); // phpcs:ignore ?><span><?php echo esc_html( (string) $amenity ); ?></span></span>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</section>
			<?php endif; ?>

			<?php if ( ! empty( $listing['video_url'] ) || ! empty( $listing['tour_url'] ) ) : ?>
				<section class="estat-section">
					<div class="estat-section-head"><h2><?php esc_html_e( 'See it before you visit', 'estat-os' ); ?></h2></div>
					<div class="estat-cta-row" style="grid-auto-flow:column;justify-content:start">
						<?php if ( ! empty( $listing['video_url'] ) ) : ?>
							<a class="estat-btn" href="<?php echo esc_url( (string) $listing['video_url'] ); ?>" target="_blank" rel="noopener"><?php echo Icon::render( 'play', 16 ); // phpcs:ignore ?> <?php esc_html_e( 'Watch the video', 'estat-os' ); ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $listing['tour_url'] ) ) : ?>
							<a class="estat-btn" href="<?php echo esc_url( (string) $listing['tour_url'] ); ?>" target="_blank" rel="noopener"><?php echo Icon::render( 'compass', 16 ); // phpcs:ignore ?> <?php esc_html_e( 'Take the 360° tour', 'estat-os' ); ?></a>
						<?php endif; ?>
					</div>
				</section>
			<?php endif; ?>

			<?php if ( $plans ) : ?>
				<section class="estat-section">
					<div class="estat-section-head"><h2><?php esc_html_e( 'Floor plans', 'estat-os' ); ?></h2></div>
					<div class="estat-grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr))">
						<?php foreach ( $plans as $plan ) : ?>
							<a class="estat-card-media" style="height:220px" href="<?php echo esc_url( $plan['url'] ); ?>" target="_blank" rel="noopener">
								<?php echo wp_get_attachment_image( (int) $plan['id'], 'medium', false, array( 'alt' => esc_attr__( 'Floor plan', 'estat-os' ), 'loading' => 'lazy' ) ); ?>
							</a>
						<?php endforeach; ?>
					</div>
				</section>
			<?php endif; ?>

			<?php
			$lat = (float) ( $listing['latitude'] ?? 0 );
			$lng = (float) ( $listing['longitude'] ?? 0 );
			if ( $lat && $lng ) :
				?>
				<section class="estat-section">
					<div class="estat-section-head"><h2><?php esc_html_e( 'Where it is', 'estat-os' ); ?></h2></div>
					<?php echo Components::map( $lat, $lng, get_the_title() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in Components::map() ?>
				</section>
			<?php endif; ?>

			<?php
			/*
			 * The asking price for a single property lives in `price`, but a
			 * record that only ever had a range (or an import) carries
			 * `price_min` instead - and a buyer still wants to know the
			 * monthly figure, so the range's lower end is used.
			 */
			$emi_price = (float) ( $listing['price'] ?? 0 );
			if ( $emi_price <= 0 ) {
				$emi_price = (float) ( $listing['price_min'] ?? 0 );
			}
			?>
			<?php
			/*
			 * WhatsApp sits above the form on purpose: on a phone, a visitor
			 * who wants to ask something will tap this before they type.
			 */
			$wa = \EstatOS\Frontend\WhatsApp::button( (int) $id );
			if ( '' !== $wa ) :
				?>
				<section class="estat-section estat-section-wa"><?php echo $wa; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in WhatsApp::button() ?></section>
			<?php endif; ?>

			<?php if ( Settings::get( 'emi_enabled' ) && ! $is_rent && $emi_price > 0 ) : ?>
				<section class="estat-section"><?php echo Components::emi( $emi_price ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></section>
			<?php endif; ?>

			<?php if ( Settings::get( 'share_enabled' ) ) : ?>
				<section class="estat-section"><?php echo Share::render_row( $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></section>
			<?php endif; ?>
		</div>

		<aside class="estat-aside">
			<?php
			/*
			 * Who to call. The office's own person for this property if one is
			 * named, otherwise the office itself — a page with no way to ask a
			 * question is a page that sells nothing.
			 */
			$agent_id = (int) ( $listing['agent_id'] ?? 0 );
			$agent    = $agent_id > 0 ? get_post( $agent_id ) : null;
			$phone    = (string) Settings::get( 'phone' );
			$whatsapp = (string) Settings::get( 'whatsapp' );
			$email    = (string) Settings::get( 'email' );
			$name     = (string) Settings::get( 'office_name' );
			if ( $agent && PostTypes::AGENT === $agent->post_type ) {
				$name     = $agent->post_title;
				$phone    = (string) get_post_meta( $agent_id, '_estat_phone', true );
				$whatsapp = (string) get_post_meta( $agent_id, '_estat_whatsapp', true );
				$email    = (string) get_post_meta( $agent_id, '_estat_email', true );
			}
			?>
			<div class="estat-panel">
				<h3><?php esc_html_e( 'Ask about this property', 'estat-os' ); ?></h3>
				<div class="estat-agent-row">
					<span class="estat-avatar<?php echo $agent ? ' is-square' : ''; ?>"><?php echo $agent ? get_the_post_thumbnail( $agent_id, 'thumbnail' ) : esc_html( mb_substr( $name, 0, 2 ) ); // phpcs:ignore ?></span>
					<span>
						<span class="estat-agent-name"><?php echo esc_html( $name ); ?></span><br>
						<?php if ( Settings::get( 'office_hours' ) ) : ?>
							<span class="estat-muted" style="font-size:var(--fs-meta)"><?php echo esc_html( (string) Settings::get( 'office_hours' ) ); ?></span>
						<?php endif; ?>
					</span>
				</div>
				<div class="estat-agent-contact">
					<?php if ( '' !== $phone ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo Icon::render( 'phone', 16 ); // phpcs:ignore ?><?php echo esc_html( $phone ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== $email ) : ?>
						<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo Icon::render( 'envelope', 16 ); // phpcs:ignore ?><?php echo esc_html( $email ); ?></a>
					<?php endif; ?>
					<?php if ( '' !== (string) Settings::get( 'address' ) ) : ?>
						<span><?php echo Icon::render( 'map-pin', 16 ); // phpcs:ignore ?><?php echo esc_html( (string) Settings::get( 'address' ) ); ?></span>
					<?php endif; ?>
				</div>
				<div class="estat-cta-row">
					<?php if ( '' !== $whatsapp ) : $wa = preg_replace( '/[^0-9]/', '', $whatsapp ); ?>
						<a class="estat-btn is-wa" href="https://wa.me/<?php echo esc_attr( (string) $wa ); ?>?text=<?php echo esc_attr( rawurlencode( sprintf( /* translators: %s: property name */ __( 'Hello, I would like to ask about %s', 'estat-os' ), get_the_title() ) ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'WhatsApp', 'estat-os' ); ?></a>
					<?php endif; ?>
					<a class="estat-btn" href="#estat-enquiry"><?php esc_html_e( 'Send an enquiry', 'estat-os' ); ?></a>
				</div>
			</div>

			<?php
			$project_id = (int) ( $listing['project_id'] ?? 0 );
			if ( $project_id > 0 && 'publish' === get_post_status( $project_id ) ) :
				?>
				<div class="estat-panel">
					<h3><?php esc_html_e( 'In this society', 'estat-os' ); ?></h3>
					<p style="margin:0 0 8px"><a href="<?php echo esc_url( (string) get_permalink( $project_id ) ); ?>"><?php echo esc_html( get_the_title( $project_id ) ); ?></a></p>
					<p class="estat-muted" style="margin:0;font-size:var(--fs-meta)"><?php esc_html_e( 'See the whole society: prices, stage, possession and the other homes listed there.', 'estat-os' ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $documents ) : ?>
				<div class="estat-panel">
					<h3><?php esc_html_e( 'Documents', 'estat-os' ); ?></h3>
					<ul class="estat-list">
						<?php foreach ( $documents as $document ) : ?>
							<li class="estat-list-row">
								<span class="estat-list-main"><b><?php echo esc_html( '' !== $document['title'] ? $document['title'] : __( 'Brochure', 'estat-os' ) ); ?></b></span>
								<a class="estat-page-link" href="<?php echo esc_url( $document['url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open', 'estat-os' ); ?></a>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( Settings::get( 'print_enabled' ) ) : ?>
				<div class="estat-panel">
					<h3><?php esc_html_e( 'Print or keep', 'estat-os' ); ?></h3>
					<p class="estat-muted" style="margin:0 0 8px;font-size:var(--fs-meta)"><?php esc_html_e( 'A clean one-page sheet with the photo, the price and your office details.', 'estat-os' ); ?></p>
					<a class="estat-page-link" href="<?php echo esc_url( add_query_arg( 'print', '1', (string) get_permalink( $id ) ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open the printable sheet', 'estat-os' ); ?></a>
				</div>
			<?php endif; ?>
		</aside>
	</div>

	<div id="estat-enquiry" class="estat-property-enquiry">
		<?php echo Components::enquiry_form( $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?>
	</div>
</div>
</main>
<?php endwhile; ?>
<?php
get_footer();
