<?php
/**
 * Insights archive — /insights/ — the office the office
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-insights" id="main">
<div class="estat-container">
	<header class="estat-page-header">
		<h1><?php esc_html_e( 'Insights', 'estat-os' ); ?></h1>
		<p class="estat-page-subtitle"><?php esc_html_e( 'Market updates, guides and stories from our office.', 'estat-os' ); ?></p>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="estat-grid">
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="estat-insight-card">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large', array( 'loading'=>'lazy' ) ); ?></a>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p class="estat-muted"><?php echo esc_html( get_the_date() ); ?> — <?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No insights yet.', 'estat-os' ); ?></p>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
