<?php
/**
 * Amenity archive — the office
 *
 * @package EstatOS
 */
defined( 'ABSPATH' ) || exit;
$term = get_queried_object();
$term_name = $term && ! is_wp_error( $term ) ? $term->name : __( 'Amenity', 'estat-os' );
wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );
get_header();
?>
<main class="estat-public estat-amenity" id="main">
<div class="estat-container">
	<header class="estat-page-header">
		<h1><?php echo esc_html( $term_name ); ?></h1>
		<?php if ( $term && ! is_wp_error( $term ) ) : ?>
			<p class="estat-page-subtitle"><?php echo esc_html( sprintf( _n( '%d property', '%d properties', (int) $term->count, 'estat-os' ), (int) $term->count ) ); ?></p>
		<?php endif; ?>
	</header>
	<?php echo \EstatOS\Frontend\Components::search_form(); // phpcs:ignore ?>
	<?php if ( have_posts() ) : ?>
		<div class="estat-grid">
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="estat-card">
					<a class="estat-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large', array( 'loading'=>'lazy' ) ); ?></a>
					<div class="estat-card-body"><h2 class="estat-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2></div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No properties found.', 'estat-os' ); ?></p>
	<?php endif; ?>
</div>
</main>
<?php get_footer(); ?>
