<?php
/**
 * Projects archive — /projects/ — the office the office
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\Projects;
use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-projects" id="main">
<div class="estat-container">
	<header class="estat-page-header">
		<h1><?php esc_html_e( 'Projects', 'estat-os' ); ?></h1>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="estat-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				$project = Projects::to_array( (int) get_the_ID() );
				// A project usually has no written description to trim, so the
				// card says the things the record actually holds.
				$meta = array_filter(
					array(
						(string) ( $project['developer'] ?? '' ),
						implode( ', ', array_map( 'strval', (array) ( $project['locality'] ?? array() ) ) ),
						(string) ( $project['price_display'] ?? '' ),
					)
				);
				?>
				<article class="estat-card">
					<a class="estat-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large', array( 'loading'=>'lazy' ) ); ?></a>
					<div class="estat-card-body">
						<h2 class="estat-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<?php if ( $meta ) : ?>
							<p class="estat-card-meta"><?php echo esc_html( implode( ' · ', $meta ) ); ?></p>
						<?php elseif ( get_the_excerpt() ) : ?>
							<p class="estat-card-meta"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
						<?php endif; ?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No projects found.', 'estat-os' ); ?></p>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
