<?php
/**
 * Single project — /project/{slug}/ — one society, the whole record.
 *
 * A master sheet brings in a name, a builder, an area, a price range, the unit
 * sizes, the RERA number and the possession date — and until now the page
 * printed a stage and a unit count, so every imported project page was an empty
 * shell that a search engine had nothing to read. Everything the record holds
 * is printed here, and nothing that the record does not hold is invented.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Frontend\Components;
use EstatOS\Frontend\Pages;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) :
	the_post();
	$id      = (int) get_the_ID();
	$project = Projects::to_array( $id );
	?>
<main class="estat-public estat-project" id="main">
<div class="estat-container">
	<header class="estat-single-header">
		<h1 class="estat-single-title"><?php the_title(); ?></h1>
		<?php
		$subtitle = array_filter(
			array(
				(string) ( $project['developer'] ?? '' ),
				(string) ( $project['address'] ?? '' ),
			)
		);
		?>
		<?php if ( $subtitle ) : ?>
			<p class="estat-page-subtitle"><?php echo esc_html( implode( ' · ', $subtitle ) ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( has_post_thumbnail( $id ) ) : ?>
		<figure class="estat-card-media"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager' ) ); ?></figure>
	<?php endif; ?>

	<div class="estat-facts">
		<?php
		$facts = array();

		if ( ! empty( $project['stage'] ) ) {
			$facts[ __( 'Stage', 'estat-os' ) ] = Vocabulary::label( 'project_statuses', (string) $project['stage'] );
		}
		if ( ! empty( $project['category'] ) ) {
			$facts[ __( 'Kind', 'estat-os' ) ] = Vocabulary::label( 'project_categories', (string) $project['category'] );
		}
		if ( ! empty( $project['project_type'] ) ) {
			$facts[ __( 'Homes or units', 'estat-os' ) ] = (string) $project['project_type'];
		}
		if ( ! empty( $project['unit_types'] ) ) {
			$facts[ __( 'Unit types', 'estat-os' ) ] = (string) $project['unit_types'];
		}
		if ( ! empty( $project['price_display'] ) ) {
			$facts[ __( 'Price', 'estat-os' ) ] = (string) $project['price_display'];
		}
		if ( ! empty( $project['possession_date'] ) ) {
			$facts[ __( 'Possession', 'estat-os' ) ] = Format::month_year( (string) $project['possession_date'] );
		}
		$localities = array_filter( (array) ( $project['locality'] ?? array() ) );
		if ( $localities ) {
			$facts[ __( 'Area', 'estat-os' ) ] = implode( ', ', array_map( 'strval', $localities ) );
		}
		if ( ! empty( $project['total_units'] ) ) {
			$facts[ __( 'Total units', 'estat-os' ) ] = (string) $project['total_units'];
		}
		if ( ! empty( $project['available_units'] ) ) {
			$facts[ __( 'Units still available', 'estat-os' ) ] = (string) $project['available_units'];
		}
		if ( Settings::get( 'show_regulatory' ) && ! empty( $project['regulatory_id'] ) ) {
			$facts[ __( 'Registration number', 'estat-os' ) ] = (string) $project['regulatory_id'];
		}

		foreach ( $facts as $label => $value ) :
			?>
			<div>
				<div class="estat-fact-label"><?php echo esc_html( (string) $label ); ?></div>
				<div class="estat-fact-value"><?php echo esc_html( (string) $value ); ?></div>
			</div>
			<?php
		endforeach;
		?>
	</div>

	<?php
	// The same WhatsApp door an individual property has: a society enquiry
	// arrives with the society's name and link already written.
	$wa = \EstatOS\Frontend\WhatsApp::button( (int) $id );
	if ( '' !== $wa ) :
		?>
		<section class="estat-section estat-section-wa"><?php echo $wa; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in WhatsApp::button() ?></section>
		<?php
	endif;

	$points = array_filter( array_map( 'trim', explode( "\n", (string) ( $project['highlights'] ?? '' ) ) ) );
	if ( $points ) :
		?>
		<section class="estat-project-highlights">
			<h2><?php esc_html_e( 'What stands out', 'estat-os' ); ?></h2>
			<ul class="estat-ui-quiet-list">
				<?php foreach ( $points as $point ) : ?>
					<li><?php echo esc_html( (string) $point ); ?></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<div class="estat-article">
		<?php the_content(); ?>
	</div>

	<?php
	// The homes in this society, when the office has listed any.
	$in_project = get_posts(
		array(
			'post_type'   => PostTypes::LISTING,
			'post_status' => 'publish',
			'numberposts' => 6,
			'fields'      => 'ids',
			'meta_key'    => '_estat_project_id',
			'meta_value'  => $id,
		)
	);
	if ( $in_project ) :
		?>
		<section class="estat-project-listings">
			<h2><?php esc_html_e( 'Properties in this project', 'estat-os' ); ?></h2>
			<div class="estat-grid">
				<?php foreach ( $in_project as $listing_id ) : ?>
					<?php echo Components::card( (int) $listing_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endforeach; ?>
			</div>
			<p>
				<a class="estat-ui-btn-primary" href="<?php echo esc_url( add_query_arg( 'project_id', $id, Pages::get_url( 'properties' ) ) ); ?>">
					<?php
					printf(
						/* translators: %d: how many properties are listed in this project. */
						esc_html( _n( 'See the %d property', 'See all %d properties', count( $in_project ), 'estat-os' ) ),
						count( $in_project )
					);
					?>
				</a>
			</p>
		</section>
	<?php endif; ?>
</div>
</main>
<?php endwhile; ?>
<?php
get_footer();
