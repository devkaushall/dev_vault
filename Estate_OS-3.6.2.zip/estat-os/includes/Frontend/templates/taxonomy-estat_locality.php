<?php
/**
 * Locality archive — the office the office
 * Wrapper: <main class="estat-public estat-locality"><div class="estat-container">
 *
 * @package EstatOS
 */

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Frontend\Components;
use EstatOS\Search\Query;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

$term = get_queried_object();
if ( ! $term || is_wp_error( $term ) ) { $term = null; }
$term_id = $term ? (int) $term->term_id : 0;
$term_name = $term ? $term->name : __( 'Locality', 'estat-os' );

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-locality" id="main">
<div class="estat-container">
	<header class="estat-page-header">
		<h1><?php echo esc_html( $term_name ); ?></h1>
		<?php if ( $term ) : ?>
			<p class="estat-page-subtitle"><?php echo esc_html( sprintf( _n( '%d property', '%d properties', (int) $term->count, 'estat-os' ), (int) $term->count ) ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( $term && Settings::get( 'locality_pages' ) ) : ?>
		<?php
		$result = Query::search( array( 'locality' => array( $term_id ), 'per_page' => 12 ) );
		$ids = $result['ids'];
		?>
		<div class="estat-grid">
			<?php if ( $ids ) : foreach ( $ids as $lid ) : $p = get_post( $lid ); if ( ! $p ) continue; ?>
				<article class="estat-card">
					<a class="estat-card-media" href="<?php echo esc_url( get_permalink( $lid ) ); ?>"><?php echo get_the_post_thumbnail( $lid, 'medium_large', array( 'loading'=>'lazy' ) ); ?></a>
					<div class="estat-card-body">
						<h2 class="estat-card-title"><a href="<?php echo esc_url( get_permalink( $lid ) ); ?>"><?php echo esc_html( get_the_title( $lid ) ); ?></a></h2>
						<div class="estat-card-meta">
							<?php
							$price = get_post_meta( $lid, '_estat_price_display', true ) ?: get_post_meta( $lid, '_estat_price', true );
							if ( $price ) { echo '<span>' . esc_html( $price ) . '</span>'; }
							?>
						</div>
					</div>
				</article>
			<?php endforeach; else : ?>
				<p><?php esc_html_e( 'No properties found in this locality yet.', 'estat-os' ); ?></p>
			<?php endif; ?>
		</div>

		<?php
		$proj_ids = get_posts( array( 'post_type' => PostTypes::PROJECT, 'post_status' => 'publish', 'tax_query' => array( array( 'taxonomy' => Taxonomies::LOCALITY, 'field' => 'term_id', 'terms' => $term_id ) ), 'posts_per_page' => 20, 'fields' => 'ids' ) );
		if ( $proj_ids ) {
			echo '<div class="estat-facts estat-mt"><h3 class="estat-section-title-sm">' . esc_html__( 'Projects / Societies', 'estat-os' ) . '</h3><ul>';
			foreach ( $proj_ids as $pid ) {
				echo '<li><a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a></li>';
			}
			echo '</ul></div>';
		}
		?>
	<?php else : ?>
		<?php echo \EstatOS\Frontend\Shortcodes::localities(); // phpcs:ignore ?>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
