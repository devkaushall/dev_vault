<?php
/**
 * Elementor integration. Entirely optional.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Integrations\Elementor;

use EstatOS\Leads\Leads;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Elementor is a presentation layer. The plugin owns the data; these widgets
 * only render it. Nothing here loads unless Elementor is actually active, and
 * every widget calls the same components the shortcodes use.
 */
final class Bridge {

	/**
	 * Widget category slug.
	 */
	public const CATEGORY = 'estat-real-estate';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'add_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
		// Forms built in Elementor: their messages also land in the office inbox.
		add_action( 'elementor_pro/forms/new_record', array( __CLASS__, 'form_record' ), 10, 2 );
	}

	/**
	 * Whether Elementor is available.
	 *
	 * @return bool
	 */
	public static function active(): bool {
		return did_action( 'elementor/loaded' ) > 0;
	}

	/**
	 * A form built in Elementor was sent — keep it as an enquiry too.
	 *
	 * The office then sees every website message in one place instead of two.
	 * Nothing is created when the switch is off, or when the message has neither
	 * a phone number nor an email address to reply to.
	 *
	 * @param mixed $record  Elementor form record.
	 * @param mixed $handler Elementor form handler (unused).
	 * @return void
	 */
	public static function form_record( $record, $handler = null ): void {
		try {
			if ( ! Settings::get( 'elementor_forms_to_enquiries', true ) ) {
				return;
			}
			if ( ! is_object( $record ) || ! method_exists( $record, 'get' ) ) {
				return;
			}

			$fields = $record->get( 'fields' );
			if ( ! is_array( $fields ) || ! $fields ) {
				return;
			}

			$name    = '';
			$phone   = '';
			$email   = '';
			$message = '';
			$rest    = array();

			foreach ( $fields as $key => $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}
				$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';
				if ( '' === $value ) {
					continue;
				}
				$type  = isset( $field['type'] ) ? strtolower( (string) $field['type'] ) : '';
				$label = isset( $field['title'] ) && '' !== (string) $field['title'] ? (string) $field['title'] : (string) $key;
				$low   = strtolower( $label );

				if ( '' === $name && ( 'name' === $type || ( false !== strpos( $low, 'name' ) && false === strpos( $low, 'surname' ) && false === strpos( $low, 'last' ) ) ) ) {
					$name = $value;
					continue;
				}
				if ( '' === $email && ( 'email' === $type || is_email( $value ) ) ) {
					$email = $value;
					continue;
				}
				if ( '' === $phone && ( 'tel' === $type || false !== strpos( $low, 'phone' ) || false !== strpos( $low, 'mobile' ) || false !== strpos( $low, 'contact' ) || false !== strpos( $low, 'whatsapp' ) ) ) {
					$phone = $value;
					continue;
				}
				if ( '' === $message && ( 'textarea' === $type || false !== strpos( $low, 'message' ) || false !== strpos( $low, 'comment' ) || false !== strpos( $low, 'enquir' ) || false !== strpos( $low, 'brief' ) || false !== strpos( $low, 'requirement' ) ) ) {
					$message = $value;
					continue;
				}
				$rest[] = $label . ': ' . $value;
			}

			// A later "last name" field would otherwise be thrown away: keep the rest.
			if ( '' === $phone && '' === $email ) {
				return;
			}
			if ( '' !== $rest ) {
				$message = trim( $message . "\n" . implode( "\n", $rest ) );
			}
			if ( '' === $name ) {
				$name = __( 'Website visitor', 'estat-os' );
			}

			$meta       = (array) $record->get( 'meta' );
			$source_url = (string) ( $meta['page_url'] ?? $meta['referrer'] ?? '' );
			$form_name  = (string) ( $meta['form_name'] ?? '' );

			$key = '';
			if ( method_exists( $record, 'get_form_settings' ) ) {
				$settings = (array) $record->get_form_settings();
				$key      = (string) ( $settings['custom_id'] ?? $settings['id'] ?? $form_name );
			}
			if ( '' !== $key ) {
				$key .= '-' . (string) ( $meta['timestamp'] ?? '' );
			}

			Leads::create(
				array(
					'name'            => $name,
					'phone'           => $phone,
					'email'           => $email,
					'message'         => $message,
					'source'          => 'elementor',
					'source_url'      => $source_url,
					'consent'         => true,
					'idempotency_key' => $key,
				)
			);
		} catch ( \Throwable $e ) {
			// A website message must never break the page the visitor is on.
			unset( $e );
		}
	}

	/**
	 * Answers already given this request, so the same question is not asked
	 * of Elementor over and over while one page is being built.
	 *
	 * @var array<string, bool>
	 */
	private static $template_cache = array();

	/**
	 * Is an Elementor template drawing this page already?
	 *
	 * The office builds its pages in Elementor. When Elementor (Pro) has a
	 * Theme Builder template for a single property, that template is the page —
	 * and a plugin that replaces it would be throwing away work somebody did on
	 * purpose. So the plugin asks first, and stays out of the way.
	 *
	 * Free Elementor has no Theme Builder, so this answers false there and the
	 * plugin's own template is used when the theme has none.
	 *
	 * Everything here is wrapped: Elementor changes its own inside code between
	 * versions, and a question about templates must never be able to take the
	 * website down. If anything at all goes wrong the answer is "no template"
	 * and the page is drawn the normal way.
	 *
	 * @param string $location Elementor location, 'single' or 'archive'.
	 * @return bool
	 */
	public static function has_template( string $location = 'single' ): bool {
		if ( array_key_exists( $location, self::$template_cache ) ) {
			return self::$template_cache[ $location ];
		}
		// Set first: if Elementor calls back into us, we must not loop.
		self::$template_cache[ $location ] = false;

		self::$template_cache[ $location ] = self::ask_elementor( $location );
		return self::$template_cache[ $location ];
	}

	/**
	 * Throw away remembered answers.
	 *
	 * A page is asked about once per request, which is what keeps the website
	 * fast. This is here so the tests can ask the same question again, and so
	 * anything that changes a template mid-request can start clean.
	 *
	 * @return void
	 */
	public static function forget_templates(): void {
		self::$template_cache = array();
	}

	/**
	 * The actual question, kept apart so callers only ever see true or false.
	 *
	 * @param string $location Elementor location.
	 * @return bool
	 */
	private static function ask_elementor( string $location ): bool {
		try {
			if ( ! self::active() || ! isset( \Elementor\Plugin::$instance ) ) {
				return false;
			}
			$instance = \Elementor\Plugin::$instance;
			if ( ! is_object( $instance ) || ! isset( $instance->modules_manager ) || ! is_object( $instance->modules_manager ) ) {
				return false;
			}

			$module = self::module( $instance->modules_manager, 'theme-builder' );
			if ( ! is_object( $module ) || ! method_exists( $module, 'get_conditions_manager' ) ) {
				return false;
			}
			$conditions = $module->get_conditions_manager();
			if ( ! is_object( $conditions ) || ! method_exists( $conditions, 'get_documents_for_location' ) ) {
				return false;
			}

			$documents = $conditions->get_documents_for_location( $location );
			return is_array( $documents ) && array() !== $documents;
		} catch ( \Throwable $e ) {
			self::note( $e );
			return false;
		}
	}

	/**
	 * Elementor has changed this call over the years.
	 *
	 * Elementor 4 asks for one module by name — "get_modules( 'theme-builder' )"
	 * — and refuses to run without that name, which is what broke the website
	 * on 3.2.6. Older Elementor has no name to give and returns the whole list.
	 * Both are tried, newest first, and a version we do not know simply answers
	 * "no module".
	 *
	 * @param object $manager Elementor modules manager.
	 * @param string $name    Module name.
	 * @return object|null
	 */
	private static function module( $manager, string $name ) {
		if ( ! method_exists( $manager, 'get_modules' ) ) {
			return null;
		}

		$wants_name = true;
		try {
			$method     = new \ReflectionMethod( $manager, 'get_modules' );
			$wants_name = $method->getNumberOfRequiredParameters() >= 1;
		} catch ( \Throwable $e ) {
			unset( $e );
		}

		if ( $wants_name ) {
			try {
				$one = $manager->get_modules( $name );
				return is_object( $one ) ? $one : null;
			} catch ( \Throwable $e ) {
				self::note( $e );
				return null;
			}
		}

		try {
			$all = $manager->get_modules();
			return is_array( $all ) && isset( $all[ $name ] ) && is_object( $all[ $name ] ) ? $all[ $name ] : null;
		} catch ( \Throwable $e ) {
			self::note( $e );
			return null;
		}
	}

	/**
	 * Leave a line in the site's log, and never let logging itself be fatal.
	 *
	 * @param \Throwable $e Error.
	 * @return void
	 */
	private static function note( \Throwable $e ): void {
		if ( function_exists( 'error_log' ) ) {
			error_log( 'Estat OS: could not ask Elementor about its templates — ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		}
	}

	/**
	 * Is somebody editing this page in Elementor right now?
	 *
	 * Used by the widgets to show a helpful line while editing. Safe to call
	 * from anywhere on the site, including when Elementor is not there.
	 *
	 * @return bool
	 */
	public static function is_edit_mode(): bool {
		try {
			if ( ! self::active() || ! isset( \Elementor\Plugin::$instance ) ) {
				return false;
			}
			$instance = \Elementor\Plugin::$instance;
			if ( ! is_object( $instance ) || ! isset( $instance->editor ) || ! is_object( $instance->editor ) ) {
				return false;
			}
			return (bool) $instance->editor->is_edit_mode();
		} catch ( \Throwable $e ) {
			self::note( $e );
			return false;
		}
	}

	/**
	 * Add the branded widget category.
	 *
	 * @param object $manager Elementor category manager.
	 * @return void
	 */
	public static function add_category( $manager ): void {
		if ( ! is_object( $manager ) || ! method_exists( $manager, 'add_category' ) ) {
			return;
		}
		$manager->add_category(
			self::CATEGORY,
			array(
				'title' => __( 'Real Estate', 'estat-os' ),
				'icon'  => 'eicon-home-heart',
			)
		);
	}

	/**
	 * Register every widget.
	 *
	 * @param object $widgets_manager Elementor widget manager.
	 * @return void
	 */
	public static function register_widgets( $widgets_manager ): void {
		if ( ! self::active() || ! is_object( $widgets_manager ) || ! method_exists( $widgets_manager, 'register' ) ) {
			return;
		}
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once __DIR__ . '/BaseWidget.php';
		require_once __DIR__ . '/Widgets.php';

		foreach ( Widgets::classes() as $class_name ) {
			if ( class_exists( $class_name ) ) {
				$widgets_manager->register( new $class_name() );
			}
		}
	}
}
