/**
 * whatsapp.js — jab koi WhatsApp wale button par tap kare to office ko batao.
 *
 * Do baatein jaan-boojh kar aise likhi hain:
 *   1. Button pehle se ek aam link hai. Ye file na chale, internet dheema ho,
 *      ya script block ho — WhatsApp phir bhi khulta hai. Ye sirf ginti likhta
 *      hai, kuch rokta nahi.
 *   2. Jawab ka intezaar nahi karte (sendBeacon jaisa). Visitor to pehle hi
 *      WhatsApp ki taraf nikal chuka hai.
 */
( function () {
	'use strict';

	function note( id ) {
		if ( ! window.estatWhatsApp || ! id ) {
			return;
		}
		var body = new URLSearchParams();
		body.set( 'action', 'estat_whatsapp_tap' );
		body.set( 'nonce', window.estatWhatsApp.nonce );
		body.set( 'id', String( id ) );

		try {
			fetch( window.estatWhatsApp.endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				body: body
			} ).catch( function () {} );
		} catch ( e ) {
			/* Purani browsers: koi baat nahi, ginti chhoot jaaye, kaam na ruke. */
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target && event.target.closest ? event.target.closest( '[data-estat-whatsapp]' ) : null;
		if ( ! link ) {
			return;
		}
		note( link.getAttribute( 'data-estat-whatsapp' ) );
	} );
} )();
