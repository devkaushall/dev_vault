=== Estat.OS — Real Estate Operating System ===
Contributors: devil
Tags: real estate, property, listings, enquiries, crm
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 3.6.2
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Run a real-estate office from WordPress: listings, enquiries, site visits, team, forms and reports, in plain language.

== Description ==

Estat.OS is the operating system for a small or medium estate office. WordPress
is the platform it runs on; this plugin is the business system.

It handles the whole cycle an office actually works through: put a property on
the website, a visitor asks about it, the enquiry lands in your inbox, somebody
is made responsible, a site visit is arranged, and it is marked as won or lost.
Reports then tell you how that is going.

The screens are written for someone who does not build websites. There is no
talk of custom post types, meta fields or endpoints anywhere in the interface.
A property is a "property", not a "post".

**What it manages**

* Listings, with photos, price, size, features and a readiness score
* Societies and projects that several listings belong to
* Your team, and who is responsible for what
* Enquiries, with notes, follow-up dates and duplicate protection
* Site visits, and how each one went
* Blogs, articles and market insights
* A gallery of every photo and document in one place
* Forms you design yourself, which feed straight into Enquiries
* Import and export by spreadsheet
* Reports on enquiries, visits and team activity

**What it does not require**

* No page builder. Elementor widgets are included, but if Elementor is switched
  off every part of the office keeps working.
* No ACF or any other field plugin. Estat.OS owns its own data model.
* No Composer, no build step, no external service.
* Maps work out of the box with OpenStreetMap. A Google key is optional.

**Your data stays yours**

Deactivating the plugin changes nothing. Deleting it changes nothing either,
unless you have explicitly ticked the box in Office Settings that says to erase
everything. Nothing is ever thrown away because a plugin was removed.

Every listing, enquiry and visit can be exported to a spreadsheet at any time.

**Languages**

English and Hinglish written in ordinary English letters, the way most Indian
offices actually speak. The language of the office screens and the language of
the public website are set separately. Information you type in — a property
name, a customer's message — is never translated.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the ZIP from
   Plugins → Add New → Upload Plugin.
2. Activate it.
3. Open **Office** in the admin menu. A short setup asks four questions and
   builds your website pages for you. You can skip it and do everything by hand.

== Frequently Asked Questions ==

= Do I need Elementor? =

No. Estat.OS renders its own property pages, search and forms. If you do use
Elementor, seventeen widgets are available so you can lay those pages out
yourself instead.

= What happens to my properties if I remove the plugin? =

They stay exactly where they are. Removing the plugin does not delete business
data unless you have deliberately asked for that in Office Settings → Tools.

= Can two people use it at once? =

Yes. There are two roles — Office Owner and Office Agent — and each enquiry can
be handed to a particular person. Permissions are checked on every action, not
just hidden from the menu. A property still belongs to whoever added it: an
agent cannot change somebody else's, but they can propose a correction from the
property itself, which the office approves or turns down.

= How many properties can it handle? =

It is built and tested for a small or medium office on ordinary shared hosting,
comfortably into the thousands. Lists are paged, searches are indexed, and
imports are processed a few rows at a time so a large spreadsheet does not time
the site out.

= Is the information visitors send me protected? =

Enquiries are stored in your own database, never sent anywhere else. Duplicate
submissions are merged, spam is filtered without a third-party service, and a
person's name, phone and email can be erased on request while keeping the
record of the enquiry itself.

== Screenshots ==

1. Today — what needs attention right now
2. Listings, with readiness scores
3. The property editor, grouped into three short chapters
4. Enquiries, with follow-up dates and notes
5. The form studio: seven steps, live preview
6. Reports

== Changelog ==

= 3.6.2 =
* **Several photographs in a row, without the phone having to be told again.** The photo box used to be one shot per trip: the camera opened, the picture came back, you pressed again. It now keeps a small pile. The button says **"Open the camera"**, and after a picture it says **"Take another"** and a line counts for you — **"2 ready"** — so a listing with eight pictures is eight taps in one place instead of eight walks back through the phone. A picture you did not mean to take comes off with its little **×**, and the **"Worth shooting"** list above ticks itself off as you go. No reload, nothing to press twice, and the save below still sends the same set it always did.
* **A property's papers are now asked for once, under one heading.** The plan and the brochure were two separate questions with two separate boxes, which read as two separate jobs on a phone. They now sit together under **"Papers"** — *"The plan, the brochure, anything the office should keep. A photo of the paper is fine."* — with the same two choosers underneath. Nothing about where those pictures are kept has changed; the office reads them exactly as before.
* **A screen for the work the phone is still holding.** Pocket's **More** list now has **"Waiting to go up"**, and the quiet line at the bottom of the form carries a **"See them"** link to it. Each save that is stuck on the phone is one row: what the property is (or *"A new property"*), how long ago it was filled in (*"just now"*, *"12 minutes ago"*), and how many times the phone has tried — with two plain words on the right, **"Send now"** and **"Take it off this phone"**. Nothing is ever dropped in silence: taking one off asks first. When the last one goes up the screen says so — *"Nothing is waiting. Everything you filled in has gone up."*

= 3.6.1 =
* **Saving with no network now works the way the field works.** Fill a form in a cellar, a lift, the back of a parking lot and press **Save**: the whole thing — every answer, every photograph, the voice note — stays on the phone, and a quiet line says so (*"1 waiting to go up"*). The moment the bars come back the phone sends it up by itself, through the same door a normal save uses, and tells you: **"Sent. It went up."** with a link to open it. Nothing is a second way of storing a property, and a save that is tried twice lands on **one** record — the phone keeps its own name for the piece of work, and the second arrival simply carries on with the same property.
* **A note can be written when it cannot be spoken.** Some phones refuse the microphone and some rooms are too loud to talk in: under **Record** there is now **"Write it instead"**, and the office reads that note in the same place it hears the others.
* **Smaller:** a property carrying a voice note or a written one opens that part of the office editor by itself, the way a property with photographs already does.

= 3.6.0 =
* **Delete and restore got simpler, because they had one choice too many.** The bar used to offer a second, cleverer thing — **Select all 240 properties** — which changed records that were not on the screen. It worked, and it was exactly the part nobody could be sure of. It is gone. **The bar now acts on what is ticked, and nothing else**; the footer already tells you what the whole list holds ("Showing 1 to 20 of 240 properties"). One press carries up to **100 records**, and if more than that is ticked the bar says so in red before you press it. Nothing is ever dropped in silence.
* **Pocket 2.2 — field capture.** A **voice note** can now be recorded on the phone and saved with the property: tap **Record**, talk for as long as it takes, tap **Stop**, and it goes up with the same Save as the photographs. The office hears it on the property screen — *"Recorded on the phone while looking at the property"* — and it is playable on the phone too. A new **"Worth shooting"** list sits above the photo box (the front of the building, the kitchen, a balcony view…), and a line under it counts as you go: *"Three so far. Six or more is what makes a listing look real."*
* **The phone now says when it is offline.** No network and a quiet line appears: *"No network. What you type is kept on this phone; photographs and voice notes will go up when the network is back."* Typing is kept on the phone as it happens (not only when a step is turned), and if a half-filled form is opened again it says so — *"Picked up where you left off."*

= 3.5.2 =
* **Fixed: the bar did nothing until the page was reloaded — and the question it asked was unreadable.** Ticking a row left the bar hidden and the count at zero, because the tick boxes sit outside the form (a form inside a form is thrown away by the browser) and the page was listening for ticks on the form. It now listens on the page and matches each tick to the list it belongs to. And when the bar did open, the question read **"Move %1$d %2$s to bin?"** — the raw pattern instead of a sentence. It now reads **Move 2 properties to bin?** / **Move 1 property to bin?**, with the right word for one and for many.
* **Fixed: one row's button used to take the ticked records with it.** The row buttons (Move to bin, Restore, Delete permanently) carried their own little form *inside* the bulk form; the browser throws an inner form away, so its hidden fields spilled into the outer one and a single **Delete permanently** could grab everything that was ticked. Every form is now a form of its own — the bulk form is printed after the list — and a row button moves that row and nothing else. Tested both by hand in the bar and end to end in a real browser.
* **Sharp corners on tag buttons.** Tags, chips, filters and counts are now squared off and read as buttons; only dots, avatars and progress bars stay round. Office, Pocket and the dashboard all follow the same rule.
* **New tests:** a real browser now walks the whole sweep — tick two, read the bar, move them to the bin, find them in the bin, restore them, empty the bin — and a separate one proves a row's button moves only its own record while others are ticked.

= 3.5.1 =
* **Fixed: the bulk bar's buttons said "that link has expired" on every press.** The bar and the row buttons carried one kind of security key and the code behind them checked another, so **Move to bin**, **Restore** and **Delete permanently** from the bar were refused — while the same actions worked from a single row. Both buttons and the code behind them now use the same key, and every swing of the bar is tested end to end over real HTTP, not only in the office's own tests.
* **Fixed: the "Undo" that the notice promised had no button.** After moving something to the bin the notice read "Mistake? Press Undo and they come straight back." — and there was no Undo to press, because the key that offers it was being handed in and quietly dropped. It now travels with the answer, and pressing it puts the whole sweep back (a live property comes back live).
* **Fixed: Empty bin sent you to the wrong screen.** Pressing **Empty bin** — or restoring from the bin — landed you on the Properties list instead of back on the Bin screen, because newer WordPress ignores a referer that is the same page as the request. The forms now say where to return, and after emptying you see **Recycle bin is empty** where you are standing.
* **Smaller:** the record columns in the bin read **Original status** (not "Was"), the same word the filter uses; and the phone's Pocket screen says "restored" everywhere instead of "brought back".

= 3.5.0 =
* **Deleting a property is safe now, and the office can get it back.** The list of properties has tick boxes: tick a few, and a bar appears at the bottom saying how many are ticked, with **Move to bin** on it. Moving them takes them off the website at once — a visitor gets a 404, not a half-deleted page — but nothing is thrown away. There is no one-press way to lose a record: every destructive button first asks, in words, with the exact number in it ("Move 7 properties to bin?").
* **A real recycle bin, not a decorative trash page.** The new **Bin** screen (heading: *Recycle bin*) lists what was set aside with its picture, title, locality, price, **Deleted by**, **Deleted on** and **Original status** — "Moved to bin by Aman · 2 Oct 2026". Every one of them can be **Restored** or **Deleted permanently**, one at a time or in a batch.
* **Restore puts it back exactly where it was.** A live property comes back live; a draft comes back a draft; one waiting for approval comes back waiting; a paused one comes back paused. Availability and verification are not quietly overwritten on the way back.
* **Move to bin is not the same as Delete.** **Paused** means an active property hidden from the website; **In bin** means it has been taken out of the working list and can be brought back. Two different things, two different words, in every screen and filter — and **Deleted** is never used as a status a property can sit in.
* **Permissions are separated, on the server.** An agent may move the properties they handle to the bin and restore their own. Permanent deletion needs the office's own permission — a manager or the owner. Hiding a button is not security, so every single one of these actions is checked again on the server, for every record in the batch.
* **Half-done sweeps say so.** Large selections go to the server in one batch (up to 100 at a time); the bar says **Moving 48 properties to bin…**, and the answer afterwards is either "48 properties moved to bin" or "45 properties moved to bin · 3 could not be moved", with the reasons. Nothing is done one browser request per record, so a slow shared host cannot leave a selection half-done and silent.
* **Undo, and an audit trail.** Just after a sweep, a notice offers **Undo** — a wrong press can be taken back for thirty minutes without hunting through the bin. Every move, restore and permanent deletion is written into the audit trail with who did it, which records, when, and what state they were in before; a bulk move also gives each property its own line in its own history.
* **Enquiries, visits, notes and history stay where they are.** Moving a property to the bin never touches the people who asked about it, the visits that were booked, the notes or the audit trail — they are kept, and they come back with the property. Media is never deleted on the way to the bin; a permanent delete only removes files that nothing else is using, and never a shared one.
* **The list is organised the way an office thinks.** **All · Needs attention · Live · Drafts · Waiting for approval · Paused**, and then, set apart, **Bin** — binned records are not mixed into any count or into any search. The menu shows **Properties 128** and **Bin 7**, permission-aware, down to the honest **Bin 0**.
* **On a phone it becomes a selection mode, not a wide table.** Ticking a row turns the bottom bar into **7 selected** with **Restore / Move to bin / Cancel**, and the same words are used in the phone app. Nothing destructive is ever done by a swipe.
* **Fixed: the older, second way of changing many records is gone.** The properties screen used to have one way of changing records in a batch (the tick boxes) and a second, older one hidden in a form of its own; they could mean slightly different things. There is one path now — the same permission checks, the same confirmation, the same audit line.
* **Fixed: restoring never changes a property's state behind your back.** A property brought back from the bin used to come back as a draft no matter what it was, which took live properties off the website in the middle of a restore. It comes back as it was.

= 3.4.0 =
* **The phone app has a working day in it now.** The first screen is **Today**, and it is built from what is actually unfinished — a site visit this afternoon, a follow-up whose day has passed, a new enquiry nobody has answered, a property the office sent back, a live property nobody has checked with its owner for two weeks. Every job carries its reason under it ("The follow-up was set for 2 October and has passed.") and the one button that finishes it, usually **Call now**. Nothing is listed twice: one client is one job.
* **Five doors and one button.** The bar reads **Today · Leads · Properties · Visits · More**, with a single **＋ Add** in the middle where a thumb already rests. The five doors are the same on a phone and on a desk; everything that is not part of a normal day (ask the office for a change, societies, search, your own details) sits under **More**, named in full instead of hidden behind a guessable icon.
* **Add-anything sheet.** ＋ Add asks one question — "What are you adding?" — and offers the five things an agent actually starts in the field: a property, an enquiry, a visit, what a client wants, and an owner update. Nothing is created until a form is filled in and its own button is pressed, so backing out can never leave half a record behind.
* **An enquiry can be written down in a minute.** Name, phone, what they want (buy/rent, area, budget, a line of notes) and the day to ring them back. It lands in the office the moment it is saved, and the follow-up date appears in Today when the day comes.
* **Visit Mode: before, during, after — on one screen.** *Before you go* ticks the three things that decide whether the visit is worth going to (the owner knows, the client has confirmed, the keys are arranged). *After the visit* asks three questions — did it happen, what did the client think, what happens next — and writes the answers where the office already looks: the visit, the client's own record, and the audit trail. Say the client is not interested and the enquiry moves to **Lost** with the reason the office needs; say they want to go ahead and it moves to **Won**; say "call them tomorrow" and a follow-up date is set by itself.
* **Owner update: thirty seconds after the phone call.** Pick the property, answer three questions (is the money still right, is it still available, what did the owner say) and the office knows the owner was checked today. The property is marked **Checked by agent** — never higher, because only the office may say **Verified by office**. A price or availability change is not quietly written onto a live page: it goes to the office as a change request, through the same path every other change takes.
* **One search box for everything.** Type a name, a number, a sector or a property — "Rahul", "Sector 49", "3 BHK", "98765" — and the answer comes back grouped into **People**, **Properties** and **Visits**, only from what that phone already has the right to see.
* **Every day starts with why.** Jobs are ordered by urgency and each one says where it came from, so "open it and see" is never the answer to "why am I doing this?". Ten new screens read as an app, not as the WordPress admin in a smaller window: 44px tap targets, a sticky search, big thumb-sized choices, and not one WordPress word anywhere in the phone.
* **Fixed: "the follow-up date has passed" was said about people nobody had promised to ring.** The office to-do list asked for overdue follow-ups and was quietly handed the newest enquiries instead — a promise made for tomorrow could sit next to a client nobody had ever scheduled to call. Overdue now means overdue.
* **Fixed: "Add to calendar" on an enquiry never worked.** Pressing it answered "That link has expired. Please go back, refresh the page and try once more." every single time, because the link carried its security key under one name and the check read another. The visit now downloads as a real .ics file — and the link says **Add to calendar** instead of ".ics", which is what a person can actually read.

= 3.3.0 =
* **One state, one word, everywhere.** A property was being described with one word doing four jobs. It now has four separate facts, each with its own word, on every screen, in every email and on the website: where it stands online (**Draft / Waiting for approval / Live / Paused / In bin**), whether it can still be offered (**Available / Under offer / Rented / Sold**), whether anybody checked it (**Not checked yet / Checked by agent / Verified by office**), and how far the building is (**New launch / Under construction / Ready to move**). The same property can honestly be "Live, Available, Not checked yet, Ready to move" — and now it says so.
* **The phone and the office finally read from the same sheet.** One shared vocabulary decides every label (Office → Support → Status), so the office list, the property card, the phone, the flash messages and the website can no longer drift apart.
* **Two words were simply wrong.** A rental that has been let was called **Booked** — it now says **Rented**, and "Booked" is kept for a real booking if that day comes. Paused inventory was called **Hidden**, **Private** or **Inactive** depending on the screen — it is **Paused** everywhere, with the explanation "Paused — kept in the office, hidden from the website."
* **A site visit is no longer "Pending".** A visit is **Scheduled**, then **Completed**, **No-show** or **Cancelled**. An office request is **Waiting for office / Approved / Declined** — and "Approved and applied" stays where it belongs, in the message after the office says yes, not on the badge.
* **The client journey is enforced, not just drawn.** An enquiry goes New → Contacted → Scheduled → Won or Lost (a client can go cold from any step). A visit can be finished, missed or cancelled — but not quietly reopened. A brand-new enquiry can no longer be marked "Won" without anybody speaking to the client: the server refuses the jump, whoever posts the form. The office itself may still put any record right by hand, and every such change is written to the audit trail.
* Pocket now offers only the steps that are actually open (the current state plus the legal moves), so the phone can never present a button the server would refuse.

= 3.2.9 =
* **A sheet of societies is no longer brought in as properties.** The upload box asks "What is in this file?" and "Properties (listings)" is the first answer — so a builder's master sheet left on the default turned every society into a property, and the office's property list filled up with names like "DLF The Camellias". The file's own columns are now read first: a sheet with Developer, Possession, Total units or a RERA number is brought in as Societies / Projects, and the preview screen says so in one line before anything is saved.
* **If we read it the other way round, you are told and can put it back with one click.** The preview carries a notice naming what you picked and what the columns say, and a button that reads the file again as the kind you picked — no second upload.
* Undoing an import now names what it removes ("Societies and projects it added will go to the bin") instead of always saying "Properties".
* The upload box says what happens if you are unsure: leave the answer as it is, and the next screen tells you what the columns said.

= 3.2.8 =
* **A property can no longer go on the website without saying what it is.** "Apartment" was quietly filled in when the question was never answered — a plot could be published as an apartment. A blank now stays blank, a draft may still be unfinished, and putting a property on the website asks for the type (and sale/rent) first. The phone app now asks for the type on the same step as sale/rent, and the office form marks both as required instead of "optional".
* **An older or imported type is never lost.** A record holding a name the shortened list no longer offers ("Flat", or something imported from elsewhere) opens with that same name still chosen, marked "(as written before)", in both the office and the phone app — instead of quietly switching the answer on the next save.
* **Reports: a rental's average price was always "₹0".** The figure sits in the rent column, and the report only read the price column. It now reads the right one, and writes a monthly figure the way the website does ("₹75,000 a month") rather than shortening a rent to "₹75 K".
* **Insights: the line under the list says what the list is.** It read "Newest first." — that explains the sorting, not the writing. Each of Blogs, Articles and Insights now gets its own sentence, and the button says what it will create ("Write a new article").
* Every one of the 48 property answers now has a home: 41 can be typed in the office, 38 on the phone, the rest are marked as filled in by the plugin itself or as another name for the same figure. Two gaps closed: **Company** (shown when the office runs more than one company) and the registration number.
* The same figure under a second name (a rent kept in `_estat_rent`, prices in `_estat_price_min`/`max`) is now written down as such, so nothing looks like a missing question.

= 3.2.7 =
* **Fix: the website could go down on the 3.2.6 update.** With the newest Elementor installed, every page of the website could answer with "There has been a critical error on this website" while the office and the phone app kept working normally. 3.2.6 asked Elementor for its page templates in a way that the newest Elementor no longer accepts. The question is now asked only on a property page, only when it matters, only once per page — and it is wrapped so that **no answer from Elementor, and no trouble inside Elementor, can stop the website from opening**. The office, the phone app, the sitemap and search were never affected.
* If anything unexpected ever happens while the plugin is choosing a page's design, WordPress now draws the page in the normal way and leaves a line in the site's log instead of showing an error to visitors.
* The WhatsApp button's edit-time check in Elementor goes through the same safe path.

= 3.2.6 =
* **A WhatsApp button on every property and society page.** One tap and the message is already written — the property's name, its price and its link — so the chat does not start with "which property?". Turn it off from Settings if you would rather not have it. It is also available as the **WhatsApp Button** widget in Elementor and as `[estat_whatsapp]`. Taps are counted on the property itself, not written into Enquiries, because a tap arrives with no name and no number to call back on.
* **The pages an older version made have been tidied.** They were carrying the office's own notes ("Team directory — agents with phone, WhatsApp, listings count", "Advanced EMI — ... (F10)") and a search engine was printing those lines under the site in Google. Every page now opens with one plain sentence for the visitor, and a page called "office" that had no job left has been put aside as a draft. Settings → Advanced → Tools → **Tidy the pages the plugin made earlier**. A page the office has written itself is never touched.
* **Cache clears itself on every update**, and there is a **Clear the website's saved copy** button for the times you changed something and the site still shows yesterday.
* **A property page can be left entirely to your theme or Elementor.** Settings → Listings → "Who draws a property page" is set to *My website* by default, and on that setting the plugin will not replace a page you built.
* **The sitemap and the noindex list now agree.** /search/, /alerts/, /favorites/, /compare/ and /thank-you/ were in the sitemap while being kept out of Google — they are out of the sitemap now. The /notes/ page is a real page of yours, so it is no longer kept out of search.
* A description that was only the page name ("Notes") is no longer used as the meta description; the plugin writes a proper line instead.
* 17 more lines of interface language, and plainer wording where a developer's shorthand had been left on screen.

= 3.2.5 =
* Societies and projects no longer sit inside the property list. The phone app's list now has two chips — **Properties** and **Societies & Projects** — and only ever shows one of them.
* A society or project has its own page on the phone: stage, builder, price, possession, and a link to the website. No property form, no "carry on editing", nothing that would write flat details onto a society.
* The property form now refuses a society twice over — the screen will not open it, and the server will not save it — so a typed URL cannot mangle an office record either.
* The bin and the office's "waiting for approval" list are split the same way.
* Counts ("N of your listings are live", the numbers on **You**) count properties only, because a society is not a flat.

= 3.2.4 =
* The staff phone app now has its own **You** screen: your name, phone, WhatsApp and email, the language you read, and your own password — all in one place, from the phone.
* The office's own settings stay with the office. The app only shows what the office decided, read-only.
* Changing the password signs you out on other devices, but keeps the phone you are holding signed in.
* Fix: the new screen's link had no page behind it (404) — one list in the plugin was missing the name; caught by the tests, now fixed and guarded.
* No office data moves: your details are saved on your own team record, the same one the office already sees.

= 3.2.3 =
* Fixed: the boxes on the staff phone app had no border at all. Cause: the shorter colour names ("card", "line-strong") were spelled out inside the office stylesheet only, and the phone app loads a smaller set of files — so a colour came out as nothing and CSS threw the whole line away. Those names now live in tokens.css, once, for every surface: office screens, the phone app, the PC dashboard and the website.
* Fixed: a couple of rounded corners on the PC dashboard were also nothing, because two more names were missing there.
* Fixed: the little badge at the top of the phone app read "Mobile Mobile" (the word was written in the page and drawn again by the stylesheet). It reads "Mobile" once now.
* New: a test (css_vars_check.py) that reads every surface's stylesheets and reports any colour name that would come out empty, so this quiet kind of fault cannot come back.
* New: a test (har_button_check.py) that opens every office screen and the whole staff app and presses every button the way a person would, then reports any button that does nothing or breaks the page. It now reports none.
* New: a test (pocket_look.js) that opens the staff app on a phone-sized screen and checks the boxes, the labels and the gaps between sections.
* The test bed now really starts fresh: every rebuild puts the settings back on their default and re-fills the office details, so one test can no longer make another one fail.

= 3.2.2 =
* New: a Settings section in the plugin menu. One place with ten lines — Overview, Office details, Properties, Enquiries & emails, Staff app (Pocket), Integrations, Advanced & tools, Website forms, Page blocks, Colours & fonts. Every switch that changes the office or the staff phone app is on one of its tabs.
* New: a working "Send a test email to me" button on Settings — Enquiries & emails, so you can find out in one press whether your emails actually go out.
* New: forms now look like forms. Every box has a visible border, a white background and a comfortable height, labels are darker, and the property editor's chapters sit in their own cards with a clear gap between them. The grey WordPress background is gone from these screens.
* New: a new society saved with nothing chosen is stored as Residence / Planning, and "not said yet" still means not said yet.
* Fixed: lists sent to the server were being thrown away. Settings' "Save changes", the website-forms form, the ticks on Add a home, ticks in bulk actions, the pages chosen in Setup and the colour names all arrived as an empty string, so nothing was saved. They arrive whole now.
* Fixed: saving one settings tab no longer switches off the other tabs' switches (print sheet, EMI calculator, share buttons).
* Fixed: a change request sent from the staff pocket app carried no changes, because the agent's answers were flattened on the way in. The office side of the same form had the same fault.
* Fixed: "Repair broken localities + draft pages" crashed instead of repairing, because it called a class by a name that does not exist.
* Fixed: the version the browser is told to ask for was two releases old, so an old stylesheet could stay on screen after an update.
* Fixed: the Settings lines were listed in the wrong order and WordPress added its own duplicate of the first line.

= 3.2.1 =
* New: a master sheet of projects now imports in one go. A 171-row file used to be read 50 rows at a time — four visits to the screen, and anything you did not come back for waited a day. The whole file is read while the request still has time, and the daily job only takes what is left.
* New: the import screen works out what the file is on its own. A builder's master sheet, a 99acres export and a plain CSV are told apart from the column names, so nothing has to be chosen before the first look.
* New: before anything is written, the preview lists every column in your file in the sheet's own order and says what will happen to it — "Read" with the box it goes into, or "Not used" with the reason. A column we leave alone is never a silence again.
* Fixed: a "Dry run" only looked at the first 50 rows of a large file and called that the whole picture. It now reads the entire file and reports the true count.
* Fixed: a project's "as written" price column was thrown away after the price was read from it. "On request", "Poss. Oct 2027" and a per-square-foot rate are the office's own words — a price is now read out of that column, a possession date out of it, and whatever is left is kept as a highlight.
* Fixed: a master sheet's second area column ("Sector 62 / GCER") was becoming its own area page beside the micro-market that is the same place. The sector is folded into the address line instead, and the city is written once at the end of it.
* Fixed: the stage was missed on rows where the sheet had written it in another column in a form we did not recognise ("Upcoming / Pre-launch", "Ready (Operational)"). Stages are read as whole words now, so "OC received" is ready to move while the "oc" inside "block" is still nothing.
* Fixed: a project's kind ("Affordable / DDJAY", "Group Housing", "Office + Retail") is turned into one of the five the record holds, instead of every imported project landing on "other".
* Fixed: undoing an import of 171 rows reported 342 records put back — each record was counted twice, once for its words and once for its fields.
* Fixed: the project page's search-engine line now starts with the project's own name ("DLF The Camellias is a Residential Apartment + Penthouse project in Golf Course Road"), and the facts on the page come out of the record the import actually wrote.

= 3.2.0 =
* New: the plugin now decides what a search engine is told about its own pages, and writes it down in one place. A published property, and an area or amenity page that actually holds something, may be indexed. A filtered view of the properties list (?offer=rent&bedrooms_min=3) points at the clean address instead of competing with it. Search, saved properties, compare and thank-you are kept out of the index.
* New: an area page, a project page or the properties list with nothing to show is kept out of the index until something is listed there — nobody wants to land on an empty directory.
* New: titles and one-line descriptions are built from the office's own records. The properties list says how many are for sale and how many to rent; an area page says how many properties it holds and the cheapest one; a property says its bedrooms, type, area and price. If the office (or the SEO plugin) has written its own title or description for a page, that wins and nothing is overwritten.
* New: "these records need filling in" — a card on Listings that lists what is missing from each property and links straight to it, the same list inside the property's own editor, and a CSV to fix in Excel and import back. It catches a name that says 4 BHK while the record says 1 bedroom, a size of 0, a missing price, no locality, no photo, no owner, no verification, and a description too short to mean anything.
* New: area names that an import cut in half ("Sohna Road (Sector 49") are pointed out on Import & export with a merge tool — every property moves onto the name that stays, then the broken name is removed. Nothing else is deleted.
* Fixed: a property whose availability was never filled in was published to search engines as "SoldOut". A blank answer was being turned into a claim nobody made. Availability is only stated when the office stated it, and an unknown answer is now simply left out of the structured data.
* Fixed: the structured address now carries the region and country as well as the locality.
* New: a test for all of it (wp_test/seo_check.php): indexing rules, titles, descriptions, structured data and the data health list — 79 checks.

= 3.1.9 =
* New: the staff phone app now asks for a property the same way the office does, one short step at a time — what it is and where, the price, size and rooms, photos and video, the description, then a last look at everything you typed before you save. An office user also gets a seventh step for the answers only the office may give.
* New: the property form shows a review step. It lists every answer you gave, step by step, with an "Ise theek kijiye" link back to the box that needs changing, and it never shows a question you have not reached yet.
* New: photos on the phone: the first photo is the one the website leads with, a star button on any photo moves it to the front, and a cross takes a photo out of the list.
* New: deleting a property is one clear step with a plain question behind it. It goes to the office bin, comes off the website, and "Wapas laiye" on the listings screen brings it back — straight onto the website for the office, and back to draft for an agent.
* New: the office listing editor has a "Manage this property" card at the end of the form, so the same remove, undo and delete-for-good buttons are reachable from the record you are looking at.
* Fixed: empty money boxes on the phone were coming up as 0, and a saved blank deposit was stored as "0" — the website then said "Deposit 0". A blank box now stays blank.
* Fixed: the last step of the phone form was blank, with no Save button and nothing to review; it now shows the full review and the save buttons.
* Changed: "New listing" on the phone's Add button is "Add a property", and a row with no price says where the property stands ("Abhi adhoori hai", "Office ke paas", "Website par hai", "Rok di gayi") instead of "Price not set yet".
* New: the import screen's sample file is now four files — properties, societies, team and enquiries — so a sheet of Gurgaon societies no longer comes with a property's columns on it. The society column names are printed on the same screen.
* New: four tests for this work — one compares the office form's fields with the phone's (46 and 45, every one in one step), one saves a property from the phone and checks the office record comes out identical, one drives the whole workflow over real HTTP with real photo uploads, and one opens the phone form in a headless browser and walks through all seven steps.

= 3.1.8 =
* Changed: the last English corners of the office read Hinglish now. Every setting on Office > Colours and fonts had an English name ("Ink (main text)", "Gap MD"); they say what they do in Hinglish instead. The list of pages on the website and in Finish setup had names that never followed the language setting; now they do.
* Fixed: the enquiry form on the website kept the English field names it was born with ("Your name", "Send enquiry") even after the office switched the language. The form now follows the language setting, and a name the office typed itself is left exactly as typed.
* Fixed: the staff app's property form printed a developer line at the top — "Step 1 of 4 - Mobile - 4-step wizard". It now reads "Step 1 / 4 - Kya aur kahan", and the lines it uses to nag you ("Title needed") are Hinglish too.
* Fixed: the staff app's enquiry screen printed the raw stored values — "sell - form". It now reads "Bechna - Website form", and a set-aside enquiry says "Alag rakha: ..." instead of "lost: ...".
* Fixed: the page list on the website printed each page's machine name ("- /properties") and the name of its icon in large letters ("map-pin"). It now shows the real icon and one of two plain lines: "Website par hai" or "Abhi nahi bana".
* Fixed: the "Preview" button beside each export on Import & export now says "Pehle dekhiye".
* New: a test that reads every screen and the whole website twice — once in Hinglish, once in English — and complains about any line that stayed English. The lines that should stay English (names, addresses, "Listings", "Enquiries") are written down in wp_test/hinglish-keep.txt.

= 3.1.7 =
* Fixed: the website never loaded the plugin's colour and font file (tokens.css) — only the office did. Every colour, size and font on the plugin's own pages was quietly falling back to the browser's defaults, and "Colours and fonts" in Office Settings changed the office screens but not the website. The website now loads that file first, and the setting works on both.
* Changed: no colour is written down twice any more. The public pages, the forms and the share buttons read every colour from that one file (the WhatsApp button keeps WhatsApp's own green, on purpose).
* Changed: Reports says what is inside it instead of offering advice — "How the office is doing" is now "Enquiries, visits and deals", "What you have to sell" is "The properties you have", and the sentence about a healthy office turning one in twenty enquiries into a deal is gone.

= 3.1.6 =
* Changed: the property form now asks "Is this for sale, rent or lease?" before anything else, and the money box is named after that answer — Price for a sale, Monthly rent for a rental, from one box rather than two.
* Changed: fields that cannot apply are hidden instead of filling the page — a plot has no bedrooms or bathrooms, a sale has no deposit or maintenance, and a plot is never asked which floor it is on. Nothing is deleted: the answer stays in the record and comes back the moment the first answer changes.
* Changed: the property form is three short parts. The everyday answers are open; the rest sits behind grey lines that say how many boxes are inside them (23 of the 46 on an ordinary listing), and each line opens by itself when it already holds something.
* New: "Add a home" follows the same order and hides the bedroom box for a plot, a shop, an office or a warehouse.
* Fixed: nothing. This release only makes the form shorter; every field that existed before it still exists, which a test checks against the previous build.

= 3.1.5 =
* New: every code you need to skip typing — the staff phone app, the office PC dashboard and the office location sit together on Office → Overview, and each team member has his own QR sheet on Team (the QR button beside his name).
* New: "Print this sheet" on a team member's QR screen. The sheet carries two codes — the app on his own phone, and the page a client should open — and prints without the WordPress menu around it.
* Fixed: the printed property page used to fetch its QR picture from an outside website (api.qrserver.com). That meant every print sent the property link to somebody else's server, and with the internet down the sheet came out with an empty box. The code is now drawn by the plugin itself, so it always appears.
* Changed: the plugin draws QR codes on its own — no account, no key, no outside service, and it works with the internet switched off. Codes hold up to 213 characters, which covers any page address on this site.

= 3.1.3 =
* Fixed: switches in Office Settings could be turned on but never off. Every tick box on the settings screens now saves both ways.
* Fixed: the Pipeline screen printed a PHP warning line at the bottom ("Undefined variable $deleted") in place of its footer.
* Fixed: the single price box on a property form. A monthly rent typed into it was saved as a sale price, so the property lost its rent. Sales and rentals both store the right number now.
* Fixed: Page blocks showed two headings and printed the machine name of every block beside its label.
* Fixed: Reports listed "Website form" twice when messages arrived through two kinds of form; the counts are added together on one line.
* Fixed: property cards showed "apartment" and "farm_house" instead of Apartment and Farm House, and the count banners said "Everything on the books", "Public" and "Confidential".
* Fixed: the Office Settings breadcrumb read "Office / Office / Office overview".
* Removed: "Add custom block" on Page blocks, which asked for a "hook" or a "child theme" and could not work without a developer.
* New: "Put them all on the website" on Listings, so drafts do not have to be opened one at a time.
* New: the Elementor message switch also sits on the Forms screen, next to the forms it collects from.
* Changed: Insights described itself as what visitors look at most; it now describes what it holds — blog posts, articles and market notes.

= 3.1.4 =
* Changed: the office now gets four emails and no more — a new enquiry, a property waiting for approval, a summary every morning at 8, and a report every Monday at 8. The other fifteen notification switches are gone from the settings screen, and those emails are not sent at all any more.
* New: the morning summary and the weekly report. Both are plain text, both can be switched off, and both are also on the screens.
* Fixed: the "Emails — templates" boxes on the settings screen saved subject and body text that nothing ever read. They are gone; the From name, From address and footer line, which do work, are still there.
* Removed: the hourly job that mailed the office a day before every site visit — that reminder is on the Today screen instead.

= 3.1.2 =
* Changed: the icons on the office screens now come from the plugin itself instead of Google Fonts. The twelve requests to fonts.googleapis.com are gone, and an icon can no longer show up as the word "add_home" when the network is slow or blocked.
* Changed: the translation template was 700 strings behind the code. It now matches exactly (2,228 strings), and 189 new Hinglish lines were added for the words you see every day on Today, Listings, Enquiries and Change requests.
* New: help text for the five screens that had none (Change requests, Pipeline, Search alerts, Page blocks, Colours and fonts).
* Fixed: Team and Today showed the machine word for a record's state ("publish", "draft"). They now say Live, Draft, Waiting, Hidden, Scheduled or Bin.
* Changed: the "Ledger" view toggle is now called "Table".
* Changed: the technical details for support are folded away behind "Asking someone for help?" instead of sitting open in every screen's help panel.

= 3.1.1 =
* Fixed: every property page returned a 500 error because the enquiry form it asked for did not exist. The form now renders, and falls back to a call/WhatsApp/email strip when no form is set up yet.
* Fixed: the Today screen stopped with a fatal error, and its work list would have shown buttons with no text.
* Fixed: the forms API endpoint (/wp-json/estat/v2/forms) stopped with a fatal error.
* New: messages sent through Elementor forms now also arrive in Enquiries (Office -> Integrations).
* New: the office's own name, phone, WhatsApp, email, address, hours and city come pre-filled; existing values are never overwritten.
* Fixed: 21 stylesheet values that screens asked for were never defined, so some gaps, text sizes, chips and focus rings did nothing.
* Changed: Listings, Listings (new) and Team tables become cards on a phone, like the other screens.
* Changed: the last hard-coded colour in the admin now uses the shared chip style.

= 3.1.0 =
* The older screens (Enquiries, Change requests, Spreadsheet, Search alerts, Import history, Templates) now wear the new design: same header, chips, cards, tables, buttons and fields as the rest.
* Search alerts stopped showing internal words. Columns are Person, What they are watching, How often, Status, Last email, Actions.
* An import's state reads Finished, Undone, In progress or Waiting instead of the machine word.
* Every colour on those screens now comes from one place. The last inline colours are gone.
* On a phone, the lists that have labels turn into one card per row.
* A duplicate setting on the Office screen was removed, so the two copies stop overwriting each other.

= 3.0.9 =
* The old interface and the on-off switch are gone. One list decides the menu and the screens.
* One property now shows three separate things: Website (Live / Draft / Hidden), Availability (Available / Under offer / Booked / Sold) and Freshness (Just listed / Ready to move).
* All admin colours come from one file. The dark theme now works. Three screen sizes, and tables become cards on a phone.
* Ten settings that had gone missing from the office screen are back. Four more (city, from name, from address, email footer) now actually save and are used.
* No client name, British agency wording or internal release codes anywhere the office can see them.


= 2.8.0 =
* The agent pocket: yoursite.com/agent opens a phone-first screen where team
  members add listings (as drafts for approval), ask for changes on live
  ones, log visits, and answer enquiries — signed in with their normal
  WordPress account, no app, no new passwords. Owners and managers also get
  an Approvals tab, so a change can be said yes to from a phone, through the
  same paths (audit, index, undo) as the dashboard.
* Approval honesty fix: approving a change request no longer touches the
  record's publication state. Previously the write-through quietly returned a
  live listing to draft; no screen asked for that, and now nothing does.

= 2.7.0 =
* Agents can now propose a correction to a property that belongs to a
  colleague. The office approves or turns it down on the new Change Requests
  screen; nothing on the website changes until they do.
* A leftover entry in the action permission map is gone. Removing a property was
  (and remains) available on every listing row; the dead entry made an auditor
  believe deletion had no route at all.

= 2.3.0 =
* Twelve listing fields were being collected and shown to nobody. All are now
  on the property page, including deposit, maintenance, video and 360 tour.
* Projects had no reader at all; the builder, price range, unit counts and
  possession date now appear on the project page.
* "Export site visits" produced an empty listings sheet. It now exports visits.
* Erasing everything on uninstall missed Insights and its two taxonomies.
* One caller typing "9876543210" and "+919876543210" became two enquiries.
* Titles are capped and control characters stripped.
* Today and Listings now check permission themselves rather than relying on
  the menu alone.

= 2.2.0 =
* Act on many records at once, with permission checked per record.
* Undo the last edit to a listing, society or team member.
* Keyboard shortcuts, with a visible list under "?".
* Hinglish finished: 1,504 strings.

= 2.1.0 =
* Dropdowns no longer hide records past the two hundredth without saying so.
* Societies and Team can be searched and paged.
* Nonsense numbers are refused with an explanation.

= 2.0.0 =
* A real type scale, a real icon set, and no pure black or white.

Earlier releases are listed in CHANGELOG.md inside the plugin folder.

== Upgrade Notice ==

= 2.3.0 =
Fixes twelve property fields and seven project fields that were saved but never
displayed. If you have been filling in deposit, video links or possession dates,
they will start appearing on your website after this update.
